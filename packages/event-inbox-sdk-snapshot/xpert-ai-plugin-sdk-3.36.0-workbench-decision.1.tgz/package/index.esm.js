import { Module, applyDecorators, SetMetadata, HttpException, HttpStatus, BadRequestException, Injectable, Inject, Logger, Optional, UnauthorizedException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { MODULE_METADATA } from '@nestjs/common/constants.js';
import { pick } from 'lodash-es';
import { dispatchCustomEvent } from '@langchain/core/callbacks/dispatch';
import { ChatMessageEventTypeEnum, createResourceCardContent, LanguagesEnum, parseAnalyticsDiagnostic, ParameterType, AiModelTypeEnum, PriceType, FetchFrom, ModelPropertyKey, readModelConfiguration, ModelFeature, isDiscoverableModelType, configurationFromModel, SecretTokenBindingType, projectTaskExecutionContextSchema, projectTaskExecutionReferenceSchema, agentRuntimeProgressSchema, agentInvocationTerminalStatusSchema, projectPipelineWorkContextSchema, WorkflowNodeTypeEnum, iconDefinitionSchema, MCP_REQUIRED_CONTEXTS, MCP_CAPABILITY_APPROVAL_MODES, MCP_TOOL_RISKS, MCP_TOOL_SIDE_EFFECTS, MCP_TOOL_IDEMPOTENCY, MCP_CAPABILITY_VISIBILITIES, PLUGIN_COMPONENT_TYPE, projectPipelineContributionSchema, projectPipelineRefSchema, pluginAgentEventSchema, agentEventDecisionSchema } from '@xpert-ai/contracts';
export { ASSISTANT_CHAT_SEND_MESSAGE_COMMAND, ASSISTANT_CONTEXT_SET_COMMAND, agentDeliveryRecoverySchema, agentEventDecisionSchema, agentEventRefSchema, agentOutputDeliverySchema, agentResultPathSchema, configurationFromModel, createResourceCardContent, humanDecisionInputSchema, humanDecisionSchema, parseResourceCard, pluginAgentEventSchema, projectPipelineContributionSchema, resourceCardId } from '@xpert-ai/contracts';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { Subject, filter } from 'rxjs';
import { _ as _extends } from './_extends.esm.js';
import { AsyncLocalStorage } from 'node:async_hooks';
import { ExtractJwt } from 'passport-jwt';
import { randomUUID, createHash as createHash$1 } from 'node:crypto';
import { Query, Command } from '@nestjs/cqrs';
import * as fs from 'fs';
import fs__default from 'fs';
import http from 'http';
import https from 'https';
import { c as createRuntimeCapability, B as BuiltinToolset, W as WorkspaceFilesRuntimeCapability } from './model-provider.esm.js';
export { A as ActorTokenRuntimeCapability, a as ActorTokenRuntimeFactoryCapability, b as ArtifactContentRuntimeCapability, d as ArtifactDraftsRuntimeCapability, e as ArtifactLibraryRuntimeCapability, f as ArtifactUseGrantsRuntimeCapability, g as ArtifactsRuntimeCapability, h as AssistantMiddlewareAccessRuntimeCapability, i as BaseTool, j as BaseToolset, D as DefaultAgentMiddlewareRuntimeCapabilityRegistry, D as DefaultRuntimeCapabilityRegistry, k as McpClientRuntimeCapability, M as ModelProviderBuiltinToolset, P as PluginTestAccessCapability, l as ProjectAccessRuntimeCapability, m as ProjectConfigurationRuntimeCapability, n as ProjectFilesRuntimeCapability, o as ProjectKnowledgeRuntimeCapability, p as ProjectProvisioningRuntimeCapability, R as RUNTIME_CAPABILITY_PROVIDER, q as RestClientRuntimeCapability, r as RuntimeCapabilityProvider, S as SANDBOX_JOB_ERROR_CODES, s as SANDBOX_JOB_INVOCATION_PREFIX, t as SANDBOX_JOB_PROGRESS_PREFIX, u as SandboxJobRuntimeError, v as SandboxJobsRuntimeCapability, T as ToolImagesRuntimeCapability, w as WORKSPACE_FILES_SOURCE, X as XPERT_RUNTIME_CAPABILITIES_TOKEN, x as isSandboxJobRuntimeError, y as workspaceFileMutationMetadata, z as workspaceFileMutationPath, C as workspaceRelativeDirectoryPathSchema, E as workspaceRelativeFilePathSchema } from './model-provider.esm.js';
import fsPromises from 'fs/promises';
import * as path from 'path';
import path__default, { join } from 'path';
import { z, ZodError, ZodFirstPartyTypeKind } from 'zod/v3';
import { createInstance } from 'i18next';
import FsBackend from 'i18next-fs-backend';
import * as yaml from 'yaml';
import yaml__default from 'yaml';
import Ajv from 'ajv';
import schemaDraft04 from 'ajv/dist/refs/json-schema-draft-06.json';
import * as _axios from 'axios';
export { DataSourceRuntimeCapability } from './data-workbench.esm.js';
export { c as analyticsBindingObjectSchema, d as analyticsBindingSchema, a as analyticsCertificationSchema, e as analyticsControlsSchema, f as analyticsDiscoveryRequestObjectSchema, g as analyticsDiscoveryRequestSchema, h as analyticsDiscoveryResultSchema, b as analyticsFieldSchema, j as analyticsOptionsSchema, k as analyticsParameterSchema, l as analyticsQueryRequestSchema, m as analyticsSourceKey, n as analyticsSourceRefSchema, o as normalizeAnalyticsResult, p as parseAnalyticsCertification, r as resolveAnalyticsParameters, v as validateAnalyticsBinding } from './analytics-result.esm.js';
import { BaseCallbackHandler } from '@langchain/core/callbacks/base';
import { ChatGenerationChunk } from '@langchain/core/outputs';
import { isBaseMessage, isAIMessage, isAIMessageChunk, AIMessage } from '@langchain/core/messages';
import { ChatOpenAICompletions, OpenAIEmbeddings } from '@langchain/openai';
import { Document } from '@langchain/core/documents';
import { BaseChatModel } from '@langchain/core/language_models/chat_models';
import { getEnvironmentVariable } from '@langchain/core/utils/env';
export { ModelProviderHttpClient, ModelProviderHttpError } from './model-provider-http-client.esm.js';
import { getEncodingNameForModel, encodingForModel, getEncoding } from 'js-tiktoken';
import { z as z$1 } from 'zod';
export { A as AGENT_TASK_REPORT_MAX_BYTES, a as AGENT_TASK_RESULTS_FEATURE, b as agentResultItemSchema } from './results.esm.js';
import { assertConnectorDefinition } from './connector.esm.js';
export { CONNECTOR_AUTHORIZATION_MODES, CONNECTOR_SCOPE_TYPES, getConnectorAuthMethods, getConnectorAuthorizationModes } from './connector.esm.js';
import { isAbsolute, relative, resolve, sep } from 'node:path';
import { _ as _object_without_properties_loose$2 } from './_object_without_properties_loose.esm.js';
export { base64ToBytes, bytesToBase64, createCollaborationClient, createCollaborationPresenceStore, createOperationCollaborationClient, createSocketIoTransportAdapter, createYjsDocumentAdapter, parseCollaborationPresence } from './collaboration-client.esm.js';
import { createHash } from 'crypto';
import { tool } from '@langchain/core/tools';

/**
 * Metadata keys used in plugins for defining various aspects like entities, subscribers, and configurations.
 */ const PLUGIN_METADATA = {
    /**
     * Key representing the entities registered within the plugin.
     */ ENTITIES: 'entities',
    /**
     * Key representing event subscribers within the plugin.
     */ SUBSCRIBERS: 'subscribers'
};

/**
 * Decorator function for extending NestJS features with additional metadata.
 *
 * @param pluginMetadata Metadata to be applied to the target class.
 * @returns Class decorator function.
 */ function XpertServerPlugin(pluginMetadata) {
    return (targetClass)=>{
        // Iterate over properties in PLUGIN_METADATA
        for (const metadataProperty of Object.values(PLUGIN_METADATA)){
            const property = metadataProperty;
            // Check if the property exists in pluginMetadata and is not undefined
            if (property in pluginMetadata && pluginMetadata[property] !== undefined) {
                // Set metadata on the target class using Reflect
                Reflect.defineMetadata(property, pluginMetadata[property] || [], targetClass);
            }
        }
        // Pick relevant metadata from pluginMetadata based on MODULE_METADATA values
        const metadata = pick(pluginMetadata, Object.values(MODULE_METADATA));
        // Apply the Module decorator with the picked metadata
        Module(metadata)(targetClass);
    };
}

const ARTIFACT_NAMESPACE_PATTERN = /^[a-z0-9_]+$/;
function normalizeArtifactSegment(value) {
    return value.trim().replace(/^@[^/]+\//, '').replace(/^plugin[-_]/, '').replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/[^A-Za-z0-9]+/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '').toLowerCase();
}
/**
 * Derive the v1 default artifact namespace from an npm package name.
 * Explicit `artifactNamespace` should stay stable after publish; this fallback is for compatibility.
 */ function derivePluginArtifactNamespace(packageName) {
    const namespace = normalizeArtifactSegment(packageName);
    assertPluginArtifactNamePart(namespace, 'artifact namespace');
    return namespace;
}
/**
 * Build the physical table name for a plugin-owned database table.
 * Keep table keys stable; the returned name is part of the plugin data contract.
 */ function pluginArtifactTableName(namespace, tableKey) {
    const normalizedNamespace = namespace.trim();
    const normalizedTableKey = tableKey.trim();
    assertPluginArtifactNamePart(normalizedNamespace, 'artifact namespace');
    assertPluginArtifactNamePart(normalizedTableKey, 'artifact table key');
    return `plugin_${normalizedNamespace}_${normalizedTableKey}`;
}
function assertPluginArtifactNamePart(value, label) {
    if (!value || !ARTIFACT_NAMESPACE_PATTERN.test(value)) {
        throw new Error(`${label} must contain only lowercase letters, numbers, and underscores`);
    }
}
function isPluginArtifactNamespace(value) {
    return typeof value === 'string' && ARTIFACT_NAMESPACE_PATTERN.test(value);
}

/** Call after the business mutation commits. A display failure must not retry that mutation. */ async function emitResourceCard(card, config) {
    await dispatchCustomEvent(ChatMessageEventTypeEnum.ON_CHAT_EVENT, createResourceCardContent(card), config);
}

const ORGANIZATION_METADATA_KEY = 'xpert:organizationId';
const PLUGIN_METADATA_KEY = 'xpert:pluginName';
const PLUGIN_VERSION_METADATA_KEY = 'xpert:pluginVersion';
const GLOBAL_ORGANIZATION_SCOPE = 'global';
const SYSTEM_GLOBAL_SCOPE = 'system:global';
const BUILTIN_GLOBAL_SCOPE = 'builtin:global';
const TENANT_GLOBAL_SCOPE_PREFIX = 'tenant:';
const TENANT_GLOBAL_SCOPE_SUFFIX = ':global';
const STRATEGY_META_KEY = 'XPERT_STRATEGY_META_KEY';
let defaultTenantId = null;
function normalizeOptionalString(value) {
    return typeof value === 'string' && value.trim().length > 0 ? value.trim() : null;
}
function getTenantGlobalScopeKey(tenantId) {
    return `${TENANT_GLOBAL_SCOPE_PREFIX}${tenantId}${TENANT_GLOBAL_SCOPE_SUFFIX}`;
}
function isTenantGlobalScopeKey(value) {
    return typeof value === 'string' && value.startsWith(TENANT_GLOBAL_SCOPE_PREFIX) && value.endsWith(TENANT_GLOBAL_SCOPE_SUFFIX);
}
function setDefaultTenantId(tenantId) {
    defaultTenantId = normalizeOptionalString(tenantId);
}
function getDefaultTenantId() {
    return defaultTenantId;
}
function resolveTenantGlobalScopeKey(tenantId) {
    const normalizedTenantId = normalizeOptionalString(tenantId);
    if (!normalizedTenantId) {
        return GLOBAL_ORGANIZATION_SCOPE;
    }
    if (defaultTenantId && normalizedTenantId !== defaultTenantId) {
        return getTenantGlobalScopeKey(normalizedTenantId);
    }
    return GLOBAL_ORGANIZATION_SCOPE;
}

const RESOURCE_CARD_PROVIDER = 'RESOURCE_CARD_PROVIDER';
/** Register exact resource types whose message cards opt in to live refresh. */ const ResourceCardProvider = (...resources)=>{
    if (!resources.length || resources.some(({ namespace, type })=>!(namespace == null ? void 0 : namespace.trim()) || !(type == null ? void 0 : type.trim()))) {
        throw new Error('ResourceCardProvider requires explicit resource namespaces and types');
    }
    return applyDecorators(SetMetadata(RESOURCE_CARD_PROVIDER, resources), SetMetadata(STRATEGY_META_KEY, RESOURCE_CARD_PROVIDER));
};

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
typeof SuppressedError === "function" ? SuppressedError : function _SuppressedError(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

// request-context.ts
const TENANT_SCOPE = 'tenant';
const ORGANIZATION_SCOPE = 'organization';
class RequestContext {
    static currentRequestContext() {
        const session = getRequestContext();
        return session;
    }
    /** @deprecated For resource authorization use currentApiPrincipal()?.resourceScope; retained for credential metadata. */ static currentApiKey() {
        var _RequestContext_currentApiPrincipal;
        var _RequestContext_currentApiPrincipal_apiKey;
        return (_RequestContext_currentApiPrincipal_apiKey = (_RequestContext_currentApiPrincipal = RequestContext.currentApiPrincipal()) == null ? void 0 : _RequestContext_currentApiPrincipal.apiKey) != null ? _RequestContext_currentApiPrincipal_apiKey : null;
    }
    static currentApiPrincipal() {
        const user = RequestContext.currentUser();
        // Conversation-scoped client secrets carry no synthetic API key.
        return (user == null ? void 0 : user.apiKey) || (user == null ? void 0 : user.principalType) === 'client_secret' || (user == null ? void 0 : user.principalType) === 'api_key' ? user : null;
    }
    static currentRequest() {
        const requestContext = RequestContext.currentRequestContext();
        if (requestContext) {
            return requestContext.request;
        }
        return null;
    }
    static currentTenantId() {
        const user = RequestContext.currentUser();
        if (user) {
            return user.tenantId;
        }
        return null;
    }
    static currentUserId() {
        const user = RequestContext.currentUser();
        if (user) {
            return user.id;
        }
        return null;
    }
    static currentRoleId() {
        const user = RequestContext.currentUser();
        if (user) {
            return user.roleId;
        }
        return null;
    }
    static currentUser(throwError) {
        const requestContext = RequestContext.currentRequestContext();
        if (requestContext) {
            // tslint:disable-next-line
            const user = requestContext.request['user'];
            if (user) {
                return user;
            }
        }
        if (throwError) {
            throw new HttpException('Unauthorized', HttpStatus.UNAUTHORIZED);
        }
        return null;
    }
    static hasPermission(permission, throwError) {
        return this.hasPermissions([
            permission
        ], throwError);
    }
    /**
     * Retrieves the language code from the headers of the current request.
     * @returns The language code (LanguagesEnum) extracted from the headers, or the default language (ENGLISH) if not found.
     */ static getLanguageCode() {
        // Retrieve the current request
        const req = RequestContext.currentRequest();
        // Variable to store the extracted language code
        let lang;
        // Check if a request exists
        if (req) {
            // Check if the 'language' header exists in the request
            if (req.headers && req.headers['language']) {
                // If found, set the lang variable
                lang = req.headers['language'];
            }
        }
        // Return the extracted language code or the default language (ENGLISH) if not found
        return lang || LanguagesEnum.English;
    }
    static getScope() {
        const request = this.currentRequest();
        const user = this.currentUser();
        var _user_tenantId, _ref;
        const tenantId = (_ref = (_user_tenantId = user == null ? void 0 : user.tenantId) != null ? _user_tenantId : getHeaderValue(request, [
            'tenant-id'
        ])) != null ? _ref : null;
        var _getHeaderValue;
        const organizationId = (_getHeaderValue = getHeaderValue(request, [
            'organization-id'
        ])) != null ? _getHeaderValue : null;
        const scopeLevelHeader = getHeaderValue(request, [
            'x-scope-level'
        ]);
        if (scopeLevelHeader) {
            if (scopeLevelHeader !== TENANT_SCOPE && scopeLevelHeader !== ORGANIZATION_SCOPE) {
                throw new BadRequestException(`Unsupported scope level: ${scopeLevelHeader}`);
            }
            if (scopeLevelHeader === TENANT_SCOPE) {
                if (organizationId) {
                    throw new BadRequestException('Tenant scope requests must not include Organization-Id.');
                }
                return {
                    tenantId,
                    level: TENANT_SCOPE,
                    organizationId: null
                };
            }
            if (!organizationId) {
                throw new BadRequestException('Organization scope requests require Organization-Id.');
            }
            return {
                tenantId,
                level: ORGANIZATION_SCOPE,
                organizationId
            };
        }
        if (organizationId) {
            return {
                tenantId,
                level: ORGANIZATION_SCOPE,
                organizationId
            };
        }
        return {
            tenantId,
            level: TENANT_SCOPE,
            organizationId: null
        };
    }
    static getOrganizationId() {
        return this.getScope().organizationId;
    }
    static isTenantScope() {
        return this.getScope().level === TENANT_SCOPE;
    }
    static isOrganizationScope() {
        return this.getScope().level === ORGANIZATION_SCOPE;
    }
    static requireOrganizationScope() {
        const scope = this.getScope();
        if (scope.level !== ORGANIZATION_SCOPE || !scope.organizationId) {
            throw new BadRequestException('Organization scope is required for this operation.');
        }
        return scope.organizationId;
    }
    /**
     * Check the authenticated principal's enabled role permissions, matching the
     * server RequestContext. Authentication guards resolve JWTs, API keys and
     * ChatKit client secrets before this check; the bearer is not always a JWT.
     */ static hasPermissions(findPermissions, throwError) {
        const permissions = new Set(this.currentPermissions());
        if (permissions.size > 0 && findPermissions.every((permission)=>permissions.has(permission))) {
            return true;
        }
        if (throwError) {
            throw new HttpException('Unauthorized', HttpStatus.UNAUTHORIZED);
        }
        return false;
    }
    static hasAnyPermission(findPermissions, throwError) {
        const permissions = this.currentPermissions();
        if (permissions.some((value)=>findPermissions.includes(value))) {
            return true;
        }
        if (throwError) {
            throw new HttpException('Unauthorized', HttpStatus.UNAUTHORIZED);
        }
        return false;
    }
    static currentToken(throwError) {
        const requestContext = RequestContext.currentRequestContext();
        if (requestContext) {
            // tslint:disable-next-line
            return ExtractJwt.fromAuthHeaderAsBearerToken()(requestContext.request);
        }
        if (throwError) {
            throw new HttpException('Unauthorized', HttpStatus.UNAUTHORIZED);
        }
        return null;
    }
    /**
     * Checks if the current user has a specific role.
     * @param {RolesEnum} role - The role to check.
     * @param {boolean} throwError - Flag indicating whether to throw an error if the role is not granted.
     * @returns {boolean} - True if the user has the role, otherwise false.
     */ static hasRole(role, throwError) {
        return this.hasRoles([
            role
        ], throwError);
    }
    /**
     * Checks if the current request context has any of the specified roles.
     *
     * @param roles - An array of roles to check.
     * @param throwError - Whether to throw an error if no roles are found.
     * @returns True if any of the required roles are found, otherwise false.
     */ static hasRoles(roles, throwError) {
        const context = RequestContext.currentRequestContext();
        if (context) {
            var _this_currentUser_role, _this_currentUser;
            const role = (_this_currentUser = this.currentUser()) == null ? void 0 : (_this_currentUser_role = _this_currentUser.role) == null ? void 0 : _this_currentUser_role.name;
            if (role) {
                return roles.includes(role);
            }
        }
        if (throwError) {
            throw new HttpException('Unauthorized', HttpStatus.UNAUTHORIZED);
        }
        return false;
    }
    static currentPermissions() {
        var _this_currentUser_role, _this_currentUser;
        var _this_currentUser_role_rolePermissions;
        return ((_this_currentUser_role_rolePermissions = (_this_currentUser = this.currentUser()) == null ? void 0 : (_this_currentUser_role = _this_currentUser.role) == null ? void 0 : _this_currentUser_role.rolePermissions) != null ? _this_currentUser_role_rolePermissions : []).filter((rolePermission)=>rolePermission == null ? void 0 : rolePermission.enabled).map((rolePermission)=>rolePermission == null ? void 0 : rolePermission.permission).filter((permission)=>!!permission);
    }
    constructor(request, response, reqId, userId, extras = {}){
        this.request = request;
        this.response = response;
        this.reqId = reqId;
        this.userId = userId;
        this.extras = extras;
    }
}
const REQUEST_CONTEXT_STORAGE_KEY = Symbol.for('xpert.plugin-sdk.request-context.storage.v1');
function getSharedRequestContextStorage() {
    const existing = Reflect.get(globalThis, REQUEST_CONTEXT_STORAGE_KEY);
    if (existing instanceof AsyncLocalStorage) {
        return existing;
    }
    const storage = new AsyncLocalStorage();
    Reflect.defineProperty(globalThis, REQUEST_CONTEXT_STORAGE_KEY, {
        value: storage,
        configurable: false,
        enumerable: false,
        writable: false
    });
    return storage;
}
/**
 * One process-wide context store shared by source, built, and dynamically loaded
 * copies of the Plugin SDK. Plugin class identity may differ; the async scope must not.
 */ const als = getSharedRequestContextStorage();
function getRequestContext() {
    return als.getStore();
}
function getHeaderValue(req, keys) {
    if (!(req == null ? void 0 : req.headers)) {
        return null;
    }
    for (const key of keys){
        const value = req.headers[key];
        if (Array.isArray(value)) {
            var _value_;
            return (_value_ = value[0]) != null ? _value_ : null;
        }
        if (typeof value === 'string' && value) {
            return value;
        }
    }
    return null;
}

let RequestContextMiddleware = class RequestContextMiddleware {
    use(req, _res, next) {
        var _req_user;
        const reqId = req.headers['x-request-id'] || randomUUID();
        // The userId can be placed in the authentication result here.
        const userId = (_req_user = req['user']) == null ? void 0 : _req_user['id'];
        const ctx = new RequestContext(req, _res, reqId, userId);
        als.run(ctx, next);
    }
};
RequestContextMiddleware = __decorate([
    Injectable()
], RequestContextMiddleware);
function runWithRequestContext(req, res, next) {
    var _req_user;
    const reqId = req.headers['x-request-id'] || randomUUID();
    const userId = (_req_user = req['user']) == null ? void 0 : _req_user['id'];
    const ctx = new RequestContext(req, res, reqId, userId);
    // Enable ALS scope
    als.run(ctx, next);
}

let StrategyBus = class StrategyBus {
    upsert(strategyType, entry) {
        this.subject.next({
            type: 'UPSERT',
            strategyType,
            entry
        });
    }
    remove(orgId, pluginName, cause) {
        this.subject.next(_extends({
            type: 'REMOVE',
            orgId,
            pluginName
        }, cause ? {
            cause
        } : {}));
    }
    constructor(){
        this.subject = new Subject();
        this.events$ = this.subject.asObservable();
    }
};
StrategyBus = __decorate([
    Injectable()
], StrategyBus);

class BaseStrategyRegistry {
    onModuleInit() {
        this.bus.events$.pipe(filter((event)=>!event.strategyType || event.strategyType === this.strategyKey)).subscribe((evt)=>{
            if (evt.type === 'UPSERT') {
                this.upsert(evt.entry.instance);
            } else if (evt.type === 'REMOVE') {
                this.remove(evt.orgId, evt.pluginName);
            }
        });
        const providers = this.discoveryService.getProviders();
        for (const wrapper of providers){
            const { instance } = wrapper;
            if (!instance) continue;
            this.upsert(instance);
        }
    }
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        if (!target) {
            return;
        }
        const type = this.reflector.get(this.strategyKey, target);
        if (type) {
            const source = this.getSource(instance);
            this.store(type, instance, source, false);
        }
    }
    /** Registers a host-generated adapter without mutating shared class metadata. */ register(type, instance, source) {
        if ((typeof instance !== 'object' || instance === null) && typeof instance !== 'function') {
            throw new Error(`Cannot register non-object strategy '${type}'.`);
        }
        this.assertCanRegister(type, instance, source);
        this.explicitSources.set(instance, source);
        return this.store(type, instance, source, false);
    }
    /** Preflights adapter batches so a provider is expanded atomically across registries. */ assertCanRegister(type, instance, source) {
        var _this_strategies_get;
        const existing = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(type);
        if (!existing || existing === instance) return;
        const existingSource = this.getSource(existing);
        const samePlugin = existingSource.kind === 'plugin' && source.kind === 'plugin' && existingSource.pluginName === source.pluginName;
        if (!samePlugin) {
            throw new Error(`Strategy '${type}' is already registered for scope '${source.scopeKey}'.`);
        }
    }
    /** Removes one exact programmatic registration without affecting fallback scopes. */ unregister(type, source, expected) {
        const orgMap = this.strategies.get(source.scopeKey);
        const current = orgMap == null ? void 0 : orgMap.get(type);
        if (expected !== undefined && current !== expected) return false;
        var _orgMap_delete;
        return (_orgMap_delete = orgMap == null ? void 0 : orgMap.delete(type)) != null ? _orgMap_delete : false;
    }
    /** Returns the explicit registry provenance attached by the plugin loader. */ getSource(instance) {
        if (typeof instance === 'object' && instance !== null || typeof instance === 'function') {
            const explicit = this.explicitSources.get(instance);
            if (explicit) return explicit;
        }
        const target = resolveStrategyMetadataTarget(instance);
        if (!target) {
            return {
                kind: 'builtin',
                scopeKey: BUILTIN_GLOBAL_SCOPE
            };
        }
        const pluginName = this.reflector.get(PLUGIN_METADATA_KEY, target);
        if (!pluginName) {
            var _this_reflector_get;
            return {
                kind: 'builtin',
                scopeKey: (_this_reflector_get = this.reflector.get(ORGANIZATION_METADATA_KEY, target)) != null ? _this_reflector_get : BUILTIN_GLOBAL_SCOPE
            };
        }
        const pluginVersion = this.reflector.get(PLUGIN_VERSION_METADATA_KEY, target);
        var _this_reflector_get1;
        return _extends({
            kind: 'plugin',
            pluginName
        }, pluginVersion ? {
            pluginVersion
        } : {}, {
            scopeKey: (_this_reflector_get1 = this.reflector.get(ORGANIZATION_METADATA_KEY, target)) != null ? _this_reflector_get1 : GLOBAL_ORGANIZATION_SCOPE
        });
    }
    /**
     * Remove all strategies registered by the given plugin for the given scope.
     */ remove(organizationId, pluginName) {
        const strategies = this.pluginStrategies.get(pluginName);
        const orgMap = this.strategies.get(organizationId);
        for (const type of strategies != null ? strategies : []){
            orgMap == null ? void 0 : orgMap.delete(type);
        }
    }
    /**
     * Resolve the primary scope key, falling back to request context org or tenant-global scope.
     */ resolveOrganization(organizationId) {
        var _RequestContext_getScope;
        var _RequestContext_getScope_tenantId;
        const tenantId = (_RequestContext_getScope_tenantId = (_RequestContext_getScope = RequestContext.getScope()) == null ? void 0 : _RequestContext_getScope.tenantId) != null ? _RequestContext_getScope_tenantId : RequestContext.currentTenantId();
        const requested = organizationId != null ? organizationId : RequestContext.getOrganizationId();
        return !requested || requested === GLOBAL_ORGANIZATION_SCOPE ? resolveTenantGlobalScopeKey(tenantId) : requested;
    }
    resolveGlobalFallbackOrganization() {
        var _RequestContext_getScope;
        var _RequestContext_getScope_tenantId;
        const tenantId = (_RequestContext_getScope_tenantId = (_RequestContext_getScope = RequestContext.getScope()) == null ? void 0 : _RequestContext_getScope.tenantId) != null ? _RequestContext_getScope_tenantId : RequestContext.currentTenantId();
        return resolveTenantGlobalScopeKey(tenantId);
    }
    resolveStrategyScopeKeys(organizationId) {
        const orgKey = this.resolveOrganization(organizationId);
        const globalKey = this.resolveGlobalFallbackOrganization();
        const scopeKeys = [
            orgKey
        ];
        if (orgKey !== globalKey) {
            scopeKeys.push(globalKey);
        }
        if (!scopeKeys.includes(SYSTEM_GLOBAL_SCOPE)) {
            scopeKeys.push(SYSTEM_GLOBAL_SCOPE);
        }
        if (!scopeKeys.includes(BUILTIN_GLOBAL_SCOPE)) {
            scopeKeys.push(BUILTIN_GLOBAL_SCOPE);
        }
        return scopeKeys;
    }
    /**
     * Get strategy by type from the given organization including global strategies as fallback.
     *
     * @param type
     * @param organizationId
     * @returns
     */ get(type, organizationId) {
        organizationId != null ? organizationId : organizationId = RequestContext.getOrganizationId();
        const strategy = this.resolveStrategyScopeKeys(organizationId).map((scopeKey)=>{
            var _this_strategies_get;
            return (_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.get(type);
        }).find((item)=>!!item);
        if (!strategy) {
            throw new Error(`No strategy found for type '${type}' for strategy '${this.strategyKey}'`);
        }
        return strategy;
    }
    /**
     * List all strategies for the given organization including global strategies, or only global strategies if global org is specified.
     *
     * @param organizationId
     * @returns
     */ list(organizationId) {
        organizationId != null ? organizationId : organizationId = RequestContext.getOrganizationId();
        const effective = new Map();
        for (const scopeKey of this.resolveStrategyScopeKeys(organizationId)){
            var _this_strategies_get;
            var _this_strategies_get_entries;
            for (const [type, strategy] of (_this_strategies_get_entries = (_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.entries()) != null ? _this_strategies_get_entries : []){
                if (!effective.has(type)) {
                    effective.set(type, strategy);
                }
            }
        }
        return Array.from(effective.values());
    }
    listRegistrations(organizationId) {
        organizationId != null ? organizationId : organizationId = RequestContext.getOrganizationId();
        const effective = new Map();
        for (const scopeKey of this.resolveStrategyScopeKeys(organizationId)){
            var _this_strategies_get;
            var _this_strategies_get_entries;
            for (const [type, strategy] of (_this_strategies_get_entries = (_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.entries()) != null ? _this_strategies_get_entries : []){
                if (!effective.has(type)) effective.set(type, strategy);
            }
        }
        return Array.from(effective, ([type, strategy])=>({
                type,
                strategy,
                source: this.getSource(strategy)
            }));
    }
    /** Returns every direct registration without applying request-scope fallback rules. */ listAllRegistrations() {
        const registrations = [];
        for (const [scopeKey, strategies] of this.strategies){
            for (const [type, strategy] of strategies){
                const source = this.getSource(strategy);
                registrations.push({
                    type,
                    strategy,
                    source: source.scopeKey === scopeKey ? source : _extends({}, source, {
                        scopeKey
                    })
                });
            }
        }
        return registrations;
    }
    store(type, instance, source, rejectCrossPluginConflict) {
        const pluginName = source.kind === 'plugin' ? source.pluginName : undefined;
        const organizationId = source.scopeKey;
        var _this_strategies_get;
        const orgMap = (_this_strategies_get = this.strategies.get(organizationId)) != null ? _this_strategies_get : new Map();
        const existing = orgMap.get(type);
        if (rejectCrossPluginConflict && existing && existing !== instance) {
            const existingSource = this.getSource(existing);
            const samePlugin = existingSource.kind === 'plugin' && source.kind === 'plugin' && existingSource.pluginName === source.pluginName;
            if (!samePlugin) {
                throw new Error(`Strategy '${type}' is already registered for scope '${organizationId}'.`);
            }
        }
        orgMap.set(type, instance);
        this.strategies.set(organizationId, orgMap);
        this.logger.debug(`Registered strategy of type ${type} for scope ${organizationId} from plugin ${pluginName}`);
        if (pluginName) {
            var _this_pluginStrategies_get;
            const pluginStrategies = (_this_pluginStrategies_get = this.pluginStrategies.get(pluginName)) != null ? _this_pluginStrategies_get : new Set();
            pluginStrategies.add(type);
            this.pluginStrategies.set(pluginName, pluginStrategies);
        }
        return existing;
    }
    constructor(strategyKey, discoveryService, reflector){
        this.logger = new Logger(BaseStrategyRegistry.name);
        // Map<scopeKey, Map<type, strategy>>
        this.strategies = new Map();
        this.pluginStrategies = new Map();
        this.explicitSources = new WeakMap();
        this.strategyKey = strategyKey;
        this.discoveryService = discoveryService;
        this.reflector = reflector;
    }
}
__decorate([
    Inject(StrategyBus),
    __metadata("design:type", StrategyBus)
], BaseStrategyRegistry.prototype, "bus", void 0);
/** Returns whether a discovered provider can carry decorator metadata. */ function isStrategyInstance(instance) {
    return typeof instance === 'object' && instance !== null || typeof instance === 'function';
}
/** Resolves the class used for plugin and organization metadata without reflecting over primitive provider values. */ function resolveStrategyMetadataTarget(instance) {
    if (!isStrategyInstance(instance)) {
        return null;
    }
    if (typeof instance === 'function') {
        return instance;
    }
    const metatype = instance.metatype;
    if (typeof metatype === 'function') {
        return metatype;
    }
    const constructor = instance.constructor;
    return typeof constructor === 'function' ? constructor : null;
}

var ResourceCardProviderRegistry_1;
const resourceTypeKey = ({ namespace, type })=>JSON.stringify([
        namespace,
        type
    ]);
function isProvider(value) {
    return !!value && typeof value === 'object' && 'resolveMany' in value && typeof value.resolveMany === 'function';
}
let ResourceCardProviderRegistry = ResourceCardProviderRegistry_1 = class ResourceCardProviderRegistry extends BaseStrategyRegistry {
    onModuleInit() {
        this.subscription = this.bus.events$.pipe(filter((event)=>!event.strategyType || event.strategyType === RESOURCE_CARD_PROVIDER)).subscribe((event)=>{
            try {
                if (event.type === 'UPSERT') this.upsert(event.entry.instance);
                else this.remove(event.orgId, event.pluginName);
            } catch (e) {
                // Reject the conflicting provider without terminating the lifecycle subscription.
                this.resourceLogger.warn('Rejected invalid or conflicting resource card provider registration');
            }
        });
        for (const { instance } of this.discoveryService.getProviders())if (instance) this.upsert(instance);
    }
    onModuleDestroy() {
        var _this_subscription;
        (_this_subscription = this.subscription) == null ? void 0 : _this_subscription.unsubscribe();
    }
    remove(scopeKey, pluginName) {
        for (const entry of this.listAllRegistrations()){
            if (entry.source.kind === 'plugin' && entry.source.pluginName === pluginName && entry.source.scopeKey === scopeKey) {
                this.unregister(entry.type, entry.source, entry.strategy);
            }
        }
    }
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        const resources = target && this.reflector.get(RESOURCE_CARD_PROVIDER, target);
        if (!resources) return;
        if (!isProvider(instance)) throw new Error('ResourceCardProvider must implement resolveMany');
        const source = this.getSource(instance);
        const keys = resources.map(resourceTypeKey);
        // A route belongs to one plugin across scopes; a different plugin cannot shadow it.
        // Preflight the whole batch so a conflicting multi-type provider is never partly installed.
        for (const key of keys){
            for (const existing of this.listAllRegistrations().filter((entry)=>entry.type === key)){
                const samePlugin = source.kind === 'plugin' && existing.source.kind === 'plugin' && source.pluginName === existing.source.pluginName;
                if (existing.strategy !== instance && !samePlugin) {
                    throw new Error(`Resource card type ${key} is already registered`);
                }
            }
            this.assertCanRegister(key, instance, source);
        }
        for (const key of keys)this.register(key, instance, source);
    }
    find(resource, organizationId) {
        const key = resourceTypeKey(resource);
        for (const scopeKey of this.resolveStrategyScopeKeys(organizationId)){
            var _this_strategies_get;
            const provider = (_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.get(key);
            if (provider) return provider;
        }
        return undefined;
    }
    constructor(discovery, reflector){
        super(RESOURCE_CARD_PROVIDER, discovery, reflector);
        this.resourceLogger = new Logger(ResourceCardProviderRegistry_1.name);
    }
};
ResourceCardProviderRegistry = ResourceCardProviderRegistry_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ResourceCardProviderRegistry);

function createPluginLogger(scope, baseMeta = {}) {
    const nestLogger = new Logger(scope);
    const wrap = (level, msg, meta)=>{
        var // Maintain alignment with the Nest Logger interface
        _nestLogger_level;
        const payload = meta ? _extends({}, baseMeta, meta) : baseMeta;
        (_nestLogger_level = nestLogger[level]) == null ? void 0 : _nestLogger_level.call(nestLogger, msg + (Object.keys(payload).length ? ` ${JSON.stringify(payload)}` : ''));
    };
    return {
        child (meta) {
            return createPluginLogger(scope, _extends({}, baseMeta, meta));
        },
        debug: (msg, meta)=>wrap('debug', msg, meta),
        log: (msg, meta)=>wrap('log', msg, meta),
        warn: (msg, meta)=>wrap('warn', msg, meta),
        error: (msg, meta)=>wrap('error', msg, meta)
    };
}

const INTEGRATION_STRATEGY = 'INTEGRATION_STRATEGY';
const IntegrationStrategyKey = (provider)=>applyDecorators(SetMetadata(INTEGRATION_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, INTEGRATION_STRATEGY));

let IntegrationStrategyRegistry = class IntegrationStrategyRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(INTEGRATION_STRATEGY, discoveryService, reflector);
    }
};
IntegrationStrategyRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], IntegrationStrategyRegistry);

/** Read an app for an authorized connector using its persisted scope, including public OAuth callbacks. */ class ResolveConnectorIntegrationQuery extends Query {
    constructor(id, provider, scope){
        super();
        this.id = id;
        this.provider = provider;
        this.scope = scope;
    }
}
ResolveConnectorIntegrationQuery.type = '[Integration] Resolve connector application';
Reflect.defineMetadata('__query__', {
    id: ResolveConnectorIntegrationQuery.type
}, ResolveConnectorIntegrationQuery);

const WORKFLOW_TRIGGER_STRATEGY = 'WORKFLOW_TRIGGER_STRATEGY';
const WorkflowTriggerStrategy = (provider)=>applyDecorators(SetMetadata(WORKFLOW_TRIGGER_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, WORKFLOW_TRIGGER_STRATEGY));

let WorkflowTriggerRegistry = class WorkflowTriggerRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(WORKFLOW_TRIGGER_STRATEGY, discoveryService, reflector);
    }
};
WorkflowTriggerRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], WorkflowTriggerRegistry);

const WORKFLOW_NODE_STRATEGY = 'WORKFLOW_NODE_STRATEGY';
/**
 * Decorator to mark a provider as a Workflow Node Strategy
 */ const WorkflowNodeStrategy = (provider)=>applyDecorators(SetMetadata(WORKFLOW_NODE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, WORKFLOW_NODE_STRATEGY));

/**
 * Registry for Workflow Node Strategies
 */ let WorkflowNodeRegistry = class WorkflowNodeRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(WORKFLOW_NODE_STRATEGY, discoveryService, reflector);
    }
};
WorkflowNodeRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], WorkflowNodeRegistry);

const COMMAND_METADATA$2 = '__command__';
/**
 * Wrap Workflow Node Execution Command
 *
 * @deprecated Prefer `IAgentMiddlewareContext.runtime.wrapWorkflowNodeExecution(...)` in middleware and plugin code.
 */ class WrapWorkflowNodeExecutionCommand extends Command {
    constructor(fuc, params){
        super();
        this.fuc = fuc;
        this.params = params;
    }
}
WrapWorkflowNodeExecutionCommand.type = '[Workflow] Wrap Workflow Node Execution';
Reflect.defineMetadata(COMMAND_METADATA$2, {
    id: WrapWorkflowNodeExecutionCommand.type
}, WrapWorkflowNodeExecutionCommand);

const VECTOR_STORE_STRATEGY = 'VECTOR_STORE_STRATEGY';
const VectorStoreStrategy = (provider)=>applyDecorators(SetMetadata(VECTOR_STORE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, VECTOR_STORE_STRATEGY));

let VectorStoreRegistry = class VectorStoreRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(VECTOR_STORE_STRATEGY, discoveryService, reflector);
    }
};
VectorStoreRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], VectorStoreRegistry);

const TEXT_SPLITTER_STRATEGY = 'TEXT_SPLITTER_STRATEGY';
const TextSplitterStrategy = (provider)=>applyDecorators(SetMetadata(TEXT_SPLITTER_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, TEXT_SPLITTER_STRATEGY));

let TextSplitterRegistry = class TextSplitterRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(TEXT_SPLITTER_STRATEGY, discoveryService, reflector);
    }
};
TextSplitterRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], TextSplitterRegistry);

const DOCUMENT_SOURCE_STRATEGY = 'DOCUMENT_SOURCE_STRATEGY';
/**
 * Decorator to mark a provider as a Document Source Strategy
 */ const DocumentSourceStrategy = (provider)=>applyDecorators(SetMetadata(DOCUMENT_SOURCE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, DOCUMENT_SOURCE_STRATEGY));

let DocumentSourceRegistry = class DocumentSourceRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(DOCUMENT_SOURCE_STRATEGY, discoveryService, reflector);
    }
};
DocumentSourceRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], DocumentSourceRegistry);

const DOCUMENT_TRANSFORMER_STRATEGY = 'DOCUMENT_TRANSFORMER_STRATEGY';
/**
 * Decorator to mark a provider as a Document Transformer Strategy
 */ const DocumentTransformerStrategy = (provider)=>applyDecorators(SetMetadata(DOCUMENT_TRANSFORMER_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, DOCUMENT_TRANSFORMER_STRATEGY));

let DocumentTransformerRegistry = class DocumentTransformerRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(DOCUMENT_TRANSFORMER_STRATEGY, discoveryService, reflector);
    }
};
DocumentTransformerRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], DocumentTransformerRegistry);

const RETRIEVER_STRATEGY = 'RETRIEVER_STRATEGY';
/**
 * Decorator to mark a provider as a Retriever Strategy
 */ const RetrieverStrategy = (provider)=>applyDecorators(SetMetadata(RETRIEVER_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, RETRIEVER_STRATEGY));

let RetrieverRegistry = class RetrieverRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(RETRIEVER_STRATEGY, discoveryService, reflector);
    }
};
RetrieverRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], RetrieverRegistry);

/**
 * Merge parent chunks with their child chunks based on metadata (parentId and chunkId)
 *
 * @deprecated use buildChunkTreeAndFindLeaves instead
 */ function mergeParentChildChunks(chunks, children // Child chunks
) {
    const chunkMap = new Map();
    for (const chunk of chunks){
        chunkMap.set(chunk.metadata.chunkId, chunk);
    }
    for (const child of children){
        if (!child.metadata.parentId) {
            if (chunkMap.has(child.metadata.chunkId)) {
                console.warn(`Duplicate chunkId found: ${child.metadata.chunkId}, skipping...`);
                continue;
            }
            chunkMap.set(child.metadata.chunkId, child);
            continue;
        }
        const parent = chunkMap.get(child.metadata.parentId);
        if (parent) {
            if (!parent.metadata.children) {
                parent.metadata.children = [];
            }
            parent.metadata.children.push(child);
        }
    }
    return Array.from(chunkMap.values());
}
function isRemoteFile(path) {
    return path.startsWith('http://') || path.startsWith('https://') || path.startsWith('ftp://');
}
async function downloadRemoteFile(url, dest) {
    return new Promise((resolve, reject)=>{
        const file = fs__default.createWriteStream(dest);
        const client = url.startsWith('https') ? https : http;
        const request = client.get(url, (response)=>{
            if (response.statusCode !== 200) {
                reject(new Error(`Failed to get '${url}' (${response.statusCode})`));
                return;
            }
            response.pipe(file);
        });
        file.on('finish', ()=>{
            file.close();
            resolve(dest);
        });
        request.on('error', (err)=>{
            fs__default.unlink(dest, ()=>reject(err));
        });
        file.on('error', (err)=>{
            fs__default.unlink(dest, ()=>reject(err));
        });
    });
}

const IMAGE_UNDERSTANDING_STRATEGY = 'IMAGE_UNDERSTANDING_STRATEGY';
/**
 * Decorator to mark a provider as an Image Understanding Strategy
 */ const ImageUnderstandingStrategy = (provider)=>applyDecorators(SetMetadata(IMAGE_UNDERSTANDING_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, IMAGE_UNDERSTANDING_STRATEGY));

let ImageUnderstandingRegistry = class ImageUnderstandingRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(IMAGE_UNDERSTANDING_STRATEGY, discoveryService, reflector);
    }
};
ImageUnderstandingRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ImageUnderstandingRegistry);

const KNOWLEDGE_STRATEGY = 'KNOWLEDGE_STRATEGY';
const KnowledgeStrategyKey = (provider)=>applyDecorators(SetMetadata(KNOWLEDGE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, KNOWLEDGE_STRATEGY));

let KnowledgeStrategyRegistry = class KnowledgeStrategyRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(KNOWLEDGE_STRATEGY, discoveryService, reflector);
    }
};
KnowledgeStrategyRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], KnowledgeStrategyRegistry);

const KEYWORD_ANALYZER_STRATEGY = 'KEYWORD_ANALYZER_STRATEGY';
const KeywordAnalyzerStrategy = (provider)=>applyDecorators(SetMetadata(KEYWORD_ANALYZER_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, KEYWORD_ANALYZER_STRATEGY));

let KeywordAnalyzerRegistry = class KeywordAnalyzerRegistry extends BaseStrategyRegistry {
    /** Resolve a pinned source without allowing a higher-priority scope to shadow it. */ getBySource(provider, source, organizationId) {
        var _this_strategies_get;
        if (!this.resolveStrategyScopeKeys(organizationId).includes(source.scopeKey)) return undefined;
        const strategy = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(provider);
        if (!strategy) return undefined;
        const registered = this.getSource(strategy);
        if (registered.kind !== source.kind || registered.scopeKey !== source.scopeKey) return undefined;
        if (source.kind === 'plugin' && (registered.kind !== 'plugin' || registered.pluginName !== source.pluginName)) {
            return undefined;
        }
        return strategy;
    }
    constructor(discoveryService, reflector){
        super(KEYWORD_ANALYZER_STRATEGY, discoveryService, reflector);
    }
};
KeywordAnalyzerRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], KeywordAnalyzerRegistry);

const KnowledgebaseRuntimeCapability = createRuntimeCapability('platform.knowledgebase', {
    description: 'List, search, and write chunks in platform knowledgebases.'
});
const KnowledgebaseProvisioningRuntimeCapability = createRuntimeCapability('platform.knowledgebase.provisioning', {
    description: 'Idempotently provision managed platform knowledgebases and connect them to an Agent.'
});

/** Knowledgebase discovery is scoped to the authenticated runtime, never caller-supplied identities. */ const knowledgebaseActions = [
    'knowledgebase.read',
    'knowledgebase.manage',
    'content.search',
    'documents.read',
    'documents.create',
    'documents.update',
    'documents.delete',
    'documents.process',
    'chunks.write',
    'chunks.delete'
];

const KnowledgeGraphRuntimeCapability = createRuntimeCapability('platform.knowledge-graph', {
    description: 'Publish, inspect, and retract source-owned structured knowledge graphs without model extraction.'
});

const KnowledgebaseDocumentsRuntimeCapability = createRuntimeCapability('platform.knowledgebase.documents', {
    description: 'Upload, import, create, process, reprocess, inspect, and delete persistent knowledgebase documents.'
});

const KnowledgeDocumentVisualAssetsRuntimeCapability = createRuntimeCapability('platform.knowledgebase.visual-assets', {
    description: 'Issue execution-scoped logical KnowledgeDocument image paths and inject validated images without exposing host storage paths.'
});
const KnowledgeDocumentVisualAssetsRuntimeFactoryCapability = createRuntimeCapability('platform.knowledge-document.visual-assets.factory', {
    description: 'Create a visual-assets API with an execution-local image allow-list and authorized workspace writer.'
});

const TOOLSET_STRATEGY = 'TOOLSET_STRATEGY';
/**
 * Decorator to mark a provider as a Toolset Strategy
 */ const ToolsetStrategy = (provider)=>applyDecorators(SetMetadata(TOOLSET_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, TOOLSET_STRATEGY));

let ToolsetRegistry = class ToolsetRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(TOOLSET_STRATEGY, discoveryService, reflector);
    }
};
ToolsetRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ToolsetRegistry);

/** Run-scoped evidence for multi-tool writes. A file write is not a domain commit. */ function createMutationEvidence() {
    let generation = 0, committed = 0;
    let receipt;
    return {
        begin () {
            return ++generation;
        },
        accept (token, value) {
            if (token !== generation) return;
            committed = token;
            receipt = value;
        },
        get pending () {
            return generation > committed;
        },
        get receipt () {
            return receipt;
        }
    };
}

function defineXpertTool(definition) {
    return Object.freeze(definition);
}

/**
 * Restricted FileSystem based on granted permissions
 */ class XpFileSystem {
    /**
     * Check if operation is allowed
     */ ensureAllowed(op) {
        if (!this.allowedOps.has(op)) {
            throw new Error(`Permission denied: ${op} operation not allowed`);
        }
    }
    /**
     * Check if path is within scope
     */ ensureInScope(targetPath) {
        if (!this.scope || this.scope.length === 0) return;
        const resolved = path__default.resolve(targetPath);
        for (const s of this.scope){
            const absScope = path__default.resolve(s);
            if (resolved.startsWith(absScope)) return;
        }
        throw new Error(`Permission denied: path "${targetPath}" is out of scope`);
    }
    /**
     * Get the absolute path of file in the file system.
     *
     * @param filePath Relative file path
     * @returns Absolute file path
     */ fullPath(filePath) {
        return path__default.join(this.basePath, filePath);
    }
    /**
     * Convert an absolute path under this file-system root back to a relative path.
     */ relativePath(filePath) {
        const relative = path__default.relative(this.basePath, path__default.resolve(filePath)).replace(/\\/g, '/');
        if (!relative || relative === '.') {
            return '';
        }
        if (relative.startsWith('..') || path__default.isAbsolute(relative)) {
            return null;
        }
        return relative;
    }
    /**
     * Get web url for a given file path in the file system.
     *
     * @param filePath Relative file path
     * @returns Web URL of file
     */ fullUrl(filePath) {
        return this.buildUrl(filePath);
    }
    /**
     * Read file contents
     */ async readFile(filePath, encoding = 'utf-8') {
        this.ensureAllowed('read');
        const fullPath = this.fullPath(filePath);
        this.ensureInScope(fullPath);
        return await fsPromises.readFile(fullPath);
    }
    /**
     * Write file contents
     */ async writeFile(filePath, content) {
        this.ensureAllowed('write');
        const fullPath = this.fullPath(filePath);
        this.ensureInScope(fullPath);
        await fsPromises.mkdir(path__default.dirname(fullPath), {
            recursive: true
        });
        await fsPromises.writeFile(fullPath, content);
        return this.buildUrl(filePath);
    }
    /**
     * Delete a file
     */ async deleteFile(filePath) {
        this.ensureAllowed('delete');
        this.ensureInScope(filePath);
        await fsPromises.unlink(filePath);
    }
    /**
     * List directory contents
     */ async listDir(dirPath) {
        this.ensureAllowed('list');
        this.ensureInScope(dirPath);
        return fsPromises.readdir(dirPath);
    }
    /**
     * Utility: check if a file or directory exists
     */ async exists(targetPath) {
        try {
            await fsPromises.access(targetPath);
            return true;
        } catch (e) {
            return false;
        }
    }
    // Keep URL generation tolerant of protocol-relative base URLs like "//localhost:3000",
    // which are used by the current dev config and would otherwise make `new URL()` throw.
    buildUrl(filePath) {
        if (/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(filePath) || filePath.startsWith('//')) {
            return filePath;
        }
        const normalizedPath = this.encodePath(`${filePath}`.replace(/^\/+/, ''));
        const normalizedBaseUrl = `${this.baseUrl}`.replace(/\/+$/, '');
        if (normalizedBaseUrl.startsWith('//')) {
            return `${normalizedBaseUrl}/${normalizedPath}`;
        }
        const url = new URL(normalizedPath, `${normalizedBaseUrl}/`);
        return url.href;
    }
    encodePath(filePath) {
        return filePath.split('/').map((segment)=>encodeURIComponent(segment)).join('/');
    }
    constructor(permission, basePath, baseUrl){
        this.basePath = basePath;
        this.baseUrl = baseUrl;
        this.allowedOps = new Set(permission.operations);
        this.scope = permission.scope;
    }
}

const PLUGIN_CONFIG_RESOLVER_TOKEN = 'XPERT_PLUGIN_CONFIG_RESOLVER';

/**
 * System token for resolving integration read service from plugin context.
 */ const INTEGRATION_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_INTEGRATION_PERMISSION_SERVICE';

const PERMISSION_OPERATION_METADATA_KEY = 'XPERT_PLUGIN_PERMISSION_OPERATION';
function RequirePermissionOperation(permissionType, operation) {
    return (_target, _propertyKey, descriptor)=>{
        const method = descriptor.value;
        if (typeof method !== 'function') {
            throw new Error('RequirePermissionOperation can only be applied to methods');
        }
        Reflect.defineMetadata(PERMISSION_OPERATION_METADATA_KEY, {
            permissionType,
            operation
        }, method);
    };
}
function getPermissionOperationMetadata(method) {
    if (typeof method !== 'function') {
        return undefined;
    }
    return Reflect.getMetadata(PERMISSION_OPERATION_METADATA_KEY, method);
}
function getRequiredPermissionOperation(method, permissionType) {
    const metadata = getPermissionOperationMetadata(method);
    if (!metadata || metadata.permissionType !== permissionType) {
        return undefined;
    }
    return metadata.operation;
}

/**
 * System token for resolving handoff queue service from plugin context.
 */ const HANDOFF_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_HANDOFF_PERMISSION_SERVICE';
/**
 * Internal system token used by core to expose the handoff queue bridge.
 */ const HANDOFF_QUEUE_SERVICE_TOKEN = 'XPERT_HANDOFF_QUEUE_SERVICE';

/**
 * System token for resolving account binding permission service from plugin context.
 */ const ACCOUNT_BINDING_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_ACCOUNT_BINDING_PERMISSION_SERVICE';

/**
 * System token for resolving bound identity login permission service from plugin context.
 */ const BOUND_IDENTITY_LOGIN_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_BOUND_IDENTITY_LOGIN_PERMISSION_SERVICE';

/**
 * System token for resolving the pending SSO binding challenge service from plugin context.
 */ const SSO_BINDING_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_SSO_BINDING_PERMISSION_SERVICE';

/**
 * System token for resolving user permission service from plugin context.
 */ const USER_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_USER_PERMISSION_SERVICE';

/**
 * System token for resolving speech-to-text service from plugin context.
 */ const SPEECH_TO_TEXT_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_SPEECH_TO_TEXT_PERMISSION_SERVICE';
/**
 * Internal system token used by core to expose the speech-to-text bridge.
 */ const SPEECH_TO_TEXT_SERVICE_TOKEN = 'XPERT_SPEECH_TO_TEXT_SERVICE';

const VIDEO_GENERATOR_FAMILIES = [
    'seedance',
    'veo',
    'kling'
];
const VIDEO_GENERATION_PERMISSION_SERVICE_TOKEN = 'XPERT_PLUGIN_VIDEO_GENERATION_PERMISSION_SERVICE';
const VIDEO_GENERATION_SERVICE_TOKEN = 'XPERT_VIDEO_GENERATION_SERVICE';

/**
 * Decode JSON text at most once, then validate with the supplied schema.
 * Intended for schemas whose native input excludes strings, such as objects and arrays.
 * Failed or oversized text remains unchanged so the schema rejects it; nested strings are not decoded.
 * Callers explicitly opt in at an input boundary; domain schemas remain unchanged.
 */ function jsonEncodedSchema(schema, { maxChars = 200000 } = {}) {
    return z.preprocess((value)=>{
        if (typeof value !== 'string' || value.length > maxChars) return value;
        try {
            return JSON.parse(value);
        } catch (e) {
            return value;
        }
    }, schema);
}

async function createI18nInstance(pluginDir, language) {
    const instance = createInstance();
    const i18nDir = path__default.join(pluginDir, 'i18n');
    // detect available languages dynamically
    const lngs = fs__default.readdirSync(i18nDir).filter((f)=>f.endsWith('.json')).map((f)=>f.replace('.json', ''));
    await instance.use(FsBackend).init({
        lng: language,
        fallbackLng: 'en',
        preload: lngs,
        ns: [
            'default'
        ],
        defaultNS: 'default',
        backend: {
            loadPath: path__default.join(i18nDir, '{{lng}}.json')
        },
        interpolation: {
            escapeValue: false
        }
    });
    return instance;
}

function loadYamlFile(filePath, logger, ignoreError = true, defaultValue = {}) {
    try {
        const fileContent = fs__default.readFileSync(filePath, 'utf-8');
        try {
            const yamlContent = yaml__default.parse(fileContent);
            return yamlContent || defaultValue;
        } catch (e) {
            throw new Error(`Failed to load YAML file ${filePath}: ${e}`);
        }
    } catch (e) {
        if (ignoreError) {
            logger == null ? void 0 : logger.debug(`Error loading YAML file: ${e}`);
            return defaultValue;
        } else {
            throw e;
        }
    }
}
/**
 * Get the mapping from name to index from a YAML file
 *
 * @param folderPath
 * @param fileName the YAML file name, default to '_position.yaml'
 * @return a dict with name as key and index as value
 */ function getPositionMap(folderPath, fileName = '_position.yaml', logger) {
    const positions = getPositionList(folderPath, fileName, logger);
    return positions.reduce((acc, name, index)=>{
        acc[name] = index;
        return acc;
    }, {});
}
function getPositionList(folderPath, fileName = '_position.yaml', logger) {
    const positionFilePath = path__default.join(folderPath, fileName);
    const yamlContent = loadYamlFile(positionFilePath, logger, true, []);
    const positions = yamlContent == null ? void 0 : yamlContent.filter((item)=>item && typeof item === 'string' && item.trim()).map((item)=>item.trim());
    return positions;
}
function getErrorMessage(err) {
    let error;
    if (typeof err === 'string') {
        error = err;
    } else if (err && (err.name === "AggregateError" || err.constructor.name === "AggregateError")) {
        return err.errors.map((_)=>getErrorMessage(_)).join('\n\n');
    } else if (err instanceof Error) {
        error = err == null ? void 0 : err.message;
    } else if ((err == null ? void 0 : err.error) instanceof Error) {
        var _err_error;
        error = err == null ? void 0 : (_err_error = err.error) == null ? void 0 : _err_error.message;
    } else if (err == null ? void 0 : err.message) {
        error = err == null ? void 0 : err.message;
    } else if (err) {
        // If there is no other way, convert it to JSON string
        error = JSON.stringify(err);
    }
    return error;
}
class JsonSchemaValidator {
    parseAndValidate(schemaStr) {
        if (!schemaStr) return undefined;
        let schema;
        try {
            schema = JSON.parse(schemaStr);
        } catch (e) {
            throw new Error('Schema is not valid JSON');
        }
        const validate = this.ajv.getSchema(schemaDraft04.$id);
        if (!validate(schema)) {
            throw new Error('Invalid JSON Schema: ' + this.ajv.errorsText(validate.errors));
        }
        return schema;
    }
    constructor(){
        this.ajv = new Ajv({
            strict: false
        });
        this.ajv.addMetaSchema(schemaDraft04);
    }
}

const PLUGIN_WEBHOOK_AUTH_METADATA_KEY = 'xpert:plugin:webhook-auth';
const PLUGIN_WEBHOOK_AUTH_SERVICE_TOKEN = 'XPERT_PLUGIN_WEBHOOK_AUTH_SERVICE';
function PluginWebhookAuth(metadata = {}) {
    return SetMetadata(PLUGIN_WEBHOOK_AUTH_METADATA_KEY, _extends({
        integrationParam: 'id',
        secretQueryParam: 'secret'
    }, metadata));
}
let PluginWebhookAuthGuard = class PluginWebhookAuthGuard {
    async canActivate(context) {
        var _request_params, _request_query;
        const metadata = this.resolveMetadata(context);
        if (!metadata) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const integrationParam = metadata.integrationParam || 'id';
        const secretQueryParam = metadata.secretQueryParam || 'secret';
        const integrationId = this.getString((_request_params = request.params) == null ? void 0 : _request_params[integrationParam]);
        const secret = this.getString((_request_query = request.query) == null ? void 0 : _request_query[secretQueryParam]);
        if (!integrationId || !secret) {
            throw new UnauthorizedException('Plugin webhook secret is required');
        }
        const authService = this.authService;
        if (!authService) {
            throw new UnauthorizedException('Plugin webhook auth service is not available');
        }
        const principalContext = await authService.validateWebhookSecret({
            integrationId,
            secret,
            provider: metadata.provider
        });
        if (!(principalContext == null ? void 0 : principalContext.user) || !principalContext.headers) {
            throw new UnauthorizedException('Plugin webhook secret is invalid');
        }
        request.user = principalContext.user;
        var _request_headers;
        request.headers = _extends({}, (_request_headers = request.headers) != null ? _request_headers : {}, principalContext.headers);
        return true;
    }
    resolveMetadata(context) {
        var _Reflect_getMetadata, _ref;
        return (_ref = (_Reflect_getMetadata = Reflect.getMetadata(PLUGIN_WEBHOOK_AUTH_METADATA_KEY, context.getHandler())) != null ? _Reflect_getMetadata : Reflect.getMetadata(PLUGIN_WEBHOOK_AUTH_METADATA_KEY, context.getClass())) != null ? _ref : null;
    }
    getString(value) {
        if (typeof value !== 'string') {
            return '';
        }
        return value.trim();
    }
    constructor(authService){
        this.authService = authService;
    }
};
PluginWebhookAuthGuard = __decorate([
    Injectable(),
    __param(0, Optional()),
    __param(0, Inject(PLUGIN_WEBHOOK_AUTH_SERVICE_TOKEN)),
    __metadata("design:paramtypes", [
        Object
    ])
], PluginWebhookAuthGuard);

const DATASOURCE_STRATEGY = 'DATASOURCE_STRATEGY';
const DataSourceStrategy = (provider)=>applyDecorators(SetMetadata(DATASOURCE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, DATASOURCE_STRATEGY));

let DataSourceStrategyRegistry = class DataSourceStrategyRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(DATASOURCE_STRATEGY, discoveryService, reflector);
    }
};
DataSourceStrategyRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], DataSourceStrategyRegistry);

/**
 * Helper base class to wrap existing adapter query runner implementations
 * into datasource strategies consumable by the plugin SDK.
 */ class AdapterDataSourceStrategy {
    /**
     * Get from cache or create new instance of DB adapter.
     *
     * @param options
     * @param id
     * @returns
     */ async create(options, id) {
        if (id) {
            if (this.runners.has(id)) {
                return this.runners.get(id);
            }
            const runner = this.instantiateRunner(options);
            this.runners.set(id, runner);
            // If the Runner supports initPool, then initialize the connection pool.
            if (typeof runner.initPool === 'function') {
                await runner.initPool(options);
            }
            return runner;
        }
        return this.instantiateRunner(options);
    }
    async configurationSchema() {
        if (!this.configurationSchemaCache) {
            var _runner_teardown;
            const runner = this.instantiateRunner(undefined);
            var _runner_configurationSchema;
            this.configurationSchemaCache = (_runner_configurationSchema = runner == null ? void 0 : runner.configurationSchema) != null ? _runner_configurationSchema : {};
            await (runner == null ? void 0 : (_runner_teardown = runner.teardown) == null ? void 0 : _runner_teardown.call(runner));
        }
        return this.configurationSchemaCache;
    }
    async teardown(runner) {
        var _runner_teardown;
        await (runner == null ? void 0 : (_runner_teardown = runner.teardown) == null ? void 0 : _runner_teardown.call(runner));
    }
    instantiateRunner(options) {
        return new this.runnerClass(options, ...this.extraArgs);
    }
    getClassType() {
        return this.runnerClass;
    }
    constructor(runnerClass, extraArgs = []){
        this.runners = new Map() // dataSourceId -> runner instance
        ;
        this.runnerClass = runnerClass;
        this.extraArgs = extraArgs;
    }
}

const axios = _axios.default;
var DBSyntaxEnum;
(function(DBSyntaxEnum) {
    DBSyntaxEnum["SQL"] = "sql";
    DBSyntaxEnum["MDX"] = "mdx";
})(DBSyntaxEnum || (DBSyntaxEnum = {}));
var DBProtocolEnum;
(function(DBProtocolEnum) {
    DBProtocolEnum["SQL"] = "sql";
    DBProtocolEnum["XMLA"] = "xmla";
})(DBProtocolEnum || (DBProtocolEnum = {}));
class BaseQueryRunner {
    jdbcUrl(schema) {
        return '';
    }
    get configurationSchema() {
        return null;
    }
    run(sql) {
        return this.runQuery(sql);
    }
    describe(catalog, statement) {
        throw new Error(`Unimplemented`);
    }
    async import({ name, columns, data }, options) {
        return null;
    }
    async dropTable(name, options) {
        this.runQuery(`DROP TABLE ${name}`, options);
    }
    async tableOp(action, params, options) {
        throw new Error(`Unimplemented method`);
    }
    async tableDataOp(action, params, options) {
        throw new Error(`Unimplemented tableDataOp`);
    }
    constructor(options){
        this.options = options;
    }
}
class BaseHTTPQueryRunner extends BaseQueryRunner {
    get url() {
        var _this_options;
        return (_this_options = this.options) == null ? void 0 : _this_options.url;
    }
    get host() {
        var _this_options, _this_options1;
        if ((_this_options = this.options) == null ? void 0 : _this_options.host) {
            return this.options.host;
        }
        return new URL((_this_options1 = this.options) == null ? void 0 : _this_options1.url).hostname;
    }
    get port() {
        var _this_options, _this_options1;
        if ((_this_options = this.options) == null ? void 0 : _this_options.port) {
            return Number(this.options.port);
        }
        return new URL((_this_options1 = this.options) == null ? void 0 : _this_options1.url).port;
    }
    get configurationSchema() {
        return {};
    }
    get() {
        return axios.get(this.url);
    }
    post(data, options) {
        return axios.post(this.url, data, options);
    }
}
class BaseSQLQueryRunner extends BaseQueryRunner {
    get host() {
        var _this_options, _this_options1;
        if ((_this_options = this.options) == null ? void 0 : _this_options.host) {
            return this.options.host;
        }
        if ((_this_options1 = this.options) == null ? void 0 : _this_options1.url) {
            var _this_options2;
            return new URL((_this_options2 = this.options) == null ? void 0 : _this_options2.url).hostname;
        }
        return null;
    }
    get port() {
        var _this_options, _this_options1;
        if ((_this_options = this.options) == null ? void 0 : _this_options.port) {
            return Number(this.options.port);
        }
        if ((_this_options1 = this.options) == null ? void 0 : _this_options1.url) {
            var _this_options2;
            return new URL((_this_options2 = this.options) == null ? void 0 : _this_options2.url).port;
        }
        return null;
    }
    async ping() {
        await this.runQuery(`SELECT 1`);
    }
    /**
     * Default implementation for table operations
     */ async tableOp(action, params, options) {
        switch(action){
            case DBTableAction.CREATE_TABLE:
                {
                    // Default implementation for creating table (generic SQL syntax)
                    const { schema, table, columns, createMode = DBCreateTableMode.ERROR } = params;
                    const tableName = schema ? `${schema}.${table}` : table;
                    // Check if table exists (try to query table info)
                    let exists = false;
                    try {
                        const result = await this.runQuery(`SELECT * FROM ${tableName} WHERE 1=0`, options);
                        exists = true;
                    } catch (error) {
                        // Table does not exist
                        exists = false;
                    }
                    // --- MODE: ERROR → throw error if table exists ---
                    if (exists && createMode === DBCreateTableMode.ERROR) {
                        throw new Error(`Table "${tableName}" already exists`);
                    }
                    // --- MODE: IGNORE → do nothing if exists ---
                    if (exists && createMode === DBCreateTableMode.IGNORE) {
                        return;
                    }
                    // --- MODE: UPGRADE → auto upgrade (simple implementation: only add new columns) ---
                    // Note: This default implementation does not support modifying column types,
                    //       recommend each database to implement its own version
                    if (exists && createMode === DBCreateTableMode.UPGRADE) {
                        console.warn(`[BaseSQLQueryRunner] UPGRADE mode uses basic implementation. Consider implementing tableOp for better support.`);
                        // Try to add new columns (will fail if column already exists, but doesn't affect)
                        for (const col of columns){
                            try {
                                const colType = this.mapColumnType(col.type, col.isKey, col.length);
                                await this.runQuery(`ALTER TABLE ${tableName} ADD COLUMN ${col.fieldName} ${colType}`, options);
                            } catch (error) {
                                // Field might already exist, ignore error
                                console.debug(`Failed to add column ${col.fieldName}:`, error instanceof Error ? error.message : String(error));
                            }
                        }
                        return;
                    }
                    // --- MODE: CREATE NEW TABLE ---
                    const columnsDDL = columns.map((col)=>{
                        const colType = this.mapColumnType(col.type, col.isKey, col.length);
                        const pk = col.isKey ? ' PRIMARY KEY' : '';
                        const notNull = col.required ? ' NOT NULL' : '';
                        return `${col.fieldName} ${colType}${pk}${notNull}`;
                    }).join(', ');
                    const createTableStatement = `CREATE TABLE ${tableName} (${columnsDDL})`;
                    await this.runQuery(createTableStatement, options);
                    return;
                }
            case DBTableAction.DROP_TABLE:
                {
                    // Default implementation for dropping table
                    const { schema, table } = params;
                    const tableName = schema ? `${schema}.${table}` : table;
                    await this.runQuery(`DROP TABLE IF EXISTS ${tableName}`, options);
                    return;
                }
            default:
                // Throw error for other unimplemented operations
                throw new Error(`Unsupported table action: ${action}`);
        }
    }
    /**
     * Generic type mapping (subclasses can override)
     */ mapColumnType(type, isKey, length) {
        switch(type == null ? void 0 : type.toLowerCase()){
            case 'string':
                return length ? `VARCHAR(${length})` : isKey ? 'VARCHAR(255)' : 'VARCHAR(1000)';
            case 'number':
                return 'INT';
            case 'boolean':
                return 'BOOLEAN';
            case 'date':
                return 'DATE';
            case 'datetime':
                return 'TIMESTAMP';
            case 'object':
                return 'TEXT';
            default:
                return 'VARCHAR(1000)';
        }
    }
    constructor(...args){
        super(...args);
        this.syntax = DBSyntaxEnum.SQL;
        this.protocol = DBProtocolEnum.SQL;
    }
}
var DBTableAction;
(function(DBTableAction) {
    DBTableAction["LIST_TABLES"] = "listTables";
    DBTableAction["TABLE_EXISTS"] = "tableExists";
    DBTableAction["CREATE_TABLE"] = "createTable";
    DBTableAction["DROP_TABLE"] = "dropTable";
    DBTableAction["RENAME_TABLE"] = "renameTable";
    DBTableAction["TRUNCATE_TABLE"] = "truncateTable";
    DBTableAction["ADD_COLUMN"] = "addColumn";
    DBTableAction["DROP_COLUMN"] = "dropColumn";
    DBTableAction["MODIFY_COLUMN"] = "modifyColumn";
    DBTableAction["CREATE_INDEX"] = "createIndex";
    DBTableAction["DROP_INDEX"] = "dropIndex";
    DBTableAction["GET_TABLE_INFO"] = "getTableInfo";
    DBTableAction["CLONE_TABLE_STRUCTURE"] = "cloneTableStructure";
    DBTableAction["CLONE_TABLE"] = "cloneTable";
    DBTableAction["OPTIMIZE_TABLE"] = "optimizeTable";
})(DBTableAction || (DBTableAction = {}));
/**
 * Modes for creating a table, if the table already exists
 */ var DBCreateTableMode;
(function(DBCreateTableMode) {
    DBCreateTableMode["ERROR"] = "error";
    DBCreateTableMode["IGNORE"] = "ignore";
    DBCreateTableMode["UPGRADE"] = "upgrade"; // automatically upgrade table structure
})(DBCreateTableMode || (DBCreateTableMode = {}));
var DBTableDataAction;
(function(DBTableDataAction) {
    DBTableDataAction["INSERT"] = "insert";
    DBTableDataAction["UPDATE"] = "update";
    DBTableDataAction["UPSERT"] = "upsert";
    DBTableDataAction["DELETE"] = "delete";
    DBTableDataAction["SELECT"] = "select";
    DBTableDataAction["BULK_INSERT"] = "bulkInsert";
})(DBTableDataAction || (DBTableDataAction = {}));

const AnalyticsRuntimeCapability = createRuntimeCapability('platform.analytics', {
    description: 'Execute scoped read-only provider queries and validate their dataset contracts.'
});

/** Public diagnostics only; Error.message deliberately excludes unvalidated provider text. */ class AnalyticsProviderError extends Error {
    constructor(diagnostic){
        super('ANALYTICS_PROVIDER_ERROR');
        this.name = 'AnalyticsProviderError';
        const parsed = parseAnalyticsDiagnostic(diagnostic);
        if (!parsed) throw new Error('ANALYTICS_DIAGNOSTIC_INVALID');
        this.diagnostic = parsed;
        this.message = JSON.stringify(parsed);
    }
}
/** Structural lookup also accepts another SDK copy; class identity is not a trust boundary. */ function readAnalyticsProviderDiagnostic(error) {
    if (!error || typeof error !== 'object') return undefined;
    // Read own data properties only. Do not invoke getters on foreign exceptions.
    try {
        const name = Object.getOwnPropertyDescriptor(error, 'name');
        const diagnostic = Object.getOwnPropertyDescriptor(error, 'diagnostic');
        if ((name == null ? void 0 : name.value) !== 'AnalyticsProviderError' || !diagnostic || !('value' in diagnostic)) return undefined;
        return parseAnalyticsDiagnostic(diagnostic.value);
    } catch (e) {
        return undefined;
    }
}

const ANALYTICS_PROVIDER = 'ANALYTICS_QUERY_PROVIDER';
/** Mark a Nest provider registered by a plugin module; id must match its descriptor.id. */ const AnalyticsProvider = (id)=>applyDecorators(SetMetadata(ANALYTICS_PROVIDER, id), SetMetadata(STRATEGY_META_KEY, ANALYTICS_PROVIDER));
/** Uses shared plugin scoping; execution callers list providers for the current actor's organization. */ let AnalyticsProviderRegistry = class AnalyticsProviderRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(ANALYTICS_PROVIDER, discovery, reflector);
    }
};
AnalyticsProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], AnalyticsProviderRegistry);

/** Structural feedback from the discovered provider contract. Never substitutes for provider authorization or validation. */ function validateAnalyticsPayload(payload, schema) {
    if (typeof schema !== 'boolean' && (schema === null || typeof schema !== 'object' || Array.isArray(schema))) {
        throw new Error('ANALYTICS_PAYLOAD_SCHEMA_INVALID: expected a provider JSON Schema');
    }
    // Do not coerce, remove properties, apply defaults, fetch remote refs, or treat unknown formats as authorization.
    const ajv = new Ajv({
        strict: false,
        validateFormats: false,
        allErrors: false
    });
    let validate;
    try {
        validate = ajv.compile(schema);
    } catch (e) {
        throw new Error('ANALYTICS_PAYLOAD_SCHEMA_INVALID: rediscover the provider contract; its schema could not be compiled');
    }
    if ('$async' in validate && validate.$async) {
        throw new Error('ANALYTICS_PAYLOAD_SCHEMA_INVALID: provider payload validation must use a synchronous schema');
    }
    if (!validate(payload)) {
        var _validate_errors;
        const issue = (_validate_errors = validate.errors) == null ? void 0 : _validate_errors[0];
        const location = (issue == null ? void 0 : issue.instancePath) || '/';
        var _issue_keyword;
        throw new Error(`ANALYTICS_PAYLOAD_INVALID: ${location.slice(0, 240)} (${(_issue_keyword = issue == null ? void 0 : issue.keyword) != null ? _issue_keyword : 'schema'}). Compare this field with the discovered payloadSchema and canonical Binding. Copy opaque IDs, revisions and contract hashes exactly; do not retry unchanged input.`);
    }
}

/** Host resource owners enumerate sources using the current viewer's ACLs. */ class ListAnalyticsSourcesCommand extends Command {
    constructor(actor, kind){
        super();
        this.actor = actor;
        this.kind = kind;
    }
}
ListAnalyticsSourcesCommand.type = '[Analytics] List native sources';
/** Authorize an exact immutable version; the owner also supplies the post-execution ACL/integrity recheck. */ class ResolveAnalyticsSourceCommand extends Command {
    constructor(actor, source){
        super();
        this.actor = actor;
        this.source = source;
    }
}
ResolveAnalyticsSourceCommand.type = '[Analytics] Resolve native source';
Reflect.defineMetadata('__command__', {
    id: ListAnalyticsSourcesCommand.type
}, ListAnalyticsSourcesCommand);
Reflect.defineMetadata('__command__', {
    id: ResolveAnalyticsSourceCommand.type
}, ResolveAnalyticsSourceCommand);

/** Separate from the read-only analytics query capability. No HTTP or model-supplied actor scope. */ const AnalyticsDefinitionAuthoringCapability = createRuntimeCapability('platform.analytics.definitions', {
    description: 'Discover authorized inputs and register immutable Agent-generated analytics definitions.'
});

const AI_MODEL_PROVIDER = 'AI_MODEL_PROVIDER';
function AIModelProviderStrategy(provider) {
    var _err_stack;
    const err = new Error();
    var _err_stack_split;
    const stack = (_err_stack_split = (_err_stack = err.stack) == null ? void 0 : _err_stack.split('\n')) != null ? _err_stack_split : [];
    // Find the current decorator function's position on the stack.
    const decoratorIndex = stack.findIndex((line)=>line.includes('AIModelProviderStrategy'));
    // The line that calls the decorator (the next line)
    const callerLine = stack[decoratorIndex + 1];
    // Extract the file path
    const match = (callerLine == null ? void 0 : callerLine.match(/\((file:\/\/\/[^\s)]+)\)/)) || (// case 1: file:///path...
    callerLine == null ? void 0 : callerLine.match(/\((\/[^\s)]+)\)/)) || (// case 2: (/Users/xxx)
    callerLine == null ? void 0 : callerLine.match(/at (file:\/\/\/[^\s]+)/)) || (// case 3: at file:///...
    callerLine == null ? void 0 : callerLine.match(/at (\/[^\s]+)/)); // case 4: at /Users/xxx
    let file = match == null ? void 0 : match[1];
    // remove the file:/// prefix
    if (file == null ? void 0 : file.startsWith('file:///')) {
        file = file.replace('file://', '');
    }
    // Strip :line:col suffix (e.g. "/path/file.js:37:5" -> "/path/file.js")
    if (file) {
        file = file.replace(/:\d+:\d+$/, '');
    }
    // Decode URL-encoded paths (e.g. Chinese characters: %E9%A1%B9%E7%9B%AE -> 项目)
    if (file) {
        try {
            file = decodeURIComponent(file);
        } catch (e) {
        // keep as-is if decode fails
        }
    }
    const dir = file ? path__default.dirname(file) : process.cwd();
    return function(target) {
        SetMetadata(STRATEGY_META_KEY, AI_MODEL_PROVIDER)(target);
        // Ensure NestJS is discoverable
        SetMetadata(AI_MODEL_PROVIDER, provider)(target);
        // Write custom path (does not affect Discovery)
        Reflect.defineMetadata(`${AI_MODEL_PROVIDER}_DIR`, dir, target);
    };
}

let AIModelProviderRegistry = class AIModelProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(AI_MODEL_PROVIDER, discoveryService, reflector);
    }
};
AIModelProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], AIModelProviderRegistry);

function valueOf(enumObj, value) {
    const enumValues = Object.values(enumObj);
    if (enumValues.includes(value)) {
        return value;
    }
    throw new Error(`Invalid enum value: ${value}`);
}
var DefaultParameterName;
(function(DefaultParameterName) {
    DefaultParameterName["TEMPERATURE"] = "temperature";
    DefaultParameterName["TOP_P"] = "top_p";
    DefaultParameterName["TOP_K"] = "top_k";
    DefaultParameterName["PRESENCE_PENALTY"] = "presence_penalty";
    DefaultParameterName["FREQUENCY_PENALTY"] = "frequency_penalty";
    DefaultParameterName["MAX_TOKENS"] = "max_tokens";
    DefaultParameterName["RESPONSE_FORMAT"] = "response_format";
    DefaultParameterName["JSON_SCHEMA"] = "json_schema";
})(DefaultParameterName || (DefaultParameterName = {}));

const PARAMETER_RULE_TEMPLATE = {
    [DefaultParameterName.TEMPERATURE]: {
        label: {
            en_US: 'Temperature',
            zh_Hans: '温度'
        },
        type: ParameterType.FLOAT,
        help: {
            en_US: 'Controls randomness. Lower temperature results in less random completions.' + ' As the temperature approaches zero, the model will become deterministic and repetitive.' + ' Higher temperature results in more random completions.',
            zh_Hans: '温度控制随机性。较低的温度会导致较少的随机完成。随着温度接近零，模型将变得确定性和重复性。' + '较高的温度会导致更多的随机完成。'
        },
        required: false,
        default: 0.0,
        min: 0.0,
        max: 1.0,
        precision: 2
    },
    [DefaultParameterName.TOP_P]: {
        label: {
            en_US: 'Top P',
            zh_Hans: 'Top P'
        },
        type: ParameterType.FLOAT,
        help: {
            en_US: 'Controls diversity via nucleus sampling: 0.5 means half of all likelihood-weighted options' + ' are considered.',
            zh_Hans: '通过核心采样控制多样性：0.5表示考虑了一半的所有可能性加权选项。'
        },
        required: false,
        default: 1.0,
        min: 0.0,
        max: 1.0,
        precision: 2
    },
    [DefaultParameterName.TOP_K]: {
        label: {
            en_US: 'Top K',
            zh_Hans: 'Top K'
        },
        type: ParameterType.INT,
        help: {
            en_US: 'Limits the number of tokens to consider for each step by keeping only the k most likely tokens.',
            zh_Hans: '通过只保留每一步中最可能的 k 个标记来限制要考虑的标记数量。'
        },
        required: false,
        default: 50,
        min: 1,
        max: 100,
        precision: 0
    },
    [DefaultParameterName.PRESENCE_PENALTY]: {
        label: {
            en_US: 'Presence Penalty',
            zh_Hans: '存在惩罚'
        },
        type: ParameterType.FLOAT,
        help: {
            en_US: 'Applies a penalty to the log-probability of tokens already in the text.',
            zh_Hans: '对文本中已有的标记的对数概率施加惩罚。'
        },
        required: false,
        default: 0.0,
        min: 0.0,
        max: 1.0,
        precision: 2
    },
    [DefaultParameterName.FREQUENCY_PENALTY]: {
        label: {
            en_US: 'Frequency Penalty',
            zh_Hans: '频率惩罚'
        },
        type: ParameterType.FLOAT,
        help: {
            en_US: 'Applies a penalty to the log-probability of tokens that appear in the text.',
            zh_Hans: '对文本中出现的标记的对数概率施加惩罚。'
        },
        required: false,
        default: 0.0,
        min: 0.0,
        max: 1.0,
        precision: 2
    },
    [DefaultParameterName.MAX_TOKENS]: {
        label: {
            en_US: 'Max Tokens',
            zh_Hans: '最大标记'
        },
        type: ParameterType.INT,
        help: {
            en_US: 'Specifies the upper limit on the length of generated results.' + ' If the generated results are truncated, you can increase this parameter.',
            zh_Hans: '指定生成结果长度的上限。如果生成结果截断，可以调大该参数。'
        },
        required: false,
        default: 2048,
        min: 1,
        max: 2048,
        precision: 0
    },
    [DefaultParameterName.RESPONSE_FORMAT]: {
        label: {
            en_US: 'Response Format',
            zh_Hans: '回复格式'
        },
        type: ParameterType.STRING,
        help: {
            en_US: 'Set a response format, ensure the output from llm is a valid code block as possible,' + ' such as JSON, XML, etc.',
            zh_Hans: '设置一个返回格式，确保llm的输出尽可能是有效的代码块，如JSON、XML等'
        },
        required: false,
        options: [
            'JSON',
            'XML'
        ]
    },
    [DefaultParameterName.JSON_SCHEMA]: {
        label: {
            en_US: 'JSON Schema'
        },
        type: ParameterType.TEXT,
        help: {
            en_US: 'Set a response json schema will ensure LLM to adhere it.',
            zh_Hans: '设置返回的json schema，llm将按照它返回'
        },
        required: false
    }
};

class AiModelNotFoundException extends NotFoundException {
}
class CredentialsValidateFailedError extends ForbiddenException {
}
class AIModelProviderNotFoundException extends NotFoundException {
}

var ModelProvider_1;
let ModelProvider = ModelProvider_1 = class ModelProvider {
    get name() {
        return this.getProviderSchema().provider;
    }
    async validateCredentials(credentials) {
        await this.validateProviderCredentials(credentials);
    }
    /**
     * Get provider lib root path.
     *
     * @returns Root of library
     */ getProviderServerPath() {
        return this.dir;
    }
    getProviderSchema() {
        if (this._meta) {
            return this._meta;
        }
        const yamlPath = join(this.getProviderServerPath(), `${this._name}.yaml`);
        const yamlData = loadYamlFile(yamlPath, this.logger);
        try {
            this._meta = yamlData;
        } catch (e) {
            throw new Error(`Invalid provider schema for ${this.name}: ${e.message}`);
        }
        return this._meta;
    }
    async getModels(modelType) {
        const providerSchema = this.getProviderSchema();
        const supported = providerSchema.supported_model_types.includes(modelType) || modelType === AiModelTypeEnum.IMAGE && providerSchema.supported_model_types.includes(AiModelTypeEnum.TEXT2IMG);
        if (!supported) {
            return [];
        }
        var _this_modelManagers_get;
        const modelInstance = modelType === AiModelTypeEnum.IMAGE ? (_this_modelManagers_get = this.modelManagers.get(AiModelTypeEnum.IMAGE)) != null ? _this_modelManagers_get : this.modelManagers.get(AiModelTypeEnum.TEXT2IMG) : this.modelManagers.get(modelType);
        if (!modelInstance) {
            throw new AiModelNotFoundException(`Missing AIModel instance for model type ${modelType}`);
        }
        return modelInstance.predefinedModels();
    }
    registerAIModelInstance(modelType, modelInstance) {
        this.modelManagers.set(modelType, modelInstance);
    }
    getModelManager(modelType) {
        const modelInstance = this.modelManagers.get(modelType);
        if (!modelInstance) {
            throw new AiModelNotFoundException(`Missing AIModel instance for model type ${modelType}`);
        }
        return modelInstance;
    }
    /**
     * Get provider models.
     * @param modelType - model type
     * @param onlyActive - only active models
     * @return provider models
     */ getProviderModels(modelType, onlyActive = false) {
        let modelTypes = [];
        if (modelType) {
            modelTypes.push(modelType);
        } else {
            modelTypes = this.getProviderSchema().supported_model_types;
        }
        const providerModels = this.getSystemProviderModels(modelTypes);
        // Resort providerModels
        return providerModels.sort((a, b)=>a.model_type.localeCompare(b.model_type));
    }
    getSystemProviderModels(modelTypes) {
        const models = [];
        modelTypes == null ? void 0 : modelTypes.forEach((modelType)=>{
            var _this_modelManagers_get;
            const modelManager = modelType === AiModelTypeEnum.IMAGE ? (_this_modelManagers_get = this.modelManagers.get(AiModelTypeEnum.IMAGE)) != null ? _this_modelManagers_get : this.modelManagers.get(AiModelTypeEnum.TEXT2IMG) : this.modelManagers.get(modelType);
            if (modelManager) {
                models.push(...modelManager.predefinedModels());
            }
        });
        return models;
    }
    getChatModel(copilotModel, options) {
        var _this_getModelManager;
        return (_this_getModelManager = this.getModelManager(AiModelTypeEnum.LLM)) == null ? void 0 : _this_getModelManager.getChatModel(copilotModel, options);
    }
    async getModelInstance(type, copilotModel, options) {
        switch(type){
            case AiModelTypeEnum.LLM:
                var _this_getModelManager;
                return (_this_getModelManager = this.getModelManager(type)) == null ? void 0 : _this_getModelManager.getChatModel(copilotModel, options);
            case AiModelTypeEnum.TEXT_EMBEDDING:
                var _this_getModelManager1;
                if (!copilotModel.options) {
                    var _copilotModel_copilot_copilotModel, _predefinedModels_find;
                    const predefinedModels = await this.getModels(AiModelTypeEnum.TEXT_EMBEDDING);
                    const modelName = copilotModel.model || ((_copilotModel_copilot_copilotModel = copilotModel.copilot.copilotModel) == null ? void 0 : _copilotModel_copilot_copilotModel.model);
                    copilotModel.options = (_predefinedModels_find = predefinedModels.find((_)=>_.model === modelName)) == null ? void 0 : _predefinedModels_find.model_properties;
                }
                return (_this_getModelManager1 = this.getModelManager(type)) == null ? void 0 : _this_getModelManager1.getEmbeddingInstance(copilotModel, options);
            case AiModelTypeEnum.TTS:
                var _this_getModelManager2;
                return (_this_getModelManager2 = this.getModelManager(type)) == null ? void 0 : _this_getModelManager2.getChatModel(copilotModel, options);
            case AiModelTypeEnum.SPEECH2TEXT:
                var _this_getModelManager3;
                return (_this_getModelManager3 = this.getModelManager(type)) == null ? void 0 : _this_getModelManager3.getChatModel(copilotModel, options);
            case AiModelTypeEnum.RERANK:
                var _this_getModelManager4;
                return (_this_getModelManager4 = this.getModelManager(type)) == null ? void 0 : _this_getModelManager4.getReranker(copilotModel, options);
            case AiModelTypeEnum.IMAGE:
                var _this;
                var _this_modelManagers_get;
                return (_this = (_this_modelManagers_get = this.modelManagers.get(AiModelTypeEnum.IMAGE)) != null ? _this_modelManagers_get : this.modelManagers.get(AiModelTypeEnum.TEXT2IMG)) == null ? void 0 : _this.getAIGCModel(copilotModel, options);
            case AiModelTypeEnum.TEXT2IMG:
            case AiModelTypeEnum.VIDEO:
                var _this_getModelManager5;
                return (_this_getModelManager5 = this.getModelManager(type)) == null ? void 0 : _this_getModelManager5.getAIGCModel(copilotModel, options);
        }
        return null;
    }
    constructor(){
        this.logger = new Logger(ModelProvider_1.name);
        // protected providerSchema: IAiProviderEntity | null = null
        this.modelManagers = new Map();
        const provider = Reflect.getMetadata(AI_MODEL_PROVIDER, this.constructor);
        this._name = provider;
        // Automatically retrieve provider DIR information from decorator metadata
        const dir = Reflect.getMetadata(`${AI_MODEL_PROVIDER}_DIR`, this.constructor);
        this.dir = dir;
    }
};
ModelProvider = ModelProvider_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [])
], ModelProvider);

const CommonParameterRules = [
    {
        name: 'temperature',
        label: {
            zh_Hans: '温度',
            en_US: `Temperature`
        },
        type: ParameterType.FLOAT,
        help: {
            zh_Hans: '控制模型输出的随机性。较高的值（例如 1.0）使响应更具创意，而较低的值（例如 0.1）使响应更具确定性和重点性。',
            en_US: `Controls the randomness of the model's output. A higher value (e.g., 1.0) makes responses more creative, while a lower value (e.g., 0.1) makes them more deterministic and focused.`
        },
        required: false,
        default: 0.2,
        min: 0,
        max: 1,
        precision: 0.1
    },
    {
        label: {
            zh_Hans: '最大尝试次数',
            en_US: 'The maximum number of attempts'
        },
        type: ParameterType.INT,
        help: {
            zh_Hans: '如果请求由于网络超时或速率限制等问题而失败，系统将尝试重新发送请求的最大次数',
            en_US: 'The maximum number of attempts the system will make to resend a request if it fails due to issues like network timeouts or rate limits'
        },
        required: false,
        default: 6,
        min: 0,
        max: 10,
        precision: 0,
        name: 'maxRetries'
    }
];
function mergeCredentials(credentials, modelProperties) {
    return _extends({}, credentials != null ? credentials : {}, modelProperties != null ? modelProperties : {});
}

function calculateModelPrice(pricing, priceType, tokens, inputTokens = tokens) {
    var _pricing_tiered_pricing;
    const tier = (_pricing_tiered_pricing = pricing.tiered_pricing) == null ? void 0 : _pricing_tiered_pricing.find(({ max_tokens })=>inputTokens <= Number(max_tokens));
    var _tier_input, _tier_output;
    const configuredUnitPrice = priceType === PriceType.INPUT ? (_tier_input = tier == null ? void 0 : tier.input) != null ? _tier_input : pricing.input : (_tier_output = tier == null ? void 0 : tier.output) != null ? _tier_output : pricing.output;
    const unitPrice = Number(configuredUnitPrice);
    if (!Number.isFinite(unitPrice)) {
        return {
            unitPrice: 0,
            unit: 0,
            totalAmount: 0,
            currency: 'USD'
        };
    }
    return {
        unitPrice,
        unit: Number(pricing.unit),
        totalAmount: Number((tokens * unitPrice * Number(pricing.unit)).toFixed(7)),
        currency: pricing.currency
    };
}
function calculateLLMUsagePrice(pricing, usage, context = {}) {
    var _pricing_rules;
    validateLLMPriceRules((_pricing_rules = pricing.rules) != null ? _pricing_rules : []);
    const pricingContext = _extends({}, context, {
        pricingTime: resolvePricingTime(context.pricingTime)
    });
    const promptTokens = tokenCount(usage.promptTokens, 'promptTokens');
    const completionTokens = tokenCount(usage.completionTokens, 'completionTokens');
    var _usage_cacheReadInputTokens;
    const cacheReadInputTokens = tokenCount((_usage_cacheReadInputTokens = usage.cacheReadInputTokens) != null ? _usage_cacheReadInputTokens : 0, 'cacheReadInputTokens');
    var _usage_cacheWriteInputTokens;
    const cacheWriteInputTokens = tokenCount((_usage_cacheWriteInputTokens = usage.cacheWriteInputTokens) != null ? _usage_cacheWriteInputTokens : 0, 'cacheWriteInputTokens');
    const cacheTokens = cacheReadInputTokens + cacheWriteInputTokens;
    const inputTokens = context.inputTokensIncludeCache === false ? promptTokens + cacheTokens : promptTokens;
    let standardInputTokens = context.inputTokensIncludeCache === false ? promptTokens : promptTokens - cacheTokens;
    if (standardInputTokens < 0) {
        throw new Error('Cache read and write tokens cannot exceed prompt tokens when input includes cache tokens');
    }
    const selectionContext = {
        inputTokens,
        outputTokens: completionTokens,
        context: pricingContext
    };
    const breakdown = [];
    const cacheReadRule = selectLLMPriceRule(pricing.rules, 'cache_read_input', selectionContext);
    if (cacheReadInputTokens > 0) {
        if (cacheReadRule) {
            breakdown.push(priceRuleComponent(cacheReadRule, cacheReadInputTokens, pricing.currency));
        } else if (hasLLMPriceRule(pricing.rules, 'cache_read_input')) {
            breakdown.push(unpricedComponent('cache_read_input', cacheReadInputTokens));
        } else {
            standardInputTokens += cacheReadInputTokens;
        }
    }
    for (const cacheWrite of resolveCacheWriteInputTokens(cacheWriteInputTokens, context)){
        const cacheWriteSelection = _extends({}, selectionContext, {
            context: _extends({}, pricingContext, {
                cacheWriteTtl: cacheWrite.cacheTtl
            })
        });
        const cacheWriteRule = selectLLMPriceRule(pricing.rules, 'cache_write_input', cacheWriteSelection);
        if (cacheWriteRule) {
            breakdown.push(priceRuleComponent(cacheWriteRule, cacheWrite.quantity, pricing.currency, {
                cacheTtl: cacheWrite.cacheTtl
            }));
        } else if (hasLLMPriceRule(pricing.rules, 'cache_write_input')) {
            breakdown.push(unpricedComponent('cache_write_input', cacheWrite.quantity, {
                cacheTtl: cacheWrite.cacheTtl
            }));
        } else {
            standardInputTokens += cacheWrite.quantity;
        }
    }
    if (standardInputTokens > 0) {
        const inputRule = selectLLMPriceRule(pricing.rules, 'input', selectionContext);
        breakdown.push(inputRule ? priceRuleComponent(inputRule, standardInputTokens, pricing.currency) : hasLLMPriceRule(pricing.rules, 'input') ? unpricedComponent('input', standardInputTokens) : legacyPriceComponent(pricing, PriceType.INPUT, standardInputTokens, inputTokens));
    }
    if (completionTokens > 0) {
        const outputRule = selectLLMPriceRule(pricing.rules, 'output', selectionContext);
        breakdown.push(outputRule ? priceRuleComponent(outputRule, completionTokens, pricing.currency) : hasLLMPriceRule(pricing.rules, 'output') ? unpricedComponent('output', completionTokens) : legacyPriceComponent(pricing, PriceType.OUTPUT, completionTokens, inputTokens));
    }
    const addOns = new Map();
    var _context_addOns;
    for (const addOn of (_context_addOns = context.addOns) != null ? _context_addOns : []){
        const quantity = nonNegativeQuantity(addOn.quantity, `add-on '${addOn.type}'`);
        if (quantity === 0) continue;
        var _addOns_get;
        addOns.set(addOn.type, ((_addOns_get = addOns.get(addOn.type)) != null ? _addOns_get : 0) + quantity);
    }
    for (const [addOn, quantity] of addOns){
        const rule = selectLLMPriceRule(pricing.rules, 'request', selectionContext, addOn);
        breakdown.push(rule ? priceRuleComponent(rule, quantity, pricing.currency, {
            addOn
        }) : unpricedComponent('request', quantity, {
            addOn
        }));
    }
    var _context_unpricedAddOns;
    for (const addOn of (_context_unpricedAddOns = context.unpricedAddOns) != null ? _context_unpricedAddOns : []){
        const quantity = nonNegativeQuantity(addOn.quantity, `unpriced add-on '${addOn.type}'`);
        if (quantity === 0) continue;
        breakdown.push(unpricedComponent('request', quantity, {
            addOn: addOn.type,
            addOnAuthority: addOn.authority
        }));
    }
    if (context.cacheStorageTokenHours !== undefined) {
        const quantity = nonNegativeQuantity(context.cacheStorageTokenHours, 'cacheStorageTokenHours');
        if (quantity > 0) {
            const rule = selectLLMPriceRule(pricing.rules, 'cache_storage', selectionContext);
            breakdown.push(rule ? priceRuleComponent(rule, quantity, pricing.currency) : unpricedComponent('cache_storage', quantity));
        }
    }
    return summarizeLLMPrice(pricing.currency, breakdown);
}
function resolveModelUsagePricingSnapshot(pricing, context) {
    var _normalizeDate;
    var _normalizeDate_toISOString;
    const capturedAt = (_normalizeDate_toISOString = (_normalizeDate = normalizeDate(context.startedAt)) == null ? void 0 : _normalizeDate.toISOString()) != null ? _normalizeDate_toISOString : new Date().toISOString();
    if (!isModelUsagePricingConfig(pricing)) {
        return _extends({
            capturedAt
        }, context.pricingDimensions ? {
            pricingDimensions: context.pricingDimensions
        } : {}, {
            rules: []
        });
    }
    const at = new Date(capturedAt);
    const matchingRules = pricing.rules.filter((rule)=>matchesUsagePriceRule(rule, context, at));
    const rules = [];
    for (const rule of matchingRules){
        validateUsagePriceRule(rule);
        const selector = usagePriceRuleSelector(rule);
        const existingIndex = rules.findIndex((candidate)=>usagePriceRuleSelector(candidate) === selector);
        if (existingIndex < 0) {
            rules.push(rule);
            continue;
        }
        const existing = rules[existingIndex];
        const existingHasWindow = Boolean(existing.daily_time_window);
        const currentHasWindow = Boolean(rule.daily_time_window);
        if (existingHasWindow === currentHasWindow) {
            throw new Error(`Ambiguous usage pricing rules for unit '${rule.unit}'`);
        }
        if (currentHasWindow) rules[existingIndex] = rule;
    }
    return _extends({
        capturedAt
    }, context.pricingDimensions ? {
        pricingDimensions: context.pricingDimensions
    } : {}, {
        rules
    });
}
function calculateModelUsageCharge(snapshot, metric) {
    const rule = selectUsagePriceRule(snapshot, metric);
    const fallbackQuantity = metricQuantity(metric);
    if (!rule) {
        return {
            pricingStatus: 'unpriced',
            quantity: fallbackQuantity
        };
    }
    const quantity = rule.unit === 'token' ? tokenQuantity(metric, rule.token_type) : fallbackQuantity;
    if (rule.charge_type === 'free') {
        return _extends({
            pricingStatus: 'free',
            pricingRule: rule,
            quantity,
            unitSize: rule.unit_size,
            unitPrice: 0
        }, rule.currency ? {
            currency: rule.currency
        } : {}, {
            amount: 0
        });
    }
    const unitPrice = Number(rule.unit_price);
    const unitSize = Number(rule.unit_size);
    return {
        pricingStatus: 'priced',
        pricingRule: rule,
        quantity,
        unitSize,
        unitPrice,
        currency: rule.currency,
        amount: roundCharge(quantity / unitSize * unitPrice)
    };
}
function isModelUsagePricingConfig(pricing) {
    return pricing !== undefined && 'type' in pricing && pricing.type === 'usage' && Array.isArray(pricing.rules);
}
function matchesUsagePriceRule(rule, context, at) {
    var _rule_operations;
    const effectiveFrom = normalizeDate(rule.effective_from);
    const effectiveTo = normalizeDate(rule.effective_to);
    if (!effectiveFrom || effectiveFrom > at || effectiveTo && effectiveTo <= at) return false;
    if (((_rule_operations = rule.operations) == null ? void 0 : _rule_operations.length) && !rule.operations.includes(context.operation)) return false;
    if (rule.daily_time_window) {
        validateRecurringDailyWindow(rule.daily_time_window);
        if (!isInRecurringDailyWindow(rule.daily_time_window, at)) return false;
    }
    var _context_pricingDimensions;
    const dimensions = (_context_pricingDimensions = context.pricingDimensions) != null ? _context_pricingDimensions : {};
    var _rule_dimensions;
    return Object.entries((_rule_dimensions = rule.dimensions) != null ? _rule_dimensions : {}).every(([key, value])=>{
        if (key === 'resolution') return dimensions.resolution === undefined || dimensions.resolution === value;
        if (key === 'audio') return dimensions.audio === undefined || dimensions.audio === value;
        if (key === 'videoInput') return dimensions.videoInput === undefined || dimensions.videoInput === value;
        if (key === 'mode') return dimensions.mode === undefined || dimensions.mode === value;
        return false;
    });
}
function selectUsagePriceRule(snapshot, metric) {
    var _snapshot_pricingDimensions, _metric_pricingDimensions;
    const dimensions = _extends({}, (_snapshot_pricingDimensions = snapshot == null ? void 0 : snapshot.pricingDimensions) != null ? _snapshot_pricingDimensions : {}, (_metric_pricingDimensions = metric.pricingDimensions) != null ? _metric_pricingDimensions : {});
    var _snapshot_rules;
    const matches = ((_snapshot_rules = snapshot == null ? void 0 : snapshot.rules) != null ? _snapshot_rules : []).filter((rule)=>{
        if (rule.unit !== metric.unit) return false;
        if (rule.component && rule.component !== metric.component) return false;
        return matchesUsagePriceDimensions(rule, dimensions);
    });
    if (!matches.length) return undefined;
    const specificity = Math.max(...matches.map(usagePriceRuleSpecificity));
    const mostSpecific = matches.filter((rule)=>usagePriceRuleSpecificity(rule) === specificity);
    if (mostSpecific.length > 1) {
        var _metric_key;
        throw new Error(`Ambiguous usage pricing rules for metric '${(_metric_key = metric.key) != null ? _metric_key : metric.unit}'`);
    }
    return mostSpecific[0];
}
function matchesUsagePriceDimensions(rule, dimensions) {
    var _rule_dimensions;
    return Object.entries((_rule_dimensions = rule.dimensions) != null ? _rule_dimensions : {}).every(([key, value])=>{
        if (key === 'resolution') return dimensions.resolution === value;
        if (key === 'audio') return dimensions.audio === value;
        if (key === 'videoInput') return dimensions.videoInput === value;
        if (key === 'mode') return dimensions.mode === value;
        return false;
    });
}
function usagePriceRuleSpecificity(rule) {
    var _rule_dimensions;
    return (rule.component ? 1 : 0) + Object.keys((_rule_dimensions = rule.dimensions) != null ? _rule_dimensions : {}).length;
}
function usagePriceRuleSelector(rule) {
    var _rule_token_type, _rule_component, _rule_dimensions;
    return JSON.stringify([
        rule.unit,
        (_rule_token_type = rule.token_type) != null ? _rule_token_type : null,
        (_rule_component = rule.component) != null ? _rule_component : null,
        Object.entries((_rule_dimensions = rule.dimensions) != null ? _rule_dimensions : {}).sort(([left], [right])=>left.localeCompare(right))
    ]);
}
function validateUsagePriceRule(rule) {
    var _rule_id, _rule_version;
    if (!((_rule_id = rule.id) == null ? void 0 : _rule_id.trim()) || !((_rule_version = rule.version) == null ? void 0 : _rule_version.trim())) throw new Error('Usage pricing rules require id and version');
    if (rule.component && ![
        'input',
        'output',
        'request'
    ].includes(rule.component)) {
        throw new Error(`Usage pricing rule '${rule.id}' has an invalid component`);
    }
    if (!Number.isFinite(Number(rule.unit_size)) || Number(rule.unit_size) <= 0) {
        throw new Error(`Usage pricing rule '${rule.id}' requires a positive unit_size`);
    }
    if (rule.unit !== 'token' && rule.token_type) {
        throw new Error(`Usage pricing rule '${rule.id}' can only use token_type with token pricing`);
    }
    if (rule.daily_time_window) validateRecurringDailyWindow(rule.daily_time_window);
    if (rule.charge_type === 'paid') {
        var _rule_currency;
        if (!Number.isFinite(Number(rule.unit_price)) || Number(rule.unit_price) <= 0 || !((_rule_currency = rule.currency) == null ? void 0 : _rule_currency.trim())) {
            throw new Error(`Paid usage pricing rule '${rule.id}' requires unit_price and currency`);
        }
    }
}
function metricQuantity(metric) {
    if (metric.unit !== 'token') return finiteQuantity(metric.quantity);
    var _metric_totalTokens, _ref;
    return finiteQuantity((_ref = (_metric_totalTokens = metric.totalTokens) != null ? _metric_totalTokens : metric.promptTokens) != null ? _ref : metric.completionTokens);
}
function tokenQuantity(metric, tokenType) {
    if (metric.unit !== 'token') return 0;
    if (tokenType === 'prompt') return finiteQuantity(metric.promptTokens);
    if (tokenType === 'completion') return finiteQuantity(metric.completionTokens);
    return finiteQuantity(metric.totalTokens);
}
function finiteQuantity(value) {
    const quantity = Number(value);
    return Number.isFinite(quantity) && quantity > 0 ? quantity : 0;
}
function normalizeDate(value) {
    if (!value) return undefined;
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? undefined : date;
}
function roundCharge(value) {
    return Number(value.toFixed(10));
}
function hasLLMPriceRule(rules, component) {
    var _rules_some;
    return (_rules_some = rules == null ? void 0 : rules.some((rule)=>rule.component === component)) != null ? _rules_some : false;
}
function selectLLMPriceRule(rules, component, selection, addOn) {
    const matches = (rules != null ? rules : []).filter((rule)=>{
        if (rule.component !== component) return false;
        if (component === 'request' && rule.add_on !== addOn) return false;
        if (rule.cache_ttl && rule.cache_ttl !== selection.context.cacheWriteTtl) return false;
        if (rule.mode && rule.mode !== selection.context.mode) return false;
        if (rule.region && rule.region !== selection.context.region) return false;
        if (rule.service_tier && rule.service_tier !== selection.context.serviceTier) return false;
        if (rule.daily_time_window && !isInRecurringDailyWindow(rule.daily_time_window, selection.context.pricingTime)) {
            return false;
        }
        if (rule.min_input_tokens !== undefined && selection.inputTokens < Number(rule.min_input_tokens)) return false;
        if (rule.max_input_tokens !== undefined && selection.inputTokens > Number(rule.max_input_tokens)) return false;
        if (rule.min_output_tokens !== undefined && selection.outputTokens < Number(rule.min_output_tokens)) return false;
        if (rule.max_output_tokens !== undefined && selection.outputTokens > Number(rule.max_output_tokens)) return false;
        return true;
    });
    if (!matches.length) return undefined;
    const specificity = Math.max(...matches.map(ruleSpecificity));
    const mostSpecific = matches.filter((rule)=>ruleSpecificity(rule) === specificity);
    if (mostSpecific.length > 1) {
        throw new Error(`Ambiguous LLM pricing rules for component '${component}'`);
    }
    return mostSpecific[0];
}
function ruleSpecificity(rule) {
    return [
        rule.min_input_tokens,
        rule.max_input_tokens,
        rule.min_output_tokens,
        rule.max_output_tokens,
        rule.mode,
        rule.region,
        rule.service_tier,
        rule.add_on,
        rule.cache_ttl,
        rule.daily_time_window
    ].filter((value)=>value !== undefined).length;
}
function validateLLMPriceRules(rules) {
    for (const rule of rules){
        if (!Number.isFinite(Number(rule.unit_price)) || Number(rule.unit_price) < 0) {
            throw new Error(`LLM pricing rule '${rule.component}' requires a non-negative unit_price`);
        }
        if (!Number.isFinite(Number(rule.unit_size)) || Number(rule.unit_size) <= 0) {
            throw new Error(`LLM pricing rule '${rule.component}' requires a positive unit_size`);
        }
        if (rule.currency !== undefined && !rule.currency.trim()) {
            throw new Error(`LLM pricing rule '${rule.component}' requires a non-empty currency when provided`);
        }
        validateTokenRange(rule, 'input', rule.min_input_tokens, rule.max_input_tokens);
        validateTokenRange(rule, 'output', rule.min_output_tokens, rule.max_output_tokens);
        if (rule.component === 'request' && !rule.add_on) {
            throw new Error('LLM request pricing rules require add_on');
        }
        if (rule.component !== 'request' && rule.add_on) {
            throw new Error(`LLM pricing rule '${rule.component}' cannot declare add_on`);
        }
        if (rule.component !== 'cache_write_input' && rule.cache_ttl) {
            throw new Error(`LLM pricing rule '${rule.component}' cannot declare cache_ttl`);
        }
        if (rule.daily_time_window) validateRecurringDailyWindow(rule.daily_time_window);
    }
}
function validateTokenRange(rule, name, min, max) {
    const normalizedMin = min === undefined ? undefined : Number(min);
    const normalizedMax = max === undefined ? undefined : Number(max);
    if (normalizedMin !== undefined) tokenCount(normalizedMin, `min_${name}_tokens`);
    if (normalizedMax !== undefined) tokenCount(normalizedMax, `max_${name}_tokens`);
    if (normalizedMin !== undefined && normalizedMax !== undefined && normalizedMin > normalizedMax) {
        throw new Error(`LLM pricing rule '${rule.component}' has an invalid ${name} token range`);
    }
}
function validateRecurringDailyWindow(window) {
    validateTimeZone(window.time_zone);
    const start = parseLocalTime(window.start_time, 'start_time');
    const end = parseLocalTime(window.end_time, 'end_time');
    if (start === end) {
        throw new Error('Recurring daily pricing window start_time and end_time must differ');
    }
}
function validateTimeZone(timeZone) {
    try {
        new Intl.DateTimeFormat('en-US', {
            timeZone
        }).format();
    } catch (e) {
        throw new Error(`Invalid IANA time zone '${timeZone}'`);
    }
}
function parseLocalTime(value, name) {
    const match = /^(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value);
    if (!match) {
        throw new Error(`Recurring daily pricing window ${name} must use HH:mm or HH:mm:ss`);
    }
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    var _match_;
    const second = Number((_match_ = match[3]) != null ? _match_ : 0);
    if (hour > 23 || minute > 59 || second > 59) {
        throw new Error(`Recurring daily pricing window ${name} must be a valid wall-clock time`);
    }
    return hour * 3600 + minute * 60 + second;
}
function isInRecurringDailyWindow(window, pricingTime) {
    const instant = resolvePricingTime(pricingTime);
    const formatter = new Intl.DateTimeFormat('en-GB', {
        timeZone: window.time_zone,
        hourCycle: 'h23',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    const values = Object.fromEntries(formatter.formatToParts(instant).filter((part)=>part.type === 'hour' || part.type === 'minute' || part.type === 'second').map((part)=>[
            part.type,
            Number(part.value)
        ]));
    const localTime = values['hour'] * 3600 + values['minute'] * 60 + values['second'];
    const start = parseLocalTime(window.start_time, 'start_time');
    const end = parseLocalTime(window.end_time, 'end_time');
    return start < end ? localTime >= start && localTime < end : localTime >= start || localTime < end;
}
function resolvePricingTime(value) {
    const instant = value instanceof Date ? new Date(value.getTime()) : value === undefined ? new Date() : new Date(value);
    if (!Number.isFinite(instant.getTime())) {
        throw new Error('pricingTime must be a valid date');
    }
    return instant;
}
function priceRuleComponent(rule, quantity, fallbackCurrency, qualifiers = {}) {
    const unitPrice = Number(rule.unit_price);
    const unit = 1 / Number(rule.unit_size);
    const amount = roundCharge(quantity * unitPrice * unit);
    var _rule_currency;
    return _extends({
        component: rule.component,
        quantity,
        pricingStatus: unitPrice === 0 ? 'free' : 'priced',
        unitPrice,
        unit,
        amount,
        currency: normalizeCurrency((_rule_currency = rule.currency) != null ? _rule_currency : fallbackCurrency)
    }, qualifiers, {
        rule
    });
}
function legacyPriceComponent(pricing, priceType, quantity, inputTokens) {
    const price = calculateModelPrice(pricing, priceType, quantity, inputTokens);
    return {
        component: priceType,
        quantity,
        pricingStatus: price.unitPrice === 0 ? 'free' : 'priced',
        unitPrice: price.unitPrice,
        unit: price.unit,
        amount: price.totalAmount,
        currency: normalizeCurrency(price.currency)
    };
}
function unpricedComponent(component, quantity, qualifiers = {}) {
    return _extends({
        component,
        quantity,
        pricingStatus: 'unpriced'
    }, qualifiers);
}
function tokenCount(value, name) {
    if (!Number.isFinite(value) || !Number.isInteger(value) || value < 0) {
        throw new Error(`${name} must be a finite non-negative integer`);
    }
    return value;
}
function nonNegativeQuantity(value, name) {
    if (!Number.isFinite(value) || value < 0) {
        throw new Error(`${name} must be a non-negative number`);
    }
    return value;
}
function resolveCacheWriteInputTokens(total, context) {
    if (!context.cacheWriteInputTokensByTtl) {
        return total > 0 ? [
            {
                quantity: total,
                cacheTtl: context.cacheWriteTtl
            }
        ] : [];
    }
    const cacheWrites = [
        '5m',
        '1h'
    ].map((cacheTtl)=>{
        var _context_cacheWriteInputTokensByTtl;
        var _context_cacheWriteInputTokensByTtl_cacheTtl;
        return {
            cacheTtl,
            quantity: tokenCount((_context_cacheWriteInputTokensByTtl_cacheTtl = (_context_cacheWriteInputTokensByTtl = context.cacheWriteInputTokensByTtl) == null ? void 0 : _context_cacheWriteInputTokensByTtl[cacheTtl]) != null ? _context_cacheWriteInputTokensByTtl_cacheTtl : 0, `cacheWriteInputTokensByTtl.${cacheTtl}`)
        };
    }).filter(({ quantity })=>quantity > 0);
    const detailedTotal = cacheWrites.reduce((sum, item)=>sum + item.quantity, 0);
    if (detailedTotal !== total) {
        throw new Error('Cache write token counts by TTL must equal cacheWriteInputTokens');
    }
    return cacheWrites;
}
function summarizeLLMPrice(currency, breakdown) {
    const hasUnpricedComponent = breakdown.some((item)=>item.pricingStatus === 'unpriced');
    const hasPaidComponent = breakdown.some((item)=>item.pricingStatus === 'priced');
    const currencies = new Set(breakdown.map((item)=>item.currency).filter((value)=>Boolean(value)).map(normalizeCurrency));
    if (currencies.size > 1) {
        throw new Error('LLM pricing calculation cannot mix currencies');
    }
    var _currencies_values_next_value;
    return {
        pricingStatus: hasUnpricedComponent ? 'unpriced' : hasPaidComponent ? 'priced' : 'free',
        totalAmount: Number(breakdown.reduce((total, item)=>{
            var _item_amount;
            return total + ((_item_amount = item.amount) != null ? _item_amount : 0);
        }, 0).toFixed(7)),
        currency: (_currencies_values_next_value = currencies.values().next().value) != null ? _currencies_values_next_value : normalizeCurrency(currency),
        breakdown
    };
}
function normalizeCurrency(currency) {
    return currency.trim().toUpperCase();
}

/** Apply an explicit saved configuration without mutating a shared predefined schema. */ function applyModelConfiguration(model, configuration, schema) {
    var _schema_label, _schema_parameter_rules;
    const result = _extends({}, schema, {
        model,
        label: (_schema_label = schema == null ? void 0 : schema.label) != null ? _schema_label : {
            en_US: model,
            zh_Hans: model
        },
        model_type: configuration.modelType,
        fetch_from: FetchFrom.CUSTOMIZABLE_MODEL,
        model_properties: _extends({}, schema == null ? void 0 : schema.model_properties, {
            [ModelPropertyKey.CONTEXT_SIZE]: configuration.contextSize
        }),
        parameter_rules: [
            ...(_schema_parameter_rules = schema == null ? void 0 : schema.parameter_rules) != null ? _schema_parameter_rules : []
        ]
    });
    if (configuration.modelType === AiModelTypeEnum.LLM) {
        result.features = [
            ...configuration.features
        ];
        result.model_properties[ModelPropertyKey.MODE] = 'chat';
        result.parameter_rules = [
            ...result.parameter_rules.filter((rule)=>rule.name !== 'max_tokens'),
            {
                name: 'max_tokens',
                label: {
                    en_US: 'Max output tokens',
                    zh_Hans: '最大输出 Token'
                },
                type: ParameterType.INT,
                min: 1,
                max: configuration.maxOutputTokens,
                default: configuration.defaultMaxTokens
            }
        ];
    }
    return result;
}

var AIModel_1;
let AIModel = AIModel_1 = class AIModel {
    getRealtimeModel(_copilotModel) {
        throw new Error('Unsupported realtime model');
    }
    getChatModel(copilotModel, options) {
        throw new Error(`Unsupport chat model!`);
    }
    getAIGCModel(copilotModel, options) {
        throw new Error(`Unsupported AIGC model!`);
    }
    getPrice(model, credentials, priceType, tokens, inputTokens = tokens) {
        const modelSchema = this.getModelSchema(model, credentials);
        if (!modelSchema || !modelSchema.pricing || isModelUsagePricingConfig(modelSchema.pricing)) {
            return {
                unitPrice: 0,
                unit: 0,
                totalAmount: 0,
                currency: 'USD'
            };
        }
        return calculateModelPrice(modelSchema.pricing, priceType, tokens, inputTokens);
    }
    getUsagePricingSnapshot(model, credentials, context) {
        var _this_getModelSchema;
        const pricing = (_this_getModelSchema = this.getModelSchema(model, credentials)) == null ? void 0 : _this_getModelSchema.pricing;
        if (this.modelType === AiModelTypeEnum.TEXT_EMBEDDING && pricing && !isModelUsagePricingConfig(pricing)) {
            var _pricing_tiered_pricing, _pricing_rules, _pricing_currency;
            // Only flat input prices can be converted without the invocation's actual token count.
            // Invalid or conditional prices must remain unpriced, never silently become free.
            const input = Number(pricing.input), unit = Number(pricing.unit);
            if (((_pricing_tiered_pricing = pricing.tiered_pricing) == null ? void 0 : _pricing_tiered_pricing.length) || ((_pricing_rules = pricing.rules) == null ? void 0 : _pricing_rules.length) || !Number.isFinite(input) || input < 0 || !Number.isFinite(unit) || unit <= 0 || !((_pricing_currency = pricing.currency) == null ? void 0 : _pricing_currency.trim())) {
                return resolveModelUsagePricingSnapshot(undefined, context);
            }
            return resolveModelUsagePricingSnapshot({
                type: 'usage',
                rules: [
                    {
                        id: `${model}:embedding-input`,
                        version: 'catalog',
                        effective_from: '1970-01-01T00:00:00.000Z',
                        unit: 'token',
                        token_type: 'prompt',
                        unit_size: 1,
                        unit_price: input * unit,
                        currency: pricing.currency,
                        charge_type: input === 0 ? 'free' : 'paid'
                    }
                ]
            }, context);
        }
        return resolveModelUsagePricingSnapshot(pricing, context);
    }
    getModelPath() {
        const modelType = this.modelType.toLowerCase();
        return path.join(this.modelProvider.getProviderServerPath(), modelType);
    }
    predefinedModels() {
        if (this.modelSchemas) {
            return this.modelSchemas;
        }
        const providerName = this.modelProvider.name.toLowerCase();
        const modelType = this.modelType.toLowerCase();
        const providerModelTypePath = this.getModelPath();
        const modelSchemaFiles = fs.readdirSync(providerModelTypePath).filter((file)=>!file.startsWith('_') && file.endsWith('.yaml'));
        const modelSchemas = [];
        for (const file of modelSchemaFiles){
            const filePath = path.join(providerModelTypePath, file);
            const yamlContent = fs.readFileSync(filePath, 'utf8');
            const yamlData = yaml.parse(yamlContent);
            // Processing parameter rules and tags
            this.processParameterRules(yamlData);
            this.processLabel(yamlData);
            try {
                const modelSchema = yamlData;
                modelSchemas.push(modelSchema);
            } catch (error) {
                throw new Error(`Invalid model schema for ${providerName}.${modelType}.${file}: ${error.message}`);
            }
        }
        // Sorting model architecture by position
        this.modelSchemas = this.sortModelSchemas(modelSchemas, providerModelTypePath);
        return this.modelSchemas;
    }
    getModelSchema(model, credentials) {
        const models = this.predefinedModels();
        const schema = models.find((_)=>_.model === model);
        const configuration = readModelConfiguration(credentials);
        if (configuration) {
            if (configuration.modelType !== this.modelType) {
                throw new Error('Saved model configuration does not match its model type');
            }
            return applyModelConfiguration(model, configuration, schema != null ? schema : this.getCustomizableModelSchemaFromCredentials(model, credentials));
        }
        if (schema) {
            return schema;
        }
        if (credentials) {
            return this.getCustomizableModelSchemaFromCredentials(model, credentials);
        }
        return null;
    }
    /**
     * Get customizable model schema.
     * Implement this method in ai model sub class that can customize model
     *
     * @param model model name
     * @param credentials model credentials
     * @returns model schema
     */ getCustomizableModelSchemaFromCredentials(model, credentials) {
        return null;
    }
    processParameterRules(yamlData) {
        const newParameterRules = [];
        const parameterRules = yamlData['parameter_rules'] || [];
        for (let parameterRule of parameterRules){
            if (parameterRule.use_template) {
                try {
                    const defaultParameterName = valueOf(DefaultParameterName, parameterRule.use_template);
                    const defaultParameterRule = getDefaultParameterRuleVariableMap(defaultParameterName);
                    const copyDefaultParameterRule = _extends({}, defaultParameterRule, parameterRule);
                    parameterRule = copyDefaultParameterRule;
                } catch (error) {
                // Handle error if necessary
                }
            }
            if (!parameterRule.label) {
                parameterRule.label = {
                    zh_Hans: parameterRule.name,
                    en_US: parameterRule.name
                };
            }
            newParameterRules.push(parameterRule);
        }
        yamlData['parameter_rules'] = newParameterRules;
    }
    processLabel(yamlData) {
        if (!yamlData['label']) {
            yamlData['label'] = {
                zh_Hans: yamlData['model'],
                en_US: yamlData['model']
            };
        }
        yamlData['fetch_from'] = FetchFrom.PREDEFINED_MODEL;
    }
    sortModelSchemas(modelSchemas, providerModelTypePath) {
        // Implementing model architecture sorting logic
        if (!this.positions) {
            this.positions = getPositionMap(providerModelTypePath);
        }
        return modelSchemas.sort((a, b)=>{
            var _this_positions_a_model;
            const positionA = (_this_positions_a_model = this.positions[a.model]) != null ? _this_positions_a_model : Number.MAX_SAFE_INTEGER;
            var _this_positions_b_model;
            const positionB = (_this_positions_b_model = this.positions[b.model]) != null ? _this_positions_b_model : Number.MAX_SAFE_INTEGER;
            return positionA - positionB;
        });
    }
    _commonParameterRules(model) {
        return null;
    }
    getParameterRules(model, credentials) {
        const modelSchema = this.getModelSchema(model, credentials);
        var _modelSchema_parameter_rules;
        const parameterRules = (_modelSchema_parameter_rules = modelSchema == null ? void 0 : modelSchema.parameter_rules) != null ? _modelSchema_parameter_rules : [];
        var _this__commonParameterRules;
        return [
            ...(_this__commonParameterRules = this._commonParameterRules(model)) != null ? _this__commonParameterRules : [],
            ...parameterRules.filter((_)=>!CommonParameterRules.some((r)=>r.name === _.name))
        ];
    }
    getModelProfile(model, credentials) {
        var _modelSchema_model_properties, _modelSchema_features, _modelSchema_features1, _modelSchema_features2, _modelSchema_features3, _modelSchema_features4, _modelSchema_features5, _modelSchema_parameter_rules;
        const modelSchema = this.getModelSchema(model, credentials);
        if (!modelSchema) return null;
        const profile = {
            maxInputTokens: (_modelSchema_model_properties = modelSchema.model_properties) == null ? void 0 : _modelSchema_model_properties.context_size,
            imageInputs: (_modelSchema_features = modelSchema.features) == null ? void 0 : _modelSchema_features.includes(ModelFeature.VISION),
            videoInputs: (_modelSchema_features1 = modelSchema.features) == null ? void 0 : _modelSchema_features1.includes(ModelFeature.VIDEO),
            toolCalling: ((_modelSchema_features2 = modelSchema.features) == null ? void 0 : _modelSchema_features2.includes(ModelFeature.TOOL_CALL)) || ((_modelSchema_features3 = modelSchema.features) == null ? void 0 : _modelSchema_features3.includes(ModelFeature.MULTI_TOOL_CALL)) || ((_modelSchema_features4 = modelSchema.features) == null ? void 0 : _modelSchema_features4.includes(ModelFeature.STREAM_TOOL_CALL)),
            structuredOutput: (_modelSchema_features5 = modelSchema.features) == null ? void 0 : _modelSchema_features5.includes(ModelFeature.STRUCTURED_OUTPUT)
        };
        const maxTokensRule = (_modelSchema_parameter_rules = modelSchema.parameter_rules) == null ? void 0 : _modelSchema_parameter_rules.find((rule)=>rule.name === 'max_tokens');
        if (maxTokensRule) {
            profile.maxOutputTokens = maxTokensRule.max;
        }
        return profile;
    }
    constructor(modelProvider, modelType){
        this.logger = new Logger(AIModel_1.name);
        this.modelSchemas = null;
        this.positions = null;
        this.modelProvider = modelProvider;
        this.modelType = modelType;
        this.modelProvider.registerAIModelInstance(this.modelType, this);
    }
};
AIModel = AIModel_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        ModelProvider,
        String
    ])
], AIModel);
function getDefaultParameterRuleVariableMap(name) {
    /**
     * Get default parameter rule for given name
     *
     * @param name - parameter name
     * @return parameter rule
     */ const defaultParameterRule = PARAMETER_RULE_TEMPLATE[name];
    if (!defaultParameterRule) {
        throw new Error(`Invalid model parameter rule name ${name}`);
    }
    return defaultParameterRule;
}

class TextEmbeddingModelManager extends AIModel {
}

class RerankModel extends AIModel {
    async validateCredentials(model, credentials) {
    //
    }
}

class SpeechToTextModel extends AIModel {
}

class TextToSpeechModel extends AIModel {
    getParameterRules(model, credentials) {
        var _this__commonParameterRules;
        const rules = (_this__commonParameterRules = this._commonParameterRules(model)) != null ? _this__commonParameterRules : [];
        const modelSchema = this.getModelSchema(model, credentials);
        if (modelSchema.model_properties) {
            if (modelSchema.model_properties['voices']) {
                rules.push({
                    name: 'voice',
                    type: ParameterType.STRING,
                    required: true,
                    options: modelSchema.model_properties['voices'].map(({ mode })=>mode),
                    label: {
                        zh_Hans: '音色',
                        en_US: `Voice`
                    },
                    help: {
                        zh_Hans: '合成声音的音色。可以选择不同的声音风格。',
                        en_US: `The voice style for the synthesized speech. Different styles can be selected.`
                    },
                    default: modelSchema.model_properties['default_voice']
                });
            }
        }
        return rules;
    }
}

class ImageGenerationModel extends AIModel {
}
class VideoGenerationModel extends AIModel {
}

const PROVIDE_AI_MODEL_LLM = 'provide_ai_model_llm';
const PROVIDE_AI_MODEL_MODERATION = 'provide_ai_model_moderation';
const PROVIDE_AI_MODEL_SPEECH2TEXT = 'provide_ai_model_speech2text';
const PROVIDE_AI_MODEL_TEXT_EMBEDDING = 'provide_ai_model_text_embedding';
const PROVIDE_AI_MODEL_TTS = 'provide_ai_model_tts';
const PROVIDE_AI_MODEL_RERANK = 'provide_ai_model_rerank';

function _class_private_field_loose_base(receiver, privateKey) {
    if (!Object.prototype.hasOwnProperty.call(receiver, privateKey)) {
        throw new TypeError("attempted to use private field on non-instance");
    }
    return receiver;
}

var id = 0;
function _class_private_field_loose_key(name) {
    return "__private_" + id++ + "_" + name;
}

function resolveTokenUsageCandidates(input) {
    const candidates = [
        {
            value: input.canonical,
            source: 'provider'
        },
        {
            value: input.actual,
            source: 'provider'
        },
        {
            value: input.estimated,
            source: 'estimated'
        },
        {
            value: {
                totalTokens: input.legacyTotal
            },
            source: 'legacy'
        }
    ];
    for (const candidate of candidates){
        const usage = normalizeTokenUsage(candidate.value);
        if (usage) return {
            usage,
            source: candidate.source
        };
    }
    return {
        usage: {
            promptTokens: 0,
            completionTokens: 0,
            totalTokens: 0
        },
        source: 'unavailable'
    };
}
function normalizeTokenUsage(candidate) {
    if (!candidate) return null;
    const counts = [
        candidate.promptTokens,
        candidate.completionTokens,
        candidate.totalTokens,
        candidate.cacheReadInputTokens,
        candidate.cacheWriteInputTokens,
        candidate.reasoningTokens
    ];
    if (counts.some((count)=>count !== undefined && (!Number.isSafeInteger(count) || count < 0))) return null;
    var _candidate_promptTokens;
    const promptTokens = (_candidate_promptTokens = candidate.promptTokens) != null ? _candidate_promptTokens : 0;
    var _candidate_completionTokens;
    const completionTokens = (_candidate_completionTokens = candidate.completionTokens) != null ? _candidate_completionTokens : 0;
    const totalTokens = candidate.totalTokens || promptTokens + completionTokens;
    if (!Number.isSafeInteger(totalTokens) || totalTokens <= 0 || totalTokens < promptTokens + completionTokens) return null;
    var _candidate_cacheReadInputTokens, _candidate_cacheWriteInputTokens, _candidate_reasoningTokens;
    if (((_candidate_cacheReadInputTokens = candidate.cacheReadInputTokens) != null ? _candidate_cacheReadInputTokens : 0) + ((_candidate_cacheWriteInputTokens = candidate.cacheWriteInputTokens) != null ? _candidate_cacheWriteInputTokens : 0) > promptTokens || ((_candidate_reasoningTokens = candidate.reasoningTokens) != null ? _candidate_reasoningTokens : 0) > completionTokens) return null;
    return _extends({
        promptTokens,
        completionTokens,
        totalTokens
    }, candidate.cacheReadInputTokens ? {
        cacheReadInputTokens: candidate.cacheReadInputTokens
    } : {}, candidate.cacheWriteInputTokens ? {
        cacheWriteInputTokens: candidate.cacheWriteInputTokens
    } : {}, candidate.reasoningTokens ? {
        reasoningTokens: candidate.reasoningTokens
    } : {});
}

var _a;
class LLMUsage {
    static emptyUsage() {
        return new LLMUsage(0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0, 0.0, 'USD', 0.0);
    }
    plus(other) {
        /**
         * Add two LLMUsage instances together.
         *
         * @param other: Another LLMUsage instance to add
         * @return: A new LLMUsage instance with summed values
         */ if (this.totalTokens === 0) {
            return other;
        } else {
            return new LLMUsage(this.promptTokens + other.promptTokens, other.promptUnitPrice, other.promptPriceUnit, this.promptPrice + other.promptPrice, this.completionTokens + other.completionTokens, other.completionUnitPrice, other.completionPriceUnit, this.completionPrice + other.completionPrice, this.totalTokens + other.totalTokens, this.totalPrice + other.totalPrice, other.currency, this.latency + other.latency);
        }
    }
    add(other) {
        /**
         * Overload the + operator to add two LLMUsage instances.
         *
         * @param other: Another LLMUsage instance to add
         * @return: A new LLMUsage instance with summed values
         */ return this.plus(other);
    }
    constructor(promptTokens, promptUnitPrice, promptPriceUnit, promptPrice, completionTokens, completionUnitPrice, completionPriceUnit, completionPrice, totalTokens, totalPrice, currency, latency){
        this.promptTokens = promptTokens;
        this.promptUnitPrice = promptUnitPrice;
        this.promptPriceUnit = promptPriceUnit;
        this.promptPrice = promptPrice;
        this.completionTokens = completionTokens;
        this.completionUnitPrice = completionUnitPrice;
        this.completionPriceUnit = completionPriceUnit;
        this.completionPrice = completionPrice;
        this.totalTokens = totalTokens;
        this.totalPrice = totalPrice;
        this.currency = currency;
        this.latency = latency;
    }
}
var _logger = /*#__PURE__*/ _class_private_field_loose_key("_logger");
class LargeLanguageModel extends AIModel {
    _commonParameterRules(model) {
        return CommonParameterRules;
    }
    /** Price already normalized provider facts without starting another inference or writing a ledger. */ priceActualTokenUsage(model, tokenUsage, context = {}) {
        var _this_getModelSchema;
        const usage = normalizeTokenUsage(tokenUsage);
        if (!usage) throw new Error('Actual token usage is required');
        const priced = this.calcResponseUsage(model, {}, usage.promptTokens, usage.completionTokens, performance.now(), usage, _extends({}, context, {
            inputTokensIncludeCache: true
        }));
        return _extends({}, priced, usage, !((_this_getModelSchema = this.getModelSchema(model, {})) == null ? void 0 : _this_getModelSchema.pricing) ? {
            pricingStatus: 'unpriced',
            totalPrice: undefined
        } : {});
    }
    calcResponseUsage(model, credentials, promptTokens, completionTokens, startedAt = this.startedAt, tokenUsage, pricingContext = {}) {
        var _this_getModelSchema;
        const resolvedTokenUsage = tokenUsage != null ? tokenUsage : {
            promptTokens,
            completionTokens,
            totalTokens: promptTokens + completionTokens
        };
        const pricing = (_this_getModelSchema = this.getModelSchema(model, credentials)) == null ? void 0 : _this_getModelSchema.pricing;
        if (pricing && !isModelUsagePricingConfig(pricing)) {
            const calculation = calculateLLMUsagePrice(pricing, resolvedTokenUsage, pricingContext);
            const promptBreakdown = calculation.breakdown.filter((item)=>[
                    'input',
                    'cache_read_input',
                    'cache_write_input'
                ].includes(item.component));
            const completionBreakdown = calculation.breakdown.filter((item)=>item.component === 'output');
            var _promptBreakdown_find;
            const promptRate = (_promptBreakdown_find = promptBreakdown.find((item)=>item.component === 'input')) != null ? _promptBreakdown_find : promptBreakdown[0];
            const completionRate = completionBreakdown[0];
            var _promptRate_unitPrice, _promptRate_unit, _completionRate_unitPrice, _completionRate_unit;
            return _extends({}, resolvedTokenUsage, {
                promptUnitPrice: (_promptRate_unitPrice = promptRate == null ? void 0 : promptRate.unitPrice) != null ? _promptRate_unitPrice : 0,
                promptPriceUnit: (_promptRate_unit = promptRate == null ? void 0 : promptRate.unit) != null ? _promptRate_unit : 0,
                promptPrice: Number(promptBreakdown.reduce((total, item)=>{
                    var _item_amount;
                    return total + ((_item_amount = item.amount) != null ? _item_amount : 0);
                }, 0).toFixed(7)),
                completionUnitPrice: (_completionRate_unitPrice = completionRate == null ? void 0 : completionRate.unitPrice) != null ? _completionRate_unitPrice : 0,
                completionPriceUnit: (_completionRate_unit = completionRate == null ? void 0 : completionRate.unit) != null ? _completionRate_unit : 0,
                completionPrice: Number(completionBreakdown.reduce((total, item)=>{
                    var _item_amount;
                    return total + ((_item_amount = item.amount) != null ? _item_amount : 0);
                }, 0).toFixed(7)),
                totalPrice: calculation.totalAmount,
                currency: calculation.currency,
                latency: performance.now() - startedAt,
                pricingStatus: calculation.pricingStatus,
                priceAuthority: 'catalog',
                pricingBreakdown: calculation.breakdown
            });
        }
        const promptPriceInfo = this.getPrice(model, credentials, PriceType.INPUT, promptTokens, promptTokens);
        const completionPriceInfo = this.getPrice(model, credentials, PriceType.OUTPUT, completionTokens, promptTokens);
        const totalPrice = Number((promptPriceInfo.totalAmount + completionPriceInfo.totalAmount).toFixed(7));
        // Conversion usage
        const usage = _extends({}, resolvedTokenUsage, {
            promptUnitPrice: promptPriceInfo.unitPrice,
            promptPriceUnit: promptPriceInfo.unit,
            promptPrice: promptPriceInfo.totalAmount,
            completionUnitPrice: completionPriceInfo.unitPrice,
            completionPriceUnit: completionPriceInfo.unit,
            completionPrice: completionPriceInfo.totalAmount,
            totalPrice,
            currency: promptPriceInfo.currency,
            latency: performance.now() - startedAt,
            pricingStatus: totalPrice === 0 ? 'free' : 'priced',
            priceAuthority: 'catalog'
        });
        return usage;
    }
    createHandleUsageCallbacks(copilot, model, credentials, handleLLMTokens, pricingConfiguration = {}) {
        const pricingOptions = normalizeUsagePricingOptions(pricingConfiguration);
        var _pricingOptions_context;
        const basePricingContext = (_pricingOptions_context = pricingOptions.context) != null ? _pricingOptions_context : {};
        const runs = new Map();
        const reportUsage = async (requestId, tokenUsage, startedAt, pricingTime, type, output)=>{
            const pricingContext = _extends({}, basePricingContext, output && pricingOptions.resolveContext ? pricingOptions.resolveContext(output) : {}, {
                pricingTime
            });
            const normalizedTokenUsage = normalizeCacheTokenAccounting(tokenUsage, pricingContext);
            if (!handleLLMTokens || normalizedTokenUsage.totalTokens <= 0) {
                return;
            }
            let usage = _extends({}, this.calcResponseUsage(model, credentials, normalizedTokenUsage.promptTokens, normalizedTokenUsage.completionTokens, startedAt, normalizedTokenUsage, _extends({}, pricingContext, {
                inputTokensIncludeCache: true
            })), normalizedTokenUsage, type ? {
                type
            } : {});
            const reportedPrice = output ? pricingOptions.resolveReportedPrice == null ? void 0 : pricingOptions.resolveReportedPrice.call(pricingOptions, output) : undefined;
            if (reportedPrice) {
                usage = applyProviderReportedPrice(usage, reportedPrice);
            } else if (pricingOptions.reportedPriceRequired) {
                usage = markUsagePriceUnpriced(usage, 'provider');
            }
            await handleLLMTokens({
                copilot,
                model,
                requestId,
                usage,
                tokenUsed: normalizedTokenUsage.totalTokens
            });
        };
        const callback = BaseCallbackHandler.fromMethods({
            handleLLMStart: (_llm, prompts, runId)=>{
                runs.set(runId, {
                    startedAt: performance.now(),
                    pricingTime: new Date(),
                    prompts,
                    completion: ''
                });
            },
            handleLLMNewToken: (token, _idx, runId, _parentRunId, _tags, fields)=>{
                const run = runs.get(runId);
                if (run) {
                    run.completion += token + readToolCallChunkText(fields == null ? void 0 : fields.chunk);
                }
            },
            handleLLMEnd: async (output, runId)=>{
                const run = runs.get(runId);
                runs.delete(runId);
                const resolved = resolveTokenUsageWithAuthority(output);
                if (resolved.usage.totalTokens > 0) {
                    var _run_startedAt, _run_pricingTime;
                    await reportUsage(runId, resolved.usage, (_run_startedAt = run == null ? void 0 : run.startedAt) != null ? _run_startedAt : performance.now(), (_run_pricingTime = run == null ? void 0 : run.pricingTime) != null ? _run_pricingTime : new Date(), resolved.type, output);
                } else {
                    var _run_startedAt1, _run_pricingTime1;
                    await reportUsage(runId, estimateFallbackUsage(run == null ? void 0 : run.prompts, (run == null ? void 0 : run.completion) || readCompletionText(output)), (_run_startedAt1 = run == null ? void 0 : run.startedAt) != null ? _run_startedAt1 : performance.now(), (_run_pricingTime1 = run == null ? void 0 : run.pricingTime) != null ? _run_pricingTime1 : new Date(), 'estimated', output);
                }
            },
            handleLLMError: async (error, runId)=>{
                const run = runs.get(runId);
                runs.delete(runId);
                if (!(run == null ? void 0 : run.completion) && !isAbortError(error)) {
                    return;
                }
                var _run_startedAt, _run_pricingTime;
                await reportUsage(runId, estimateFallbackUsage(run == null ? void 0 : run.prompts, run == null ? void 0 : run.completion), (_run_startedAt = run == null ? void 0 : run.startedAt) != null ? _run_startedAt : performance.now(), (_run_pricingTime = run == null ? void 0 : run.pricingTime) != null ? _run_pricingTime : new Date(), 'estimated');
            }
        });
        callback.awaitHandlers = true;
        callback.raiseError = true;
        return [
            callback
        ];
    }
    createHandleLLMErrorCallbacks(_fields, logger) {
        return {
            handleLLMError: (error)=>{
                // Provider errors and constructor fields can contain credentials or request bodies.
                const errorType = error instanceof Error && /^[A-Za-z]{1,60}$/.test(error.name) ? error.name : 'Error';
                (logger != null ? logger : _class_private_field_loose_base(this, _logger)[_logger]).error({
                    event: 'model_provider_request_failed',
                    errorType
                });
            }
        };
    }
    getCustomizableModelSchemaFromCredentials(model, credentials) {
        var _credentials_ModelPropertyKey_CONTEXT_SIZE, _credentials_input_price, _credentials_output_price, _credentials_unit, _credentials_currency;
        return {
            model,
            label: {
                zh_Hans: model,
                en_US: model
            },
            model_type: AiModelTypeEnum.LLM,
            fetch_from: FetchFrom.CUSTOMIZABLE_MODEL,
            model_properties: {
                [ModelPropertyKey.MODE]: credentials[ModelPropertyKey.MODE],
                [ModelPropertyKey.CONTEXT_SIZE]: parseInt((_credentials_ModelPropertyKey_CONTEXT_SIZE = credentials[ModelPropertyKey.CONTEXT_SIZE]) != null ? _credentials_ModelPropertyKey_CONTEXT_SIZE : 4096)
            },
            parameter_rules: [
                {
                    name: 'streaming',
                    type: ParameterType.BOOLEAN,
                    label: {
                        zh_Hans: '是否流式传输结果',
                        en_US: 'Whether to stream the results or not'
                    },
                    default: true
                },
                {
                    name: 'temperature',
                    type: ParameterType.FLOAT,
                    label: {
                        zh_Hans: '取样温度',
                        en_US: 'Sampling temperature'
                    },
                    min: 0,
                    max: 2
                }
            ],
            pricing: {
                input: (_credentials_input_price = credentials['input_price']) != null ? _credentials_input_price : 0,
                output: (_credentials_output_price = credentials['output_price']) != null ? _credentials_output_price : 0,
                unit: (_credentials_unit = credentials['unit']) != null ? _credentials_unit : 0,
                currency: (_credentials_currency = credentials['currency']) != null ? _credentials_currency : 'USD'
            }
        };
    }
    createHandleVerboseCallbacks(enabled, logger) {
        if (!enabled) {
            return [];
        }
        const targetLogger = logger != null ? logger : _class_private_field_loose_base(this, _logger)[_logger];
        return [
            {
                handleChatModelStart: (llm, messages, runId, parentRunId, extraParams, tags, metadata, runName)=>{
                    targetLogger.verbose(this.formatVerboseLog('chat_model/start', {
                        runId,
                        parentRunId,
                        runName,
                        model: llm,
                        messages,
                        extraParams,
                        tags,
                        metadata
                    }));
                },
                handleLLMStart: (llm, prompts, runId, parentRunId, extraParams, tags, metadata, runName)=>{
                    targetLogger.verbose(this.formatVerboseLog('llm/start', {
                        runId,
                        parentRunId,
                        runName,
                        model: llm,
                        prompts,
                        extraParams,
                        tags,
                        metadata
                    }));
                },
                handleLLMEnd: (output, runId, parentRunId, tags, extraParams)=>{
                    targetLogger.verbose(this.formatVerboseLog('llm/end', {
                        runId,
                        parentRunId,
                        output,
                        tags,
                        extraParams
                    }));
                },
                handleLLMError: (err, runId, parentRunId, tags, extraParams)=>{
                    targetLogger.verbose(this.formatVerboseLog('llm/error', {
                        runId,
                        parentRunId,
                        error: this.formatError(err),
                        tags,
                        extraParams
                    }));
                }
            }
        ];
    }
    formatVerboseLog(event, payload) {
        return `[langchain][${event}] ${this.stringifyLogPayload(payload)}`;
    }
    stringifyLogPayload(payload) {
        try {
            return JSON.stringify(payload, null, 2);
        } catch (error) {
            return `[unserializable payload: ${this.formatError(error)}]`;
        }
    }
    formatError(error) {
        if (error instanceof Error) {
            return {
                name: error.name,
                message: error.message,
                stack: error.stack
            };
        }
        return error;
    }
    constructor(...args){
        super(...args);
        Object.defineProperty(this, _logger, {
            writable: true,
            value: void 0
        });
        _class_private_field_loose_base(this, _logger)[_logger] = new Logger(_a.name);
    }
}
_a = LargeLanguageModel;
function normalizeUsagePricingOptions(configuration) {
    if ('context' in configuration || 'resolveContext' in configuration || 'resolveReportedPrice' in configuration || 'reportedPriceRequired' in configuration) {
        return configuration;
    }
    return {
        context: configuration
    };
}
function applyProviderReportedPrice(usage, reportedPrice) {
    var _reportedPrice_currency;
    const amount = Number(reportedPrice.amount);
    const currency = (_reportedPrice_currency = reportedPrice.currency) == null ? void 0 : _reportedPrice_currency.trim();
    if (!Number.isFinite(amount) || amount < 0 || !currency) {
        throw new Error('Provider-reported price requires a non-negative amount and currency');
    }
    return _extends({}, usage, {
        totalPrice: amount,
        currency: currency.toUpperCase(),
        pricingStatus: amount === 0 ? 'free' : 'priced',
        priceAuthority: 'provider',
        pricingBreakdown: undefined
    });
}
function markUsagePriceUnpriced(usage, priceAuthority) {
    return _extends({}, usage, {
        totalPrice: 0,
        pricingStatus: 'unpriced',
        priceAuthority,
        pricingBreakdown: undefined
    });
}
function estimateFallbackUsage(prompts, completion) {
    if (!prompts) {
        return {
            promptTokens: 0,
            completionTokens: 0,
            totalTokens: 0
        };
    }
    const promptTokens = estimateTokens$1(prompts.join('\n'));
    const completionTokens = estimateTokens$1(completion != null ? completion : '');
    return {
        promptTokens,
        completionTokens,
        totalTokens: promptTokens + completionTokens
    };
}
function readCompletionText(output) {
    var _output_generations;
    return (_output_generations = output.generations) == null ? void 0 : _output_generations.flat().map((generation)=>generation.text).filter(Boolean).join('\n');
}
function estimateTokens$1(text) {
    const estimatedText = text.replace(/data:image\/[a-zA-Z0-9.+-]+;base64,[a-zA-Z0-9+/_=-]+/g, '[image]');
    let cjkCharacters = 0;
    let otherCharacters = 0;
    for (const character of estimatedText){
        if (RegExp("\\p{Script=Han}", "u").test(character)) {
            cjkCharacters++;
        } else {
            otherCharacters++;
        }
    }
    return Math.ceil(cjkCharacters / 1.5 + otherCharacters / 4);
}
function readToolCallChunkText(chunk) {
    if (!(chunk instanceof ChatGenerationChunk) || !isAIMessageChunk(chunk.message)) {
        return '';
    }
    var _chunk_message_tool_call_chunks;
    return ((_chunk_message_tool_call_chunks = chunk.message.tool_call_chunks) != null ? _chunk_message_tool_call_chunks : []).map((toolCall)=>{
        var _toolCall_name, _toolCall_args;
        return `${(_toolCall_name = toolCall.name) != null ? _toolCall_name : ''}${(_toolCall_args = toolCall.args) != null ? _toolCall_args : ''}`;
    }).join('');
}
function isAbortError(error) {
    if (!(error instanceof Error)) {
        return false;
    }
    return error.name === 'AbortError' || /\babort(?:ed)?\b/i.test(error.message);
}
function calcTokenUsage(output) {
    const result = {
        promptTokens: 0,
        completionTokens: 0,
        totalTokens: 0
    };
    var _output_generations;
    for (const choices of (_output_generations = output.generations) != null ? _output_generations : []){
        // Each inner array contains choices from one request, not independent provider attempts.
        const usage = choices.map((choice)=>{
            var _metadata_input_token_details, _metadata_input_token_details1, _metadata_output_token_details;
            if (!('message' in choice) || !isBaseMessage(choice.message) || !isAIMessage(choice.message)) return null;
            const metadata = choice.message.usage_metadata;
            return metadata ? normalizeTokenUsage({
                promptTokens: metadata.input_tokens,
                completionTokens: metadata.output_tokens,
                totalTokens: metadata.total_tokens,
                cacheReadInputTokens: (_metadata_input_token_details = metadata.input_token_details) == null ? void 0 : _metadata_input_token_details.cache_read,
                cacheWriteInputTokens: (_metadata_input_token_details1 = metadata.input_token_details) == null ? void 0 : _metadata_input_token_details1.cache_creation,
                reasoningTokens: (_metadata_output_token_details = metadata.output_token_details) == null ? void 0 : _metadata_output_token_details.reasoning
            }) : null;
        }).find((candidate)=>candidate !== null);
        if (!usage) continue;
        result.promptTokens += usage.promptTokens;
        result.completionTokens += usage.completionTokens;
        result.totalTokens += usage.totalTokens;
        for (const key of [
            'cacheReadInputTokens',
            'cacheWriteInputTokens',
            'reasoningTokens'
        ]){
            var _result_key;
            if (usage[key] !== undefined) result[key] = ((_result_key = result[key]) != null ? _result_key : 0) + usage[key];
        }
    }
    return result;
}
function resolveTokenUsage(output) {
    return resolveTokenUsageWithAuthority(output).usage;
}
function resolveTokenUsageWithAuthority(output) {
    var _output_llmOutput, _output_llmOutput1, _output_llmOutput2;
    const resolved = resolveTokenUsageCandidates({
        canonical: calcTokenUsage(output),
        actual: (_output_llmOutput = output.llmOutput) == null ? void 0 : _output_llmOutput['tokenUsage'],
        estimated: (_output_llmOutput1 = output.llmOutput) == null ? void 0 : _output_llmOutput1['estimatedTokenUsage'],
        legacyTotal: (_output_llmOutput2 = output.llmOutput) == null ? void 0 : _output_llmOutput2['totalTokens']
    });
    return _extends({
        usage: resolved.usage
    }, resolved.source === 'estimated' ? {
        type: 'estimated'
    } : {});
}
function normalizeCacheTokenAccounting(tokenUsage, context) {
    if (context.inputTokensIncludeCache !== false) return tokenUsage;
    var _tokenUsage_cacheReadInputTokens, _tokenUsage_cacheWriteInputTokens;
    const cacheTokens = ((_tokenUsage_cacheReadInputTokens = tokenUsage.cacheReadInputTokens) != null ? _tokenUsage_cacheReadInputTokens : 0) + ((_tokenUsage_cacheWriteInputTokens = tokenUsage.cacheWriteInputTokens) != null ? _tokenUsage_cacheWriteInputTokens : 0);
    if (!cacheTokens) return tokenUsage;
    return _extends({}, tokenUsage, {
        promptTokens: tokenUsage.promptTokens + cacheTokens,
        totalTokens: tokenUsage.totalTokens + cacheTokens
    });
}
/**
 * @deprecated use calcTokenUsage
 */ function sumTokenUsage(output) {
    var _output_generations;
    let tokenUsed = 0;
    (_output_generations = output.generations) == null ? void 0 : _output_generations.forEach((generation)=>{
        generation.forEach((item)=>{
            const message = item.message;
            if (message.usage_metadata) {
                tokenUsed += message.usage_metadata.total_tokens;
            }
        });
    });
    return tokenUsed;
}

/**
 * Runs one asynchronous provider request inside a Managed Queue job.
 * Provider acceptance, terminal usage reporting, and result delivery are checkpointed so a queue retry resumes
 * from the last durable provider request instead of intentionally submitting a second request.
 */ async function processAsyncAIGCManagedJob(job, options) {
    let payload = job.data;
    if (payload.phase === 'succeeded' && payload.result !== undefined) return payload.result;
    if (payload.phase === 'failed') throw new Error(payload.errorCode || 'Provider generation task failed');
    if (!payload.modelAccess && options.provider.resolveModelAccess) {
        const modelAccess = await options.provider.resolveModelAccess({
            requestId: payload.requestId,
            model: payload.model,
            operation: payload.operation,
            modality: payload.modality,
            pricingDimensions: payload.pricingDimensions,
            startedAt: payload.startedAt
        });
        payload = await checkpoint(job, _extends({}, payload, {
            modelAccess
        }));
    }
    if (!payload.pricingSnapshot) {
        const pricingSnapshot = options.provider.resolvePricingSnapshot ? await options.provider.resolvePricingSnapshot({
            model: payload.model,
            operation: payload.operation,
            modality: payload.modality,
            pricingDimensions: payload.pricingDimensions,
            startedAt: payload.startedAt
        }) : {
            capturedAt: new Date().toISOString(),
            rules: []
        };
        payload = await checkpoint(job, _extends({}, payload, {
            pricingSnapshot
        }));
    }
    if (!payload.providerRequestId) {
        const submission = await options.client.submit(payload.input);
        payload = await checkpoint(job, _extends({}, payload, {
            providerRequestId: submission.providerRequestId,
            phase: 'submitted',
            providerState: 'submitted'
        }));
    }
    const providerRequestId = payload.providerRequestId;
    var _options_sleep;
    const sleep = (_options_sleep = options.sleep) != null ? _options_sleep : delay;
    const pollIntervalMs = normalizePollInterval(options.pollIntervalMs);
    while(true){
        const query = await options.client.query(providerRequestId, {
            operation: payload.operation,
            pricingDimensions: payload.pricingDimensions
        });
        const observation = query.observation;
        payload = await checkpoint(job, _extends({}, payload, {
            providerState: observation.state,
            phase: toJobPhase(observation.state)
        }, observation.errorCode ? {
            errorCode: observation.errorCode
        } : {}));
        if (observation.state === 'succeeded') {
            payload = await reportTerminalUsage(job, payload, observation.metrics, options.provider);
            const result = await options.finalize(query.data);
            payload = await checkpoint(job, _extends({}, payload, {
                phase: 'succeeded',
                result
            }));
            return result;
        }
        if (observation.state === 'failed' || observation.state === 'cancelled') {
            payload = await reportTerminalUsage(job, payload, observation.metrics, options.provider);
            var _options_failureMessage, _ref;
            const message = (_ref = (_options_failureMessage = options.failureMessage == null ? void 0 : options.failureMessage.call(options, query.data, observation)) != null ? _options_failureMessage : observation.errorCode) != null ? _ref : `Provider generation task ${providerRequestId} ${observation.state}`;
            await checkpoint(job, _extends({}, payload, {
                phase: 'failed',
                errorCode: message
            }));
            throw new Error(message);
        }
        await sleep(pollIntervalMs);
    }
}
async function reportTerminalUsage(job, payload, metrics, provider) {
    if (payload.usageReported || !(metrics == null ? void 0 : metrics.length)) return payload;
    await provider.reportUsage({
        requestId: payload.requestId,
        model: payload.model,
        modelType: payload.modality === 'image' ? AiModelTypeEnum.IMAGE : AiModelTypeEnum.VIDEO,
        toolName: payload.toolName,
        operation: payload.operation,
        modality: payload.modality,
        pricingDimensions: payload.pricingDimensions,
        pricingSnapshot: payload.pricingSnapshot,
        metrics,
        recordedAt: new Date().toISOString()
    }, payload.modelAccess);
    return checkpoint(job, _extends({}, payload, {
        usageReported: true
    }));
}
async function checkpoint(job, payload) {
    await job.updateData(payload);
    return payload;
}
function toJobPhase(state) {
    if (state === 'succeeded') return 'succeeded';
    if (state === 'failed' || state === 'cancelled') return 'failed';
    return state === 'submitted' ? 'submitted' : 'processing';
}
function normalizePollInterval(value) {
    return Number.isFinite(value) && Number(value) > 0 ? Math.trunc(Number(value)) : 5000;
}
function delay(milliseconds) {
    return new Promise((resolve)=>setTimeout(resolve, milliseconds));
}

/**
 * A model extended from ChatOpenAICompletions, compatible with OpenAI-style chat completions,
 * and supports structuring content within `<think>` reasoning tags into the `reasoning_content` field.
 *
 * This class overrides the `_convertCompletionsDeltaToBaseMessageChunk` method to detect `<think>` and `</think>` tags in the completion stream:
 * - When `<think>` is encountered, it enters reasoning content collection mode. Subsequent content is collected into the `reasoning_content` field and does not appear in the main `content` field.
 * - When `</think>` is encountered, reasoning content collection ends.
 * - In other cases, the `reasoning_content` field is directly assigned from the `reasoning_content` in the delta.
 *
 * In this way, the reasoning process in the model output can be separated from the main content, making it easier for subsequent structured processing and display.
 */ class ChatOAICompatReasoningModel extends ChatOpenAICompletions {
    /**
     *
     */ _convertCompletionsDeltaToBaseMessageChunk(// eslint-disable-next-line @typescript-eslint/no-explicit-any
    delta, rawResponse, defaultRole) {
        // Some OpenAI-compatible providers omit `delta.role` on the final usage
        // chunk. Without a role, LangChain creates a generic ChatMessageChunk;
        // persisting that chunk makes the next request contain `role: undefined`.
        // Treat role-less completion deltas as assistant output so they remain
        // valid both in the current stream and when the conversation is resumed.
        const messageChunk = super._convertCompletionsDeltaToBaseMessageChunk(delta, rawResponse, defaultRole != null ? defaultRole : 'assistant');
        if (delta['content'] === '<think>') {
            this.thinking = true;
            messageChunk.content = '';
        } else if (delta['content'] === '</think>') {
            this.thinking = false;
            messageChunk.content = '';
        } else if (this.thinking) {
            messageChunk.additional_kwargs['reasoning_content'] = messageChunk.content;
            messageChunk.content = '';
        } else {
            messageChunk.additional_kwargs['reasoning_content'] = delta['reasoning_content'];
        }
        return messageChunk;
    }
    _convertCompletionsMessageToBaseMessage(message, rawResponse) {
        var _message_role;
        // Some compatible providers also omit the role on non-stream responses.
        // Normalize that response before LangChain falls back to a generic
        // message with role `unknown`.
        const normalizedMessage = _extends({}, message, {
            role: (_message_role = message.role) != null ? _message_role : 'assistant'
        });
        const langChainMessage = super._convertCompletionsMessageToBaseMessage(normalizedMessage, rawResponse);
        console.log(langChainMessage.content);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if (message.reasoning_content) {
            langChainMessage.additional_kwargs['reasoning_content'] = message.reasoning_content;
        } else if (typeof langChainMessage.content === 'string') {
            const match = langChainMessage.content.match(/<think>([\s\S]*?)<\/think>/);
            if (match) {
                langChainMessage.additional_kwargs['reasoning_content'] = match[1];
                langChainMessage.content = langChainMessage.content.replace(match[0], '');
            }
        }
        return langChainMessage;
    }
    constructor(...args){
        super(...args);
        this.thinking = false;
    }
}

class OpenAICompatibleReranker {
    async rerank(docs, query, options) {
        const { model, topN, scoreThreshold } = options;
        const { apiKey, endpointModelName } = this.credentials;
        let endpointUrl = this.credentials.endpointUrl;
        if (!endpointUrl) throw new Error('Missing credentials.endpointUrl');
        if (docs.length === 0) return [];
        if (!endpointUrl.endsWith('/')) {
            endpointUrl += '/';
        }
        const url = new URL('rerank', endpointUrl).toString();
        const headers = {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
        };
        var _options_returnDocuments;
        const payload = {
            model: endpointModelName != null ? endpointModelName : model,
            query,
            documents: docs.map((d)=>d.pageContent),
            top_n: topN != null ? topN : docs.length,
            return_documents: (_options_returnDocuments = options.returnDocuments) != null ? _options_returnDocuments : false
        };
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers,
                body: JSON.stringify(payload),
                timeout: 60000
            });
            if (!response.ok) {
                throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
            }
            const results = await response.json();
            var _results_results;
            const output = (_results_results = results.results) != null ? _results_results : [];
            if (!Array.isArray(output)) {
                throw new Error('Invalid response format: missing results array');
            }
            const reranked = output.map((r)=>{
                const index = r.index;
                const result = {
                    index,
                    relevanceScore: r.relevance_score
                };
                if (options.returnDocuments) {
                    var _r_document, _docs_index, _docs_index1;
                    var _r_document_text, _ref, _docs_index_metadata;
                    result.document = new Document({
                        pageContent: typeof r.document === 'string' ? r.document : (_ref = (_r_document_text = (_r_document = r.document) == null ? void 0 : _r_document.text) != null ? _r_document_text : (_docs_index = docs[index]) == null ? void 0 : _docs_index.pageContent) != null ? _ref : '',
                        metadata: (_docs_index_metadata = (_docs_index1 = docs[index]) == null ? void 0 : _docs_index1.metadata) != null ? _docs_index_metadata : {}
                    });
                }
                return result;
            }).filter((r)=>scoreThreshold == null || r.relevanceScore >= scoreThreshold).sort((a, b)=>b.relevanceScore - a.relevanceScore).slice(0, topN != null ? topN : docs.length);
            return reranked;
        } catch (err) {
            throw new Error(`Rerank request failed: ${err.message}`);
        }
    }
    constructor(credentials){
        this.credentials = credentials;
    }
}

class Speech2TextChatModel extends BaseChatModel {
    _llmType() {
        return 'tongyi-speech2text';
    }
    async _generate(messages, options, runManager) {
        const humanMessage = messages[messages.length - 1];
        humanMessage.content.map((_)=>_.url);
        return {
            generations: [].map((content)=>({
                    text: content,
                    message: new AIMessage({
                        content
                    })
                }))
        };
    }
    constructor(fields){
        const apiKey = (fields == null ? void 0 : fields.apiKey) || getEnvironmentVariable('DASHSCOPE_API_KEY');
        if (!apiKey) {
            throw new Error(`Tongyi API key not found. Please set the DASHSCOPE_API_KEY environment variable or pass the key into "apiKey" field.`);
        }
        super(_extends({}, fields));
        this.fields = fields;
        this.apiKey = apiKey;
    }
}

/** OpenAI-compatible embeddings with authoritative, per-request usage callbacks. */ class OpenAICompatibleEmbeddings extends OpenAIEmbeddings {
    async embeddingWithRetry(request) {
        var _this_usageCallbacks, _this_usageCallbacks_resolveUsagePricingSnapshot, _this_usageCallbacks1, _response_usage, _response_usage1;
        const requestId = randomUUID();
        const context = {
            model: request.model,
            modelType: AiModelTypeEnum.TEXT_EMBEDDING,
            operation: AiModelTypeEnum.TEXT_EMBEDDING,
            modality: 'text',
            startedAt: new Date().toISOString()
        };
        const reportUsage = (_this_usageCallbacks = this.usageCallbacks) == null ? void 0 : _this_usageCallbacks.handleModelUsage;
        const pricingSnapshot = reportUsage ? await ((_this_usageCallbacks1 = this.usageCallbacks) == null ? void 0 : (_this_usageCallbacks_resolveUsagePricingSnapshot = _this_usageCallbacks1.resolveUsagePricingSnapshot) == null ? void 0 : _this_usageCallbacks_resolveUsagePricingSnapshot.call(_this_usageCallbacks1, context)) : undefined;
        const response = await super.embeddingWithRetry(request);
        const usage = normalizeTokenUsage({
            promptTokens: (_response_usage = response.usage) == null ? void 0 : _response_usage.prompt_tokens,
            completionTokens: 0,
            totalTokens: (_response_usage1 = response.usage) == null ? void 0 : _response_usage1.total_tokens
        });
        // Stay outside the transport retry loop: accounting failure must not repeat a billable request.
        if (usage && reportUsage) {
            await reportUsage(_extends({}, context, {
                requestId,
                pricingSnapshot,
                recordedAt: new Date().toISOString(),
                metrics: [
                    _extends({
                        unit: 'token',
                        authority: 'provider'
                    }, usage)
                ]
            }));
        }
        return response;
    }
    constructor(input, usageCallbacks){
        super(input);
        this.usageCallbacks = usageCallbacks;
    }
}

const encodingCache = new Map();
/** Exact, model-independent text count for hard chunk limits. Treat special-token spellings as literal document text. */ function textEncoding() {
    const cacheKey = 'encoding:cl100k_base';
    let encoder = encodingCache.get(cacheKey);
    if (!encoder) {
        encoder = getEncoding('cl100k_base');
        encodingCache.set(cacheKey, encoder);
    }
    return encoder;
}
function countTextTokens(text) {
    if (!text) return 0;
    // A hard limit must fail if tokenization fails, never fall back to an estimate.
    return textEncoding().encode(text, [], []).length;
}
/** Token boundaries that also end on complete Unicode characters, in UTF-16 source offsets. */ function textTokenBoundaries(text) {
    const encoder = textEncoding();
    const tokens = encoder.encode(text, [], []);
    const boundaries = [
        {
            offset: 0,
            tokens: 0
        }
    ];
    let offset = 0;
    let start = 0;
    for(let end = 1; end <= tokens.length; end++){
        const decoded = encoder.decode(tokens.slice(start, end));
        if (!decoded || !text.startsWith(decoded, offset)) continue;
        offset += decoded.length;
        boundaries.push({
            offset,
            tokens: end
        });
        start = end;
    }
    if (offset !== text.length) throw new Error('Tokenization could not preserve the source text.');
    return boundaries;
}
/**
 * Fallback token estimation method.
 *
 * 思路:
 * - 英文：约 4 chars / token
 * - 中文：约 1.5 chars / token
 * - Mixed：按字符区分
 */ function estimateTokens(text) {
    if (!text) return 0;
    let cn = 0;
    let en = 0;
    for (const ch of text){
        if (/[\u4e00-\u9fa5]/.test(ch)) {
            cn++;
        } else {
            en++;
        }
    }
    // 中文 1 token ≈ 1.5 chars
    const cnTokens = cn / 1.5;
    // 英文 1 token ≈ 4 chars
    const enTokens = en / 4;
    return Math.ceil(cnTokens + enTokens);
}
/**
 * Count tokens in text
 * 1) Preferred: js-tiktoken precise encoding
 * 2) Fallback: estimated token count
 */ function countTokensSafe(text, opts) {
    if (!text) return 0;
    try {
        let resolvedEncoding;
        if (opts == null ? void 0 : opts.encodingName) {
            resolvedEncoding = String(opts.encodingName);
        } else if (opts == null ? void 0 : opts.model) {
            var _getEncodingNameForModel;
            resolvedEncoding = (_getEncodingNameForModel = getEncodingNameForModel(opts.model)) != null ? _getEncodingNameForModel : 'cl100k_base';
        } else {
            resolvedEncoding = 'cl100k_base';
        }
        // Prefer exact token count via js-tiktoken
        const cacheKey = (opts == null ? void 0 : opts.model) ? `model:${opts.model}` : `encoding:${resolvedEncoding}`;
        let enc = encodingCache.get(cacheKey);
        if (!enc) {
            enc = (opts == null ? void 0 : opts.model) ? encodingForModel(opts.model) : getEncoding(resolvedEncoding);
            encodingCache.set(cacheKey, enc);
        }
        const tokens = enc.encode(text);
        return tokens.length;
    } catch (e) {
        // Provider-specific model names are not always known by js-tiktoken.
        return estimateTokens(text);
    }
}

function getModelContextSize(input) {
    if (isCopilotModel(input)) {
        var _input_options;
        return normalizeContextSize((_input_options = input.options) == null ? void 0 : _input_options[ModelPropertyKey.CONTEXT_SIZE]);
    }
    return getClientContextSize(input);
}
/** Bind the effective window to the runtime configuration and client without guessing from model names. */ function applyModelContextSize(model, configuration) {
    var _configuration_options;
    const configuredLimit = normalizeContextSize((_configuration_options = configuration.options) == null ? void 0 : _configuration_options[ModelPropertyKey.CONTEXT_SIZE]);
    const providerLimit = getClientContextSize(model);
    const limits = [
        configuredLimit,
        providerLimit
    ].filter((value)=>value !== undefined);
    if (!limits.length) return model;
    const contextSize = Math.min(...limits);
    configuration.options = _extends({}, configuration.options, {
        [ModelPropertyKey.CONTEXT_SIZE]: contextSize
    });
    const metadata = 'metadata' in model && typeof model.metadata === 'object' && model.metadata !== null ? model.metadata : {};
    const legacyProfile = 'profile' in metadata && typeof metadata.profile === 'object' && metadata.profile !== null ? metadata.profile : {};
    const profile = 'profile' in model && typeof model.profile === 'object' && model.profile !== null ? model.profile : {};
    Object.assign(model, {
        metadata: _extends({}, metadata, {
            profile: _extends({}, legacyProfile, {
                maxInputTokens: contextSize
            })
        })
    });
    Object.defineProperty(model, 'profile', {
        configurable: true,
        enumerable: true,
        writable: true,
        value: _extends({}, legacyProfile, profile, {
            maxInputTokens: contextSize
        })
    });
    return model;
}
function getClientContextSize(model) {
    const metadata = 'metadata' in model ? model.metadata : undefined;
    const legacyProfile = metadata && typeof metadata === 'object' && 'profile' in metadata ? metadata.profile : undefined;
    const limits = [
        readProfileContextSize(legacyProfile),
        readProfileContextSize('profile' in model ? model.profile : undefined)
    ].filter((value)=>value !== undefined);
    return limits.length ? Math.min(...limits) : undefined;
}
function readProfileContextSize(profile) {
    return profile && typeof profile === 'object' && 'maxInputTokens' in profile ? normalizeContextSize(profile.maxInputTokens) : undefined;
}
function isCopilotModel(input) {
    return typeof input === 'object' && input !== null && !('invoke' in input);
}
function normalizeContextSize(value) {
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
        return Math.floor(value);
    }
    if (typeof value === 'string') {
        const parsed = Number.parseInt(value, 10);
        if (Number.isFinite(parsed) && parsed > 0) {
            return parsed;
        }
    }
    return undefined;
}

const COMMAND_METADATA$1 = '__command__';
/**
 * Get a Chat Model of copilot model and check it's token limitation, record the token usage
 *
 * @deprecated Prefer `IAgentMiddlewareContext.runtime.createModelClient(...)` in middleware and plugin code.
 */ class CreateModelClientCommand extends Command {
    constructor(copilotModel, options){
        super();
        this.copilotModel = copilotModel;
        this.options = options;
    }
}
CreateModelClientCommand.type = '[AI Model] Create Model Client';
Reflect.defineMetadata(COMMAND_METADATA$1, {
    id: CreateModelClientCommand.type
}, CreateModelClientCommand);

/** A single fetch is one billable attempt. No SDK retries or redirects to another credential origin. */ function nativeModelTransport(input) {
    const base = new URL(input.baseUrl);
    if (![
        'http:',
        'https:'
    ].includes(base.protocol) || base.username || base.password || base.search || base.hash) throw new Error('Invalid native model endpoint');
    const suffix = input.protocol === 'openai_responses' ? '/responses' : '/v1/messages';
    const url = `${base.href.replace(/\/$/, '')}${suffix}`;
    return (body, forwarded, signal)=>{
        const headers = new Headers({
            'content-type': 'application/json'
        });
        if (input.protocol === 'anthropic_messages') {
            headers.set('anthropic-version', '2023-06-01');
            for (const [name, value] of Object.entries(forwarded)){
                // Native Anthropic feature/version headers must survive protocol evolution.
                if (/^anthropic-[a-z0-9-]+$/.test(name)) headers.set(name, value);
            }
            headers.set('x-api-key', input.authorization);
        } else headers.set('authorization', input.authorization);
        var _input_fetch;
        return ((_input_fetch = input.fetch) != null ? _input_fetch : fetch)(url, {
            method: 'POST',
            headers,
            body: JSON.stringify(body),
            signal,
            redirect: 'error'
        });
    };
}

const modelListSchema = z$1.object({
    data: z$1.array(z$1.object({
        id: z$1.string().trim().min(1).max(512),
        active: z$1.boolean().optional(),
        name: z$1.string().optional(),
        model_type: z$1.string().optional()
    }))
});
/** OpenAI-compatible discovery transport and import suggestions, never runtime routing. */ async function discoverOpenAIModels(options) {
    var _options_fetchImpl, _options_path;
    const response = await ((_options_fetchImpl = options.fetchImpl) != null ? _options_fetchImpl : fetch)(`${options.baseUrl.replace(/\/+$/, '')}/${((_options_path = options.path) != null ? _options_path : 'models').replace(/^\/+/, '')}`, {
        method: 'GET',
        headers: {
            Authorization: options.authorization,
            Accept: 'application/json'
        },
        signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) throw new Error(`Model discovery returned HTTP ${response.status}`);
    const payload = modelListSchema.parse(await response.json());
    const models = new Map();
    for (const entry of payload.data){
        var _options_predefinedModels;
        if (entry.active === false || models.has(entry.id)) continue;
        const known = (_options_predefinedModels = options.predefinedModels) == null ? void 0 : _options_predefinedModels.find((model)=>model.model === entry.id);
        // Explicit unsupported types must not fall through to name-based guesses.
        if (entry.model_type && !isDiscoverableModelType(entry.model_type)) continue;
        if (known && !isDiscoverableModelType(known.model_type)) continue;
        var _entry_model_type, _ref;
        const modelType = (_ref = (_entry_model_type = entry.model_type) != null ? _entry_model_type : known == null ? void 0 : known.model_type) != null ? _ref : suggestModelType(entry.id);
        const typeSource = entry.model_type ? 'provider' : known ? 'catalog' : modelType ? 'name' : 'unknown';
        const supportedType = isDiscoverableModelType(modelType) ? modelType : null;
        models.set(entry.id, _extends({
            model: entry.id,
            label: entry.name || entry.id,
            modelType: supportedType,
            typeSource
        }, supportedType ? {
            configuration: configurationFromModel(supportedType, known)
        } : {}));
    }
    return [
        ...models.values()
    ];
}
function suggestModelType(name) {
    if (/(?:rerank|reranker)/i.test(name)) return AiModelTypeEnum.RERANK;
    if (/(?:embedding|embed)/i.test(name)) return AiModelTypeEnum.TEXT_EMBEDDING;
    // Unknown and opaque IDs stay unclassified, including unsupported image/audio/video models.
    if (/(?:image|vision-exp|video|tts|whisper|speech|audio|wan\d|seedance|seedream)/i.test(name)) return null;
    if (/(?:^|[\/_-])(?:gpt|qwen|deepseek|glm|kimi|llama|mistral|claude|minimax|gemini|chat|doubao)(?:[\d._/-]|$)/i.test(name)) {
        return AiModelTypeEnum.LLM;
    }
    return null;
}

const SKILL_SOURCE_PROVIDER = 'SKILL_SOURCE_PROVIDER';
const SkillSourceProviderStrategy = (provider)=>applyDecorators(SetMetadata(SKILL_SOURCE_PROVIDER, provider), SetMetadata(STRATEGY_META_KEY, SKILL_SOURCE_PROVIDER));

let SkillSourceProviderRegistry = class SkillSourceProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(SKILL_SOURCE_PROVIDER, discoveryService, reflector);
    }
};
SkillSourceProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], SkillSourceProviderRegistry);

const AGENT_MIDDLEWARE_STRATEGY = 'AGENT_MIDDLEWARE_STRATEGY';
const AgentMiddlewareStrategy = (provider)=>applyDecorators(SetMetadata(AGENT_MIDDLEWARE_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, AGENT_MIDDLEWARE_STRATEGY));

let AgentMiddlewareRegistry = class AgentMiddlewareRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(AGENT_MIDDLEWARE_STRATEGY, discoveryService, reflector);
    }
};
AgentMiddlewareRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], AgentMiddlewareRegistry);

/**
 * jump targets (user facing)
 */ const JUMP_TO_TARGETS = [
    'model',
    'tools',
    'end'
];

/** Scoped runtime capability for platform Assistant tasks. */ const AssistantTaskRuntimeCapability = createRuntimeCapability('platform.assistant_task', {
    description: 'Start asynchronous tasks on the current platform assistant.'
});

const FileRuntimeCapability = createRuntimeCapability('platform.file', {
    description: 'Resolve platform file handles into previewable file URLs.'
});

/** Credential audience check only; the host must still revalidate the human's live admin role and grant. */ function isExecutionObservationSession(principal, xpertId) {
    var _principal_resourceScope;
    return !principal || Boolean(xpertId && principal.principalType === 'client_secret' && principal.clientSecretBindingType === SecretTokenBindingType.USER_XPERT && principal.clientSecretId && ((_principal_resourceScope = principal.resourceScope) == null ? void 0 : _principal_resourceScope.kind) === 'assistant' && principal.resourceScope.xpertId === xpertId);
}
const ExecutionObservabilityRuntimeCapability = createRuntimeCapability('platform.execution_observability', {
    description: 'Administrator-only execution analytics within the host-bound tenant and organization.'
});

const XPERT_AGENT_MIDDLEWARE_RUNTIME_TOKEN = 'XPERT_AGENT_MIDDLEWARE_RUNTIME';

const MODEL_OUTPUT_VALIDATION_ERROR_CODE = 'MODEL_OUTPUT_VALIDATION_ERROR';
/**
 * Signals that the provider returned a model response which could not be
 * accepted, but can be regenerated safely because no tool was executed.
 *
 * Keep `repairContext` compact and free of raw tool arguments. Model
 * middleware may use it as retry-local feedback, so it must never contain
 * credentials, complete documents, or other unbounded model output.
 */ class ModelOutputValidationError extends Error {
    constructor(message, repairContext){
        super(message);
        this.code = MODEL_OUTPUT_VALIDATION_ERROR_CODE;
        this.retryable = true;
        this.repairContext = repairContext;
        this.name = 'ModelOutputValidationError';
    }
}
function isModelOutputValidationError(error) {
    var _candidate_repairContext;
    if (!error || typeof error !== 'object') return false;
    const candidate = error;
    return candidate.code === MODEL_OUTPUT_VALIDATION_ERROR_CODE && candidate.retryable === true && ((_candidate_repairContext = candidate.repairContext) == null ? void 0 : _candidate_repairContext.kind) === 'invalid_tool_calls' && Array.isArray(candidate.repairContext.issues);
}

/** Combine middleware contributions without mutating or weakening existing requirements. */ function mergeModelRequirements(...requirements) {
    const features = [
        ...new Set(requirements.flatMap((item)=>{
            var _item_features;
            return (_item_features = item == null ? void 0 : item.features) != null ? _item_features : [];
        }))
    ];
    return features.length ? {
        features
    } : undefined;
}

const SEGMENT_PATTERN = /^[a-z][a-z0-9_-]*$/i;
const VERSION_PATTERN = /^v[1-9][0-9]*$/;
function assertSegment(input, name) {
    if (!SEGMENT_PATTERN.test(input)) {
        throw new Error(`Invalid ${name} segment: "${input}"`);
    }
}
/**
 * Unified construction of channel message types to avoid manual string errors.
 * Example: channel.lark.inbound.v1
 */ function defineChannelMessageType(provider, action, version) {
    assertSegment(provider, 'provider');
    assertSegment(action, 'action');
    if (!Number.isInteger(version) || version <= 0) {
        throw new Error(`Invalid version: "${version}"`);
    }
    return `channel.${provider}.${action}.v${version}`;
}
/**
 * Unified construction of agent message types.
 * Example: agent.handoff.v1
 */ function defineAgentMessageType(action, version) {
    assertSegment(action, 'action');
    if (!Number.isInteger(version) || version <= 0) {
        throw new Error(`Invalid version: "${version}"`);
    }
    return `agent.${action}.v${version}`;
}
/**
 * Check if a type conforms to the structured naming convention (format only, no semantic validation).
 */ function isStructuredMessageType(type) {
    const parts = type.split('.');
    if (parts.length < 3) {
        return false;
    }
    const version = parts[parts.length - 1];
    if (!VERSION_PATTERN.test(version)) {
        return false;
    }
    return parts.slice(0, -1).every((part)=>SEGMENT_PATTERN.test(part));
}

const AGENT_CHAT_DISPATCH_MESSAGE_TYPE = defineAgentMessageType('chat_dispatch', 1);
const AGENT_CHAT_DISPATCH_ERROR_STEER_TARGET_NOT_RUNNING = 'steer_target_not_running';

/** Captured by an authorized host command. Describing a recipient never authorizes delivery. */ const replyConversation = {
    conversationId: z.string().uuid(),
    threadId: z.string().trim().min(1).max(256)
};
const agentRuntimeReplyTargetSchema = z.discriminatedUnion('type', [
    z.object(_extends({}, replyConversation, {
        type: z.literal('xpert').optional(),
        xpertId: z.string().uuid(),
        agentKey: z.string().trim().min(1).max(256)
    })).strict(),
    z.object(_extends({}, replyConversation, {
        type: z.literal('project_agent'),
        projectId: z.string().uuid(),
        agentKey: z.literal('general_agent')
    })).strict()
]);
/** Persist with the immutable invocation request before launch. No credentials or arbitrary routing headers. */ const agentInvocationDispatchContextSchema = z.object({
    version: z.literal(1),
    requestId: z.string().uuid(),
    sourceMessageId: z.string().trim().min(1).max(256),
    replyTo: agentRuntimeReplyTargetSchema,
    projectTask: projectTaskExecutionContextSchema.optional()
}).strict();

const AGENT_RUNTIME_EVENT_MESSAGE_TYPE = defineAgentMessageType('runtime_event', 1);
const reference = {
    version: z.literal(1),
    invocationId: z.string().uuid(),
    /** Revision of the persisted observation, never a queue delivery attempt. */ revision: z.number().int().nonnegative(),
    projectTask: projectTaskExecutionReferenceSchema.optional()
};
/** Host-produced references. Consumers reload and authorize the invocation and its pinned observation. */ const agentRuntimeEventSchema = z.discriminatedUnion('kind', [
    z.object(_extends({}, reference, {
        kind: z.literal('progress'),
        progress: agentRuntimeProgressSchema
    })).strict(),
    z.object(_extends({}, reference, {
        kind: z.literal('result'),
        status: agentInvocationTerminalStatusSchema
    })).strict(),
    z.object(_extends({}, reference, {
        kind: z.literal('input_request'),
        interactionId: z.string().trim().min(1).max(256)
    })).strict()
]);
/** Same observation always has the same HandoffMessage.id across retries and process restarts. */ function agentRuntimeEventMessageId(event) {
    return `runtime-${event.invocationId}-${event.kind}-${event.revision}`;
}
/** Transport states are deliberately separate from Task and Invocation status. */ const agentRuntimeDeliveryStateSchema = z.enum([
    'pending',
    'received',
    'blocked',
    'failed'
]);
const agentRuntimeConsumptionStateSchema = z.enum([
    'pending',
    'processing',
    'processed',
    'blocked',
    'failed'
]);
/** Store under a unique scoped key in the same transaction as the continuation reservation. */ const agentRuntimeResultClaimSchema = z.object({
    invocationId: z.string().uuid(),
    resultRevision: z.number().int().nonnegative(),
    recipient: agentRuntimeReplyTargetSchema,
    consumer: z.discriminatedUnion('type', [
        z.object({
            type: z.literal('follow_up'),
            executionId: z.string().uuid()
        }).strict(),
        z.object({
            type: z.literal('wait'),
            executionId: z.string().uuid(),
            callId: z.string().trim().min(1).max(1024)
        }).strict()
    ])
}).strict();
/**
 * Wait and asynchronous reply compete for this same key, regardless of delivery revision.
 * The storage key must additionally include tenant, organization and owner from trusted scope.
 */ function agentRuntimeResultConsumptionKey(invocationId, recipient) {
    return JSON.stringify([
        invocationId,
        recipient.conversationId,
        recipient.threadId,
        recipient.type === 'project_agent' ? `project:${recipient.projectId}` : recipient.xpertId,
        recipient.agentKey
    ]);
}

/**
 * Handoff Processor meta key。
 */ const HANDOFF_PROCESSOR_STRATEGY = 'HANDOFF_PROCESSOR_STRATEGY';
/**
 * Declare on a provider:
 * 1) Which message types it handles
 * 2) Default execution policy (lane/timeout)
 */ function HandoffProcessorStrategy(provider, metadata) {
    var _metadata_types;
    if (!(metadata == null ? void 0 : (_metadata_types = metadata.types) == null ? void 0 : _metadata_types.length)) {
        throw new Error('HandoffProcessor requires at least one message type');
    }
    return applyDecorators(SetMetadata(HANDOFF_PROCESSOR_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, HANDOFF_PROCESSOR_STRATEGY));
}

let HandoffProcessorRegistry = class HandoffProcessorRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(HANDOFF_PROCESSOR_STRATEGY, discoveryService, reflector);
    }
};
HandoffProcessorRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], HandoffProcessorRegistry);

/**
 * Handoff execution types.
 *
 * Note:
 * - Two-gate lane/session permit logic has been removed.
 * - Lane is now an execution tag for observability and soft policy only.
 */ const DEFAULT_EXECUTION_CONFIG = {
    lanes: {
        main: 8,
        subagent: 16,
        cron: 4,
        nested: 8
    },
    runTtlMs: 10 * 60 * 1000
};

/** Checks confirmed completion; unknown remains non-terminal. */ function isAgentInvocationTerminal(status) {
    return status === 'succeeded' || status === 'failed' || status === 'cancelled';
}

/** Nest discovery metadata key for runtime strategies. */ const AGENT_RUNTIME_STRATEGY = 'AGENT_RUNTIME_STRATEGY';
/** Associate a stable provider key with an adapter. Also declare @Injectable() and register the provider. */ const AgentRuntimeStrategy = (provider)=>applyDecorators(SetMetadata(AGENT_RUNTIME_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, AGENT_RUNTIME_STRATEGY));
/** Scoped strategy registry with pinned provider/version lookup for continuation. */ let AgentRuntimeRegistry = class AgentRuntimeRegistry extends BaseStrategyRegistry {
    /** Find the exact original scope/plugin/version, without fallback. Returns undefined if unavailable. */ getPinned(provider, source) {
        var _this_strategies_get;
        const strategy = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(provider);
        if (!strategy) return undefined;
        const actual = this.getSource(strategy);
        return actual.kind === source.kind && actual.scopeKey === source.scopeKey && (actual.kind !== 'plugin' || source.kind !== 'plugin' || actual.pluginName === source.pluginName && actual.pluginVersion === source.pluginVersion) ? strategy : undefined;
    }
    constructor(discoveryService, reflector){
        super(AGENT_RUNTIME_STRATEGY, discoveryService, reflector);
    }
};
AgentRuntimeRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], AgentRuntimeRegistry);

/** Caller-scoped API obtained through runtime.capabilities.require(...). */ const AgentInvocationRuntimeCapability = createRuntimeCapability('platform.agent_invocation', {
    description: 'Scoped, versioned Agent invocation and lifecycle control'
});
/** Platform factory capability. The wire key is stable across SDK naming changes. */ const AgentRuntimeFactoryCapability = createRuntimeCapability('platform.agent_invocation.factory');

/**
 * Keeps shared OS model authorization independent of Pro Computer/Docker lifecycle details.
 * Grant issuance, authentication, revalidation and renewal delegate environment checks to this host adapter.
 * Implementations validate ownership and instance identity so a replaced runtime cannot keep its old grant.
 * Execution validity is independent of desktop viewing sessions; managed runners may also require an operation lease.
 * Other environments can supply their own checks without changing the grant service.
 * This capability validates the bound environment; model selection and usage accounting remain separate concerns.
 */ const ModelExecutionEnvironmentCapability = createRuntimeCapability('platform.model_execution.environment');

/** Configuration adapters describe secrets by reference; only the host materializes credentials. */ const CLI_MODEL_TOKEN_REFERENCE = '${XPERT_EXECUTION_TOKEN}';
const CliModelProfilesCapability = createRuntimeCapability('platform.cli_model_profiles');
/** Additional execution sources can validate lifecycle without making OS depend on Pro entities. */ const ShellModelExecutionSourceCapability = createRuntimeCapability('platform.model_execution.shell_source');

function taskWaitReason(states, mode) {
    if (states.length && (mode === 'all' ? states.every((state)=>state === 'completed') : states.includes('completed'))) return 'completed';
    if (states.includes('attention')) return 'attention';
    return undefined;
}

const AgentExecutionRunnerCapability = createRuntimeCapability('platform.agent_execution.runner');
const AgentExecutionRunnerFactoryCapability = createRuntimeCapability('platform.agent_execution.runner.factory');

// Invariants: this payload has no runtime imports; protocol streams are not exit evidence.
// The device supervisor regression test enforces identical process supervision semantics.
const AGENT_PROCESS_SUPERVISOR = String.raw`
import ctypes, errno, json, os, signal, subprocess, sys, time
owner = int(sys.argv[1])
stopping = False
strong = False
if sys.platform.startswith('linux'):
    strong = ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0
def stop(*args):
    global stopping
    stopping = True
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
# The supervisor is the process-group leader. Its live PID reserves the group identity.
os.write(3, b'{"ready":true}\n')
try:
    if os.getppid() != owner: raise OSError('Original host exited before admission')
    child = subprocess.Popen(sys.argv[2:], close_fds=True)
except OSError:
    os.write(3, json.dumps({'version': 1, 'state': 'not_started', 'coverage': 'descendants', 'exitCode': 127}).encode())
    sys.exit(0)
# Only the protocol child owns stdin, so a closed transport still produces EPIPE.
os.close(0)
code = None
deadline = None
while True:
    if os.getppid() != owner: stopping = True
    if code is None:
        value = child.poll()
        if value is not None: code = value; stopping = True
    if stopping and deadline is None:
        deadline = time.monotonic() + 2
        os.killpg(os.getpgrp(), signal.SIGTERM)
    if deadline is not None and time.monotonic() >= deadline:
        if not strong:
            # No subreaper means escaped descendants cannot be certified. No receipt is emitted.
            os.killpg(os.getpgrp(), signal.SIGKILL)
        # Kill only still-waitable direct children. Orphans are adopted by this subreaper;
        # holding them until waitpid prevents PID reuse between selection and signalling.
        try:
            ids = open('/proc/self/task/' + str(os.getpid()) + '/children').read().split()
            for value in ids:
                try: os.kill(int(value), signal.SIGKILL)
                except ProcessLookupError: pass
        except OSError:
            os.killpg(os.getpgrp(), signal.SIGKILL)
    if stopping and strong:
        empty = False
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
                if pid == 0: break
                if pid == child.pid and code is None: code = os.waitstatus_to_exitcode(status)
            except ChildProcessError:
                empty = True
                break
        if empty:
            os.write(3, json.dumps({'version': 1, 'state': 'exited', 'coverage': 'descendants', 'exitCode': code}).encode())
            sys.exit(0)
    time.sleep(.02)
`;

/** Persisted host ownership marker. Only built-in presets are supported. */ const managedAgentRuntimeSchema = z.object({
    type: z.literal('builtin'),
    version: z.string().min(1)
}).strict();
/** Launch settings supplied by the installed strategy, never by tool input or host provider lists. */ const agentRuntimeDeploymentSpecSchema = z.discriminatedUnion('type', [
    z.object({
        type: z.literal('process'),
        command: z.string().min(1).refine((value)=>!value.includes('\0')),
        args: z.array(z.string().refine((value)=>!value.includes('\0'))),
        environment: z.record(z.string(), z.string()),
        model: z.string().min(1).optional(),
        timeoutMs: z.number().int().min(1000).max(3600000)
    }).strict(),
    z.object({
        type: z.literal('sdk'),
        environment: z.record(z.string(), z.string()),
        model: z.string().min(1).optional(),
        timeoutMs: z.number().int().min(1000).max(3600000)
    }).strict(),
    z.object({
        type: z.literal('service'),
        serverUrl: z.string().url().refine((value)=>{
            try {
                const url = new URL(value);
                return [
                    'http:',
                    'https:'
                ].includes(url.protocol) && !url.username && !url.password && !url.search && !url.hash;
            } catch (e) {
                return false;
            }
        }),
        authorization: z.string().optional(),
        timeoutMs: z.number().int().min(1000).max(3600000)
    }).strict()
]);
/** Used by SDK/process/service adapters. The host pins the target and rechecks access; no caller-selected scope. */ const AgentRuntimeDeploymentCapability = createRuntimeCapability('platform.agent_runtime.deployment');

/** Host-only provenance. This describes a saved operation; it never grants access by itself. */ const projectPipelineInvocationScopeSchema = z.object({
    tenantId: z.string().uuid(),
    organizationId: z.string().uuid(),
    userId: z.string().uuid(),
    projectId: z.string().uuid(),
    workspaceId: z.string().uuid(),
    callerType: z.literal('project_pipeline'),
    callerAgentKey: z.literal('pipeline_node'),
    parentExecutionId: z.string(),
    pipelineOrigin: projectPipelineWorkContextSchema
}).strict().superRefine((value, context)=>{
    if (value.parentExecutionId !== `pipeline-operation:${value.pipelineOrigin.operationId}`) context.addIssue({
        code: 'custom',
        message: 'PIPELINE_PARENT_IDENTITY_MISMATCH'
    });
});

/** Older runtime plugins can still send this event; new emissions use ON_CHAT_EVENT. */ const RESOURCE_CARD_EVENT = 'xpert.resource_card';

function middleware(node) {
    return node.type === 'workflow' && node.entity.type === WorkflowNodeTypeEnum.MIDDLEWARE;
}
function hasAssistantMiddleware(draft, provider, agentKey = (()=>{
    var _draft_team_agent;
    return (_draft_team_agent = draft.team.agent) == null ? void 0 : _draft_team_agent.key;
})()) {
    return draft.nodes.some((node)=>middleware(node) && node.entity.provider === provider && draft.connections.some((edge)=>edge.type === 'workflow' && edge.from === agentKey && edge.to.split('/')[0] === node.key));
}
/** Compose only the draft graph. The platform records the contribution for safe removal.
 * No Project, permission, external resource or implicit replacement is created here. */ function applyAssistantMiddleware(draft, input) {
    var _agent_entity_prompt;
    const agent = draft.nodes.find((node)=>{
        var _draft_team_agent;
        return node.type === 'agent' && node.key === ((_draft_team_agent = draft.team.agent) == null ? void 0 : _draft_team_agent.key);
    });
    if ((agent == null ? void 0 : agent.type) !== 'agent') throw new BadRequestException('assistant.invalid_draft');
    if (!hasAssistantMiddleware(draft, input.provider)) {
        var _agent_entity_options, _agent_entity_options_middlewares, _agent_entity_options1;
        let key = input.key;
        for(let suffix = 2; draft.nodes.some((node)=>node.key === key) || draft.connections.some((edge)=>edge.key === `${agent.key}/${key}`); suffix++)key = `${input.key}_${suffix}`;
        const entity = {
            id: key,
            key,
            type: WorkflowNodeTypeEnum.MIDDLEWARE,
            title: input.title,
            provider: input.provider,
            required: true,
            options: {}
        };
        draft.nodes.push({
            type: 'workflow',
            key,
            position: {
                x: 620,
                y: 160 * (draft.nodes.length - 1)
            },
            entity
        });
        draft.connections.push({
            key: `${agent.key}/${key}`,
            type: 'workflow',
            from: agent.key,
            to: key,
            required: true
        });
        var _agent_entity_options_middlewares_order;
        agent.entity.options = _extends({}, agent.entity.options, input.preserveToolConcurrency ? {} : {
            parallelToolCalls: false
        }, {
            middlewares: _extends({}, (_agent_entity_options = agent.entity.options) == null ? void 0 : _agent_entity_options.middlewares, {
                order: [
                    ...(_agent_entity_options_middlewares_order = (_agent_entity_options1 = agent.entity.options) == null ? void 0 : (_agent_entity_options_middlewares = _agent_entity_options1.middlewares) == null ? void 0 : _agent_entity_options_middlewares.order) != null ? _agent_entity_options_middlewares_order : [],
                    key
                ]
            })
        });
    }
    if (!((_agent_entity_prompt = agent.entity.prompt) == null ? void 0 : _agent_entity_prompt.includes(input.instructions))) agent.entity.prompt = [
        agent.entity.prompt,
        input.instructions
    ].filter(Boolean).join('\n\n');
}

const ASSISTANT_CAPABILITY_PROVIDER = 'ASSISTANT_CAPABILITY_PROVIDER';
const AssistantCapabilityProvider = (key)=>applyDecorators(SetMetadata(ASSISTANT_CAPABILITY_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, ASSISTANT_CAPABILITY_PROVIDER));
let AssistantCapabilityProviderRegistry = class AssistantCapabilityProviderRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(ASSISTANT_CAPABILITY_PROVIDER, discovery, reflector);
    }
};
AssistantCapabilityProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], AssistantCapabilityProviderRegistry);

/**
 * Common platform message length limits
 */ const CHAT_CHANNEL_TEXT_LIMITS = {
    lark: 4000,
    wecom: 2048,
    dingtalk: 4000,
    slack: 4000,
    telegram: 4096,
    discord: 2000
};
/**
 * Chunk long text by specified length
 *
 * @param text - Text to chunk
 * @param limit - Maximum characters per chunk
 * @param mode - Chunking mode: 'text' splits by character, 'markdown' tries to preserve paragraphs
 * @returns Array of chunked text
 */ function chunkText(text, limit, mode = 'text') {
    if (!text || text.length <= limit) {
        return [
            text
        ];
    }
    const chunks = [];
    if (mode === 'markdown') {
        // Markdown mode: try to split at paragraph boundaries
        const paragraphs = text.split(/\n\n+/);
        let currentChunk = '';
        for (const para of paragraphs){
            if (currentChunk.length + para.length + 2 <= limit) {
                currentChunk += (currentChunk ? '\n\n' : '') + para;
            } else if (para.length > limit) {
                // Paragraph itself is too long, need hard split
                if (currentChunk) {
                    chunks.push(currentChunk);
                    currentChunk = '';
                }
                let remaining = para;
                while(remaining.length > limit){
                    chunks.push(remaining.slice(0, limit));
                    remaining = remaining.slice(limit);
                }
                currentChunk = remaining;
            } else {
                if (currentChunk) {
                    chunks.push(currentChunk);
                }
                currentChunk = para;
            }
        }
        if (currentChunk) {
            chunks.push(currentChunk);
        }
    } else {
        // Plain text mode: split directly by length
        let remaining = text;
        while(remaining.length > limit){
            chunks.push(remaining.slice(0, limit));
            remaining = remaining.slice(limit);
        }
        if (remaining) {
            chunks.push(remaining);
        }
    }
    return chunks;
}

/**
 * Metadata key for chat channel
 */ const CHAT_CHANNEL = 'CHAT_CHANNEL';
/**
 * Decorator for chat channel implementations
 *
 * Use this decorator to register a chat channel implementation.
 * The decorated class will be automatically discovered and registered
 * to ChatChannelRegistry on module initialization.
 *
 * @param type - The channel type identifier (e.g., 'lark', 'wecom', 'dingtalk')
 *
 * @example
 * ```typescript
 * @Injectable()
 * @ChatChannel('lark')
 * export class LarkChatChannel implements IChatChannel {
 *   // Implementation
 * }
 * ```
 */ const ChatChannel = (type)=>SetMetadata(CHAT_CHANNEL, type);

/**
 * Chat Channel Registry
 *
 * Manages all registered chat channel implementations.
 * Channels are automatically discovered and registered via @ChatChannel decorator.
 *
 * Supports:
 * - Organization-scoped channels
 * - Global channels (fallback)
 * - Plugin-based registration/removal
 * - Dynamic channel lookup
 *
 * @example
 * ```typescript
 * // Get channel by type
 * const channel = registry.get('lark')
 *
 * // List all available channels for an organization
 * const channels = registry.list(organizationId)
 *
 * // Send message using a channel
 * await channel.sendText(ctx, 'Hello!')
 * ```
 */ let ChatChannelRegistry = class ChatChannelRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(CHAT_CHANNEL, discoveryService, reflector);
    }
};
ChatChannelRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ChatChannelRegistry);

const COMMAND_METADATA = '__command__';
class CancelConversationCommand {
    constructor(input){
        this.input = input;
    }
}
CancelConversationCommand.type = '[Chat Conversation] Cancel';
Reflect.defineMetadata(COMMAND_METADATA, {
    id: CancelConversationCommand.type
}, CancelConversationCommand);

const FILE_STORAGE_PROVIDER = 'FILE_STORAGE_PROVIDER';
const FileStorageProvider = (provider)=>applyDecorators(SetMetadata(FILE_STORAGE_PROVIDER, provider), SetMetadata(STRATEGY_META_KEY, FILE_STORAGE_PROVIDER));

let FileStorageProviderRegistry = class FileStorageProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(FILE_STORAGE_PROVIDER, discoveryService, reflector);
    }
};
FileStorageProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], FileStorageProviderRegistry);

const FILE_UPLOAD_TARGET_STRATEGY = 'FILE_UPLOAD_TARGET_STRATEGY';
const FileUploadTargetStrategy = (type)=>applyDecorators(SetMetadata(FILE_UPLOAD_TARGET_STRATEGY, type), SetMetadata(STRATEGY_META_KEY, FILE_UPLOAD_TARGET_STRATEGY));

let FileUploadTargetRegistry = class FileUploadTargetRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(FILE_UPLOAD_TARGET_STRATEGY, discoveryService, reflector);
    }
};
FileUploadTargetRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], FileUploadTargetRegistry);

const SSO_PROVIDER = 'SSO_PROVIDER';
const SSOProviderStrategyKey = (provider)=>applyDecorators(SetMetadata(SSO_PROVIDER, provider), SetMetadata(STRATEGY_META_KEY, SSO_PROVIDER));

let SSOProviderRegistry = class SSOProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(SSO_PROVIDER, discoveryService, reflector);
    }
};
SSOProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], SSOProviderRegistry);

const ConnectorRuntimeCapability = createRuntimeCapability('platform.connector', {
    description: 'Resolve connector credentials for agent middleware.'
});
const ConnectorRuntimeFactoryCapability = createRuntimeCapability('platform.connector.factory', {
    description: 'Create a connector API restricted to host-granted connectors and the authorized execution identity.'
});

const CONNECTOR_STRATEGY = 'CONNECTOR_STRATEGY';
const ConnectorStrategyKey = (provider)=>applyDecorators(SetMetadata(CONNECTOR_STRATEGY, provider), SetMetadata(STRATEGY_META_KEY, CONNECTOR_STRATEGY));

let ConnectorStrategyRegistry = class ConnectorStrategyRegistry extends BaseStrategyRegistry {
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        if (!target) {
            return;
        }
        const provider = this.reflector.get(CONNECTOR_STRATEGY, target);
        if (provider) {
            const definition = readConnectorDefinition(instance, target);
            if (definition === undefined) {
                throw new Error(`Connector strategy '${provider}' must expose a connector definition`);
            }
            assertConnectorDefinition(definition);
            if (definition.provider !== provider) {
                throw new Error(`Connector strategy '${provider}' definition declares provider '${definition.provider}'`);
            }
        }
        super.upsert(instance);
    }
    get(type, organizationId) {
        const strategy = super.get(type, organizationId);
        if (!isLegacyConnectorStrategy(strategy)) {
            throw new Error(`Connector strategy '${type}' does not implement the legacy OAuth contract`);
        }
        return strategy;
    }
    list(organizationId) {
        return super.list(organizationId).filter(isLegacyConnectorStrategy);
    }
    getRuntime(type, organizationId) {
        return super.get(type, organizationId);
    }
    listRuntime(organizationId) {
        return super.list(organizationId);
    }
    constructor(discoveryService, reflector){
        super(CONNECTOR_STRATEGY, discoveryService, reflector);
    }
};
ConnectorStrategyRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ConnectorStrategyRegistry);
function readConnectorDefinition(instance, target) {
    if (isStrategyInstance(instance)) {
        const definition = Reflect.get(instance, 'definition');
        if (definition !== undefined) {
            return definition;
        }
    }
    return Reflect.get(target, 'definition');
}
function isLegacyConnectorStrategy(strategy) {
    var _strategy_definition_auth;
    return 'auth' in strategy.definition && ((_strategy_definition_auth = strategy.definition.auth) == null ? void 0 : _strategy_definition_auth.type) === 'oauth2' && typeof strategy.buildAuthorizationUrl === 'function' && typeof strategy.exchangeOAuthCode === 'function';
}

const ConnectorDocumentsRuntimeCapability = createRuntimeCapability('platform.connector.documents', {
    description: 'Read authorized connector documents for explicit project imports; never exposes credentials or writes remote content.'
});

const SANDBOX_SHELL_TIMEOUT_LIMITS_SEC = {
    min: 1,
    max: 3600
};
const DEFAULT_SANDBOX_SHELL_TIMEOUT_SEC = 600;
const DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_SEC = 120;
const DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_SEC = 120;
const DEFAULT_SANDBOX_SHELL_TIMEOUT_MS = DEFAULT_SANDBOX_SHELL_TIMEOUT_SEC * 1000;
const DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_MS = DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_SEC * 1000;
const DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_MS = DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_SEC * 1000;
const DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES = 1024 * 1024;
const DEFAULT_SANDBOX_SHELL_EXECUTION_OPTIONS = {
    timeoutMs: DEFAULT_SANDBOX_SHELL_TIMEOUT_MS,
    maxOutputBytes: DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES
};
const DEFAULT_SANDBOX_FILE_SEARCH_EXECUTION_OPTIONS = {
    timeoutMs: DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_MS,
    maxOutputBytes: DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES
};
const DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS = {
    timeoutMs: DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_MS,
    maxOutputBytes: DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES
};
function secondsToMilliseconds(seconds) {
    return Math.trunc(seconds * 1000);
}
function formatSandboxTimeout(timeoutMs) {
    const timeoutSeconds = timeoutMs / 1000;
    const secondsLabel = Number.isInteger(timeoutSeconds) ? String(timeoutSeconds) : Number(timeoutSeconds.toFixed(3)).toString();
    return `${secondsLabel}s (${timeoutMs}ms)`;
}
function buildSandboxTimeoutMessage(subject, timeoutMs) {
    return `${subject} timed out after ${formatSandboxTimeout(timeoutMs)}`;
}
function appendSandboxMessage(output, message) {
    return output ? `${output}\n${message}` : message;
}
function resolveSandboxExecutionOptions(options, defaults = DEFAULT_SANDBOX_SHELL_EXECUTION_OPTIONS) {
    const timeoutMs = typeof (options == null ? void 0 : options.timeoutMs) === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0 ? Math.trunc(options.timeoutMs) : typeof defaults.timeoutMs === 'number' && Number.isFinite(defaults.timeoutMs) && defaults.timeoutMs > 0 ? Math.trunc(defaults.timeoutMs) : DEFAULT_SANDBOX_SHELL_TIMEOUT_MS;
    const maxOutputBytes = typeof (options == null ? void 0 : options.maxOutputBytes) === 'number' && Number.isFinite(options.maxOutputBytes) && options.maxOutputBytes > 0 ? Math.trunc(options.maxOutputBytes) : typeof defaults.maxOutputBytes === 'number' && Number.isFinite(defaults.maxOutputBytes) && defaults.maxOutputBytes > 0 ? Math.trunc(defaults.maxOutputBytes) : DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES;
    return _extends({
        timeoutMs,
        maxOutputBytes
    }, (options == null ? void 0 : options.executionScope) ? {
        executionScope: options.executionScope
    } : {}, (options == null ? void 0 : options.signal) ? {
        signal: options.signal
    } : {});
}

function isObjectLike$2(value) {
    return typeof value === 'object' && value !== null;
}
function isSandboxManagedServiceAdapter(value) {
    return isObjectLike$2(value) && typeof Reflect.get(value, 'startService') === 'function' && typeof Reflect.get(value, 'listServices') === 'function' && typeof Reflect.get(value, 'getServiceLogs') === 'function' && typeof Reflect.get(value, 'stopService') === 'function' && typeof Reflect.get(value, 'restartService') === 'function';
}
function resolveSandboxManagedServiceAdapter(sandbox) {
    if (!isObjectLike$2(sandbox)) {
        return null;
    }
    const candidate = Reflect.has(sandbox, 'backend') ? Reflect.get(sandbox, 'backend') : sandbox;
    return isSandboxManagedServiceAdapter(candidate) ? candidate : null;
}
function isSandboxServiceProxyAdapter(value) {
    return isObjectLike$2(value) && typeof Reflect.get(value, 'proxyServiceRequest') === 'function';
}
function resolveSandboxServiceProxyAdapter(sandbox) {
    if (!isObjectLike$2(sandbox)) {
        return null;
    }
    const candidate = Reflect.has(sandbox, 'backend') ? Reflect.get(sandbox, 'backend') : sandbox;
    return isSandboxServiceProxyAdapter(candidate) ? candidate : null;
}

/**
 * Type guard to check if a backend supports execution.
 *
 * @param backend - Backend instance to check
 * @returns True if the backend implements SandboxBackendProtocol
 */ function isObjectLike$1(value) {
    return typeof value === 'object' && value !== null;
}
function isSandboxBackend(backend) {
    return isObjectLike$1(backend) && typeof Reflect.get(backend, 'execute') === 'function' && typeof Reflect.get(backend, 'id') === 'string';
}
function resolveSandboxBackend(sandbox) {
    if (!isObjectLike$1(sandbox)) {
        return null;
    }
    const candidate = Reflect.has(sandbox, 'backend') ? Reflect.get(sandbox, 'backend') : sandbox;
    return isSandboxBackend(candidate) ? candidate : null;
}

const editMetricsSchema = z.object({
    occurrences: z.number().int().nonnegative(),
    oldLines: z.number().int().nonnegative(),
    newLines: z.number().int().nonnegative(),
    changed: z.boolean(),
    diff: z.object({
        removed: z.number().int().nonnegative(),
        added: z.number().int().nonnegative()
    }).optional(),
    diffUnavailable: z.enum([
        'comparison_budget_exceeded',
        'diff_unavailable'
    ]).optional()
});
function editMetrics(output) {
    try {
        const result = editMetricsSchema.safeParse(JSON.parse(output));
        if (!result.success) return undefined;
        const _result_data = result.data, { diff } = _result_data, metrics = _object_without_properties_loose$2(_result_data, [
            "diff"
        ]);
        return _extends({}, metrics, diff ? {
            diff: {
                removed: diff.removed,
                added: diff.added
            }
        } : {});
    } catch (e) {
        return undefined;
    }
}
function editCommandResult(filePath, result) {
    const metrics = editMetrics(result.output);
    switch(result.exitCode){
        case 0:
            return _extends({
                path: filePath,
                filesUpdate: null
            }, metrics != null ? metrics : {
                occurrences: parseInt(result.output.trim(), 10) || 1
            });
        case 1:
            return _extends({}, metrics, {
                error: `String not found in file '${filePath}'`
            });
        case 2:
            return _extends({}, metrics, {
                error: `Multiple occurrences found in '${filePath}'. Use replaceAll=true to replace all.`
            });
        case 3:
            return _extends({}, metrics, {
                error: `Error: File '${filePath}' not found`
            });
        default:
            return {
                error: `Unknown error editing file '${filePath}'`
            };
    }
}
/** Stops on failure; never promises rollback or silently reapplies completed edits. */ async function sequentialFileEdits(filePath, edits, apply) {
    const results = [];
    if (!(edits == null ? void 0 : edits.length)) return {
        error: 'No edits provided',
        progress: {
            mode: 'sequential',
            appliedEdits: 0
        }
    };
    for (const edit of edits){
        const result = await apply(edit);
        results.push(result);
        if (result.error) return {
            error: `Multi-edit failed at edit ${results.length}: ${result.error}`,
            path: filePath,
            filesUpdate: null,
            results,
            progress: {
                mode: 'sequential',
                appliedEdits: results.length - 1,
                failedEdit: results.length
            }
        };
    }
    return {
        path: filePath,
        filesUpdate: null,
        results,
        progress: {
            mode: 'sequential',
            appliedEdits: results.length
        }
    };
}

// Embedded in the existing sandbox Node process; no Git, subprocess, or temporary files.
const FILE_EDIT_DIFF_SCRIPT = String.raw`
function inspectLineDiff(before, after) {
  if (before === after) return { diff: { removed: 0, added: 0 } };
  // Include line terminators so a missing final newline is an actual line change.
  const oldLines = before.match(/[^\n]*\n|[^\n]+$/g) || [];
  const newLines = after.match(/[^\n]*\n|[^\n]+$/g) || [];
  let start = 0, oldEnd = oldLines.length, newEnd = newLines.length;
  while (start < oldEnd && start < newEnd && oldLines[start] === newLines[start]) start++;
  while (oldEnd > start && newEnd > start && oldLines[oldEnd - 1] === newLines[newEnd - 1]) {
    oldEnd--;
    newEnd--;
  }
  const removed = oldEnd - start, added = newEnd - start;
  if (!removed || !added) return { diff: { removed, added } };

  // Myers shortest edit distance needs only a frontier when reporting counts, not a patch.
  // Bound the optional quadratic search on broad rewrites; never limit the edit itself.
  const maxDistance = Math.min(removed + added, 2000);
  const offset = maxDistance + 1;
  const frontier = new Int32Array(2 * maxDistance + 3);
  let work = 0;
  for (let distance = 0; distance <= maxDistance; distance++) {
    for (let diagonal = -distance; diagonal <= distance; diagonal += 2) {
      if (++work > 1000000) return { diffUnavailable: 'comparison_budget_exceeded' };
      const index = offset + diagonal;
      let x = diagonal === -distance || (diagonal !== distance && frontier[index - 1] < frontier[index + 1])
        ? frontier[index + 1]
        : frontier[index - 1] + 1;
      let y = x - diagonal;
      while (x < removed && y < added && oldLines[start + x] === newLines[start + y]) {
        if (++work > 1000000) return { diffUnavailable: 'comparison_budget_exceeded' };
        x++;
        y++;
      }
      if (x >= removed && y >= added) {
        return { diff: { removed: (distance + removed - added) / 2, added: (distance + added - removed) / 2 } };
      }
      frontier[index] = x;
    }
  }
  return { diffUnavailable: 'comparison_budget_exceeded' };
}
`;

/** Compare actual file contents inside the sandbox; reporting must never prevent an edit. */ function buildEditCommand(filePath, oldString, newString, replaceAll) {
    const encoded = Buffer.from(JSON.stringify({
        filePath,
        oldString,
        newString,
        replaceAll
    })).toString('base64');
    const script = `
const fs = require('node:fs');
const input = JSON.parse(Buffer.from('${encoded}', 'base64').toString('utf8'));
const lines = text => text.length ? text.split('\\n').length - Number(text.endsWith('\\n')) : 0;
const metrics = { oldLines: lines(input.oldString), newLines: lines(input.newString) };

${FILE_EDIT_DIFF_SCRIPT}

function unchanged(exitCode) {
  console.log(JSON.stringify({ ...metrics, occurrences: 0, changed: false, diff: { removed: 0, added: 0 } }));
  process.exit(exitCode);
}
let before;
try { before = fs.readFileSync(input.filePath, 'utf8'); } catch { unchanged(3); }
const occurrences = before.split(input.oldString).length - 1;
if (occurrences === 0) unchanged(1);
if (occurrences > 1 && !input.replaceAll) unchanged(2);
const after = before.split(input.oldString).join(input.newString);
const changed = before !== after;
if (changed) fs.writeFileSync(input.filePath, after, 'utf8');
try {
  Object.assign(metrics, inspectLineDiff(before, after));
} catch {
  metrics.diffUnavailable = 'diff_unavailable';
}
console.log(JSON.stringify({ ...metrics, occurrences, changed }));
`;
    return `node -e '${script.replace(/'/g, "'\\''")}'`;
}

const INDENTATION_SPACES = 2;
/**
 * Node.js command template for recursive directory listing with depth control.
 */ function buildListDirCommand(dirPath, displayPath, offset, limit, depth) {
    const pathB64 = Buffer.from(dirPath, 'utf-8').toString('base64');
    const displayPathB64 = Buffer.from(displayPath, 'utf-8').toString('base64');
    const safeOffset = Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 1;
    const safeLimit = Number.isFinite(limit) && limit > 0 ? Math.floor(limit) : 25;
    const safeDepth = Number.isFinite(depth) && depth > 0 ? Math.floor(depth) : 2;
    return `node -e "
const fs = require('fs');
const path = require('path');

const dirPath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const displayPath = Buffer.from('${displayPathB64}', 'base64').toString('utf-8');
const offset = ${safeOffset};
const limit = ${safeLimit};
const maxDepth = ${safeDepth};
const INDENTATION_SPACES = ${INDENTATION_SPACES};

if (!path.isAbsolute(dirPath)) {
  console.error('Error: dir_path must be an absolute path');
  process.exit(1);
}

if (!fs.existsSync(dirPath)) {
  console.error('Error: Directory not found');
  process.exit(1);
}

if (!fs.statSync(dirPath).isDirectory()) {
  console.error('Error: Path is not a directory');
  process.exit(1);
}

function collectEntries(currentPath, relativePrefix, remainingDepth, entries) {
  if (remainingDepth === 0) return;

  try {
    const dirEntries = fs.readdirSync(currentPath, { withFileTypes: true });
    const sortedEntries = dirEntries
      .map(entry => {
        const fullPath = path.join(currentPath, entry.name);
        const relativePath = path.join(relativePrefix, entry.name);

        let kind = 'file';
        if (entry.isSymbolicLink()) kind = 'symlink';
        else if (entry.isDirectory()) kind = 'directory';

        return {
          fullPath,
          relativePath,
          kind,
          depth: relativePrefix.split(path.sep).filter(Boolean).length
        };
      })
      .sort((a, b) => a.relativePath.localeCompare(b.relativePath));

    for (const entry of sortedEntries) {
      entries.push(entry);
      if (entry.kind === 'directory' && remainingDepth > 1) {
        collectEntries(entry.fullPath, entry.relativePath, remainingDepth - 1, entries);
      }
    }
  } catch (e) {
    // Skip unreadable directories
  }
}

const allEntries = [];
collectEntries(dirPath, '', maxDepth, allEntries);

if (allEntries.length === 0) {
  console.log('Workspace-relative directory: ' + displayPath);
  console.log('(Empty directory)');
  process.exit(0);
}

const startIndex = offset - 1;
if (startIndex >= allEntries.length) {
  console.error('Error: offset exceeds directory entry count');
  process.exit(1);
}

const endIndex = Math.min(startIndex + limit, allEntries.length);
const selectedEntries = allEntries.slice(startIndex, endIndex);

console.log('Workspace-relative directory: ' + displayPath);

for (const entry of selectedEntries) {
  const indent = ' '.repeat(entry.depth * INDENTATION_SPACES);
  let name = path.posix.join(displayPath, entry.relativePath.split(path.sep).join('/'));
  if (entry.kind === 'directory') name += '/';
  else if (entry.kind === 'symlink') name += '@';
  console.log(indent + name);
}

if (endIndex < allEntries.length) {
  console.log('More than ' + limit + ' entries found');
}
"`;
}

/** Format tool-owned paths only; file contents and backend filesystem authorization stay unchanged. */ function workspaceRelativeDisplayPath(workingDirectory, filePath) {
    if (!workingDirectory || !isAbsolute(workingDirectory)) {
        throw new Error('Sandbox working directory is not available.');
    }
    const value = relative(workingDirectory, resolve(workingDirectory, filePath));
    if (isAbsolute(value) || value === '..' || value.startsWith(`..${sep}`)) {
        throw new Error('Sandbox discovery path is outside the workspace.');
    }
    return value.split(sep).join('/') || '.';
}

const MAX_LINE_LENGTH = 500;
const MAX_GREP_LINE_LENGTH = 2000;
const GREP_RESULT_LIMIT = 100;
const GLOB_RESULT_LIMIT = 100;
const WRITE_EXISTS_OUTPUT = 'Error: File already exists';
/**
 * UTF-8 safe Base64 encoding function.
 * Replaces btoa() which only supports Latin1 characters.
 */ function utf8ToBase64(str) {
    return Buffer.from(str, 'utf-8').toString('base64');
}
/**
 * Format glob results into human-readable output.
 */ function formatGlobOutput(files, pattern) {
    const limit = GLOB_RESULT_LIMIT;
    const truncated = files.length > limit;
    const finalFiles = truncated ? files.slice(0, limit) : files;
    if (finalFiles.length === 0) {
        return 'No files found';
    }
    const lines = [];
    for (const file of finalFiles){
        lines.push(file.path);
    }
    if (truncated) {
        lines.push('');
        lines.push('(Results truncated. Consider using a more specific path or pattern.)');
    }
    return lines.join('\n');
}
/**
 * Format grep matches into human-readable output grouped by file.
 */ function formatGrepOutput(matches) {
    const limit = GREP_RESULT_LIMIT;
    const truncated = matches.length > limit;
    const finalMatches = truncated ? matches.slice(0, limit) : matches;
    if (finalMatches.length === 0) {
        return 'No matches found';
    }
    const lines = [
        `Found ${finalMatches.length} matches`
    ];
    let currentFile = '';
    for (const match of finalMatches){
        if (currentFile !== match.path) {
            if (currentFile !== '') {
                lines.push('');
            }
            currentFile = match.path;
            lines.push(`${match.path}:`);
        }
        const text = match.text.length > MAX_GREP_LINE_LENGTH ? match.text.substring(0, MAX_GREP_LINE_LENGTH) + '...' : match.text;
        lines.push(`  Line ${match.line}: ${text}`);
    }
    if (truncated) {
        lines.push('');
        lines.push('(Results truncated. Consider using a more specific path or pattern.)');
    }
    return lines.join('\n');
}
/**
 * Node.js command template for glob operations.
 * Uses web-standard atob() for base64 decoding.
 */ function buildGlobCommand(searchPath, pattern) {
    const pathB64 = utf8ToBase64(searchPath);
    const patternB64 = utf8ToBase64(pattern);
    return `node -e "
const fs = require('fs');
const path = require('path');

const searchPath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const pattern = Buffer.from('${patternB64}', 'base64').toString('utf-8');

function globMatch(relativePath, pattern) {
  const regexPattern = pattern
    .replace(/\\*\\*/g, '<<<GLOBSTAR>>>')
    .replace(/\\*/g, '[^/]*')
    .replace(/\\?/g, '.')
    .replace(/<<<GLOBSTAR>>>/g, '.*');
  return new RegExp('^' + regexPattern + '$').test(relativePath);
}

function walkDir(dir, baseDir, results) {
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relativePath = path.relative(baseDir, fullPath);
      if (entry.isDirectory()) {
        walkDir(fullPath, baseDir, results);
      } else if (globMatch(relativePath, pattern)) {
        const stat = fs.statSync(fullPath);
        console.log(JSON.stringify({
          path: relativePath,
          size: stat.size,
          mtime: stat.mtimeMs,
          isDir: false
        }));
      }
    }
  } catch (e) {
    // Silent failure for non-existent paths
  }
}

try {
  process.chdir(searchPath);
  walkDir('.', '.', []);
} catch (e) {
  // Silent failure for non-existent paths
}
"`;
}
/**
 * Node.js command template for listing directory contents.
 */ function buildLsCommand(dirPath) {
    const pathB64 = utf8ToBase64(dirPath);
    return `node -e "
const fs = require('fs');
const path = require('path');

const dirPath = Buffer.from('${pathB64}', 'base64').toString('utf-8');

try {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const stat = fs.statSync(fullPath);
    console.log(JSON.stringify({
      path: entry.isDirectory() ? fullPath + '/' : fullPath,
      size: stat.size,
      mtime: stat.mtimeMs,
      isDir: entry.isDirectory()
    }));
  }
} catch (e) {
  console.error('Error: ' + e.message);
  process.exit(1);
}
"`;
}
const TAB_WIDTH = 4;
const COMMENT_PREFIXES = [
    '#',
    '//',
    '--'
];
/**
 * Node.js command template for slice mode reading.
 */ function buildSliceReadCommand(filePath, offset, limit) {
    const pathB64 = utf8ToBase64(filePath);
    const safeOffset = Number.isFinite(offset) && offset > 0 ? Math.floor(offset) - 1 : 0;
    const safeLimit = Number.isFinite(limit) && limit > 0 && limit < Number.MAX_SAFE_INTEGER ? Math.floor(limit) : 2000;
    return `node -e "
const fs = require('fs');
const MAX_LINE_LENGTH = ${MAX_LINE_LENGTH};

const filePath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const offset = ${safeOffset};
const limit = ${safeLimit};

if (!fs.existsSync(filePath)) {
  console.log('Error: File not found');
  process.exit(1);
}

const stat = fs.statSync(filePath);
if (stat.size === 0) {
  console.log('System reminder: File exists but has empty contents');
  process.exit(0);
}

const content = fs.readFileSync(filePath, 'utf-8');
const lines = content.split('\\n');

if (offset >= lines.length) {
  console.log('Error: offset exceeds file length');
  process.exit(1);
}

const selected = lines.slice(offset, offset + limit);

for (let i = 0; i < selected.length; i++) {
  const lineNum = offset + i + 1;
  let line = selected[i];
  if (line.length > MAX_LINE_LENGTH) {
    line = line.substring(0, MAX_LINE_LENGTH);
  }
  console.log('L' + lineNum + ': ' + line);
}
"`;
}
/**
 * Node.js command template for indentation mode reading.
 */ function buildIndentationReadCommand(filePath, offset, limit, options) {
    const pathB64 = utf8ToBase64(filePath);
    const safeOffset = Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 1;
    const safeLimit = Number.isFinite(limit) && limit > 0 && limit < Number.MAX_SAFE_INTEGER ? Math.floor(limit) : 2000;
    var _options_anchor_line;
    const anchorLine = (_options_anchor_line = options.anchor_line) != null ? _options_anchor_line : safeOffset;
    var _options_max_levels;
    const maxLevels = (_options_max_levels = options.max_levels) != null ? _options_max_levels : 0;
    var _options_include_siblings;
    const includeSiblings = (_options_include_siblings = options.include_siblings) != null ? _options_include_siblings : false;
    var _options_include_header;
    const includeHeader = (_options_include_header = options.include_header) != null ? _options_include_header : true;
    var _options_max_lines;
    const maxLines = (_options_max_lines = options.max_lines) != null ? _options_max_lines : safeLimit;
    return `node -e "
const fs = require('fs');
const MAX_LINE_LENGTH = ${MAX_LINE_LENGTH};
const TAB_WIDTH = ${TAB_WIDTH};
const COMMENT_PREFIXES = ${JSON.stringify(COMMENT_PREFIXES)};

const filePath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const anchorLine = ${anchorLine};
const limit = ${safeLimit};
const maxLevels = ${maxLevels};
const includeSiblings = ${includeSiblings};
const includeHeader = ${includeHeader};
const maxLines = ${maxLines};

if (!fs.existsSync(filePath)) {
  console.log('Error: File not found');
  process.exit(1);
}

const content = fs.readFileSync(filePath, 'utf-8');
const rawLines = content.split('\\n');

if (rawLines.length === 0 || anchorLine > rawLines.length) {
  console.log('Error: anchor_line exceeds file length');
  process.exit(1);
}

function measureIndent(line) {
  let indent = 0;
  for (const c of line) {
    if (c === ' ') indent++;
    else if (c === '\\t') indent += TAB_WIDTH;
    else break;
  }
  return indent;
}

function isBlank(line) { return line.trim() === ''; }
function isComment(line) { return COMMENT_PREFIXES.some(p => line.trim().startsWith(p)); }
function formatLine(line) { return line.length > MAX_LINE_LENGTH ? line.substring(0, MAX_LINE_LENGTH) : line; }

const records = rawLines.map((raw, i) => ({
  number: i + 1,
  raw,
  display: formatLine(raw),
  indent: measureIndent(raw)
}));

const effectiveIndents = [];
let prevIndent = 0;
for (const r of records) {
  if (isBlank(r.raw)) {
    effectiveIndents.push(prevIndent);
  } else {
    prevIndent = r.indent;
    effectiveIndents.push(prevIndent);
  }
}

const anchorIndex = anchorLine - 1;
const anchorIndent = effectiveIndents[anchorIndex];
const minIndent = maxLevels === 0 ? 0 : Math.max(0, anchorIndent - maxLevels * TAB_WIDTH);
const finalLimit = Math.min(limit, maxLines, records.length);

if (finalLimit === 1) {
  console.log('L' + records[anchorIndex].number + ': ' + records[anchorIndex].display);
  process.exit(0);
}

const out = [records[anchorIndex]];
let i = anchorIndex - 1;
let j = anchorIndex + 1;
let iCounterMinIndent = 0;
let jCounterMinIndent = 0;

while (out.length < finalLimit) {
  let progressed = 0;

  if (i >= 0) {
    if (effectiveIndents[i] >= minIndent) {
      out.unshift(records[i]);
      progressed++;
      const curI = i;
      i--;

      if (effectiveIndents[curI] === minIndent && !includeSiblings) {
        const allowHeaderComment = includeHeader && isComment(records[curI].raw);
        const canTakeLine = allowHeaderComment || iCounterMinIndent === 0;
        if (canTakeLine) {
          iCounterMinIndent++;
        } else {
          out.shift();
          progressed--;
          i = -1;
        }
      }

      if (out.length >= finalLimit) break;
    } else {
      i = -1;
    }
  }

  if (j < records.length) {
    if (effectiveIndents[j] >= minIndent) {
      out.push(records[j]);
      progressed++;
      const curJ = j;
      j++;

      if (effectiveIndents[curJ] === minIndent && !includeSiblings) {
        if (jCounterMinIndent > 0) {
          out.pop();
          progressed--;
          j = records.length;
        }
        jCounterMinIndent++;
      }
    } else {
      j = records.length;
    }
  }

  if (progressed === 0) break;
}

while (out.length > 0 && isBlank(out[0].raw)) out.shift();
while (out.length > 0 && isBlank(out[out.length - 1].raw)) out.pop();

for (const r of out) {
  console.log('L' + r.number + ': ' + r.display);
}
"`;
}
/**
 * Node.js command template for writing files.
 */ function buildWriteCommand(filePath, content) {
    const pathB64 = utf8ToBase64(filePath);
    const contentB64 = utf8ToBase64(content);
    return `node -e "
const fs = require('fs');
const path = require('path');

const filePath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const content = Buffer.from('${contentB64}', 'base64').toString('utf-8');

if (fs.existsSync(filePath)) {
  console.error('${WRITE_EXISTS_OUTPUT}');
  process.exit(1);
}

const parentDir = path.dirname(filePath) || '.';
fs.mkdirSync(parentDir, { recursive: true });

fs.writeFileSync(filePath, content, 'utf-8');
console.log('OK');
"`;
}
function buildExistsCommand(filePath) {
    const pathB64 = utf8ToBase64(filePath);
    return `node -e "
const fs = require('fs');
const filePath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
process.exit(fs.existsSync(filePath) ? 0 : 1);
"`;
}
/**
 * Node.js command template for appending to files.
 */ function buildAppendCommand(filePath, content) {
    const pathB64 = utf8ToBase64(filePath);
    const contentB64 = utf8ToBase64(content);
    return `node -e "
const fs = require('fs');
const path = require('path');

const filePath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const content = Buffer.from('${contentB64}', 'base64').toString('utf-8');

const parentDir = path.dirname(filePath) || '.';
fs.mkdirSync(parentDir, { recursive: true });

fs.appendFileSync(filePath, content, 'utf-8');
console.log('OK');
"`;
}
/**
 * Node.js command template for grep operations.
 */ function buildGrepCommand(pattern, searchPath, globPattern) {
    const patternB64 = utf8ToBase64(pattern);
    const pathB64 = utf8ToBase64(searchPath);
    const globB64 = globPattern ? utf8ToBase64(globPattern) : '';
    return `node -e "
const fs = require('fs');
const path = require('path');

const pattern = Buffer.from('${patternB64}', 'base64').toString('utf-8');
const searchPath = Buffer.from('${pathB64}', 'base64').toString('utf-8');
const globPattern = ${globPattern ? `Buffer.from('${globB64}', 'base64').toString('utf-8')` : 'null'};

let regex;
try {
  regex = new RegExp(pattern);
} catch (e) {
  console.error('Invalid regex: ' + e.message);
  process.exit(1);
}

function globMatch(filePath, pattern) {
  if (!pattern) return true;
  const regexPattern = pattern
    .replace(/\\*\\*/g, '<<<GLOBSTAR>>>')
    .replace(/\\*/g, '[^/]*')
    .replace(/\\?/g, '.')
    .replace(/<<<GLOBSTAR>>>/g, '.*');
  return new RegExp('^' + regexPattern + '$').test(filePath);
}

function walkDir(dir, results) {
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walkDir(fullPath, results);
      } else {
        const relativePath = path.relative(searchPath, fullPath);
        if (globMatch(relativePath, globPattern)) {
          try {
            const content = fs.readFileSync(fullPath, 'utf-8');
            const lines = content.split('\\n');
            for (let i = 0; i < lines.length; i++) {
              if (regex.test(lines[i])) {
                console.log(JSON.stringify({
                  path: fullPath,
                  line: i + 1,
                  text: lines[i]
                }));
              }
            }
          } catch (e) {
            // Skip unreadable files
          }
        }
      }
    }
  } catch (e) {
    // Skip unreadable directories
  }
}

try {
  walkDir(searchPath, []);
} catch (e) {
  // Silent failure
}
"`;
}
/**
 * Base sandbox implementation with execute() as the only abstract method.
 *
 * This class provides default implementations for all SandboxBackendProtocol
 * methods using shell commands executed via execute(). Concrete implementations
 * only need to implement the execute() method.
 *
 * Requires Node.js 20+ on the sandbox host.
 */ class BaseSandbox {
    /**
     * Internal hook for file/search operations. Concrete backends can override
     * this to distinguish "background helper commands" from user-facing shell
     * execute calls.
     */ executeOperation(command, options) {
        return this.execute(command, options);
    }
    async streamExecute(command, onLine, options) {
        const result = await this.execute(command, options);
        if (result.output) {
            onLine(result.output);
        }
        return result;
    }
    /**
     * List files and directories in the specified directory (non-recursive).
     *
     * @param path - Absolute path to directory
     * @returns List of FileInfo objects for files and directories directly in the directory.
     */ async lsInfo(path) {
        const command = buildLsCommand(path);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (result.exitCode !== 0) {
            return [];
        }
        const infos = [];
        const lines = result.output.trim().split('\n').filter(Boolean);
        for (const line of lines){
            try {
                const parsed = JSON.parse(line);
                infos.push({
                    path: parsed.path,
                    is_dir: parsed.isDir,
                    size: parsed.size,
                    modified_at: parsed.mtime ? new Date(parsed.mtime).toISOString() : undefined
                });
            } catch (e) {
            // Skip invalid JSON lines
            }
        }
        return infos;
    }
    /**
     * List directory contents recursively with depth control and pagination.
     *
     * @param dirPath - Absolute path to directory
     * @param offset - 1-indexed entry number to start from (default: 1)
     * @param limit - Maximum number of entries to return (default: 25)
     * @param depth - Maximum depth to traverse (default: 2)
     * @returns Directory tree whose entries are relative to the sandbox working directory
     */ async listDir(dirPath, offset = 1, limit = 25, depth = 2) {
        if (offset < 1) {
            return 'Error: offset must be a 1-indexed entry number';
        }
        if (limit < 1) {
            return 'Error: limit must be greater than zero';
        }
        if (depth < 1) {
            return 'Error: depth must be greater than zero';
        }
        const displayPath = workspaceRelativeDisplayPath(this.workingDirectory, dirPath);
        const command = buildListDirCommand(dirPath, displayPath, offset, limit, depth);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (result.exitCode !== 0) {
            return result.output || `Error: Failed to list directory '${displayPath}'`;
        }
        return result.output;
    }
    /**
     * Read file content with line numbers.
     *
     * @param filePath - Absolute file path
     * @param offset - Line offset to start reading from (1-indexed)
     * @param limit - Maximum number of lines to read
     * @param mode - Read mode: 'slice' (default) or 'indentation'
     * @param indentation - Configuration for indentation mode
     * @returns Formatted file content with line numbers, or error message
     */ async read(filePath, offset = 1, limit = 2000, mode = 'slice', indentation) {
        const command = mode === 'indentation' ? buildIndentationReadCommand(filePath, offset, limit, indentation != null ? indentation : {}) : buildSliceReadCommand(filePath, offset, limit);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (result.exitCode !== 0) {
            return result.output || `Error: File '${filePath}' not found`;
        }
        return result.output;
    }
    /**
     * Structured search results or error string for invalid input.
     */ async grepRaw(pattern, path = '/', include = null) {
        const command = buildGrepCommand(pattern, path, include);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_SEARCH_EXECUTION_OPTIONS);
        if (result.exitCode === 1) {
            // Check if it's a regex error
            if (result.output.includes('Invalid regex:')) {
                return result.output.trim();
            }
        }
        const matches = [];
        const lines = result.output.trim().split('\n').filter(Boolean);
        for (const line of lines){
            try {
                const parsed = JSON.parse(line);
                matches.push({
                    path: parsed.path,
                    line: parsed.line,
                    text: parsed.text
                });
            } catch (e) {
            // Skip invalid JSON lines
            }
        }
        return matches;
    }
    /**
     * Search file contents for a regex pattern, returning workspace-relative path labels.
     */ async grep(pattern, path = this.workingDirectory, include = null) {
        const displayPath = workspaceRelativeDisplayPath(this.workingDirectory, path);
        const result = await this.grepRaw(pattern, resolve(this.workingDirectory, displayPath), include);
        if (typeof result === 'string') {
            return result;
        }
        if (result.length === 0) {
            return 'No matches found';
        }
        return formatGrepOutput(result.map((match)=>_extends({}, match, {
                path: workspaceRelativeDisplayPath(this.workingDirectory, match.path)
            })));
    }
    /**
     * Structured glob matching returning FileInfo objects.
     */ async globInfo(pattern, path = '/') {
        const command = buildGlobCommand(path, pattern);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_SEARCH_EXECUTION_OPTIONS);
        const infos = [];
        const lines = result.output.trim().split('\n').filter(Boolean);
        for (const line of lines){
            try {
                const parsed = JSON.parse(line);
                infos.push({
                    path: parsed.path,
                    is_dir: parsed.isDir,
                    size: parsed.size,
                    modified_at: parsed.mtime ? new Date(parsed.mtime).toISOString() : undefined
                });
            } catch (e) {
            // Skip invalid JSON lines
            }
        }
        return infos;
    }
    /**
     * Find files matching a glob pattern, returning workspace-relative paths.
     */ async glob(pattern, path = this.workingDirectory) {
        const displayPath = workspaceRelativeDisplayPath(this.workingDirectory, path);
        const searchPath = resolve(this.workingDirectory, displayPath);
        const files = await this.globInfo(pattern, searchPath);
        if (files.length === 0) {
            return 'No files found';
        }
        return formatGlobOutput(files.map((file)=>_extends({}, file, {
                path: workspaceRelativeDisplayPath(this.workingDirectory, resolve(searchPath, file.path))
            })));
    }
    /**
     * Create a new file with content.
     */ async write(filePath, content) {
        const command = buildWriteCommand(filePath, content);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (result.exitCode !== 0) {
            const output = (result.output || '').trim();
            if (output.includes(WRITE_EXISTS_OUTPUT)) {
                return {
                    error: `Cannot write to ${filePath} because it already exists. Read and then make an edit, or write to a new path.`
                };
            }
            const fallback = await this.writeViaUpload(filePath, content);
            if (!fallback.error) {
                return fallback;
            }
            return {
                error: output ? `Failed to write file '${filePath}': ${output}` : `Failed to write file '${filePath}'.`
            };
        }
        return {
            path: filePath,
            filesUpdate: null
        };
    }
    async writeViaUpload(filePath, content) {
        const existsCheck = await this.executeOperation(buildExistsCommand(filePath), DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (existsCheck.exitCode === 0) {
            return {
                error: `Cannot write to ${filePath} because it already exists. Read and then make an edit, or write to a new path.`
            };
        }
        const uploads = await this.uploadFiles([
            [
                filePath,
                Buffer.from(content, 'utf-8')
            ]
        ]);
        const first = uploads[0];
        if (!first) {
            return {
                error: `Failed to write file '${filePath}': upload returned no result.`
            };
        }
        if (first.error) {
            return {
                error: `Failed to write file '${filePath}': ${first.error}`
            };
        }
        return {
            path: filePath,
            filesUpdate: null
        };
    }
    /**
     * Append content to a file. Creates the file if it doesn't exist.
     */ async append(filePath, content) {
        const command = buildAppendCommand(filePath, content);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        if (result.exitCode !== 0) {
            const output = (result.output || '').trim();
            return {
                error: output ? `Failed to append to file '${filePath}': ${output}` : `Failed to append to file '${filePath}'.`
            };
        }
        return {
            path: filePath,
            filesUpdate: null
        };
    }
    /** Edit a file by replacing string occurrences. */ async edit(filePath, oldString, newString, replaceAll = false) {
        const command = buildEditCommand(filePath, oldString, newString, replaceAll);
        const result = await this.executeOperation(command, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS);
        return editCommandResult(filePath, result);
    }
    /** Earlier successful edits remain persisted if a later edit fails. */ multiEdit(filePath, edits) {
        return sequentialFileEdits(filePath, edits, (edit)=>{
            var _edit_replaceAll;
            return this.edit(filePath, edit.oldString, edit.newString, (_edit_replaceAll = edit.replaceAll) != null ? _edit_replaceAll : false);
        });
    }
}

const SANDBOX_PROVIDER = 'SANDBOX_PROVIDER';
const SandboxProviderStrategy = (provider)=>applyDecorators(SetMetadata(SANDBOX_PROVIDER, provider), SetMetadata(STRATEGY_META_KEY, SANDBOX_PROVIDER));

let SandboxProviderRegistry = class SandboxProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(SANDBOX_PROVIDER, discoveryService, reflector);
    }
};
SandboxProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], SandboxProviderRegistry);

function isObjectLike(value) {
    return typeof value === 'object' && value !== null;
}
function isSandboxTerminalAdapter(value) {
    return isObjectLike(value) && typeof Reflect.get(value, 'open') === 'function';
}
function resolveSandboxTerminalAdapter(sandbox) {
    if (!isObjectLike(sandbox)) {
        return null;
    }
    const candidate = Reflect.has(sandbox, 'backend') ? Reflect.get(sandbox, 'backend') : sandbox;
    return isSandboxTerminalAdapter(candidate) ? candidate : null;
}

const SANDBOX_RUNTIME_PROVIDER = 'SANDBOX_RUNTIME_PROVIDER';
/** Marks a built-in or system-plugin class as a named Sandbox Runtime Provider strategy. */ const SandboxRuntimeProviderStrategy = (provider)=>applyDecorators(SetMetadata(SANDBOX_RUNTIME_PROVIDER, provider), SetMetadata(STRATEGY_META_KEY, SANDBOX_RUNTIME_PROVIDER));

/**
 * Returns whether reduced-isolation Sandbox Runtime Bindings may be used.
 *
 * Only explicit development and test modes qualify. An unset or custom
 * NODE_ENV remains fail-closed so a production deployment cannot accidentally
 * execute a local Runtime Provider.
 */ function isDevelopmentSandboxRuntimeEnvironment(environment = process.env) {
    return environment['NODE_ENV'] === 'development' || environment['NODE_ENV'] === 'test';
}

var SandboxRuntimeProviderRegistry_1;
/** Discovers Runtime Provider strategies and rejects organization-scoped executable infrastructure. */ let SandboxRuntimeProviderRegistry = SandboxRuntimeProviderRegistry_1 = class SandboxRuntimeProviderRegistry extends BaseStrategyRegistry {
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        if (!target) {
            return;
        }
        if (!this.reflector.get(SANDBOX_RUNTIME_PROVIDER, target)) {
            return;
        }
        const pluginName = this.reflector.get(PLUGIN_METADATA_KEY, target);
        var _this_reflector_get;
        const scope = (_this_reflector_get = this.reflector.get(ORGANIZATION_METADATA_KEY, target)) != null ? _this_reflector_get : BUILTIN_GLOBAL_SCOPE;
        if (pluginName && scope !== SYSTEM_GLOBAL_SCOPE) {
            this.runtimeLogger.warn(`Ignored Sandbox Runtime Provider from non-system plugin ${pluginName} in scope ${scope}.`);
            return;
        }
        super.upsert(instance);
    }
    constructor(discoveryService, reflector){
        super(SANDBOX_RUNTIME_PROVIDER, discoveryService, reflector);
        this.runtimeLogger = new Logger(SandboxRuntimeProviderRegistry_1.name);
    }
};
SandboxRuntimeProviderRegistry = SandboxRuntimeProviderRegistry_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], SandboxRuntimeProviderRegistry);

const SANDBOX_WORKSPACE_MAPPER = 'SANDBOX_WORKSPACE_MAPPER';
/** Associates a workspace path mapper with a named Runtime Provider strategy. */ const SandboxWorkspaceMapperStrategy = (provider)=>applyDecorators(SetMetadata(SANDBOX_WORKSPACE_MAPPER, provider), SetMetadata(STRATEGY_META_KEY, SANDBOX_WORKSPACE_MAPPER));

var SandboxWorkspaceMapperRegistry_1;
/** Discovers Provider path mappers while enforcing the same system-level trust boundary as Providers. */ let SandboxWorkspaceMapperRegistry = SandboxWorkspaceMapperRegistry_1 = class SandboxWorkspaceMapperRegistry extends BaseStrategyRegistry {
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        if (!target) {
            return;
        }
        if (!this.reflector.get(SANDBOX_WORKSPACE_MAPPER, target)) {
            return;
        }
        const pluginName = this.reflector.get(PLUGIN_METADATA_KEY, target);
        var _this_reflector_get;
        const scope = (_this_reflector_get = this.reflector.get(ORGANIZATION_METADATA_KEY, target)) != null ? _this_reflector_get : BUILTIN_GLOBAL_SCOPE;
        if (pluginName && scope !== SYSTEM_GLOBAL_SCOPE) {
            this.mapperLogger.warn(`Ignored Sandbox Workspace Mapper from non-system plugin ${pluginName} in scope ${scope}.`);
            return;
        }
        super.upsert(instance);
    }
    constructor(discoveryService, reflector){
        super(SANDBOX_WORKSPACE_MAPPER, discoveryService, reflector);
        this.mapperLogger = new Logger(SandboxWorkspaceMapperRegistry_1.name);
    }
};
SandboxWorkspaceMapperRegistry = SandboxWorkspaceMapperRegistry_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], SandboxWorkspaceMapperRegistry);

const MANAGED_CONNECTION_REGISTRY_TOKEN = 'XPERT_MANAGED_CONNECTION_REGISTRY';
const CONNECTION_COMMAND_ROUTER_TOKEN = 'XPERT_CONNECTION_COMMAND_ROUTER';

const MANAGED_QUEUE_SERVICE_TOKEN = 'XPERT_MANAGED_QUEUE_SERVICE';
const MANAGED_QUEUE_HANDLER_REGISTRY_TOKEN = 'XPERT_MANAGED_QUEUE_HANDLER_REGISTRY';
const PLUGIN_JOB_PROCESSOR_METADATA = 'XPERT_PLUGIN_JOB_PROCESSOR_METADATA';
function PluginJobProcessor(options) {
    return (target)=>{
        const metadata = normalizePluginJobProcessorMetadata(options);
        var _Reflect_getMetadata;
        const existing = (_Reflect_getMetadata = Reflect.getMetadata(PLUGIN_JOB_PROCESSOR_METADATA, target)) != null ? _Reflect_getMetadata : [];
        Reflect.defineMetadata(PLUGIN_JOB_PROCESSOR_METADATA, [
            metadata,
            ...existing
        ], target);
    };
}
function normalizePluginJobProcessorMetadata(options) {
    const pluginName = requireManagedQueueDecoratorValue(options.pluginName, 'pluginName');
    var _options_queueName;
    const queueName = requireManagedQueueDecoratorValue((_options_queueName = options.queueName) != null ? _options_queueName : options.queue, 'queueName');
    var _options_jobName;
    const jobName = requireManagedQueueDecoratorValue((_options_jobName = options.jobName) != null ? _options_jobName : options.jobType, 'jobName');
    const concurrency = options.concurrency;
    if (concurrency !== undefined && (!Number.isFinite(concurrency) || concurrency <= 0)) {
        throw new Error('PluginJobProcessor concurrency must be a positive number');
    }
    return _extends({
        pluginName,
        queueName,
        jobName
    }, options.controlContract === undefined ? {} : {
        controlContract: requireManagedQueueDecoratorValue(options.controlContract, 'controlContract')
    }, concurrency === undefined ? {} : {
        concurrency: Math.trunc(concurrency)
    });
}
function requireManagedQueueDecoratorValue(value, field) {
    const normalized = `${value != null ? value : ''}`.trim();
    if (!normalized) {
        throw new Error(`PluginJobProcessor ${field} is required`);
    }
    return normalized;
}

const VIEW_EXTENSION_PROVIDER = 'VIEW_EXTENSION_PROVIDER';
const ViewExtensionProvider = (providerKey)=>applyDecorators(SetMetadata(VIEW_EXTENSION_PROVIDER, providerKey), SetMetadata(STRATEGY_META_KEY, VIEW_EXTENSION_PROVIDER));

let ViewExtensionProviderRegistry = class ViewExtensionProviderRegistry extends BaseStrategyRegistry {
    listEntries(organizationId) {
        const entries = new Map();
        for (const scopeKey of this.resolveStrategyScopeKeys(organizationId)){
            var _this_strategies_get;
            var _this_strategies_get_entries;
            for (const [providerKey, provider] of (_this_strategies_get_entries = (_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.entries()) != null ? _this_strategies_get_entries : []){
                if (!entries.has(providerKey)) {
                    entries.set(providerKey, provider);
                }
            }
        }
        return Array.from(entries.entries()).map(([providerKey, provider])=>({
                providerKey,
                provider
            }));
    }
    constructor(discoveryService, reflector){
        super(VIEW_EXTENSION_PROVIDER, discoveryService, reflector);
    }
};
ViewExtensionProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ViewExtensionProviderRegistry);

const XPERT_REMOTE_UI_CSS = `
:root {
  font-size: var(--xui-density-root-font-size, 16px);
  color-scheme: light;
  --xui-font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  --xui-color-background: #fff;
  --xui-color-foreground: #18181b;
  --xui-color-card: #fff;
  --xui-color-card-foreground: #18181b;
  --xui-color-popover: var(--xui-color-card);
  --xui-color-popover-foreground: var(--xui-color-card-foreground);
  --xui-color-secondary: #f4f4f5;
  --xui-color-secondary-foreground: #18181b;
  --xui-color-muted: #f4f4f5;
  --xui-color-muted-foreground: #71717a;
  --xui-color-accent: #f4f4f5;
  --xui-color-accent-foreground: #18181b;
  --xui-color-border: #e4e4e7;
  --xui-color-input: #d4d4d8;
  --xui-color-primary: #18181b;
  --xui-color-primary-foreground: #fff;
  --xui-color-ring: var(--xui-color-primary);
  --xui-color-destructive: #dc2626;
  --xui-color-destructive-foreground: #fff;
  --xui-color-destructive-background: #fef2f2;
  --xui-color-success: #047857;
  --xui-color-success-background: #ecfdf5;
  --xui-color-warning: #b45309;
  --xui-color-info: #2563eb;
  --xui-color-chart-1: var(--xui-color-primary);
  --xui-color-chart-2: var(--xui-color-success);
  --xui-color-chart-3: var(--xui-color-warning);
  --xui-color-chart-4: var(--xui-color-destructive);
  --xui-color-chart-5: #7c3aed;
  --xui-radius-sm: 6px;
  --xui-radius-md: 8px;
  --xui-radius-lg: 10px;
  --xui-font-size: 14px;
  --xui-font-size-xs: 0.75rem;
  --xui-font-size-sm: 0.8125rem;
  --xui-font-size-md: 0.875rem;
  --xui-font-size-lg: 1rem;
  --xui-font-size-control: var(--xui-font-size-sm);
  --xui-font-size-button: var(--xui-font-size-sm);
  --xui-font-size-table: var(--xui-font-size-sm);
  --xui-control-height: 2rem;
  --xui-button-height: 2rem;
  --xui-button-height-sm: 1.75rem;
  --xui-shadow-dialog: 0 20px 50px rgba(24, 24, 27, 0.22);
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: var(--xui-color-background);
  color: var(--xui-color-foreground);
  font-family: var(--xui-font-family);
  font-size: var(--xui-font-size-md);
}

button,
input,
select,
textarea {
  font: inherit;
}

button {
  cursor: pointer;
}

button:disabled,
input:disabled,
select:disabled,
textarea:disabled {
  cursor: not-allowed;
  opacity: 0.56;
}

.xui-app {
  min-height: 420px;
  padding: 2px;
}

.xui-toolbar {
  display: grid;
  grid-template-columns: minmax(160px, 240px) minmax(160px, 240px) minmax(180px, 1fr) auto auto;
  gap: 8px;
  align-items: center;
  margin-bottom: 12px;
}

.xui-control,
.xui-input,
.xui-textarea {
  width: 100%;
  min-width: 0;
  border: 1px solid var(--xui-color-input);
  border-radius: var(--xui-radius-md);
  background: var(--xui-color-card);
  color: var(--xui-color-card-foreground);
  outline: none;
}

.xui-control,
.xui-input {
  height: var(--xui-control-height);
  padding: 0 10px;
  font-size: var(--xui-font-size-control);
}

.xui-textarea {
  min-height: 84px;
  padding: 8px 10px;
  resize: vertical;
  font-size: var(--xui-font-size-control);
}

.xui-button {
  display: inline-flex;
  height: var(--xui-button-height);
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: 1px solid var(--xui-color-input);
  border-radius: var(--xui-radius-md);
  background: var(--xui-color-card);
  color: var(--xui-color-card-foreground);
  padding: 0 12px;
  font-size: var(--xui-font-size-button);
  white-space: nowrap;
}

.xui-button-primary {
  border-color: var(--xui-color-primary);
  background: var(--xui-color-primary);
  color: var(--xui-color-primary-foreground);
}

.xui-button-danger {
  border-color: color-mix(in srgb, var(--xui-color-destructive) 32%, transparent);
  color: var(--xui-color-destructive);
}

.xui-button-sm {
  height: var(--xui-button-height-sm);
  padding: 0 8px;
  font-size: var(--xui-font-size-xs);
}

.xui-notice {
  display: flex;
  align-items: center;
  min-height: 36px;
  margin-bottom: 12px;
  border: 1px solid var(--xui-color-border);
  border-radius: var(--xui-radius-md);
  padding: 8px 10px;
  color: var(--xui-color-muted-foreground);
  background: var(--xui-color-muted);
  font-size: var(--xui-font-size-sm);
}

.xui-notice-error {
  border-color: color-mix(in srgb, var(--xui-color-destructive) 32%, transparent);
  color: var(--xui-color-destructive);
  background: var(--xui-color-destructive-background);
}

.xui-table-wrap {
  overflow: auto;
  border: 1px solid var(--xui-color-border);
  border-radius: var(--xui-radius-md);
}

.xui-table {
  width: 100%;
  min-width: 880px;
  border-collapse: collapse;
}

.xui-table th,
.xui-table td {
  border-bottom: 1px solid var(--xui-color-border);
  padding: 10px;
  text-align: left;
  vertical-align: middle;
  font-size: var(--xui-font-size-table);
}

.xui-table th {
  background: var(--xui-color-muted);
  color: var(--xui-color-muted-foreground);
  font-weight: 600;
}

.xui-table tr:last-child td {
  border-bottom: 0;
}

.xui-muted {
  color: var(--xui-color-muted-foreground);
}

.xui-pill {
  display: inline-flex;
  align-items: center;
  border: 1px solid var(--xui-color-border);
  border-radius: 999px;
  padding: 2px 8px;
  font-size: var(--xui-font-size-xs);
  color: var(--xui-color-muted-foreground);
  background: var(--xui-color-muted);
}

.xui-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.xui-pager {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 12px;
  color: var(--xui-color-muted-foreground);
  font-size: var(--xui-font-size-sm);
}

.xui-empty {
  display: grid;
  min-height: 180px;
  place-items: center;
  color: var(--xui-color-muted-foreground);
  font-size: var(--xui-font-size-md);
}

.xui-modal-backdrop {
  position: fixed;
  inset: 0;
  display: grid;
  place-items: center;
  background: rgba(24, 24, 27, 0.32);
  padding: 16px;
}

.xui-modal {
  width: min(720px, 100%);
  max-height: calc(100vh - 32px);
  overflow: auto;
  border-radius: var(--xui-radius-lg);
  background: var(--xui-color-card);
  color: var(--xui-color-card-foreground);
  box-shadow: var(--xui-shadow-dialog);
}

.xui-modal-header,
.xui-modal-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 16px;
  border-bottom: 1px solid var(--xui-color-border);
}

.xui-modal-footer {
  border-top: 1px solid var(--xui-color-border);
  border-bottom: 0;
}

.xui-modal-title {
  margin: 0;
  font-size: var(--xui-font-size-lg);
  font-weight: 700;
}

.xui-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  padding: 16px;
}

.xui-field {
  display: grid;
  gap: 6px;
}

.xui-field-full {
  grid-column: 1 / -1;
}

.xui-field label {
  color: var(--xui-color-muted-foreground);
  font-size: var(--xui-font-size-xs);
  font-weight: 600;
}

.xui-checkbox {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: var(--xui-color-card-foreground);
  font-size: var(--xui-font-size-sm);
}

@media (max-width: 760px) {
  .xui-toolbar,
  .xui-form {
    grid-template-columns: 1fr;
  }
}
`;
const XPERT_REMOTE_UI_BOOTSTRAP = `
(function () {
  var CHANNEL = 'xpertai.remote_component'
  var VERSION = 1
  var TOKEN_MAP = {
    fontFamily: '--xui-font-family',
    densityRootFontSize: '--xui-density-root-font-size',
    colorBackground: '--xui-color-background',
    colorForeground: '--xui-color-foreground',
    colorCard: '--xui-color-card',
    colorCardForeground: '--xui-color-card-foreground',
    colorPopover: '--xui-color-popover',
    colorPopoverForeground: '--xui-color-popover-foreground',
    colorSecondary: '--xui-color-secondary',
    colorSecondaryForeground: '--xui-color-secondary-foreground',
    colorMuted: '--xui-color-muted',
    colorMutedForeground: '--xui-color-muted-foreground',
    colorAccent: '--xui-color-accent',
    colorAccentForeground: '--xui-color-accent-foreground',
    colorBorder: '--xui-color-border',
    colorInput: '--xui-color-input',
    colorPrimary: '--xui-color-primary',
    colorPrimaryForeground: '--xui-color-primary-foreground',
    colorRing: '--xui-color-ring',
    colorDestructive: '--xui-color-destructive',
    colorDestructiveForeground: '--xui-color-destructive-foreground',
    colorDestructiveBackground: '--xui-color-destructive-background',
    colorSuccess: '--xui-color-success',
    colorSuccessBackground: '--xui-color-success-background',
    colorWarning: '--xui-color-warning',
    colorInfo: '--xui-color-info',
    colorChart1: '--xui-color-chart-1',
    colorChart2: '--xui-color-chart-2',
    colorChart3: '--xui-color-chart-3',
    colorChart4: '--xui-color-chart-4',
    colorChart5: '--xui-color-chart-5',
    radiusSm: '--xui-radius-sm',
    radiusMd: '--xui-radius-md',
    radiusLg: '--xui-radius-lg',
    fontSize: '--xui-font-size',
    fontSizeXs: '--xui-font-size-xs',
    fontSizeSm: '--xui-font-size-sm',
    fontSizeMd: '--xui-font-size-md',
    fontSizeLg: '--xui-font-size-lg',
    fontSizeControl: '--xui-font-size-control',
    fontSizeButton: '--xui-font-size-button',
    fontSizeTable: '--xui-font-size-table',
    controlHeight: '--xui-control-height',
    buttonHeight: '--xui-button-height',
    buttonHeightSm: '--xui-button-height-sm'
  }

  function isObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
  }

  function applyTheme(theme) {
    var mode = typeof theme === 'string' ? theme : isObject(theme) ? theme.mode : null
    var tokens = isObject(theme) && isObject(theme.tokens) ? theme.tokens : {}
    if (mode === 'dark') {
      document.documentElement.dataset.theme = 'dark'
      document.documentElement.style.colorScheme = 'dark'
    } else {
      document.documentElement.dataset.theme = 'light'
      document.documentElement.style.colorScheme = 'light'
    }
    Object.keys(TOKEN_MAP).forEach(function (key) {
      var value = tokens[key]
      if (typeof value === 'string' && value.trim()) {
        document.documentElement.style.setProperty(TOKEN_MAP[key], value.trim())
      }
    })
  }

  window.XpertRemoteUI = {
    applyTheme: applyTheme
  }

  window.addEventListener('message', function (event) {
    var message = event.data
    if (
      !isObject(message) ||
      message.channel !== CHANNEL ||
      message.protocolVersion !== VERSION ||
      message.type !== 'init'
    ) {
      return
    }
    applyTheme(message.theme)
  })
})()
`;
function renderRemoteReactIframeHtml(options) {
    var _options_lang, _options_appCss;
    return `<!doctype html>
<html lang="${escapeHtmlAttribute((_options_lang = options.lang) != null ? _options_lang : 'en')}">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${escapeHtml(options.title)}</title>
    <style>
${XPERT_REMOTE_UI_CSS}
${(_options_appCss = options.appCss) != null ? _options_appCss : ''}
    </style>
    <script>
${escapeInlineScript(options.reactUmd)}
    </script>
    <script>
${escapeInlineScript(options.reactDomUmd)}
    </script>
    <script>
${XPERT_REMOTE_UI_BOOTSTRAP}
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script>
${escapeInlineScript(options.appScript)}
    </script>
  </body>
</html>`;
}
function renderRemoteModuleIframeHtml(options) {
    var _options_lang, _options_appCss;
    return `<!doctype html>
<html lang="${escapeHtmlAttribute((_options_lang = options.lang) != null ? _options_lang : 'en')}">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${escapeHtml(options.title)}</title>
    <style>
${XPERT_REMOTE_UI_CSS}
${(_options_appCss = options.appCss) != null ? _options_appCss : ''}
    </style>
    <script>
${XPERT_REMOTE_UI_BOOTSTRAP}
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module">
${escapeInlineScript(options.appScript)}
    </script>
  </body>
</html>`;
}
function renderRemoteVueIframeHtml(options) {
    return renderRemoteModuleIframeHtml(options);
}
function escapeHtml(value) {
    return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function escapeHtmlAttribute(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
}
function escapeInlineScript(value) {
    return value.replace(/<\/script/gi, '<\\/script');
}

const VIEW_EXTENSION_CACHE_SERVICE_TOKEN = 'XPERT_PLUGIN_VIEW_EXTENSION_CACHE_SERVICE';

const ViewMiddlewareRuntimeCapability = createRuntimeCapability('platform.view.middleware-runtime', {
    description: 'Resolve a View capability through its authorized Assistant middleware and scoped runtime.'
});

/**
 * Lets a plugin's server-side View provider submit a human decision during an authorized
 * assistant or project workbench action. The host takes the actor and plugin identity from
 * the current action and routes the submission to their active source binding.
 * The event source checks who can decide the business matter and records the choice.
 */ const WorkbenchDecisionCapability = createRuntimeCapability('platform.view.workbench-decision');

const ARTIFACT_PRESENTATION_PROVIDER = 'ARTIFACT_PRESENTATION_PROVIDER';
const artifactPresentationKey = (source)=>`${source.pluginName}:${source.resourceType}`;
/** Registers a read-only renderer for an explicit Artifact source, independently of Workbench actions. */ const ArtifactPresentationProvider = (source)=>applyDecorators(SetMetadata(ARTIFACT_PRESENTATION_PROVIDER, artifactPresentationKey(source)), SetMetadata(STRATEGY_META_KEY, ARTIFACT_PRESENTATION_PROVIDER));
let ArtifactPresentationRegistry = class ArtifactPresentationRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(ARTIFACT_PRESENTATION_PROVIDER, discovery, reflector);
    }
};
ArtifactPresentationRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ArtifactPresentationRegistry);

/** Package exports are a runtime boundary; reject malformed declarations before registration. */ const artifactTypeDefinitionSchema = z.object({
    contentTypeId: z.string().trim().min(1).max(200).optional(),
    icon: iconDefinitionSchema.optional(),
    title: z.object({
        en_US: z.string().trim().min(1).max(200),
        zh_Hans: z.string().trim().min(1).max(200).optional(),
        zh_Hant: z.string().trim().min(1).max(200).optional()
    }).strict().optional(),
    kinds: z.array(z.enum([
        'html',
        'markdown',
        'pdf',
        'pptx',
        'image',
        'file',
        'site',
        'presentation'
    ])).min(1),
    collection: z.object({
        allowCopy: z.boolean()
    }).strict().optional(),
    useGrants: z.object({
        audience: z.literal('group'),
        permission: z.literal('read'),
        queryOperations: z.array(z.string().min(1).max(80)).max(32).optional()
    }).strict().optional(),
    versioning: z.object({
        mode: z.literal('draft-only')
    }).strict().optional(),
    content: z.object({
        mimeTypes: z.array(z.string().min(1)).min(1),
        maxBytes: z.number().int().positive()
    }).strict().optional(),
    sharing: z.object({
        projectAccess: z.literal('link-audience').optional(),
        accessModes: z.array(z.enum([
            'owner_only',
            'workspace_all',
            'organization_all',
            'custom_principals',
            'public_link',
            'signed_preview'
        ])).min(1),
        versionModes: z.array(z.enum([
            'latest',
            'version'
        ])).min(1),
        maxTtlSeconds: z.number().int().positive().optional(),
        allowDownload: z.boolean(),
        mutableLinks: z.boolean(),
        descriptor: z.boolean(),
        shareKey: z.string().min(1).optional()
    }).strict().optional(),
    presentation: z.object({
        mode: z.enum([
            'file',
            'snapshot',
            'authenticated'
        ])
    }).strict()
}).strict().refine((definition)=>!definition.useGrants || definition.presentation.mode === 'authenticated', 'Group use grants require an authenticated presentation').refine((definition)=>{
    var _definition_sharing;
    return ((_definition_sharing = definition.sharing) == null ? void 0 : _definition_sharing.projectAccess) !== 'link-audience' || definition.presentation.mode === 'authenticated' && definition.sharing.accessModes.every((mode)=>[
            'organization_all',
            'workspace_all'
        ].includes(mode));
}, 'Project link audiences require authenticated organization or workspace sharing');

const artifactTypeKey = (type)=>JSON.stringify([
        type.pluginName,
        type.resourceType
    ]);
const FILE_ARTIFACT_TYPE = {
    pluginName: '@xpert-ai/platform',
    resourceType: 'file'
};
/** Bindings pin registration scope. Removal never falls back to a different installation or plain file. */ let ArtifactTypeRegistry = class ArtifactTypeRegistry extends BaseStrategyRegistry {
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        const resourceType = target ? this.reflector.get(ARTIFACT_TYPE_PROVIDER, target) : undefined;
        if (!resourceType) return;
        const provider = instance;
        const source = this.getSource(provider);
        // Built-ins are explicitly composed by the host, never inferred from missing loader metadata.
        if (source.kind !== 'plugin') return;
        this.register(artifactTypeKey({
            pluginName: source.pluginName,
            resourceType
        }), provider, source);
    }
    registerBuiltin(type, provider) {
        this.register(artifactTypeKey(type), provider, {
            kind: 'builtin',
            scopeKey: BUILTIN_GLOBAL_SCOPE
        });
    }
    assertCanRegister(key, provider, source) {
        var _provider_snapshot, _this_strategies_get;
        if (!(provider == null ? void 0 : provider.definition) || typeof provider.authorize !== 'function' || typeof provider.validateContent !== 'function') throw new Error('ARTIFACT_TYPE_INVALID');
        artifactTypeDefinitionSchema.parse(provider.definition);
        if (provider.analytics && (typeof provider.analytics.resolveBindings !== 'function' || provider.analytics.normalizeControls !== undefined && typeof provider.analytics.normalizeControls !== 'function')) throw new Error('ARTIFACT_TYPE_ANALYTICS_INVALID');
        const identity = JSON.parse(key);
        if (!Array.isArray(identity) || identity.length !== 2 || identity.some((value)=>typeof value !== 'string' || !value.trim())) throw new Error('ARTIFACT_TYPE_INVALID');
        if (source.kind === 'plugin' && (identity[0] !== source.pluginName || source.pluginName === '@xpert-ai/platform')) throw new Error('ARTIFACT_TYPE_NAMESPACE_DENIED');
        if (source.kind === 'plugin' && ((_provider_snapshot = provider.snapshot) == null ? void 0 : _provider_snapshot.kind) === 'host') throw new Error('ARTIFACT_TYPE_HOST_VIEW_DENIED');
        if (provider.definition.presentation.mode === 'snapshot' && !provider.snapshot) throw new Error('ARTIFACT_TYPE_SNAPSHOT_REQUIRED');
        if (provider.snapshot && (provider.definition.presentation.mode !== 'snapshot' || typeof provider.snapshot.read !== 'function' || provider.snapshot.kind === 'plugin' && typeof provider.snapshot.getEntry !== 'function')) throw new Error('ARTIFACT_TYPE_INVALID');
        const existing = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(key);
        if (existing && existing !== provider) {
            const owner = this.getSource(existing);
            if (owner.kind !== source.kind || source.kind === 'builtin' || owner.kind === 'plugin' && source.kind === 'plugin' && owner.pluginName !== source.pluginName) throw new Error('ARTIFACT_TYPE_CONFLICT');
        }
        for (const [scope, entries] of this.strategies){
            if ([
                ...entries.values()
            ].includes(provider) && scope !== source.scopeKey) throw new Error('ARTIFACT_TYPE_SCOPE_CONFLICT');
        }
        super.assertCanRegister(key, provider, source);
    }
    bind(type, scope) {
        var _this_strategies_get;
        if (!scope.tenantId) throw new Error('ARTIFACT_TYPE_SCOPE_REQUIRED');
        const tenantScope = scope.tenantId === getDefaultTenantId() ? GLOBAL_ORGANIZATION_SCOPE : getTenantGlobalScopeKey(scope.tenantId);
        const scopes = [
            ...new Set([
                scope.organizationId,
                tenantScope,
                SYSTEM_GLOBAL_SCOPE,
                BUILTIN_GLOBAL_SCOPE
            ].filter(Boolean))
        ];
        const key = artifactTypeKey(type);
        for (const scopeKey of scopes)if ((_this_strategies_get = this.strategies.get(scopeKey)) == null ? void 0 : _this_strategies_get.has(key)) return _extends({}, type, {
            scopeKey
        });
        throw new Error('ARTIFACT_TYPE_UNAVAILABLE');
    }
    hasType(type, scope) {
        try {
            this.bind(type, scope);
            return true;
        } catch (e) {
            return false;
        }
    }
    requireBinding(binding, scope) {
        var _this_strategies_get;
        if (!binding || !scope.tenantId) throw new Error('ARTIFACT_TYPE_UNAVAILABLE');
        const tenantScope = scope.tenantId === getDefaultTenantId() ? GLOBAL_ORGANIZATION_SCOPE : getTenantGlobalScopeKey(scope.tenantId);
        if (![
            scope.organizationId,
            tenantScope,
            SYSTEM_GLOBAL_SCOPE,
            BUILTIN_GLOBAL_SCOPE
        ].includes(binding.scopeKey)) throw new Error('ARTIFACT_TYPE_SCOPE_DENIED');
        const provider = (_this_strategies_get = this.strategies.get(binding.scopeKey)) == null ? void 0 : _this_strategies_get.get(artifactTypeKey(binding));
        if (!provider) throw new Error('ARTIFACT_TYPE_UNAVAILABLE');
        return provider;
    }
    constructor(discovery, reflector){
        super(ARTIFACT_TYPE_PROVIDER, discovery, reflector);
    }
};
ArtifactTypeRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ArtifactTypeRegistry);

const ARTIFACT_TYPE_PROVIDER = 'XPERT_ARTIFACT_TYPE_PROVIDER';
/** The loader supplies plugin identity. A contribution cannot select another plugin's namespace. */ const ArtifactTypeProvider = (resourceType)=>applyDecorators(SetMetadata(ARTIFACT_TYPE_PROVIDER, resourceType), SetMetadata(STRATEGY_META_KEY, ARTIFACT_TYPE_PROVIDER));

/** Platform-owned real-time collaboration capability available to scoped plugin runtimes. */ const CollaborationRuntimeCapability = createRuntimeCapability('platform.collaboration', {
    description: 'Create, synchronize, persist, authorize, and observe platform-managed real-time collaboration documents.'
});

const COLLABORATION_DOCUMENT_PROVIDER = 'COLLABORATION_DOCUMENT_PROVIDER';
/** Register a plugin adapter for one stable collaboration resource type. */ const CollaborationDocumentProvider = (providerKey)=>applyDecorators(SetMetadata(COLLABORATION_DOCUMENT_PROVIDER, providerKey), SetMetadata(STRATEGY_META_KEY, COLLABORATION_DOCUMENT_PROVIDER));

/** Discovers system and organization-scoped collaboration providers from loaded plugins. */ let CollaborationDocumentProviderRegistry = class CollaborationDocumentProviderRegistry extends BaseStrategyRegistry {
    constructor(discoveryService, reflector){
        super(COLLABORATION_DOCUMENT_PROVIDER, discoveryService, reflector);
    }
};
CollaborationDocumentProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], CollaborationDocumentProviderRegistry);

const ContentDocumentsRuntimeCapability = createRuntimeCapability('platform.content.documents', {
    description: 'Project file-backed editor sessions, versioned publication and Assistant review.'
});

const ContentReferencesRuntimeCapability = createRuntimeCapability('platform.content.references', {
    description: 'Authorized durable document references; plugins provide source-specific listing and files.'
});

/** Matching semantic type alone never grants a writer access to an incompatible native model. */ function supportsContentModel(editor, model, access) {
    return editor.supports.some((item)=>item.typeId === model.typeId && item.modelId === model.modelId && item.schemaVersion === model.schemaVersion && item.editProtocol.id === model.editProtocol.id && item.editProtocol.version === model.editProtocol.version && item.access.includes(access));
}

function isTextContentEditor(provider) {
    return provider.descriptor.kind === 'text-document';
}
function isFileContentEditor(provider) {
    return provider.descriptor.kind === 'file';
}
function isResourceContentEditor(provider) {
    return provider.descriptor.kind === 'resource';
}
const EDITOR_PROVIDER = 'XPERT_CONTENT_EDITOR_PROVIDER';
const ContentEditorProvider = (key)=>applyDecorators(SetMetadata(EDITOR_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, EDITOR_PROVIDER));
let ContentEditorRegistry = class ContentEditorRegistry extends BaseStrategyRegistry {
    getTextModel(key, organizationId) {
        const provider = this.get(key, organizationId);
        if (!isTextContentEditor(provider)) throw new Error('Editor does not implement the text document protocol');
        return provider;
    }
    constructor(discovery, reflector){
        super(EDITOR_PROVIDER, discovery, reflector);
    }
};
ContentEditorRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ContentEditorRegistry);
const ContentEditorsRuntimeCapability = createRuntimeCapability('platform.content.editors', {
    description: 'Discover editors, resolve authorized resources and exchange versioned file bytes without format-specific models.'
});

const CONTENT_RESOURCE_PROVIDER = 'XPERT_CONTENT_RESOURCE_PROVIDER';
const ContentResourceProvider = (key)=>applyDecorators(SetMetadata(CONTENT_RESOURCE_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, CONTENT_RESOURCE_PROVIDER));
let ContentResourceProviderRegistry = class ContentResourceProviderRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(CONTENT_RESOURCE_PROVIDER, discovery, reflector);
    }
};
ContentResourceProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ContentResourceProviderRegistry);
const ContentResourcesRuntimeCapability = createRuntimeCapability('platform.content.resources', {
    description: 'Current organization identities and plugin-owned content authorization.'
});

const EVOLUTION_TARGET_PROVIDER = 'EVOLUTION_TARGET_PROVIDER';
/** Declares the stable registration key of an evolution target provider. */ const EvolutionTargetProviderStrategy = (providerKey)=>applyDecorators(SetMetadata(EVOLUTION_TARGET_PROVIDER, providerKey), SetMetadata(STRATEGY_META_KEY, EVOLUTION_TARGET_PROVIDER));

/** Registry of evolution targets visible within a strategy scope. */ let EvolutionTargetProviderRegistry = class EvolutionTargetProviderRegistry extends BaseStrategyRegistry {
    /** Returns target declarations visible in the supplied organization scope. */ listDescriptors(organizationId) {
        return this.list(organizationId).map((provider)=>provider.descriptor);
    }
    constructor(discoveryService, reflector){
        super(EVOLUTION_TARGET_PROVIDER, discoveryService, reflector);
    }
};
EvolutionTargetProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], EvolutionTargetProviderRegistry);

const EVOLUTION_RUNTIME_SERVICE_TOKEN = 'XPERT_EVOLUTION_RUNTIME_SERVICE';
const ExecutionReviewRuntimeCapability = createRuntimeCapability('platform.agent-evolution.execution-review', {
    description: 'Human review of executions within the authorized project and Assistant.'
});
/** Capability for inspecting and publishing source baselines within an authorized organization. */ const EvolutionBaselineRuntimeCapability = createRuntimeCapability('platform.agent-evolution.baselines', {
    description: 'Inspect and initialize organization rule baselines with administrator authorization and revision checks.'
});
/** Capability for version selection and evidence tied to Agent executions. */ const EvolutionRuntimeCapability = createRuntimeCapability('platform.agent-evolution', {
    description: 'Ingest learning signals and resolve immutable capability versions for domain runtimes.'
});
/** Capability for scoped preparation, review and publication of versioned changes. */ const EvolutionChangeRuntimeCapability = createRuntimeCapability('platform.agent-evolution.changes', {
    description: 'Prepare, evaluate and publish versioned changes through target-owned validators and effect providers.'
});

/** Returns the sha256-prefixed hex digest of the canonical JSON value. */ function hashEvolutionValue(value) {
    return `sha256:${createHash('sha256').update(canonicalEvolutionJson(value)).digest('hex')}`;
}
/** Serializes JSON with object keys in sorted order and array elements in their original order. */ function canonicalEvolutionJson(value) {
    if (value === null || typeof value === 'boolean' || typeof value === 'number' || typeof value === 'string') {
        return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
        return `[${value.map((item)=>canonicalEvolutionJson(item)).join(',')}]`;
    }
    return `{${Object.keys(value).sort().map((key)=>`${JSON.stringify(key)}:${canonicalEvolutionJson(value[key])}`).join(',')}}`;
}

function defineMcpApp(definition) {
    return Object.freeze(definition);
}

const MCP_CAPABILITY_CHANGE_EVENT_TYPES = [
    'tools.changed',
    'resources.changed',
    'resource.updated',
    'prompts.changed',
    'task.updated'
];

function defineMcpPrompt(definition) {
    return Object.freeze(definition);
}

function defineMcpResource(definition) {
    return Object.freeze(definition);
}

function defineMcpResourceTemplate(definition) {
    return Object.freeze(definition);
}

function defineMcpCapabilities(definitions) {
    return Object.freeze({
        instructions: definitions.instructions,
        tools: freezeItems(definitions.tools),
        resources: freezeItems(definitions.resources),
        resourceTemplates: freezeItems(definitions.resourceTemplates),
        prompts: freezeItems(definitions.prompts),
        apps: freezeItems(definitions.apps)
    });
}
function freezeItems(items) {
    return items ? Object.freeze([
        ...items
    ]) : undefined;
}

const XPERT_TOOL_PROVIDER = 'XPERT_TOOL_PROVIDER';
const XPERT_TOOL_PROVIDER_METADATA = 'XPERT_TOOL_PROVIDER_METADATA';
const XPERT_TOOL_METHOD_METADATA = 'XPERT_TOOL_METHOD_METADATA';
/** Marks one injectable business service as a shared Tool, Resource and Prompt provider. */ const XpertToolProvider = (options)=>applyDecorators(Injectable(), SetMetadata(XPERT_TOOL_PROVIDER, options.provider), SetMetadata(XPERT_TOOL_PROVIDER_METADATA, Object.freeze(_extends({}, options))), SetMetadata(STRATEGY_META_KEY, XPERT_TOOL_PROVIDER));
/** Exposes one business method through an Agent Middleware, native MCP, or both. */ const XpertTool = (options)=>SetMetadata(XPERT_TOOL_METHOD_METADATA, Object.freeze(_extends({}, options)));

/** Child overrides hide parent declarations, including undecorated overrides and accessors. */ function collectProviderMethods(instance) {
    const methods = [];
    const seen = new Set();
    let prototype = Object.getPrototypeOf(instance);
    while(prototype && prototype !== Object.prototype){
        for (const methodName of Object.getOwnPropertyNames(prototype)){
            var _Object_getOwnPropertyDescriptor;
            if (methodName === 'constructor' || seen.has(methodName)) continue;
            seen.add(methodName);
            const method = (_Object_getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor(prototype, methodName)) == null ? void 0 : _Object_getOwnPropertyDescriptor.value;
            if (typeof method === 'function') methods.push({
                methodName,
                method
            });
        }
        prototype = Object.getPrototypeOf(prototype);
    }
    return methods;
}

const MCP_METHOD_METADATA = 'XPERT_MCP_METHOD_METADATA';
/** The decorated method receives ResourceReadContext and returns McpResourceReadResult. */ const XpertResource = (options)=>SetMetadata(MCP_METHOD_METADATA, {
        kind: 'resource',
        options: Object.freeze(_extends({}, options))
    });
/** The decorated method receives URI arguments and ResourceReadContext. */ const XpertResourceTemplate = (options)=>SetMetadata(MCP_METHOD_METADATA, {
        kind: 'resource-template',
        options: Object.freeze(_extends({}, options))
    });
/** The decorated method receives prompt arguments and ToolExecutionContext. */ const XpertPrompt = (options)=>SetMetadata(MCP_METHOD_METADATA, {
        kind: 'prompt',
        options: Object.freeze(_extends({}, options))
    });
function describeXpertMcpMethods(instance) {
    const result = [];
    for (const { methodName, method } of collectProviderMethods(instance)){
        var _metadata_options_uri, _metadata_options_uriTemplate, _metadata_options_name;
        const metadata = Reflect.getMetadata(MCP_METHOD_METADATA, method);
        if (!metadata) continue;
        const { options } = metadata;
        if (!/^[A-Za-z0-9_-]{1,191}$/.test(options.key)) throw new Error(`Invalid MCP capability key '${options.key}'.`);
        var _options_requiredContext;
        const contexts = (_options_requiredContext = options.requiredContext) != null ? _options_requiredContext : [];
        if (new Set(contexts).size !== contexts.length || contexts.some((context)=>!MCP_REQUIRED_CONTEXTS.includes(context))) {
            throw new Error(`MCP capability '${options.key}' declares invalid execution contexts.`);
        }
        if (metadata.kind === 'resource' && !((_metadata_options_uri = metadata.options.uri) == null ? void 0 : _metadata_options_uri.trim())) {
            throw new Error(`Resource '${options.key}' requires a URI.`);
        }
        if (metadata.kind === 'resource-template' && !((_metadata_options_uriTemplate = metadata.options.uriTemplate) == null ? void 0 : _metadata_options_uriTemplate.trim())) {
            throw new Error(`Resource template '${options.key}' requires a URI template.`);
        }
        if (metadata.kind === 'prompt' && !((_metadata_options_name = metadata.options.name) == null ? void 0 : _metadata_options_name.trim())) {
            throw new Error(`Prompt '${options.key}' requires a name.`);
        }
        if (metadata.kind !== 'resource' && metadata.options.completionMethod) {
            callable(instance, metadata.options.completionMethod);
        }
        result.push(Object.freeze(_extends({}, metadata, {
            methodName
        })));
    }
    return Object.freeze(result);
}
/** One catalog for runtime publication and fingerprinting; legacy declarations remain supported. */ function resolveXpertMcpExtensions(instance, descriptor) {
    const legacy = 'getMcpExtensions' in instance && typeof instance.getMcpExtensions === 'function' ? instance.getMcpExtensions == null ? void 0 : instance.getMcpExtensions.call(instance) : undefined;
    var _legacy_resources;
    const resources = [
        ...(_legacy_resources = legacy == null ? void 0 : legacy.resources) != null ? _legacy_resources : []
    ];
    var _legacy_resourceTemplates;
    const resourceTemplates = [
        ...(_legacy_resourceTemplates = legacy == null ? void 0 : legacy.resourceTemplates) != null ? _legacy_resourceTemplates : []
    ];
    var _legacy_prompts;
    const prompts = [
        ...(_legacy_prompts = legacy == null ? void 0 : legacy.prompts) != null ? _legacy_prompts : []
    ];
    var _descriptor_mcpMethods;
    for (const _ref of (_descriptor_mcpMethods = descriptor == null ? void 0 : descriptor.mcpMethods) != null ? _descriptor_mcpMethods : describeXpertMcpMethods(instance)){
        let definition = _ref;
        const method = callable(instance, definition.methodName);
        switch(definition.kind){
            case 'resource':
                resources.push(_extends({}, definition.options, {
                    read: method
                }));
                break;
            case 'resource-template':
                {
                    const _definition_options = definition.options, { completionMethod } = _definition_options, options = _object_without_properties_loose$2(_definition_options, [
                        "completionMethod"
                    ]);
                    resourceTemplates.push(_extends({}, options, {
                        read: method
                    }, completionMethod ? {
                        complete: callable(instance, completionMethod)
                    } : {}));
                    break;
                }
            case 'prompt':
                {
                    const _definition_options = definition.options, { completionMethod } = _definition_options, options = _object_without_properties_loose$2(_definition_options, [
                        "completionMethod"
                    ]);
                    prompts.push(_extends({}, options, {
                        get: method
                    }, completionMethod ? {
                        complete: callable(instance, completionMethod)
                    } : {}));
                    break;
                }
        }
    }
    assertUnique(resources, (item)=>item.key, 'resource key');
    assertUnique(resources, (item)=>item.uri, 'resource URI');
    assertUnique(resourceTemplates, (item)=>item.key, 'resource template key');
    assertUnique(resourceTemplates, (item)=>item.uriTemplate, 'resource template URI');
    assertUnique(prompts, (item)=>item.key, 'prompt key');
    assertUnique(prompts, (item)=>item.name, 'prompt name');
    return {
        resources,
        resourceTemplates,
        prompts
    };
}
function callable(instance, name) {
    var _collectProviderMethods_find;
    // Match discovery semantics: accessors and non-method overrides are not executable handlers.
    const method = (_collectProviderMethods_find = collectProviderMethods(instance).find((item)=>item.methodName === name)) == null ? void 0 : _collectProviderMethods_find.method;
    if (typeof method !== 'function') throw new Error(`MCP method '${name}' is not callable.`);
    return method.bind(instance);
}
function assertUnique(items, key, label) {
    const seen = new Set();
    for (const item of items){
        const value = key(item);
        if (seen.has(value)) throw new Error(`MCP ${label} '${value}' is declared more than once.`);
        seen.add(value);
    }
}

const PROVIDER_PATTERN = /^[a-z][a-z0-9_]*$/;
const MIDDLEWARE_PROVIDER_PATTERN = /^[A-Za-z][A-Za-z0-9_]*$/;
const COMPONENT_KEY_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const SLUG_PATTERN = COMPONENT_KEY_PATTERN;
const TOOL_NAME_PATTERN = /^[A-Za-z0-9_-]+$/;
function describeXpertToolProvider(instance) {
    const target = instance.constructor;
    const options = Reflect.getMetadata(XPERT_TOOL_PROVIDER_METADATA, target);
    if (!options) {
        throw new Error(`Provider '${target.name}' is missing @XpertToolProvider metadata.`);
    }
    validateProviderOptions(options);
    const methods = collectDecoratedMethods(instance);
    const names = new Set();
    var _options_middlewares;
    const middlewareProviders = new Set(((_options_middlewares = options.middlewares) != null ? _options_middlewares : []).map(({ provider })=>provider));
    var _options_apps;
    const appKeys = new Set(((_options_apps = options.apps) != null ? _options_apps : []).map(({ key })=>key));
    const tools = methods.map(({ methodName, options: toolOptions })=>{
        var _toolOptions_mcp_app;
        validateToolOptions(toolOptions, methodName);
        if (names.has(toolOptions.name)) {
            throw new Error(`Tool '${toolOptions.name}' is declared more than once by provider '${options.provider}'.`);
        }
        names.add(toolOptions.name);
        const middlewareProvider = resolveMiddlewareProvider(toolOptions, options);
        if (!middlewareProvider && !toolOptions.mcp) {
            throw new Error(`Tool '${toolOptions.name}' is not exposed through Middleware or MCP.`);
        }
        if (middlewareProvider && !middlewareProviders.has(middlewareProvider)) {
            throw new Error(`Tool '${toolOptions.name}' references undeclared Middleware provider '${middlewareProvider}'.`);
        }
        if (toolOptions.app) {
            if (!middlewareProvider || !toolOptions.app.visibility.length || toolOptions.app.visibility.some((item)=>item !== 'model' && item !== 'app') || toolOptions.app.resourceKey && (!appKeys.has(toolOptions.app.resourceKey) || !toolOptions.app.visibility.includes('app'))) {
                throw new Error(`Tool '${toolOptions.name}' has an invalid middleware App binding.`);
            }
        }
        const appKey = toolOptions.mcp && ((_toolOptions_mcp_app = toolOptions.mcp.app) == null ? void 0 : _toolOptions_mcp_app.resourceKey);
        if (appKey && !appKeys.has(appKey)) {
            throw new Error(`MCP Tool '${toolOptions.name}' references undeclared App '${appKey}'.`);
        }
        return Object.freeze({
            methodName,
            middlewareProvider,
            options: toolOptions
        });
    });
    const mcpMethods = describeXpertMcpMethods(instance);
    if (!tools.length && !mcpMethods.length) {
        throw new Error(`Provider '${options.provider}' does not declare any decorated capability methods.`);
    }
    return Object.freeze({
        options: Object.freeze(_extends({}, options)),
        tools: Object.freeze(tools),
        mcpMethods
    });
}
function collectDecoratedMethods(instance) {
    const result = [];
    for (const { methodName, method } of collectProviderMethods(instance)){
        const options = Reflect.getMetadata(XPERT_TOOL_METHOD_METADATA, method);
        if (options) result.push({
            methodName,
            options
        });
    }
    return result;
}
function validateProviderOptions(options) {
    var _options_name;
    if (!PROVIDER_PATTERN.test(options.provider)) {
        throw new Error(`Xpert Tool provider '${options.provider}' must use lowercase snake_case.`);
    }
    if (!COMPONENT_KEY_PATTERN.test(options.componentKey)) {
        throw new Error(`Xpert Tool component key '${options.componentKey}' must use lowercase kebab-case.`);
    }
    if (!((_options_name = options.name) == null ? void 0 : _options_name.trim())) throw new Error(`Xpert Tool provider '${options.provider}' requires a name.`);
    if (options.slug && !SLUG_PATTERN.test(options.slug)) {
        throw new Error(`Xpert Tool provider slug '${options.slug}' must use lowercase kebab-case.`);
    }
    const middlewareProviders = new Set();
    var _options_middlewares;
    for (const definition of (_options_middlewares = options.middlewares) != null ? _options_middlewares : []){
        if (!MIDDLEWARE_PROVIDER_PATTERN.test(definition.provider)) {
            throw new Error(`Middleware provider '${definition.provider}' must be a stable identifier.`);
        }
        if (middlewareProviders.has(definition.provider)) {
            throw new Error(`Middleware provider '${definition.provider}' is declared more than once.`);
        }
        if (definition.meta.name !== definition.provider) {
            throw new Error(`Middleware metadata name must match provider '${definition.provider}'.`);
        }
        middlewareProviders.add(definition.provider);
    }
    if (options.defaultMiddleware && !middlewareProviders.has(options.defaultMiddleware)) {
        throw new Error(`Default Middleware provider '${options.defaultMiddleware}' is not declared.`);
    }
    const appKeys = new Set();
    var _options_apps;
    for (const app of (_options_apps = options.apps) != null ? _options_apps : []){
        if (!TOOL_NAME_PATTERN.test(app.key) || app.key.length > 191) {
            throw new Error(`MCP App key '${app.key}' is invalid.`);
        }
        if (appKeys.has(app.key)) {
            throw new Error(`MCP App '${app.key}' is declared more than once.`);
        }
        if (!isRelativeHtmlEntry(app.entry)) {
            throw new Error(`MCP App '${app.key}' entry must be a relative HTML path inside the plugin bundle.`);
        }
        appKeys.add(app.key);
    }
}
function validateToolOptions(options, methodName) {
    var _options_description;
    if (options.resultFormat && options.resultFormat !== 'dto' && options.resultFormat !== 'tool_result') {
        throw new Error(`Tool '${options.name}' declares an invalid resultFormat.`);
    }
    if (!TOOL_NAME_PATTERN.test(options.name) || options.name.length > 191) {
        throw new Error(`Method '${methodName}' declares invalid Tool name '${options.name}'.`);
    }
    if (!((_options_description = options.description) == null ? void 0 : _options_description.trim())) throw new Error(`Tool '${options.name}' requires a description.`);
    assertStrictObjectSchema(options.inputSchema, options.name, 'input');
    if (options.mcp && !options.outputSchema && options.resultFormat !== 'tool_result') {
        throw new Error(`MCP Tool '${options.name}' requires an outputSchema.`);
    }
    if (options.mcp && options.outputSchema) {
        assertStrictObjectSchema(options.outputSchema, options.name, 'output');
    }
    if (options.mcp && !options.mcp.requiredContext.length) {
        throw new Error(`MCP Tool '${options.name}' requires at least one execution context.`);
    }
    if (options.mcp) {
        const transportSchema = options.mcp.inputSchema;
        if (transportSchema && typeof transportSchema.parseAsync !== 'function') {
            throw new Error(`MCP Tool '${options.name}' requires a Zod transport input schema.`);
        }
        const task = options.mcp.task;
        if (task && (task.mode !== 'optional' && task.mode !== 'required' || task.maxLifetimeMs !== undefined && (!Number.isSafeInteger(task.maxLifetimeMs) || task.maxLifetimeMs <= 0))) {
            throw new Error(`MCP Tool '${options.name}' declares invalid task execution policy.`);
        }
        if (options.mcp.defaultApprovalMode !== undefined && !includesValue(MCP_CAPABILITY_APPROVAL_MODES, options.mcp.defaultApprovalMode)) {
            throw new Error(`MCP Tool '${options.name}' declares invalid defaultApprovalMode.`);
        }
        const behavior = options.mcp.behavior;
        if (!includesValue(MCP_TOOL_RISKS, behavior == null ? void 0 : behavior.risk) || !includesValue(MCP_TOOL_SIDE_EFFECTS, behavior == null ? void 0 : behavior.sideEffect) || !includesValue(MCP_TOOL_IDEMPOTENCY, behavior == null ? void 0 : behavior.idempotency)) {
            throw new Error(`MCP Tool '${options.name}' requires valid behavior annotations.`);
        }
        const contexts = new Set(options.mcp.requiredContext);
        if (contexts.size !== options.mcp.requiredContext.length || [
            ...contexts
        ].some((context)=>!includesValue(MCP_REQUIRED_CONTEXTS, context))) {
            throw new Error(`MCP Tool '${options.name}' declares invalid or duplicate execution context requirements.`);
        }
        if (options.mcp.visibility && (!options.mcp.visibility.length || new Set(options.mcp.visibility).size !== options.mcp.visibility.length || options.mcp.visibility.some((visibility)=>!includesValue(MCP_CAPABILITY_VISIBILITIES, visibility)))) {
            throw new Error(`MCP Tool '${options.name}' declares invalid visibility.`);
        }
        if (options.mcp.app && options.mcp.visibility && !options.mcp.visibility.includes('app')) {
            throw new Error(`MCP Tool '${options.name}' with an App binding must include app visibility.`);
        }
    }
}
function isRelativeHtmlEntry(entry) {
    if (!entry || !entry.endsWith('.html') || entry.startsWith('/') || entry.includes('\\')) return false;
    return entry.split('/').every((segment)=>segment !== '.' && segment !== '..' && segment.length > 0);
}
function assertStrictObjectSchema(schema, toolName, role) {
    if (!schema || typeof Reflect.get(schema, 'parseAsync') !== 'function') {
        throw new Error(`Tool '${toolName}' requires a Zod ${role} schema.`);
    }
    // Refinements preserve the strict object shape while enforcing cross-field invariants.
    // Plugins can load a different physical copy of Zod; use its explicit type tag.
    while(schema._def.typeName === 'ZodEffects'){
        const refinement = schema;
        if (refinement._def.effect.type !== 'refinement') break;
        schema = refinement.innerType();
    }
    if (role === 'output' && schema._def.typeName === 'ZodUnion') {
        // Recovery receipts may have a different shape, but every branch must reject extra fields.
        const union = schema;
        for (const option of union.options)assertStrictObjectSchema(option, toolName, role);
        return;
    }
    const definition = Reflect.get(schema, '_def');
    if (!definition || Reflect.get(definition, 'unknownKeys') !== 'strict') {
        throw new Error(`Tool '${toolName}' ${role} schema must be a strict Zod object.`);
    }
}
function resolveMiddlewareProvider(tool, provider) {
    if (tool.middleware === false) return undefined;
    if (typeof tool.middleware === 'string') return tool.middleware;
    if (tool.middleware === true || tool.middleware === undefined) return provider.defaultMiddleware;
    return undefined;
}
function getXpertToolMethod(instance, descriptor) {
    const method = Reflect.get(instance, descriptor.methodName);
    if (typeof method !== 'function') {
        throw new Error(`Decorated Tool method '${descriptor.methodName}' is not callable.`);
    }
    return method.bind(instance);
}
function includesValue(values, value) {
    return values.some((candidate)=>candidate === value);
}

function sameOwner(left, right) {
    return left.kind === 'plugin' ? right.kind === 'plugin' && left.pluginName === right.pluginName : right.kind === 'builtin';
}
/** Component keys belong to a plugin; public strategy and Tool names retain their scope-wide claims. */ function assertXpertToolProviderClaims(candidate, existing) {
    const { source, descriptor } = candidate;
    const tools = new Set(descriptor.tools.map(({ options })=>options.name));
    for (const other of existing){
        if (other.source.scopeKey !== source.scopeKey) continue;
        const owner = sameOwner(source, other.source);
        const otherOwner = other.source.kind === 'plugin' ? other.source.pluginName : 'built-in providers';
        if (other.descriptor.options.provider === descriptor.options.provider) {
            if (owner) continue; // A new instance/version may replace the same owner's registration.
            throw new Error(`Provider '${descriptor.options.provider}' is already registered by '${otherOwner}' in scope '${source.scopeKey}'.`);
        }
        if (owner && other.descriptor.options.componentKey === descriptor.options.componentKey) {
            throw new Error(`Component key '${descriptor.options.componentKey}' is already registered for '${otherOwner}' in scope '${source.scopeKey}'.`);
        }
        const duplicate = other.descriptor.tools.find(({ options })=>tools.has(options.name));
        if (duplicate) {
            throw new Error(`Tool '${duplicate.options.name}' is already registered by '${otherOwner}' in scope '${source.scopeKey}'.`);
        }
    }
}

let XpertToolProviderRegistry = class XpertToolProviderRegistry extends BaseStrategyRegistry {
    upsert(candidate) {
        const target = resolveStrategyMetadataTarget(candidate);
        if (!target || !Reflect.getMetadata(XPERT_TOOL_PROVIDER_METADATA, target)) return;
        const instance = candidate;
        const descriptor = describeXpertToolProvider(instance);
        const source = this.getSource(instance);
        assertXpertToolProviderClaims({
            descriptor,
            source
        }, this.listAllRegistrations().filter(({ strategy })=>strategy !== instance).map(({ strategy, source })=>({
                descriptor: describeXpertToolProvider(strategy),
                source
            })));
        const previous = this.register(descriptor.options.provider, instance, source);
        this.replacements.set(instance, previous != null ? previous : null);
    }
    rollback(instance) {
        const descriptor = describeXpertToolProvider(instance);
        const source = this.getSource(instance);
        const previous = this.replacements.get(instance);
        if (previous) {
            this.register(descriptor.options.provider, previous, this.getSource(previous));
        } else {
            this.unregister(descriptor.options.provider, source, instance);
        }
        this.replacements.delete(instance);
    }
    constructor(discoveryService, reflector){
        super(XPERT_TOOL_PROVIDER, discoveryService, reflector);
        this.replacements = new WeakMap();
    }
};
XpertToolProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], XpertToolProviderRegistry);

// Invariants: recovery starts only after the business method returns successfully.
// Projection and recovery callbacks must be free of business side effects.
// The adapter validates normal output once and validates any fallback separately;
// neither path may rerun the operation or suppress input, authorization or commit failures.
// Installed plugins may resolve a different physical SDK copy from the host.
const PREPARED_RESULT = Symbol.for('xpert.tool.prepared-result.v1');
/** Defer output projection until the adapter can validate and recover its result. */ function prepareToolResult(project, recover) {
    return {
        [PREPARED_RESULT]: true,
        project,
        recover
    };
}
function isPrepared(value) {
    return typeof value === 'object' && value !== null && PREPARED_RESULT in value && value[PREPARED_RESULT] === true && 'project' in value && typeof value.project === 'function' && 'recover' in value && typeof value.recover === 'function';
}
async function resolveToolResult(value, validate) {
    if (!isPrepared(value)) return validate(value);
    try {
        return await validate(await value.project());
    } catch (error) {
        const diagnostic = {
            code: 'tool_output_invalid',
            issues: error instanceof ZodError ? error.issues.slice(0, 10).map((issue)=>({
                    path: issue.path.join('.').slice(0, 240),
                    code: issue.code
                })) : []
        };
        // A malformed fallback is a programming error too; never send unchecked data.
        return validate(await value.recover(diagnostic));
    }
}

// Why this exists: MCP media blocks and business metadata have different contracts.
// Validate metadata with the declared output schema, preserve bounded media blocks,
// and include the same DTO in text for clients that hide structuredContent.
const XPERT_TOOL_RESULT_FORMAT_VERSION = 1;
const contentSchema = z.discriminatedUnion('type', [
    z.object({
        type: z.literal('text'),
        text: z.string().max(2 * 1024 * 1024)
    }).strict(),
    z.object({
        type: z.literal('image'),
        data: z.string().min(1).max(8 * 1024 * 1024),
        mimeType: z.enum([
            'image/png',
            'image/jpeg',
            'image/webp',
            'image/gif'
        ])
    }).strict(),
    z.object({
        type: z.literal('audio'),
        data: z.string().min(1).max(8 * 1024 * 1024),
        mimeType: z.string().min(1).max(100)
    }).strict(),
    z.object({
        type: z.literal('resource_link'),
        uri: z.string().min(1).max(4096),
        name: z.string().max(240).optional()
    }).strict()
]);
/** Validate the envelope separately so binary content never enters the business DTO. */ async function parseDecoratedToolResult(value, outputSchema) {
    var _result_content;
    const envelope = z.object({
        content: z.array(contentSchema).max(32).optional(),
        structuredContent: outputSchema != null ? outputSchema : z.unknown().optional(),
        isError: z.boolean().optional()
    }).strict();
    const result = await envelope.parseAsync(value);
    var _result_content_map;
    const content = (_result_content_map = (_result_content = result.content) == null ? void 0 : _result_content.map((item)=>{
        switch(item.type){
            case 'text':
                return {
                    type: 'text',
                    text: item.text
                };
            case 'image':
                return {
                    type: 'image',
                    data: item.data,
                    mimeType: item.mimeType
                };
            case 'audio':
                return {
                    type: 'audio',
                    data: item.data,
                    mimeType: item.mimeType
                };
            case 'resource_link':
                return _extends({
                    type: 'resource_link',
                    uri: item.uri
                }, item.name ? {
                    name: item.name
                } : {});
        }
    })) != null ? _result_content_map : [];
    // MCP clients may expose only content to the model. Keep the validated DTO
    // readable there too, while retaining binary blocks and App structured data.
    const text = JSON.stringify(result.structuredContent);
    if (text !== undefined && !content.some((item)=>item.type === 'text' && item.text === text)) content.push({
        type: 'text',
        text
    });
    return _extends({
        structuredContent: result.structuredContent,
        content
    }, result.isError === undefined ? {} : {
        isError: result.isError
    });
}
function agentContent(content) {
    return (content != null ? content : []).map((item)=>{
        if (item.type === 'image') return {
            type: 'image_url',
            image_url: {
                url: `data:${item.mimeType};base64,${item.data}`
            }
        };
        if (item.type === 'text') return item;
        var _item_name;
        if (item.type === 'resource_link') return {
            type: 'text',
            text: `${(_item_name = item.name) != null ? _item_name : 'Resource'}: ${item.uri}`
        };
        return {
            type: 'text',
            text: `Audio content (${item.mimeType}) is available through MCP.`
        };
    });
}

class DecoratedToolsetStrategy {
    async validateConfig(config) {
        await (this.instance.validateConfig == null ? void 0 : this.instance.validateConfig.call(this.instance, config));
    }
    async create(toolset, params) {
        return new DecoratedBuiltinToolset(this.instance, this.descriptor, toolset, params, this.pluginName, this.pluginVersion);
    }
    createTools() {
        return [];
    }
    constructor(instance, pluginName, pluginVersion){
        this.instance = instance;
        this.pluginName = pluginName;
        this.pluginVersion = pluginVersion;
        this.descriptor = describeXpertToolProvider(instance);
        const options = this.descriptor.options;
        var _options_author, _options_tags, _options_label, _options_configSchema;
        this.meta = _extends({
            author: (_options_author = options.author) != null ? _options_author : 'Plugin',
            tags: [
                ...(_options_tags = options.tags) != null ? _options_tags : [
                    'mcp'
                ]
            ],
            name: options.provider,
            label: (_options_label = options.label) != null ? _options_label : asI18n(options.name)
        }, options.description ? {
            description: asI18n(options.description)
        } : {}, {
            configSchema: (_options_configSchema = options.configSchema) != null ? _options_configSchema : {
                type: 'object',
                properties: {},
                required: []
            }
        }, options.icon ? {
            icon: options.icon
        } : {});
    }
}
class DecoratedAgentMiddlewareStrategy {
    getToolNames() {
        return this.descriptor.tools.filter((item)=>item.middlewareProvider === this.provider).map((item)=>item.options.name);
    }
    async createMiddleware(options, context) {
        var _this_descriptor_options_apps;
        const tools = this.descriptor.tools.filter((item)=>item.middlewareProvider === this.provider).map((item)=>createAgentTool(this.instance, item, context, options));
        const extensions = await (this.instance.getMiddlewareExtensions == null ? void 0 : this.instance.getMiddlewareExtensions.call(this.instance, this.provider, options, context));
        return _extends({}, extensions != null ? extensions : {}, {
            name: this.provider,
            tools
        }, ((_this_descriptor_options_apps = this.descriptor.options.apps) == null ? void 0 : _this_descriptor_options_apps.length) ? {
            apps: {
                definitions: this.descriptor.options.apps,
                tools: Object.fromEntries(this.descriptor.tools.filter((item)=>item.middlewareProvider === this.provider && item.options.app).map((item)=>[
                        item.options.name,
                        item.options.app
                    ]))
            }
        } : {});
    }
    constructor(instance, descriptor, provider){
        var _descriptor_options_middlewares;
        this.instance = instance;
        this.descriptor = descriptor;
        this.provider = provider;
        const definition = (_descriptor_options_middlewares = descriptor.options.middlewares) == null ? void 0 : _descriptor_options_middlewares.find((item)=>item.provider === provider);
        if (!definition) throw new Error(`Middleware provider '${provider}' is not declared.`);
        this.meta = definition.meta;
    }
}
var _definitions = /*#__PURE__*/ _class_private_field_loose_key("_definitions");
let DecoratedBuiltinToolset = class DecoratedBuiltinToolset extends BuiltinToolset {
    _validateCredentials() {
        return Promise.resolve();
    }
    async initTools() {
        return this.tools;
    }
    getMcpCapabilityDefinitions() {
        return _class_private_field_loose_base(this, _definitions)[_definitions];
    }
    getMcpCapabilitySource() {
        return _extends({}, this.pluginName ? {
            pluginName: this.pluginName
        } : {}, this.pluginVersion ? {
            pluginVersion: this.pluginVersion
        } : {});
    }
    constructor(instance, descriptor, toolset, params, pluginName, pluginVersion){
        var _descriptor_options_apps;
        super(descriptor.options.provider, toolset, params);
        Object.defineProperty(this, _definitions, {
            writable: true,
            value: void 0
        });
        this.pluginName = pluginName;
        this.pluginVersion = pluginVersion;
        this.tools = [];
        const extensions = resolveXpertMcpExtensions(instance, descriptor);
        _class_private_field_loose_base(this, _definitions)[_definitions] = _extends({
            resources: extensions == null ? void 0 : extensions.resources,
            resourceTemplates: extensions == null ? void 0 : extensions.resourceTemplates,
            prompts: extensions == null ? void 0 : extensions.prompts,
            instructions: descriptor.options.instructions,
            tools: descriptor.tools.filter((item)=>!!item.options.mcp).map((item)=>createMcpTool(instance, item))
        }, ((_descriptor_options_apps = descriptor.options.apps) == null ? void 0 : _descriptor_options_apps.length) ? {
            apps: [
                ...descriptor.options.apps
            ]
        } : {});
    }
};
function createAgentTool(instance, descriptor, middlewareContext, middlewareOptions) {
    const invoke = getXpertToolMethod(instance, descriptor);
    return tool(async (input, config)=>{
        const parsedInput = await descriptor.options.inputSchema.parseAsync(input);
        const output = await invoke(parsedInput, agentExecutionContext(middlewareContext, middlewareOptions, config));
        if (descriptor.options.resultFormat === 'tool_result') {
            const result = await resolveToolResult(output, (value)=>parseDecoratedToolResult(value, descriptor.options.outputSchema));
            var _result_isError;
            return [
                agentContent(result.content),
                {
                    structuredContent: result.structuredContent,
                    isError: (_result_isError = result.isError) != null ? _result_isError : false
                }
            ];
        }
        return resolveToolResult(output, async (value)=>{
            const parsedOutput = descriptor.options.outputSchema ? await descriptor.options.outputSchema.parseAsync(value) : value;
            return stringifyDto(parsedOutput, descriptor.options.name);
        });
    }, _extends({
        name: descriptor.options.name,
        description: descriptor.options.description,
        schema: descriptor.options.inputSchema,
        verboseParsingErrors: true,
        responseFormat: descriptor.options.resultFormat === 'tool_result' ? 'content_and_artifact' : 'content'
    }, descriptor.options.metadata ? {
        metadata: descriptor.options.metadata
    } : {}));
}
function createMcpTool(instance, descriptor) {
    const mcp = descriptor.options.mcp;
    const outputSchema = descriptor.options.outputSchema;
    if (!mcp) throw new Error(`MCP Tool '${descriptor.options.name}' is incomplete.`);
    const invoke = getXpertToolMethod(instance, descriptor);
    var _mcp_inputSchema, _mcp_visibility;
    return _extends({
        name: descriptor.options.name
    }, descriptor.options.title ? {
        title: descriptor.options.title
    } : {}, {
        description: descriptor.options.description,
        inputSchema: (_mcp_inputSchema = mcp.inputSchema) != null ? _mcp_inputSchema : descriptor.options.inputSchema
    }, outputSchema ? {
        outputSchema
    } : {}, {
        exposure: {
            mcp: {
                eligible: true
            }
        },
        behavior: mcp.behavior
    }, mcp.task ? {
        task: mcp.task
    } : {}, mcp.defaultApprovalMode ? {
        defaultApprovalMode: mcp.defaultApprovalMode
    } : {}, {
        requiredContext: [
            ...mcp.requiredContext
        ],
        visibility: [
            ...(_mcp_visibility = mcp.visibility) != null ? _mcp_visibility : mcp.app ? [
                'model',
                'app'
            ] : [
                'model'
            ]
        ]
    }, mcp.app ? {
        app: {
            resourceKey: mcp.app.resourceKey
        }
    } : {}, {
        execute: async (input, context)=>{
            const parsedInput = await descriptor.options.inputSchema.parseAsync(input);
            const transportInput = mcp.inputSchema ? await mcp.inputSchema.parseAsync(parsedInput) : parsedInput;
            const output = await invoke(transportInput, mcpExecutionContext(context));
            if (descriptor.options.resultFormat === 'tool_result') {
                return resolveToolResult(output, (value)=>parseDecoratedToolResult(value, outputSchema));
            }
            return resolveToolResult(output, async (value)=>{
                const parsedOutput = outputSchema ? await outputSchema.parseAsync(value) : value;
                // Serialize once so text-only clients and MCP Apps receive the same JSON-safe DTO.
                const text = stringifyDto(parsedOutput, descriptor.options.name);
                return {
                    content: [
                        {
                            type: 'text',
                            text
                        }
                    ],
                    structuredContent: JSON.parse(text)
                };
            });
        }
    });
}
function agentExecutionContext(context, middlewareOptions, config) {
    var _context_runtime_capabilities;
    const configurable = config.configurable;
    const requestId = readString(configurable, 'tool_call_id');
    const executionId = readString(configurable, 'executionId');
    const traceId = readString(configurable, 'traceId');
    return _extends({
        surface: 'middleware',
        tenantId: context.tenantId,
        organizationId: context.organizationId,
        principal: {
            type: 'user',
            id: context.userId,
            userId: context.userId
        },
        workspaceId: context.workspaceId,
        projectId: context.projectId,
        conversationId: context.conversationId,
        threadId: context.threadId,
        xpertId: context.xpertId,
        agentKey: context.agentKey
    }, executionId ? {
        executionId
    } : {}, requestId ? {
        requestId
    } : {}, traceId ? {
        traceId
    } : {}, {
        signal: config.signal,
        host: {
            files: (_context_runtime_capabilities = context.runtime.capabilities) == null ? void 0 : _context_runtime_capabilities.get(WorkspaceFilesRuntimeCapability),
            models: {
                createModelClient: context.runtime.createModelClient,
                getModelProvider: context.runtime.getModelProvider
            }
        },
        xpertFeatures: context.xpertFeatures,
        middlewareOptions
    });
}
function mcpExecutionContext(context) {
    return {
        surface: 'mcp',
        tenantId: context.tenantId,
        organizationId: context.organizationId,
        principal: context.principal,
        workspaceId: context.workspaceId,
        projectId: context.projectId,
        conversationId: context.conversationId,
        threadId: readString(context, 'threadId'),
        xpertId: context.xpertId,
        agentKey: context.agentKey,
        executionId: context.executionId,
        requestId: context.requestId,
        traceId: context.traceId,
        signal: context.signal,
        host: context.host
    };
}
function stringifyDto(value, toolName) {
    const result = JSON.stringify(value);
    if (result === undefined) throw new Error(`Tool '${toolName}' returned a non-JSON value.`);
    return result;
}
function asI18n(value) {
    return {
        en_US: value,
        zh_Hans: value
    };
}
function readString(value, key) {
    if (!value || typeof value !== 'object') return undefined;
    const field = Reflect.get(value, key);
    return typeof field === 'string' && field ? field : undefined;
}

/** Expands one decorated business provider into the existing Toolset and Middleware registries. */ let XpertToolProviderCoordinator = class XpertToolProviderCoordinator {
    onModuleInit() {
        this.subscription = this.bus.events$.subscribe((event)=>{
            if (event.type === 'UPSERT' && event.strategyType === XPERT_TOOL_PROVIDER) {
                this.expand(event.entry.instance);
            }
        });
        for (const wrapper of this.discovery.getProviders()){
            if (wrapper.instance) this.expand(wrapper.instance);
        }
    }
    onModuleDestroy() {
        var _this_subscription;
        (_this_subscription = this.subscription) == null ? void 0 : _this_subscription.unsubscribe();
    }
    expand(candidate) {
        if (!candidate || typeof candidate !== 'object' && typeof candidate !== 'function') return;
        const instance = candidate;
        if (this.processed.has(instance)) return;
        const target = resolveStrategyMetadataTarget(instance);
        if (!target || !Reflect.getMetadata(XPERT_TOOL_PROVIDER_METADATA, target)) return;
        const provider = instance;
        const descriptor = describeXpertToolProvider(provider);
        const source = this.providerRegistry.getSource(provider);
        const pluginName = source.kind === 'plugin' ? source.pluginName : undefined;
        const pluginVersion = source.kind === 'plugin' ? source.pluginVersion : undefined;
        const toolsetAdapter = new DecoratedToolsetStrategy(provider, pluginName, pluginVersion);
        var _descriptor_options_middlewares;
        const middlewareAdapters = ((_descriptor_options_middlewares = descriptor.options.middlewares) != null ? _descriptor_options_middlewares : []).filter((definition)=>descriptor.tools.some((item)=>item.middlewareProvider === definition.provider)).map((definition)=>({
                provider: definition.provider,
                strategy: new DecoratedAgentMiddlewareStrategy(provider, descriptor, definition.provider)
            }));
        try {
            this.toolsetRegistry.assertCanRegister(descriptor.options.provider, toolsetAdapter, source);
            for (const adapter of middlewareAdapters){
                this.middlewareRegistry.assertCanRegister(adapter.provider, adapter.strategy, source);
            }
        } catch (error) {
            this.providerRegistry.rollback(provider);
            throw error;
        }
        this.toolsetRegistry.register(descriptor.options.provider, toolsetAdapter, source);
        for (const adapter of middlewareAdapters){
            this.middlewareRegistry.register(adapter.provider, adapter.strategy, source);
        }
        this.processed.add(instance);
    }
    constructor(discovery, bus, providerRegistry, toolsetRegistry, middlewareRegistry){
        this.processed = new WeakSet();
        this.discovery = discovery;
        this.bus = bus;
        this.providerRegistry = providerRegistry;
        this.toolsetRegistry = toolsetRegistry;
        this.middlewareRegistry = middlewareRegistry;
    }
};
XpertToolProviderCoordinator = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        StrategyBus,
        XpertToolProviderRegistry,
        ToolsetRegistry,
        AgentMiddlewareRegistry
    ])
], XpertToolProviderCoordinator);

function _define_property$h(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$h(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$h(target, key, source[key]);
        });
    }
    return target;
}
var ignoreOverride = Symbol("Let zodToJsonSchema decide on which parser to use");
var defaultOptions = {
    name: undefined,
    $refStrategy: "root",
    basePath: [
        "#"
    ],
    effectStrategy: "input",
    pipeStrategy: "all",
    dateStrategy: "format:date-time",
    mapStrategy: "entries",
    removeAdditionalStrategy: "passthrough",
    allowedAdditionalProperties: true,
    rejectedAdditionalProperties: false,
    definitionPath: "definitions",
    target: "jsonSchema7",
    strictUnions: false,
    definitions: {},
    errorMessages: false,
    markdownDescription: false,
    patternStrategy: "escape",
    applyRegexFlags: false,
    emailStrategy: "format:email",
    base64Strategy: "contentEncoding:base64",
    nameStrategy: "ref",
    openAiAnyTypeName: "OpenAiAnyType"
};
var getDefaultOptions = function(options) {
    return _object_spread$h({}, defaultOptions, options);
};

function _array_like_to_array$f(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$f(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$f(arr);
}
function _define_property$g(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$f(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$f() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$g(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$g(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$f(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$f(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$f(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array$f(arr, i) || _non_iterable_rest();
}
function _to_consumable_array$f(arr) {
    return _array_without_holes$f(arr) || _iterable_to_array$f(arr) || _unsupported_iterable_to_array$f(arr) || _non_iterable_spread$f();
}
function _unsupported_iterable_to_array$f(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$f(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$f(o, minLen);
}
var getRefs = function(options) {
    var _options = getDefaultOptions(options);
    var currentPath = _options.name !== undefined ? _to_consumable_array$f(_options.basePath).concat([
        _options.definitionPath,
        _options.name
    ]) : _options.basePath;
    return _object_spread_props$f(_object_spread$g({}, _options), {
        flags: {
            hasReferencedOpenAiAnyType: false
        },
        currentPath: currentPath,
        propertyPath: undefined,
        seen: new Map(Object.entries(_options.definitions).map(function(param) {
            var _param = _sliced_to_array(param, 2), name = _param[0], def = _param[1];
            return [
                def._def,
                {
                    def: def._def,
                    path: _to_consumable_array$f(_options.basePath).concat([
                        _options.definitionPath,
                        name
                    ]),
                    // Resolution of references will be forced even though seen, so it's ok that the schema is undefined here for now.
                    jsonSchema: undefined
                }
            ];
        }))
    });
};

function _define_property$f(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$f(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$f(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$e(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$e(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$e(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function addErrorMessage(res, key, errorMessage, refs) {
    if (!(refs === null || refs === void 0 ? void 0 : refs.errorMessages)) return;
    if (errorMessage) {
        res.errorMessage = _object_spread_props$e(_object_spread$f({}, res.errorMessage), _define_property$f({}, key, errorMessage));
    }
}
function setResponseValueAndErrors(res, key, value, errorMessage, refs) {
    res[key] = value;
    addErrorMessage(res, key, errorMessage, refs);
}

function _array_like_to_array$e(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$e(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$e(arr);
}
function _iterable_to_array$e(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$e() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$e(arr) {
    return _array_without_holes$e(arr) || _iterable_to_array$e(arr) || _unsupported_iterable_to_array$e(arr) || _non_iterable_spread$e();
}
function _unsupported_iterable_to_array$e(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$e(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$e(o, minLen);
}
var getRelativePath = function(pathA, pathB) {
    var i = 0;
    for(; i < pathA.length && i < pathB.length; i++){
        if (pathA[i] !== pathB[i]) break;
    }
    return [
        (pathA.length - i).toString()
    ].concat(_to_consumable_array$e(pathB.slice(i))).join("/");
};

function _array_like_to_array$d(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$d(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$d(arr);
}
function _iterable_to_array$d(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$d() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$d(arr) {
    return _array_without_holes$d(arr) || _iterable_to_array$d(arr) || _unsupported_iterable_to_array$d(arr) || _non_iterable_spread$d();
}
function _unsupported_iterable_to_array$d(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$d(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$d(o, minLen);
}
function parseAnyDef(refs) {
    if (refs.target !== "openAi") {
        return {};
    }
    var anyDefinitionPath = _to_consumable_array$d(refs.basePath).concat([
        refs.definitionPath,
        refs.openAiAnyTypeName
    ]);
    refs.flags.hasReferencedOpenAiAnyType = true;
    return {
        $ref: refs.$refStrategy === "relative" ? getRelativePath(anyDefinitionPath, refs.currentPath) : anyDefinitionPath.join("/")
    };
}

function _array_like_to_array$c(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$c(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$c(arr);
}
function _define_property$e(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$c(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$c() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$e(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$e(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$d(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$d(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$d(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$c(arr) {
    return _array_without_holes$c(arr) || _iterable_to_array$c(arr) || _unsupported_iterable_to_array$c(arr) || _non_iterable_spread$c();
}
function _unsupported_iterable_to_array$c(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$c(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$c(o, minLen);
}
function parseArrayDef(def, refs) {
    var _def_type, _def_type__def, _def_type1;
    var res = {
        type: "array"
    };
    if (((_def_type = def.type) === null || _def_type === void 0 ? void 0 : _def_type._def) && ((_def_type1 = def.type) === null || _def_type1 === void 0 ? void 0 : (_def_type__def = _def_type1._def) === null || _def_type__def === void 0 ? void 0 : _def_type__def.typeName) !== ZodFirstPartyTypeKind.ZodAny) {
        res.items = parseDef(def.type._def, _object_spread_props$d(_object_spread$e({}, refs), {
            currentPath: _to_consumable_array$c(refs.currentPath).concat([
                "items"
            ])
        }));
    }
    if (def.minLength) {
        setResponseValueAndErrors(res, "minItems", def.minLength.value, def.minLength.message, refs);
    }
    if (def.maxLength) {
        setResponseValueAndErrors(res, "maxItems", def.maxLength.value, def.maxLength.message, refs);
    }
    if (def.exactLength) {
        setResponseValueAndErrors(res, "minItems", def.exactLength.value, def.exactLength.message, refs);
        setResponseValueAndErrors(res, "maxItems", def.exactLength.value, def.exactLength.message, refs);
    }
    return res;
}

function parseBigintDef(def, refs) {
    var res = {
        type: "integer",
        format: "int64"
    };
    if (!def.checks) return res;
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = def.checks[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var check = _step.value;
            switch(check.kind){
                case "min":
                    if (refs.target === "jsonSchema7") {
                        if (check.inclusive) {
                            setResponseValueAndErrors(res, "minimum", check.value, check.message, refs);
                        } else {
                            setResponseValueAndErrors(res, "exclusiveMinimum", check.value, check.message, refs);
                        }
                    } else {
                        if (!check.inclusive) {
                            res.exclusiveMinimum = true;
                        }
                        setResponseValueAndErrors(res, "minimum", check.value, check.message, refs);
                    }
                    break;
                case "max":
                    if (refs.target === "jsonSchema7") {
                        if (check.inclusive) {
                            setResponseValueAndErrors(res, "maximum", check.value, check.message, refs);
                        } else {
                            setResponseValueAndErrors(res, "exclusiveMaximum", check.value, check.message, refs);
                        }
                    } else {
                        if (!check.inclusive) {
                            res.exclusiveMaximum = true;
                        }
                        setResponseValueAndErrors(res, "maximum", check.value, check.message, refs);
                    }
                    break;
                case "multipleOf":
                    setResponseValueAndErrors(res, "multipleOf", check.value, check.message, refs);
                    break;
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return res;
}

function parseBooleanDef() {
    return {
        type: "boolean"
    };
}

function parseBrandedDef(_def, refs) {
    return parseDef(_def.type._def, refs);
}

var parseCatchDef = function(def, refs) {
    return parseDef(def.innerType._def, refs);
};

function parseDateDef(def, refs, overrideDateStrategy) {
    var strategy = overrideDateStrategy !== null && overrideDateStrategy !== void 0 ? overrideDateStrategy : refs.dateStrategy;
    if (Array.isArray(strategy)) {
        return {
            anyOf: strategy.map(function(item, i) {
                return parseDateDef(def, refs, item);
            })
        };
    }
    switch(strategy){
        case "string":
        case "format:date-time":
            return {
                type: "string",
                format: "date-time"
            };
        case "format:date":
            return {
                type: "string",
                format: "date"
            };
        case "integer":
            return integerDateParser(def, refs);
    }
}
var integerDateParser = function(def, refs) {
    var res = {
        type: "integer",
        format: "unix-time"
    };
    if (refs.target === "openApi3") {
        return res;
    }
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = def.checks[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var check = _step.value;
            switch(check.kind){
                case "min":
                    setResponseValueAndErrors(res, "minimum", check.value, check.message, refs);
                    break;
                case "max":
                    setResponseValueAndErrors(res, "maximum", check.value, check.message, refs);
                    break;
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return res;
};

function _define_property$d(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$d(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$d(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$c(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$c(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$c(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function parseDefaultDef(_def, refs) {
    return _object_spread_props$c(_object_spread$d({}, parseDef(_def.innerType._def, refs)), {
        default: _def.defaultValue()
    });
}

function parseEffectsDef(_def, refs) {
    return refs.effectStrategy === "input" ? parseDef(_def.schema._def, refs) : parseAnyDef(refs);
}

function parseEnumDef(def) {
    return {
        type: "string",
        enum: Array.from(def.values)
    };
}

function _array_like_to_array$b(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$b(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$b(arr);
}
function _define_property$c(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$b(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$b() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$c(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$c(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$b(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$b(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$b(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _object_without_properties$1(source, excluded) {
    if (source == null) return {};
    var target = _object_without_properties_loose$1(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _object_without_properties_loose$1(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
function _to_consumable_array$b(arr) {
    return _array_without_holes$b(arr) || _iterable_to_array$b(arr) || _unsupported_iterable_to_array$b(arr) || _non_iterable_spread$b();
}
function _unsupported_iterable_to_array$b(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$b(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$b(o, minLen);
}
var isJsonSchema7AllOfType = function(type) {
    if ("type" in type && type.type === "string") return false;
    return "allOf" in type;
};
function parseIntersectionDef(def, refs) {
    var allOf = [
        parseDef(def.left._def, _object_spread_props$b(_object_spread$c({}, refs), {
            currentPath: _to_consumable_array$b(refs.currentPath).concat([
                "allOf",
                "0"
            ])
        })),
        parseDef(def.right._def, _object_spread_props$b(_object_spread$c({}, refs), {
            currentPath: _to_consumable_array$b(refs.currentPath).concat([
                "allOf",
                "1"
            ])
        }))
    ].filter(function(x) {
        return !!x;
    });
    var unevaluatedProperties = refs.target === "jsonSchema2019-09" ? {
        unevaluatedProperties: false
    } : undefined;
    var mergedAllOf = [];
    // If either of the schemas is an allOf, merge them into a single allOf
    allOf.forEach(function(schema) {
        if (isJsonSchema7AllOfType(schema)) {
            var _mergedAllOf;
            (_mergedAllOf = mergedAllOf).push.apply(_mergedAllOf, _to_consumable_array$b(schema.allOf));
            if (schema.unevaluatedProperties === undefined) {
                // If one of the schemas has no unevaluatedProperties set,
                // the merged schema should also have no unevaluatedProperties set
                unevaluatedProperties = undefined;
            }
        } else {
            var nestedSchema = schema;
            if ("additionalProperties" in schema && schema.additionalProperties === false) {
                schema.additionalProperties; var rest = _object_without_properties$1(schema, [
                    "additionalProperties"
                ]);
                nestedSchema = rest;
            } else {
                // As soon as one of the schemas has additionalProperties set not to false, we allow unevaluatedProperties
                unevaluatedProperties = undefined;
            }
            mergedAllOf.push(nestedSchema);
        }
    });
    return mergedAllOf.length ? _object_spread$c({
        allOf: mergedAllOf
    }, unevaluatedProperties) : undefined;
}

function _type_of$2(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function parseLiteralDef(def, refs) {
    var parsedType = _type_of$2(def.value);
    if (parsedType !== "bigint" && parsedType !== "number" && parsedType !== "boolean" && parsedType !== "string") {
        return {
            type: Array.isArray(def.value) ? "array" : "object"
        };
    }
    if (refs.target === "openApi3") {
        return {
            type: parsedType === "bigint" ? "integer" : parsedType,
            enum: [
                def.value
            ]
        };
    }
    return {
        type: parsedType === "bigint" ? "integer" : parsedType,
        const: def.value
    };
}

function _define_property$b(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$b(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$b(target, key, source[key]);
        });
    }
    return target;
}
var emojiRegex = undefined;
/**
 * Generated from the regular expressions found here as of 2024-05-22:
 * https://github.com/colinhacks/zod/blob/master/src/types.ts.
 *
 * Expressions with /i flag have been changed accordingly.
 */ var zodPatterns = {
    /**
     * `c` was changed to `[cC]` to replicate /i flag
     */ cuid: /^[cC][^\s-]{8,}$/,
    cuid2: /^[0-9a-z]+$/,
    ulid: /^[0-9A-HJKMNP-TV-Z]{26}$/,
    /**
     * `a-z` was added to replicate /i flag
     */ email: /^(?!\.)(?!.*\.\.)([a-zA-Z0-9_'+\-\.]*)[a-zA-Z0-9_+-]@([a-zA-Z0-9][a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$/,
    /**
     * Constructed a valid Unicode RegExp
     *
     * Lazily instantiate since this type of regex isn't supported
     * in all envs (e.g. React Native).
     *
     * See:
     * https://github.com/colinhacks/zod/issues/2433
     * Fix in Zod:
     * https://github.com/colinhacks/zod/commit/9340fd51e48576a75adc919bff65dbc4a5d4c99b
     */ emoji: function() {
        if (emojiRegex === undefined) {
            emojiRegex = RegExp("^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$", "u");
        }
        return emojiRegex;
    },
    /**
     * Unused
     */ uuid: /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/,
    /**
     * Unused
     */ ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
    ipv4Cidr: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,
    /**
     * Unused
     */ ipv6: /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,
    ipv6Cidr: /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
    base64: /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,
    base64url: /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,
    nanoid: /^[a-zA-Z0-9_-]{21}$/,
    jwt: /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/
};
function parseStringDef(def, refs) {
    var res = {
        type: "string"
    };
    if (def.checks) {
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = def.checks[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var check = _step.value;
                switch(check.kind){
                    case "min":
                        setResponseValueAndErrors(res, "minLength", typeof res.minLength === "number" ? Math.max(res.minLength, check.value) : check.value, check.message, refs);
                        break;
                    case "max":
                        setResponseValueAndErrors(res, "maxLength", typeof res.maxLength === "number" ? Math.min(res.maxLength, check.value) : check.value, check.message, refs);
                        break;
                    case "email":
                        switch(refs.emailStrategy){
                            case "format:email":
                                addFormat(res, "email", check.message, refs);
                                break;
                            case "format:idn-email":
                                addFormat(res, "idn-email", check.message, refs);
                                break;
                            case "pattern:zod":
                                addPattern(res, zodPatterns.email, check.message, refs);
                                break;
                        }
                        break;
                    case "url":
                        addFormat(res, "uri", check.message, refs);
                        break;
                    case "uuid":
                        addFormat(res, "uuid", check.message, refs);
                        break;
                    case "regex":
                        addPattern(res, check.regex, check.message, refs);
                        break;
                    case "cuid":
                        addPattern(res, zodPatterns.cuid, check.message, refs);
                        break;
                    case "cuid2":
                        addPattern(res, zodPatterns.cuid2, check.message, refs);
                        break;
                    case "startsWith":
                        addPattern(res, RegExp("^".concat(escapeLiteralCheckValue(check.value, refs))), check.message, refs);
                        break;
                    case "endsWith":
                        addPattern(res, RegExp("".concat(escapeLiteralCheckValue(check.value, refs), "$")), check.message, refs);
                        break;
                    case "datetime":
                        addFormat(res, "date-time", check.message, refs);
                        break;
                    case "date":
                        addFormat(res, "date", check.message, refs);
                        break;
                    case "time":
                        addFormat(res, "time", check.message, refs);
                        break;
                    case "duration":
                        addFormat(res, "duration", check.message, refs);
                        break;
                    case "length":
                        setResponseValueAndErrors(res, "minLength", typeof res.minLength === "number" ? Math.max(res.minLength, check.value) : check.value, check.message, refs);
                        setResponseValueAndErrors(res, "maxLength", typeof res.maxLength === "number" ? Math.min(res.maxLength, check.value) : check.value, check.message, refs);
                        break;
                    case "includes":
                        {
                            addPattern(res, RegExp(escapeLiteralCheckValue(check.value, refs)), check.message, refs);
                            break;
                        }
                    case "ip":
                        {
                            if (check.version !== "v6") {
                                addFormat(res, "ipv4", check.message, refs);
                            }
                            if (check.version !== "v4") {
                                addFormat(res, "ipv6", check.message, refs);
                            }
                            break;
                        }
                    case "base64url":
                        addPattern(res, zodPatterns.base64url, check.message, refs);
                        break;
                    case "jwt":
                        addPattern(res, zodPatterns.jwt, check.message, refs);
                        break;
                    case "cidr":
                        {
                            if (check.version !== "v6") {
                                addPattern(res, zodPatterns.ipv4Cidr, check.message, refs);
                            }
                            if (check.version !== "v4") {
                                addPattern(res, zodPatterns.ipv6Cidr, check.message, refs);
                            }
                            break;
                        }
                    case "emoji":
                        addPattern(res, zodPatterns.emoji(), check.message, refs);
                        break;
                    case "ulid":
                        {
                            addPattern(res, zodPatterns.ulid, check.message, refs);
                            break;
                        }
                    case "base64":
                        {
                            switch(refs.base64Strategy){
                                case "format:binary":
                                    {
                                        addFormat(res, "binary", check.message, refs);
                                        break;
                                    }
                                case "contentEncoding:base64":
                                    {
                                        setResponseValueAndErrors(res, "contentEncoding", "base64", check.message, refs);
                                        break;
                                    }
                                case "pattern:zod":
                                    {
                                        addPattern(res, zodPatterns.base64, check.message, refs);
                                        break;
                                    }
                            }
                            break;
                        }
                    case "nanoid":
                        {
                            addPattern(res, zodPatterns.nanoid, check.message, refs);
                        }
                    case "toLowerCase":
                    case "toUpperCase":
                    case "trim":
                        break;
                    default:
                        (function(_) {})(check);
                }
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    return res;
}
function escapeLiteralCheckValue(literal, refs) {
    return refs.patternStrategy === "escape" ? escapeNonAlphaNumeric(literal) : literal;
}
var ALPHA_NUMERIC = new Set("ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789");
function escapeNonAlphaNumeric(source) {
    var result = "";
    for(var i = 0; i < source.length; i++){
        if (!ALPHA_NUMERIC.has(source[i])) {
            result += "\\";
        }
        result += source[i];
    }
    return result;
}
// Adds a "format" keyword to the schema. If a format exists, both formats will be joined in an allOf-node, along with subsequent ones.
function addFormat(schema, value, message, refs) {
    var _schema_anyOf;
    if (schema.format || ((_schema_anyOf = schema.anyOf) === null || _schema_anyOf === void 0 ? void 0 : _schema_anyOf.some(function(x) {
        return x.format;
    }))) {
        if (!schema.anyOf) {
            schema.anyOf = [];
        }
        if (schema.format) {
            schema.anyOf.push(_object_spread$b({
                format: schema.format
            }, schema.errorMessage && refs.errorMessages && {
                errorMessage: {
                    format: schema.errorMessage.format
                }
            }));
            delete schema.format;
            if (schema.errorMessage) {
                delete schema.errorMessage.format;
                if (Object.keys(schema.errorMessage).length === 0) {
                    delete schema.errorMessage;
                }
            }
        }
        schema.anyOf.push(_object_spread$b({
            format: value
        }, message && refs.errorMessages && {
            errorMessage: {
                format: message
            }
        }));
    } else {
        setResponseValueAndErrors(schema, "format", value, message, refs);
    }
}
// Adds a "pattern" keyword to the schema. If a pattern exists, both patterns will be joined in an allOf-node, along with subsequent ones.
function addPattern(schema, regex, message, refs) {
    var _schema_allOf;
    if (schema.pattern || ((_schema_allOf = schema.allOf) === null || _schema_allOf === void 0 ? void 0 : _schema_allOf.some(function(x) {
        return x.pattern;
    }))) {
        if (!schema.allOf) {
            schema.allOf = [];
        }
        if (schema.pattern) {
            schema.allOf.push(_object_spread$b({
                pattern: schema.pattern
            }, schema.errorMessage && refs.errorMessages && {
                errorMessage: {
                    pattern: schema.errorMessage.pattern
                }
            }));
            delete schema.pattern;
            if (schema.errorMessage) {
                delete schema.errorMessage.pattern;
                if (Object.keys(schema.errorMessage).length === 0) {
                    delete schema.errorMessage;
                }
            }
        }
        schema.allOf.push(_object_spread$b({
            pattern: stringifyRegExpWithFlags(regex, refs)
        }, message && refs.errorMessages && {
            errorMessage: {
                pattern: message
            }
        }));
    } else {
        setResponseValueAndErrors(schema, "pattern", stringifyRegExpWithFlags(regex, refs), message, refs);
    }
}
// Mutate z.string.regex() in a best attempt to accommodate for regex flags when applyRegexFlags is true
function stringifyRegExpWithFlags(regex, refs) {
    if (!refs.applyRegexFlags || !regex.flags) {
        return regex.source;
    }
    // Currently handled flags
    var flags = {
        i: regex.flags.includes("i"),
        m: regex.flags.includes("m"),
        s: regex.flags.includes("s")
    };
    // The general principle here is to step through each character, one at a time, applying mutations as flags require. We keep track when the current character is escaped, and when it's inside a group /like [this]/ or (also) a range like /[a-z]/. The following is fairly brittle imperative code; edit at your peril!
    var source = flags.i ? regex.source.toLowerCase() : regex.source;
    var pattern = "";
    var isEscaped = false;
    var inCharGroup = false;
    var inCharRange = false;
    for(var i = 0; i < source.length; i++){
        if (isEscaped) {
            pattern += source[i];
            isEscaped = false;
            continue;
        }
        if (flags.i) {
            if (inCharGroup) {
                if (source[i].match(/[a-z]/)) {
                    var _source_;
                    if (inCharRange) {
                        pattern += source[i];
                        pattern += "".concat(source[i - 2], "-").concat(source[i]).toUpperCase();
                        inCharRange = false;
                    } else if (source[i + 1] === "-" && ((_source_ = source[i + 2]) === null || _source_ === void 0 ? void 0 : _source_.match(/[a-z]/))) {
                        pattern += source[i];
                        inCharRange = true;
                    } else {
                        pattern += "".concat(source[i]).concat(source[i].toUpperCase());
                    }
                    continue;
                }
            } else if (source[i].match(/[a-z]/)) {
                pattern += "[".concat(source[i]).concat(source[i].toUpperCase(), "]");
                continue;
            }
        }
        if (flags.m) {
            if (source[i] === "^") {
                pattern += "(^|(?<=[\r\n]))";
                continue;
            } else if (source[i] === "$") {
                pattern += "($|(?=[\r\n]))";
                continue;
            }
        }
        if (flags.s && source[i] === ".") {
            pattern += inCharGroup ? "".concat(source[i], "\r\n") : "[".concat(source[i], "\r\n]");
            continue;
        }
        pattern += source[i];
        if (source[i] === "\\") {
            isEscaped = true;
        } else if (inCharGroup && source[i] === "]") {
            inCharGroup = false;
        } else if (!inCharGroup && source[i] === "[") {
            inCharGroup = true;
        }
    }
    try {
        new RegExp(pattern);
    } catch (e) {
        console.warn("Could not convert regex pattern at ".concat(refs.currentPath.join("/"), " to a flag-independent form! Falling back to the flag-ignorant source"));
        return regex.source;
    }
    return pattern;
}

function _array_like_to_array$a(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$a(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$a(arr);
}
function _define_property$a(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$a(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$a() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$a(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$a(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$a(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$a(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$a(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _object_without_properties(source, excluded) {
    if (source == null) return {};
    var target = _object_without_properties_loose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _object_without_properties_loose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
function _to_consumable_array$a(arr) {
    return _array_without_holes$a(arr) || _iterable_to_array$a(arr) || _unsupported_iterable_to_array$a(arr) || _non_iterable_spread$a();
}
function _unsupported_iterable_to_array$a(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$a(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$a(o, minLen);
}
function parseRecordDef(def, refs) {
    var _def_keyType, _def_keyType1, _def_keyType__def_checks, _def_keyType2, _def_keyType3, _def_keyType__def_type__def_checks;
    if (refs.target === "openAi") {
        console.warn("Warning: OpenAI may not support records in schemas! Try an array of key-value pairs instead.");
    }
    if (refs.target === "openApi3" && ((_def_keyType = def.keyType) === null || _def_keyType === void 0 ? void 0 : _def_keyType._def.typeName) === ZodFirstPartyTypeKind.ZodEnum) {
        return {
            type: "object",
            required: def.keyType._def.values,
            properties: def.keyType._def.values.reduce(function(acc, key) {
                var _parseDef;
                return _object_spread_props$a(_object_spread$a({}, acc), _define_property$a({}, key, (_parseDef = parseDef(def.valueType._def, _object_spread_props$a(_object_spread$a({}, refs), {
                    currentPath: _to_consumable_array$a(refs.currentPath).concat([
                        "properties",
                        key
                    ])
                }))) !== null && _parseDef !== void 0 ? _parseDef : parseAnyDef(refs)));
            }, {}),
            additionalProperties: refs.rejectedAdditionalProperties
        };
    }
    var _parseDef;
    var schema = {
        type: "object",
        additionalProperties: (_parseDef = parseDef(def.valueType._def, _object_spread_props$a(_object_spread$a({}, refs), {
            currentPath: _to_consumable_array$a(refs.currentPath).concat([
                "additionalProperties"
            ])
        }))) !== null && _parseDef !== void 0 ? _parseDef : refs.allowedAdditionalProperties
    };
    if (refs.target === "openApi3") {
        return schema;
    }
    if (((_def_keyType1 = def.keyType) === null || _def_keyType1 === void 0 ? void 0 : _def_keyType1._def.typeName) === ZodFirstPartyTypeKind.ZodString && ((_def_keyType__def_checks = def.keyType._def.checks) === null || _def_keyType__def_checks === void 0 ? void 0 : _def_keyType__def_checks.length)) {
        var _parseStringDef = parseStringDef(def.keyType._def, refs); _parseStringDef.type; var keyType = _object_without_properties(_parseStringDef, [
            "type"
        ]);
        return _object_spread_props$a(_object_spread$a({}, schema), {
            propertyNames: keyType
        });
    } else if (((_def_keyType2 = def.keyType) === null || _def_keyType2 === void 0 ? void 0 : _def_keyType2._def.typeName) === ZodFirstPartyTypeKind.ZodEnum) {
        return _object_spread_props$a(_object_spread$a({}, schema), {
            propertyNames: {
                enum: def.keyType._def.values
            }
        });
    } else if (((_def_keyType3 = def.keyType) === null || _def_keyType3 === void 0 ? void 0 : _def_keyType3._def.typeName) === ZodFirstPartyTypeKind.ZodBranded && def.keyType._def.type._def.typeName === ZodFirstPartyTypeKind.ZodString && ((_def_keyType__def_type__def_checks = def.keyType._def.type._def.checks) === null || _def_keyType__def_type__def_checks === void 0 ? void 0 : _def_keyType__def_type__def_checks.length)) {
        var _parseBrandedDef = parseBrandedDef(def.keyType._def, refs); _parseBrandedDef.type; var keyType1 = _object_without_properties(_parseBrandedDef, [
            "type"
        ]);
        return _object_spread_props$a(_object_spread$a({}, schema), {
            propertyNames: keyType1
        });
    }
    return schema;
}

function _array_like_to_array$9(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$9(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$9(arr);
}
function _define_property$9(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$9(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$9() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$9(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$9(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$9(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$9(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$9(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$9(arr) {
    return _array_without_holes$9(arr) || _iterable_to_array$9(arr) || _unsupported_iterable_to_array$9(arr) || _non_iterable_spread$9();
}
function _unsupported_iterable_to_array$9(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$9(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$9(o, minLen);
}
function parseMapDef(def, refs) {
    if (refs.mapStrategy === "record") {
        return parseRecordDef(def, refs);
    }
    var keys = parseDef(def.keyType._def, _object_spread_props$9(_object_spread$9({}, refs), {
        currentPath: _to_consumable_array$9(refs.currentPath).concat([
            "items",
            "items",
            "0"
        ])
    })) || parseAnyDef(refs);
    var values = parseDef(def.valueType._def, _object_spread_props$9(_object_spread$9({}, refs), {
        currentPath: _to_consumable_array$9(refs.currentPath).concat([
            "items",
            "items",
            "1"
        ])
    })) || parseAnyDef(refs);
    return {
        type: "array",
        maxItems: 125,
        items: {
            type: "array",
            items: [
                keys,
                values
            ],
            minItems: 2,
            maxItems: 2
        }
    };
}

function _type_of$1(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function parseNativeEnumDef(def) {
    var object = def.values;
    var actualKeys = Object.keys(def.values).filter(function(key) {
        return typeof object[object[key]] !== "number";
    });
    var actualValues = actualKeys.map(function(key) {
        return object[key];
    });
    var parsedTypes = Array.from(new Set(actualValues.map(function(values) {
        return typeof values === "undefined" ? "undefined" : _type_of$1(values);
    })));
    return {
        type: parsedTypes.length === 1 ? parsedTypes[0] === "string" ? "string" : "number" : [
            "string",
            "number"
        ],
        enum: actualValues
    };
}

function _array_like_to_array$8(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$8(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$8(arr);
}
function _define_property$8(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$8(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$8() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$8(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$8(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$8(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$8(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$8(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$8(arr) {
    return _array_without_holes$8(arr) || _iterable_to_array$8(arr) || _unsupported_iterable_to_array$8(arr) || _non_iterable_spread$8();
}
function _unsupported_iterable_to_array$8(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$8(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$8(o, minLen);
}
function parseNeverDef(refs) {
    return refs.target === "openAi" ? undefined : {
        not: parseAnyDef(_object_spread_props$8(_object_spread$8({}, refs), {
            currentPath: _to_consumable_array$8(refs.currentPath).concat([
                "not"
            ])
        }))
    };
}

function parseNullDef(refs) {
    return refs.target === "openApi3" ? {
        enum: [
            "null"
        ],
        nullable: true
    } : {
        type: "null"
    };
}

function _array_like_to_array$7(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$7(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$7(arr);
}
function _define_property$7(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _iterable_to_array$7(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$7() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$7(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$7(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$7(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$7(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$7(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$7(arr) {
    return _array_without_holes$7(arr) || _iterable_to_array$7(arr) || _unsupported_iterable_to_array$7(arr) || _non_iterable_spread$7();
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function _unsupported_iterable_to_array$7(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$7(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$7(o, minLen);
}
var primitiveMappings = {
    ZodString: "string",
    ZodNumber: "number",
    ZodBigInt: "integer",
    ZodBoolean: "boolean",
    ZodNull: "null"
};
function parseUnionDef(def, refs) {
    if (refs.target === "openApi3") return asAnyOf(def, refs);
    var options = _instanceof(def.options, Map) ? Array.from(def.options.values()) : def.options;
    // This blocks tries to look ahead a bit to produce nicer looking schemas with type array instead of anyOf.
    if (options.every(function(x) {
        return x._def.typeName in primitiveMappings && (!x._def.checks || !x._def.checks.length);
    })) {
        // all types in union are primitive and lack checks, so might as well squash into {type: [...]}
        var types = options.reduce(function(types, x) {
            var type = primitiveMappings[x._def.typeName]; //Can be safely casted due to row 43
            return type && !types.includes(type) ? _to_consumable_array$7(types).concat([
                type
            ]) : types;
        }, []);
        return {
            type: types.length > 1 ? types : types[0]
        };
    } else if (options.every(function(x) {
        return x._def.typeName === "ZodLiteral" && !x.description;
    })) {
        // all options literals
        var types1 = options.reduce(function(acc, x) {
            var type = _type_of(x._def.value);
            switch(type){
                case "string":
                case "number":
                case "boolean":
                    return _to_consumable_array$7(acc).concat([
                        type
                    ]);
                case "bigint":
                    return _to_consumable_array$7(acc).concat([
                        "integer"
                    ]);
                case "object":
                    if (x._def.value === null) return _to_consumable_array$7(acc).concat([
                        "null"
                    ]);
                case "symbol":
                case "undefined":
                case "function":
                default:
                    return acc;
            }
        }, []);
        if (types1.length === options.length) {
            // all the literals are primitive, as far as null can be considered primitive
            var uniqueTypes = types1.filter(function(x, i, a) {
                return a.indexOf(x) === i;
            });
            return {
                type: uniqueTypes.length > 1 ? uniqueTypes : uniqueTypes[0],
                enum: options.reduce(function(acc, x) {
                    return acc.includes(x._def.value) ? acc : _to_consumable_array$7(acc).concat([
                        x._def.value
                    ]);
                }, [])
            };
        }
    } else if (options.every(function(x) {
        return x._def.typeName === "ZodEnum";
    })) {
        return {
            type: "string",
            enum: options.reduce(function(acc, x) {
                return _to_consumable_array$7(acc).concat(_to_consumable_array$7(x._def.values.filter(function(x) {
                    return !acc.includes(x);
                })));
            }, [])
        };
    }
    return asAnyOf(def, refs);
}
var asAnyOf = function(def, refs) {
    var anyOf = (_instanceof(def.options, Map) ? Array.from(def.options.values()) : def.options).map(function(x, i) {
        return parseDef(x._def, _object_spread_props$7(_object_spread$7({}, refs), {
            currentPath: _to_consumable_array$7(refs.currentPath).concat([
                "anyOf",
                "".concat(i)
            ])
        }));
    }).filter(function(x) {
        return !!x && (!refs.strictUnions || typeof x === "object" && Object.keys(x).length > 0);
    });
    return anyOf.length ? {
        anyOf: anyOf
    } : undefined;
};

function _array_like_to_array$6(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$6(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$6(arr);
}
function _define_property$6(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$6(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$6() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$6(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$6(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$6(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$6(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$6(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$6(arr) {
    return _array_without_holes$6(arr) || _iterable_to_array$6(arr) || _unsupported_iterable_to_array$6(arr) || _non_iterable_spread$6();
}
function _unsupported_iterable_to_array$6(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$6(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$6(o, minLen);
}
function parseNullableDef(def, refs) {
    if ([
        "ZodString",
        "ZodNumber",
        "ZodBigInt",
        "ZodBoolean",
        "ZodNull"
    ].includes(def.innerType._def.typeName) && (!def.innerType._def.checks || !def.innerType._def.checks.length)) {
        if (refs.target === "openApi3") {
            return {
                type: primitiveMappings[def.innerType._def.typeName],
                nullable: true
            };
        }
        return {
            type: [
                primitiveMappings[def.innerType._def.typeName],
                "null"
            ]
        };
    }
    if (refs.target === "openApi3") {
        var base = parseDef(def.innerType._def, _object_spread_props$6(_object_spread$6({}, refs), {
            currentPath: _to_consumable_array$6(refs.currentPath)
        }));
        if (base && "$ref" in base) return {
            allOf: [
                base
            ],
            nullable: true
        };
        return base && _object_spread_props$6(_object_spread$6({}, base), {
            nullable: true
        });
    }
    var base1 = parseDef(def.innerType._def, _object_spread_props$6(_object_spread$6({}, refs), {
        currentPath: _to_consumable_array$6(refs.currentPath).concat([
            "anyOf",
            "0"
        ])
    }));
    return base1 && {
        anyOf: [
            base1,
            {
                type: "null"
            }
        ]
    };
}

function parseNumberDef(def, refs) {
    var res = {
        type: "number"
    };
    if (!def.checks) return res;
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = def.checks[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var check = _step.value;
            switch(check.kind){
                case "int":
                    res.type = "integer";
                    addErrorMessage(res, "type", check.message, refs);
                    break;
                case "min":
                    if (refs.target === "jsonSchema7") {
                        if (check.inclusive) {
                            setResponseValueAndErrors(res, "minimum", check.value, check.message, refs);
                        } else {
                            setResponseValueAndErrors(res, "exclusiveMinimum", check.value, check.message, refs);
                        }
                    } else {
                        if (!check.inclusive) {
                            res.exclusiveMinimum = true;
                        }
                        setResponseValueAndErrors(res, "minimum", check.value, check.message, refs);
                    }
                    break;
                case "max":
                    if (refs.target === "jsonSchema7") {
                        if (check.inclusive) {
                            setResponseValueAndErrors(res, "maximum", check.value, check.message, refs);
                        } else {
                            setResponseValueAndErrors(res, "exclusiveMaximum", check.value, check.message, refs);
                        }
                    } else {
                        if (!check.inclusive) {
                            res.exclusiveMaximum = true;
                        }
                        setResponseValueAndErrors(res, "maximum", check.value, check.message, refs);
                    }
                    break;
                case "multipleOf":
                    setResponseValueAndErrors(res, "multipleOf", check.value, check.message, refs);
                    break;
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return res;
}

function _array_like_to_array$5(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$5(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$5(arr);
}
function _define_property$5(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$5(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$5() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$5(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$5(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$5(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$5(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$5(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$5(arr) {
    return _array_without_holes$5(arr) || _iterable_to_array$5(arr) || _unsupported_iterable_to_array$5(arr) || _non_iterable_spread$5();
}
function _unsupported_iterable_to_array$5(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$5(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$5(o, minLen);
}
function parseObjectDef(def, refs) {
    var forceOptionalIntoNullable = refs.target === "openAi";
    var result = {
        type: "object",
        properties: {}
    };
    var required = [];
    var shape = def.shape();
    for(var propName in shape){
        var propDef = shape[propName];
        if (propDef === undefined || propDef._def === undefined) {
            continue;
        }
        var propOptional = safeIsOptional(propDef);
        if (propOptional && forceOptionalIntoNullable) {
            if (propDef._def.typeName === "ZodOptional") {
                propDef = propDef._def.innerType;
            }
            if (!propDef.isNullable()) {
                propDef = propDef.nullable();
            }
            propOptional = false;
        }
        var parsedDef = parseDef(propDef._def, _object_spread_props$5(_object_spread$5({}, refs), {
            currentPath: _to_consumable_array$5(refs.currentPath).concat([
                "properties",
                propName
            ]),
            propertyPath: _to_consumable_array$5(refs.currentPath).concat([
                "properties",
                propName
            ])
        }));
        if (parsedDef === undefined) {
            continue;
        }
        result.properties[propName] = parsedDef;
        if (!propOptional) {
            required.push(propName);
        }
    }
    if (required.length) {
        result.required = required;
    }
    var additionalProperties = decideAdditionalProperties(def, refs);
    if (additionalProperties !== undefined) {
        result.additionalProperties = additionalProperties;
    }
    return result;
}
function decideAdditionalProperties(def, refs) {
    if (def.catchall._def.typeName !== "ZodNever") {
        return parseDef(def.catchall._def, _object_spread_props$5(_object_spread$5({}, refs), {
            currentPath: _to_consumable_array$5(refs.currentPath).concat([
                "additionalProperties"
            ])
        }));
    }
    switch(def.unknownKeys){
        case "passthrough":
            return refs.allowedAdditionalProperties;
        case "strict":
            return refs.rejectedAdditionalProperties;
        case "strip":
            return refs.removeAdditionalStrategy === "strict" ? refs.allowedAdditionalProperties : refs.rejectedAdditionalProperties;
    }
}
function safeIsOptional(schema) {
    try {
        return schema.isOptional();
    } catch (e) {
        return true;
    }
}

function _array_like_to_array$4(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$4(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$4(arr);
}
function _define_property$4(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$4(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$4() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$4(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$4(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$4(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$4(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$4(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$4(arr) {
    return _array_without_holes$4(arr) || _iterable_to_array$4(arr) || _unsupported_iterable_to_array$4(arr) || _non_iterable_spread$4();
}
function _unsupported_iterable_to_array$4(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$4(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$4(o, minLen);
}
var parseOptionalDef = function(def, refs) {
    var _refs_propertyPath;
    if (refs.currentPath.toString() === ((_refs_propertyPath = refs.propertyPath) === null || _refs_propertyPath === void 0 ? void 0 : _refs_propertyPath.toString())) {
        return parseDef(def.innerType._def, refs);
    }
    var innerSchema = parseDef(def.innerType._def, _object_spread_props$4(_object_spread$4({}, refs), {
        currentPath: _to_consumable_array$4(refs.currentPath).concat([
            "anyOf",
            "1"
        ])
    }));
    return innerSchema ? {
        anyOf: [
            {
                not: parseAnyDef(refs)
            },
            innerSchema
        ]
    } : parseAnyDef(refs);
};

function _array_like_to_array$3(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$3(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$3(arr);
}
function _define_property$3(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$3(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$3() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$3(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$3(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$3(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$3(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$3(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$3(arr) {
    return _array_without_holes$3(arr) || _iterable_to_array$3(arr) || _unsupported_iterable_to_array$3(arr) || _non_iterable_spread$3();
}
function _unsupported_iterable_to_array$3(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$3(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$3(o, minLen);
}
var parsePipelineDef = function(def, refs) {
    if (refs.pipeStrategy === "input") {
        return parseDef(def.in._def, refs);
    } else if (refs.pipeStrategy === "output") {
        return parseDef(def.out._def, refs);
    }
    var a = parseDef(def.in._def, _object_spread_props$3(_object_spread$3({}, refs), {
        currentPath: _to_consumable_array$3(refs.currentPath).concat([
            "allOf",
            "0"
        ])
    }));
    var b = parseDef(def.out._def, _object_spread_props$3(_object_spread$3({}, refs), {
        currentPath: _to_consumable_array$3(refs.currentPath).concat([
            "allOf",
            a ? "1" : "0"
        ])
    }));
    return {
        allOf: [
            a,
            b
        ].filter(function(x) {
            return x !== undefined;
        })
    };
};

function parsePromiseDef(def, refs) {
    return parseDef(def.type._def, refs);
}

function _array_like_to_array$2(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$2(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$2(arr);
}
function _define_property$2(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$2(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$2() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$2(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$2(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$2(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$2(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$2(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$2(arr) {
    return _array_without_holes$2(arr) || _iterable_to_array$2(arr) || _unsupported_iterable_to_array$2(arr) || _non_iterable_spread$2();
}
function _unsupported_iterable_to_array$2(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$2(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$2(o, minLen);
}
function parseSetDef(def, refs) {
    var items = parseDef(def.valueType._def, _object_spread_props$2(_object_spread$2({}, refs), {
        currentPath: _to_consumable_array$2(refs.currentPath).concat([
            "items"
        ])
    }));
    var schema = {
        type: "array",
        uniqueItems: true,
        items: items
    };
    if (def.minSize) {
        setResponseValueAndErrors(schema, "minItems", def.minSize.value, def.minSize.message, refs);
    }
    if (def.maxSize) {
        setResponseValueAndErrors(schema, "maxItems", def.maxSize.value, def.maxSize.message, refs);
    }
    return schema;
}

function _array_like_to_array$1(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$1(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$1(arr);
}
function _define_property$1(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$1(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$1() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$1(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$1(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$1(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$1(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$1(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$1(arr) {
    return _array_without_holes$1(arr) || _iterable_to_array$1(arr) || _unsupported_iterable_to_array$1(arr) || _non_iterable_spread$1();
}
function _unsupported_iterable_to_array$1(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$1(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$1(o, minLen);
}
function parseTupleDef(def, refs) {
    if (def.rest) {
        return {
            type: "array",
            minItems: def.items.length,
            items: def.items.map(function(x, i) {
                return parseDef(x._def, _object_spread_props$1(_object_spread$1({}, refs), {
                    currentPath: _to_consumable_array$1(refs.currentPath).concat([
                        "items",
                        "".concat(i)
                    ])
                }));
            }).reduce(function(acc, x) {
                return x === undefined ? acc : _to_consumable_array$1(acc).concat([
                    x
                ]);
            }, []),
            additionalItems: parseDef(def.rest._def, _object_spread_props$1(_object_spread$1({}, refs), {
                currentPath: _to_consumable_array$1(refs.currentPath).concat([
                    "additionalItems"
                ])
            }))
        };
    } else {
        return {
            type: "array",
            minItems: def.items.length,
            maxItems: def.items.length,
            items: def.items.map(function(x, i) {
                return parseDef(x._def, _object_spread_props$1(_object_spread$1({}, refs), {
                    currentPath: _to_consumable_array$1(refs.currentPath).concat([
                        "items",
                        "".concat(i)
                    ])
                }));
            }).reduce(function(acc, x) {
                return x === undefined ? acc : _to_consumable_array$1(acc).concat([
                    x
                ]);
            }, [])
        };
    }
}

function parseUndefinedDef(refs) {
    return {
        not: parseAnyDef(refs)
    };
}

function parseUnknownDef(refs) {
    return parseAnyDef(refs);
}

var parseReadonlyDef = function(def, refs) {
    return parseDef(def.innerType._def, refs);
};

var selectParser = function(def, typeName, refs) {
    switch(typeName){
        case ZodFirstPartyTypeKind.ZodString:
            return parseStringDef(def, refs);
        case ZodFirstPartyTypeKind.ZodNumber:
            return parseNumberDef(def, refs);
        case ZodFirstPartyTypeKind.ZodObject:
            return parseObjectDef(def, refs);
        case ZodFirstPartyTypeKind.ZodBigInt:
            return parseBigintDef(def, refs);
        case ZodFirstPartyTypeKind.ZodBoolean:
            return parseBooleanDef();
        case ZodFirstPartyTypeKind.ZodDate:
            return parseDateDef(def, refs);
        case ZodFirstPartyTypeKind.ZodUndefined:
            return parseUndefinedDef(refs);
        case ZodFirstPartyTypeKind.ZodNull:
            return parseNullDef(refs);
        case ZodFirstPartyTypeKind.ZodArray:
            return parseArrayDef(def, refs);
        case ZodFirstPartyTypeKind.ZodUnion:
        case ZodFirstPartyTypeKind.ZodDiscriminatedUnion:
            return parseUnionDef(def, refs);
        case ZodFirstPartyTypeKind.ZodIntersection:
            return parseIntersectionDef(def, refs);
        case ZodFirstPartyTypeKind.ZodTuple:
            return parseTupleDef(def, refs);
        case ZodFirstPartyTypeKind.ZodRecord:
            return parseRecordDef(def, refs);
        case ZodFirstPartyTypeKind.ZodLiteral:
            return parseLiteralDef(def, refs);
        case ZodFirstPartyTypeKind.ZodEnum:
            return parseEnumDef(def);
        case ZodFirstPartyTypeKind.ZodNativeEnum:
            return parseNativeEnumDef(def);
        case ZodFirstPartyTypeKind.ZodNullable:
            return parseNullableDef(def, refs);
        case ZodFirstPartyTypeKind.ZodOptional:
            return parseOptionalDef(def, refs);
        case ZodFirstPartyTypeKind.ZodMap:
            return parseMapDef(def, refs);
        case ZodFirstPartyTypeKind.ZodSet:
            return parseSetDef(def, refs);
        case ZodFirstPartyTypeKind.ZodLazy:
            return function() {
                return def.getter()._def;
            };
        case ZodFirstPartyTypeKind.ZodPromise:
            return parsePromiseDef(def, refs);
        case ZodFirstPartyTypeKind.ZodNaN:
        case ZodFirstPartyTypeKind.ZodNever:
            return parseNeverDef(refs);
        case ZodFirstPartyTypeKind.ZodEffects:
            return parseEffectsDef(def, refs);
        case ZodFirstPartyTypeKind.ZodAny:
            return parseAnyDef(refs);
        case ZodFirstPartyTypeKind.ZodUnknown:
            return parseUnknownDef(refs);
        case ZodFirstPartyTypeKind.ZodDefault:
            return parseDefaultDef(def, refs);
        case ZodFirstPartyTypeKind.ZodBranded:
            return parseBrandedDef(def, refs);
        case ZodFirstPartyTypeKind.ZodReadonly:
            return parseReadonlyDef(def, refs);
        case ZodFirstPartyTypeKind.ZodCatch:
            return parseCatchDef(def, refs);
        case ZodFirstPartyTypeKind.ZodPipeline:
            return parsePipelineDef(def, refs);
        case ZodFirstPartyTypeKind.ZodFunction:
        case ZodFirstPartyTypeKind.ZodVoid:
        case ZodFirstPartyTypeKind.ZodSymbol:
            return undefined;
        default:
            return function(_) {
                return undefined;
            }();
    }
};

function parseDef(def, refs) {
    var forceResolution = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    var seenItem = refs.seen.get(def);
    if (refs.override) {
        var _refs_override;
        var overrideResult = (_refs_override = refs.override) === null || _refs_override === void 0 ? void 0 : _refs_override.call(refs, def, refs, seenItem, forceResolution);
        if (overrideResult !== ignoreOverride) {
            return overrideResult;
        }
    }
    if (seenItem && !forceResolution) {
        var seenSchema = get$ref(seenItem, refs);
        if (seenSchema !== undefined) {
            return seenSchema;
        }
    }
    var newItem = {
        def: def,
        path: refs.currentPath,
        jsonSchema: undefined
    };
    refs.seen.set(def, newItem);
    var jsonSchemaOrGetter = selectParser(def, def.typeName, refs);
    // If the return was a function, then the inner definition needs to be extracted before a call to parseDef (recursive)
    var jsonSchema = typeof jsonSchemaOrGetter === "function" ? parseDef(jsonSchemaOrGetter(), refs) : jsonSchemaOrGetter;
    if (jsonSchema) {
        addMeta(def, refs, jsonSchema);
    }
    if (refs.postProcess) {
        var postProcessResult = refs.postProcess(jsonSchema, def, refs);
        newItem.jsonSchema = jsonSchema;
        return postProcessResult;
    }
    newItem.jsonSchema = jsonSchema;
    return jsonSchema;
}
var get$ref = function(item, refs) {
    switch(refs.$refStrategy){
        case "root":
            return {
                $ref: item.path.join("/")
            };
        case "relative":
            return {
                $ref: getRelativePath(refs.currentPath, item.path)
            };
        case "none":
        case "seen":
            {
                if (item.path.length < refs.currentPath.length && item.path.every(function(value, index) {
                    return refs.currentPath[index] === value;
                })) {
                    console.warn("Recursive reference detected at ".concat(refs.currentPath.join("/"), "! Defaulting to any"));
                    return parseAnyDef(refs);
                }
                return refs.$refStrategy === "seen" ? parseAnyDef(refs) : undefined;
            }
    }
};
var addMeta = function(def, refs, jsonSchema) {
    if (def.description) {
        jsonSchema.description = def.description;
        if (refs.markdownDescription) {
            jsonSchema.markdownDescription = def.description;
        }
    }
    return jsonSchema;
};

function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array(arr);
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
var zodToJsonSchema = function(schema, options) {
    var refs = getRefs(options);
    var definitions = undefined;
    var name = void 0 ;
    var _parseDef;
    var main = (_parseDef = parseDef(schema._def, refs , false)) !== null && _parseDef !== void 0 ? _parseDef : parseAnyDef(refs);
    if (refs.flags.hasReferencedOpenAiAnyType) {
        if (!definitions) {
            definitions = {};
        }
        if (!definitions[refs.openAiAnyTypeName]) {
            definitions[refs.openAiAnyTypeName] = {
                // Skipping "object" as no properties can be defined and additionalProperties must be "false"
                type: [
                    "string",
                    "number",
                    "integer",
                    "boolean",
                    "array",
                    "null"
                ],
                items: {
                    $ref: refs.$refStrategy === "relative" ? "1" : _to_consumable_array(refs.basePath).concat([
                        refs.definitionPath,
                        refs.openAiAnyTypeName
                    ]).join("/")
                }
            };
        }
    }
    var combined = name === undefined ? definitions ? _object_spread_props(_object_spread({}, main), _define_property({}, refs.definitionPath, definitions)) : main : _define_property({
        $ref: _to_consumable_array(refs.$refStrategy === "relative" ? [] : refs.basePath).concat([
            refs.definitionPath,
            name
        ]).join("/")
    }, refs.definitionPath, _object_spread_props(_object_spread({}, definitions), _define_property({}, name, main)));
    if (refs.target === "jsonSchema7") {
        combined.$schema = "http://json-schema.org/draft-07/schema#";
    } else if (refs.target === "jsonSchema2019-09" || refs.target === "openAi") {
        combined.$schema = "https://json-schema.org/draft/2019-09/schema#";
    }
    if (refs.target === "openAi" && ("anyOf" in combined || "oneOf" in combined || "allOf" in combined || "type" in combined && Array.isArray(combined.type))) {
        console.warn("Warning: OpenAI may not support schemas with unions as roots! Try wrapping it in an object property.");
    }
    return combined;
};

function runtimeToolProviderComponent(provider) {
    var _extensions_resources, _extensions_resourceTemplates, _extensions_prompts;
    const descriptor = describeXpertToolProvider(provider);
    const options = descriptor.options;
    const extensions = resolveXpertMcpExtensions(provider, descriptor);
    // Fingerprint declarations only; never execute resource, prompt or completion handlers.
    const capabilities = _extends({}, (extensions == null ? void 0 : (_extensions_resources = extensions.resources) == null ? void 0 : _extensions_resources.length) ? {
        resources: extensions.resources.map((_param)=>{
            var { read } = _param, definition = _object_without_properties_loose$2(_param, [
                "read"
            ]);
            return definition;
        })
    } : {}, (extensions == null ? void 0 : (_extensions_resourceTemplates = extensions.resourceTemplates) == null ? void 0 : _extensions_resourceTemplates.length) ? {
        resourceTemplates: extensions.resourceTemplates.map((_param)=>{
            var { read, complete } = _param, definition = _object_without_properties_loose$2(_param, [
                "read",
                "complete"
            ]);
            return _extends({}, definition, {
                supportsCompletion: !!complete
            });
        })
    } : {}, (extensions == null ? void 0 : (_extensions_prompts = extensions.prompts) == null ? void 0 : _extensions_prompts.length) ? {
        prompts: extensions.prompts.map((_param)=>{
            var { get, complete } = _param, definition = _object_without_properties_loose$2(_param, [
                "get",
                "complete"
            ]);
            return _extends({}, definition, {
                hasCompletionHandler: !!complete
            });
        })
    } : {});
    const tools = descriptor.tools.map((tool)=>{
        var _tool_options_title, _tool_middlewareProvider, _tool_options_mcp_visibility;
        return {
            name: tool.options.name,
            title: (_tool_options_title = tool.options.title) != null ? _tool_options_title : null,
            description: tool.options.description,
            middleware: (_tool_middlewareProvider = tool.middlewareProvider) != null ? _tool_middlewareProvider : null,
            mcp: tool.options.mcp ? _extends({}, tool.options.mcp.inputSchema ? {
                transportInputSchema: JSON.parse(JSON.stringify(zodToJsonSchema(tool.options.mcp.inputSchema)))
            } : {}, tool.options.mcp.task ? {
                task: tool.options.mcp.task
            } : {}, {
                behavior: tool.options.mcp.behavior,
                requiredContext: [
                    ...tool.options.mcp.requiredContext
                ],
                visibility: [
                    ...(_tool_options_mcp_visibility = tool.options.mcp.visibility) != null ? _tool_options_mcp_visibility : [
                        'model'
                    ]
                ],
                inputSchema: JSON.parse(JSON.stringify(zodToJsonSchema(tool.options.inputSchema))),
                outputSchema: tool.options.outputSchema ? JSON.parse(JSON.stringify(zodToJsonSchema(tool.options.outputSchema))) : null
            }) : null
        };
    });
    var _options_description, _options_instructions;
    const config = {
        provider: options.provider,
        name: options.name,
        description: (_options_description = options.description) != null ? _options_description : null,
        instructions: (_options_instructions = options.instructions) != null ? _options_instructions : null,
        runtimeDiscovered: true,
        nativeMcp: true,
        toolCount: tools.filter((tool)=>!!tool.mcp).length
    };
    const metadata = {
        runtimeDiscovered: true,
        nativeMcp: true,
        toolNames: tools.filter((tool)=>!!tool.mcp).map((tool)=>tool.name)
    };
    return {
        componentType: PLUGIN_COMPONENT_TYPE.TOOLSET,
        componentKey: options.componentKey,
        config,
        metadata,
        definitionHash: createHash$1('sha256').update(stableJson(_extends({
            config,
            metadata,
            tools
        }, capabilities))).digest('hex')
    };
}
function stableJson(value) {
    if (value === undefined) return 'null';
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map((item)=>stableJson(item)).join(',')}]`;
    const entries = Object.entries(value).sort(([left], [right])=>left.localeCompare(right));
    return `{${entries.map(([key, item])=>`${JSON.stringify(key)}:${stableJson(item)}`).join(',')}}`;
}

const PROJECT_TYPE_PROVIDER = 'PROJECT_TYPE_PROVIDER';
/** Register the stable provider key used by entity-backed App project type declarations. */ const ProjectTypeProvider = (key)=>applyDecorators(SetMetadata(PROJECT_TYPE_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, PROJECT_TYPE_PROVIDER));
let ProjectTypeProviderRegistry = class ProjectTypeProviderRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(PROJECT_TYPE_PROVIDER, discovery, reflector);
    }
};
ProjectTypeProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ProjectTypeProviderRegistry);

const PROJECT_TASK_PROVIDER = 'PROJECT_TASK_PROVIDER';
const ProjectTaskProvider = (key)=>applyDecorators(SetMetadata(PROJECT_TASK_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, PROJECT_TASK_PROVIDER));
let ProjectTaskProviderRegistry = class ProjectTaskProviderRegistry extends BaseStrategyRegistry {
    constructor(discovery, reflector){
        super(PROJECT_TASK_PROVIDER, discovery, reflector);
    }
};
ProjectTaskProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ProjectTaskProviderRegistry);
const ProjectTasksRuntimeCapability = createRuntimeCapability('platform.project.tasks', {
    description: 'Read project task graphs and acceptance receipts, request background synchronization, manage schedules, and resolve exact execution conversations.'
});

class UnavailablePipelineContribution {
    constructor(metatype, issues){
        this.metatype = metatype;
        this.issues = issues;
    }
}
function pipelineContributionIssues(error) {
    // Do not log schema messages or input values, which may contain plugin configuration secrets.
    return error.issues.slice(0, 20).map(({ path, code })=>({
            path,
            code
        }));
}
function isolatePipelineContribution(target) {
    function IsolatedContribution(...args) {
        try {
            return Reflect.construct(target, args, new.target);
        } catch (error) {
            if (!Reflect.getMetadata(PLUGIN_METADATA_KEY, new.target) || !(error instanceof z.ZodError)) throw error;
            return new UnavailablePipelineContribution(new.target, pipelineContributionIssues(error));
        }
    }
    Object.setPrototypeOf(IsolatedContribution, target);
    IsolatedContribution.prototype = Object.create(target.prototype, {
        constructor: {
            value: IsolatedContribution,
            writable: true,
            configurable: true
        }
    });
    Object.defineProperty(IsolatedContribution, 'name', {
        value: target.name
    });
    // A class decorator must preserve the caller's constructor type; Reflect.construct preserves its arguments.
    return IsolatedContribution;
}

var ProjectPipelineContributionRegistry_1;
const PROJECT_PIPELINE_CONTRIBUTION = 'PROJECT_PIPELINE_CONTRIBUTION';
const ProjectPipelineContributor = (key)=>(target)=>{
        applyDecorators(SetMetadata(PROJECT_PIPELINE_CONTRIBUTION, key), SetMetadata(STRATEGY_META_KEY, PROJECT_PIPELINE_CONTRIBUTION))(target);
        return isolatePipelineContribution(target);
    };
let ProjectPipelineContributionRegistry = ProjectPipelineContributionRegistry_1 = class ProjectPipelineContributionRegistry extends BaseStrategyRegistry {
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        const key = target ? this.reflector.get(PROJECT_PIPELINE_CONTRIBUTION, target) : undefined;
        if (!key) return;
        const source = this.getSource(instance);
        try {
            if (instance instanceof UnavailablePipelineContribution) {
                this.rejectContribution(key, source, instance.issues);
                return;
            }
            const contribution = projectPipelineContributionSchema.parse(instance);
            if (key !== contribution.key) throw new Error('PIPELINE_CONTRIBUTION_KEY_MISMATCH');
            // Parsing validates public fields before preserving loader provenance.
            this.registerParsed(key, instance, contribution, source);
            this.failures.delete(this.failureIdentity(key, source));
        } catch (error) {
            if (source.kind !== 'plugin' || !(error instanceof z.ZodError)) throw error;
            this.rejectContribution(key, source, pipelineContributionIssues(error));
        }
    }
    getRegistrationFailures() {
        return structuredClone([
            ...this.failures.values()
        ]);
    }
    remove(scopeKey, pluginName) {
        super.remove(scopeKey, pluginName);
        for (const [identity, failure] of this.failures){
            if (failure.source.scopeKey === scopeKey && failure.source.pluginName === pluginName) this.failures.delete(identity);
        }
    }
    failureIdentity(key, source) {
        return JSON.stringify([
            source.scopeKey,
            source.kind === 'plugin' ? source.pluginName : null,
            key
        ]);
    }
    rejectContribution(key, source, issues) {
        var _this_strategies_get;
        if (source.kind !== 'plugin') throw new Error('PIPELINE_CONTRIBUTION_INVALID');
        const previous = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(key);
        if (previous) {
            const owner = this.getSource(previous);
            if (owner.kind === 'plugin' && owner.pluginName === source.pluginName) this.unregister(key, source, previous);
        }
        const failure = {
            key,
            source,
            code: 'PIPELINE_CONTRIBUTION_INVALID',
            issues
        };
        this.failures.set(this.failureIdentity(key, source), failure);
        this.failureLogger.error(failure);
    }
    register(key, contribution, source) {
        return this.registerParsed(key, contribution, projectPipelineContributionSchema.parse(contribution), source);
    }
    registerParsed(key, contribution, validated, source) {
        // Parsed metadata is immutable and source-local: sharing a cached object would overwrite
        // the loader provenance held by the base registry when another scope registers it.
        const identity = JSON.stringify([
            source.kind,
            source.scopeKey,
            source.kind === 'plugin' ? source.pluginName : null
        ]);
        var _this_parsedContributions_get;
        const cache = (_this_parsedContributions_get = this.parsedContributions.get(contribution)) != null ? _this_parsedContributions_get : new Map();
        const cached = cache.get(identity);
        const parsed = cached && JSON.stringify(cached) === JSON.stringify(validated) ? cached : validated;
        if (parsed.key !== key) throw new Error('PIPELINE_CONTRIBUTION_KEY_MISMATCH');
        freezeMetadata(parsed);
        const previous = super.register(key, parsed, source);
        cache.set(identity, parsed);
        this.parsedContributions.set(contribution, cache);
        return previous;
    }
    assertCanRegister(key, contribution, source) {
        var _this_strategies_get;
        const existing = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(key);
        if (existing) {
            const owner = this.getSource(existing);
            if (owner.kind !== source.kind || owner.kind === 'plugin' && source.kind === 'plugin' && owner.pluginName !== source.pluginName) {
                throw new Error('PIPELINE_CONTRIBUTION_OWNER_CONFLICT');
            }
            for (const previous of existing.configurations){
                const replacement = contribution.configurations.find((item)=>item.template.key === previous.template.key && item.template.version === previous.template.version);
                if (replacement && canonicalJson(previous.template) !== canonicalJson(replacement.template)) {
                    throw new Error('PIPELINE_DEFINITION_VERSION_IMMUTABLE');
                }
            }
        }
        super.assertCanRegister(key, contribution, source);
    }
    /** Explicit actor scope prevents a delegated call from inheriting an unrelated ambient tenant. */ listForActor(actor) {
        if (!actor.tenantId) return [];
        const tenantScope = actor.tenantId === getDefaultTenantId() ? GLOBAL_ORGANIZATION_SCOPE : getTenantGlobalScopeKey(actor.tenantId);
        const scopes = [
            ...new Set([
                actor.organizationId || tenantScope,
                tenantScope,
                SYSTEM_GLOBAL_SCOPE,
                BUILTIN_GLOBAL_SCOPE
            ])
        ];
        const effective = new Map();
        for (const scope of scopes){
            var _this_strategies_get;
            for (const [key, value] of (_this_strategies_get = this.strategies.get(scope)) != null ? _this_strategies_get : []){
                if (!effective.has(key)) effective.set(key, value);
            }
        }
        return Array.from(effective.values());
    }
    constructor(discovery, reflector){
        super(PROJECT_PIPELINE_CONTRIBUTION, discovery, reflector);
        this.parsedContributions = new WeakMap();
        this.failures = new Map();
        this.failureLogger = new Logger(ProjectPipelineContributionRegistry_1.name);
    }
};
ProjectPipelineContributionRegistry = ProjectPipelineContributionRegistry_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ProjectPipelineContributionRegistry);
/** Only validated JSON metadata is frozen; live adapter instances retain their own lifecycle. */ function freezeMetadata(value) {
    if (value === null || typeof value !== 'object' || Object.isFrozen(value)) return;
    for (const child of Object.values(value))freezeMetadata(child);
    Object.freeze(value);
}
function canonicalJson(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
    return `{${Object.keys(value).sort().filter((key)=>value[key] !== undefined).map((key)=>`${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
}

const ProjectPipelinePortfolioRuntimeCapability = createRuntimeCapability('platform.project.pipeline_portfolio', {
    description: 'Compare explicitly selected authorized Projects in one consistent snapshot.'
});
const ProjectPipelineAnalyticsRuntimeCapability = createRuntimeCapability('platform.project.pipeline_analytics', {
    description: 'Read Project-scoped cross-instance execution cohorts without replaying provider callbacks.'
});
const ProjectPipelineProviderActionsRuntimeCapability = createRuntimeCapability('platform.project.pipeline_provider_actions', {
    description: 'Submit version-bound provider actions through a durable, inspect-only recovery outbox.'
});
const ProjectPipelineEvidenceRuntimeCapability = createRuntimeCapability('platform.project.pipeline_evidence', {
    description: 'Read authorized, versioned pipeline evidence through its registered resolver.'
});
const ProjectPipelineCatalogRuntimeCapability = createRuntimeCapability('platform.project.pipeline_catalog', {
    description: 'Discover plugin-declared configuration forms and save authorized Project bindings.'
});
const ProjectPipelineConfigurationRuntimeCapability = createRuntimeCapability('platform.project.pipeline_configuration', {
    description: 'Check generic project pipeline configuration and registered extension dependencies without starting work.'
});
const ProjectPipelinesRuntimeCapability = createRuntimeCapability('platform.project.pipelines', {
    description: 'Read saved pipeline graphs and enqueue instance-scoped provider projections.'
});
const ProjectPipelineCommandsRuntimeCapability = createRuntimeCapability('platform.project.pipeline_commands', {
    description: 'Configure and start managed pipelines, and submit authorized version-bound human decisions.'
});

function pipelineActorScopeKeys(actor) {
    if (!actor.tenantId) return [];
    const tenant = actor.tenantId === getDefaultTenantId() ? GLOBAL_ORGANIZATION_SCOPE : getTenantGlobalScopeKey(actor.tenantId);
    return [
        ...new Set([
            actor.organizationId || tenant,
            tenant,
            SYSTEM_GLOBAL_SCOPE,
            BUILTIN_GLOBAL_SCOPE
        ])
    ];
}
/** Public capabilities resolve from their explicit, authorized actor, never another ambient request. */ class ProjectPipelineScopedRegistry extends BaseStrategyRegistry {
    assertCanRegister(key, instance, source) {
        var _this_strategies_get;
        const existing = (_this_strategies_get = this.strategies.get(source.scopeKey)) == null ? void 0 : _this_strategies_get.get(key);
        if (existing) {
            const owner = this.getSource(existing);
            if (owner.kind !== source.kind || owner.kind === 'plugin' && source.kind === 'plugin' && owner.pluginName !== source.pluginName) throw new Error('PIPELINE_ADAPTER_OWNER_CONFLICT');
        }
        // Live adapters cannot be cloned safely. Require a distinct instance for each provenance
        // so registration in one scope cannot silently change ownership in another.
        for (const [scope, entries] of this.strategies){
            if (![
                ...entries.values()
            ].includes(instance)) continue;
            const owner = this.getSource(instance);
            if (scope !== source.scopeKey || owner.kind !== source.kind || owner.kind === 'plugin' && source.kind === 'plugin' && owner.pluginName !== source.pluginName) throw new Error('PIPELINE_ADAPTER_SOURCE_CONFLICT');
        }
        super.assertCanRegister(key, instance, source);
    }
    upsert(instance) {
        const target = resolveStrategyMetadataTarget(instance);
        const key = target ? this.reflector.get(this.strategyKey, target) : undefined;
        if (key) this.register(key, instance, this.getSource(instance));
    }
    listForActor(actor) {
        const effective = new Map();
        var _this_strategies_get;
        for (const scope of pipelineActorScopeKeys(actor))for (const [key, adapter] of (_this_strategies_get = this.strategies.get(scope)) != null ? _this_strategies_get : []){
            if (!effective.has(key)) effective.set(key, adapter);
        }
        return [
            ...effective.values()
        ];
    }
    getForActor(key, actor) {
        for (const scope of pipelineActorScopeKeys(actor)){
            var _this_strategies_get;
            const adapter = (_this_strategies_get = this.strategies.get(scope)) == null ? void 0 : _this_strategies_get.get(key);
            if (adapter) return adapter;
        }
        throw new Error('PIPELINE_ADAPTER_UNAVAILABLE');
    }
}

const PROJECT_PIPELINE_PROJECTION_PROVIDER = 'PROJECT_PIPELINE_PROJECTION_PROVIDER';
const ProjectPipelineProjectionProvider = (key)=>applyDecorators(SetMetadata(PROJECT_PIPELINE_PROJECTION_PROVIDER, key), SetMetadata(STRATEGY_META_KEY, PROJECT_PIPELINE_PROJECTION_PROVIDER));
let ProjectPipelineProjectionProviderRegistry = class ProjectPipelineProjectionProviderRegistry extends ProjectPipelineScopedRegistry {
    register(key, provider, source) {
        projectPipelineRefSchema.parse(key);
        if (provider.key !== key) throw new Error('PIPELINE_PROVIDER_KEY_MISMATCH');
        // Registration checks the extension shape without executing business callbacks. A future
        // protocol must be negotiated explicitly rather than silently treated as a legacy provider.
        if (provider.nativeTaskProtocol !== undefined && provider.nativeTaskProtocol !== 1) throw new Error('PIPELINE_PROVIDER_PROTOCOL_UNSUPPORTED');
        if (typeof provider.snapshot !== 'function') throw new Error('PIPELINE_PROVIDER_CONTRACT_INVALID');
        for (const name of [
            'linked',
            'describeNode',
            'actions',
            'executeAction',
            'inspectAction'
        ]){
            if (provider[name] !== undefined && typeof provider[name] !== 'function') throw new Error('PIPELINE_PROVIDER_CONTRACT_INVALID');
        }
        if (provider.executeAction === undefined !== (provider.inspectAction === undefined) || provider.actions !== undefined && provider.executeAction === undefined) throw new Error('PIPELINE_PROVIDER_CONTRACT_INVALID');
        return super.register(key, provider, source);
    }
    constructor(discovery, reflector){
        super(PROJECT_PIPELINE_PROJECTION_PROVIDER, discovery, reflector);
    }
};
ProjectPipelineProjectionProviderRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ProjectPipelineProjectionProviderRegistry);

const PROJECT_PIPELINE_RUNTIME_ADAPTER = 'PROJECT_PIPELINE_RUNTIME_ADAPTER';
const ProjectPipelineRuntimeAdapterProvider = (kind, ref)=>applyDecorators(SetMetadata(PROJECT_PIPELINE_RUNTIME_ADAPTER, `${kind}:${projectPipelineRefSchema.parse(ref)}`), SetMetadata(STRATEGY_META_KEY, PROJECT_PIPELINE_RUNTIME_ADAPTER));
let ProjectPipelineRuntimeAdapterRegistry = class ProjectPipelineRuntimeAdapterRegistry extends ProjectPipelineScopedRegistry {
    register(key, adapter, source) {
        projectPipelineRefSchema.parse(adapter.ref);
        if (key !== `${adapter.kind}:${adapter.ref}`) throw new Error('PIPELINE_ADAPTER_KEY_MISMATCH');
        switch(adapter.kind){
            case 'resource':
                if (typeof adapter.resolve !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'assistant_operation':
            case 'runtime_operation':
                if (typeof adapter.prepare !== 'function' || typeof adapter.collect !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'schema':
                if (typeof adapter.parse !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'subject':
                if (typeof adapter.resolve !== 'function' || typeof adapter.checkCurrent !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'evidence':
                if (typeof adapter.read !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'operation':
            case 'subscription':
                if (typeof adapter.execute !== 'function' || typeof adapter.inspect !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            case 'completion':
            case 'policy':
                if (typeof adapter.evaluate !== 'function') throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
                break;
            default:
                throw new Error('PIPELINE_ADAPTER_CONTRACT_INVALID');
        }
        return super.register(key, adapter, source);
    }
    resolve(kind, ref, actor) {
        const adapter = this.getForActor(`${kind}:${ref}`, actor);
        if (adapter.kind !== kind || adapter.ref !== ref) throw new Error('PIPELINE_ADAPTER_KEY_MISMATCH');
        return adapter;
    }
    constructor(discovery, reflector){
        super(PROJECT_PIPELINE_RUNTIME_ADAPTER, discovery, reflector);
    }
};
ProjectPipelineRuntimeAdapterRegistry = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [
        DiscoveryService,
        Reflector
    ])
], ProjectPipelineRuntimeAdapterRegistry);

/** Import official resource packages for the authenticated organization administrator. Does not authorize workspaces. */ class ImportDefaultAgentPluginsCommand extends Command {
}
ImportDefaultAgentPluginsCommand.type = '[Agent Plugins] Import defaults';
Reflect.defineMetadata('__command__', {
    id: ImportDefaultAgentPluginsCommand.type
}, ImportDefaultAgentPluginsCommand);

function agentEventDigest(value) {
    const sorted = JSON.stringify(value, (_key, item)=>{
        if (item && typeof item === 'object' && !Array.isArray(item)) return Object.fromEntries(Object.entries(item).sort(([a], [b])=>a < b ? -1 : a > b ? 1 : 0));
        return item;
    });
    return createHash$1('sha256').update(sorted).digest('hex');
}
/** PostgreSQL source journal scoped to one plugin's own route and fact tables. */ class PluginEventJournal {
    async lock(tx, origin) {
        await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [
            JSON.stringify([
                this.routes,
                origin.tenantId,
                origin.organizationId,
                origin.ref
            ])
        ]);
    }
    async configure(tx, ctx, enabled) {
        const origin = {
            tenantId: ctx.tenantId,
            organizationId: ctx.organizationId,
            ref: ctx.sourceBindingRef
        };
        await this.lock(tx, origin);
        const [route] = await tx.query(`SELECT * FROM ${this.routes} WHERE tenant=$1 AND org=$2 AND ref=$3`, [
            origin.tenantId,
            origin.organizationId,
            origin.ref
        ]);
        if (route && (route.binding !== ctx.bindingId || route.revision > ctx.bindingRevision)) throw new Error('source_binding_changed');
        await tx.query(`INSERT INTO ${this.routes}(binding,tenant,org,ref,revision,enabled) VALUES($1,$2,$3,$4,$5,$6)
      ON CONFLICT(binding) DO UPDATE SET revision=EXCLUDED.revision,enabled=EXCLUDED.enabled`, [
            ctx.bindingId,
            ctx.tenantId,
            ctx.organizationId,
            ctx.sourceBindingRef,
            ctx.bindingRevision,
            enabled
        ]);
    }
    async route(tx, origin) {
        await this.lock(tx, origin);
        const [route] = await tx.query(`SELECT * FROM ${this.routes} WHERE tenant=$1 AND org=$2 AND ref=$3`, [
            origin.tenantId,
            origin.organizationId,
            origin.ref
        ]);
        return route;
    }
    async capture(tx, route, data, snapshot, factKey, revision) {
        const event = pluginAgentEventSchema.parse(_extends({}, data, {
            bindingRevision: route.revision,
            fact: {
                key: factKey,
                revision,
                sha256: agentEventDigest(snapshot)
            }
        }));
        const [existing] = await tx.query(`SELECT event FROM ${this.facts} WHERE binding=$1 AND source=$2`, [
            route.binding,
            event.sourceEventId
        ]);
        if (existing) {
            if (existing.event.type !== event.type || existing.event.schemaVersion !== event.schemaVersion || existing.event.fact.key !== event.fact.key || existing.event.fact.revision !== event.fact.revision || existing.event.fact.sha256 !== event.fact.sha256 || existing.event.subject.key !== event.subject.key || existing.event.subject.kind !== event.subject.kind) throw new Error('event_source_conflict');
            return true;
        }
        if (!route.enabled) return false;
        await tx.query(`INSERT INTO ${this.facts}(id,binding,source,event,snapshot) VALUES($1,$2,$3,$4,$5)`, [
            randomUUID(),
            route.binding,
            event.sourceEventId,
            event,
            JSON.stringify(snapshot)
        ]);
        return true;
    }
    async drain(db, ctx, publisher, limit) {
        const scope = [
            ctx.bindingId,
            ctx.tenantId,
            ctx.organizationId,
            ctx.sourceBindingRef,
            ctx.bindingRevision
        ];
        // The current worker may reconcile older facts (including a lost receipt ACK), never a later revision.
        const routeScope = 'r.binding=$1 AND r.tenant=$2 AND r.org=$3 AND r.ref=$4 AND r.revision=$5';
        const facts = await db.query(`SELECT f.id,f.event FROM ${this.facts} f JOIN ${this.routes} r USING(binding)
      WHERE ${routeScope} AND (f.event->>'bindingRevision')::numeric <= r.revision AND f.receipt IS NULL
      AND (f.error IS NULL OR (f.error='binding_changed' AND f.event->>'bindingRevision'=r.revision::text))
      ORDER BY f.seq LIMIT $6`, [
            ...scope,
            limit
        ]);
        for (const fact of facts){
            ctx.signal.throwIfAborted();
            const result = await publisher.publish(fact.event);
            if (result.status === 'rejected') {
                // The host may already have advanced or may still be enabling this revision.
                if (result.code === 'binding_changed' && fact.event.bindingRevision === ctx.bindingRevision) return {
                    more: false
                };
                await db.query(`WITH current_route AS (SELECT r.binding FROM ${this.routes} r WHERE ${routeScope} FOR SHARE)
          UPDATE ${this.facts} f SET error=$7 FROM current_route r
          WHERE f.binding=r.binding AND f.id=$6 AND f.receipt IS NULL`, [
                    ...scope,
                    fact.id,
                    result.code
                ]);
            } else {
                // A committed host receipt remains authoritative even if the route changed while awaiting its ACK.
                await db.query(`UPDATE ${this.facts} SET receipt=$2,error=NULL WHERE id=$1 AND binding=$3 AND (receipt IS NULL OR receipt=$2)`, [
                    fact.id,
                    result.receiptId,
                    ctx.bindingId
                ]);
            }
        }
        return {
            more: facts.length === limit
        };
    }
    async decide(tx, ctx, delivery, apply) {
        const [fact] = await tx.query(`SELECT f.* FROM ${this.facts} f JOIN ${this.routes} r USING(binding)
      WHERE r.binding=$1 AND r.tenant=$2 AND r.org=$3 AND r.ref=$4 AND r.revision=$5 AND f.source=$6
      FOR SHARE OF r FOR UPDATE OF f`, [
            ctx.bindingId,
            ctx.tenantId,
            ctx.organizationId,
            ctx.sourceBindingRef,
            ctx.bindingRevision,
            delivery.event.sourceEventId
        ]);
        if (!fact || fact.event.bindingRevision !== ctx.bindingRevision || agentEventDigest(fact.event) !== agentEventDigest(delivery.event) || agentEventDigest(fact.snapshot) !== delivery.event.fact.sha256 || fact.receipt && fact.receipt !== delivery.receiptId) return {
            status: 'blocked',
            reasonCode: 'source_binding_changed'
        };
        if (fact.decision) return agentEventDecisionSchema.parse(fact.decision);
        const partition = JSON.stringify([
            ctx.bindingId,
            delivery.event.subject.kind,
            delivery.event.subject.key
        ]);
        await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [
            partition
        ]);
        const [newer] = await tx.query(`SELECT EXISTS(SELECT 1 FROM ${this.facts} WHERE binding=$1
      AND event->'subject'=$2::jsonb AND fence>$3::bigint) AS exists`, [
            ctx.bindingId,
            JSON.stringify(delivery.event.subject),
            delivery.fence
        ]);
        if (newer.exists) throw new Error('stale_event_fence');
        ctx.signal.throwIfAborted();
        const result = agentEventDecisionSchema.parse(await apply(fact.snapshot));
        ctx.signal.throwIfAborted();
        await tx.query(`UPDATE ${this.facts} SET decision=$2,receipt=$3,fence=$4 WHERE id=$1`, [
            fact.id,
            result,
            delivery.receiptId,
            delivery.fence
        ]);
        return result;
    }
    constructor(prefix){
        if (!/^[a-z][a-z0-9_]{1,45}$/.test(prefix)) throw new Error('invalid_event_journal_prefix');
        this.routes = prefix + '_route';
        this.facts = prefix + '_fact';
    }
}

const AGENT_EVENT_SOURCE = 'XPERT_AGENT_EVENT_SOURCE_V1';
const AgentEventSourceStrategy = (key)=>applyDecorators(SetMetadata(AGENT_EVENT_SOURCE, key), SetMetadata(STRATEGY_META_KEY, AGENT_EVENT_SOURCE));

export { ACCOUNT_BINDING_PERMISSION_SERVICE_TOKEN, AGENT_CHAT_DISPATCH_ERROR_STEER_TARGET_NOT_RUNNING, AGENT_CHAT_DISPATCH_MESSAGE_TYPE, AGENT_EVENT_SOURCE, AGENT_MIDDLEWARE_STRATEGY, AGENT_PROCESS_SUPERVISOR, AGENT_RUNTIME_EVENT_MESSAGE_TYPE, AGENT_RUNTIME_STRATEGY, AIModel, AIModelProviderNotFoundException, AIModelProviderRegistry, AIModelProviderStrategy, AI_MODEL_PROVIDER, ANALYTICS_PROVIDER, ARTIFACT_PRESENTATION_PROVIDER, ARTIFACT_TYPE_PROVIDER, ASSISTANT_CAPABILITY_PROVIDER, AdapterDataSourceStrategy, AgentEventSourceStrategy, AgentExecutionRunnerCapability, AgentExecutionRunnerFactoryCapability, AgentInvocationRuntimeCapability, AgentMiddlewareRegistry, AgentMiddlewareStrategy, AgentRuntimeDeploymentCapability, AgentRuntimeFactoryCapability, AgentRuntimeRegistry, AgentRuntimeStrategy, AiModelNotFoundException, AnalyticsDefinitionAuthoringCapability, AnalyticsProvider, AnalyticsProviderError, AnalyticsProviderRegistry, AnalyticsRuntimeCapability, ArtifactPresentationProvider, ArtifactPresentationRegistry, ArtifactTypeProvider, ArtifactTypeRegistry, AssistantCapabilityProvider, AssistantCapabilityProviderRegistry, AssistantTaskRuntimeCapability, BOUND_IDENTITY_LOGIN_PERMISSION_SERVICE_TOKEN, BUILTIN_GLOBAL_SCOPE, BaseHTTPQueryRunner, BaseQueryRunner, BaseSQLQueryRunner, BaseSandbox, BaseStrategyRegistry, BuiltinToolset, CHAT_CHANNEL, CHAT_CHANNEL_TEXT_LIMITS, CLI_MODEL_TOKEN_REFERENCE, COLLABORATION_DOCUMENT_PROVIDER, CONNECTION_COMMAND_ROUTER_TOKEN, CONNECTOR_STRATEGY, CONTENT_RESOURCE_PROVIDER, CancelConversationCommand, ChatChannel, ChatChannelRegistry, ChatOAICompatReasoningModel, CliModelProfilesCapability, CollaborationDocumentProvider, CollaborationDocumentProviderRegistry, CollaborationRuntimeCapability, CommonParameterRules, ConnectorDocumentsRuntimeCapability, ConnectorRuntimeCapability, ConnectorRuntimeFactoryCapability, ConnectorStrategyKey, ConnectorStrategyRegistry, ContentDocumentsRuntimeCapability, ContentEditorProvider, ContentEditorRegistry, ContentEditorsRuntimeCapability, ContentReferencesRuntimeCapability, ContentResourceProvider, ContentResourceProviderRegistry, ContentResourcesRuntimeCapability, CreateModelClientCommand, CredentialsValidateFailedError, DATASOURCE_STRATEGY, DBCreateTableMode, DBProtocolEnum, DBSyntaxEnum, DBTableAction, DBTableDataAction, DEFAULT_EXECUTION_CONFIG, DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES, DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS, DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_MS, DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_SEC, DEFAULT_SANDBOX_FILE_SEARCH_EXECUTION_OPTIONS, DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_MS, DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_SEC, DEFAULT_SANDBOX_SHELL_EXECUTION_OPTIONS, DEFAULT_SANDBOX_SHELL_TIMEOUT_MS, DEFAULT_SANDBOX_SHELL_TIMEOUT_SEC, DOCUMENT_SOURCE_STRATEGY, DOCUMENT_TRANSFORMER_STRATEGY, DataSourceStrategy, DataSourceStrategyRegistry, DecoratedAgentMiddlewareStrategy, DecoratedToolsetStrategy, DocumentSourceRegistry, DocumentSourceStrategy, DocumentTransformerRegistry, DocumentTransformerStrategy, EVOLUTION_RUNTIME_SERVICE_TOKEN, EVOLUTION_TARGET_PROVIDER, EvolutionBaselineRuntimeCapability, EvolutionChangeRuntimeCapability, EvolutionRuntimeCapability, EvolutionTargetProviderRegistry, EvolutionTargetProviderStrategy, ExecutionObservabilityRuntimeCapability, ExecutionReviewRuntimeCapability, FILE_ARTIFACT_TYPE, FILE_STORAGE_PROVIDER, FILE_UPLOAD_TARGET_STRATEGY, FileRuntimeCapability, FileStorageProvider, FileStorageProviderRegistry, FileUploadTargetRegistry, FileUploadTargetStrategy, GLOBAL_ORGANIZATION_SCOPE, HANDOFF_PERMISSION_SERVICE_TOKEN, HANDOFF_PROCESSOR_STRATEGY, HANDOFF_QUEUE_SERVICE_TOKEN, HandoffProcessorRegistry, HandoffProcessorStrategy, IMAGE_UNDERSTANDING_STRATEGY, INTEGRATION_PERMISSION_SERVICE_TOKEN, INTEGRATION_STRATEGY, ImageGenerationModel, ImageUnderstandingRegistry, ImageUnderstandingStrategy, ImportDefaultAgentPluginsCommand, IntegrationStrategyKey, IntegrationStrategyRegistry, JUMP_TO_TARGETS, JsonSchemaValidator, KEYWORD_ANALYZER_STRATEGY, KNOWLEDGE_STRATEGY, KeywordAnalyzerRegistry, KeywordAnalyzerStrategy, KnowledgeDocumentVisualAssetsRuntimeCapability, KnowledgeDocumentVisualAssetsRuntimeFactoryCapability, KnowledgeGraphRuntimeCapability, KnowledgeStrategyKey, KnowledgeStrategyRegistry, KnowledgebaseDocumentsRuntimeCapability, KnowledgebaseProvisioningRuntimeCapability, KnowledgebaseRuntimeCapability, LLMUsage, LargeLanguageModel, ListAnalyticsSourcesCommand, MANAGED_CONNECTION_REGISTRY_TOKEN, MANAGED_QUEUE_HANDLER_REGISTRY_TOKEN, MANAGED_QUEUE_SERVICE_TOKEN, MCP_CAPABILITY_CHANGE_EVENT_TYPES, MODEL_OUTPUT_VALIDATION_ERROR_CODE, ModelExecutionEnvironmentCapability, ModelOutputValidationError, ModelProvider, ORGANIZATION_METADATA_KEY, OpenAICompatibleEmbeddings, OpenAICompatibleReranker, PERMISSION_OPERATION_METADATA_KEY, PLUGIN_CONFIG_RESOLVER_TOKEN, PLUGIN_JOB_PROCESSOR_METADATA, PLUGIN_METADATA, PLUGIN_METADATA_KEY, PLUGIN_VERSION_METADATA_KEY, PLUGIN_WEBHOOK_AUTH_METADATA_KEY, PLUGIN_WEBHOOK_AUTH_SERVICE_TOKEN, PROJECT_PIPELINE_CONTRIBUTION, PROJECT_PIPELINE_PROJECTION_PROVIDER, PROJECT_PIPELINE_RUNTIME_ADAPTER, PROJECT_TASK_PROVIDER, PROJECT_TYPE_PROVIDER, PROVIDE_AI_MODEL_LLM, PROVIDE_AI_MODEL_MODERATION, PROVIDE_AI_MODEL_RERANK, PROVIDE_AI_MODEL_SPEECH2TEXT, PROVIDE_AI_MODEL_TEXT_EMBEDDING, PROVIDE_AI_MODEL_TTS, PluginEventJournal, PluginJobProcessor, PluginWebhookAuth, PluginWebhookAuthGuard, ProjectPipelineAnalyticsRuntimeCapability, ProjectPipelineCatalogRuntimeCapability, ProjectPipelineCommandsRuntimeCapability, ProjectPipelineConfigurationRuntimeCapability, ProjectPipelineContributionRegistry, ProjectPipelineContributor, ProjectPipelineEvidenceRuntimeCapability, ProjectPipelinePortfolioRuntimeCapability, ProjectPipelineProjectionProvider, ProjectPipelineProjectionProviderRegistry, ProjectPipelineProviderActionsRuntimeCapability, ProjectPipelineRuntimeAdapterProvider, ProjectPipelineRuntimeAdapterRegistry, ProjectPipelinesRuntimeCapability, ProjectTaskProvider, ProjectTaskProviderRegistry, ProjectTasksRuntimeCapability, ProjectTypeProvider, ProjectTypeProviderRegistry, RESOURCE_CARD_EVENT, RESOURCE_CARD_PROVIDER, RETRIEVER_STRATEGY, RequestContext, RequestContextMiddleware, RequirePermissionOperation, RerankModel, ResolveAnalyticsSourceCommand, ResolveConnectorIntegrationQuery, ResourceCardProvider, ResourceCardProviderRegistry, RetrieverRegistry, RetrieverStrategy, SANDBOX_PROVIDER, SANDBOX_RUNTIME_PROVIDER, SANDBOX_SHELL_TIMEOUT_LIMITS_SEC, SANDBOX_WORKSPACE_MAPPER, SKILL_SOURCE_PROVIDER, SPEECH_TO_TEXT_PERMISSION_SERVICE_TOKEN, SPEECH_TO_TEXT_SERVICE_TOKEN, SSOProviderRegistry, SSOProviderStrategyKey, SSO_BINDING_PERMISSION_SERVICE_TOKEN, SSO_PROVIDER, STRATEGY_META_KEY, SYSTEM_GLOBAL_SCOPE, SandboxProviderRegistry, SandboxProviderStrategy, SandboxRuntimeProviderRegistry, SandboxRuntimeProviderStrategy, SandboxWorkspaceMapperRegistry, SandboxWorkspaceMapperStrategy, ShellModelExecutionSourceCapability, SkillSourceProviderRegistry, SkillSourceProviderStrategy, Speech2TextChatModel, SpeechToTextModel, StrategyBus, TENANT_GLOBAL_SCOPE_PREFIX, TENANT_GLOBAL_SCOPE_SUFFIX, TEXT_SPLITTER_STRATEGY, TOOLSET_STRATEGY, TextEmbeddingModelManager, TextSplitterRegistry, TextSplitterStrategy, TextToSpeechModel, ToolsetRegistry, ToolsetStrategy, USER_PERMISSION_SERVICE_TOKEN, VECTOR_STORE_STRATEGY, VIDEO_GENERATION_PERMISSION_SERVICE_TOKEN, VIDEO_GENERATION_SERVICE_TOKEN, VIDEO_GENERATOR_FAMILIES, VIEW_EXTENSION_CACHE_SERVICE_TOKEN, VIEW_EXTENSION_PROVIDER, VectorStoreRegistry, VectorStoreStrategy, VideoGenerationModel, ViewExtensionProvider, ViewExtensionProviderRegistry, ViewMiddlewareRuntimeCapability, WORKFLOW_NODE_STRATEGY, WORKFLOW_TRIGGER_STRATEGY, WorkbenchDecisionCapability, WorkflowNodeRegistry, WorkflowNodeStrategy, WorkflowTriggerRegistry, WorkflowTriggerStrategy, WorkspaceFilesRuntimeCapability, WrapWorkflowNodeExecutionCommand, XPERT_AGENT_MIDDLEWARE_RUNTIME_TOKEN, XPERT_TOOL_METHOD_METADATA, XPERT_TOOL_PROVIDER, XPERT_TOOL_PROVIDER_METADATA, XPERT_TOOL_RESULT_FORMAT_VERSION, XpFileSystem, XpertPrompt, XpertResource, XpertResourceTemplate, XpertServerPlugin, XpertTool, XpertToolProvider, XpertToolProviderCoordinator, XpertToolProviderRegistry, agentEventDigest, agentInvocationDispatchContextSchema, agentRuntimeConsumptionStateSchema, agentRuntimeDeliveryStateSchema, agentRuntimeDeploymentSpecSchema, agentRuntimeEventMessageId, agentRuntimeEventSchema, agentRuntimeReplyTargetSchema, agentRuntimeResultClaimSchema, agentRuntimeResultConsumptionKey, als, appendSandboxMessage, applyAssistantMiddleware, applyModelConfiguration, applyModelContextSize, artifactPresentationKey, artifactTypeKey, assertConnectorDefinition, assertXpertToolProviderClaims, buildSandboxTimeoutMessage, calcTokenUsage, calculateLLMUsagePrice, calculateModelPrice, calculateModelUsageCharge, canonicalEvolutionJson, chunkText, countTextTokens, countTokensSafe, createI18nInstance, createMutationEvidence, createPluginLogger, createRuntimeCapability, defineAgentMessageType, defineChannelMessageType, defineMcpApp, defineMcpCapabilities, defineMcpPrompt, defineMcpResource, defineMcpResourceTemplate, defineXpertTool, derivePluginArtifactNamespace, describeXpertToolProvider, discoverOpenAIModels, downloadRemoteFile, emitResourceCard, formatSandboxTimeout, getDefaultTenantId, getErrorMessage, getModelContextSize, getPermissionOperationMetadata, getPositionList, getPositionMap, getRequestContext, getRequiredPermissionOperation, getTenantGlobalScopeKey, getXpertToolMethod, hasAssistantMiddleware, hashEvolutionValue, isAgentInvocationTerminal, isDevelopmentSandboxRuntimeEnvironment, isExecutionObservationSession, isFileContentEditor, isModelOutputValidationError, isModelUsagePricingConfig, isPluginArtifactNamespace, isRemoteFile, isResourceContentEditor, isSandboxBackend, isSandboxManagedServiceAdapter, isSandboxServiceProxyAdapter, isSandboxTerminalAdapter, isStrategyInstance, isStructuredMessageType, isTenantGlobalScopeKey, isTextContentEditor, jsonEncodedSchema, knowledgebaseActions, loadYamlFile, managedAgentRuntimeSchema, mergeCredentials, mergeModelRequirements, mergeParentChildChunks, nativeModelTransport, normalizeContextSize, normalizeTokenUsage, pluginArtifactTableName, prepareToolResult, processAsyncAIGCManagedJob, projectPipelineInvocationScopeSchema, readAnalyticsProviderDiagnostic, renderRemoteModuleIframeHtml, renderRemoteReactIframeHtml, renderRemoteVueIframeHtml, resolveModelUsagePricingSnapshot, resolveSandboxBackend, resolveSandboxExecutionOptions, resolveSandboxManagedServiceAdapter, resolveSandboxServiceProxyAdapter, resolveSandboxTerminalAdapter, resolveStrategyMetadataTarget, resolveTenantGlobalScopeKey, resolveTokenUsage, resolveTokenUsageCandidates, resolveXpertMcpExtensions, runWithRequestContext, runtimeToolProviderComponent, secondsToMilliseconds, setDefaultTenantId, sumTokenUsage, supportsContentModel, taskWaitReason, textTokenBoundaries, validateAnalyticsPayload };
