import { z } from 'zod/v3';
/** Package exports are a runtime boundary; reject malformed declarations before registration. */
export declare const artifactTypeDefinitionSchema: z.ZodEffects<z.ZodEffects<z.ZodObject<{
    contentTypeId: z.ZodOptional<z.ZodString>;
    icon: z.ZodOptional<z.ZodObject<{
        type: z.ZodEnum<["image", "svg", "font", "emoji", "lottie"]>;
        value: z.ZodString;
        color: z.ZodOptional<z.ZodString>;
        size: z.ZodOptional<z.ZodNumber>;
        alt: z.ZodOptional<z.ZodString>;
        style: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    }, {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    }>>;
    title: z.ZodOptional<z.ZodObject<{
        en_US: z.ZodString;
        zh_Hans: z.ZodOptional<z.ZodString>;
        zh_Hant: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    }, {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    }>>;
    kinds: z.ZodArray<z.ZodEnum<["html", "markdown", "pdf", "pptx", "image", "file", "site", "presentation"]>, "many">;
    collection: z.ZodOptional<z.ZodObject<{
        allowCopy: z.ZodBoolean;
    }, "strict", z.ZodTypeAny, {
        allowCopy?: boolean;
    }, {
        allowCopy?: boolean;
    }>>;
    useGrants: z.ZodOptional<z.ZodObject<{
        audience: z.ZodLiteral<"group">;
        permission: z.ZodLiteral<"read">;
        queryOperations: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }, "strict", z.ZodTypeAny, {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    }, {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    }>>;
    versioning: z.ZodOptional<z.ZodObject<{
        mode: z.ZodLiteral<"draft-only">;
    }, "strict", z.ZodTypeAny, {
        mode?: "draft-only";
    }, {
        mode?: "draft-only";
    }>>;
    content: z.ZodOptional<z.ZodObject<{
        mimeTypes: z.ZodArray<z.ZodString, "many">;
        maxBytes: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        mimeTypes?: string[];
        maxBytes?: number;
    }, {
        mimeTypes?: string[];
        maxBytes?: number;
    }>>;
    sharing: z.ZodOptional<z.ZodObject<{
        projectAccess: z.ZodOptional<z.ZodLiteral<"link-audience">>;
        accessModes: z.ZodArray<z.ZodEnum<["owner_only", "workspace_all", "organization_all", "custom_principals", "public_link", "signed_preview"]>, "many">;
        versionModes: z.ZodArray<z.ZodEnum<["latest", "version"]>, "many">;
        maxTtlSeconds: z.ZodOptional<z.ZodNumber>;
        allowDownload: z.ZodBoolean;
        mutableLinks: z.ZodBoolean;
        descriptor: z.ZodBoolean;
        shareKey: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    }, {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    }>>;
    presentation: z.ZodObject<{
        mode: z.ZodEnum<["file", "snapshot", "authenticated"]>;
    }, "strict", z.ZodTypeAny, {
        mode?: "file" | "authenticated" | "snapshot";
    }, {
        mode?: "file" | "authenticated" | "snapshot";
    }>;
}, "strict", z.ZodTypeAny, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}>, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}>, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}, {
    title?: {
        en_US?: string;
        zh_Hans?: string;
        zh_Hant?: string;
    };
    collection?: {
        allowCopy?: boolean;
    };
    icon?: {
        size?: number;
        color?: string;
        type?: "image" | "svg" | "font" | "emoji" | "lottie";
        value?: string;
        alt?: string;
        style?: Record<string, string>;
    };
    content?: {
        mimeTypes?: string[];
        maxBytes?: number;
    };
    presentation?: {
        mode?: "file" | "authenticated" | "snapshot";
    };
    contentTypeId?: string;
    kinds?: ("file" | "image" | "html" | "markdown" | "pdf" | "pptx" | "site" | "presentation")[];
    useGrants?: {
        audience?: "group";
        permission?: "read";
        queryOperations?: string[];
    };
    versioning?: {
        mode?: "draft-only";
    };
    sharing?: {
        projectAccess?: "link-audience";
        accessModes?: ("owner_only" | "workspace_all" | "organization_all" | "custom_principals" | "public_link" | "signed_preview")[];
        versionModes?: ("version" | "latest")[];
        maxTtlSeconds?: number;
        allowDownload?: boolean;
        mutableLinks?: boolean;
        descriptor?: boolean;
        shareKey?: string;
    };
}>;
