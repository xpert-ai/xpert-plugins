import { DiscoveryService, Reflector } from '@nestjs/core';
import { type ProjectPipelineContribution, type ProjectPipelineJsonValue } from '@xpert-ai/contracts';
import { BaseStrategyRegistry, type StrategySource } from '../strategy';
import type { ProjectAccessActor } from '../runtime/capabilities/project-access';
import { type PipelineContributionIssue } from './contribution-failure';
export { projectPipelineContributionSchema, type ProjectPipelineContribution } from '@xpert-ai/contracts';
export declare const PROJECT_PIPELINE_CONTRIBUTION = "PROJECT_PIPELINE_CONTRIBUTION";
export declare const ProjectPipelineContributor: (key: string) => ClassDecorator;
export interface ProjectPipelineContributionFailure {
    key: string;
    source: Extract<StrategySource, {
        kind: 'plugin';
    }>;
    code: 'PIPELINE_CONTRIBUTION_INVALID';
    issues: PipelineContributionIssue[];
}
export declare class ProjectPipelineContributionRegistry extends BaseStrategyRegistry<ProjectPipelineContribution> {
    private readonly parsedContributions;
    private readonly failures;
    private readonly failureLogger;
    constructor(discovery: DiscoveryService, reflector: Reflector);
    upsert(instance: unknown): void;
    getRegistrationFailures(): ProjectPipelineContributionFailure[];
    remove(scopeKey: string, pluginName: string): void;
    private failureIdentity;
    private rejectContribution;
    register(key: string, contribution: ProjectPipelineContribution, source: StrategySource): {
        key: string;
        configurations: {
            schemaVersion: 1;
            binding: {
                templateRef: string;
                roleBindings: Record<string, {
                    kind: "assistant" | "runtime_binding" | "human" | "service";
                    selectionKey: string;
                    requiredCapabilities?: string[] | undefined;
                }>;
                parameters: Record<string, import("packages/contracts/dist/src/ai/project-pipeline/primitives.schema").ProjectPipelineJsonValue>;
                executorBindings?: Record<string, {
                    kind: "assistant" | "runtime_binding" | "human" | "service";
                    roleKey: string;
                    selectionKey: string;
                    requiredCapabilities?: string[] | undefined;
                    workspaceId?: string | undefined;
                }> | undefined;
                providerConfiguration?: Record<string, import("packages/contracts/dist/src/ai/project-pipeline/primitives.schema").ProjectPipelineJsonValue> | undefined;
                limits?: {
                    maxConcurrentExecutions: number;
                    maxTechnicalAttemptsPerNode: number;
                    runTimeoutMinutes: number;
                    nativeModelBudget?: {
                        maxCalls: number;
                        maxTokens: number;
                        reservationTokens: number;
                    } | undefined;
                } | undefined;
                triggers?: {
                    adapterRef: string;
                    events: string[];
                }[] | undefined;
            };
            template: {
                key: string;
                title: string;
                version: string;
                lanes: {
                    key: string;
                    label: string;
                    order: number;
                    roleKey: string;
                }[];
                executionAuthority: "provider";
                providerRef: string;
                topology: {
                    source: "provider";
                    presentationAdapterRef: string;
                };
                projectTypes: {
                    applicationKey: string;
                    projectTypeKey: string;
                }[];
                subjectResolverRef: string;
                roles: {
                    key: string;
                    allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
                }[];
                stages: {
                    key: string;
                    label: string;
                    order: number;
                    icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
                }[];
                presentation?: {
                    views: ("tasks" | "pipeline" | "agent_timeline")[];
                    nodeDetailRef?: string | undefined;
                    evidenceTypes?: string[] | undefined;
                } | undefined;
                actionRefs?: string[] | undefined;
                hostRequirements?: {
                    protocol: number;
                    features: Record<string, number>;
                } | undefined;
                metrics?: {
                    dimensionRefs: string[];
                    metricRefs: string[];
                } | undefined;
            } | {
                key: string;
                title: string;
                version: string;
                lanes: {
                    key: string;
                    label: string;
                    order: number;
                    roleKey: string;
                }[];
                executionAuthority: "platform";
                topology: {
                    source: "definition";
                };
                projectTypes: {
                    applicationKey: string;
                    projectTypeKey: string;
                }[];
                subjectResolverRef: string;
                roles: {
                    key: string;
                    allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
                }[];
                stages: {
                    key: string;
                    label: string;
                    order: number;
                    icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
                }[];
                nodes: ({
                    kind: "work";
                    key: string;
                    laneKey: string;
                    operationRef: string;
                    executorSlot: string;
                    completionRef: string;
                    stageKey: string;
                    label?: string | undefined;
                    presentation?: {
                        foldIntoApproval: string;
                    } | undefined;
                    resourceResolverRef?: string | undefined;
                    outputSchemaRef?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                } | {
                    kind: "fork";
                    key: string;
                    stageKey: string;
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                } | {
                    kind: "join";
                    key: string;
                    join: {
                        mode: "all_selected";
                        accept: "completed";
                    };
                    stageKey: string;
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                } | {
                    kind: "router";
                    key: string;
                    stageKey: string;
                    policyRef: string;
                    outcomes: string[];
                    unmatched: "block";
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                } | {
                    kind: "human_gate";
                    key: string;
                    laneKey: string;
                    stageKey: string;
                    policyRef: string;
                    outcomes: string[];
                    candidateRoleKey: string;
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                    outcomeLabels?: Record<string, string> | undefined;
                } | {
                    kind: "external_wait";
                    key: string;
                    laneKey: string;
                    stageKey: string;
                    subscriptionRef: string;
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                } | {
                    kind: "terminal";
                    key: string;
                    outcome: string;
                    stageKey: string;
                    label?: string | undefined;
                    inputBindings?: Record<string, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    } | {
                        from: "subject";
                    } | {
                        key: string;
                        from: "parameter";
                    } | {
                        items: {
                            from: "node_output";
                            nodeKey: string;
                            port: string;
                        }[];
                        from: "collection";
                    }> | undefined;
                    outputPorts?: Record<string, string> | undefined;
                    disposition?: "complete" | "await_new_subject" | undefined;
                })[];
                edges: {
                    from: string;
                    to: string;
                    outcome?: string | undefined;
                }[];
                roundPolicy: {
                    entryNodeKey: string;
                    maxRounds: number;
                    onRework: "await_new_subject_then_next_round";
                    onLimit: "attention";
                    newVersionWhileActive: "supersede_round";
                    terminalOutcomes: string[];
                };
                failurePolicy: {
                    requiredNodeFailure: "block_and_attention";
                    unknownExecution: "inspect_without_replay";
                };
                presentation?: {
                    views: ("tasks" | "pipeline" | "agent_timeline")[];
                    nodeDetailRef?: string | undefined;
                    evidenceTypes?: string[] | undefined;
                } | undefined;
                hostRequirements?: {
                    protocol: number;
                    features: Record<string, number>;
                } | undefined;
                metrics?: {
                    dimensionRefs: string[];
                    metricRefs: string[];
                } | undefined;
            };
        }[];
        descriptors: ({
            kind: "schema";
            ref: string;
        } | {
            kind: "resource";
            ref: string;
        } | {
            kind: "subject";
            outputSchemaRef: string;
            ref: string;
        } | {
            kind: "operation";
            requiredCapabilities: string[];
            ref: string;
            effects: "read_only" | "isolated_write" | "external_write";
            idempotency: "read_only" | "keyed_receipt";
            inputs: Record<string, {
                schemaRef: string;
                cardinality: "collection" | "one";
            }>;
            outputs: Record<string, string>;
            retry?: "never" | "after_confirmed_failure" | undefined;
        } | {
            kind: "completion";
            ref: string;
        } | {
            kind: "policy";
            outcomes: string[];
            ref: string;
        } | {
            kind: "projection";
            ref: string;
        } | {
            kind: "presentation";
            ref: string;
        } | {
            kind: "action";
            ref: string;
        } | {
            kind: "metric";
            ref: string;
        } | {
            kind: "dimension";
            ref: string;
        } | {
            kind: "trigger";
            ref: string;
        } | {
            kind: "subscription";
            ref: string;
            outputs: Record<string, string>;
        })[];
        forms?: {
            templateRef: string;
            parameters: ({
                key: string;
                type: "boolean";
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            } | {
                key: string;
                type: "text";
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                minLength: number;
                maxLength: number;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            } | {
                key: string;
                type: "number";
                integer: boolean;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                min: number;
                max: number;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            } | {
                key: string;
                options: {
                    value: string;
                    label: {
                        en_US: string;
                        zh_Hans?: string | undefined;
                    };
                }[];
                type: "choice";
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            } | {
                key: string;
                options: {
                    value: string;
                    label: {
                        en_US: string;
                        zh_Hans?: string | undefined;
                    };
                }[];
                type: "multi_choice";
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                minItems: number;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            } | {
                key: string;
                type: "string_list";
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                maxItems: number;
                itemMaxLength: number;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            })[];
            description: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            assistantSlots: {
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                slot: string;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            }[];
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
            runtimeSlots?: {
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
                slot: string;
                description?: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                } | undefined;
            }[] | undefined;
        }[] | undefined;
    };
    private registerParsed;
    assertCanRegister(key: string, contribution: ProjectPipelineContribution, source: StrategySource): void;
    /** Explicit actor scope prevents a delegated call from inheriting an unrelated ambient tenant. */
    listForActor(actor: ProjectAccessActor): ProjectPipelineContribution[];
}
