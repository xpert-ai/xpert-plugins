'use strict';

const CONNECTOR_SCOPE_TYPES = [
    'workspace',
    'project'
];
const CONNECTOR_AUTHORIZATION_MODES = [
    'personal',
    'shared'
];
function getConnectorAuthMethods(definition) {
    var _definition_legacyAuthMethodId;
    if ('authMethods' in definition) {
        return definition.authMethods;
    }
    return [
        {
            id: ((_definition_legacyAuthMethodId = definition.legacyAuthMethodId) == null ? void 0 : _definition_legacyAuthMethodId.trim()) || 'oauth2',
            type: 'oauth2',
            label: {
                en_US: 'OAuth 2.0',
                zh_Hans: 'OAuth 2.0'
            },
            appCredentials: definition.appCredentials
        }
    ];
}
function getConnectorAuthorizationModes(definition) {
    var _definition_authorizationModes;
    return ((_definition_authorizationModes = definition.authorizationModes) == null ? void 0 : _definition_authorizationModes.length) ? [
        ...definition.authorizationModes
    ] : [
        'shared'
    ];
}
function assertConnectorDefinition(definition) {
    if (!isObjectValue(definition)) {
        throw new Error('Connector strategy must expose a valid connector definition');
    }
    const providerValue = Reflect.get(definition, 'provider');
    const provider = typeof providerValue === 'string' ? providerValue.trim() : '';
    if (!provider) {
        throw new Error('Connector definition must declare a provider');
    }
    const label = Reflect.get(definition, 'label');
    if (!isRuntimeI18nText(label)) {
        throw new Error(`Connector '${provider}' must declare a label`);
    }
    const auth = Reflect.get(definition, 'auth');
    const authMethods = Reflect.get(definition, 'authMethods');
    const authorizationModes = Reflect.get(definition, 'authorizationModes');
    const resolvedMethods = [];
    const ids = new Set();
    if (authorizationModes !== undefined) {
        if (!Array.isArray(authorizationModes) || !authorizationModes.length) {
            throw new Error(`Connector '${provider}' must declare at least one authorization mode`);
        }
        const seenModes = new Set();
        for (const mode of authorizationModes){
            if (mode !== 'personal' && mode !== 'shared') {
                throw new Error(`Connector '${provider}' has unsupported authorization mode '${String(mode)}'`);
            }
            if (seenModes.has(mode)) {
                throw new Error(`Connector '${provider}' has duplicate authorization mode '${mode}'`);
            }
            seenModes.add(mode);
        }
    }
    if (authMethods !== undefined) {
        if (!Array.isArray(authMethods) || !authMethods.length) {
            throw new Error(`Connector '${provider}' must declare at least one authentication method`);
        }
        for (const method of authMethods){
            assertConnectorAuthMethod(method, provider);
            const id = method.id.trim();
            if (ids.has(id)) {
                throw new Error(`Connector '${provider}' has duplicate authentication method id '${id}'`);
            }
            ids.add(id);
            resolvedMethods.push({
                id,
                type: method.type
            });
        }
        if (auth !== undefined && !isConnectorOAuthConfig(auth)) {
            throw new Error(`Connector '${provider}' has invalid legacy OAuth metadata`);
        }
    } else {
        if (!isConnectorOAuthConfig(auth)) {
            throw new Error(`Connector '${provider}' must declare legacy OAuth configuration or authentication methods`);
        }
        const legacyMethodValue = Reflect.get(definition, 'legacyAuthMethodId');
        const legacyMethodId = typeof legacyMethodValue === 'string' && legacyMethodValue.trim() ? legacyMethodValue.trim() : 'oauth2';
        resolvedMethods.push({
            id: legacyMethodId,
            type: 'oauth2'
        });
    }
    const legacyAuthMethodValue = Reflect.get(definition, 'legacyAuthMethodId');
    if (legacyAuthMethodValue !== undefined && (typeof legacyAuthMethodValue !== 'string' || !legacyAuthMethodValue.trim())) {
        throw new Error(`Connector '${provider}' has an invalid legacy authentication method id`);
    }
    if (typeof legacyAuthMethodValue === 'string') {
        const legacyAuthMethodId = legacyAuthMethodValue.trim();
        const legacyMethod = resolvedMethods.find((method)=>method.id === legacyAuthMethodId);
        if (!legacyMethod) {
            throw new Error(`Connector '${provider}' maps legacy credentials to unknown authentication method '${legacyAuthMethodId}'`);
        }
        if (legacyMethod.type !== 'oauth2') {
            throw new Error(`Connector '${provider}' must map legacy credentials to an OAuth authentication method`);
        }
    }
}
function assertConnectorAuthMethod(method, provider) {
    if (!isObjectValue(method)) {
        throw new Error(`Connector '${provider}' has an invalid authentication method`);
    }
    const idValue = Reflect.get(method, 'id');
    if (typeof idValue !== 'string' || !idValue.trim()) {
        throw new Error(`Connector '${provider}' has an authentication method without an id`);
    }
    const label = Reflect.get(method, 'label');
    if (!isRuntimeI18nText(label)) {
        throw new Error(`Connector '${provider}' authentication method '${idValue.trim()}' must declare a label`);
    }
    const type = Reflect.get(method, 'type');
    if (type !== 'oauth2' && type !== 'api_key') {
        throw new Error(`Connector '${provider}' has unsupported authentication method type '${String(type)}'`);
    }
    if (type === 'api_key' && !isObjectValue(Reflect.get(method, 'credentials'))) {
        throw new Error(`Connector '${provider}' API key method '${idValue.trim()}' must declare credentials`);
    }
    const authorizationPresentation = Reflect.get(method, 'authorizationPresentation');
    if (authorizationPresentation !== undefined) {
        assertConnectorAuthorizationPresentation(authorizationPresentation, provider, idValue.trim(), type);
    }
}
function assertConnectorAuthorizationPresentation(value, provider, authMethodId, authMethodType) {
    if (!isObjectValue(value) || Reflect.get(value, 'mode') !== 'embedded_qr') {
        throw new Error(`Connector '${provider}' authentication method '${authMethodId}' has an invalid authorization presentation`);
    }
    if (authMethodType !== 'oauth2') {
        throw new Error(`Connector '${provider}' authentication method '${authMethodId}' can declare authorization presentation only for OAuth`);
    }
    for (const field of [
        'title',
        'description',
        'ariaLabel',
        'completionHint',
        'cancelLabel',
        'copyLinkLabel',
        'copyLinkError'
    ]){
        if (!isRuntimeI18nText(Reflect.get(value, field))) {
            throw new Error(`Connector '${provider}' authentication method '${authMethodId}' authorization presentation must declare '${field}'`);
        }
    }
}
function isConnectorOAuthConfig(value) {
    return isObjectValue(value) && Reflect.get(value, 'type') === 'oauth2';
}
function isRuntimeI18nText(value) {
    if (typeof value === 'string') {
        return !!value.trim();
    }
    return isObjectValue(value) && typeof Reflect.get(value, 'en_US') === 'string';
}
function isObjectValue(value) {
    return typeof value === 'object' && value !== null;
}

exports.CONNECTOR_AUTHORIZATION_MODES = CONNECTOR_AUTHORIZATION_MODES;
exports.CONNECTOR_SCOPE_TYPES = CONNECTOR_SCOPE_TYPES;
exports.assertConnectorDefinition = assertConnectorDefinition;
exports.getConnectorAuthMethods = getConnectorAuthMethods;
exports.getConnectorAuthorizationModes = getConnectorAuthorizationModes;
