'use strict';

var results = require('./results.cjs.js');
var contracts = require('@xpert-ai/contracts');
require('./_extends.cjs.js');
require('zod/v3');



exports.AGENT_TASK_REPORT_MAX_BYTES = results.AGENT_TASK_REPORT_MAX_BYTES;
exports.AGENT_TASK_RESULTS_FEATURE = results.AGENT_TASK_RESULTS_FEATURE;
exports.agentResultItemSchema = results.agentResultItemSchema;
Object.defineProperty(exports, "agentDeliveryRecoverySchema", {
	enumerable: true,
	get: function () { return contracts.agentDeliveryRecoverySchema; }
});
Object.defineProperty(exports, "agentOutputDeliverySchema", {
	enumerable: true,
	get: function () { return contracts.agentOutputDeliverySchema; }
});
Object.defineProperty(exports, "agentResultPathSchema", {
	enumerable: true,
	get: function () { return contracts.agentResultPathSchema; }
});
