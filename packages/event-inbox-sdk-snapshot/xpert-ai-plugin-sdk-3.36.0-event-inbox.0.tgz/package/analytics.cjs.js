'use strict';

var analyticsResult = require('./analytics-result.cjs.js');
var v3 = require('zod/v3');
var _object_without_properties_loose = require('./_object_without_properties_loose.cjs.js');
require('./_extends.cjs.js');

const key$1 = v3.z.string().trim().min(1).max(128).refine((value)=>![
        '__proto__',
        'constructor',
        'prototype'
    ].includes(value));
const scalar$1 = v3.z.union([
    v3.z.string().max(512),
    v3.z.number().finite(),
    v3.z.boolean(),
    v3.z.null()
]);
/** Validate one predicate's shape/cardinality; field existence, logical types and allowed scope require live dataset metadata. */ const resourceAnalysisFilterSchema = v3.z.object({
    field: key$1,
    operator: v3.z.enum([
        'eq',
        'ne',
        'in',
        'gt',
        'gte',
        'lt',
        'lte'
    ]),
    values: v3.z.array(scalar$1).min(1).max(50)
}).strict().refine((value)=>value.operator === 'in' || value.values.length === 1);
/**
 * Shared authoring/server policy boundary: bounded nonempty allowlists, fixed-filter fields and supported mode combinations.
 * Parsing does not establish source sharing authority or receiving-group consent; those remain runtime checks.
 */ const resourceAnalysisPolicySchema = v3.z.object({
    execution: v3.z.enum([
        'viewer_permissions',
        'delegated_results'
    ]).optional(),
    mode: v3.z.enum([
        'bindings',
        'explore'
    ]),
    datasets: v3.z.array(v3.z.object({
        key: key$1,
        fields: v3.z.array(key$1).min(1).max(64),
        filters: v3.z.array(resourceAnalysisFilterSchema).max(20),
        controlValues: v3.z.record(key$1, v3.z.array(scalar$1).min(1).max(50)).refine((value)=>Object.keys(value).length <= 32).optional()
    }).strict()).min(1).max(20),
    allowDetails: v3.z.boolean(),
    maxRows: v3.z.number().int().min(1).max(100)
}).strict().refine((value)=>value.execution === 'delegated_results' || value.datasets.every((item)=>!item.controlValues)).refine((value)=>new Set(value.datasets.map((item)=>item.key)).size === value.datasets.length).refine((value)=>value.datasets.every((item)=>new Set(item.fields).size === item.fields.length && item.filters.every((filter)=>item.fields.includes(filter.field)))).refine((value)=>value.mode !== 'bindings' || value.allowDetails);
/**
 * Normalize public query input to ResourceAnalysisQuery, defaulting optional wire collections to empty values.
 * Keep limit absent so the executor uses the live policy's maxRows; validate field/mode/budget permissions before querying.
 */ const resourceAnalysisQuerySchema = v3.z.object({
    datasetKey: key$1,
    controls: v3.z.record(key$1, scalar$1).refine((value)=>Object.keys(value).length <= 32).default({}),
    select: v3.z.array(key$1).max(64).default([]),
    filters: v3.z.array(resourceAnalysisFilterSchema).max(20).default([]),
    groupBy: v3.z.array(key$1).max(8).default([]),
    aggregates: v3.z.array(v3.z.object({
        field: key$1.optional(),
        key: key$1,
        operation: v3.z.enum([
            'count',
            'sum',
            'min',
            'max'
        ])
    }).strict()).max(16).default([]),
    orderBy: v3.z.array(v3.z.object({
        field: key$1,
        direction: v3.z.enum([
            'asc',
            'desc'
        ])
    }).strict()).max(8).default([]),
    limit: v3.z.number().int().min(1).max(100).optional()
}).strict();
/**
 * Check a predicate scalar against the declared logical type, including exact-string int64/decimal wire values.
 * Shared by authoring and execution; this does not validate the operator, field allowlist or grant authority.
 */ function isResourceAnalysisFilterValue(type, value) {
    if (value === null) return true;
    if (type === 'boolean') return typeof value === 'boolean';
    if (type === 'float64') return typeof value === 'number' && Number.isFinite(value);
    if (typeof value !== 'string') return false;
    if (type === 'int64') return value.length <= 128 && /^-?\d+$/.test(value);
    if (type === 'decimal') return value.length <= 128 && /^-?\d+(\.\d+)?$/.test(value);
    if (type === 'date') return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value));
    if (type === 'timestamp') return /^\d{4}-\d{2}-\d{2}T/.test(value) && Number.isFinite(Date.parse(value));
    return true;
}

// Evidence is a bounded copy of a past result. Parsing establishes neither current source access
// nor certification authority; producers and readers enforce those checks in their own runtime.
const key = v3.z.string().min(1).max(160).refine((value)=>![
        '__proto__',
        'constructor',
        'prototype'
    ].includes(value));
const scalar = v3.z.union([
    v3.z.string().max(4000),
    v3.z.number().finite(),
    v3.z.boolean(),
    v3.z.null()
]);
const dataset = v3.z.object({
    schema: v3.z.literal('xpert.analytics.dataset'),
    datasetId: key,
    fields: v3.z.array(analyticsResult.analyticsFieldSchema).min(1).max(64),
    rows: v3.z.array(v3.z.record(key, scalar)).max(1000),
    grain: v3.z.array(key).max(64),
    completeness: v3.z.object({
        returnedRows: v3.z.number().int().nonnegative(),
        totalRows: v3.z.number().int().nonnegative().optional(),
        totalAccuracy: v3.z.enum([
            'exact',
            'estimated',
            'unknown'
        ]),
        scope: v3.z.enum([
            'full_query_result',
            'page',
            'sample',
            'top_n'
        ]),
        truncated: v3.z.boolean()
    }).strict(),
    freshness: v3.z.object({
        executedAt: v3.z.string().datetime(),
        sourceFetchedAt: v3.z.string().datetime(),
        dataAsOf: v3.z.string().max(160).optional()
    }).strict(),
    provenance: v3.z.object({
        executionId: key,
        bindingId: key,
        providerId: key,
        sourceVersion: v3.z.string().max(512).optional(),
        upstreamExecutionId: key.optional(),
        auditRef: v3.z.string().max(512).optional(),
        certification: analyticsResult.analyticsCertificationSchema.optional()
    }).strict()
}).strict().superRefine((value, ctx)=>{
    const ids = new Set(value.fields.map((field)=>field.id));
    if (ids.size !== value.fields.length || new Set(value.grain).size !== value.grain.length || value.grain.some((id)=>!ids.has(id)) || value.completeness.returnedRows !== value.rows.length || value.completeness.totalRows !== undefined && value.completeness.totalRows < value.rows.length || value.completeness.truncated && value.completeness.scope === 'full_query_result') ctx.addIssue({
        code: 'custom',
        message: 'Inconsistent evidence result'
    });
    for (const row of value.rows){
        // Reuse result validation so transport never coerces values or relaxes their logical types.
        if (Object.keys(row).length !== ids.size || Object.keys(row).some((id)=>!ids.has(id)) || value.fields.some((field)=>!Object.prototype.hasOwnProperty.call(row, field.id) || !analyticsResult.isAnalyticsCell(field.logicalType, row[field.id], field.nullable))) ctx.addIssue({
            code: 'custom',
            message: 'Invalid evidence cells'
        });
    }
});
const analysisEvidenceSchema = v3.z.object({
    schema: v3.z.literal('xpert.analysis-evidence@1'),
    id: v3.z.string().uuid(),
    title: v3.z.string().min(1).max(200),
    capturedAt: v3.z.string().datetime(),
    source: v3.z.object({
        artifactId: v3.z.string().uuid(),
        versionId: v3.z.string().uuid(),
        projectId: v3.z.string().uuid()
    }).strict(),
    controls: v3.z.record(key, scalar).refine((value)=>Object.keys(value).length <= 32),
    datasets: v3.z.array(dataset).min(1).max(20),
    statements: v3.z.array(v3.z.object({
        kind: v3.z.enum([
            'fact',
            'inference',
            'unverified'
        ]),
        text: v3.z.string().min(1).max(2000),
        citations: v3.z.array(v3.z.object({
            datasetId: key,
            row: v3.z.number().int().nonnegative(),
            field: key
        }).strict()).max(64)
    }).strict()).max(1000),
    sha256: v3.z.string().regex(/^[a-f0-9]{64}$/)
}).strict().superRefine((value, ctx)=>{
    if (new Set(value.datasets.map((item)=>item.datasetId)).size !== value.datasets.length) ctx.addIssue({
        code: 'custom',
        message: 'Duplicate evidence dataset'
    });
    for (const statement of value.statements){
        // A citation identifies an existing cell; it does not prove the statement's interpretation.
        if (statement.kind === 'fact' && !statement.citations.length) ctx.addIssue({
            code: 'custom',
            message: 'Facts need cell citations'
        });
        for (const citation of statement.citations){
            const data = value.datasets.find((item)=>item.datasetId === citation.datasetId);
            if (!data || citation.row >= data.rows.length || !data.fields.some((field)=>field.id === citation.field)) ctx.addIssue({
                code: 'custom',
                message: 'Unknown evidence cell'
            });
        }
    }
    if (new TextEncoder().encode(JSON.stringify(value)).length > 2000000) ctx.addIssue({
        code: 'custom',
        message: 'Evidence exceeds limit'
    });
});
/** Canonicalize validated JSON: sort object keys, but preserve array order and exact scalar values.
 * Omitted optional properties do not affect the digest. Hashing stays in the consumer's runtime. */ function canonicalEvidenceJson(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(canonicalEvidenceJson).join(',') + ']';
    return '{' + Object.entries(value).filter(([, entry])=>entry !== undefined).sort(([a], [b])=>a < b ? -1 : a > b ? 1 : 0).map(([name, entry])=>JSON.stringify(name) + ':' + canonicalEvidenceJson(entry)).join(',') + '}';
}
/** Validate shape and cell references; callers must verify the digest and current source access separately. */ function parseAnalysisEvidence(value) {
    return analysisEvidenceSchema.parse(value);
}
/** Exclude only the digest itself; source, capture time, cells and statement classifications stay covered. */ function analysisEvidenceDigestInput(value) {
    const { sha256: _digest } = value, body = _object_without_properties_loose._object_without_properties_loose(value, [
        "sha256"
    ]);
    return canonicalEvidenceJson(body);
}

exports.analyticsBindingObjectSchema = analyticsResult.analyticsBindingObjectSchema;
exports.analyticsBindingSchema = analyticsResult.analyticsBindingSchema;
exports.analyticsCertificationSchema = analyticsResult.analyticsCertificationSchema;
exports.analyticsControlsSchema = analyticsResult.analyticsControlsSchema;
exports.analyticsDiscoveryRequestObjectSchema = analyticsResult.analyticsDiscoveryRequestObjectSchema;
exports.analyticsDiscoveryRequestSchema = analyticsResult.analyticsDiscoveryRequestSchema;
exports.analyticsDiscoveryResultSchema = analyticsResult.analyticsDiscoveryResultSchema;
exports.analyticsFieldSchema = analyticsResult.analyticsFieldSchema;
exports.analyticsOptionsSchema = analyticsResult.analyticsOptionsSchema;
exports.analyticsParameterSchema = analyticsResult.analyticsParameterSchema;
exports.analyticsQueryRequestSchema = analyticsResult.analyticsQueryRequestSchema;
exports.analyticsSourceKey = analyticsResult.analyticsSourceKey;
exports.analyticsSourceRefSchema = analyticsResult.analyticsSourceRefSchema;
exports.normalizeAnalyticsResult = analyticsResult.normalizeAnalyticsResult;
exports.parseAnalyticsCertification = analyticsResult.parseAnalyticsCertification;
exports.resolveAnalyticsParameters = analyticsResult.resolveAnalyticsParameters;
exports.validateAnalyticsBinding = analyticsResult.validateAnalyticsBinding;
exports.analysisEvidenceDigestInput = analysisEvidenceDigestInput;
exports.analysisEvidenceSchema = analysisEvidenceSchema;
exports.canonicalEvidenceJson = canonicalEvidenceJson;
exports.isResourceAnalysisFilterValue = isResourceAnalysisFilterValue;
exports.parseAnalysisEvidence = parseAnalysisEvidence;
exports.resourceAnalysisFilterSchema = resourceAnalysisFilterSchema;
exports.resourceAnalysisPolicySchema = resourceAnalysisPolicySchema;
exports.resourceAnalysisQuerySchema = resourceAnalysisQuerySchema;
