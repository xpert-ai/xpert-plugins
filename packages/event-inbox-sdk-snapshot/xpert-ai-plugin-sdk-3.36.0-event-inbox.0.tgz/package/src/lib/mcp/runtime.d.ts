import type { McpAppDefinition } from './app';
import type { McpPromptDefinition } from './prompt';
import type { McpResourceDefinition } from './resource';
import type { McpResourceTemplateDefinition } from './resource-template';
import type { AnyXpertToolDefinition } from '../toolset/define-tool';
export interface McpCapabilityDefinitions {
    /** Lower-priority server guidance merged after platform and Publication instructions. */
    instructions?: string;
    tools?: readonly AnyXpertToolDefinition[];
    resources?: readonly McpResourceDefinition[];
    resourceTemplates?: readonly McpResourceTemplateDefinition[];
    prompts?: readonly McpPromptDefinition[];
    apps?: readonly McpAppDefinition[];
}
/** Implemented by toolsets that provide host-executed MCP capabilities in addition to tools. */
export interface McpCapabilityRuntimeProvider {
    getMcpCapabilityDefinitions(): Readonly<McpCapabilityDefinitions>;
    getMcpCapabilitySource?(): {
        pluginName?: string;
        pluginVersion?: string;
    };
}
export declare function defineMcpCapabilities(definitions: McpCapabilityDefinitions): Readonly<McpCapabilityDefinitions>;
