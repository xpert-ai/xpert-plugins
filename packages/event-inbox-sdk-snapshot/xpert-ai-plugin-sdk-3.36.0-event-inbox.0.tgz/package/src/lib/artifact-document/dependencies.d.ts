import { z } from 'zod/v3';
export interface ArtifactDocumentDependencyLock {
    id: string;
    version: string;
    format: 'classic-script';
    global: string;
    sha256: string;
}
export interface ArtifactDocumentDependencyAsset extends ArtifactDocumentDependencyLock {
    source: string;
}
export declare const artifactDocumentDependencyLock: z.ZodEffects<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    format: z.ZodLiteral<"classic-script">;
    global: z.ZodEffects<z.ZodString, string, string>;
    sha256: z.ZodString;
}, "strict", z.ZodTypeAny, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>, ArtifactDocumentDependencyLock, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>;
export declare const artifactDocumentDependencyLocks: z.ZodEffects<z.ZodArray<z.ZodEffects<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    format: z.ZodLiteral<"classic-script">;
    global: z.ZodEffects<z.ZodString, string, string>;
    sha256: z.ZodString;
}, "strict", z.ZodTypeAny, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>, ArtifactDocumentDependencyLock, {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>, "many">, ArtifactDocumentDependencyLock[], {
    id?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}[]>;
export declare const artifactDocumentDependencyAssets: z.ZodArray<z.ZodEffects<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    format: z.ZodLiteral<"classic-script">;
    global: z.ZodEffects<z.ZodString, string, string>;
    sha256: z.ZodString;
} & {
    source: z.ZodString;
}, "strict", z.ZodTypeAny, {
    id?: string;
    source?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}, {
    id?: string;
    source?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>, ArtifactDocumentDependencyAsset, {
    id?: string;
    source?: string;
    version?: string;
    sha256?: string;
    format?: "classic-script";
    global?: string;
}>, "many">;
/** Browser/server identical verification. Integrity is not authorization: the caller owns library admission. */
export declare function verifyArtifactDocumentDependencies(input: unknown, expected?: ArtifactDocumentDependencyLock[]): ArtifactDocumentDependencyAsset[];
/** Assign script.textContent to preserve exact bytes without eval or HTML parser termination hazards. */
export declare function renderArtifactDocumentDependencies(assets: ArtifactDocumentDependencyAsset[]): string;
