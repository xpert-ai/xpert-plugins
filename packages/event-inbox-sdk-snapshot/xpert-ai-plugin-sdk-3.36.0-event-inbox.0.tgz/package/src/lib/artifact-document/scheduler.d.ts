import type { ArtifactDocumentControls } from './protocol';
import type { AnalyticsQueryRequest } from '@xpert-ai/contracts';
export type ArtifactQueryPriority = 'interactive' | 'initial' | 'refresh';
export interface ArtifactQueryInput {
    bindingId: string;
    controls: ArtifactDocumentControls;
    /** Forward to the runtime; a refresh must not coalesce with an earlier reuse request. */
    cache?: AnalyticsQueryRequest['cache'];
}
export interface ArtifactQueryState {
    bindingId: string;
    controls: ArtifactDocumentControls;
    state: 'queued' | 'running' | 'succeeded' | 'failed' | 'superseded';
    queuedAt: number;
    startedAt?: number;
    finishedAt?: number;
    code?: string;
}
export interface ArtifactQuerySchedulerOptions<T> {
    execute(input: ArtifactQueryInput, signal: AbortSignal): Promise<T>;
    concurrency?: number;
    /** Trusted executor budget. Live integrations should retain 60; bounded snapshot replay may use up to 1024. */
    dispatchesPerMinute?: number;
    onState?(state: ArtifactQueryState): void;
    onBusy?(busy: boolean): void;
}
/** One trusted Artifact/version/actor generation. Queue time never consumes execution time.
 * Slots remain occupied until the underlying execution settles, even after timeout/abort.
 * Callers must propagate the signal when supported; disposal alone cannot cancel database work. */
export declare function createArtifactQueryScheduler<T>(options: ArtifactQuerySchedulerOptions<T>): {
    query(input: ArtifactQueryInput, priority?: ArtifactQueryPriority): Promise<T>;
    readonly busy: boolean;
    dispose(): void;
};
