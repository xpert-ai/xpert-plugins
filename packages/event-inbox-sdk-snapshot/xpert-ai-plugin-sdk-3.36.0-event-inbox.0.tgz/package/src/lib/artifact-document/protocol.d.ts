import { z } from 'zod/v3';
/** Wire namespace/version shared by the trusted host and its isolated document bootstrap. */
export declare const ARTIFACT_DOCUMENT_CHANNEL = "xpert.artifact-document";
export declare const ARTIFACT_DOCUMENT_VERSION = 1;
/** Portable binding/control identifier; shape validation never grants resource access. */
export declare const artifactDocumentId: z.ZodString;
export declare const artifactDocumentValue: z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
export declare const artifactDocumentControls: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>, Record<string, string | number | boolean>, Record<string, string | number | boolean>>;
/** The entire untrusted query envelope. Provider definitions, SQL and identity fields are forbidden. */
export declare const artifactDocumentQuery: z.ZodObject<{
    type: z.ZodLiteral<"query">;
    requestId: z.ZodString;
    bindingId: z.ZodString;
    controls: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>, Record<string, string | number | boolean>, Record<string, string | number | boolean>>;
    priority: z.ZodOptional<z.ZodEnum<["interactive", "initial", "refresh"]>>;
}, "strict", z.ZodTypeAny, {
    type?: "query";
    controls?: Record<string, string | number | boolean>;
    bindingId?: string;
    requestId?: string;
    priority?: "interactive" | "initial" | "refresh";
}, {
    type?: "query";
    controls?: Record<string, string | number | boolean>;
    bindingId?: string;
    requestId?: string;
    priority?: "interactive" | "initial" | "refresh";
}>;
/** Flat UI filter values keyed by declared control IDs; validated again by the backend Binding. */
export type ArtifactDocumentControls = Record<string, string | number | boolean | null>;
/** Correlates a document request with one host result; the host owns binding resolution and authorization. */
export interface ArtifactDocumentQuery {
    type: 'query';
    requestId: string;
    bindingId: string;
    controls: ArtifactDocumentControls;
    priority?: 'interactive' | 'initial' | 'refresh';
}
/** Only public presentation context may cross into the untrusted frame. Never include credentials here. */
export declare const artifactDocumentContext: z.ZodObject<{
    bindingIds: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
    defaults: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>, Record<string, string | number | boolean>, Record<string, string | number | boolean>>;
    theme: z.ZodEnum<["light", "dark"]>;
    locale: z.ZodString;
}, "strict", z.ZodTypeAny, {
    bindingIds?: string[];
    defaults?: Record<string, string | number | boolean>;
    theme?: "light" | "dark";
    locale?: string;
}, {
    bindingIds?: string[];
    defaults?: Record<string, string | number | boolean>;
    theme?: "light" | "dark";
    locale?: string;
}>;
/** A snapshot for one mount. Artifact/version/actor identity belongs in the trusted query callback closure. */
export interface ArtifactDocumentContext {
    bindingIds: string[];
    defaults: ArtifactDocumentControls;
    theme: 'light' | 'dark';
    locale: string;
}
/** Format/UTF-8 size gate, not a sanitizer. Isolation and server authorization enforce security. */
export declare const artifactDocumentHtml: z.ZodEffects<z.ZodString, string, string>;
