import { z } from 'zod/v3';
export declare const artifactDocumentNetworkPolicy: z.ZodObject<{
    mode: z.ZodOptional<z.ZodEnum<["restricted", "unrestricted"]>>;
    scripts: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
    styles: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
    fonts: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
    images: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
}, "strict", z.ZodTypeAny, {
    mode?: "restricted" | "unrestricted";
    scripts?: string[];
    styles?: string[];
    fonts?: string[];
    images?: string[];
}, {
    mode?: "restricted" | "unrestricted";
    scripts?: string[];
    styles?: string[];
    fonts?: string[];
    images?: string[];
}>;
export type ArtifactDocumentNetworkPolicy = z.output<typeof artifactDocumentNetworkPolicy>;
export declare function artifactDocumentCsp(input?: ArtifactDocumentNetworkPolicy): string;
/** For preview browser routing; CSP remains the enforcement in the displayed frame. */
export declare function isArtifactDocumentResourceAllowed(policy: ArtifactDocumentNetworkPolicy, resourceType: string, value: string): boolean;
