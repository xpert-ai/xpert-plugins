import { type ArtifactDocumentDependencyAsset } from './dependencies';
import { type ArtifactDocumentNetworkPolicy } from './network';
export declare const ARTIFACT_DOCUMENT_CSP: string;
/** Host-owned prefix precedes all authored markup, including malformed/duplicate heads. */
export declare function renderArtifactDocument(html: string, sessionId: string, dependencies?: ArtifactDocumentDependencyAsset[], networkPolicy?: ArtifactDocumentNetworkPolicy): string;
