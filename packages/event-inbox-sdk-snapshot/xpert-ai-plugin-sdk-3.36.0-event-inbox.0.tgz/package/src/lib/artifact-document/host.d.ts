import { type ArtifactQueryState } from './scheduler';
import { type ArtifactDocumentContext, type ArtifactDocumentQuery } from './protocol';
import type { ArtifactDocumentDependencyAsset } from './dependencies';
import type { ArtifactDocumentNetworkPolicy } from './network';
/** Trusted integration callbacks. T is the plugin's cloneable result shape, independent of any chart library. */
export interface ArtifactDocumentHostOptions<T> {
    /** Complete untrusted HTML; scripts run only inside the isolated frame. */
    html: string;
    /** Exact packaged bytes pinned to this Artifact version, never URLs or library names from the document. */
    dependencies?: ArtifactDocumentDependencyAsset[];
    /** Trusted resource policy; unrestricted mode permits networking. Omit to block external resources. */
    networkPolicy?: ArtifactDocumentNetworkPolicy;
    /** Public binding IDs and presentation defaults for this document generation. */
    context: ArtifactDocumentContext;
    /** Resolve against saved Bindings on the server with the current user's access; never execute a query definition from HTML. */
    query(input: ArtifactDocumentQuery, signal?: AbortSignal): Promise<T>;
    concurrency?: number;
    /** Trusted host policy, never supplied by authored HTML. Defaults to 60 live executions/minute. */
    dispatchesPerMinute?: number;
    onQueryState?(state: ArtifactQueryState): void;
    /** Latest result for a Binding, suitable for host-owned freshness/partial-result indicators. */
    onResult?(result: T): void;
    /** Stable protocol/query error code; private backend error details are never sent into the document. */
    onError?(code: string): void;
    /** Tracks all pending host queries, including those superseded by newer filter values. */
    onBusy?(busy: boolean): void;
}
/** Lifecycle handle for one mount; dispose before replacing the document or its trusted query scope. */
export interface ArtifactDocumentHost {
    /** Requeries subscribed/previously queried bindings using their last controls. */
    refresh(bindingId?: string): void;
    /** Closes the query channel and discards late results; backend cancellation remains the caller's responsibility. */
    dispose(): void;
}
/** Dedicated query bridge. Requires a dedicated host document with installArtifactDocumentFramePolicy installed. */
export declare function mountArtifactDocument<T>(frame: HTMLIFrameElement, options: ArtifactDocumentHostOptions<T>): ArtifactDocumentHost;
/** Installs a document-wide policy once. Use a dedicated host: all URL-based child frames are denied; srcdoc works. */
export declare function installArtifactDocumentFramePolicy(hostDocument: Document): void;
