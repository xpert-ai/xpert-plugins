/** Internal one-shot digest. Callers bound asset sizes before allocating hashing buffers. */
export declare function sha256Hex(bytes: Uint8Array): string;
