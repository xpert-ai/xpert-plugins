import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { IVectorStoreStrategy } from './strategy.interface';
export declare class VectorStoreRegistry<TConfig = any> extends BaseStrategyRegistry<IVectorStoreStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
