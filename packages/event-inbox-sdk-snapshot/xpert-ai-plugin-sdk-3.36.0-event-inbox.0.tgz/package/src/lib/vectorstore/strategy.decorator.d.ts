export declare const VECTOR_STORE_STRATEGY = "VECTOR_STORE_STRATEGY";
export declare const VectorStoreStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
