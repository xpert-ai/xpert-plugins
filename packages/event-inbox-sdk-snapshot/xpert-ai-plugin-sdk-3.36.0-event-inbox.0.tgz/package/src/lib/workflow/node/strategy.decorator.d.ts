export declare const WORKFLOW_NODE_STRATEGY = "WORKFLOW_NODE_STRATEGY";
/**
 * Decorator to mark a provider as a Workflow Node Strategy
 */
export declare const WorkflowNodeStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
