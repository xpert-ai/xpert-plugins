import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IWorkflowNodeStrategy } from './strategy.interface';
/**
 * Registry for Workflow Node Strategies
 */
export declare class WorkflowNodeRegistry<TConfig = any, TResult = any> extends BaseStrategyRegistry<IWorkflowNodeStrategy<TConfig, TResult>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
