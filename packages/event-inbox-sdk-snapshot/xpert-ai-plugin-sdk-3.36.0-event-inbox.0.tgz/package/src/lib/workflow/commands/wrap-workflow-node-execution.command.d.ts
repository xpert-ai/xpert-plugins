import { IXpertAgentExecution } from '@xpert-ai/contracts';
import { Command } from '@nestjs/cqrs';
import { AgentMiddlewareWrapWorkflowNodeExecutionParams, AgentMiddlewareWrapWorkflowNodeExecutionResult } from '../../agent/middleware/runtime';
/**
 * Wrap Workflow Node Execution Command
 *
 * @deprecated Prefer `IAgentMiddlewareContext.runtime.wrapWorkflowNodeExecution(...)` in middleware and plugin code.
 */
export declare class WrapWorkflowNodeExecutionCommand<T = any> extends Command<T> {
    readonly fuc: (execution: Partial<IXpertAgentExecution>) => Promise<AgentMiddlewareWrapWorkflowNodeExecutionResult<T>>;
    readonly params: AgentMiddlewareWrapWorkflowNodeExecutionParams;
    static readonly type = "[Workflow] Wrap Workflow Node Execution";
    constructor(fuc: (execution: Partial<IXpertAgentExecution>) => Promise<AgentMiddlewareWrapWorkflowNodeExecutionResult<T>>, params: AgentMiddlewareWrapWorkflowNodeExecutionParams);
}
