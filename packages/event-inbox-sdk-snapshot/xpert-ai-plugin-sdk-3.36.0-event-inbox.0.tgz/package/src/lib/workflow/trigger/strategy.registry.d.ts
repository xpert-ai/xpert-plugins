import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IWorkflowTriggerStrategy } from './strategy.interface';
export declare class WorkflowTriggerRegistry<T = any> extends BaseStrategyRegistry<IWorkflowTriggerStrategy<T>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
