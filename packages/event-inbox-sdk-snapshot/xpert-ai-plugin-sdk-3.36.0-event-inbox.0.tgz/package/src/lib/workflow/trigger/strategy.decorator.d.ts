export declare const WORKFLOW_TRIGGER_STRATEGY = "WORKFLOW_TRIGGER_STRATEGY";
export declare const WorkflowTriggerStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
