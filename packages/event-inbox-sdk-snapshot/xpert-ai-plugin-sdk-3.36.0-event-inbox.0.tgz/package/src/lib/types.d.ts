import { AssistantCapabilityDeclaration, IconDefinition, I18nObject, JsonSchemaObjectType, PluginMeta, PluginTargetApp, PluginTargetAppMeta, TAvatar, type TPromptWorkflow, XpertTypeEnum } from '@xpert-ai/contracts';
import type { DynamicModule, INestApplicationContext } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import type { ZodSchema } from 'zod/v3';
import type { Permissions } from './core/permissions';
export declare const ORGANIZATION_METADATA_KEY = "xpert:organizationId";
export declare const PLUGIN_METADATA_KEY = "xpert:pluginName";
export declare const PLUGIN_VERSION_METADATA_KEY = "xpert:pluginVersion";
export declare const GLOBAL_ORGANIZATION_SCOPE = "global";
export declare const SYSTEM_GLOBAL_SCOPE = "system:global";
export declare const BUILTIN_GLOBAL_SCOPE = "builtin:global";
export declare const TENANT_GLOBAL_SCOPE_PREFIX = "tenant:";
export declare const TENANT_GLOBAL_SCOPE_SUFFIX = ":global";
export declare const STRATEGY_META_KEY = "XPERT_STRATEGY_META_KEY";
export declare function getTenantGlobalScopeKey(tenantId: string): string;
export declare function isTenantGlobalScopeKey(value?: string | null): boolean;
export declare function setDefaultTenantId(tenantId?: string | null): void;
export declare function getDefaultTenantId(): string;
export declare function resolveTenantGlobalScopeKey(tenantId?: string | null): string;
export interface PluginLifecycle {
    /** Called after module registration but before application startup */
    onInit?(ctx: PluginContext): Promise<void> | void;
    /** Called after application startup (can start serving externally) */
    onStart?(ctx: PluginContext): Promise<void> | void;
    /** Called during graceful shutdown */
    onStop?(ctx: PluginContext): Promise<void> | void;
}
export interface PluginHealth {
    /** Returns health status and optional dependency check details */
    checkHealth?(ctx: PluginContext): Promise<{
        status: 'up' | 'down';
        details?: any;
    }> | {
        status: 'up' | 'down';
        details?: any;
    };
}
export interface PluginConfigSpec<T extends object = any> {
    /** Zod validation schema for plugin-level config (optional) */
    schema?: ZodSchema<T>;
    /** Default configuration */
    defaults?: Partial<T>;
    /** Optional JSON schema used by frontend configuration forms. */
    formSchema?: JsonSchemaObjectType;
}
export interface XpertPlugin<TConfig extends object = any> extends PluginLifecycle, PluginHealth {
    meta: PluginMeta;
    config?: PluginConfigSpec<TConfig>;
    /**
     * Xpert DSL templates contributed by this plugin. The platform namespaces
     * template ids as `${pluginName}:${key}` when exposing them through the
     * xpert-template API.
     */
    templates?: XpertTemplateContribution[] | XpertTemplateProvider | XpertTemplateCatalogProvider;
    /** Declares the required system-level permissions for this plugin. */
    permissions?: Permissions;
    /** Returns the DynamicModule to be mounted to the main application (can be set as global) */
    register(ctx: PluginContext<TConfig>): DynamicModule;
}
export interface XpertTemplateContribution {
    manifest?: import('@xpert-ai/contracts').TemplateManifest;
    key: string;
    id?: string;
    name?: string;
    title?: string | I18nObject;
    description?: string | I18nObject;
    category?: string;
    copyright?: string | null;
    privacyPolicy?: string | null;
    avatar?: TAvatar;
    icon?: IconDefinition;
    type?: XpertTypeEnum | 'project';
    targetApps?: PluginTargetApp[];
    targetAppMeta?: PluginTargetAppMeta | null;
    dslContent?: string;
    export_data?: string;
    order?: number;
    default?: boolean;
    startPrompts?: string[];
    promptWorkflows?: TPromptWorkflow[];
    releaseNotes?: string;
    availableLocales?: string[];
    defaultLocale?: string;
    locale?: string;
    pluginVersion?: string;
    contentHash?: string;
    xpertName?: string;
    capabilities?: AssistantCapabilityDeclaration[];
    dependencies?: import('@xpert-ai/contracts').AssistantTemplateDependencies;
    [key: string]: unknown;
}
export interface XpertTemplateProvider {
    listTemplates(ctx: PluginContext): PromiseOrValue<XpertTemplateContribution[]>;
}
/** Lists metadata without DSL; resolves exactly one immutable language variant on demand. */
export interface XpertTemplateCatalogProvider {
    kind: 'catalog';
    listTemplates(ctx: PluginContext): PromiseOrValue<XpertTemplateContribution[]>;
    resolveTemplate(ctx: PluginContext, key: string, locale?: string): PromiseOrValue<XpertTemplateContribution>;
}
export interface PluginContext<TConfig extends object = any> {
    module: ModuleRef;
    app?: INestApplicationContext;
    logger: PluginLogger;
    config: TConfig;
    /** Read current persisted configuration after host initialization or hot installation completes.
     * No background polling or cross-call cache. Errors propagate instead of returning stale configuration.
     * Optional for compatibility with older hosts; `config` remains the synchronous local snapshot.
     */
    readConfig?(): Promise<TConfig>;
    tenantId?: string | null;
    organizationId?: string | null;
    scopeKey?: string | null;
    /** Helper method to access other Providers in the container */
    resolve<TInput = any, TResult = TInput>(token: any): TResult;
}
export interface PluginLogger {
    child(meta: Record<string, any>): PluginLogger;
    debug(msg: string, meta?: any): void;
    log(msg: string, meta?: any): void;
    warn(msg: string, meta?: any): void;
    error(msg: string, meta?: any): void;
}
export type PromiseOrValue<T> = T | Promise<T>;
