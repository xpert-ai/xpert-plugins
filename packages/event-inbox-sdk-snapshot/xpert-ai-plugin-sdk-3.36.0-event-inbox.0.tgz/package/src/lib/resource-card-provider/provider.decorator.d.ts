import type { ResourceCardType } from './types';
export declare const RESOURCE_CARD_PROVIDER = "RESOURCE_CARD_PROVIDER";
/** Register exact resource types whose message cards opt in to live refresh. */
export declare const ResourceCardProvider: (...resources: ResourceCardType[]) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
