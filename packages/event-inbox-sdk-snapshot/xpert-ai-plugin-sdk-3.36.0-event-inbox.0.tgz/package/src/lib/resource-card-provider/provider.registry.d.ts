import { type OnModuleDestroy } from '@nestjs/common';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { IResourceCardProvider, ResourceCardType } from './types';
export declare class ResourceCardProviderRegistry extends BaseStrategyRegistry<IResourceCardProvider> implements OnModuleDestroy {
    private readonly resourceLogger;
    private subscription?;
    constructor(discovery: DiscoveryService, reflector: Reflector);
    onModuleInit(): void;
    onModuleDestroy(): void;
    remove(scopeKey: string, pluginName: string): void;
    upsert(instance: unknown): void;
    find(resource: ResourceCardType, organizationId?: string): IResourceCardProvider | undefined;
}
