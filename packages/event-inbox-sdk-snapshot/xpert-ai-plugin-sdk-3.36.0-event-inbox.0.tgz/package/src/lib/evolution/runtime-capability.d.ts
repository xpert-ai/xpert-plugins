import type { EvolutionRuntimeApi, EvolutionChangeRuntimeApi, EvolutionBaselineRuntimeApi } from '@xpert-ai/contracts';
export declare const EVOLUTION_RUNTIME_SERVICE_TOKEN = "XPERT_EVOLUTION_RUNTIME_SERVICE";
export declare const ExecutionReviewRuntimeCapability: import("../core").RuntimeCapabilityKey<import("@xpert-ai/contracts").ExecutionReviewApi>;
/** Capability for inspecting and publishing source baselines within an authorized organization. */
export declare const EvolutionBaselineRuntimeCapability: import("../core").RuntimeCapabilityKey<EvolutionBaselineRuntimeApi>;
/** Capability for version selection and evidence tied to Agent executions. */
export declare const EvolutionRuntimeCapability: import("../core").RuntimeCapabilityKey<EvolutionRuntimeApi>;
/** Capability for scoped preparation, review and publication of versioned changes. */
export declare const EvolutionChangeRuntimeCapability: import("../core").RuntimeCapabilityKey<EvolutionChangeRuntimeApi>;
