export declare const EVOLUTION_TARGET_PROVIDER = "EVOLUTION_TARGET_PROVIDER";
/** Declares the stable registration key of an evolution target provider. */
export declare const EvolutionTargetProviderStrategy: (providerKey: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
