import { EvolutionTargetProvider } from '@xpert-ai/contracts';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
/** Registry of evolution targets visible within a strategy scope. */
export declare class EvolutionTargetProviderRegistry extends BaseStrategyRegistry<EvolutionTargetProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    /** Returns target declarations visible in the supplied organization scope. */
    listDescriptors(organizationId?: string): import("@xpert-ai/contracts").EvolutionTargetDescriptor[];
}
