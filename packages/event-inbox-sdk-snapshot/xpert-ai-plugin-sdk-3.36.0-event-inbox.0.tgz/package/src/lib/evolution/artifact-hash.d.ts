/** JSON data eligible for a reproducible evolution digest. Array order is significant; object key order is not. */
export type EvolutionJson = null | boolean | number | string | EvolutionJson[] | {
    [key: string]: EvolutionJson;
};
/** Returns the sha256-prefixed hex digest of the canonical JSON value. */
export declare function hashEvolutionValue(value: EvolutionJson): string;
/** Serializes JSON with object keys in sorted order and array elements in their original order. */
export declare function canonicalEvolutionJson(value: EvolutionJson): string;
