export declare const INTEGRATION_STRATEGY = "INTEGRATION_STRATEGY";
export declare const IntegrationStrategyKey: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
