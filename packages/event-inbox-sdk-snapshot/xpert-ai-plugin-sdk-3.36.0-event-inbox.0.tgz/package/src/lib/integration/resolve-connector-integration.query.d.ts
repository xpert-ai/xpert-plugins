import { Query } from '@nestjs/cqrs';
import type { IIntegration } from '@xpert-ai/contracts';
/** Read an app for an authorized connector using its persisted scope, including public OAuth callbacks. */
export declare class ResolveConnectorIntegrationQuery extends Query<IIntegration | null> {
    readonly id: string;
    readonly provider: string;
    readonly scope: {
        tenantId: string;
        organizationId: string | null;
    };
    static readonly type = "[Integration] Resolve connector application";
    constructor(id: string, provider: string, scope: {
        tenantId: string;
        organizationId: string | null;
    });
}
