import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { IntegrationStrategy } from './strategy.interface';
export declare class IntegrationStrategyRegistry extends BaseStrategyRegistry<IntegrationStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
