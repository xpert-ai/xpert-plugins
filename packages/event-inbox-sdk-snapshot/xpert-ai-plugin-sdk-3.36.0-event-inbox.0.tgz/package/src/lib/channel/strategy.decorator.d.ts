/**
 * Metadata key for chat channel
 */
export declare const CHAT_CHANNEL = "CHAT_CHANNEL";
/**
 * Decorator for chat channel implementations
 *
 * Use this decorator to register a chat channel implementation.
 * The decorated class will be automatically discovered and registered
 * to ChatChannelRegistry on module initialization.
 *
 * @param type - The channel type identifier (e.g., 'lark', 'wecom', 'dingtalk')
 *
 * @example
 * ```typescript
 * @Injectable()
 * @ChatChannel('lark')
 * export class LarkChatChannel implements IChatChannel {
 *   // Implementation
 * }
 * ```
 */
export declare const ChatChannel: (type: string) => import("@nestjs/common").CustomDecorator<string>;
