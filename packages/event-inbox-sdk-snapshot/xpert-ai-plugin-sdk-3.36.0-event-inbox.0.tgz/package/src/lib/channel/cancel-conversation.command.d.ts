import { ICommand } from '@nestjs/cqrs';
export declare class CancelConversationCommand implements ICommand {
    readonly input: {
        conversationId?: string;
        threadId?: string;
        executionId?: string;
    };
    static readonly type = "[Chat Conversation] Cancel";
    constructor(input: {
        conversationId?: string;
        threadId?: string;
        executionId?: string;
    });
}
