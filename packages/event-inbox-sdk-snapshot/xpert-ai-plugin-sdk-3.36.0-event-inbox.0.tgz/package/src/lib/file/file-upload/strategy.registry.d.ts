import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IFileUploadTargetStrategy } from './strategy.interface';
export declare class FileUploadTargetRegistry extends BaseStrategyRegistry<IFileUploadTargetStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
