export declare const FILE_STORAGE_PROVIDER = "FILE_STORAGE_PROVIDER";
export declare const FileStorageProvider: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
