import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IFileStorageProvider } from './provider.interface';
export declare class FileStorageProviderRegistry extends BaseStrategyRegistry<IFileStorageProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
