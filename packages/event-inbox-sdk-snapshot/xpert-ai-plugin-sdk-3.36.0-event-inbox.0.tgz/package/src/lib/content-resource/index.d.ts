import type { ContentReferenceProvider } from './reference';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { OrganizationRuntimeActor } from '../runtime/actor';
export type ContentActor = OrganizationRuntimeActor;
export interface ContentPrincipal extends ContentActor {
    groupIds: string[];
}
export type ContentOperation = 'read' | 'comment' | 'write' | 'manage';
export interface ContentResourceReference {
    providerKey: string;
    resourceId: string;
}
export interface ContentResourceRequest extends ContentResourceReference {
    actor: ContentActor;
    operation: ContentOperation;
    /** Relative immutable file path. Providers must validate its owning item. */
    filePath?: string;
}
export interface ContentResourceDescriptor extends ContentResourceReference {
    title: string;
    role: string;
    canWrite: boolean;
    canManage: boolean;
}
/** Source hook scope uses the provider's identifier; it is never a platform document id. */
export type ContentSourceInput = import('./document').ContentDocumentScope & {
    sourceResourceId: string;
};
export interface ContentPageProvider {
    pageHierarchy(input: ContentSourceInput): Promise<import('@xpert-ai/contracts').ContentPageHierarchy>;
    /** Retry requestId after unknown outcomes. Return the registered platform document id. */
    createChildPage(input: ContentSourceInput & {
        title: string;
        requestId: string;
    }): Promise<{
        documentId: string;
    }>;
}
export interface ContentPublicationObserver {
    /** Retryable projection: compare the supplied head before updating derived data. */
    onDocumentPublished(input: ContentSourceInput & {
        path: string;
        hash: string;
        revisionId: string;
        sequence: number;
    }): Promise<void>;
}
export interface ContentLocationProvider {
    validateLocationChange(input: import('./document').ContentLocationChangeInput): Promise<void>;
    onLocationPrepared?(input: import('./document').ContentLocationChangeInput & {
        operationId: string;
    }): Promise<void>;
    onLocationChanged(input: import('./document').ContentLocationChangeInput & {
        operationId: string;
    }): Promise<void>;
}
/** Resource authorization is mandatory. Content extensions are explicitly composed, never inferred. */
export interface IContentResourceProvider {
    readonly title: string;
    authorize(input: ContentResourceRequest & {
        principal: ContentPrincipal;
    }): Promise<ContentResourceDescriptor>;
    readonly editor?: import('./editor').ContentResourceEditor;
    readonly references?: ContentReferenceProvider;
    readonly pages?: ContentPageProvider;
    readonly publication?: ContentPublicationObserver;
    readonly locations?: ContentLocationProvider;
    readonly catalog?: import('./catalog').ContentCatalogProvider;
}
export declare const CONTENT_RESOURCE_PROVIDER = "XPERT_CONTENT_RESOURCE_PROVIDER";
export declare const ContentResourceProvider: (key: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class ContentResourceProviderRegistry extends BaseStrategyRegistry<IContentResourceProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
}
export interface ContentIdentitiesApi {
    /** Checks current active organization membership, then resolves current groups. */
    principal(actor: ContentActor): Promise<ContentPrincipal>;
    directory(actor: ContentActor, query: string): Promise<Array<{
        id: string;
        type: 'user' | 'group';
        label: string;
    }>>;
}
export interface ContentResourcesApi {
    readonly identities: ContentIdentitiesApi;
    authorize(input: ContentResourceRequest): Promise<ContentResourceDescriptor>;
    readonly catalog: import('./catalog').ContentCatalogApi;
    /** Conversation-scoped discovery for Views; group authorization does not expand the Project catalog. */
    readonly discovery: import('./discovery').ConversationResourcesApi;
}
export declare const ContentResourcesRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ContentResourcesApi>;
export * from './document';
export * from './reference';
export * from './editor';
export * from './catalog';
export * from './discovery';
