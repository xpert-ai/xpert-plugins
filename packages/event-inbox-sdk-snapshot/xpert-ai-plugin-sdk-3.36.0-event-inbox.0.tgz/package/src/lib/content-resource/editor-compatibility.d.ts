import type { ContentModelIdentity, ResourceContentEditorRegistration } from '@xpert-ai/contracts';
/** Matching semantic type alone never grants a writer access to an incompatible native model. */
export declare function supportsContentModel(editor: ResourceContentEditorRegistration, model: ContentModelIdentity, access: 'view' | 'edit'): boolean;
