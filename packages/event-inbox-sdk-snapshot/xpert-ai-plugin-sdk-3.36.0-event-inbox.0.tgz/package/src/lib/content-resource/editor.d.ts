import { DiscoveryService, Reflector } from '@nestjs/core';
import type { ContentEditorRegistration, FileContentEditorRegistration, ResourceContentEditorRegistration } from '@xpert-ai/contracts';
import { BaseStrategyRegistry } from '../strategy';
import type { ContentDocumentModel, ContentDocumentScope } from './document';
import type { ContentResourceReference, ContentSourceInput } from './index';
export { supportsContentModel } from './editor-compatibility';
/** File codecs expose no cells, blocks or plugin-specific edit operations to the platform. */
export interface ContentFileEditor {
    readonly descriptor: FileContentEditorRegistration;
    create(): Promise<Buffer>;
    validateFile(buffer: Buffer): Promise<void>;
}
export interface ContentResourceEditorImplementation {
    readonly descriptor: ResourceContentEditorRegistration;
}
export type IContentEditorProvider = ContentDocumentModel | ContentFileEditor | ContentResourceEditorImplementation;
export declare function isTextContentEditor(provider: IContentEditorProvider): provider is ContentDocumentModel;
export declare function isFileContentEditor(provider: IContentEditorProvider): provider is ContentFileEditor;
export declare function isResourceContentEditor(provider: IContentEditorProvider): provider is ContentResourceEditorImplementation;
export declare const ContentEditorProvider: (key: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class ContentEditorRegistry extends BaseStrategyRegistry<IContentEditorProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
    getTextModel(key: string, organizationId: string): ContentDocumentModel;
}
export interface ContentEditorFile {
    editorKey: string;
    projectId: string;
    path: string;
    title: string;
}
/** Resource owner supplies current identity/location and owns atomic versions, independent of format. */
export interface ContentResourceEditor {
    describe(input: ContentSourceInput): Promise<ContentEditorFile>;
    files?: {
        read(input: ContentSourceInput): Promise<{
            buffer: Buffer;
            revision: string;
        }>;
        write(input: ContentSourceInput & {
            buffer: Buffer;
            expectedRevision: string;
        }): Promise<{
            revision: string;
        }>;
    };
}
export type ContentEditorInput = ContentDocumentScope & {
    source: ContentResourceReference;
    editorKey?: string;
};
export type ContentEditorPreferenceScope = 'resource' | 'project' | 'organization';
export interface ContentEditorPreferenceState {
    scope: ContentEditorPreferenceScope;
    editorKey: string | null;
    revision: number;
    canSet: boolean;
}
export interface ContentEditorResolution {
    registration: ContentEditorRegistration;
    file?: ContentEditorFile;
    resource?: import('@xpert-ai/contracts').ContentCatalogItem;
    canWrite: boolean;
    viewKey: string;
    selectionId?: string;
    parameters?: {
        contentProvider: string;
        contentId?: string;
        contentTitle?: string;
        contentEditor?: string;
    };
    editors?: ResourceContentEditorRegistration[];
}
/** Trusted scope only. Every operation checks Project, Assistant binding and resource permissions. */
export interface ContentEditorsApi {
    preferences(input: ContentDocumentScope & {
        contentId: string;
    }): Promise<ContentEditorPreferenceState[]>;
    setPreference(input: ContentDocumentScope & {
        contentId: string;
        scope: ContentEditorPreferenceScope;
        editorKey: string | null;
        expectedRevision: number;
    }): Promise<ContentEditorPreferenceState>;
    list(scope: ContentDocumentScope): Promise<ContentEditorRegistration[]>;
    /** Prepare/validate bytes; does not create a resource or grant access to a destination. */
    prepare(scope: ContentDocumentScope & {
        editorKey: string;
        buffer?: Buffer;
    }): Promise<{
        registration: FileContentEditorRegistration;
        buffer: Buffer;
    }>;
    resolve(input: ContentEditorInput): Promise<ContentEditorResolution>;
    read(input: ContentEditorInput): Promise<ContentEditorResolution & {
        buffer: Buffer;
        revision: string;
    }>;
    write(input: ContentEditorInput & {
        buffer: Buffer;
        expectedRevision: string;
    }): Promise<{
        revision: string;
    }>;
}
export declare const ContentEditorsRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ContentEditorsApi>;
