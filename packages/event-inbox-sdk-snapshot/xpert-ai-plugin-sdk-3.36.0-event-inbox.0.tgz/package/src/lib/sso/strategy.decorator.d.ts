export declare const SSO_PROVIDER = "SSO_PROVIDER";
export declare const SSOProviderStrategyKey: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
