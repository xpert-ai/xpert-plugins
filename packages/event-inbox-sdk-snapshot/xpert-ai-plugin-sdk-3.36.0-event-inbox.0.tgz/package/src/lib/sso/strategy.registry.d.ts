import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { ISSOProviderStrategy } from './strategy.interface';
export declare class SSOProviderRegistry extends BaseStrategyRegistry<ISSOProviderStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
