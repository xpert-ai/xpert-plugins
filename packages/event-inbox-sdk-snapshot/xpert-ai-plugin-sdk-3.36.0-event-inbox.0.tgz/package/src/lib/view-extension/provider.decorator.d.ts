export declare const VIEW_EXTENSION_PROVIDER = "VIEW_EXTENSION_PROVIDER";
export declare const ViewExtensionProvider: (providerKey: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
