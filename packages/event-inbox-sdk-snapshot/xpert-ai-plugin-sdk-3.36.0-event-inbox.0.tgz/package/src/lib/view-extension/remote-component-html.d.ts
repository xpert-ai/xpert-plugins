export interface RenderRemoteReactIframeHtmlOptions {
    title: string;
    reactUmd: string;
    reactDomUmd: string;
    appScript: string;
    appCss?: string;
    lang?: string;
}
export interface RenderRemoteModuleIframeHtmlOptions {
    title: string;
    appScript: string;
    appCss?: string;
    lang?: string;
}
export interface RenderRemoteVueIframeHtmlOptions extends RenderRemoteModuleIframeHtmlOptions {
}
export declare function renderRemoteReactIframeHtml(options: RenderRemoteReactIframeHtmlOptions): string;
export declare function renderRemoteModuleIframeHtml(options: RenderRemoteModuleIframeHtmlOptions): string;
export declare function renderRemoteVueIframeHtml(options: RenderRemoteVueIframeHtmlOptions): string;
