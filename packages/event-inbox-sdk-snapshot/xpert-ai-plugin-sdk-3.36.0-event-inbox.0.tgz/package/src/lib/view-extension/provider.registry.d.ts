import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { IXpertViewExtensionProvider } from './provider.interface';
export declare class ViewExtensionProviderRegistry extends BaseStrategyRegistry<IXpertViewExtensionProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    listEntries(organizationId?: string): Array<{
        providerKey: string;
        provider: IXpertViewExtensionProvider;
    }>;
}
