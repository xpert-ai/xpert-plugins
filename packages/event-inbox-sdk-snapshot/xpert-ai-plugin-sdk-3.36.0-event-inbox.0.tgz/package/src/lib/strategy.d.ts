import { OnModuleInit, type Type } from '@nestjs/common';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { StrategyBus } from './core/strategy-bus';
export type StrategySource = {
    kind: 'builtin';
    scopeKey: string;
} | {
    kind: 'plugin';
    pluginName: string;
    pluginVersion?: string;
    scopeKey: string;
};
export declare class BaseStrategyRegistry<S> implements OnModuleInit {
    protected readonly strategyKey: string;
    protected discoveryService: DiscoveryService;
    protected reflector: Reflector;
    private readonly logger;
    protected readonly bus: StrategyBus;
    protected strategies: Map<string, Map<string, S>>;
    protected pluginStrategies: Map<string, Set<string>>;
    private readonly explicitSources;
    constructor(strategyKey: string, discoveryService: DiscoveryService, reflector: Reflector);
    onModuleInit(): void;
    upsert(instance: unknown): void;
    /** Registers a host-generated adapter without mutating shared class metadata. */
    register(type: string, instance: S, source: StrategySource): S;
    /** Preflights adapter batches so a provider is expanded atomically across registries. */
    assertCanRegister(type: string, instance: S, source: StrategySource): void;
    /** Removes one exact programmatic registration without affecting fallback scopes. */
    unregister(type: string, source: StrategySource, expected?: S): boolean;
    /** Returns the explicit registry provenance attached by the plugin loader. */
    getSource(instance: S): StrategySource;
    /**
     * Remove all strategies registered by the given plugin for the given scope.
     */
    remove(organizationId: string, pluginName: string): void;
    /**
     * Resolve the primary scope key, falling back to request context org or tenant-global scope.
     */
    protected resolveOrganization(organizationId?: string): string;
    protected resolveGlobalFallbackOrganization(): string;
    protected resolveStrategyScopeKeys(organizationId?: string): string[];
    /**
     * Get strategy by type from the given organization including global strategies as fallback.
     *
     * @param type
     * @param organizationId
     * @returns
     */
    get(type: string, organizationId?: string): S;
    /**
     * List all strategies for the given organization including global strategies, or only global strategies if global org is specified.
     *
     * @param organizationId
     * @returns
     */
    list(organizationId?: string): S[];
    listRegistrations(organizationId?: string): Array<{
        type: string;
        strategy: S;
        source: StrategySource;
    }>;
    /** Returns every direct registration without applying request-scope fallback rules. */
    listAllRegistrations(): Array<{
        type: string;
        strategy: S;
        source: StrategySource;
    }>;
    private store;
}
/** Returns whether a discovered provider can carry decorator metadata. */
export declare function isStrategyInstance(instance: unknown): instance is object;
/** Resolves the class used for plugin and organization metadata without reflecting over primitive provider values. */
export declare function resolveStrategyMetadataTarget(instance: unknown): Type<unknown> | null;
