import { HandoffProcessorMetadata } from './handoff.interface';
/**
 * Handoff Processor meta key。
 */
export declare const HANDOFF_PROCESSOR_STRATEGY = "HANDOFF_PROCESSOR_STRATEGY";
/**
 * Declare on a provider:
 * 1) Which message types it handles
 * 2) Default execution policy (lane/timeout)
 */
export declare function HandoffProcessorStrategy(provider: string, metadata: HandoffProcessorMetadata): <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
