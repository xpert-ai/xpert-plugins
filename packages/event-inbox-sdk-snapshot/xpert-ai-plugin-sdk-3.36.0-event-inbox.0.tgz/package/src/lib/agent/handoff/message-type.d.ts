/**
 * Structured message types (suggested format):
 * - channel.{provider}.{action}.v{number}
 * - agent.{action}.v{number}
 * - system.{action}.v{number}
 * - plugin.{domain}.{action}.v{number}
 *
 * Note: At runtime, any string type is still allowed, facilitating dynamic extension by plugins.
 */
export type StructuredHandoffMessageType = `channel.${string}.${string}.v${number}` | `agent.${string}.v${number}` | `system.${string}.v${number}` | `plugin.${string}.${string}.v${number}`;
/**
 * Unified construction of channel message types to avoid manual string errors.
 * Example: channel.lark.inbound.v1
 */
export declare function defineChannelMessageType(provider: string, action: string, version: number): StructuredHandoffMessageType;
/**
 * Unified construction of agent message types.
 * Example: agent.handoff.v1
 */
export declare function defineAgentMessageType(action: string, version: number): StructuredHandoffMessageType;
/**
 * Check if a type conforms to the structured naming convention (format only, no semantic validation).
 */
export declare function isStructuredMessageType(type: string): boolean;
