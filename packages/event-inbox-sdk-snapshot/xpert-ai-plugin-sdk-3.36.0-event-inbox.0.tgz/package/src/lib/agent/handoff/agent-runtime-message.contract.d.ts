import { z } from 'zod/v3';
import { type AgentRuntimeReplyTarget } from '../runtime/dispatch';
export declare const AGENT_RUNTIME_EVENT_MESSAGE_TYPE: import("./message-type").StructuredHandoffMessageType;
/** Host-produced references. Consumers reload and authorize the invocation and its pinned observation. */
export declare const agentRuntimeEventSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    kind: z.ZodLiteral<"progress">;
    progress: z.ZodObject<{
        source: z.ZodEnum<["executor", "host"]>;
        observedAt: z.ZodString;
        startedAt: z.ZodOptional<z.ZodString>;
        phase: z.ZodOptional<z.ZodString>;
        summary: z.ZodOptional<z.ZodString>;
        steps: z.ZodOptional<z.ZodEffects<z.ZodObject<{
            completed: z.ZodNumber;
            total: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            completed: number;
            total: number;
        }, {
            completed: number;
            total: number;
        }>, {
            completed: number;
            total: number;
        }, {
            completed: number;
            total: number;
        }>>;
    }, "strict", z.ZodTypeAny, {
        source: "executor" | "host";
        observedAt: string;
        startedAt?: string | undefined;
        steps?: {
            completed: number;
            total: number;
        } | undefined;
        summary?: string | undefined;
        phase?: string | undefined;
    }, {
        source: "executor" | "host";
        observedAt: string;
        startedAt?: string | undefined;
        steps?: {
            completed: number;
            total: number;
        } | undefined;
        summary?: string | undefined;
        phase?: string | undefined;
    }>;
    version: z.ZodLiteral<1>;
    invocationId: z.ZodString;
    /** Revision of the persisted observation, never a queue delivery attempt. */
    revision: z.ZodNumber;
    projectTask: z.ZodOptional<z.ZodObject<{
        projectId: z.ZodString;
        projectTaskId: z.ZodString;
        taskExecutionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    kind?: "progress";
    version?: 1;
    progress?: {
        source: "executor" | "host";
        observedAt: string;
        startedAt?: string | undefined;
        steps?: {
            completed: number;
            total: number;
        } | undefined;
        summary?: string | undefined;
        phase?: string | undefined;
    };
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
}, {
    kind?: "progress";
    version?: 1;
    progress?: {
        source: "executor" | "host";
        observedAt: string;
        startedAt?: string | undefined;
        steps?: {
            completed: number;
            total: number;
        } | undefined;
        summary?: string | undefined;
        phase?: string | undefined;
    };
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"result">;
    status: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
    version: z.ZodLiteral<1>;
    invocationId: z.ZodString;
    /** Revision of the persisted observation, never a queue delivery attempt. */
    revision: z.ZodNumber;
    projectTask: z.ZodOptional<z.ZodObject<{
        projectId: z.ZodString;
        projectTaskId: z.ZodString;
        taskExecutionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    status?: "failed" | "succeeded" | "cancelled";
    kind?: "result";
    version?: 1;
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
}, {
    status?: "failed" | "succeeded" | "cancelled";
    kind?: "result";
    version?: 1;
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"input_request">;
    interactionId: z.ZodString;
    version: z.ZodLiteral<1>;
    invocationId: z.ZodString;
    /** Revision of the persisted observation, never a queue delivery attempt. */
    revision: z.ZodNumber;
    projectTask: z.ZodOptional<z.ZodObject<{
        projectId: z.ZodString;
        projectTaskId: z.ZodString;
        taskExecutionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }, {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    kind?: "input_request";
    version?: 1;
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
    interactionId?: string;
}, {
    kind?: "input_request";
    version?: 1;
    revision?: number;
    projectTask?: {
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    invocationId?: string;
    interactionId?: string;
}>]>;
export type AgentRuntimeEvent = z.output<typeof agentRuntimeEventSchema>;
/** Same observation always has the same HandoffMessage.id across retries and process restarts. */
export declare function agentRuntimeEventMessageId(event: Pick<AgentRuntimeEvent, 'invocationId' | 'revision' | 'kind'>): string;
/** Transport states are deliberately separate from Task and Invocation status. */
export declare const agentRuntimeDeliveryStateSchema: z.ZodEnum<["pending", "received", "blocked", "failed"]>;
export declare const agentRuntimeConsumptionStateSchema: z.ZodEnum<["pending", "processing", "processed", "blocked", "failed"]>;
export type AgentRuntimeDeliveryState = z.output<typeof agentRuntimeDeliveryStateSchema>;
export type AgentRuntimeConsumptionState = z.output<typeof agentRuntimeConsumptionStateSchema>;
/** Store under a unique scoped key in the same transaction as the continuation reservation. */
export declare const agentRuntimeResultClaimSchema: z.ZodObject<{
    invocationId: z.ZodString;
    resultRevision: z.ZodNumber;
    recipient: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodOptional<z.ZodLiteral<"xpert">>;
        xpertId: z.ZodString;
        agentKey: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    }, {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"project_agent">;
        projectId: z.ZodString;
        agentKey: z.ZodLiteral<"general_agent">;
        conversationId: z.ZodString;
        threadId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    }, {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    }>]>;
    consumer: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"follow_up">;
        executionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "follow_up";
        executionId?: string;
    }, {
        type?: "follow_up";
        executionId?: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"wait">;
        executionId: z.ZodString;
        callId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "wait";
        executionId?: string;
        callId?: string;
    }, {
        type?: "wait";
        executionId?: string;
        callId?: string;
    }>]>;
}, "strict", z.ZodTypeAny, {
    invocationId?: string;
    resultRevision?: number;
    recipient?: {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    } | {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    };
    consumer?: {
        type?: "follow_up";
        executionId?: string;
    } | {
        type?: "wait";
        executionId?: string;
        callId?: string;
    };
}, {
    invocationId?: string;
    resultRevision?: number;
    recipient?: {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    } | {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    };
    consumer?: {
        type?: "follow_up";
        executionId?: string;
    } | {
        type?: "wait";
        executionId?: string;
        callId?: string;
    };
}>;
export type AgentRuntimeResultClaim = z.output<typeof agentRuntimeResultClaimSchema>;
/**
 * Wait and asynchronous reply compete for this same key, regardless of delivery revision.
 * The storage key must additionally include tenant, organization and owner from trusted scope.
 */
export declare function agentRuntimeResultConsumptionKey(invocationId: string, recipient: AgentRuntimeReplyTarget): string;
