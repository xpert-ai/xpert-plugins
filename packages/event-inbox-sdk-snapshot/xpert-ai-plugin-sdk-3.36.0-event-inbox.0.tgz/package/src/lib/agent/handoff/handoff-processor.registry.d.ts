import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IHandoffProcessor } from './handoff.interface';
export declare class HandoffProcessorRegistry extends BaseStrategyRegistry<IHandoffProcessor> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
