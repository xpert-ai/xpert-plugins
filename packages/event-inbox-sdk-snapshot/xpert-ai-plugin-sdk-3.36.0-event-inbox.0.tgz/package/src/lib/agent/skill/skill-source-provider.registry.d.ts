import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { ISkillSourceProvider } from './skill-source-provider.interface';
export declare class SkillSourceProviderRegistry extends BaseStrategyRegistry<ISkillSourceProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
