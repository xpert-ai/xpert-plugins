export declare const SKILL_SOURCE_PROVIDER = "SKILL_SOURCE_PROVIDER";
export declare const SkillSourceProviderStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
