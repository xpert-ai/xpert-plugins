import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IAgentMiddlewareStrategy } from './strategy.interface';
export declare class AgentMiddlewareRegistry extends BaseStrategyRegistry<IAgentMiddlewareStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
