export declare const AGENT_MIDDLEWARE_STRATEGY = "AGENT_MIDDLEWARE_STRATEGY";
export declare const AgentMiddlewareStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
