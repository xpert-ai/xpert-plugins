import type { z } from 'zod/v3';
import type { ExecutionObservationQueryInput, ExecutionObservationOverview, ExecutionObservationList, ExecutionObservationConversations, ExecutionObservationSummary, ExecutionObservationDetail, ExecutionObservationComparison, ExecutionObservationAnomalies, executionObservationDetailQuerySchema, executionObservationCompareSchema, executionObservationAnomalySchema } from '@xpert-ai/contracts';
import { type IApiPrincipal } from '@xpert-ai/contracts';
/** Credential audience check only; the host must still revalidate the human's live admin role and grant. */
export declare function isExecutionObservationSession(principal: IApiPrincipal | null, xpertId?: string | null): boolean;
/** Read-only execution analytics. The host binds identity; arguments cannot change its authorization scope. */
export interface ExecutionObservabilityApi {
    workspaces(input: {
        page: number;
        search?: string;
    }): Promise<{
        items: Array<{
            id: string;
            name: string;
        }>;
        hasMore: boolean;
    }>;
    overview(input: ExecutionObservationQueryInput): Promise<ExecutionObservationOverview>;
    conversations(input: ExecutionObservationQueryInput): Promise<ExecutionObservationConversations>;
    query(input: ExecutionObservationQueryInput): Promise<ExecutionObservationList>;
    summary(input: ExecutionObservationQueryInput): Promise<ExecutionObservationSummary>;
    get(input: z.input<typeof executionObservationDetailQuerySchema>): Promise<ExecutionObservationDetail>;
    compare(input: z.input<typeof executionObservationCompareSchema>): Promise<ExecutionObservationComparison>;
    findAnomalies(input: z.input<typeof executionObservationAnomalySchema>): Promise<ExecutionObservationAnomalies>;
}
export declare const ExecutionObservabilityRuntimeCapability: import("../../../core/runtime-capability").RuntimeCapabilityKey<ExecutionObservabilityApi>;
