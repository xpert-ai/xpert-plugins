import type { ModelExecutionModel, ModelExecutionLimits, ModelExecutionProtocol, ModelFeature, CliPermissionMode } from '@xpert-ai/contracts';
/** Configuration adapters describe secrets by reference; only the host materializes credentials. */
export declare const CLI_MODEL_TOKEN_REFERENCE = "${XPERT_EXECUTION_TOKEN}";
export interface CliModelConfiguration {
    args: string[];
    environment: Record<string, string>;
    files: Array<{
        name: string;
        content: string;
    }>;
}
export interface CliModelConfigurationInput {
    directory: string;
    gatewayBaseUrl: string;
    defaultModelId?: string;
    models: Array<Pick<ModelExecutionModel, 'id' | 'protocols' | 'contextWindow' | 'outputTokenLimit' | 'parameters'>>;
    /** @deprecated Legacy input only. Use the selected model's catalog metadata. */
    limits?: Partial<ModelExecutionLimits> & {
        maxOutputTokens?: number;
    };
    managed: boolean;
    /** Host-resolved CLI approval policy; omitted preserves the profile's default behavior. */
    permissionMode?: CliPermissionMode;
}
/** Installed trusted code; neither an executable path nor a model permission comes from this adapter. */
export interface CliModelProfile {
    id: string;
    revision: string;
    command: string;
    protocol: Extract<ModelExecutionProtocol, 'openai_chat' | 'openai_responses' | 'anthropic_messages'>;
    requiredCapabilities: ModelFeature[];
    /** Modes this profile explicitly implements; unsupported modes must not be silently ignored. */
    permissionModes?: readonly CliPermissionMode[];
    /** Native authentication stays in the owner Computer; the host never receives credentials. */
    native?: {
        versions: readonly string[];
        homeDirectory: string;
        statusArguments: readonly string[];
        loginArguments: readonly string[];
        logoutArguments: readonly string[];
        testArguments: readonly string[];
        configure(input: {
            home: string;
            permissionMode: CliPermissionMode;
        }): CliModelConfiguration;
    };
    chatBridge?: {
        versions: readonly string[];
        requiredCapabilities: ModelFeature[];
    };
    /** Optional host-managed background transport. Arguments are trusted profile code, never model input. */
    background?: {
        versions: readonly string[];
    } & ({
        transport: 'opencode';
    } | {
        transport: 'jsonl';
        args: readonly string[];
        /** For CLIs without stdin prompt support. Host appends one literal argv value, never shell text. */
        promptArgument?: string;
    });
    /** Exact complete argv sequences that never need a model grant. */
    offlineArguments: readonly (readonly string[])[];
    /** Exact accepted stdout values for a policy-pinned version probe. */
    versionOutputs(version: string): string[];
    configure(input: CliModelConfigurationInput): CliModelConfiguration;
}
export interface CliModelProfiles {
    get(id: string): CliModelProfile | undefined;
}
export declare const CliModelProfilesCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<CliModelProfiles>;
/** Additional execution sources can validate lifecycle without making OS depend on Pro entities. */
export declare const ShellModelExecutionSourceCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<{
    assertCurrent(context: import("@xpert-ai/contracts").ExecutionSourceContext, preparing?: boolean): Promise<void>;
}>;
