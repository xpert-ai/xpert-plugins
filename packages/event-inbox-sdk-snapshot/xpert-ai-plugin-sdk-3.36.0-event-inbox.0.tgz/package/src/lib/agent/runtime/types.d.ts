import type { ExecutionControlEvidence, AgentInvocationStatus, AgentRuntimeProgress, ModelExecutionEnvironment, ExecutionActivityCapabilities, ProjectPipelineWorkContext } from '@xpert-ai/contracts';
export type { AgentInvocationStatus, AgentRuntimeProgress } from '@xpert-ai/contracts';
import type { AgentInvocationDispatchContext } from './dispatch';
import type { AgentRunnerReceipt } from './execution-runner';
import type { AgentOutputDelivery, AgentOutputExport, AgentResultArtifact, AgentResultItem } from './results';
/** Serializable invocation data. Use finite numbers and plain objects; exclude credentials. */
export type AgentJson = null | boolean | number | string | AgentJson[] | {
    [key: string]: AgentJson;
};
/** Host-authorized ownership and execution scope; never accept identities from model input. */
export interface AgentInvocationScope {
    tenantId: string;
    organizationId: string;
    userId: string;
    workspaceId?: string;
    projectId?: string;
    /** Platform conversation ID, distinct from a provider session ID. */
    conversationId?: string;
    /** Opaque parent execution identity; host Task adapters may use logical IDs. */
    parentExecutionId: string;
    /** Calling Agent key or host-assigned background-task entry. */
    callerAgentKey: string;
    /** Omitted preserves existing Assistant callers. Project general agents have no fabricated Assistant ID. */
    callerType?: 'xpert' | 'project_agent' | 'project_pipeline';
    /** Exact durable Pipeline work, reauthorized by the host before resolving or controlling a binding. */
    pipelineOrigin?: ProjectPipelineWorkContext;
    callerXpertId?: string;
}
/** Authorized, version-pinned target. Pass the resolved snapshot unchanged. */
export interface AgentTarget {
    /** Opaque host binding ID; do not assume UUID format or derive the provider from it. */
    bindingId: string;
    /** Registered AgentRuntimeStrategy key. */
    provider: string;
    /** Opaque configuration version, distinct from the invocation revision. */
    revision: string;
    /** Provider-specific target/profile reference. */
    reference: string;
    /** Validated configuration; use managed secret references instead of credentials. */
    configuration: {
        [key: string]: AgentJson;
    };
}
/** Provider support flags; they do not grant caller permissions. */
export interface AgentRuntimeCapabilities {
    /** Explicitly allow repeat delivery of the same cancellation after an ambiguous response. */
    idempotentCancellation?: boolean;
    /** Versioned proof of original operation completion, including its owned work. Omitted is unsupported. */
    completionEvidence?: 1 | 2;
    /** Process-local adapters must be controlled on the host boot that admitted the execution. */
    hostAffinity?: 1;
    activity?: ExecutionActivityCapabilities;
    /** Explicit adapter compatibility; does not install tools or grant model/environment access. */
    executionTools?: Array<{
        id: string;
        versions: string[];
        environments: ModelExecutionEnvironment['type'][];
    }>;
    /**
     * Recovery by host checkpoint, existing provider session, or none.
     * Session recovery does not guarantee survival of a worker crash.
     */
    recovery: 'checkpoint' | 'session' | 'none';
    interactions: boolean;
    /** Supports cancel requests; termination still requires provider confirmation. */
    cancellation: boolean;
    /** Work can continue after start() returns. */
    background: boolean;
    /** Omitted means unsupported. This declaration alone does not enable a host message API. */
    runningMessages?: boolean;
    /** A new invocation may reuse a prior session only through an explicitly supported adapter path. */
    sessionContinuation?: boolean;
}
/** Provider-neutral task payload; supported structured fields depend on the adapter. */
export interface AgentInvocationInput {
    prompt: string;
    /** No export by default; files/archive require an explicit delivery request. */
    delivery?: AgentOutputDelivery;
    parameters?: {
        [key: string]: AgentJson;
    };
    context?: {
        [key: string]: AgentJson;
    };
    /** Host-managed file references, authorized and materialized by the adapter. */
    files?: Array<{
        id: string;
        name?: string;
    }>;
}
/** Output or in-progress receipt. Check invocation status before treating it as final. */
export interface AgentInvocationResult {
    /** Optional reply content, preserved without imposing a report format; may be empty. */
    text: string;
    /** The reply exceeded the transport limit; no partial text is presented as complete evidence. */
    textTruncated?: boolean;
    /** Present only when a report file was explicitly selected. */
    report?: import('./results').AgentReportDelivery;
    deliveryHistory?: Array<{
        at: string;
        report?: import('./results').AgentReportDelivery;
        export?: AgentOutputExport;
    }>;
    /** Explicit adapter-normalized findings; display kind is never inferred from prose or titles. */
    items?: AgentResultItem[];
    /** Separate delivery outcome; task success does not imply that files were exported. */
    export?: AgentOutputExport;
    /** Adapter-defined structured output. */
    data?: AgentJson;
    /** Host-managed output references; normal artifact authorization applies. */
    artifacts?: AgentResultArtifact[];
}
/** Persisted provider receipt. Session/run IDs are distinct from the host invocation ID. */
export interface AgentRuntimeHandle {
    /** Optional host-managed process receipt; direct remote runtimes need only their session/run IDs. */
    runner?: AgentRunnerReceipt;
    sessionId: string;
    runId: string;
    metadata?: {
        [key: string]: AgentJson;
    };
}
/** Pending question or approval. Respond using its exact ID and provider-defined data schema. */
export interface AgentInteraction {
    id: string;
    kind: 'approval' | 'input';
    prompt: string;
    data?: AgentJson;
}
/**
 * Partial provider observation; omitted fields may retain previously stored values.
 * The host manages identity, revisions and persistence.
 */
export interface AgentRuntimeObservation {
    /** Distinct from request acceptance. The host validates source, capability and exact operation identity. */
    controlEvidence?: ExecutionControlEvidence;
    /** succeeded requires a result, even for structured-only output. */
    status: AgentInvocationStatus;
    handle?: AgentRuntimeHandle;
    result?: AgentInvocationResult;
    interaction?: AgentInteraction;
    /** Reported work/activity only; it never confirms business acceptance. */
    progress?: AgentRuntimeProgress;
    /** Safe diagnostic message without credentials or raw provider payloads. */
    error?: string;
}
/** Request pinned by the host before dispatch. */
export interface AgentInvocationRequest {
    target: AgentTarget;
    /**
     * Idempotency key within the captured scope (max 1024 characters).
     * Reuse for the same request; changed input or target is a conflict.
     */
    callId: string;
    input: AgentInvocationInput;
    /** Optional host-owned asynchronous reply and project association; not supplied by the execution Agent. */
    dispatch?: AgentInvocationDispatchContext;
}
/** Host supervisor causes; provider observations cannot replace a pending termination. */
export type AgentRunnerTerminationReason = 'authorization_revoked' | 'lease_expired' | 'runner_unavailable';
/** Host-owned invocation snapshot; not an update DTO. */
export interface AgentInvocation extends AgentRuntimeObservation {
    /** Durable host stop intent. Only matching descendant-exit evidence can settle this execution. */
    runnerTermination?: {
        reason: AgentRunnerTerminationReason;
        requestedAt: string;
    };
    /** Persisted business outcome awaiting independent process completion evidence. */
    reportedOutcome?: 'succeeded' | 'failed' | 'cancelled';
    /** Pinned at admission; plugins cannot replace the original host or execution generation. */
    executionTarget?: import('@xpert-ai/contracts').ExecutionRuntimeTarget;
    completionEvidence?: 1 | 2;
    /** Host-only durable response delivery. An ambiguous claimed response is never resent. */
    hostResponse?: {
        interactionId: string;
        response: AgentJson;
        claimed: boolean;
    };
    /** Host-assigned control adapter, independent of provider names or task labels. */
    controlAdapter?: 'native-assistant-task' | 'native-graph';
    /** Host control survives a missing handle and cannot be cleared by provider progress. */
    control?: {
        intent: 'terminated';
        requestedAt: string;
        deliveryToken?: string;
        deliveryUntil?: string;
        attempted?: boolean;
    };
    /** Pinned presentation contract remains readable after the runtime plugin is removed. */
    activity?: ExecutionActivityCapabilities;
    /** Host startup fence; intermediate receipts are not inspected until start returns or this deadline expires. */
    startPendingUntil?: string;
    /** Host-only startup owner; a stale heartbeat cannot renew another launch. */
    startPendingId?: string;
    /** Host invocation ID used by inspect, cancel and respond. */
    id: string;
    /** Host-managed concurrency revision, distinct from the target version. */
    revision: number;
    scope: AgentInvocationScope;
    request: AgentInvocationRequest;
    /** Host timestamps in ISO 8601 format. */
    createdAt: string;
    updatedAt: string;
}
/** Checks confirmed completion; unknown remains non-terminal. */
export declare function isAgentInvocationTerminal(status: AgentInvocationStatus): boolean;
