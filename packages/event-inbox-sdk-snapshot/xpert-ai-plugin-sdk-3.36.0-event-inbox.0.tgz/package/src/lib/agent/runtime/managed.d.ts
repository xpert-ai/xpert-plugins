import { z } from 'zod/v3';
/** Adapter declarations are discoverability metadata, never an execution grant. */
export interface ManagedAgentRuntimeProfile {
    reference: string;
    version: string;
    title: string;
    toolName: string;
    description: string;
    environment: 'computer' | 'process' | 'sdk' | 'service';
}
export interface ManagedAgentRuntimeSelection {
    provider: string;
    reference: string;
}
export interface ManagedAgentRuntimeOption extends ManagedAgentRuntimeSelection {
    title: string;
    toolName: string;
    description: string;
}
/** Persisted host ownership marker. Only built-in presets are supported. */
export declare const managedAgentRuntimeSchema: z.ZodObject<{
    type: z.ZodLiteral<"builtin">;
    version: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "builtin";
    version?: string;
}, {
    type?: "builtin";
    version?: string;
}>;
/** Launch settings supplied by the installed strategy, never by tool input or host provider lists. */
export declare const agentRuntimeDeploymentSpecSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"process">;
    command: z.ZodEffects<z.ZodString, string, string>;
    args: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
    environment: z.ZodRecord<z.ZodString, z.ZodString>;
    model: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    type?: "process";
    command?: string;
    timeoutMs?: number;
    model?: string;
    args?: string[];
    environment?: Record<string, string>;
}, {
    type?: "process";
    command?: string;
    timeoutMs?: number;
    model?: string;
    args?: string[];
    environment?: Record<string, string>;
}>, z.ZodObject<{
    type: z.ZodLiteral<"sdk">;
    environment: z.ZodRecord<z.ZodString, z.ZodString>;
    model: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    type?: "sdk";
    timeoutMs?: number;
    model?: string;
    environment?: Record<string, string>;
}, {
    type?: "sdk";
    timeoutMs?: number;
    model?: string;
    environment?: Record<string, string>;
}>, z.ZodObject<{
    type: z.ZodLiteral<"service">;
    serverUrl: z.ZodEffects<z.ZodString, string, string>;
    authorization: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    type?: "service";
    timeoutMs?: number;
    authorization?: string;
    serverUrl?: string;
}, {
    type?: "service";
    timeoutMs?: number;
    authorization?: string;
    serverUrl?: string;
}>]>;
export type AgentRuntimeDeploymentSpec = z.infer<typeof agentRuntimeDeploymentSpecSchema>;
/** Ephemeral launch settings scoped by the host. Only the fingerprint enters persisted targets. */
export type AgentRuntimeDeployment = AgentRuntimeDeploymentSpec & {
    provider: string;
    revision: string;
    workspaceRoot: string;
};
/** Used by SDK/process/service adapters. The host pins the target and rechecks access; no caller-selected scope. */
export declare const AgentRuntimeDeploymentCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<{
    resolve(): Promise<AgentRuntimeDeployment>;
}>;
