export declare const AGENT_PROCESS_SUPERVISOR: string;
