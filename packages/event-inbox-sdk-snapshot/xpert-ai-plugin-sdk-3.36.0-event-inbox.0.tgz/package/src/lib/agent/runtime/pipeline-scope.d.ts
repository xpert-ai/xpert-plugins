import { z } from 'zod/v3';
/** Host-only provenance. This describes a saved operation; it never grants access by itself. */
export declare const projectPipelineInvocationScopeSchema: z.ZodEffects<z.ZodObject<{
    tenantId: z.ZodString;
    organizationId: z.ZodString;
    userId: z.ZodString;
    projectId: z.ZodString;
    workspaceId: z.ZodString;
    callerType: z.ZodLiteral<"project_pipeline">;
    callerAgentKey: z.ZodLiteral<"pipeline_node">;
    parentExecutionId: z.ZodString;
    pipelineOrigin: z.ZodObject<{
        instanceId: z.ZodString;
        runId: z.ZodString;
        roundId: z.ZodString;
        nodeInstanceId: z.ZodString;
        operationId: z.ZodString;
        inputDigest: z.ZodString;
        generation: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    }, {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    }>;
}, "strict", z.ZodTypeAny, {
    projectId?: string;
    userId?: string;
    organizationId?: string;
    tenantId?: string;
    workspaceId?: string;
    callerType?: "project_pipeline";
    callerAgentKey?: "pipeline_node";
    parentExecutionId?: string;
    pipelineOrigin?: {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
}, {
    projectId?: string;
    userId?: string;
    organizationId?: string;
    tenantId?: string;
    workspaceId?: string;
    callerType?: "project_pipeline";
    callerAgentKey?: "pipeline_node";
    parentExecutionId?: string;
    pipelineOrigin?: {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
}>, {
    projectId?: string;
    userId?: string;
    organizationId?: string;
    tenantId?: string;
    workspaceId?: string;
    callerType?: "project_pipeline";
    callerAgentKey?: "pipeline_node";
    parentExecutionId?: string;
    pipelineOrigin?: {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
}, {
    projectId?: string;
    userId?: string;
    organizationId?: string;
    tenantId?: string;
    workspaceId?: string;
    callerType?: "project_pipeline";
    callerAgentKey?: "pipeline_node";
    parentExecutionId?: string;
    pipelineOrigin?: {
        operationId: string;
        instanceId: string;
        runId: string;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
}>;
export type ProjectPipelineInvocationScope = z.output<typeof projectPipelineInvocationScopeSchema>;
