import { z } from 'zod/v3';
import { type AgentOutputDelivery } from '@xpert-ai/contracts';
/** Opt in to the host's authorized, on-demand result View from middleware metadata. */
export declare const AGENT_TASK_RESULTS_FEATURE = "agent_task_results";
export { agentResultPathSchema, agentOutputDeliverySchema, agentDeliveryRecoverySchema, type AgentDeliveryRecovery, type AgentOutputDelivery } from '@xpert-ai/contracts';
/** Machine-readable result kind; file declarations are not committed artifacts or download grants. */
export declare const agentResultItemSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"analysis">;
    id: z.ZodString;
    title: z.ZodString;
    summary: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "analysis";
    id?: string;
    title?: string;
    summary?: string;
}, {
    type?: "analysis";
    id?: string;
    title?: string;
    summary?: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"changes">;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodEffects<z.ZodString, string, string>;
        change: z.ZodEnum<["created", "modified", "deleted"]>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        change?: "created" | "modified" | "deleted";
    }, {
        path?: string;
        change?: "created" | "modified" | "deleted";
    }>, "many">;
    id: z.ZodString;
    title: z.ZodString;
    summary: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "changes";
    id?: string;
    title?: string;
    summary?: string;
    files?: {
        path?: string;
        change?: "created" | "modified" | "deleted";
    }[];
}, {
    type?: "changes";
    id?: string;
    title?: string;
    summary?: string;
    files?: {
        path?: string;
        change?: "created" | "modified" | "deleted";
    }[];
}>, z.ZodObject<{
    type: z.ZodLiteral<"tests">;
    status: z.ZodEnum<["passed", "failed", "skipped"]>;
    command: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    title: z.ZodString;
    summary: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "tests";
    status?: "passed" | "failed" | "skipped";
    id?: string;
    title?: string;
    summary?: string;
    command?: string;
}, {
    type?: "tests";
    status?: "passed" | "failed" | "skipped";
    id?: string;
    title?: string;
    summary?: string;
    command?: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"file">;
    path: z.ZodEffects<z.ZodString, string, string>;
    id: z.ZodString;
    title: z.ZodString;
    summary: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "file";
    path?: string;
    id?: string;
    title?: string;
    summary?: string;
}, {
    type?: "file";
    path?: string;
    id?: string;
    title?: string;
    summary?: string;
}>]>;
export type AgentResultItem = z.output<typeof agentResultItemSchema>;
/** Report bytes are transported independently of artifact quotas and business acceptance. */
export declare const AGENT_TASK_REPORT_MAX_BYTES: number;
export type AgentTaskReport = {
    text: string;
    sha256: string;
};
export type AgentReportDelivery = {
    status: 'completed';
    sha256: string;
    path?: string;
} | {
    status: 'failed';
    code: 'report_unavailable' | 'report_empty' | 'report_too_large';
    path?: string;
};
/** Persist only after the platform has committed the artifact; never accept an ID invented by a model. */
export interface AgentResultArtifact {
    id: string;
    name?: string;
    mimeType?: string;
    /** Required for downloads; optional only to read older task records without changing their meaning. */
    versionId?: string;
    /** Item paths included in this immutable artifact. */
    paths?: string[];
}
export interface AgentArtifactSelection {
    mode: 'files' | 'archive';
    /** Exact relative files; the runner still enforces filesystem and delivery authorization. */
    paths: string[];
}
/** Export outcome is independent of task success, so an export error cannot hide completed work. */
export interface AgentOutputExport {
    mode: AgentOutputDelivery['mode'];
    status: 'not_requested' | 'completed' | 'failed' | 'unavailable';
    /** Safe diagnostic only; execution status is independent of export status. */
    error?: string;
}
