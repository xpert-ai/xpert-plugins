import { z } from 'zod/v3';
export declare const agentRuntimeReplyTargetSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodOptional<z.ZodLiteral<"xpert">>;
    xpertId: z.ZodString;
    agentKey: z.ZodString;
    conversationId: z.ZodString;
    threadId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "xpert";
    threadId?: string;
    conversationId?: string;
    xpertId?: string;
    agentKey?: string;
}, {
    type?: "xpert";
    threadId?: string;
    conversationId?: string;
    xpertId?: string;
    agentKey?: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"project_agent">;
    projectId: z.ZodString;
    agentKey: z.ZodLiteral<"general_agent">;
    conversationId: z.ZodString;
    threadId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "project_agent";
    projectId?: string;
    threadId?: string;
    conversationId?: string;
    agentKey?: "general_agent";
}, {
    type?: "project_agent";
    projectId?: string;
    threadId?: string;
    conversationId?: string;
    agentKey?: "general_agent";
}>]>;
export type AgentRuntimeReplyTarget = z.output<typeof agentRuntimeReplyTargetSchema>;
/** Persist with the immutable invocation request before launch. No credentials or arbitrary routing headers. */
export declare const agentInvocationDispatchContextSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    requestId: z.ZodString;
    sourceMessageId: z.ZodString;
    replyTo: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodOptional<z.ZodLiteral<"xpert">>;
        xpertId: z.ZodString;
        agentKey: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    }, {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"project_agent">;
        projectId: z.ZodString;
        agentKey: z.ZodLiteral<"general_agent">;
        conversationId: z.ZodString;
        threadId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    }, {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    }>]>;
    projectTask: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        projectId: z.ZodString;
        projectTaskId: z.ZodString;
        taskExecutionId: z.ZodString;
    } & {
        specification: z.ZodObject<{
            digest: z.ZodString;
            specification: z.ZodEffects<z.ZodObject<{
                version: z.ZodLiteral<1>;
                title: z.ZodString;
                description: z.ZodOptional<z.ZodString>;
                requirements: z.ZodArray<z.ZodString, "many">;
                steps: z.ZodArray<z.ZodObject<{
                    stepIndex: z.ZodNumber;
                    description: z.ZodString;
                }, "strict", z.ZodTypeAny, {
                    description: string;
                    stepIndex: number;
                }, {
                    description: string;
                    stepIndex: number;
                }>, "many">;
            }, "strict", z.ZodTypeAny, {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            }, {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            }>, {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            }, {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            }>;
        }, "strict", z.ZodTypeAny, {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        }, {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        }>;
        purpose: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"implementation">;
            reviewer: z.ZodOptional<z.ZodObject<{
                bindingId: z.ZodString;
                mode: z.ZodEnum<["evidence_only", "execution"]>;
            }, "strict", z.ZodTypeAny, {
                mode: "execution" | "evidence_only";
                bindingId: string;
            }, {
                mode: "execution" | "evidence_only";
                bindingId: string;
            }>>;
            coordination: z.ZodOptional<z.ZodObject<{
                taskId: z.ZodString;
                specificationDigest: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                taskId: string;
                specificationDigest: string;
            }, {
                taskId: string;
                specificationDigest: string;
            }>>;
            rework: z.ZodOptional<z.ZodObject<{
                reviewExecutionId: z.ZodString;
                feedback: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                reviewExecutionId: string;
                feedback: string;
            }, {
                reviewExecutionId: string;
                feedback: string;
            }>>;
        }, "strict", z.ZodTypeAny, {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        }, {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"review">;
            mode: z.ZodOptional<z.ZodEnum<["evidence_only", "execution"]>>;
            candidatePaths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
            implementationExecutionId: z.ZodString;
            implementationTaskId: z.ZodOptional<z.ZodString>;
            implementationInvocationId: z.ZodString;
            specificationDigest: z.ZodString;
            evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
                type: z.ZodLiteral<"artifact">;
                artifactId: z.ZodString;
                versionId: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                type: "artifact";
                artifactId: string;
                versionId: string;
            }, {
                type: "artifact";
                artifactId: string;
                versionId: string;
            }>, z.ZodObject<{
                type: z.ZodLiteral<"invocation_result">;
                invocationId: z.ZodString;
                revision: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            }, {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            }>, z.ZodObject<{
                type: z.ZodLiteral<"workspace_snapshot">;
                snapshotId: z.ZodString;
                digest: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            }, {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            }>]>, "many">;
        }, "strict", z.ZodTypeAny, {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        }, {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        }>]>, {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        }, {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    }, {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    }>, {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    }, {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    requestId?: string;
    sourceMessageId?: string;
    replyTo?: {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    } | {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    };
    projectTask?: {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    };
}, {
    version?: 1;
    requestId?: string;
    sourceMessageId?: string;
    replyTo?: {
        type?: "xpert";
        threadId?: string;
        conversationId?: string;
        xpertId?: string;
        agentKey?: string;
    } | {
        type?: "project_agent";
        projectId?: string;
        threadId?: string;
        conversationId?: string;
        agentKey?: "general_agent";
    };
    projectTask?: {
        purpose: {
            type: "implementation";
            reviewer?: {
                mode: "execution" | "evidence_only";
                bindingId: string;
            } | undefined;
            coordination?: {
                taskId: string;
                specificationDigest: string;
            } | undefined;
            rework?: {
                reviewExecutionId: string;
                feedback: string;
            } | undefined;
        } | {
            type: "review";
            evidence: ({
                type: "artifact";
                artifactId: string;
                versionId: string;
            } | {
                type: "invocation_result";
                revision: number;
                invocationId: string;
            } | {
                type: "workspace_snapshot";
                digest: string;
                snapshotId: string;
            })[];
            implementationExecutionId: string;
            specificationDigest: string;
            implementationInvocationId: string;
            mode?: "execution" | "evidence_only" | undefined;
            implementationTaskId?: string | undefined;
            candidatePaths?: string[] | undefined;
        };
        projectId: string;
        specification: {
            digest: string;
            specification: {
                title: string;
                version: 1;
                steps: {
                    description: string;
                    stepIndex: number;
                }[];
                requirements: string[];
                description?: string | undefined;
            };
        };
        projectTaskId: string;
        taskExecutionId: string;
    };
}>;
export type AgentInvocationDispatchContext = z.output<typeof agentInvocationDispatchContextSchema>;
