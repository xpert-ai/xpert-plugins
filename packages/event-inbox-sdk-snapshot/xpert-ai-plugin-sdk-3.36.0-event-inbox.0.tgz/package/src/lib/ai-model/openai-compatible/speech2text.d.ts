import { CallbackManagerForLLMRun } from '@langchain/core/callbacks/manager';
import { BaseChatModel, BaseChatModelParams } from '@langchain/core/language_models/chat_models';
import { BaseMessage } from '@langchain/core/messages';
import { ChatResult } from '@langchain/core/outputs';
export interface ChatSpeech2TextInput extends BaseChatModelParams {
    /**
     */
    apiKey?: string;
    model: string;
}
export declare class Speech2TextChatModel extends BaseChatModel {
    private fields?;
    _llmType(): string;
    protected apiKey: string;
    constructor(fields?: Partial<ChatSpeech2TextInput>);
    _generate(messages: BaseMessage[], options: this['ParsedCallOptions'], runManager?: CallbackManagerForLLMRun): Promise<ChatResult>;
}
