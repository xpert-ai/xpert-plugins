import { OpenAIEmbeddings } from '@langchain/openai';
import type { TChatModelOptions } from '../types/model';
/** OpenAI-compatible embeddings with authoritative, per-request usage callbacks. */
export declare class OpenAICompatibleEmbeddings extends OpenAIEmbeddings {
    private readonly usageCallbacks?;
    constructor(input: ConstructorParameters<typeof OpenAIEmbeddings>[0], usageCallbacks?: Pick<TChatModelOptions, 'handleModelUsage' | 'resolveUsagePricingSnapshot'>);
    protected embeddingWithRetry(request: Parameters<OpenAIEmbeddings['embeddingWithRetry']>[0]): ReturnType<OpenAIEmbeddings['embeddingWithRetry']>;
}
