import { ChatOpenAICompletions, ChatOpenAIFields, ClientOptions, OpenAIClient } from '@langchain/openai';
export type TOAIAPICompatLLMParams = ChatOpenAIFields & {
    configuration: ClientOptions;
};
/**
 * A model extended from ChatOpenAICompletions, compatible with OpenAI-style chat completions,
 * and supports structuring content within `<think>` reasoning tags into the `reasoning_content` field.
 *
 * This class overrides the `_convertCompletionsDeltaToBaseMessageChunk` method to detect `<think>` and `</think>` tags in the completion stream:
 * - When `<think>` is encountered, it enters reasoning content collection mode. Subsequent content is collected into the `reasoning_content` field and does not appear in the main `content` field.
 * - When `</think>` is encountered, reasoning content collection ends.
 * - In other cases, the `reasoning_content` field is directly assigned from the `reasoning_content` in the delta.
 *
 * In this way, the reasoning process in the model output can be separated from the main content, making it easier for subsequent structured processing and display.
 */
export declare class ChatOAICompatReasoningModel extends ChatOpenAICompletions {
    private thinking;
    /**
     *
     */
    protected _convertCompletionsDeltaToBaseMessageChunk(delta: Record<string, any>, rawResponse: OpenAIClient.ChatCompletionChunk, defaultRole?: 'function' | 'user' | 'system' | 'developer' | 'assistant' | 'tool'): import("@langchain/core/messages").AIMessageChunk | import("@langchain/core/messages").HumanMessageChunk | import("@langchain/core/messages").SystemMessageChunk | import("@langchain/core/messages").FunctionMessageChunk | import("@langchain/core/messages").ToolMessageChunk | import("@langchain/core/messages").ChatMessageChunk;
    protected _convertCompletionsMessageToBaseMessage(message: OpenAIClient.ChatCompletionMessage, rawResponse: OpenAIClient.ChatCompletion): import("@langchain/core/messages").BaseMessage;
}
