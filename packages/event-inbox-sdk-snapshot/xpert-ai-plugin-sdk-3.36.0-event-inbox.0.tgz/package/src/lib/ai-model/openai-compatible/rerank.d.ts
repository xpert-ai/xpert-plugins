import { Document } from '@langchain/core/documents';
import { IRerank, RerankResult } from '../types';
export declare class OpenAICompatibleReranker implements IRerank {
    credentials: {
        endpointUrl: string;
        apiKey: string;
        endpointModelName?: string;
    };
    constructor(credentials: {
        endpointUrl: string;
        apiKey: string;
        endpointModelName?: string;
    });
    rerank(docs: Document<Record<string, any>>[], query: string, options: {
        topN?: number;
        scoreThreshold?: number;
        model: string;
        returnDocuments?: boolean;
    }): Promise<RerankResult[]>;
}
