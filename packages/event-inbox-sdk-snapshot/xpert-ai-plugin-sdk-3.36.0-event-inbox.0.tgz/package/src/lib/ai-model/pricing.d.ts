import { type LLMPriceCalculation, type LLMPriceContext, type ModelUsagePricingSnapshot, type ModelUsageMetric, type ModelUsagePriceRule, type ModelUsagePricingConfig, type ModelUsagePricingContext, type ModelUsagePricingStatus, PriceConfig, PriceInfo, PriceType, type TTokenUsage } from '@xpert-ai/contracts';
export declare function calculateModelPrice(pricing: PriceConfig, priceType: PriceType, tokens: number, inputTokens?: number): PriceInfo;
export declare function calculateLLMUsagePrice(pricing: PriceConfig, usage: TTokenUsage, context?: LLMPriceContext): LLMPriceCalculation;
export type ModelUsageChargeCalculation = {
    pricingStatus: ModelUsagePricingStatus;
    pricingRule?: ModelUsagePriceRule;
    quantity: number;
    unitSize?: number;
    unitPrice?: number;
    currency?: string;
    amount?: number;
};
export declare function resolveModelUsagePricingSnapshot(pricing: PriceConfig | ModelUsagePricingConfig | undefined, context: ModelUsagePricingContext): ModelUsagePricingSnapshot;
export declare function calculateModelUsageCharge(snapshot: ModelUsagePricingSnapshot | null | undefined, metric: ModelUsageMetric): ModelUsageChargeCalculation;
export declare function isModelUsagePricingConfig(pricing: PriceConfig | ModelUsagePricingConfig | undefined): pricing is ModelUsagePricingConfig;
