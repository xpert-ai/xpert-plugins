export declare const AI_MODEL_PROVIDER = "AI_MODEL_PROVIDER";
export declare function AIModelProviderStrategy(provider: string): (target: any) => void;
