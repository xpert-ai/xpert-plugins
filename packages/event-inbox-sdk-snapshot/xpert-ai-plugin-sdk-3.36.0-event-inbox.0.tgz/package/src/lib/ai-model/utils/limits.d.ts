import { BaseLanguageModel } from '@langchain/core/language_models/base';
import { ICopilotModel } from '@xpert-ai/contracts';
export declare function getModelContextSize(input: BaseLanguageModel | ICopilotModel): number | undefined;
/** Bind the effective window to the runtime configuration and client without guessing from model names. */
export declare function applyModelContextSize<T extends object>(model: T, configuration: ICopilotModel): T;
export declare function normalizeContextSize(value: unknown): number | undefined;
