import type { TiktokenEncoding } from 'js-tiktoken';
export declare function countTextTokens(text: string): number;
/** Token boundaries that also end on complete Unicode characters, in UTF-16 source offsets. */
export declare function textTokenBoundaries(text: string): {
    offset: number;
    tokens: number;
}[];
/**
 * Count tokens in text
 * 1) Preferred: js-tiktoken precise encoding
 * 2) Fallback: estimated token count
 */
export declare function countTokensSafe(text: string, opts?: {
    model?: string;
    encodingName?: TiktokenEncoding | string;
}): number;
