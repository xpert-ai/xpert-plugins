import { BaseChatModel } from '@langchain/core/language_models/chat_models';
import { AIModelEntity, ICopilot, ICopilotModel, ILLMUsage, ModelUsageReport, ModelUsagePricingContext, ModelUsagePricingSnapshot, ParameterRule, ParameterType, PriceInfo, PriceType } from '@xpert-ai/contracts';
export type TModelUsageType = 'estimated';
export type TLLMUsage = ILLMUsage & {
    type?: TModelUsageType;
};
export type TChatModelOptions = {
    modelProperties: Record<string, any>;
    /** Final authoritative usage for non-LLM model clients. */
    handleModelUsage?: (report: ModelUsageReport) => void | Promise<void>;
    /** Freeze the active usage price rules at invocation start. */
    resolveUsagePricingSnapshot?: (context: ModelUsagePricingContext) => ModelUsagePricingSnapshot | Promise<ModelUsagePricingSnapshot>;
    handleLLMTokens: (input: {
        copilot: ICopilot;
        model?: string;
        requestId?: string;
        usage?: TLLMUsage;
        /**
         * @deprecated use usage
         */
        tokenUsed?: number;
    }) => void | Promise<void>;
    verbose: boolean;
};
export interface IAIModel {
    validateCredentials(model: string, credentials: Record<string, any>): Promise<void>;
    getChatModel(copilotModel: ICopilotModel, options?: TChatModelOptions): BaseChatModel;
    predefinedModels(): AIModelEntity[];
    getParameterRules(model: string, credentials: Record<string, string>): ParameterRule[];
    getUsagePricingSnapshot(model: string, credentials: Record<string, any>, context: ModelUsagePricingContext): ModelUsagePricingSnapshot;
    getPrice(model: string, credentials: Record<string, any>, priceType: PriceType, tokens: number, inputTokens?: number): PriceInfo;
}
export declare const CommonParameterRules: {
    name: string;
    label: {
        zh_Hans: string;
        en_US: string;
    };
    type: ParameterType;
    help: {
        zh_Hans: string;
        en_US: string;
    };
    required: boolean;
    default: number;
    min: number;
    max: number;
    precision: number;
}[];
export declare function mergeCredentials(credentials: any, modelProperties: any): any;
export type TModelProperties = {
    endpoint_url: string;
    api_key: string;
    endpoint_model_name?: string;
};
