import { ParameterRule } from '@xpert-ai/contracts';
import { AIModel } from '../ai-model';
export declare abstract class TextToSpeechModel extends AIModel {
    getParameterRules(model: string, credentials: Record<string, string>): ParameterRule[];
}
