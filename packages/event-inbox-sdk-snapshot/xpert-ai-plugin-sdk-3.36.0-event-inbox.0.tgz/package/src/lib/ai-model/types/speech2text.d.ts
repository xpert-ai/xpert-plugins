import { AIModel } from "../ai-model";
export declare abstract class SpeechToTextModel extends AIModel {
}
