import { type IModelAccessResolution, type ModelUsageModality, type ModelUsageOperation, type ModelUsagePricingDimensions, type ModelUsagePricingSnapshot } from '@xpert-ai/contracts';
import type { AgentMiddlewareModelProviderConnection } from '../agent/middleware/runtime';
import type { ManagedQueueJob } from '../managed-queue';
import type { AIGCModelObservation, AsyncAIGCModelClient } from './types/aigc';
export type AsyncAIGCManagedJobPhase = 'queued' | 'submitted' | 'processing' | 'succeeded' | 'failed';
/** Durable provider checkpoint stored inside the Managed Queue payload. */
export type AsyncAIGCManagedJobPayload<TInput, TResult> = {
    requestId: string;
    model: string;
    toolName: string;
    modality: ModelUsageModality;
    operation: ModelUsageOperation;
    pricingDimensions?: ModelUsagePricingDimensions;
    input: TInput;
    phase: AsyncAIGCManagedJobPhase;
    startedAt: string;
    providerRequestId?: string;
    providerState?: AIGCModelObservation['state'];
    modelAccess?: IModelAccessResolution;
    pricingSnapshot?: ModelUsagePricingSnapshot;
    usageReported?: boolean;
    result?: TResult;
    errorCode?: string;
};
export type ProcessAsyncAIGCManagedJobOptions<TInput, TData, TResult> = {
    client: AsyncAIGCModelClient<TInput, TData>;
    provider: AgentMiddlewareModelProviderConnection;
    pollIntervalMs?: number;
    sleep?: (milliseconds: number) => Promise<void>;
    finalize(data: TData): Promise<TResult>;
    failureMessage?(data: TData, observation: AIGCModelObservation): string;
};
/**
 * Runs one asynchronous provider request inside a Managed Queue job.
 * Provider acceptance, terminal usage reporting, and result delivery are checkpointed so a queue retry resumes
 * from the last durable provider request instead of intentionally submitting a second request.
 */
export declare function processAsyncAIGCManagedJob<TInput, TData, TResult>(job: ManagedQueueJob<AsyncAIGCManagedJobPayload<TInput, TResult>>, options: ProcessAsyncAIGCManagedJobOptions<TInput, TData, TResult>): Promise<TResult>;
