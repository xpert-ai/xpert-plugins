import { AIModelEntity, DiscoveredModel } from '@xpert-ai/contracts';
export type OpenAIModelDiscoveryOptions = {
    baseUrl: string;
    authorization: string;
    path?: string;
    predefinedModels?: readonly AIModelEntity[];
    fetchImpl?: typeof fetch;
};
/** OpenAI-compatible discovery transport and import suggestions, never runtime routing. */
export declare function discoverOpenAIModels(options: OpenAIModelDiscoveryOptions): Promise<DiscoveredModel[]>;
export { configurationFromModel } from '@xpert-ai/contracts';
