import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { IAIModelProviderStrategy } from './ai-model-provider.interface';
export declare class AIModelProviderRegistry extends BaseStrategyRegistry<IAIModelProviderStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
