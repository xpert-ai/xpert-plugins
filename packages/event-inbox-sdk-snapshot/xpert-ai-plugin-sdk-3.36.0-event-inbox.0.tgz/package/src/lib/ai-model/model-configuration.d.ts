import { AIModelEntity, ModelConfiguration } from '@xpert-ai/contracts';
/** Apply an explicit saved configuration without mutating a shared predefined schema. */
export declare function applyModelConfiguration(model: string, configuration: ModelConfiguration, schema?: AIModelEntity | null): AIModelEntity;
