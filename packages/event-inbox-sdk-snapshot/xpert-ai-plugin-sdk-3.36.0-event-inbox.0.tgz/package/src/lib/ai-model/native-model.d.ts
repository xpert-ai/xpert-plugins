import type { ICopilotModel, ILLMUsage, LLMPriceContext, ModelExecutionProtocol, TTokenUsage } from '@xpert-ai/contracts';
export type NativeModelProtocol = Extract<ModelExecutionProtocol, 'openai_responses' | 'anthropic_messages'>;
export type NativeModelJson = null | boolean | number | string | NativeModelJson[] | {
    [key: string]: NativeModelJson;
};
export type NativeModelBody = {
    [key: string]: NativeModelJson;
};
/** Server-only capability. Provider credentials and configured upstream URLs never leave this closure. */
export interface NativeModelClient {
    readonly protocol: NativeModelProtocol;
    generate(body: NativeModelBody, headers: Readonly<Record<string, string>>, signal: AbortSignal): Promise<Response>;
    priceUsage(usage: TTokenUsage, context?: LLMPriceContext): ILLMUsage;
}
export type NativeModelClientFactory = (protocol: NativeModelProtocol, model: ICopilotModel, 
/** Host-resolved custom model settings, including credentials; never serialized into a grant. */
options?: {
    modelProperties?: Record<string, unknown>;
}) => Promise<NativeModelClient>;
/** A single fetch is one billable attempt. No SDK retries or redirects to another credential origin. */
export declare function nativeModelTransport(input: {
    protocol: NativeModelProtocol;
    baseUrl: string;
    authorization: string;
    fetch?: typeof fetch;
}): NativeModelClient['generate'];
