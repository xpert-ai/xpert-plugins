import { ICopilotModel } from '@xpert-ai/contracts';
import { Command } from '@nestjs/cqrs';
import { AgentMiddlewareCreateModelClientOptions, AgentMiddlewareModelClient } from '../../agent/middleware/runtime';
/**
 * Get a Chat Model of copilot model and check it's token limitation, record the token usage
 *
 * @deprecated Prefer `IAgentMiddlewareContext.runtime.createModelClient(...)` in middleware and plugin code.
 */
export declare class CreateModelClientCommand<T = AgentMiddlewareModelClient> extends Command<T> {
    readonly copilotModel: ICopilotModel;
    readonly options: AgentMiddlewareCreateModelClientOptions;
    static readonly type = "[AI Model] Create Model Client";
    constructor(copilotModel: ICopilotModel, options: AgentMiddlewareCreateModelClientOptions);
}
