import { AIModelEntity, ICopilot, ILLMUsage, LLMPriceContext, LLMReportedPrice, ParameterRule, TTokenUsage } from '@xpert-ai/contracts';
import { Logger } from '@nestjs/common';
import { BaseCallbackHandler } from '@langchain/core/callbacks/base';
import { LLMResult } from '@langchain/core/outputs';
import { AIModel } from './ai-model';
import { TChatModelOptions } from './types/';
export type CommonChatModelParameters = {
    temperature: number;
    maxRetries?: number | null;
};
export type LLMUsagePricingOptions = {
    context?: LLMPriceContext;
    resolveContext?: (output: LLMResult) => LLMPriceContext;
    resolveReportedPrice?: (output: LLMResult) => LLMReportedPrice | undefined;
    reportedPriceRequired?: boolean;
};
export type LLMUsagePricingConfiguration = LLMPriceContext | LLMUsagePricingOptions;
export declare class LLMUsage implements ILLMUsage {
    /**
     * Model class for llm usage.
     */
    promptTokens: number;
    promptUnitPrice: number;
    promptPriceUnit: number;
    promptPrice: number;
    completionTokens: number;
    completionUnitPrice: number;
    completionPriceUnit: number;
    completionPrice: number;
    totalTokens: number;
    totalPrice: number;
    currency: string;
    latency: number;
    constructor(promptTokens: number, promptUnitPrice: number, promptPriceUnit: number, promptPrice: number, completionTokens: number, completionUnitPrice: number, completionPriceUnit: number, completionPrice: number, totalTokens: number, totalPrice: number, currency: string, latency: number);
    static emptyUsage(): LLMUsage;
    plus(other: LLMUsage): LLMUsage;
    add(other: LLMUsage): LLMUsage;
}
export declare abstract class LargeLanguageModel extends AIModel {
    #private;
    protected startedAt: DOMHighResTimeStamp;
    protected _commonParameterRules(model: string): ParameterRule[];
    /** Price already normalized provider facts without starting another inference or writing a ledger. */
    priceActualTokenUsage(model: string, tokenUsage: TTokenUsage, context?: LLMPriceContext): ILLMUsage;
    protected calcResponseUsage(model: string, credentials: Record<string, any>, promptTokens: number, completionTokens: number, startedAt?: number, tokenUsage?: TTokenUsage, pricingContext?: LLMPriceContext): ILLMUsage;
    createHandleUsageCallbacks(copilot: ICopilot, model: string, credentials: any, handleLLMTokens: TChatModelOptions['handleLLMTokens'], pricingConfiguration?: LLMUsagePricingConfiguration): {
        name: string;
        lc_serializable: boolean;
        readonly lc_namespace: ["langchain_core", "callbacks", string];
        readonly lc_secrets: {
            [key: string]: string;
        } | undefined;
        readonly lc_attributes: {
            [key: string]: string;
        } | undefined;
        readonly lc_aliases: {
            [key: string]: string;
        } | undefined;
        readonly lc_serializable_keys: string[] | undefined;
        readonly lc_id: string[];
        lc_kwargs: import("@langchain/core/dist/load/map_keys").SerializedFields;
        ignoreLLM: boolean;
        ignoreChain: boolean;
        ignoreAgent: boolean;
        ignoreRetriever: boolean;
        ignoreCustomEvent: boolean;
        raiseError: boolean;
        awaitHandlers: boolean;
        copy(): BaseCallbackHandler;
        toJSON(): import("@langchain/core/load/serializable").Serialized;
        toJSONNotImplemented(): import("@langchain/core/load/serializable").SerializedNotImplemented;
        handleLLMStart?(llm: import("@langchain/core/load/serializable").Serialized, prompts: string[], runId: string, parentRunId?: string, extraParams?: Record<string, unknown>, tags?: string[], metadata?: Record<string, unknown>, runName?: string): Promise<any> | any;
        handleLLMNewToken?(token: string, idx: import("@langchain/core/callbacks/base").NewTokenIndices, runId: string, parentRunId?: string, tags?: string[], fields?: import("@langchain/core/callbacks/base").HandleLLMNewTokenCallbackFields): Promise<any> | any;
        handleLLMError?(err: any, runId: string, parentRunId?: string, tags?: string[], extraParams?: Record<string, unknown>): Promise<any> | any;
        handleLLMEnd?(output: LLMResult, runId: string, parentRunId?: string, tags?: string[], extraParams?: Record<string, unknown>): Promise<any> | any;
        handleChatModelStart?(llm: import("@langchain/core/load/serializable").Serialized, messages: import("@langchain/core/messages").BaseMessage[][], runId: string, parentRunId?: string, extraParams?: Record<string, unknown>, tags?: string[], metadata?: Record<string, unknown>, runName?: string): Promise<any> | any;
        handleChainStart?(chain: import("@langchain/core/load/serializable").Serialized, inputs: import("@langchain/core/utils/types").ChainValues, runId: string, parentRunId?: string, tags?: string[], metadata?: Record<string, unknown>, runType?: string, runName?: string): Promise<any> | any;
        handleChainError?(err: any, runId: string, parentRunId?: string, tags?: string[], kwargs?: {
            inputs?: Record<string, unknown>;
        }): Promise<any> | any;
        handleChainEnd?(outputs: import("@langchain/core/utils/types").ChainValues, runId: string, parentRunId?: string, tags?: string[], kwargs?: {
            inputs?: Record<string, unknown>;
        }): Promise<any> | any;
        handleToolStart?(tool: import("@langchain/core/load/serializable").Serialized, input: string, runId: string, parentRunId?: string, tags?: string[], metadata?: Record<string, unknown>, runName?: string): Promise<any> | any;
        handleToolError?(err: any, runId: string, parentRunId?: string, tags?: string[]): Promise<any> | any;
        handleToolEnd?(output: any, runId: string, parentRunId?: string, tags?: string[]): Promise<any> | any;
        handleText?(text: string, runId: string, parentRunId?: string, tags?: string[]): Promise<void> | void;
        handleAgentAction?(action: import("@langchain/core/dist/agents").AgentAction, runId: string, parentRunId?: string, tags?: string[]): Promise<void> | void;
        handleAgentEnd?(action: import("@langchain/core/dist/agents").AgentFinish, runId: string, parentRunId?: string, tags?: string[]): Promise<void> | void;
        handleRetrieverStart?(retriever: import("@langchain/core/load/serializable").Serialized, query: string, runId: string, parentRunId?: string, tags?: string[], metadata?: Record<string, unknown>, name?: string): Promise<any> | any;
        handleRetrieverEnd?(documents: import("@langchain/core/documents").DocumentInterface[], runId: string, parentRunId?: string, tags?: string[]): Promise<any> | any;
        handleRetrieverError?(err: any, runId: string, parentRunId?: string, tags?: string[]): Promise<any> | any;
        handleCustomEvent?(eventName: string, data: any, runId: string, tags?: string[], metadata?: Record<string, any>): Promise<any> | any;
    }[];
    createHandleLLMErrorCallbacks(_fields: unknown, logger?: Logger): {
        handleLLMError: (error: unknown) => void;
    };
    protected getCustomizableModelSchemaFromCredentials(model: string, credentials: Record<string, any>): AIModelEntity | null;
    protected createHandleVerboseCallbacks(enabled?: boolean, logger?: Logger): {
        handleChatModelStart: (llm: any, messages: any, runId: any, parentRunId: any, extraParams: any, tags: any, metadata: any, runName: any) => void;
        handleLLMStart: (llm: any, prompts: any, runId: any, parentRunId: any, extraParams: any, tags: any, metadata: any, runName: any) => void;
        handleLLMEnd: (output: any, runId: any, parentRunId: any, tags: any, extraParams: any) => void;
        handleLLMError: (err: any, runId: any, parentRunId: any, tags: any, extraParams: any) => void;
    }[];
    private formatVerboseLog;
    private stringifyLogPayload;
    private formatError;
}
export declare function calcTokenUsage(output: LLMResult): TTokenUsage;
export declare function resolveTokenUsage(output: LLMResult): TTokenUsage;
/**
 * @deprecated use calcTokenUsage
 */
export declare function sumTokenUsage(output: LLMResult): number;
