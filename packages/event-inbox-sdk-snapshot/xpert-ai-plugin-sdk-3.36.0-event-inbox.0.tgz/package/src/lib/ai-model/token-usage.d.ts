import type { TTokenUsage } from '@xpert-ai/contracts';
export interface ResolvedTokenUsage {
    usage: TTokenUsage;
    source: 'provider' | 'estimated' | 'legacy' | 'unavailable';
}
/** Select a whole candidate. Never fill missing actual counts using estimates. */
export declare function resolveTokenUsageCandidates(input: {
    canonical?: Partial<TTokenUsage> | null;
    actual?: Partial<TTokenUsage> | null;
    estimated?: Partial<TTokenUsage> | null;
    legacyTotal?: number;
}): ResolvedTokenUsage;
export declare function normalizeTokenUsage(candidate?: Partial<TTokenUsage> | null): TTokenUsage | null;
