export type ModelProviderHttpClientOptions = {
    provider: string;
    baseUrl: string;
    defaultHeaders?: Readonly<Record<string, string>>;
    fetchImpl?: typeof fetch;
    requestTimeoutMs?: number;
};
export type ModelProviderBufferOptions = {
    maxBytes?: number;
    maxBytesError?: string;
    defaultMimeType?: string;
};
export type ModelProviderHttpResponse = {
    ok: boolean;
    status: number;
    statusText: string;
    headers: {
        get(name: string): string | null;
    };
    text(): Promise<string>;
    json(): Promise<unknown>;
    arrayBuffer(): Promise<ArrayBuffer>;
};
export declare class ModelProviderHttpError extends Error {
    readonly status: number;
    constructor(message: string, status: number);
}
/**
 * Shared HTTP transport for model Provider adapters.
 *
 * Provider-specific authentication headers are supplied at construction time;
 * response parsing, task semantics, and download URL policy stay in each adapter.
 */
export declare abstract class ModelProviderHttpClient {
    protected readonly baseUrl: string;
    private readonly provider;
    private readonly defaultHeaders;
    private readonly fetchImpl;
    private readonly requestTimeoutMs?;
    protected constructor(options: ModelProviderHttpClientOptions);
    protected requestJson<T>(pathOrUrl: string, init: RequestInit, parse: (value: unknown) => T): Promise<T>;
    protected fetchResponse(input: string | URL, init?: RequestInit, timeoutMs?: number): Promise<ModelProviderHttpResponse>;
    protected readBufferResponse(response: ModelProviderHttpResponse, options?: ModelProviderBufferOptions): Promise<{
        buffer: Buffer;
        mimeType?: string;
    }>;
    protected createHttpError(response: ModelProviderHttpResponse): Promise<Error>;
    protected createTimeoutError(timeoutMs: number): Error;
    private resolveRequestUrl;
    private mergeHeaders;
}
