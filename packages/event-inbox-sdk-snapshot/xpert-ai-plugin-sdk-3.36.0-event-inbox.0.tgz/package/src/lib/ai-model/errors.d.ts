import { ForbiddenException, NotFoundException } from "@nestjs/common";
export declare class AiModelNotFoundException extends NotFoundException {
}
export declare class CredentialsValidateFailedError extends ForbiddenException {
}
export declare class AIModelProviderNotFoundException extends NotFoundException {
}
