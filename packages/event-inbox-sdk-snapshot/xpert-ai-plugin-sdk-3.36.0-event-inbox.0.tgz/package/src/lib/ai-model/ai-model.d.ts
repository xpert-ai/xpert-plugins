import { BaseChatModel } from '@langchain/core/language_models/chat_models';
import type { RealtimeModelConnection } from './realtime';
import { AIModelEntity, AiModelTypeEnum, ICopilotModel, ModelUsagePricingContext, ModelUsagePricingSnapshot, ParameterRule, PriceInfo, PriceType } from '@xpert-ai/contracts';
import { Logger } from '@nestjs/common';
import { ModelProvider } from './abstract-provider';
import type { AIGCModelClient, AsyncAIGCModelClient } from './types/aigc';
import { IAIModel, TChatModelOptions } from './types/model';
import { ModelProfile } from './types/profile';
export declare abstract class AIModel implements IAIModel {
    protected readonly modelProvider: ModelProvider;
    modelType: AiModelTypeEnum;
    protected logger: Logger;
    protected modelSchemas: AIModelEntity[] | null;
    private positions;
    constructor(modelProvider: ModelProvider, modelType: AiModelTypeEnum);
    abstract validateCredentials(model: string, credentials: Record<string, any>): Promise<void>;
    getRealtimeModel(_copilotModel: ICopilotModel): RealtimeModelConnection;
    getChatModel(copilotModel: ICopilotModel, options?: TChatModelOptions): BaseChatModel;
    getAIGCModel(copilotModel: ICopilotModel, options?: TChatModelOptions): AIGCModelClient | AsyncAIGCModelClient;
    getPrice(model: string, credentials: Record<string, any>, priceType: PriceType, tokens: number, inputTokens?: number): PriceInfo;
    getUsagePricingSnapshot(model: string, credentials: Record<string, any>, context: ModelUsagePricingContext): ModelUsagePricingSnapshot;
    protected getModelPath(): string;
    predefinedModels(): AIModelEntity[];
    getModelSchema(model: string, credentials?: Record<string, any>): AIModelEntity | null;
    /**
     * Get customizable model schema.
     * Implement this method in ai model sub class that can customize model
     *
     * @param model model name
     * @param credentials model credentials
     * @returns model schema
     */
    protected getCustomizableModelSchemaFromCredentials(model: string, credentials: Record<string, any>): AIModelEntity | null;
    private processParameterRules;
    private processLabel;
    private sortModelSchemas;
    protected _commonParameterRules(model: string): ParameterRule[];
    getParameterRules(model: string, credentials: Record<string, string>): ParameterRule[];
    getModelProfile(model: string, credentials: unknown): ModelProfile;
}
