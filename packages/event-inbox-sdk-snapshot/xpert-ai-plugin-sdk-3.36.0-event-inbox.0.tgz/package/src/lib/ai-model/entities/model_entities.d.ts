export declare function valueOf<T>(enumObj: T, value: string): T[keyof T];
export declare enum DefaultParameterName {
    TEMPERATURE = "temperature",
    TOP_P = "top_p",
    TOP_K = "top_k",
    PRESENCE_PENALTY = "presence_penalty",
    FREQUENCY_PENALTY = "frequency_penalty",
    MAX_TOKENS = "max_tokens",
    RESPONSE_FORMAT = "response_format",
    JSON_SCHEMA = "json_schema"
}
export interface ModelUsage {
    token?: number;
}
