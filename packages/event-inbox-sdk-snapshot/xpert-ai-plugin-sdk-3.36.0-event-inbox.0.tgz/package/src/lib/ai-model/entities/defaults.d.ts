import { ParameterRule } from '@xpert-ai/contracts';
import { DefaultParameterName } from './model_entities';
export declare const PARAMETER_RULE_TEMPLATE: Record<DefaultParameterName, ParameterRule>;
