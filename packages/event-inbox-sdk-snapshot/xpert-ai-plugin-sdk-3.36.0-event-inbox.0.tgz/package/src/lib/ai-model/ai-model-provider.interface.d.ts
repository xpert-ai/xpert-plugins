import { AiModelTypeEnum, IAiProviderEntity, ICopilotModel, ProviderModel, AIModelEntity, DiscoveredModel, ProviderCredentialValidationPolicy } from '@xpert-ai/contracts';
import { BaseLanguageModel } from '@langchain/core/language_models/base';
import { Embeddings } from '@langchain/core/embeddings';
import { BaseChatModel } from '@langchain/core/language_models/chat_models';
import { AIGCModelClient, AsyncAIGCModelClient, IRerank } from './types';
import { AIModel } from './ai-model';
import type { NativeModelClientFactory } from './native-model';
export interface IAIModelProviderStrategy {
    /** Fetch account-visible models without persisting them or invoking model inference. */
    discoverModels?(credentials: Record<string, unknown>): Promise<DiscoveredModel[]>;
    /** Used when discovery is unavailable; never pick a fixed inference model for all credentials. */
    readonly credentialValidation?: ProviderCredentialValidationPolicy;
    getNativeModelClient?: NativeModelClientFactory;
    /**
     * Provider metadata
     */
    /**
     * Stable provider identifier from the provider schema.
     */
    readonly name: string;
    /**
     * Validate whether the credentials are valid
     */
    validateCredentials(credentials: Record<string, any>): Promise<void>;
    /**
     * @deprecated use validateCredentials instead
     */
    validateProviderCredentials(credentials: Record<string, any>): Promise<void>;
    /**
     * Get the provider's Base URL
     */
    getBaseUrl(credentials: Record<string, any>): string;
    /**
     * Get authorization information, such as API Key, Token, etc.
     */
    getAuthorization(credentials: Record<string, any>): string;
    /**
     * Get the list of models supported by the provider
     */
    getModels(modelType: AiModelTypeEnum): Promise<AIModelEntity[]>;
    /**
     * Return a directly usable model instance (LLM / Embedding / TTS / Rerank / AIGC)
     */
    getModelInstance(type: AiModelTypeEnum, copilotModel: ICopilotModel, options?: Record<string, any>): Promise<BaseLanguageModel | BaseChatModel | Embeddings | IRerank | AIGCModelClient | AsyncAIGCModelClient>;
    /**
     * Return the defined provider models (metadata)
     */
    getProviderModels(modelType?: AiModelTypeEnum, onlyActive?: boolean): ProviderModel[];
    getProviderSchema(): IAiProviderEntity;
    getProviderServerPath(): string;
    getModelManager<T extends AIModel>(modelType: AiModelTypeEnum): T;
}
