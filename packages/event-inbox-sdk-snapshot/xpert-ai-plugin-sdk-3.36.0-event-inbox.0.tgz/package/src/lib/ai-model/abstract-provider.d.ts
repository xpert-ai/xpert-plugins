import { Embeddings } from '@langchain/core/embeddings';
import { BaseLanguageModel } from '@langchain/core/language_models/base';
import { BaseChatModel } from '@langchain/core/language_models/chat_models';
import { AIModelEntity, AiModelTypeEnum, IAiProviderEntity, ICopilotModel, ProviderModel } from '@xpert-ai/contracts';
import { Logger } from '@nestjs/common';
import { AIModel } from './ai-model';
import { IAIModelProviderStrategy } from './ai-model-provider.interface';
import { AIGCModelClient, AsyncAIGCModelClient, TChatModelOptions, IRerank } from './types/';
export declare abstract class ModelProvider implements IAIModelProviderStrategy {
    readonly logger: Logger;
    protected _name?: string;
    protected _meta?: IAiProviderEntity;
    get name(): string;
    protected modelManagers: Map<AiModelTypeEnum, AIModel>;
    private dir?;
    constructor();
    validateCredentials(credentials: Record<string, any>): Promise<void>;
    abstract getAuthorization(credentials: Record<string, any>): string;
    abstract getBaseUrl(credentials: Record<string, any>): string;
    abstract validateProviderCredentials(credentials: Record<string, any>): Promise<void>;
    /**
     * Get provider lib root path.
     *
     * @returns Root of library
     */
    getProviderServerPath(): string;
    getProviderSchema(): IAiProviderEntity;
    getModels(modelType: AiModelTypeEnum): Promise<AIModelEntity[]>;
    registerAIModelInstance(modelType: AiModelTypeEnum, modelInstance: AIModel): void;
    getModelManager<T extends AIModel>(modelType: AiModelTypeEnum): T;
    /**
     * Get provider models.
     * @param modelType - model type
     * @param onlyActive - only active models
     * @return provider models
     */
    getProviderModels(modelType?: AiModelTypeEnum, onlyActive?: boolean): ProviderModel[];
    getSystemProviderModels(modelTypes: AiModelTypeEnum[]): any[];
    getChatModel(copilotModel: ICopilotModel, options?: TChatModelOptions): BaseChatModel<import("@langchain/core/language_models/chat_models").BaseChatModelCallOptions, import("@langchain/core/messages").AIMessageChunk>;
    getModelInstance(type: AiModelTypeEnum, copilotModel: ICopilotModel, options?: TChatModelOptions): Promise<BaseLanguageModel | BaseChatModel | Embeddings | IRerank | AIGCModelClient | AsyncAIGCModelClient>;
}
