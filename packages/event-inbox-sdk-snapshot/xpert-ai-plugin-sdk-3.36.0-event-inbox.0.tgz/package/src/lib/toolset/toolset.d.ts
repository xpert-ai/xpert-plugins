import { BaseToolkit, StructuredTool, StructuredToolInterface } from "@langchain/core/tools";
import { I18nObject, TStateVariable, TToolsetParams } from "@xpert-ai/contracts";
import { z } from 'zod/v3';
type ZodObjectAny = z.ZodObject<any, any, any, any>;
/**
 * Base ability for all toolsets
 */
export declare abstract class BaseToolset<T extends StructuredToolInterface = StructuredToolInterface> extends BaseToolkit {
    protected params?: TToolsetParams;
    abstract providerName: string;
    tools: T[];
    stateVariables: TStateVariable[];
    constructor(params?: TToolsetParams);
    /**
     * Async init tools
     *
     * @returns
     */
    initTools(): Promise<T[]>;
    /**
     * Get ID of the toolset
     */
    abstract getId(): string;
    /**
     * Get name of the toolset
     */
    abstract getName(): string;
    /**
     * Get one tool
     *
     * @param toolName
     * @returns
     */
    getTool(toolName: string): StructuredToolInterface<import("@langchain/core/tools").ToolSchemaBase, any, any>;
    /**
     * Get state variables config
     *
     * @returns State variables
     */
    getVariables(): Promise<TStateVariable[]>;
    /**
     * Get title of tool
     */
    abstract getToolTitle(name: string): string | I18nObject;
    /**
     * Close all (connections).
     */
    close(): Promise<void>;
}
export declare abstract class BaseTool<T extends ZodObjectAny = ZodObjectAny> extends StructuredTool<T> {
    schema: any;
}
export {};
