import { DiscoveryService, Reflector } from '@nestjs/core';
import { IToolsetStrategy } from './strategy.interface';
import { BaseStrategyRegistry } from '../strategy';
export declare class ToolsetRegistry<TConfig = any> extends BaseStrategyRegistry<IToolsetStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
