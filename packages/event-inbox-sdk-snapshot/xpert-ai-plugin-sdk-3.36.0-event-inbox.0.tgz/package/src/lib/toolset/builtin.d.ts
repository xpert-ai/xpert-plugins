import { StructuredToolInterface } from '@langchain/core/tools';
import { BaseStore } from '@langchain/langgraph';
import { I18nObject, IXpertToolset, ToolProviderCredentials, TToolCredentials, TToolsetParams, XpertToolsetCategoryEnum } from '@xpert-ai/contracts';
import { Logger } from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { BaseToolset } from './toolset';
import type { AgentMiddlewareModelProviderConnection, AgentMiddlewareRuntimeApi, AgentMiddlewareRuntimeScope } from '../agent/middleware/runtime';
import type { RuntimeCapabilityResolver } from '../core/runtime-capability';
import type { ManagedQueueService } from '../managed-queue';
import type { McpCapabilityDefinitions, McpCapabilityRuntimeProvider } from '../mcp';
/**
 * The context params of creating toolset
 */
export type TToolTokenUsage = {
    type?: 'estimated';
    requestId: string;
    provider: string;
    model?: string;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
};
export type TToolModelUsageReporter = (usage: TToolTokenUsage) => void | Promise<void>;
export type TToolModelProviderRuntime = AgentMiddlewareModelProviderConnection;
export type TToolModelRuntime = {
    /** Use the host's configured model provider; tool plugins must not handle provider API keys. */
    createModelClient: AgentMiddlewareRuntimeApi['createModelClient'];
    /** Resolve the host model provider account required by a direct Provider API tool. */
    getModelProvider?: (provider: string) => Promise<TToolModelProviderRuntime>;
    /** Report usage only for model APIs called directly by the tool. */
    reportUsage?: TToolModelUsageReporter;
};
export type TBuiltinToolsetParams = TToolsetParams & {
    commandBus: CommandBus;
    queryBus: QueryBus;
    store?: BaseStore;
    modelRuntime?: TToolModelRuntime;
    /** Host-bound capabilities for this execution; these override installation-level plugin capabilities. */
    runtimeCapabilities?: RuntimeCapabilityResolver;
    /** Authoritative execution scope used by scoped capabilities and delayed plugin jobs. */
    runtimeScope?: AgentMiddlewareRuntimeScope;
    managedQueue?: ManagedQueueService;
    /** Installation scope used to route jobs back to this plugin instance. */
    pluginScopeKey?: string;
    /** Package provenance used to resolve plugin-owned MCP App bundles. */
    pluginName?: string;
    pluginVersion?: string;
};
export interface IBuiltinToolset {
    validateCredentials(credentials: TToolCredentials): Promise<void>;
}
export declare abstract class BuiltinToolset<T extends StructuredToolInterface = StructuredToolInterface, C = TToolCredentials> extends BaseToolset<T> implements IBuiltinToolset, McpCapabilityRuntimeProvider {
    providerName: string;
    protected toolset?: IXpertToolset;
    protected params?: TBuiltinToolsetParams;
    static provider: string;
    protected logger: Logger;
    providerType: XpertToolsetCategoryEnum.BUILTIN;
    credentialsSchema?: {
        [key: string]: ToolProviderCredentials;
    };
    protected mcpCapabilities: McpCapabilityDefinitions;
    get tenantId(): string;
    get organizationId(): string;
    get commandBus(): CommandBus<import("@nestjs/cqrs").ICommand>;
    get queryBus(): QueryBus<import("@nestjs/cqrs").IQuery>;
    get xpertId(): string;
    get modelRuntime(): TToolModelRuntime;
    get managedQueue(): ManagedQueueService;
    get pluginScopeKey(): string;
    constructor(providerName: string, toolset?: IXpertToolset, params?: TBuiltinToolsetParams);
    validateCredentials(credentials: C): Promise<void>;
    _validateCredentials(credentials: C): Promise<void>;
    getId(): string;
    getCredentials(): C;
    getMcpCapabilityDefinitions(): Readonly<McpCapabilityDefinitions>;
    getMcpCapabilitySource(): {
        pluginVersion?: string;
        pluginName?: string;
    };
    getToolTitle(name: string): string | I18nObject;
    /**
     * Get credentials schema
     *
     * @returns Credentials schema
     */
    getCredentialsSchema(): {
        [key: string]: ToolProviderCredentials;
    };
    /**
     * Get toolset entity
     *
     * @returns XpertToolset
     */
    getToolset(): IXpertToolset;
    getName(): string;
}
