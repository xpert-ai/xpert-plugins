import type { StructuredToolInterface } from '@langchain/core/tools';
import { type IXpertToolset, type TToolCredentials } from '@xpert-ai/contracts';
import { type AIGCModelClient, type AsyncAIGCModelClient } from '../ai-model';
import { type RuntimeCapabilityResolver, type WorkspaceFileScope, type WorkspaceFilesApi } from '../runtime';
import { BuiltinToolset, type TBuiltinToolsetParams, type TToolModelProviderRuntime } from './builtin';
export type ModelProviderAuthorizationScheme = 'Bearer' | 'ApiKey';
export type ModelProviderBuiltinToolsetOptions = {
    toolsetProviderName: string;
    modelProviderName: string;
    authorizationScheme: ModelProviderAuthorizationScheme;
    invalidCredentialsMessage: string;
    missingProviderMessage: string;
    missingWorkspaceMessage: string;
};
/**
 * Shared host-runtime plumbing for built-in tools backed by a configured model provider.
 * Provider request/response semantics remain owned by each plugin.
 */
export declare abstract class ModelProviderBuiltinToolset<T extends StructuredToolInterface = StructuredToolInterface, C = TToolCredentials> extends BuiltinToolset<T, C> {
    private readonly modelProviderOptions;
    private modelProvider?;
    constructor(modelProviderOptions: ModelProviderBuiltinToolsetOptions, toolset?: IXpertToolset, _runtimeCapabilities?: RuntimeCapabilityResolver, params?: TBuiltinToolsetParams);
    _validateCredentials(_credentials: C): Promise<void>;
    protected getModelProviderRuntime(): Promise<TToolModelProviderRuntime>;
    protected getModelProviderCredential(modelProvider: TToolModelProviderRuntime): string;
    protected getWorkspaceFiles(): WorkspaceFilesApi;
    protected createWorkspaceScope(): WorkspaceFileScope | undefined;
    protected createAsyncModelClient<TInput, TData>(model: string, modality: 'image' | 'video', purpose?: 'invoke' | 'observe'): Promise<AsyncAIGCModelClient<TInput, TData>>;
    protected createModelClient<TInput, TData>(model: string, modality: 'image' | 'video'): Promise<AIGCModelClient<TInput, TData>>;
}
