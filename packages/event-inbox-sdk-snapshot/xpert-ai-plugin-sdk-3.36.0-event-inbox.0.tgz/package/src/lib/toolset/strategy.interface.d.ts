import { DynamicStructuredTool } from '@langchain/core/tools';
import { I18nObject, IconDefinition } from '@xpert-ai/contracts';
import type { ZodSchema } from 'zod/v3';
import { BuiltinToolset, TBuiltinToolsetParams } from './builtin';
import type { VideoGenerationToolsetCapability } from '../core/permissions/video-generation';
export interface IToolsetStrategy<TConfig = any> {
    /**
     * Metadata about this toolset
     */
    readonly meta: {
        author: string;
        tags: string[];
        name: string;
        label: I18nObject;
        description?: I18nObject;
        configSchema: any;
        icon?: IconDefinition;
        /** Optional normalized video-generation capability consumed by platform services. */
        videoGeneration?: VideoGenerationToolsetCapability;
    };
    /**
     * Validate the configuration
     */
    validateConfig(config: TConfig): Promise<void>;
    create(config: TConfig, params?: TBuiltinToolsetParams): Promise<BuiltinToolset>;
    createTools(): DynamicStructuredTool<ZodSchema>[];
}
