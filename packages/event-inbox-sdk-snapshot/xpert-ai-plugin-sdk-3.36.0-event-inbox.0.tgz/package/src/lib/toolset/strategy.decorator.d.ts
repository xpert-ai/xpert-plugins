export declare const TOOLSET_STRATEGY = "TOOLSET_STRATEGY";
/**
 * Decorator to mark a provider as a Toolset Strategy
 */
export declare const ToolsetStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
