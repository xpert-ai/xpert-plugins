import { DiscoveryService, Reflector } from '@nestjs/core';
import type { I18nObject, LanguagesEnum, ModelFeature, TXpertTeamDraft, TXpertTemplate } from '@xpert-ai/contracts';
import { BaseStrategyRegistry } from '../strategy';
export { applyAssistantMiddleware, hasAssistantMiddleware } from './middleware';
export interface AssistantCapabilityContext {
    template: TXpertTemplate;
    draft: TXpertTeamDraft;
    language: LanguagesEnum;
    /** Provided again at installation; providers must not silently select a fallback. */
    sandboxProviders?: {
        type: string;
    }[];
}
export interface AssistantCapabilityApplyContext extends AssistantCapabilityContext {
    loadTemplate: (id: string) => Promise<TXpertTemplate>;
}
/** Optional capabilities default to off. IDs are stable machine-readable keys. */
export interface IAssistantCapabilityProvider {
    readonly key: string;
    readonly label: string | I18nObject;
    readonly description: string | I18nObject;
    readonly requiredModelFeatures?: ModelFeature[];
    /** Explicitly opt into the blank Assistant creation flow. */
    readonly availableForBlankAssistant?: boolean;
    /** Opt into a simple creation switch; no additional capability-specific configuration is needed. */
    readonly supportsQuickCreation?: boolean;
    /** Distribution extensions to specific templates, without changing their portable source. */
    readonly templates?: {
        templateId: string;
        required: boolean;
    }[];
    /** Detect a capability already owned by the base workflow; it cannot be removed by a new overlay. */
    isEnabled?(draft: TXpertTeamDraft): boolean;
    check(context: AssistantCapabilityContext): Promise<{
        available: boolean;
        reason?: string;
    }>;
    /** Deterministic draft composition; never creates external resources. */
    apply(context: AssistantCapabilityApplyContext): Promise<void>;
}
export declare const ASSISTANT_CAPABILITY_PROVIDER = "ASSISTANT_CAPABILITY_PROVIDER";
export declare const AssistantCapabilityProvider: (key: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class AssistantCapabilityProviderRegistry extends BaseStrategyRegistry<IAssistantCapabilityProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
}
