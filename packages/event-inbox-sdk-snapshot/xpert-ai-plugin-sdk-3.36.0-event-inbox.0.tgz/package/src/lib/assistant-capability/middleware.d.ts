import { type TXpertTeamDraft } from '@xpert-ai/contracts';
export declare function hasAssistantMiddleware(draft: TXpertTeamDraft, provider: string, agentKey?: string): boolean;
/** Compose only the draft graph. The platform records the contribution for safe removal.
 * No Project, permission, external resource or implicit replacement is created here. */
export declare function applyAssistantMiddleware(draft: TXpertTeamDraft, input: {
    provider: string;
    key: string;
    title: string;
    instructions: string;
    preserveToolConcurrency?: boolean;
}): void;
