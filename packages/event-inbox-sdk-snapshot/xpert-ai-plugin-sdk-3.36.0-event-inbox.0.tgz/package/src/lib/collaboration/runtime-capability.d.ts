import type { CollaborationApi } from './types';
/** Platform-owned real-time collaboration capability available to scoped plugin runtimes. */
export declare const CollaborationRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<CollaborationApi>;
