import type { ICollaborationActor, ICollaborationPresence } from './types';
/** Connection-specific metadata delivered with a presence snapshot. */
export type CollaborationPresenceSnapshotMetadata = {
    selfClientId: string | null;
};
/** Stable, framework-neutral view of active collaboration sessions and deduplicated actors. */
export type CollaborationPresenceStoreSnapshot = {
    selfClientId: string | null;
    /** Every active browser/Agent session keyed by `clientId`. */
    sessions: ICollaborationPresence[];
    /** Sessions excluding only this exact browser client. */
    remoteSessions: ICollaborationPresence[];
    /** One entry per actor identity, including the local actor when supplied. */
    collaborators: ICollaborationPresence[];
};
export type CollaborationPresenceStoreOptions = {
    selfActor?: ICollaborationActor | null;
    includeSelf?: boolean;
    onChange?: (snapshot: CollaborationPresenceStoreSnapshot) => void;
};
/** Mutable presence projection used by plugin UIs without coupling them to a framework. */
export interface CollaborationPresenceStore {
    setSelfClientId(clientId: string | null): void;
    replace(items: ICollaborationPresence[], selfClientId?: string | null): void;
    upsert(item: ICollaborationPresence): void;
    remove(clientId: string): void;
    clear(): void;
    snapshot(): CollaborationPresenceStoreSnapshot;
}
/**
 * Keep per-client sessions for cursors while exposing one collaborator per stable actor identity.
 * This prevents a second tab owned by the same user from either duplicating or hiding that user.
 */
export declare function createCollaborationPresenceStore(options?: CollaborationPresenceStoreOptions): CollaborationPresenceStore;
/** Parse untrusted presence payloads shared by both engines; document content is ignored. */
export declare function parseCollaborationPresence(value: unknown): ICollaborationPresence | null;
