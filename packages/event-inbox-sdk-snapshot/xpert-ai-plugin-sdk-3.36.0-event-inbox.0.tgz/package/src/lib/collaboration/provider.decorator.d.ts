export declare const COLLABORATION_DOCUMENT_PROVIDER = "COLLABORATION_DOCUMENT_PROVIDER";
/** Register a plugin adapter for one stable collaboration resource type. */
export declare const CollaborationDocumentProvider: (providerKey: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
