import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { CollaborationProvider } from './types';
/** Discovers system and organization-scoped collaboration providers from loaded plugins. */
export declare class CollaborationDocumentProviderRegistry extends BaseStrategyRegistry<CollaborationProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
