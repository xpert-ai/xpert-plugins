import type { CollaborationTransport } from './transport';
import { type CollaborationPresenceSnapshotMetadata } from './presence';
export * from './transport';
export * from './presence';
import type { ApplyCollaborationUpdateResult, CollaborationPresencePatch, CollaborationSessionDescriptor, ICollaborationPresence } from './types';
export type CollaborationDocumentUpdateHandler = (update: Uint8Array, origin: unknown) => void;
/** Binary CRDT operations required by the generic collaboration client. */
export interface CollaborationBinaryDocumentAdapter {
    applyUpdate(update: Uint8Array, origin: unknown): void;
    encodeStateVector(): Uint8Array;
    mergeUpdates(updates: Uint8Array[]): Uint8Array;
    onUpdate(handler: CollaborationDocumentUpdateHandler): () => void;
}
/** Minimal observable Yjs document surface accepted by `createYjsDocumentAdapter`. */
export interface YjsDocumentLike {
    on(event: 'update', handler: CollaborationDocumentUpdateHandler): void;
    off(event: 'update', handler: CollaborationDocumentUpdateHandler): void;
}
/** Caller-supplied Yjs functions, avoiding a second Yjs runtime in plugin bundles. */
export interface YjsApiLike<TDocument extends YjsDocumentLike> {
    applyUpdate(document: TDocument, update: Uint8Array, origin?: unknown): void;
    encodeStateVector(document: TDocument): Uint8Array;
    mergeUpdates(updates: Uint8Array[]): Uint8Array;
}
/** Wrap a caller-owned `Y.Doc` without passing it across the runtime capability boundary. */
export declare function createYjsDocumentAdapter<TDocument extends YjsDocumentLike>(document: TDocument, yjs: YjsApiLike<TDocument>): CollaborationBinaryDocumentAdapter;
/** Timings, callbacks, transport, and document adapter used by a browser client. */
export type CollaborationClientOptions = {
    session: CollaborationSessionDescriptor;
    transport: CollaborationTransport;
    document: CollaborationBinaryDocumentAdapter;
    initialPresence?: CollaborationPresencePatch;
    batchMs?: number;
    syncIntervalMs?: number;
    presenceHeartbeatMs?: number;
    /** Remove a presence locally when no refresh has been received within this interval. */
    presenceStaleMs?: number;
    onAck?: (ack: ApplyCollaborationUpdateResult) => void;
    onPresence?: (presence: ICollaborationPresence) => void;
    onPresenceSnapshot?: (items: ICollaborationPresence[], metadata: CollaborationPresenceSnapshotMetadata) => void;
    onPresenceRemove?: (clientId: string) => void;
    onConnectionChange?: (state: 'connecting' | 'connected' | 'disconnected') => void;
    onError?: (error: Error) => void;
};
/** Lifecycle and presence controls returned by `createCollaborationClient`. */
export interface CollaborationClient {
    /** Stable origin applied to remote updates so local observers can prevent echo loops. */
    readonly remoteOrigin: object;
    /** Socket id for this exact tab/device; distinct from the stable actor `presenceId`. */
    readonly selfClientId: string | null;
    connect(): void;
    disconnect(): void;
    flush(): void;
    requestSync(): void;
    setPresence(patch: CollaborationPresencePatch): void;
}
/**
 * Create a Yjs collaboration client with update batching, state-vector repair, presence heartbeat,
 * and reconnect synchronization. The caller retains ownership of the document and transport.
 */
export declare function createCollaborationClient(options: CollaborationClientOptions): CollaborationClient;
/** Encode bytes in browsers without Node.js `Buffer`; chunks avoid argument-size limits. */
export declare function bytesToBase64(bytes: Uint8Array): string;
/** Decode base64 in browsers without requiring Node.js polyfills. */
export declare function base64ToBytes(value: string): Uint8Array;
