import type { CollaborationTransport } from './transport';
import type { CollaborationPresencePatch, CollaborationSessionDescriptor, ICollaborationPresence } from './types';
export type OperationCollaborationOptions = {
    session: CollaborationSessionDescriptor;
    transport: CollaborationTransport;
    /** Invalidate/refetch domain state; this is neither an operation payload nor a save acknowledgement. */
    onRevision(revision: number): void;
    onPresence(items: ICollaborationPresence[], selfClientId: string | null): void;
    onConnection(state: 'connected' | 'disconnected'): void;
    onError(error: Error): void;
};
/**
 * Notification client for a domain-owned operation log, not an OT/CRDT implementation.
 * The domain API owns writes, validation, conflict handling and persistence. This client
 * only tracks committed revisions and ephemeral presence; it never submits business edits.
 * Revisions coalesce to one high-water mark, so consumers must refetch authoritative state.
 */
export declare function createOperationCollaborationClient(options: OperationCollaborationOptions): {
    connect(): void;
    disconnect: () => void;
    requestSync: () => void;
    setPresence(value: CollaborationPresencePatch): void;
};
