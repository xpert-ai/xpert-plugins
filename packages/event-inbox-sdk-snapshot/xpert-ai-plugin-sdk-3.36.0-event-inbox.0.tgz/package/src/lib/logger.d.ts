import type { PluginLogger } from './types';
export declare function createPluginLogger(scope: string, baseMeta?: Record<string, any>): PluginLogger;
