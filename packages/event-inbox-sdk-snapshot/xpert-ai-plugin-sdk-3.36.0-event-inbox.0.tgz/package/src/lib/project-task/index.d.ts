import { DiscoveryService, Reflector } from '@nestjs/core';
import type { ProjectTaskGraph, ProjectTaskGraphChange, ProjectTaskExecutionTarget, ProjectTaskTypeDefinition, TXpertProjectTaskStatus } from '@xpert-ai/contracts';
import { BaseStrategyRegistry } from '../strategy';
import type { ProjectAccessActor } from '../runtime/capabilities/project-access';
import type { ProjectTaskAcceptanceReceipt, ProjectTaskCandidateReceipt } from './acceptance';
export type { ProjectTaskAcceptanceReceipt, ProjectTaskCandidateReceipt } from './acceptance';
export interface ProjectTaskContext {
    actor: ProjectAccessActor;
    projectId: string;
}
export interface ProjectTaskProjection {
    key: string;
    title: string;
    status: TXpertProjectTaskStatus;
    /** Completion percentage (0–100), independent of status. Omit to preserve; null clears it. */
    progress?: number | null;
    kind: 'task' | 'summary' | 'milestone';
    /** Registered business type; omitted values preserve legacy persisted types. Null explicitly clears it. */
    taskType?: string | null;
    parentKey?: string;
    predecessorKeys: string[];
    diagnostic?: string;
    assigneeXpertId?: string;
    executions: Array<{
        key: string;
        attempt: number;
        invocationId?: string;
        agentExecutionId?: string;
        conversationId?: string;
        threadId?: string;
        xpertId?: string;
        agentKey?: string;
        status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
        startedAt?: string;
        completedAt?: string;
        error?: string;
        outputSummary?: string;
    }>;
}
/** Domain facts remain durable in the provider; projection can be replayed after interruption. */
export interface ProjectTaskSnapshot {
    revision: string;
    tasks: ProjectTaskProjection[];
}
export interface IProjectTaskProvider {
    readonly key: string;
    /** Presentation declarations belong to this provider and never contain executable icon code. */
    readonly taskTypes?: readonly ProjectTaskTypeDefinition[];
    /** Return null when the project is not owned by this provider. Always scope domain reads. */
    snapshot(context: ProjectTaskContext): Promise<ProjectTaskSnapshot | null>;
    /** Called after projection commits; retries must be idempotent. Never start work here. */
    linked?(context: ProjectTaskContext, links: Array<{
        sourceKey: string;
        taskId: string;
    }>): Promise<void>;
}
export type { ProjectTaskIconName, ProjectTaskTypeDefinition, ProjectTaskTypePresentation } from '@xpert-ai/contracts';
export declare const PROJECT_TASK_PROVIDER = "PROJECT_TASK_PROVIDER";
export declare const ProjectTaskProvider: (key: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class ProjectTaskProviderRegistry extends BaseStrategyRegistry<IProjectTaskProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
}
/** ORM-independent project task management; actor values come from trusted server context. */
export interface ProjectTasksApi {
    /** Read completed implementation output before review, without reconciling or accepting work. */
    readCandidate?(context: ProjectTaskContext, taskId: string): Promise<ProjectTaskCandidateReceipt>;
    /** Read current formal acceptance without dispatching or reconciling work; null means no current acceptance. */
    readAcceptance(context: ProjectTaskContext, taskId: string): Promise<ProjectTaskAcceptanceReceipt | null>;
    /** Read the saved graph and current execution facts. Never invokes provider snapshot/linked callbacks. */
    graph(context: ProjectTaskContext): Promise<ProjectTaskGraph>;
    /** After committing domain changes, enqueue a durable coalesced refresh; does not wait for provider callbacks. */
    refresh(context: ProjectTaskContext): Promise<{
        status: 'queued';
    }>;
    change(context: ProjectTaskContext, input: ProjectTaskGraphChange): Promise<ProjectTaskGraph>;
    resolveExecution(context: ProjectTaskContext, taskExecutionId: string): Promise<ProjectTaskExecutionTarget>;
}
export declare const ProjectTasksRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectTasksApi>;
