import { z } from 'zod/v3';
/** Portable Agent input; filesystem containment and authorization remain with the host. */
export declare const workspaceRelativeFilePathSchema: z.ZodEffects<z.ZodString, string, string>;
/** Directory discovery also accepts the workspace root and a trailing directory slash. */
export declare const workspaceRelativeDirectoryPathSchema: z.ZodPipeline<z.ZodEffects<z.ZodString, string, string>, z.ZodUnion<[z.ZodLiteral<".">, z.ZodEffects<z.ZodString, string, string>]>>;
/** Host-owned metadata lets plugins observe file intent without guessing tool names. */
export declare const workspaceFileMutationMetadata: {
    readonly workspaceFileOperation: {
        readonly type: "mutation";
        readonly pathArgument: "file_path";
    };
};
export declare function workspaceFileMutationPath(metadata: unknown, args: Record<string, unknown>): string | undefined;
