/** Run-scoped evidence for multi-tool writes. A file write is not a domain commit. */
export declare function createMutationEvidence<T>(): {
    begin(): number;
    accept(token: number, value: T): void;
    readonly pending: boolean;
    readonly receipt: T;
};
