import type { RuntimeIdentityScope } from '../runtime-scope';
export type ActorTokenAct = Record<string, string | number | boolean | null | undefined>;
export interface ActorTokenRequest {
    audience?: string | string[];
    ttlSeconds?: number;
    /** Extra delegation metadata; cannot replace claims fixed by the host when creating the API. */
    act?: ActorTokenAct;
}
export interface ActorTokenResult {
    token: string;
    expiresAt: string;
    audience: string | string[];
}
export interface ActorTokenApi {
    getToken(input?: ActorTokenRequest): Promise<ActorTokenResult>;
}
export declare const ActorTokenRuntimeCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<ActorTokenApi>;
/** Host-defined delegation claims are fixed when the API is created. */
export type ActorTokenRuntimeScope = RuntimeIdentityScope & {
    act?: ActorTokenAct;
};
export interface ActorTokenRuntimeFactory {
    /** Create one independent token cache for a host-authorized caller/execution. */
    createScopedApi(scope: ActorTokenRuntimeScope): ActorTokenApi;
}
/** Platform registry entry. The operation capability above is bound only inside a caller runtime. */
export declare const ActorTokenRuntimeFactoryCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<ActorTokenRuntimeFactory>;
