import type { SandboxJobRetryReference } from '@xpert-ai/contracts';
import type { JSONValue } from '@xpert-ai/contracts';
import type { WorkspaceFileScope, WorkspacePortableFileReference } from './workspace-files';
import type { TaskControlPolicy } from '../../execution-control';
/** Stable machine-readable failures emitted by the Sandbox Jobs capability. */
export declare const SANDBOX_JOB_ERROR_CODES: readonly ["SANDBOX_ACTION_UNAVAILABLE", "SANDBOX_ACTION_INVALID", "SANDBOX_PROFILE_UNAVAILABLE", "SANDBOX_RUNTIME_UNAVAILABLE", "SANDBOX_VERSION_MISMATCH", "SANDBOX_CAPACITY_UNAVAILABLE", "SANDBOX_START_FAILED", "SANDBOX_DEPENDENCY_MISSING", "EXPORT_CONVERSION_FAILED", "EXPORT_TEXT_EXTRACTION_FAILED", "SANDBOX_INVOCATION_FAILED", "BROWSER_LAUNCH_FAILED", "EXPORT_TIMEOUT", "EXPORT_OOM", "EXPORT_MEDIA_FAILED", "EXPORT_INPUT_INVALID", "EXPORT_OUTPUT_INVALID", "SANDBOX_CANCELLED", "SANDBOX_CONTROL_UNCONFIRMED"];
export type SandboxJobErrorCode = (typeof SANDBOX_JOB_ERROR_CODES)[number];
/** Persisted lifecycle states for a generic isolated background execution. */
export type SandboxJobStatus = 'waiting' | 'starting' | 'running' | 'settling' | 'cancelling' | 'unknown' | 'succeeded' | 'failed' | 'cancelled' | 'lost';
/** Line prefix used by trusted Actions to report structured, provider-neutral progress. */
export declare const SANDBOX_JOB_PROGRESS_PREFIX = "XPERT_SANDBOX_PROGRESS ";
/** Latest structured progress reported by a Sandbox Action or Core lifecycle stage. */
export type SandboxJobProgress = {
    /** Normalized completion ratio from 0 through 1. */
    progress: number;
    /** Stable machine-readable stage such as `rendering`, `packaging`, or `complete`. */
    stage?: string;
    /** Optional bounded diagnostic intended for operational UIs and logs. */
    message?: string;
    /** Optional current work unit, for example the rendered frame number. */
    current?: number;
    /** Optional total work units corresponding to `current`. */
    total?: number;
    /** Platform timestamp of the latest accepted update. */
    updatedAt?: Date | string | null;
};
/** Portable Workspace Files input materialized under `/workspace/input`. */
export type SandboxJobFileInput = {
    /** Tenant-scoped portable reference; raw bytes never enter queue state. */
    reference: WorkspacePortableFileReference;
    /** Safe relative path below `/workspace/input`. */
    targetPath: string;
    /** Expected immutable byte length checked during materialization. */
    size: number;
    /** Expected immutable lowercase SHA-256; materialized inputs are re-hashed before execution. */
    sha256: string;
    /**
     * Input access semantics required by the Action.
     *
     * `materialized` preserves the v1 behavior: Core verifies and copies the
     * complete file into the Job workspace before execution. `read-only-seekable`
     * asks Core to expose the exact Workspace file through a Provider-owned,
     * Job-scoped read-only mapping so media decoders can perform on-demand reads.
     */
    access?: 'materialized' | 'read-only-seekable';
};
/** Declares one output to validate and persist back into Workspace Files. */
export type SandboxJobOutputRequest = {
    path: string;
    originalName: string;
    mimeType: string;
    destination: WorkspaceFileScope & {
        folder: string;
    };
};
/** Tenant and business ownership recorded for authorization, audit, and cleanup. */
export type SandboxJobScope = {
    tenantId: string;
    organizationId?: string | null;
    userId?: string | null;
    pluginName: string;
    businessResourceType: string;
    businessResourceId: string;
};
/** Action-oriented request accepted from a plugin background handler. */
export type SandboxJobRunInput = {
    /** Optional caller-known UUID used when cancellation must be possible while run() is awaiting completion. */
    jobId?: string;
    action: string;
    actionVersion: string;
    /** Stable tenant-scoped key combining business identity and immutable input checksum. */
    idempotencyKey: string;
    /** A new call identity that explicitly retries a settled original generation. */
    retryOf?: SandboxJobRetryReference;
    scope: SandboxJobScope;
    /** Small structured request; file bytes must be supplied through `files`. */
    payload: JSONValue;
    files?: SandboxJobFileInput[];
    outputs: SandboxJobOutputRequest[];
    /** Soft execution limit capped by the Runtime Definition's hard deadline. */
    timeoutMs?: number;
};
/** Validated output evidence returned as a portable Workspace Files reference. */
export type SandboxJobOutput = {
    path: string;
    originalName: string;
    mimeType: string;
    size: number;
    sha256: string;
    reference: WorkspacePortableFileReference;
    fileUrl?: string;
    workspacePath?: string;
};
/** Provider-neutral persisted view of a Sandbox Job and its runtime evidence. */
export type SandboxJobSnapshot = {
    /** Business result and physical completion are independent facts. */
    controlState?: 'pending' | 'settled' | 'unknown';
    generation?: string;
    id: string;
    runtimeProfile: string;
    sandboxRuntimeVersion: string;
    action: string;
    actionVersion: string;
    status: SandboxJobStatus;
    /** Latest persisted Action/Core progress, available while a Job is running and after reload. */
    progress?: SandboxJobProgress | null;
    /** Attempt number; a new failed-job attempt may select a newly healthy Binding. */
    attempt: number;
    /** Provider and Binding are persisted so cleanup never depends on current selection. */
    provider?: string | null;
    runtimeBindingId?: string | null;
    /** Opaque Provider identity used for reattachment and idempotent destruction. */
    runtimeRef?: string | null;
    artifactDigest?: string | null;
    /** @deprecated Use runtimeRef. Kept for one compatibility cycle. */
    containerRef?: string | null;
    outputs: SandboxJobOutput[];
    errorCode?: SandboxJobErrorCode | null;
    errorMessage?: string | null;
    createdAt?: Date | string | null;
    startedAt?: Date | string | null;
    finishedAt?: Date | string | null;
};
/**
 * Host callbacks available only for one execution attempt. This configuration is never
 * serialized into a Job or exposed to the script. An attached caller cannot replace it.
 */
export type SandboxJobInvocation = {
    /** Exact operation names the script may request; names carry no built-in business meaning. */
    operations: readonly string[];
    /** Positive integer request limit, including queued requests; Core caps it at 32. */
    maxCalls: number;
    /** Positive integer budget for UTF-8 request lines and response JSON combined; capped at 8 MB. */
    maxBytes: number;
    /**
     * Runs in the initiating host context. The plugin validates the operation payload and
     * rechecks resource access; the operation allowlist is not business authorization.
     * Honor signal to stop child work. Return only data permitted to enter the script workspace.
     */
    handle(operation: string, payload: JSONValue, context: {
        jobId: string;
        signal: AbortSignal;
    }): Promise<JSONValue>;
};
/** Live execution controls; kept separate from the persisted, JSON-only RunInput. */
export type SandboxJobRunOptions = {
    /** Trusted host ownership; independent/shared work must not inherit caller termination. */
    controlPolicy?: TaskControlPolicy;
    /** Cancels an owned attempt; on reattachment, cancels only this caller's wait. */
    signal?: AbortSignal;
    invocation?: SandboxJobInvocation;
};
/**
 * Stdout frame: prefix + JSON { id, operation, payload } + newline.
 * Core writes { id, value } to <workspaceRoot>/invocations/<id>.json after validation.
 * IDs are unique per attempt and restricted to 1–64 ASCII letters, digits, '_' or '-'.
 * The bridge has no network endpoint and gives the script no host credentials.
 */
export declare const SANDBOX_JOB_INVOCATION_PREFIX = "XPERT_SANDBOX_INVOKE ";
/** Successful `run()` result; failed executions reject with SandboxJobRuntimeError. */
export type SandboxJobRunResult = SandboxJobSnapshot & {
    status: 'succeeded';
};
/** Aggregated readiness of an Action, Runtime Definition, Worker, Binding, and Provider. */
export type SandboxJobActionHealth = {
    pluginName: string;
    action: string;
    actionVersion: string;
    runtimeProfile?: string;
    sandboxRuntimeVersion?: string;
    provider?: string;
    runtimeBindingId?: string;
    artifactDigest?: string;
    available: boolean;
    reason?: 'ACTION_MISSING' | 'ACTION_INVALID' | 'PROFILE_MISSING' | 'VERSION_MISMATCH' | 'RUNTIME_UNBOUND' | 'PROVIDER_UNAVAILABLE' | 'PROFILE_UNHEALTHY';
    message?: string;
    manifest?: Record<string, string>;
};
/**
 * Plugin-facing API for registered, structured Sandbox Actions.
 *
 * Callers choose only an Action and its version; images, commands, entrypoints,
 * environment variables, and Provider options are resolved and enforced by Core.
 */
export interface SandboxJobsApi {
    /** Starts, reattaches, or reuses a successful execution by tenant-scoped idempotency key. */
    run(input: SandboxJobRunInput, options?: SandboxJobRunOptions): Promise<SandboxJobRunResult>;
    /** Persists stop intent; terminal status is returned only after actual execution and host settlement. */
    cancel(input: {
        jobId: string;
    }): Promise<SandboxJobSnapshot>;
    /** Returns the active tenant's persisted Job snapshot, or null when inaccessible or absent. */
    getJob(input: {
        jobId: string;
    }): Promise<SandboxJobSnapshot | null>;
    /** Checks readiness before a product exposes or enqueues a browser-backed operation. */
    getActionHealth(input: {
        pluginName: string;
        action: string;
        actionVersion: string;
    }): Promise<SandboxJobActionHealth>;
}
/** Error carrying retry policy and Job identity across plugin queue handlers. */
export declare class SandboxJobRuntimeError extends Error {
    readonly code: SandboxJobErrorCode;
    readonly retryable: boolean;
    readonly jobId?: string;
    constructor(code: SandboxJobErrorCode, message: string, retryable: boolean, jobId?: string);
}
/** Narrows an unknown failure to the structured Sandbox Jobs runtime error contract. */
export declare function isSandboxJobRuntimeError(error: unknown): error is SandboxJobRuntimeError;
/** Runtime capability key used to resolve SandboxJobsApi from the platform registry. */
export declare const SandboxJobsRuntimeCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<SandboxJobsApi>;
