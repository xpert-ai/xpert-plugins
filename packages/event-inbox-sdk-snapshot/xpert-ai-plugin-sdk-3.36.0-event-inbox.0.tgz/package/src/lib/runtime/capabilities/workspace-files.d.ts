import type { WorkspaceAppDataOptions, WorkspaceStorage } from './workspace-storage';
/** Logical workspace volume catalog supported by plugin-facing file APIs. */
export type WorkspaceFileCatalog = 'projects' | 'users' | 'knowledges' | 'skills' | 'xperts' | 'user-xperts';
/** Stable source identifier for portable workspace file references. */
export declare const WORKSPACE_FILES_SOURCE: "platform.workspace.files";
/**
 * Scope fields used to resolve a workspace Volume.
 * Project types (including Spaces) share the projects catalog and projectId;
 * plugin resource IDs belong to content-resource metadata, not storage scope.
 *
 * Explicit APIs can provide catalog plus the matching id directly. Runtime-aware
 * APIs usually receive these fields from the current Agent execution context.
 */
export type WorkspaceFileScope = {
    tenantId?: string | null;
    organizationId?: string | null;
    userId?: string | null;
    catalog?: WorkspaceFileCatalog | null;
    scopeId?: string | null;
    projectId?: string | null;
    knowledgeId?: string | null;
    rootId?: string | null;
    xpertId?: string | null;
    isolateByUser?: boolean | null;
};
/**
 * Input for uploading raw bytes into an explicitly scoped workspace Volume.
 *
 * Use `writeRuntimeBuffer()` instead when a plugin writes into the current Agent
 * runtime workspace and wants the platform to infer project/Xpert scope.
 */
export type WorkspaceUploadBufferInput = WorkspaceFileScope & {
    buffer: Buffer;
    originalName: string;
    mimeType?: string | null;
    size?: number | null;
    folder?: string | null;
    fileName?: string | null;
    metadata?: Record<string, unknown>;
};
/**
 * Scoped reference to an existing workspace file.
 *
 * `filePath` is always a Volume-relative path, not a sandbox absolute path such
 * as `/workspace/...` and not a host/API-process filesystem path.
 */
export type WorkspaceFileReference = WorkspaceFileScope & {
    filePath: string;
};
/**
 * Agent-facing locator for a file in the current runtime workspace.
 *
 * Callers may provide sandbox paths such as `/workspace/report.docx`,
 * workspace-relative paths such as `report.docx`, or metadata aliases commonly
 * produced by tool calls.
 */
export type WorkspaceRuntimeFileDescriptor = {
    path?: string | null;
    filePath?: string | null;
    workspacePath?: string | null;
    originalName?: string | null;
    name?: string | null;
    mimeType?: string | null;
    mimetype?: string | null;
    size?: number | null;
};
/**
 * Persistable workspace file reference produced by the platform.
 *
 * Unlike a sandbox absolute path, this reference carries enough scope metadata
 * to read the same file later from queues, callbacks, or async jobs.
 */
export type WorkspacePortableFileReference = WorkspaceFileReference & {
    source: typeof WORKSPACE_FILES_SOURCE;
    workspacePath: string;
    originalName?: string | null;
    name?: string | null;
    mimeType?: string | null;
    size?: number | null;
};
/** Input accepted by runtime-aware workspace file APIs. */
export type WorkspaceFileLocator = string | WorkspaceRuntimeFileDescriptor | WorkspacePortableFileReference;
/**
 * Metadata returned by workspace file operations.
 *
 * `filePath` is the stable Volume-relative path. `workspacePath` is the
 * runtime/sandbox-facing path when one is available.
 */
export type WorkspaceFile = {
    name: string;
    filePath: string;
    workspacePath: string;
    fileUrl?: string;
    url?: string;
    mimeType?: string;
    size?: number;
    catalog: WorkspaceFileCatalog;
    scopeId?: string;
    metadata?: Record<string, unknown>;
};
/** Workspace file metadata plus raw file bytes. */
export type WorkspaceFileBuffer = WorkspaceFile & {
    buffer: Buffer;
};
/** Workspace file bytes plus the portable reference used to retrieve them. */
export type WorkspaceRuntimeFileBuffer = WorkspaceFileBuffer & {
    reference: WorkspacePortableFileReference;
};
/**
 * Runtime-aware write input for bytes created by tools or plugins.
 *
 * If a path is provided, it is interpreted as a workspace path in the scoped
 * runtime, not as a host/API-process filesystem path.
 */
export type WorkspaceRuntimeWriteInput = WorkspaceFileScope & WorkspaceRuntimeFileDescriptor & {
    buffer: Buffer;
    originalName?: string | null;
    folder?: string | null;
    fileName?: string | null;
    metadata?: Record<string, unknown>;
};
/**
 * Input for registering an existing workspace file with the file-understanding
 * pipeline.
 *
 * The file must already exist in the scoped workspace Volume identified by
 * `filePath` and the scope fields.
 */
export type WorkspaceUnderstandFileInput = WorkspaceFileReference & {
    originalName?: string | null;
    mimeType?: string | null;
    size?: number | null;
    fileUrl?: string | null;
    url?: string | null;
    purpose?: 'chat_attachment' | 'workspace' | 'knowledge';
    parseMode?: 'auto' | 'fast' | 'deep' | 'none';
    conversationId?: string | null;
    threadId?: string | null;
    projectId?: string | null;
    xpertId?: string | null;
    metadata?: Record<string, unknown>;
    runInline?: boolean | null;
};
/** File-understanding asset metadata created from a workspace file. */
export type WorkspaceUnderstoodFile = WorkspaceFile & {
    id: string;
    fileId: string;
    fileAssetId: string;
    storageFileId?: string;
    originalName?: string;
    status: string;
    parseStatus: string;
    purpose?: string;
    parseMode?: string;
    capabilities?: string[];
    summary?: string;
};
export type WorkspaceUnderstandingVectorStatus = 'pending' | 'ready' | 'failed' | 'unavailable';
export type WorkspaceUnderstandingStatusInput = WorkspaceFileScope & {
    fileAssetId: string;
};
/** Compact readiness DTO for an understood file. It never contains parsed text. */
export type WorkspaceUnderstandingStatus = {
    fileAssetId: string;
    status: string;
    parseMode: string;
    capabilities: string[];
    chunkCount: number;
    indexedChunkCount: number;
    vectorIndexStatus: WorkspaceUnderstandingVectorStatus;
    errorCode?: string;
    parsedAt?: string;
};
export type WorkspaceRetryUnderstandingInput = WorkspaceUnderstandingStatusInput;
export type WorkspaceUnderstandingReferenceInput = {
    fileAssetId: string;
    chunkId: string;
};
export type WorkspaceValidateUnderstandingReferencesInput = WorkspaceFileScope & {
    references: WorkspaceUnderstandingReferenceInput[];
    excerptLength?: number;
};
export type WorkspaceValidatedUnderstandingReference = {
    fileAssetId: string;
    chunkId: string;
    orderNo: number;
    anchor?: Record<string, unknown>;
    excerpt: string;
};
/** Scoped, bounded FileChunk DTO for plugin-owned evidence mapping. */
export type WorkspaceUnderstandingChunk = {
    /** FileAsset that owns the parsed chunk. */
    fileAssetId: string;
    /** Stable FileChunk identifier suitable for evidence references. */
    chunkId: string;
    /** Parser order within the source document. */
    orderNo: number;
    /** Parser-specific page, sheet, slide, or block location. */
    anchor?: Record<string, unknown>;
    /** Bounded source text; callers must not assume it contains the whole file. */
    content: string;
};
/** Input for paging an already parsed FileAsset without creating a second index. */
export type WorkspaceListUnderstandingChunksInput = WorkspaceFileScope & {
    fileAssetId: string;
    /** One-based page number. */
    page?: number;
    /** Page size clamped by the host. */
    pageSize?: number;
    /** Maximum characters returned for each chunk. */
    contentLength?: number;
};
/** One bounded page from the FileAsset's existing FileChunk index. */
export type WorkspaceUnderstandingChunkPage = {
    fileAssetId: string;
    /** Chunks in parser order for the requested page. */
    items: WorkspaceUnderstandingChunk[];
    page: number;
    pageSize: number;
    /** True when another bounded page can be requested. */
    hasMore: boolean;
};
/** Input for hybrid search over a FileAsset's existing FileChunk index. */
export type WorkspaceSearchUnderstandingChunksInput = WorkspaceFileScope & {
    fileAssetId: string;
    /** Natural-language or keyword query evaluated by the platform hybrid index. */
    query: string;
    /** Result count clamped by the host. */
    limit?: number;
    /** Maximum characters returned for each matching chunk. */
    contentLength?: number;
};
/**
 * Runtime capability contract for reading, writing, uploading, deleting, and
 * understanding files in Xpert workspace Volumes.
 */
export interface WorkspaceFilesApi {
    /** Managed .apps data in the bound Assistant workspace. Each operation reauthorizes the actor.
     * Ordinary Files/sandbox access cannot access this namespace. Requires a scoped runtime API. */
    appData(options: WorkspaceAppDataOptions): WorkspaceStorage;
    /** Host-bound storage identity for restoring the same scope in durable jobs. */
    readonly scope?: Readonly<WorkspaceFileScope>;
    /** Upload raw bytes into an explicitly scoped workspace Volume. */
    uploadBuffer(input: WorkspaceUploadBufferInput): Promise<WorkspaceFile>;
    /** Register an existing workspace file with the platform understanding pipeline. */
    understandFile(input: WorkspaceUnderstandFileInput): Promise<WorkspaceUnderstoodFile>;
    /** Return compact parsing and semantic-index readiness for one scoped FileAsset. */
    getUnderstandingStatus(input: WorkspaceUnderstandingStatusInput): Promise<WorkspaceUnderstandingStatus>;
    /** Retry parsing and semantic indexing for one failed scoped FileAsset. */
    retryUnderstanding(input: WorkspaceRetryUnderstandingInput): Promise<WorkspaceUnderstandingStatus>;
    /** Validate bounded FileAsset/chunk evidence without returning complete file contents. */
    validateUnderstandingReferences(input: WorkspaceValidateUnderstandingReferencesInput): Promise<WorkspaceValidatedUnderstandingReference[]>;
    /** List one bounded page of parsed chunks after enforcing FileAsset workspace scope. */
    listUnderstandingChunks(input: WorkspaceListUnderstandingChunksInput): Promise<WorkspaceUnderstandingChunkPage>;
    /** Search the existing FileChunk hybrid index without creating another embedding index. */
    searchUnderstandingChunks(input: WorkspaceSearchUnderstandingChunksInput): Promise<WorkspaceUnderstandingChunk[]>;
    /**
     * Resolve metadata and an openable URL for an explicitly scoped workspace
     * file without reading its bytes into the API process.
     */
    resolveFile(input: WorkspaceFileReference): Promise<WorkspaceFile>;
    /**
     * Read raw bytes from an explicitly scoped workspace file reference.
     * Missing paths or an uninitialized volume root reject with `error.code === 'ENOENT'`
     * in-process; other validation/access failures must not be treated as missing files.
     */
    readBuffer(input: WorkspaceFileReference): Promise<WorkspaceFileBuffer>;
    /** Delete an explicitly scoped workspace file; missing paths/roots reject with code ENOENT in-process. */
    deleteFile(input: WorkspaceFileReference): Promise<void>;
    /**
     * Normalize a runtime locator into a portable, scope-aware reference without
     * reading the file bytes.
     */
    resolveRuntimeReference(input: WorkspaceFileLocator): Promise<WorkspacePortableFileReference>;
    /**
     * Read bytes from a runtime locator using the current Agent workspace scope.
     *
     * This is the preferred API for plugin tools that receive `/workspace/...`
     * paths from sandbox commands.
     * After resolving the locator, missing paths/roots reject with code ENOENT in-process.
     * Callers must not infer missing files from localized validation or access errors.
     */
    readRuntimeBuffer(input: WorkspaceFileLocator): Promise<WorkspaceRuntimeFileBuffer>;
    /**
     * Write bytes into the current runtime workspace and return a portable
     * reference suitable for delayed processing or queue retries.
     */
    writeRuntimeBuffer(input: WorkspaceRuntimeWriteInput): Promise<WorkspaceFile & {
        reference: WorkspacePortableFileReference;
    }>;
}
/** Workspace file operations used by media generation tools. */
export type WorkspaceMediaFilesApi<TLocator extends WorkspaceFileLocator = WorkspaceFileLocator> = Pick<WorkspaceFilesApi, 'uploadBuffer' | 'readBuffer'> & {
    readRuntimeBuffer?: (input: TLocator) => Promise<WorkspaceFileBuffer>;
    deleteFile?: WorkspaceFilesApi['deleteFile'];
};
export declare const WorkspaceFilesRuntimeCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<WorkspaceFilesApi>;
