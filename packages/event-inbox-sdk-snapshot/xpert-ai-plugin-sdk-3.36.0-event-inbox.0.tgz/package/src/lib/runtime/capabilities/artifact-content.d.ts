import type { WorkspacePortableFileReference, WorkspaceFileBuffer } from './workspace-files';
/** Content owned by an Artifact, isolated from generic Project/Assistant file access. */
export interface ArtifactContentApi {
    write(input: {
        artifactId: string;
        buffer: Buffer;
    }): Promise<WorkspacePortableFileReference>;
    /** Reauthorizes a published version or the working draft owning these exact bytes. */
    read(reference: WorkspacePortableFileReference): Promise<WorkspaceFileBuffer>;
}
export declare const ArtifactContentRuntimeCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<ArtifactContentApi>;
