import type { XpertProjectTypeRef } from '@xpert-ai/contracts';
/** Lifecycle states that plugin-managed Projects may synchronize to the platform. */
export type ProjectProvisioningStatus = 'active' | 'archived';
/** Portable identity of one expected direct External Assistant binding. */
export type ProjectExternalAssistantExpectation = {
    pluginName: string;
    templateKey: string;
    agentKey: string;
};
/** A requested portable role resolved to an authorized Assistant; not proof of Project membership. */
export type ProjectAssistantBinding = ProjectExternalAssistantExpectation & {
    xpertId: string;
};
/** Stable identity and desired state for an idempotently provisioned Chat Project. */
export type ProjectEnsureInput = {
    /** Registered application type. Omission preserves legacy unclassified callers. */
    projectType?: XpertProjectTypeRef;
    /** Caller-generated id reused across retries to prevent duplicate Projects. */
    projectId: string;
    /** @deprecated Projects no longer belong to a Workspace. Accepted only for legacy callers. */
    workspaceId?: string;
    /** Creation seed: this Assistant and all recursive External Assistants join a new Project. Existing membership is preserved. */
    xpertId: string;
    /** Primary requester Agent used as the trust anchor for direct External Assistants. */
    requesterAgentKey?: string;
    /** Portable External Assistant identities that must all validate before any Project mutation. */
    externalAssistantExpectations?: ProjectExternalAssistantExpectation[];
    /** Current business-project display name. */
    name: string;
    /** Current business-project lifecycle state. */
    status: ProjectProvisioningStatus;
};
/** Effective Project state after an idempotent ensure operation. */
export type ProjectEnsureResult = {
    projectId: string;
    /** @deprecated Echoed only when supplied by a legacy caller. */
    workspaceId?: string;
    /** Persisted Assistant members; ensure never restores removed members or adds new graph dependencies to an existing Project. */
    xpertIds: string[];
    /** Bindings for the requested role expectations, not all members. Check xpertIds before assigning an executor. */
    assistantBindings: ProjectAssistantBinding[];
    /**
     * `created` inserts a new Project; `updated` reuses an existing Project and ensures its content is initialized.
     * `updated` does not guarantee metadata changes: direct creation retries preserve existing names and status.
     */
    operation: 'created' | 'updated';
};
/** Host API exposed to plugins that own one-to-one business Project mappings. */
export interface ProjectProvisioningApi {
    /** App-only confirmation of a pending conversation's first Project; never moves an existing binding. */
    confirmConversation?(input: {
        conversationId: string;
        xpertId: string;
        confirmationId: string;
        name: string;
        configuration: object;
    }): Promise<{
        projectId: string;
    }>;
    /** Create or reconcile a Chat Project without changing its caller-supplied id. */
    ensure(input: ProjectEnsureInput): Promise<ProjectEnsureResult>;
    /** Check the permanent-deletion fence while the caller holds its business record lock, before restoring. */
    assertRestorable?(input: {
        projectId: string;
        xpertId: string;
    }): Promise<void>;
    /** Owner-only physical deletion of an archived plugin-bound Project and its workspace. */
    purge?(input: {
        projectId: string;
        xpertId: string;
    }): Promise<{
        projectId: string;
        deleted: boolean;
    }>;
}
export declare const ProjectProvisioningRuntimeCapability: import("../../core/runtime-capability").RuntimeCapabilityKey<ProjectProvisioningApi>;
