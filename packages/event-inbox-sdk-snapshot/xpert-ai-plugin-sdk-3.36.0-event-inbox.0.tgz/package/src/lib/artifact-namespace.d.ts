/**
 * Derive the v1 default artifact namespace from an npm package name.
 * Explicit `artifactNamespace` should stay stable after publish; this fallback is for compatibility.
 */
export declare function derivePluginArtifactNamespace(packageName: string): string;
/**
 * Build the physical table name for a plugin-owned database table.
 * Keep table keys stable; the returned name is part of the plugin data contract.
 */
export declare function pluginArtifactTableName(namespace: string, tableKey: string): string;
export declare function isPluginArtifactNamespace(value: unknown): value is string;
