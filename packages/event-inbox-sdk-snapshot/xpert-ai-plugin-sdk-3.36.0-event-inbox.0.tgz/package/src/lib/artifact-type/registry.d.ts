import { DiscoveryService, Reflector } from '@nestjs/core';
import type { ArtifactTypeBinding, ArtifactTypeReference } from '@xpert-ai/contracts';
import { BaseStrategyRegistry, type StrategySource } from '../strategy';
import { type IArtifactTypeProvider } from './index';
export declare const artifactTypeKey: (type: ArtifactTypeReference) => string;
export declare const FILE_ARTIFACT_TYPE: ArtifactTypeReference;
/** Bindings pin registration scope. Removal never falls back to a different installation or plain file. */
export declare class ArtifactTypeRegistry extends BaseStrategyRegistry<IArtifactTypeProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
    upsert(instance: unknown): void;
    registerBuiltin(type: ArtifactTypeReference, provider: IArtifactTypeProvider): void;
    assertCanRegister(key: string, provider: IArtifactTypeProvider, source: StrategySource): void;
    bind(type: ArtifactTypeReference, scope: {
        tenantId?: string | null;
        organizationId?: string | null;
    }): ArtifactTypeBinding;
    hasType(type: ArtifactTypeReference, scope: {
        tenantId?: string | null;
        organizationId?: string | null;
    }): boolean;
    requireBinding(binding: ArtifactTypeBinding, scope: {
        tenantId?: string | null;
        organizationId?: string | null;
    }): IArtifactTypeProvider;
}
