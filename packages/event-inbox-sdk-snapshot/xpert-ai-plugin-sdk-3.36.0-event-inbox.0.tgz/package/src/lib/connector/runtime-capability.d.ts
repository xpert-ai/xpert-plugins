import type { RuntimeIdentityScope } from '../runtime/runtime-scope';
import type { ConnectorRuntimeApi } from './strategy.interface';
export declare const ConnectorRuntimeCapability: import("../core").RuntimeCapabilityKey<ConnectorRuntimeApi>;
/** No binding or provider grants means no connector access. */
export type ConnectorRuntimeScope = RuntimeIdentityScope & {
    /** Server-owned View host identity, set only after the host authorizes the Assistant and its graph. */
    viewHost?: {
        type: 'agent';
        id: string;
    };
    /** Host-validated Agent Plugin dependencies may use their workspace binding in an authorized project. */
    allowWorkspaceBindingsInProject?: boolean;
    /** Host-selected bindings, including IDs pinned by enabled graph Connector nodes. */
    connectorBindingIds?: string[] | null;
    /** Providers configured by enabled graph Connector nodes without a pinned ID. */
    connectorProviders?: string[] | null;
};
export type SelectedRuntimeConnectorBinding = {
    bindingId: string;
    provider: string;
};
export interface ConnectorRuntimeFactory {
    /** Snapshot the authorized identity and connector grants for this runtime. */
    createScopedApi(scope: ConnectorRuntimeScope): ConnectorRuntimeApi;
    /** Preflight selected bindings through the same identity, project and credential checks. */
    resolveSelectedRuntimeBindings(bindingIds: string[] | null | undefined, scope: ConnectorRuntimeScope): Promise<SelectedRuntimeConnectorBinding[]>;
}
export declare const ConnectorRuntimeFactoryCapability: import("../core").RuntimeCapabilityKey<ConnectorRuntimeFactory>;
