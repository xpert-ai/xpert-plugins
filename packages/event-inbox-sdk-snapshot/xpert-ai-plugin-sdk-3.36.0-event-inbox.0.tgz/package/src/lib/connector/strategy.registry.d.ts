import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { type ConnectorStrategy, type ConnectorStrategyRuntime } from './strategy.interface';
export declare class ConnectorStrategyRegistry extends BaseStrategyRegistry<ConnectorStrategyRuntime> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    upsert(instance: unknown): void;
    get(type: string, organizationId?: string): ConnectorStrategy;
    list(organizationId?: string): ConnectorStrategy[];
    getRuntime(type: string, organizationId?: string): ConnectorStrategyRuntime;
    listRuntime(organizationId?: string): ConnectorStrategyRuntime[];
}
