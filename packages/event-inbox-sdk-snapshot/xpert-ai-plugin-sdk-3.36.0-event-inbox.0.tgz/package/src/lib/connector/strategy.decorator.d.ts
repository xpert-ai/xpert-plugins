export declare const CONNECTOR_STRATEGY = "CONNECTOR_STRATEGY";
export declare const ConnectorStrategyKey: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
