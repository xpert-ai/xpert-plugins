import type { ConnectorDocumentSource } from './document-source';
import type { I18nText, IconDefinition } from '@xpert-ai/contracts';
export type RuntimeI18nText = I18nText;
export type RuntimeCapabilityIcon = IconDefinition;
export type ConnectorStatus = 'pending' | 'active' | 'expired' | 'error' | 'disconnected';
export declare const CONNECTOR_SCOPE_TYPES: readonly ["workspace", "project"];
export type ConnectorScopeType = (typeof CONNECTOR_SCOPE_TYPES)[number];
export type ConnectorScope = {
    type: 'workspace';
    workspaceId: string;
} | {
    type: 'project';
    projectId: string;
};
export declare const CONNECTOR_AUTHORIZATION_MODES: readonly ["personal", "shared"];
export type ConnectorAuthorizationMode = (typeof CONNECTOR_AUTHORIZATION_MODES)[number];
export type ConnectorOAuthConfig = {
    type: 'oauth2';
    authorizationUrl?: string;
    tokenUrl?: string;
    userInfoUrl?: string;
    scopes?: string[];
    redirectPath?: string;
};
export type ConnectorAppCredentialField = {
    name: string;
    label: RuntimeI18nText;
    type?: 'text' | 'password';
    required?: boolean;
    placeholder?: RuntimeI18nText;
    description?: RuntimeI18nText;
    secret?: boolean;
};
export type ConnectorAppCredentialsConfig = {
    fields?: ConnectorAppCredentialField[];
    /** Persist application credentials in a system integration; connections only retain its ID. */
    integration?: {
        provider: string;
        fields: ConnectorAppCredentialField[];
    };
    help?: {
        label: RuntimeI18nText;
        url: string;
    };
    defaultValues?: Record<string, string | number | boolean | null>;
};
export type ConnectorCredentialFormDefinition = ConnectorAppCredentialsConfig;
export type ConnectorAuthorizationPresentation = {
    mode: 'embedded_qr';
    title: RuntimeI18nText;
    description: RuntimeI18nText;
    ariaLabel: RuntimeI18nText;
    completionHint: RuntimeI18nText;
    cancelLabel: RuntimeI18nText;
    copyLinkLabel: RuntimeI18nText;
    copyLinkError: RuntimeI18nText;
};
type ConnectorAuthMethodBase = {
    id: string;
    label: RuntimeI18nText;
    /** Retained for stored credentials and in-flight callbacks, not new authorizations. */
    deprecated?: boolean;
    authorizationPresentation?: ConnectorAuthorizationPresentation;
};
export type ConnectorAuthMethodDefinition = ConnectorAuthMethodBase & ({
    type: 'oauth2';
    appCredentials?: ConnectorCredentialFormDefinition;
} | {
    type: 'api_key';
    credentials: ConnectorCredentialFormDefinition;
});
export type ConnectorPermissionDeclaration = {
    key: string;
    label?: RuntimeI18nText;
    description?: RuntimeI18nText;
    identity?: 'user' | 'app' | 'tenant';
    scopes?: string[];
    credential?: 'access_token' | 'refresh_token' | 'app_credential' | 'api_key';
    storage?: 'platform_vault' | 'runtime_only' | 'external';
    required?: boolean;
};
export type ConnectorDefinitionBase = {
    /** Explicit MCP resources whose old generic OAuth connections this provider can replace. */
    mcpOAuthResources?: string[];
    /** Native provider used by a compatibility definition that retains its old provider ID. */
    canonicalProvider?: string;
    /** Imported dependency is visible but its provider is not installed in this scope. */
    unavailable?: string;
    runtimeUsage?: 'middleware' | 'credential';
    provider: string;
    label: RuntimeI18nText;
    description?: RuntimeI18nText;
    icon?: RuntimeCapabilityIcon;
    permissions?: ConnectorPermissionDeclaration[];
    /** Credential ownership modes supported by this provider. Legacy providers are shared-only. */
    authorizationModes?: ConnectorAuthorizationMode[];
    /** Maps credentials stored before multi-auth support to a declared OAuth method. */
    legacyAuthMethodId?: string;
};
export type ConnectorDefinition = ConnectorDefinitionBase & {
    auth: ConnectorOAuthConfig;
    appCredentials?: ConnectorAppCredentialsConfig;
};
export type ConnectorMultiAuthDefinition = ConnectorDefinitionBase & {
    authMethods: ConnectorAuthMethodDefinition[];
    /** Optional legacy OAuth metadata used by host compatibility adapters. */
    auth?: ConnectorOAuthConfig;
    appCredentials?: ConnectorAppCredentialsConfig;
};
export type ConnectorStrategyDefinition = ConnectorDefinition | ConnectorMultiAuthDefinition;
export declare function getConnectorAuthMethods(definition: ConnectorStrategyDefinition): ConnectorAuthMethodDefinition[];
export declare function getConnectorAuthorizationModes(definition: ConnectorStrategyDefinition): ConnectorAuthorizationMode[];
export declare function assertConnectorDefinition(definition: unknown): asserts definition is ConnectorStrategyDefinition;
export type ConnectorProfile = {
    openId?: string;
    unionId?: string;
    userId?: string;
    name?: string;
    avatarUrl?: string;
    email?: string;
    [key: string]: unknown;
};
export type ConnectorInstance = {
    id: string;
    /** @deprecated Prefer scope. */
    workspaceId?: string | null;
    projectId?: string | null;
    scopeType?: ConnectorScopeType;
    scope?: ConnectorScope;
    authorizationMode?: ConnectorAuthorizationMode;
    provider: string;
    authMethodId?: string | null;
    /** Selected application configuration, never its secrets. */
    appIntegrationId?: string | null;
    status: ConnectorStatus;
    profile?: ConnectorProfile | null;
    scopes?: string[];
    expiresAt?: string | null;
    refreshExpiresAt?: string | null;
    connectedAt?: string | null;
    disconnectedAt?: string | null;
    lastError?: string | null;
    createdById?: string | null;
    updatedById?: string | null;
    createdAt?: string;
    updatedAt?: string;
};
export type ConnectorBinding = ConnectorInstance & {
    scopeType: ConnectorScopeType;
    scope: ConnectorScope;
    authorizationMode: ConnectorAuthorizationMode;
};
export type ConnectorBindingCreateRequest = {
    scope: ConnectorScope;
    provider: string;
    authorizationMode: ConnectorAuthorizationMode;
};
export type ConnectorRuntimeOption = {
    canonicalProvider?: string;
    scope?: ConnectorScope;
    canManage?: boolean;
    managementUrl?: string;
    runtimeUsage?: 'middleware' | 'credential';
    bindingId: string;
    provider: string;
    authorizationMode: ConnectorAuthorizationMode;
    status: ConnectorStatus;
    granted: boolean;
    label: RuntimeI18nText;
    description?: RuntimeI18nText;
    icon?: RuntimeCapabilityIcon;
    /** Sanitized authentication forms needed to connect the current user's account. */
    authMethods?: ConnectorAuthMethodDefinition[];
    profile?: ConnectorProfile | null;
};
export type ConnectorRuntimeOptions = {
    workspaceScope?: ConnectorScope;
    canManageWorkspace?: boolean;
    managementUrl?: string;
    scope: ConnectorScope;
    items: ConnectorRuntimeOption[];
};
export type ConnectorPersonalAccountInstance = {
    id: string;
    provider: string;
    status: ConnectorStatus;
    authMethodId?: string | null;
    profile?: ConnectorProfile | null;
    scopes?: string[];
    expiresAt?: string | null;
    connectedAt?: string | null;
    disconnectedAt?: string | null;
    lastError?: string | null;
};
export type ConnectorOAuthStartRequest = {
    app?: ConnectorAppCredentialPayload;
};
export type ConnectorConnectRequest = {
    authMethodId?: string;
    values?: ConnectorAppCredentialPayload;
    /** Assistant proving run access when a non-member authorizes a personal Workspace connector. */
    xpertId?: string;
    /** @deprecated Use values instead. */
    app?: ConnectorAppCredentialPayload;
};
export type ConnectorConnectResponse = {
    status: 'active' | 'pending';
    connector: ConnectorInstance;
    authorizationUrl?: string | null;
    stateExpiresAt?: string | null;
    pollIntervalSeconds?: number | null;
};
export type ConnectorOAuthStartResponse = {
    connector: ConnectorInstance;
    authorizationUrl: string;
    stateExpiresAt: string;
    pollIntervalSeconds?: number | null;
};
export type ConnectorOAuthStatusResponse = {
    connector: ConnectorInstance;
    /** Whether this binding currently has a usable credential for the requesting user. */
    granted?: boolean;
    authorizationUrl?: string | null;
    stateExpiresAt?: string | null;
    pollIntervalSeconds?: number | null;
    message?: string | null;
};
export type ConnectorRuntimeCredential = {
    connectorId: string;
    bindingId: string;
    scope: ConnectorScope;
    authorizationMode: ConnectorAuthorizationMode;
    workspaceId?: string | null;
    projectId?: string | null;
    provider: string;
    appId: string;
    brand?: string;
    accessToken: string;
    expiresAt?: string | null;
    scopes?: string[];
    profile?: ConnectorProfile | null;
};
export type ConnectorRuntimeCredentialV2 = {
    connectorId: string;
    bindingId: string;
    scope: ConnectorScope;
    authorizationMode: ConnectorAuthorizationMode;
    workspaceId?: string | null;
    projectId?: string | null;
    provider: string;
    authMethodId: string;
    credentials: Record<string, unknown>;
    expiresAt?: string | null;
    scopes?: string[];
    profile?: ConnectorProfile | null;
};
export type ConnectorRuntimeGetInput = {
    bindingId?: string;
    /** @deprecated Use bindingId. */
    workspaceId?: string;
    projectId?: string;
    provider?: string;
    /** @deprecated Use bindingId. */
    connectorId?: string;
};
export interface ConnectorRuntimeApi {
    getConnector(input: ConnectorRuntimeGetInput): Promise<ConnectorRuntimeCredential>;
    getConnectorCredential?(input: ConnectorRuntimeGetInput): Promise<ConnectorRuntimeCredentialV2>;
}
export type ConnectorSelectOption = {
    value: string;
    label: RuntimeI18nText;
    provider: string;
    status: ConnectorStatus;
    description?: RuntimeI18nText;
    avatarUrl?: string;
};
export type ConnectorAppCredentialPayload = Record<string, unknown>;
export type ConnectorAuthorizationUrlInput = {
    app?: ConnectorAppCredentialPayload;
    redirectUri: string;
    state: string;
    scopes?: string[];
};
export type ConnectorAuthorizationUrlResult = {
    authorizationUrl: string;
    scopes?: string[];
    metadata?: Record<string, unknown>;
    pollIntervalSeconds?: number | null;
};
export type ConnectorOAuthCodeInput = {
    app?: ConnectorAppCredentialPayload;
    code: string;
    redirectUri: string;
    scopes?: string[];
};
export type ConnectorRefreshInput = {
    app?: ConnectorAppCredentialPayload;
    refreshToken: string;
};
export type ConnectorOAuthCredential = {
    appId: string;
    brand?: string;
    /**
     * Provider app credentials retained only for encrypted platform storage and token refresh.
     * Hosts must not expose this field through public connector or runtime credential APIs.
     */
    app?: ConnectorAppCredentialPayload;
    accessToken: string;
    refreshToken?: string;
    expiresAt?: string | null;
    refreshExpiresAt?: string | null;
    scopes?: string[];
    profile?: ConnectorProfile | null;
};
export type ConnectorCredential = {
    data: ConnectorAppCredentialPayload;
    expiresAt?: string | null;
    refreshExpiresAt?: string | null;
    scopes?: string[];
    profile?: ConnectorProfile | null;
};
export type ConnectorProviderScope = {
    tenantId: string;
    organizationId: string | null;
};
export type ConnectorConnectInput = {
    scope?: ConnectorProviderScope;
    authMethodId: string;
    values?: ConnectorAppCredentialPayload;
    redirectUri: string;
    state: string;
    scopes?: string[];
};
export type ConnectorConnectResult = {
    status: 'pending';
    authorizationUrl: string;
    scopes?: string[];
    metadata?: Record<string, unknown>;
    pollIntervalSeconds?: number | null;
} | {
    status: 'active';
    credential: ConnectorCredential;
};
export type ConnectorAuthorizationCodeInput = {
    scope?: ConnectorProviderScope;
    authMethodId: string;
    values?: ConnectorAppCredentialPayload;
    metadata?: Record<string, unknown> | null;
    code: string;
    redirectUri: string;
    scopes?: string[];
};
export type ConnectorConnectionPollInput = {
    authMethodId: string;
    values?: ConnectorAppCredentialPayload;
    metadata?: Record<string, unknown> | null;
    redirectUri: string;
    scopes?: string[];
};
export type ConnectorConnectionPollResult = {
    status: 'pending';
    authorizationUrl?: string;
    metadata?: Record<string, unknown>;
    pollIntervalSeconds?: number | null;
    message?: string;
} | {
    status: 'complete';
    credential: ConnectorCredential;
    metadata?: Record<string, unknown>;
} | {
    status: 'error';
    error: string;
    metadata?: Record<string, unknown>;
};
export type ConnectorCredentialRefreshInput = {
    scope?: ConnectorProviderScope;
    authMethodId: string;
    credential: ConnectorCredential;
};
export type ConnectorCredentialRevokeReason = 'disconnect' | 'delete' | 'rotate';
export type ConnectorCredentialRevokeInput = {
    authMethodId: string;
    credential: ConnectorCredential;
    reason: ConnectorCredentialRevokeReason;
};
export type ConnectorRuntimeCredentialResolveInput = {
    scope?: ConnectorProviderScope;
    authMethodId: string;
    credential: ConnectorCredential;
};
export type ConnectorOAuthCompleteRequest = {
    state: string;
    code: string;
};
export type ConnectorAuthorizationPollInput = {
    metadata?: Record<string, unknown> | null;
    redirectUri: string;
    scopes?: string[];
};
export type ConnectorAuthorizationPollResult = {
    status: 'pending';
    authorizationUrl?: string;
    metadata?: Record<string, unknown>;
    pollIntervalSeconds?: number | null;
    message?: string;
} | {
    status: 'complete';
    credential: ConnectorOAuthCredential;
    metadata?: Record<string, unknown>;
} | {
    status: 'error';
    error: string;
    metadata?: Record<string, unknown>;
};
export interface ConnectorStrategyRuntime {
    /** Optional read-only document adapter, independent of knowledge ingestion and remote editing. */
    documents?: ConnectorDocumentSource;
    definition: ConnectorStrategyDefinition;
    connect?(input: ConnectorConnectInput): Promise<ConnectorConnectResult>;
    exchangeAuthorizationCode?(input: ConnectorAuthorizationCodeInput): Promise<ConnectorCredential>;
    pollConnection?(input: ConnectorConnectionPollInput): Promise<ConnectorConnectionPollResult>;
    refreshConnectionCredential?(input: ConnectorCredentialRefreshInput): Promise<ConnectorCredential>;
    /**
     * Revokes a provider-side credential before the host destroys a shared credential locally.
     * Implementations should be idempotent. Hosts remain compatible with providers that omit this hook.
     */
    revokeCredential?(input: ConnectorCredentialRevokeInput): Promise<void>;
    resolveRuntimeCredential?(input: ConnectorRuntimeCredentialResolveInput): Promise<Record<string, unknown>> | Record<string, unknown>;
    buildAuthorizationUrl?(input: ConnectorAuthorizationUrlInput): Promise<ConnectorAuthorizationUrlResult>;
    exchangeOAuthCode?(input: ConnectorOAuthCodeInput): Promise<ConnectorOAuthCredential>;
    refreshCredential?(input: ConnectorRefreshInput): Promise<ConnectorOAuthCredential>;
    pollAuthorization?(input: ConnectorAuthorizationPollInput): Promise<ConnectorAuthorizationPollResult>;
}
export interface ConnectorStrategy extends ConnectorStrategyRuntime {
    definition: ConnectorDefinition;
    buildAuthorizationUrl(input: ConnectorAuthorizationUrlInput): Promise<ConnectorAuthorizationUrlResult>;
    exchangeOAuthCode(input: ConnectorOAuthCodeInput): Promise<ConnectorOAuthCredential>;
}
export interface ConnectorMultiAuthStrategy extends ConnectorStrategyRuntime {
    definition: ConnectorMultiAuthDefinition;
    connect(input: ConnectorConnectInput): Promise<ConnectorConnectResult>;
}
export {};
