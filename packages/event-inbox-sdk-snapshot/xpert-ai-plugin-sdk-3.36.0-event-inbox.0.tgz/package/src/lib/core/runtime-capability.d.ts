export type RuntimeCapabilityKey<T> = {
    readonly id: string;
    readonly description?: string;
    readonly __type?: T;
};
export declare function createRuntimeCapability<T>(id: string, options?: {
    description?: string;
}): RuntimeCapabilityKey<T>;
export interface RuntimeCapabilityRegistry {
    register<T>(key: RuntimeCapabilityKey<T> | string, implementation: T): this;
    has<T>(key: RuntimeCapabilityKey<T> | string): boolean;
    get<T>(key: RuntimeCapabilityKey<T> | string): T | undefined;
    require<T>(key: RuntimeCapabilityKey<T> | string): T;
}
/** Read-only capability view accepted by plugin-side consumers. */
export type RuntimeCapabilityResolver = Pick<RuntimeCapabilityRegistry, 'get'>;
export declare const XPERT_RUNTIME_CAPABILITIES_TOKEN = "XPERT_RUNTIME_CAPABILITIES";
/** Metadata key under which RuntimeCapabilityProviderExplorer discovers capability providers. */
export declare const RUNTIME_CAPABILITY_PROVIDER = "XPERT_RUNTIME_CAPABILITY_PROVIDER";
/** Tags a Nest provider as the platform implementation of a runtime capability. */
export declare const RuntimeCapabilityProvider: <T>(capability: RuntimeCapabilityKey<T>) => import("@nestjs/common").CustomDecorator<string>;
export declare class DefaultRuntimeCapabilityRegistry implements RuntimeCapabilityRegistry {
    private readonly parent?;
    private readonly capabilities;
    constructor(entries?: Array<[RuntimeCapabilityKey<unknown> | string, unknown]>, parent?: RuntimeCapabilityResolver);
    register<T>(key: RuntimeCapabilityKey<T> | string, implementation: T): this;
    has<T>(key: RuntimeCapabilityKey<T> | string): boolean;
    get<T>(key: RuntimeCapabilityKey<T> | string): T | undefined;
    require<T>(key: RuntimeCapabilityKey<T> | string): T;
}
