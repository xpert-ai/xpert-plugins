import { IApiKey, IRequestScopeContext, IUser, LanguagesEnum, PermissionsEnum, RolesEnum } from '@xpert-ai/contracts';
import type { IApiPrincipal } from '@xpert-ai/contracts';
import type { IncomingMessage, ServerResponse } from 'http';
import { AsyncLocalStorage } from 'node:async_hooks';
export declare class RequestContext {
    readonly request: IncomingMessage;
    readonly response: ServerResponse;
    readonly reqId: string;
    readonly userId?: string;
    readonly extras: Record<string, any>;
    constructor(request: IncomingMessage, response: ServerResponse, reqId: string, userId?: string, extras?: Record<string, any>);
    static currentRequestContext(): RequestContext;
    /** @deprecated For resource authorization use currentApiPrincipal()?.resourceScope; retained for credential metadata. */
    static currentApiKey(): IApiKey | null;
    static currentApiPrincipal(): IApiPrincipal | null;
    static currentRequest(): IncomingMessage;
    static currentTenantId(): string;
    static currentUserId(): string;
    static currentRoleId(): string;
    static currentUser(throwError?: boolean): IUser;
    static hasPermission(permission: PermissionsEnum | string, throwError?: boolean): boolean;
    /**
     * Retrieves the language code from the headers of the current request.
     * @returns The language code (LanguagesEnum) extracted from the headers, or the default language (ENGLISH) if not found.
     */
    static getLanguageCode(): LanguagesEnum;
    static getScope(): IRequestScopeContext;
    static getOrganizationId(): string | null;
    static isTenantScope(): boolean;
    static isOrganizationScope(): boolean;
    static requireOrganizationScope(): string;
    /**
     * Check the authenticated principal's enabled role permissions, matching the
     * server RequestContext. Authentication guards resolve JWTs, API keys and
     * ChatKit client secrets before this check; the bearer is not always a JWT.
     */
    static hasPermissions(findPermissions: Array<PermissionsEnum | string>, throwError?: boolean): boolean;
    static hasAnyPermission(findPermissions: PermissionsEnum[], throwError?: boolean): boolean;
    static currentToken(throwError?: boolean): any;
    /**
     * Checks if the current user has a specific role.
     * @param {RolesEnum} role - The role to check.
     * @param {boolean} throwError - Flag indicating whether to throw an error if the role is not granted.
     * @returns {boolean} - True if the user has the role, otherwise false.
     */
    static hasRole(role: RolesEnum, throwError?: boolean): boolean;
    /**
     * Checks if the current request context has any of the specified roles.
     *
     * @param roles - An array of roles to check.
     * @param throwError - Whether to throw an error if no roles are found.
     * @returns True if any of the required roles are found, otherwise false.
     */
    static hasRoles(roles: RolesEnum[], throwError?: boolean): boolean;
    private static currentPermissions;
}
/**
 * One process-wide context store shared by source, built, and dynamically loaded
 * copies of the Plugin SDK. Plugin class identity may differ; the async scope must not.
 */
export declare const als: AsyncLocalStorage<RequestContext>;
export declare function getRequestContext(): RequestContext;
