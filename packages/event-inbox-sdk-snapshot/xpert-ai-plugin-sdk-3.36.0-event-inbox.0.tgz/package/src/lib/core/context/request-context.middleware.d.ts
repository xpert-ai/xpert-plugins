import { IUser } from '@xpert-ai/contracts';
import { NestMiddleware } from '@nestjs/common';
import { IncomingMessage, ServerResponse } from 'node:http';
export declare class RequestContextMiddleware implements NestMiddleware {
    use(req: IncomingMessage, _res: ServerResponse, next: () => void): void;
}
export declare function runWithRequestContext(req: Partial<IncomingMessage> & {
    user?: IUser;
}, res: Partial<ServerResponse>, next: () => void): void;
