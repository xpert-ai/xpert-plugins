/**
 * Common UI Schema field definitions
 */
export interface ISchemaUIBase {
    component: string;
    label?: string;
    description?: string;
    placeholder?: string;
    order?: number;
    required?: boolean;
    visibleWhen?: Record<string, any>;
    enabledWhen?: Record<string, any>;
}
/**
 * Secret field extensions
 */
export interface ISchemaSecretField extends ISchemaUIBase {
    component: 'secretInput';
    revealable?: boolean;
    maskSymbol?: string;
    persist?: boolean;
}
