import { Logger } from '@nestjs/common';
import { JSONSchema4 } from 'json-schema';
export declare function loadYamlFile<T>(filePath: string, logger?: Logger, ignoreError?: boolean, defaultValue?: T): T;
/**
 * Get the mapping from name to index from a YAML file
 *
 * @param folderPath
 * @param fileName the YAML file name, default to '_position.yaml'
 * @return a dict with name as key and index as value
 */
export declare function getPositionMap(folderPath: string, fileName?: string, logger?: Logger): Record<string, number>;
export declare function getPositionList(folderPath: string, fileName?: string, logger?: Logger): string[];
export declare function getErrorMessage(err: any): string;
export declare class JsonSchemaValidator {
    private ajv;
    constructor();
    parseAndValidate(schemaStr?: string): JSONSchema4 | undefined;
}
