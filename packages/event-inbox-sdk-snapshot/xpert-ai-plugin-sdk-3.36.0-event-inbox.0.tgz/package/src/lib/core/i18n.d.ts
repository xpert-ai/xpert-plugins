import { i18n as I18nInstance } from 'i18next';
export declare function createI18nInstance(pluginDir: string, language?: string): Promise<I18nInstance>;
