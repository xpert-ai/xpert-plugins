import { StrategyEntry } from './types';
export type StrategyBusEvent<S = any> = {
    type: 'UPSERT';
    strategyType: string;
    entry: StrategyEntry<S>;
} | {
    type: 'REMOVE';
    strategyType?: string;
    pluginName: string;
    orgId: string;
    cause?: 'refresh' | 'uninstall';
};
export declare class StrategyBus {
    private readonly subject;
    readonly events$: import("rxjs").Observable<StrategyBusEvent<any>>;
    upsert<S>(strategyType: string, entry: StrategyEntry<S>): void;
    remove(orgId: string, pluginName: string, cause?: 'refresh' | 'uninstall'): void;
}
