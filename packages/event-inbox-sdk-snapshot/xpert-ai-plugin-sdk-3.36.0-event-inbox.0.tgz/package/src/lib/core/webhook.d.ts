import type { IApiPrincipal } from '@xpert-ai/contracts';
import { CanActivate, ExecutionContext } from '@nestjs/common';
export declare const PLUGIN_WEBHOOK_AUTH_METADATA_KEY = "xpert:plugin:webhook-auth";
export declare const PLUGIN_WEBHOOK_AUTH_SERVICE_TOKEN = "XPERT_PLUGIN_WEBHOOK_AUTH_SERVICE";
export type PluginWebhookAuthMetadata = {
    provider?: string;
    integrationParam?: string;
    secretQueryParam?: string;
};
export type PluginWebhookCredentialRecord = {
    id: string;
    tokenHash: string;
    tokenPrefix?: string;
    createdAt: string;
    rotatedAt?: string | null;
    revokedAt?: string | null;
};
export type PluginWebhookCredentialResult = {
    token: string;
    credential: PluginWebhookCredentialRecord;
};
export type PluginWebhookAuthRequest = {
    integrationId: string;
    secret: string;
    provider?: string | null;
};
export type PluginWebhookAuthResult = {
    user: IApiPrincipal;
    headers: Record<string, string>;
};
export interface PluginWebhookAuthService {
    validateWebhookSecret(input: PluginWebhookAuthRequest): Promise<PluginWebhookAuthResult | null>;
}
export declare function PluginWebhookAuth(metadata?: PluginWebhookAuthMetadata): import("@nestjs/common").CustomDecorator<string>;
export declare class PluginWebhookAuthGuard implements CanActivate {
    private readonly authService?;
    constructor(authService?: PluginWebhookAuthService | null);
    canActivate(context: ExecutionContext): Promise<boolean>;
    private resolveMetadata;
    private getString;
}
