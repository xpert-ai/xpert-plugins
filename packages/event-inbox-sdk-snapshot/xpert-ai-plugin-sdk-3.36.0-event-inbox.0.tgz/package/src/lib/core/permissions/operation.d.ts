export interface PermissionOperationMetadata<TPermissionType extends string = string, TOperation extends string = string> {
    permissionType: TPermissionType;
    operation: TOperation;
}
export declare const PERMISSION_OPERATION_METADATA_KEY = "XPERT_PLUGIN_PERMISSION_OPERATION";
export declare function RequirePermissionOperation<TPermissionType extends string, TOperation extends string>(permissionType: TPermissionType, operation: TOperation): MethodDecorator;
export declare function getPermissionOperationMetadata(method: unknown): PermissionOperationMetadata | undefined;
export declare function getRequiredPermissionOperation<TOperation extends string = string>(method: unknown, permissionType: string): TOperation | undefined;
