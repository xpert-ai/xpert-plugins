import type { IntegrationUsage, IntegrationUsageScope } from '@xpert-ai/contracts';
import type { IIntegration, IPagination } from '@xpert-ai/contracts';
import type { PluginWebhookCredentialResult } from '../webhook';
/**
 * Base Permission type
 */
export interface BasePermission {
    type: string;
    description?: string;
}
export type IntegrationPermissionOperation = 'read' | 'write' | 'update' | 'delete';
/**
 * 1. LLM Permission
 * Example: { type: 'llm', provider: 'openai', capability: 'vision' }
 */
export interface LLMPermission extends BasePermission {
    type: 'llm';
    provider?: string;
    capability: 'text' | 'chat' | 'vision' | 'embedding';
    scope?: string[];
    maxTokens?: number;
    rateLimit?: {
        rps: number;
    };
}
/**
 * 2. Vector Store Permission
 * Example: { type: 'vectorstore', provider: 'pinecone', operations: ['insert', 'query'] }
 */
export interface VectorStorePermission extends BasePermission {
    type: 'vectorstore';
    provider: string;
    operations: Array<'insert' | 'query' | 'delete'>;
    scope?: string[];
}
/**
 * 3. Knowledge Base Permission
 * Example: { type: 'knowledge', operations: ['read', 'write'], scope: ['kb_123'] }
 */
export interface KnowledgePermission extends BasePermission {
    type: 'knowledge';
    operations: Array<'read' | 'write' | 'update' | 'delete'>;
    scope?: string[];
}
/**
 * 4. File System Permission
 * Example: { type: 'filesystem', operations: ['read', 'write'], scope: ['/documents', '/images'] }
 */
export interface FileSystemPermission extends BasePermission {
    type: 'filesystem';
    operations: Array<'read' | 'write' | 'delete' | 'list'>;
    scope?: string[];
}
/**
 * 5. Integration Permission
 * Example: { type: 'integration', service: 'feishu', operations: ['read', 'write'] }
 */
export interface IntegrationPermission extends BasePermission {
    type: 'integration';
    service: string;
    operations?: IntegrationPermissionOperation[];
    scope?: string[];
}
/**
 * System token for resolving integration read service from plugin context.
 */
export declare const INTEGRATION_PERMISSION_SERVICE_TOKEN = "XPERT_PLUGIN_INTEGRATION_PERMISSION_SERVICE";
/**
 * Read-only integration permission service exposed to plugins.
 */
export interface IntegrationPermissionService {
    /** Scope must come from a host-authorized request/execution or a persisted binding, never tool input. */
    readForUsage?(id: string, usage: IntegrationUsage, scope: IntegrationUsageScope): Promise<IIntegration | null>;
    /** Read plugin configuration in its host-bound scope; system plugins use the Default tenant. */
    readConfiguration?(id: string): Promise<IIntegration | null>;
    /** Exact lookup for a connector whose actor and persisted scope have been authorized by the host. */
    readForConnector?(id: string, provider: string, scope: {
        tenantId: string;
        organizationId: string | null;
    }): Promise<IIntegration | null>;
    /** Legacy runtime lookup for integrations with their own callback/actor authorization. */
    read<TIntegration = IIntegration>(id: string, options?: Record<string, any>): Promise<TIntegration | null>;
    findAll<TIntegration = IIntegration>(options?: Record<string, any>): Promise<IPagination<TIntegration>>;
    findAllWithInheritance?<TIntegration = IIntegration>(options?: Record<string, any>): Promise<IPagination<TIntegration>>;
    ensureWebhookCredential?(id: string, options?: {
        provider?: string | null;
        rotateIfRevoked?: boolean;
    }): Promise<PluginWebhookCredentialResult | null>;
    rotateWebhookCredential?(id: string, options?: {
        provider?: string | null;
    }): Promise<PluginWebhookCredentialResult | null>;
    revokeWebhookCredential?(id: string, options?: {
        provider?: string | null;
    }): Promise<boolean>;
}
