import { FileSystemPermission } from './permissions';
/**
 * Restricted FileSystem based on granted permissions
 */
export declare class XpFileSystem {
    private basePath;
    private baseUrl;
    private allowedOps;
    private scope;
    constructor(permission: FileSystemPermission, basePath: string, baseUrl: string);
    /**
     * Check if operation is allowed
     */
    private ensureAllowed;
    /**
     * Check if path is within scope
     */
    private ensureInScope;
    /**
     * Get the absolute path of file in the file system.
     *
     * @param filePath Relative file path
     * @returns Absolute file path
     */
    fullPath(filePath: string): string;
    /**
     * Convert an absolute path under this file-system root back to a relative path.
     */
    relativePath(filePath: string): string | null;
    /**
     * Get web url for a given file path in the file system.
     *
     * @param filePath Relative file path
     * @returns Web URL of file
     */
    fullUrl(filePath: string): string;
    /**
     * Read file contents
     */
    readFile(filePath: string, encoding?: BufferEncoding): Promise<NonSharedBuffer>;
    /**
     * Write file contents
     */
    writeFile(filePath: string, content: string | Buffer): Promise<string>;
    /**
     * Delete a file
     */
    deleteFile(filePath: string): Promise<void>;
    /**
     * List directory contents
     */
    listDir(dirPath: string): Promise<string[]>;
    /**
     * Utility: check if a file or directory exists
     */
    exists(targetPath: string): Promise<boolean>;
    private buildUrl;
    private encodePath;
}
