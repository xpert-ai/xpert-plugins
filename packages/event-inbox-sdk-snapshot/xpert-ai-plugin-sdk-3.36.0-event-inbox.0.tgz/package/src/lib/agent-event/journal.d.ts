import type { AgentEventContext, AgentEventDelivery, AgentEventPublisher, EventDecision, PluginAgentEvent } from './index';
export interface AgentEventSql {
    query<T = unknown>(sql: string, params?: unknown[]): Promise<T>;
}
export declare function agentEventDigest(value: unknown): string;
interface Route {
    binding: string;
    revision: number;
    enabled: boolean;
}
export interface AgentEventOrigin {
    tenantId: string;
    organizationId: string;
    ref: string;
}
/** PostgreSQL source journal scoped to one plugin's own route and fact tables. */
export declare class PluginEventJournal {
    private readonly routes;
    private readonly facts;
    constructor(prefix: string);
    private lock;
    configure(tx: AgentEventSql, ctx: AgentEventContext, enabled: boolean): Promise<void>;
    route(tx: AgentEventSql, origin: AgentEventOrigin): Promise<Route>;
    capture(tx: AgentEventSql, route: Route, data: Omit<PluginAgentEvent, 'bindingRevision' | 'fact'>, snapshot: unknown, factKey: string, revision: string): Promise<boolean>;
    drain(db: AgentEventSql, ctx: AgentEventContext, publisher: AgentEventPublisher, limit: number): Promise<{
        more: boolean;
    }>;
    decide(tx: AgentEventSql, ctx: AgentEventContext, delivery: AgentEventDelivery, apply: (snapshot: unknown) => Promise<EventDecision>): Promise<EventDecision>;
}
export {};
