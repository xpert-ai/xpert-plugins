export declare const RETRIEVER_STRATEGY = "RETRIEVER_STRATEGY";
/**
 * Decorator to mark a provider as a Retriever Strategy
 */
export declare const RetrieverStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
