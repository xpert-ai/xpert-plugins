import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IRetrieverStrategy } from './strategy.interface';
export declare class RetrieverRegistry extends BaseStrategyRegistry<IRetrieverStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
