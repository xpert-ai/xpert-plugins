import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IDocumentTransformerStrategy, TDocumentTransformerConfig } from './strategy.interface';
export declare class DocumentTransformerRegistry<TConfig extends TDocumentTransformerConfig = TDocumentTransformerConfig> extends BaseStrategyRegistry<IDocumentTransformerStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
