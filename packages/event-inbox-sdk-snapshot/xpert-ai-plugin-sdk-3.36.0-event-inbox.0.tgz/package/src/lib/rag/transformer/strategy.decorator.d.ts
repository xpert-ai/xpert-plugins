export declare const DOCUMENT_TRANSFORMER_STRATEGY = "DOCUMENT_TRANSFORMER_STRATEGY";
/**
 * Decorator to mark a provider as a Document Transformer Strategy
 */
export declare const DocumentTransformerStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
