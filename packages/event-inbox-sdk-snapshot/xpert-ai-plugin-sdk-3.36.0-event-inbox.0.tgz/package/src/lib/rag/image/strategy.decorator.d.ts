export declare const IMAGE_UNDERSTANDING_STRATEGY = "IMAGE_UNDERSTANDING_STRATEGY";
/**
 * Decorator to mark a provider as an Image Understanding Strategy
 */
export declare const ImageUnderstandingStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
