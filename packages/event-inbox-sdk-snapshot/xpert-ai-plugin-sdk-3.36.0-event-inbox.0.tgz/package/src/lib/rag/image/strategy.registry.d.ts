import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IImageUnderstandingStrategy, TImageUnderstandingConfig } from './strategy.interface';
export declare class ImageUnderstandingRegistry<TConfig extends TImageUnderstandingConfig = TImageUnderstandingConfig> extends BaseStrategyRegistry<IImageUnderstandingStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
