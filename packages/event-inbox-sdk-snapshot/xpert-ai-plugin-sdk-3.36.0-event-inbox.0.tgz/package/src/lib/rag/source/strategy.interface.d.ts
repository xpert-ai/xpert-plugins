import { IDocumentSourceProvider, IIntegration } from '@xpert-ai/contracts';
import { Document } from '@langchain/core/documents';
import { Permissions } from '../../core';
export interface IDocumentSourceStrategy<TConfig = any> {
    readonly permissions: Permissions;
    /**
     * Metadata about this document source
     */
    readonly meta: IDocumentSourceProvider;
    /**
     * Validate the configuration
     */
    validateConfig(config: TConfig): Promise<void>;
    /**
     * Test the connection to the source
     *
     * @param config
     */
    test(config: TConfig): Promise<any>;
    /**
     * Load documents from the source
     */
    loadDocuments(config: TConfig, context?: {
        integration?: IIntegration;
    }): Promise<Document[]>;
    /**
     * Load a single document by its ID
     *
     * @deprecated Planning
     * @param documentId
     * @param context
     */
    loadDocument?(document: Document, context: {
        integration?: IIntegration;
    }): Promise<Document>;
}
