export declare const DOCUMENT_SOURCE_STRATEGY = "DOCUMENT_SOURCE_STRATEGY";
/**
 * Decorator to mark a provider as a Document Source Strategy
 */
export declare const DocumentSourceStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
