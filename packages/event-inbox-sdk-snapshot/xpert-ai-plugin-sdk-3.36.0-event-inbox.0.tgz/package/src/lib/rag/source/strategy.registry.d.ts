import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IDocumentSourceStrategy } from './strategy.interface';
export declare class DocumentSourceRegistry<TConfig = any> extends BaseStrategyRegistry<IDocumentSourceStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
