export declare const KEYWORD_ANALYZER_STRATEGY = "KEYWORD_ANALYZER_STRATEGY";
export declare const KeywordAnalyzerStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
