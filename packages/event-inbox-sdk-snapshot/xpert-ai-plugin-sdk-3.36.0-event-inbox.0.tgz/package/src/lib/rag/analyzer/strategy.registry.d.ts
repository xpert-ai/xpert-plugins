import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry, StrategySource } from '../../strategy';
import { IKeywordAnalyzerStrategy } from './strategy.interface';
export declare class KeywordAnalyzerRegistry extends BaseStrategyRegistry<IKeywordAnalyzerStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    /** Resolve a pinned source without allowing a higher-priority scope to shadow it. */
    getBySource(provider: string, source: StrategySource, organizationId?: string): IKeywordAnalyzerStrategy | undefined;
}
