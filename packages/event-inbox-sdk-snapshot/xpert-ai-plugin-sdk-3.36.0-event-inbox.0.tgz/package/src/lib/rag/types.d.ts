import { DocumentInterface } from '@langchain/core/documents';
import { IDocChunkMetadata } from '@xpert-ai/contracts';
export type { TDocumentAsset } from '@xpert-ai/contracts';
export interface ChunkMetadata extends IDocChunkMetadata {
    startOffset?: number;
    endOffset?: number;
    type?: 'parent' | 'child';
    [key: string]: any;
}
/**
 * Merge parent chunks with their child chunks based on metadata (parentId and chunkId)
 *
 * @deprecated use buildChunkTreeAndFindLeaves instead
 */
export declare function mergeParentChildChunks(chunks: DocumentInterface<ChunkMetadata>[], // Parent chunks
children: DocumentInterface<ChunkMetadata>[]): DocumentInterface<ChunkMetadata>[];
export declare function isRemoteFile(path: string): boolean;
export declare function downloadRemoteFile(url: string, dest: string): Promise<string>;
