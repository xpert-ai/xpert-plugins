export declare const KNOWLEDGE_STRATEGY = "KNOWLEDGE_STRATEGY";
export declare const KnowledgeStrategyKey: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
