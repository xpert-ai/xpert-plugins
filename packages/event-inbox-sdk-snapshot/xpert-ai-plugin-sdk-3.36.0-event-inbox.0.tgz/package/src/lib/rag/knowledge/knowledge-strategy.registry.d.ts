import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { KnowledgeStrategy } from './knowledge-strategy.interface';
export declare class KnowledgeStrategyRegistry extends BaseStrategyRegistry<KnowledgeStrategy> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
