import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { ITextSplitterStrategy } from './strategy.interface';
export declare class TextSplitterRegistry<TConfig = any> extends BaseStrategyRegistry<ITextSplitterStrategy<TConfig>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
