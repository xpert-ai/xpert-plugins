export declare const TEXT_SPLITTER_STRATEGY = "TEXT_SPLITTER_STRATEGY";
export declare const TextSplitterStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
