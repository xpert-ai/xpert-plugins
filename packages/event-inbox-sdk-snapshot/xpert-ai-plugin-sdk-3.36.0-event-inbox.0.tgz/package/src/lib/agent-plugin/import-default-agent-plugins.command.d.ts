import { Command } from '@nestjs/cqrs';
import type { DefaultAgentPluginsImportResult } from '@xpert-ai/contracts';
/** Import official resource packages for the authenticated organization administrator. Does not authorize workspaces. */
export declare class ImportDefaultAgentPluginsCommand extends Command<DefaultAgentPluginsImportResult> {
    static readonly type = "[Agent Plugins] Import defaults";
}
