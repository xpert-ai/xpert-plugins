import type { RunnableConfig } from '@langchain/core/runnables';
import { type ConversationResourceCard } from '@xpert-ai/contracts';
export { createResourceCardContent, parseResourceCard, resourceCardId } from '@xpert-ai/contracts';
export type { ConversationResourceCard, ResourceCardContent, ResourceCardField, ResourceCardFile, ResourceCardFileReference, ResourceCardImage, ResourceCardOpenTarget, ResourceCardScalar, TMessageContentResourceCard } from '@xpert-ai/contracts';
/** Call after the business mutation commits. A display failure must not retry that mutation. */
export declare function emitResourceCard(card: ConversationResourceCard, config?: RunnableConfig): Promise<void>;
