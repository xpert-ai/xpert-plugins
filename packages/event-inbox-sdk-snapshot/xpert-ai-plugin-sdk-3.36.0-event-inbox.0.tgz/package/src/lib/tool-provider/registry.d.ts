import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { XpertToolProviderInstance } from './types';
export declare class XpertToolProviderRegistry extends BaseStrategyRegistry<XpertToolProviderInstance> {
    private readonly replacements;
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    upsert(candidate: unknown): void;
    rollback(instance: XpertToolProviderInstance): void;
}
