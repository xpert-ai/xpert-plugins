import type { XpertToolOptions, XpertToolProviderOptions } from './types';
export declare const XPERT_TOOL_PROVIDER = "XPERT_TOOL_PROVIDER";
export declare const XPERT_TOOL_PROVIDER_METADATA = "XPERT_TOOL_PROVIDER_METADATA";
export declare const XPERT_TOOL_METHOD_METADATA = "XPERT_TOOL_METHOD_METADATA";
/** Marks one injectable business service as a shared Tool, Resource and Prompt provider. */
export declare const XpertToolProvider: (options: XpertToolProviderOptions) => ClassDecorator;
/** Exposes one business method through an Agent Middleware, native MCP, or both. */
export declare const XpertTool: (options: XpertToolOptions) => MethodDecorator;
