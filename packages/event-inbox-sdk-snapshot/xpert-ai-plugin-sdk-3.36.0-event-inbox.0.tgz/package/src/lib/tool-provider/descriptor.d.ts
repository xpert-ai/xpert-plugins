import type { XpertDecoratedToolDescriptor, XpertToolProviderDescriptor } from './types';
export declare function describeXpertToolProvider(instance: object): XpertToolProviderDescriptor;
export declare function getXpertToolMethod(instance: object, descriptor: XpertDecoratedToolDescriptor): (input: unknown, context: unknown) => unknown;
