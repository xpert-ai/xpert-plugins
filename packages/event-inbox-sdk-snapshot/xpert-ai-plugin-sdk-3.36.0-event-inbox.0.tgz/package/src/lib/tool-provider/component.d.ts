import { type IPluginComponentDefinition } from '@xpert-ai/contracts';
export declare function runtimeToolProviderComponent(provider: object): IPluginComponentDefinition;
