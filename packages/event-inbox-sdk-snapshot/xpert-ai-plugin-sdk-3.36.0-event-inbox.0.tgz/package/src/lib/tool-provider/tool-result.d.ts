import type { ZodTypeAny } from 'zod/v3';
import type { XpertToolContent, XpertToolResult } from '../toolset/tool-result';
export declare const XPERT_TOOL_RESULT_FORMAT_VERSION = 1;
/** Validate the envelope separately so binary content never enters the business DTO. */
export declare function parseDecoratedToolResult(value: unknown, outputSchema?: ZodTypeAny): Promise<XpertToolResult>;
export declare function agentContent(content: XpertToolContent[] | undefined): ({
    type: string;
    image_url: {
        url: string;
    };
    text?: undefined;
} | {
    type: string;
    text: string;
    image_url?: undefined;
})[];
