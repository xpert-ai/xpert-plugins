import type { PromiseOrValue } from '../types';
declare const PREPARED_RESULT: unique symbol;
export interface XpertOutputDiagnostic {
    code: 'tool_output_invalid';
    issues: {
        path: string;
        code: string;
    }[];
}
export interface XpertPreparedToolResult<T = unknown> {
    readonly [PREPARED_RESULT]: true;
    project(): PromiseOrValue<T>;
    recover(diagnostic: XpertOutputDiagnostic): PromiseOrValue<T>;
}
/** Defer output projection until the adapter can validate and recover its result. */
export declare function prepareToolResult<T, TRecovery>(project: () => PromiseOrValue<T>, recover: (diagnostic: XpertOutputDiagnostic) => PromiseOrValue<TRecovery>): XpertPreparedToolResult<T | TRecovery>;
export declare function resolveToolResult<T>(value: unknown, validate: (output: unknown) => Promise<T>): Promise<T>;
export {};
