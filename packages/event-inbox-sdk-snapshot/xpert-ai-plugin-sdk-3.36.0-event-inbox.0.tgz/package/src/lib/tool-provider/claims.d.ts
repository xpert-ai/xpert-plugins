import type { StrategySource } from '../strategy';
import type { XpertToolProviderDescriptor } from './types';
export interface XpertToolProviderClaim {
    source: StrategySource;
    descriptor: XpertToolProviderDescriptor;
}
/** Component keys belong to a plugin; public strategy and Tool names retain their scope-wide claims. */
export declare function assertXpertToolProviderClaims(candidate: XpertToolProviderClaim, existing: XpertToolProviderClaim[]): void;
