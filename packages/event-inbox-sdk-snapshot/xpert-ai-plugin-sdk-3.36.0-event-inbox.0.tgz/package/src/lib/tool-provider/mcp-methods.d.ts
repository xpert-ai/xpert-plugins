import type { McpResourceDefinition } from '../mcp/resource';
import type { McpResourceTemplateDefinition } from '../mcp/resource-template';
import type { McpPromptDefinition } from '../mcp/prompt';
import type { XpertToolProviderDescriptor } from './types';
export type XpertResourceOptions = Omit<McpResourceDefinition, 'read'>;
export type XpertResourceTemplateOptions = Omit<McpResourceTemplateDefinition, 'read' | 'complete'> & {
    /** Optional instance method implementing McpCompletionHandler. */
    completionMethod?: string;
};
export type XpertPromptOptions = Omit<McpPromptDefinition, 'get' | 'complete'> & {
    completionMethod?: string;
};
type McpMethod = {
    kind: 'resource';
    options: Readonly<XpertResourceOptions>;
} | {
    kind: 'resource-template';
    options: Readonly<XpertResourceTemplateOptions>;
} | {
    kind: 'prompt';
    options: Readonly<XpertPromptOptions>;
};
export type XpertDecoratedMcpDescriptor = McpMethod & {
    methodName: string;
};
/** The decorated method receives ResourceReadContext and returns McpResourceReadResult. */
export declare const XpertResource: (options: XpertResourceOptions) => MethodDecorator;
/** The decorated method receives URI arguments and ResourceReadContext. */
export declare const XpertResourceTemplate: (options: XpertResourceTemplateOptions) => MethodDecorator;
/** The decorated method receives prompt arguments and ToolExecutionContext. */
export declare const XpertPrompt: (options: XpertPromptOptions) => MethodDecorator;
export declare function describeXpertMcpMethods(instance: object): readonly XpertDecoratedMcpDescriptor[];
/** One catalog for runtime publication and fingerprinting; legacy declarations remain supported. */
export declare function resolveXpertMcpExtensions(instance: object, descriptor?: XpertToolProviderDescriptor): {
    resources: McpResourceDefinition[];
    resourceTemplates: McpResourceTemplateDefinition[];
    prompts: McpPromptDefinition[];
};
export {};
