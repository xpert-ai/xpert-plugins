/** Child overrides hide parent declarations, including undecorated overrides and accessors. */
export declare function collectProviderMethods(instance: object): {
    methodName: string;
    method: object;
}[];
