import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { DiscoveryService } from '@nestjs/core';
import { AgentMiddlewareRegistry } from '../agent/middleware/strategy.registry';
import { StrategyBus } from '../core/strategy-bus';
import { ToolsetRegistry } from '../toolset/strategy.registry';
import { XpertToolProviderRegistry } from './registry';
/** Expands one decorated business provider into the existing Toolset and Middleware registries. */
export declare class XpertToolProviderCoordinator implements OnModuleInit, OnModuleDestroy {
    private readonly discovery;
    private readonly bus;
    private readonly providerRegistry;
    private readonly toolsetRegistry;
    private readonly middlewareRegistry;
    private subscription?;
    private readonly processed;
    constructor(discovery: DiscoveryService, bus: StrategyBus, providerRegistry: XpertToolProviderRegistry, toolsetRegistry: ToolsetRegistry, middlewareRegistry: AgentMiddlewareRegistry);
    onModuleInit(): void;
    onModuleDestroy(): void;
    private expand;
}
