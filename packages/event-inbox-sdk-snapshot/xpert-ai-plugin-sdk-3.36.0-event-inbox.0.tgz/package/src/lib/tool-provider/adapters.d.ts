import { type DynamicStructuredTool } from '@langchain/core/tools';
import type { IXpertToolset } from '@xpert-ai/contracts';
import type { ZodSchema } from 'zod/v3';
import type { IAgentMiddlewareContext, IAgentMiddlewareStrategy } from '../agent/middleware/strategy.interface';
import type { AgentMiddleware } from '../agent/middleware/types';
import { BuiltinToolset, type TBuiltinToolsetParams } from '../toolset/builtin';
import type { IToolsetStrategy } from '../toolset/strategy.interface';
import type { XpertToolProviderDescriptor, XpertToolProviderInstance } from './types';
export declare class DecoratedToolsetStrategy implements IToolsetStrategy<IXpertToolset> {
    private readonly instance;
    private readonly pluginName?;
    private readonly pluginVersion?;
    readonly descriptor: XpertToolProviderDescriptor;
    readonly meta: IToolsetStrategy<IXpertToolset>['meta'];
    constructor(instance: XpertToolProviderInstance, pluginName?: string, pluginVersion?: string);
    validateConfig(config?: unknown): Promise<void>;
    create(toolset: IXpertToolset, params?: TBuiltinToolsetParams): Promise<BuiltinToolset>;
    createTools(): DynamicStructuredTool<ZodSchema>[];
}
export declare class DecoratedAgentMiddlewareStrategy implements IAgentMiddlewareStrategy<unknown> {
    private readonly instance;
    private readonly descriptor;
    readonly provider: string;
    readonly meta: any;
    constructor(instance: XpertToolProviderInstance, descriptor: XpertToolProviderDescriptor, provider: string);
    getToolNames(): readonly string[];
    createMiddleware(options: unknown, context: IAgentMiddlewareContext): Promise<AgentMiddleware>;
}
