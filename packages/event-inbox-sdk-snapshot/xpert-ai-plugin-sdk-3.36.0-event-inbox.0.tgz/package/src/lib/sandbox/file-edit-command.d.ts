/** Compare actual file contents inside the sandbox; reporting must never prevent an edit. */
export declare function buildEditCommand(filePath: string, oldString: string, newString: string, replaceAll: boolean): string;
