/** Format tool-owned paths only; file contents and backend filesystem authorization stay unchanged. */
export declare function workspaceRelativeDisplayPath(workingDirectory: string, filePath: string): string;
