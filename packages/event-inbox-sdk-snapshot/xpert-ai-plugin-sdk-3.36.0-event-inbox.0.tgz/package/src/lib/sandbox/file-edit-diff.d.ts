export declare const FILE_EDIT_DIFF_SCRIPT: string;
