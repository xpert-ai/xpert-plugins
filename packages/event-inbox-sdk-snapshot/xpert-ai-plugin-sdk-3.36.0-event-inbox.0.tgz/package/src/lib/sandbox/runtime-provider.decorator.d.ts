export declare const SANDBOX_RUNTIME_PROVIDER = "SANDBOX_RUNTIME_PROVIDER";
/** Marks a built-in or system-plugin class as a named Sandbox Runtime Provider strategy. */
export declare const SandboxRuntimeProviderStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
