export declare const SANDBOX_PROVIDER = "SANDBOX_PROVIDER";
export declare const SandboxProviderStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
