import type { EditOperation, EditResult, ExecuteResponse, MaybePromise, MultiEditResult } from './protocol';
export declare function editCommandResult(filePath: string, result: ExecuteResponse): EditResult;
/** Stops on failure; never promises rollback or silently reapplies completed edits. */
export declare function sequentialFileEdits(filePath: string, edits: EditOperation[], apply: (edit: EditOperation) => MaybePromise<EditResult>): Promise<MultiEditResult>;
