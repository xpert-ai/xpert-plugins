export interface SandboxExecutionOptions {
    /** Trusted host correlation/capabilities, never part of the model-visible command schema. */
    executionScope?: SandboxExecutionScope;
    timeoutMs?: number;
    maxOutputBytes?: number;
    /** Request cancellation; the backend must implement guest process termination. */
    signal?: AbortSignal;
}
export interface ResolvedSandboxExecutionOptions {
    executionScope?: SandboxExecutionScope;
    timeoutMs: number;
    maxOutputBytes: number;
    signal?: AbortSignal;
}
export declare const SANDBOX_SHELL_TIMEOUT_LIMITS_SEC: {
    readonly min: 1;
    readonly max: 3600;
};
export declare const DEFAULT_SANDBOX_SHELL_TIMEOUT_SEC = 600;
export declare const DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_SEC = 120;
export declare const DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_SEC = 120;
export declare const DEFAULT_SANDBOX_SHELL_TIMEOUT_MS: number;
export declare const DEFAULT_SANDBOX_FILE_SEARCH_TIMEOUT_MS: number;
export declare const DEFAULT_SANDBOX_FILE_OPERATION_TIMEOUT_MS: number;
export declare const DEFAULT_SANDBOX_EXECUTION_MAX_OUTPUT_BYTES: number;
export declare const DEFAULT_SANDBOX_SHELL_EXECUTION_OPTIONS: Readonly<SandboxExecutionOptions>;
export declare const DEFAULT_SANDBOX_FILE_SEARCH_EXECUTION_OPTIONS: Readonly<SandboxExecutionOptions>;
export declare const DEFAULT_SANDBOX_FILE_OPERATION_EXECUTION_OPTIONS: Readonly<SandboxExecutionOptions>;
export declare function secondsToMilliseconds(seconds: number): number;
export declare function formatSandboxTimeout(timeoutMs: number): string;
export declare function buildSandboxTimeoutMessage(subject: string, timeoutMs: number): string;
export declare function appendSandboxMessage(output: string, message: string): string;
export declare function resolveSandboxExecutionOptions(options?: SandboxExecutionOptions, defaults?: SandboxExecutionOptions): ResolvedSandboxExecutionOptions;
export interface SandboxExecutionScope {
    parentExecutionId: string;
    conversationId: string;
    toolCallId: string;
    /** Environment capabilities selected by the Assistant's middleware configuration. */
    capabilities: readonly string[];
}
