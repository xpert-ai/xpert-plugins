import type { TSandboxConfigurable } from '@xpert-ai/contracts';
import type { MaybePromise } from './protocol';
export type SandboxTerminalExit = {
    exitCode: number | null;
    signal?: number | null;
};
export type SandboxTerminalOpenOptions = {
    cols: number;
    rows: number;
    /** Reports terminal transport or provider failures separately from process exit. */
    onError?: (error: Error) => void;
    onExit: (event: SandboxTerminalExit) => void;
    onOutput: (data: string) => void;
};
export interface SandboxTerminalSession {
    close(): MaybePromise<void>;
    resize(cols: number, rows: number): MaybePromise<void>;
    write(data: string): MaybePromise<void>;
}
export interface SandboxTerminalAdapter {
    open(options: SandboxTerminalOpenOptions): MaybePromise<SandboxTerminalSession>;
}
export declare function isSandboxTerminalAdapter(value: unknown): value is SandboxTerminalAdapter;
export declare function resolveSandboxTerminalAdapter(sandbox: TSandboxConfigurable | SandboxTerminalAdapter | null | undefined | unknown): SandboxTerminalAdapter | null;
