import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { ISandboxRuntimeProvider } from './runtime-provider';
/** Discovers Runtime Provider strategies and rejects organization-scoped executable infrastructure. */
export declare class SandboxRuntimeProviderRegistry extends BaseStrategyRegistry<ISandboxRuntimeProvider> {
    private readonly runtimeLogger;
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    upsert(instance: unknown): void;
}
