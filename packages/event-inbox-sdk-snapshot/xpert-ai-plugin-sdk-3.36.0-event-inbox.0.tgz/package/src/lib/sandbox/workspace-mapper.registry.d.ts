import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import type { SandboxWorkspaceMapper } from './workspace-mapper';
/** Discovers Provider path mappers while enforcing the same system-level trust boundary as Providers. */
export declare class SandboxWorkspaceMapperRegistry extends BaseStrategyRegistry<SandboxWorkspaceMapper> {
    private readonly mapperLogger;
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    upsert(instance: unknown): void;
}
