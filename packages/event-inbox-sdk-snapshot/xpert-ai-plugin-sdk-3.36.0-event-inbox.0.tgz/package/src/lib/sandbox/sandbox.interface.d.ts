import { TSandboxProviderMeta, TSandboxWorkForType } from '@xpert-ai/contracts';
import { MaybePromise, SandboxBackendProtocol } from './protocol';
export type SandboxWorkspaceBinding = {
    /**
     * Host-side bind source used by containerized sandboxes.
     */
    bindSource?: string;
    /**
     * Mount target inside the sandbox container, such as `/workspace`.
     */
    containerMountPath?: string;
    /**
     * Server-visible canonical volume root.
     */
    volumeRoot: string;
    /**
     * Concrete sandbox-visible working path derived from the mapped workspace root.
     */
    workspacePath: string;
    /**
     * Sandbox-visible workspace root that corresponds to `volumeRoot`.
     */
    workspaceRoot: string;
};
/** A mount resolved by the application after resource authorization. Never accept it from HTTP input. */
export type SandboxWorkspaceMount = {
    source: string;
    destination: string;
    readOnly: boolean;
};
export type SandboxProviderCreateOptions = {
    /**
     * Working space directory for the sandbox instance
     */
    workingDirectory?: string;
    /**
     * Explicit mapping between the server-visible volume root and the sandbox-visible workspace root.
     */
    workspaceBinding?: SandboxWorkspaceBinding;
    /** Trusted Project scope hint for providers that can enforce read-only Project Content. */
    protectProjectContent?: true;
    /**
     * Canonical sandbox environment identifier that owns the container lifecycle.
     */
    environmentId?: string;
    /** Authorized mount configuration; providers enforce physical mount identity, not business access. */
    workspaceMounts?: SandboxWorkspaceMount[];
    /**
     * Tenant identifier
     */
    tenantId?: string;
    /** Registered runtime profile. Providers resolve this to an immutable image. */
    profile?: string;
    /** Immutable image reference selected by the profile registry. */
    image?: string;
    /** Job sandboxes are never reused after the action completes. */
    ephemeral?: boolean;
    resources?: {
        memoryMb?: number;
        cpu?: number;
        shmSizeMb?: number;
        tempDiskMb?: number;
    };
    networkPolicy?: {
        mode: 'none' | 'internal-only';
        allowedHosts?: string[];
    };
    security?: {
        runAsNonRoot: boolean;
        readOnlyRootFilesystem: boolean;
        noNewPrivileges: boolean;
        dropCapabilities: 'all';
    };
    /** Provider-enforced absolute lifetime for the sandbox. */
    hardDeadlineMs?: number;
    workFor: {
        type: TSandboxWorkForType;
        id: string;
    };
};
export type SandboxProviderCapabilities = {
    /** The provider enforces project.md and skills as read-only inside the runtime. */
    projectContentReadOnly: boolean;
};
export interface ISandboxProvider<T extends SandboxBackendProtocol = SandboxBackendProtocol> {
    type: string;
    meta: TSandboxProviderMeta;
    /** Optional for backward compatibility; protected requests treat absence as unsupported. */
    readonly capabilities?: SandboxProviderCapabilities;
    /**
     * Whether this provider is currently available in this deployment.
     * Providers without an availability hook remain available for backward compatibility.
     */
    isAvailable?(): MaybePromise<boolean>;
    /**
     * Create a new sandbox instance
     *
     * @param options
     */
    create(options?: SandboxProviderCreateOptions): Promise<T>;
    /** Destroy an ephemeral sandbox by its stable work identity after process loss or cancellation. */
    destroy?(options: SandboxProviderCreateOptions & {
        containerRef?: string | null;
    }): Promise<void>;
    /** Provider-side image/runner readiness check used by profile health. */
    getProfileHealth?(input: {
        profile: string;
        image?: string;
        /** Exact trusted command used to read the runner manifest. */
        manifestCommand?: readonly string[];
        expectedManifest?: Record<string, string>;
    }): Promise<{
        available: boolean;
        reason?: string;
        manifest?: Record<string, string>;
    }>;
    /**
     * Get default working directory for the sandbox instances
     */
    getDefaultWorkingDir(): string;
}
