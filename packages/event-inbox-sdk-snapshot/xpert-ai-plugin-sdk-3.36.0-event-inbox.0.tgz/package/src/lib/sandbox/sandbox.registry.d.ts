import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../strategy';
import { ISandboxProvider } from './sandbox.interface';
export declare class SandboxProviderRegistry extends BaseStrategyRegistry<ISandboxProvider> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
