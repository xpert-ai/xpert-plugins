import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ISandboxManagedService, TSandboxConfigurable, TSandboxManagedServiceEnvEntry, TSandboxManagedServiceLogs, TSandboxManagedServiceStatus, TSandboxManagedServiceTransportMode } from '@xpert-ai/contracts';
import type { MaybePromise } from './protocol';
export type SandboxManagedServiceStateChange = {
    actualPort?: number | null;
    exitCode?: number | null;
    runtimeRef?: ISandboxManagedService['runtimeRef'];
    signal?: string | null;
    startedAt?: Date;
    status: TSandboxManagedServiceStatus;
    stoppedAt?: Date | null;
    transportMode?: TSandboxManagedServiceTransportMode | null;
};
export type SandboxManagedServiceStartOptions = {
    command: string;
    cwd: string;
    env?: TSandboxManagedServiceEnvEntry[];
    metadata?: ISandboxManagedService['metadata'];
    port?: number | null;
    previewPath?: string | null;
    readyPattern?: string | null;
    serviceId: string;
    onStateChange?: (change: SandboxManagedServiceStateChange) => MaybePromise<void>;
};
export type SandboxManagedServiceListOptions = {
    services: ISandboxManagedService[];
};
export type SandboxManagedServiceListResult = {
    services: ISandboxManagedService[];
};
export type SandboxManagedServiceLogsOptions = {
    service: ISandboxManagedService;
    tail?: number;
};
export type SandboxManagedServiceStopOptions = {
    service: ISandboxManagedService;
    onStateChange?: (change: SandboxManagedServiceStateChange) => MaybePromise<void>;
};
export type SandboxManagedServiceRestartOptions = {
    command: string;
    cwd: string;
    env?: TSandboxManagedServiceEnvEntry[];
    metadata?: ISandboxManagedService['metadata'];
    port?: number | null;
    previewPath?: string | null;
    readyPattern?: string | null;
    service: ISandboxManagedService;
    onStateChange?: (change: SandboxManagedServiceStateChange) => MaybePromise<void>;
};
export type SandboxManagedServiceStartResult = SandboxManagedServiceStateChange;
export interface SandboxManagedServiceAdapter {
    getServiceLogs(options: SandboxManagedServiceLogsOptions): MaybePromise<TSandboxManagedServiceLogs>;
    /** Inspect existing services only; do not create or recover a runtime during discovery. */
    listServices(options: SandboxManagedServiceListOptions): MaybePromise<SandboxManagedServiceListResult>;
    restartService(options: SandboxManagedServiceRestartOptions): MaybePromise<SandboxManagedServiceStartResult>;
    startService(options: SandboxManagedServiceStartOptions): MaybePromise<SandboxManagedServiceStartResult>;
    stopService(options: SandboxManagedServiceStopOptions): MaybePromise<SandboxManagedServiceStateChange>;
}
export type SandboxServiceProxyRequest = {
    path: string;
    request: IncomingMessage;
    response: ServerResponse<IncomingMessage>;
    service: ISandboxManagedService;
};
export interface SandboxServiceProxyAdapter {
    proxyServiceRequest(request: SandboxServiceProxyRequest): MaybePromise<void>;
}
export declare function isSandboxManagedServiceAdapter(value: unknown): value is SandboxManagedServiceAdapter;
export declare function resolveSandboxManagedServiceAdapter(sandbox: TSandboxConfigurable | SandboxManagedServiceAdapter | null | undefined | unknown): SandboxManagedServiceAdapter | null;
export declare function isSandboxServiceProxyAdapter(value: unknown): value is SandboxServiceProxyAdapter;
export declare function resolveSandboxServiceProxyAdapter(sandbox: TSandboxConfigurable | SandboxServiceProxyAdapter | null | undefined | unknown): SandboxServiceProxyAdapter | null;
