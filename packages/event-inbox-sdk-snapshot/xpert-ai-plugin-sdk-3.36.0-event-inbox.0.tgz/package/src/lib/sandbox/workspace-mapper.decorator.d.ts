export declare const SANDBOX_WORKSPACE_MAPPER = "SANDBOX_WORKSPACE_MAPPER";
/** Associates a workspace path mapper with a named Runtime Provider strategy. */
export declare const SandboxWorkspaceMapperStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
