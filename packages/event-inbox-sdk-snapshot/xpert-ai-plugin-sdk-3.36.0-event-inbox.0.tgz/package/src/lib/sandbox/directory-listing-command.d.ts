/**
 * Node.js command template for recursive directory listing with depth control.
 */
export declare function buildListDirCommand(dirPath: string, displayPath: string, offset: number, limit: number, depth: number): string;
