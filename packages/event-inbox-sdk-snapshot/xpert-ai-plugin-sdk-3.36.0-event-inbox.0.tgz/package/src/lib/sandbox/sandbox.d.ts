/**
 * BaseSandbox: Abstract base class for sandbox backends with command execution.
 *
 * This class provides default implementations for all SandboxBackendProtocol
 * methods using shell commands executed via execute(). Concrete implementations
 * only need to implement the execute() method.
 *
 * Requires Node.js 20+ on the sandbox host.
 */
import type { EditOperation, EditResult, ExecuteResponse, FileDownloadResponse, FileInfo, FileUploadResponse, GrepMatch, IndentationOptions, MaybePromise, MultiEditResult, ReadMode, SandboxBackendProtocol, WriteResult } from './protocol';
import { SandboxExecutionOptions } from './execution';
/**
 * Base sandbox implementation with execute() as the only abstract method.
 *
 * This class provides default implementations for all SandboxBackendProtocol
 * methods using shell commands executed via execute(). Concrete implementations
 * only need to implement the execute() method.
 *
 * Requires Node.js 20+ on the sandbox host.
 */
export declare abstract class BaseSandbox implements SandboxBackendProtocol {
    workingDirectory: string;
    /** Unique identifier for the sandbox backend */
    abstract readonly id: string;
    /**
     * Internal hook for file/search operations. Concrete backends can override
     * this to distinguish "background helper commands" from user-facing shell
     * execute calls.
     */
    protected executeOperation(command: string, options?: SandboxExecutionOptions): MaybePromise<ExecuteResponse>;
    /**
     * Execute a command in the sandbox.
     * This is the only method concrete implementations must provide.
     */
    abstract execute(command: string, options?: SandboxExecutionOptions): MaybePromise<ExecuteResponse>;
    streamExecute(command: string, onLine: (line: string) => void, options?: SandboxExecutionOptions): Promise<ExecuteResponse>;
    /**
     * Upload multiple files to the sandbox.
     * Implementations must support partial success.
     */
    abstract uploadFiles(files: Array<[string, Uint8Array]>): MaybePromise<FileUploadResponse[]>;
    /**
     * Download multiple files from the sandbox.
     * Implementations must support partial success.
     */
    abstract downloadFiles(paths: string[]): MaybePromise<FileDownloadResponse[]>;
    /**
     * List files and directories in the specified directory (non-recursive).
     *
     * @param path - Absolute path to directory
     * @returns List of FileInfo objects for files and directories directly in the directory.
     */
    lsInfo(path: string): Promise<FileInfo[]>;
    /**
     * List directory contents recursively with depth control and pagination.
     *
     * @param dirPath - Absolute path to directory
     * @param offset - 1-indexed entry number to start from (default: 1)
     * @param limit - Maximum number of entries to return (default: 25)
     * @param depth - Maximum depth to traverse (default: 2)
     * @returns Directory tree whose entries are relative to the sandbox working directory
     */
    listDir(dirPath: string, offset?: number, limit?: number, depth?: number): Promise<string>;
    /**
     * Read file content with line numbers.
     *
     * @param filePath - Absolute file path
     * @param offset - Line offset to start reading from (1-indexed)
     * @param limit - Maximum number of lines to read
     * @param mode - Read mode: 'slice' (default) or 'indentation'
     * @param indentation - Configuration for indentation mode
     * @returns Formatted file content with line numbers, or error message
     */
    read(filePath: string, offset?: number, limit?: number, mode?: ReadMode, indentation?: IndentationOptions): Promise<string>;
    /**
     * Structured search results or error string for invalid input.
     */
    grepRaw(pattern: string, path?: string, include?: string | null): Promise<GrepMatch[] | string>;
    /**
     * Search file contents for a regex pattern, returning workspace-relative path labels.
     */
    grep(pattern: string, path?: string, include?: string | null): Promise<string>;
    /**
     * Structured glob matching returning FileInfo objects.
     */
    globInfo(pattern: string, path?: string): Promise<FileInfo[]>;
    /**
     * Find files matching a glob pattern, returning workspace-relative paths.
     */
    glob(pattern: string, path?: string): Promise<string>;
    /**
     * Create a new file with content.
     */
    write(filePath: string, content: string): Promise<WriteResult>;
    private writeViaUpload;
    /**
     * Append content to a file. Creates the file if it doesn't exist.
     */
    append(filePath: string, content: string): Promise<WriteResult>;
    /** Edit a file by replacing string occurrences. */
    edit(filePath: string, oldString: string, newString: string, replaceAll?: boolean): Promise<EditResult>;
    /** Earlier successful edits remain persisted if a later edit fails. */
    multiEdit(filePath: string, edits: EditOperation[]): Promise<MultiEditResult>;
}
