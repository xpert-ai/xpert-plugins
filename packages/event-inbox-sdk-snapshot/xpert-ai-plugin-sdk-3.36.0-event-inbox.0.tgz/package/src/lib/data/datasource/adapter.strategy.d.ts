import { IDataSourceStrategy } from './strategy.interface';
import { AdapterBaseOptions, DBQueryRunner, DBQueryRunnerType } from './types';
/**
 * Helper base class to wrap existing adapter query runner implementations
 * into datasource strategies consumable by the plugin SDK.
 */
export declare abstract class AdapterDataSourceStrategy<TOptions extends AdapterBaseOptions = AdapterBaseOptions> implements IDataSourceStrategy<TOptions> {
    private readonly runnerClass;
    private readonly extraArgs;
    abstract readonly type: string;
    abstract readonly name: string;
    readonly workbench?: {
        readonly engine: string;
    };
    readonly description?: string;
    private configurationSchemaCache;
    private runners;
    protected constructor(runnerClass: DBQueryRunnerType, extraArgs?: unknown[]);
    /**
     * Get from cache or create new instance of DB adapter.
     *
     * @param options
     * @param id
     * @returns
     */
    create(options: TOptions, id?: string): Promise<DBQueryRunner>;
    configurationSchema(): Promise<Record<string, unknown>>;
    teardown(runner: DBQueryRunner): Promise<void>;
    protected instantiateRunner(options: TOptions | undefined): DBQueryRunner;
    getClassType(): DBQueryRunnerType;
}
