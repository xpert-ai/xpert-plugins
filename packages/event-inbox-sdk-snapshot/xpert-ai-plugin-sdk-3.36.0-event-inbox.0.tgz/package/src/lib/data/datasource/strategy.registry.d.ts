import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import { IDataSourceStrategy } from './strategy.interface';
import { AdapterBaseOptions } from './types';
export declare class DataSourceStrategyRegistry<TOptions extends AdapterBaseOptions = any> extends BaseStrategyRegistry<IDataSourceStrategy<TOptions>> {
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
}
