export declare const DATASOURCE_STRATEGY = "DATASOURCE_STRATEGY";
export declare const DataSourceStrategy: (provider: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
