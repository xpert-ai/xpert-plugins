import * as _axios from 'axios';
import { Readable } from 'stream';
import type { DatabaseLocation, DatabaseWorkbenchAdapter } from './workbench';
import { IColumnDef, IDataSourceCapabilityQuery, IDSSchema, IDSTable } from '@xpert-ai/contracts';
export type { IColumnDef, IDataSourceCapabilityQuery, IDSSchema, IDSTable } from '@xpert-ai/contracts';
/**
 * The base options for DB adapters
 */
export interface AdapterBaseOptions {
    /**
     * Ref to debug in `createConnection` of `mysql`
     */
    debug?: boolean;
    /**
     * Ref to trace in `createConnection` of `mysql`
     */
    trace?: boolean;
    host: string;
    port: number;
    username: string;
    password: string;
}
export declare enum DBSyntaxEnum {
    SQL = "sql",
    MDX = "mdx"
}
export declare enum DBProtocolEnum {
    SQL = "sql",
    XMLA = "xmla"
}
/**
 * Options of single query
 */
export interface QueryOptions {
    catalog?: string;
    headers?: Record<string, string>;
    params?: Record<string, any>[];
}
export interface QueryResult<T = unknown> {
    status: 'OK' | 'ERROR';
    data?: Array<T>;
    columns?: Array<IColumnDef>;
    stats?: any;
    error?: string;
}
/**
 * Duties:
 * - Convert error messages into a unified format
 * - Connect different types of data sources
 */
export interface DBQueryRunner {
    getWorkbenchAdapter?(location?: DatabaseLocation): DatabaseWorkbenchAdapter;
    type: string;
    name: string;
    syntax: DBSyntaxEnum;
    protocol: DBProtocolEnum;
    host: string;
    port: number | string;
    jdbcDriver: string;
    configurationSchema: Record<string, unknown>;
    jdbcUrl(schema?: string): string;
    initPool?(options: AdapterBaseOptions): Promise<void>;
    /**
     * Execute a sql query
     *
     * @param sql
     */
    run(sql: string): Promise<any>;
    /**
     * Execute a sql query with options
     *
     * @param query
     * @param options
     */
    runQuery(query: string, options?: QueryOptions): Promise<QueryResult | any>;
    /**
     * Get catalog (schema or database) list in data source
     */
    getCatalogs(): Promise<IDSSchema[]>;
    /**
     * Get schema of table in catalog (schema or database)
     *
     * @param catalog
     * @param tableName
     */
    getSchema(catalog?: string, tableName?: string): Promise<IDSSchema[]>;
    /**
     * Runs an adapter-owned, read-only capability without exposing its domain
     * contract through the host platform.
     */
    queryCapability?(query: IDataSourceCapabilityQuery): Promise<unknown>;
    /**
     * Describe a sql query result schema
     *
     * @param catalog
     * @param statement
     */
    describe(catalog: string, statement: string): Promise<{
        columns?: IDSTable['columns'];
    }>;
    /**
     * Ping the db
     */
    ping(): Promise<void>;
    /**
     * Create a new catalog (schema) in database
     *
     * @param catalog
     */
    createCatalog?(catalog: string): Promise<void>;
    /**
     * Create or append table data
     *
     * @param params
     * @param options
     */
    import(params: CreationTable, options?: QueryOptions): Promise<any>;
    /**
     * Drop a table
     *
     * @param name Table name
     * @param options
     */
    dropTable(name: string, options?: QueryOptions): Promise<void>;
    /**
     * Unified table operation executor
     */
    tableOp(action: DBTableAction, params: DBTableOperationParams, options?: QueryOptions): Promise<any>;
    tableDataOp<T = any>(action: DBTableDataAction, params: DBTableDataParams, options?: QueryOptions): Promise<T[] | number | any>;
    /**
     * Teardown all resources:
     * - close connection
     *
     */
    teardown(): Promise<void>;
}
export type DBQueryRunnerType = new (options?: AdapterBaseOptions, ...args: unknown[]) => DBQueryRunner;
export interface ColumnDef {
    /**
     * Key of data object
     */
    name: string;
    /**
     * Name of table column
     */
    fieldName: string;
    /**
     * Object value type, convert to db type
     * - string
     * - number
     * - boolean
     * - date
     * - datetime
     * - object
     */
    type: string;
    /**
     * Is primary key column
     */
    isKey: boolean;
    /**
     * Is required column (NOT NULL)
     */
    required?: boolean;
    /**
     * Is unique column
     */
    unique?: boolean;
    /**
     * Auto increment (for number type)
     */
    autoIncrement?: boolean;
    /**
     * Default value
     */
    defaultValue?: string;
    /**
     * length of type for column: varchar, decimal ...
     */
    length?: number;
    /**
     * fraction of type for decimal
     */
    fraction?: number;
    /**
     * Enum values (for ENUM type)
     */
    enumValues?: string[];
    /**
     * Set values (for SET type)
     */
    setValues?: string[];
}
export interface CreationTable {
    catalog?: string;
    table?: string;
    name: string;
    columns: ColumnDef[];
    data?: any[];
    file?: File;
    mergeType?: 'APPEND' | 'DELETE' | 'MERGE';
    format?: 'csv' | 'json' | 'parquet' | 'orc' | 'data';
    columnSeparator?: string;
    withHeader?: number;
}
export declare abstract class BaseQueryRunner<T extends AdapterBaseOptions = AdapterBaseOptions> implements DBQueryRunner {
    type: string;
    name: string;
    syntax: DBSyntaxEnum;
    protocol: DBProtocolEnum;
    jdbcDriver: string;
    abstract get host(): string;
    abstract get port(): number | string;
    options: T;
    jdbcUrl(schema?: string): string;
    get configurationSchema(): any;
    constructor(options?: T);
    run(sql: string): Promise<any>;
    abstract runQuery(query: string, options?: QueryOptions): Promise<QueryResult>;
    abstract getCatalogs(): Promise<IDSSchema[]>;
    abstract getSchema(catalog?: string, tableName?: string): Promise<IDSSchema[]>;
    describe(catalog: string, statement: string): Promise<{
        columns?: IDSTable['columns'];
    }>;
    abstract ping(): Promise<void>;
    import({ name, columns, data }: {
        name: any;
        columns: any;
        data: any;
    }, options?: {
        catalog?: string;
    }): Promise<void>;
    dropTable(name: string, options?: any): Promise<void>;
    tableOp(action: DBTableAction, params: DBTableOperationParams, options?: QueryOptions): Promise<any>;
    tableDataOp(action: DBTableDataAction, params: DBTableDataParams, options?: QueryOptions): Promise<any>;
    abstract teardown(): Promise<void>;
}
export interface HttpAdapterOptions extends AdapterBaseOptions {
    url?: string;
}
export declare abstract class BaseHTTPQueryRunner<T extends HttpAdapterOptions = HttpAdapterOptions> extends BaseQueryRunner<T> {
    get url(): string;
    get host(): string;
    get port(): number | string;
    get configurationSchema(): {};
    get(): Promise<_axios.AxiosResponse<any, any>>;
    post(data: any, options?: any): Promise<_axios.AxiosResponse<any, any>>;
}
/**
 * Adapter options for sql db
 */
export interface SQLAdapterOptions extends AdapterBaseOptions {
    url?: string;
    /**
     * Database name, used as catalog
     */
    catalog?: string;
    use_ssl?: boolean;
    ssl_cacert?: string;
    version?: number;
}
export declare abstract class BaseSQLQueryRunner<T extends SQLAdapterOptions = SQLAdapterOptions> extends BaseQueryRunner<T> {
    syntax: DBSyntaxEnum;
    protocol: DBProtocolEnum;
    get host(): string;
    get port(): string | number;
    abstract createCatalog?(catalog: string): Promise<void>;
    ping(): Promise<void>;
    /**
     * Default implementation for table operations
     */
    tableOp(action: DBTableAction, params: DBTableOperationParams, options?: QueryOptions): Promise<any>;
    /**
     * Generic type mapping (subclasses can override)
     */
    protected mapColumnType(type: string, isKey: boolean, length?: number): string;
}
export interface File {
    /** Name of the form field associated with this file. */
    fieldname: string;
    /** Name of the file on the uploader's computer. */
    originalname: string;
    /**
     * Value of the `Content-Transfer-Encoding` header for this file.
     * @deprecated since July 2015
     * @see RFC 7578, Section 4.7
     */
    encoding: string;
    /** Value of the `Content-Type` header for this file. */
    mimetype: string;
    /** Size of the file in bytes. */
    size: number;
    /**
     * A readable stream of this file. Only available to the `_handleFile`
     * callback for custom `StorageEngine`s.
     */
    stream: Readable;
    /** `DiskStorage` only: Directory to which this file has been uploaded. */
    destination: string;
    /** `DiskStorage` only: Name of this file within `destination`. */
    filename: string;
    /** `DiskStorage` only: Full path to the uploaded file. */
    path: string;
    /** `MemoryStorage` only: A Buffer containing the entire file. */
    buffer: Buffer;
}
export declare enum DBTableAction {
    LIST_TABLES = "listTables",
    TABLE_EXISTS = "tableExists",
    CREATE_TABLE = "createTable",
    DROP_TABLE = "dropTable",
    RENAME_TABLE = "renameTable",
    TRUNCATE_TABLE = "truncateTable",
    ADD_COLUMN = "addColumn",
    DROP_COLUMN = "dropColumn",
    MODIFY_COLUMN = "modifyColumn",
    CREATE_INDEX = "createIndex",
    DROP_INDEX = "dropIndex",
    GET_TABLE_INFO = "getTableInfo",
    CLONE_TABLE_STRUCTURE = "cloneTableStructure",
    CLONE_TABLE = "cloneTable",
    OPTIMIZE_TABLE = "optimizeTable"
}
export interface DBTableOperationParams {
    schema?: string;
    table?: string;
    newTable?: string;
    columns?: ColumnDef[];
    column?: ColumnDef;
    columnName?: string;
    index?: DBIndexDefinition;
    indexName?: string;
    createMode?: DBCreateTableMode;
}
export interface DBIndexDefinition {
    name: string;
    columns: string[];
    unique?: boolean;
    type?: 'btree' | 'hash' | 'gin' | 'bitmap' | 'fulltext' | string;
}
/**
 * Modes for creating a table, if the table already exists
 */
export declare enum DBCreateTableMode {
    ERROR = "error",// throw error
    IGNORE = "ignore",// do nothing
    UPGRADE = "upgrade"
}
export declare enum DBTableDataAction {
    INSERT = "insert",
    UPDATE = "update",
    UPSERT = "upsert",
    DELETE = "delete",
    SELECT = "select",
    BULK_INSERT = "bulkInsert"
}
export interface DBTableDataParams {
    schema?: string;
    table: string;
    columns?: Partial<ColumnDef>[];
    where?: Record<string, any> | string;
    orderBy?: string;
    limit?: number;
    offset?: number;
    values?: Record<string, any> | Array<Record<string, any>>;
    set?: Record<string, any>;
    deleteWhere?: Record<string, any> | string;
    conflictKeys?: string[];
}
