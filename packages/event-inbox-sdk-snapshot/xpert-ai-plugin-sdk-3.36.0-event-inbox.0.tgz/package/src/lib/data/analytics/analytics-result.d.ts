import type { AnalyticsBinding, AnalyticalDataset, AnalyticsValue } from '@xpert-ai/contracts';
import type { AnalyticsProviderResult } from './analytics-provider';
export declare function resolveAnalyticsParameters(binding: AnalyticsBinding, controls: Record<string, AnalyticsValue>): Record<string, AnalyticsValue>;
export declare function normalizeAnalyticsResult(binding: AnalyticsBinding, result: AnalyticsProviderResult, executionId: string, maxRows: number): AnalyticalDataset;
