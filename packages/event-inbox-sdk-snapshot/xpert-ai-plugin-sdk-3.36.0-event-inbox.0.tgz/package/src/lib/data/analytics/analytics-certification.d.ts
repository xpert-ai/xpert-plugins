import { z } from 'zod/v3';
import type { AnalyticsCertification } from '@xpert-ai/contracts';
/** Parse only provider results. A valid shape alone never grants certification authority.
 * Legacy records remain explicitly unverified; approval fields require a verified source proof. */
export declare const analyticsCertificationSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"legacy_unverified">;
    kind: z.ZodLiteral<"business_metric">;
    subjectId: z.ZodString;
    verifiedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status?: "legacy_unverified";
    kind?: "business_metric";
    subjectId?: string;
    verifiedAt?: string;
}, {
    status?: "legacy_unverified";
    kind?: "business_metric";
    subjectId?: string;
    verifiedAt?: string;
}>, z.ZodObject<{
    status: z.ZodLiteral<"verified">;
    definitionHash: z.ZodString;
    dependency: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        id?: string;
        version?: number;
    }, {
        id?: string;
        version?: number;
    }>;
    certifiedBy: z.ZodString;
    certifiedAt: z.ZodString;
    kind: z.ZodLiteral<"business_metric">;
    subjectId: z.ZodString;
    verifiedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status?: "verified";
    kind?: "business_metric";
    subjectId?: string;
    verifiedAt?: string;
    definitionHash?: string;
    dependency?: {
        id?: string;
        version?: number;
    };
    certifiedBy?: string;
    certifiedAt?: string;
}, {
    status?: "verified";
    kind?: "business_metric";
    subjectId?: string;
    verifiedAt?: string;
    definitionHash?: string;
    dependency?: {
        id?: string;
        version?: number;
    };
    certifiedBy?: string;
    certifiedAt?: string;
}>]>;
/** The package supports hosts compiled without strictNullChecks; parsing still requires every field. */
export declare function parseAnalyticsCertification(value: unknown): AnalyticsCertification;
