import { z } from 'zod/v3';
import type { AnalyticsField, AnalyticsValue, ResourceAnalysisPolicy, ResourceAnalysisQuery, ResourceAnalysisFilter } from '@xpert-ai/contracts';
/** Validate one predicate's shape/cardinality; field existence, logical types and allowed scope require live dataset metadata. */
export declare const resourceAnalysisFilterSchema: z.ZodType<ResourceAnalysisFilter>;
/**
 * Shared authoring/server policy boundary: bounded nonempty allowlists, fixed-filter fields and supported mode combinations.
 * Parsing does not establish source sharing authority or receiving-group consent; those remain runtime checks.
 */
export declare const resourceAnalysisPolicySchema: z.ZodType<ResourceAnalysisPolicy>;
/**
 * Normalize public query input to ResourceAnalysisQuery, defaulting optional wire collections to empty values.
 * Keep limit absent so the executor uses the live policy's maxRows; validate field/mode/budget permissions before querying.
 */
export declare const resourceAnalysisQuerySchema: z.ZodType<ResourceAnalysisQuery>;
/**
 * Check a predicate scalar against the declared logical type, including exact-string int64/decimal wire values.
 * Shared by authoring and execution; this does not validate the operator, field allowlist or grant authority.
 */
export declare function isResourceAnalysisFilterValue(type: AnalyticsField['logicalType'], value: AnalyticsValue): boolean;
