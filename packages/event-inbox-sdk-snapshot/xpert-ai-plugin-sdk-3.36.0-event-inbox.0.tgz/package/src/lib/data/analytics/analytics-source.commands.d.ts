import { Command } from '@nestjs/cqrs';
import type { AnalyticsSourceSummary, AnalyticsSourceRef } from '@xpert-ai/contracts';
import type { DataSourceActor } from '../datasource/workbench';
import type { AnalyticsResolvedSource } from './analytics-provider';
/** Host resource owners enumerate sources using the current viewer's ACLs. */
export declare class ListAnalyticsSourcesCommand extends Command<AnalyticsSourceSummary[]> {
    readonly actor: DataSourceActor;
    readonly kind: AnalyticsSourceRef['kind'];
    static readonly type = "[Analytics] List native sources";
    constructor(actor: DataSourceActor, kind: AnalyticsSourceRef['kind']);
}
/** Authorize an exact immutable version; the owner also supplies the post-execution ACL/integrity recheck. */
export declare class ResolveAnalyticsSourceCommand extends Command<AnalyticsResolvedSource> {
    readonly actor: DataSourceActor;
    readonly source: AnalyticsSourceRef;
    static readonly type = "[Analytics] Resolve native source";
    constructor(actor: DataSourceActor, source: AnalyticsSourceRef);
}
