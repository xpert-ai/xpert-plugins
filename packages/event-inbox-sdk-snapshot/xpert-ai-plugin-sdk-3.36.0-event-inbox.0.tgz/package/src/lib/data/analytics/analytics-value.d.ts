import type { AnalyticsField, AnalyticsValue } from '@xpert-ai/contracts';
/** Shared wire-value rules for normalized query results and immutable evidence snapshots. */
export declare function isAnalyticsDate(value: string): boolean;
/** int64/decimal stay strings on the wire to avoid JavaScript number rounding; never coerce them. */
export declare function isAnalyticsCell(type: AnalyticsField['logicalType'], cell: AnalyticsValue, nullable: boolean): boolean;
