import { type AnalyticsDiagnostic } from '@xpert-ai/contracts';
/** Public diagnostics only; Error.message deliberately excludes unvalidated provider text. */
export declare class AnalyticsProviderError extends Error {
    readonly diagnostic: AnalyticsDiagnostic;
    constructor(diagnostic: AnalyticsDiagnostic);
}
/** Structural lookup also accepts another SDK copy; class identity is not a trust boundary. */
export declare function readAnalyticsProviderDiagnostic(error: unknown): AnalyticsDiagnostic | undefined;
