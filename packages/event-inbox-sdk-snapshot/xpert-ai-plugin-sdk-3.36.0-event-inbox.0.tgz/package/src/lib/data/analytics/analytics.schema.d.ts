import { z } from 'zod/v3';
import type { AnalyticsSourceRef, AnalyticsBinding, AnalyticsQueryRequest, AnalyticsDiscoveryRequest, AnalyticsDiscoveryResult, JSONValue } from '@xpert-ai/contracts';
export declare const analyticsSourceRefSchema: z.ZodType<AnalyticsSourceRef>;
export declare const analyticsOptionsSchema: z.ZodRecord<z.ZodString, z.ZodType<JSONValue, z.ZodTypeDef, JSONValue>>;
export declare const analyticsFieldSchema: z.ZodObject<{
    id: z.ZodString;
    sourceField: z.ZodString;
    label: z.ZodString;
    logicalType: z.ZodEnum<["string", "boolean", "int64", "float64", "decimal", "date", "timestamp"]>;
    nullable: z.ZodBoolean;
    role: z.ZodEnum<["dimension", "measure", "time", "identifier"]>;
    semanticRef: z.ZodOptional<z.ZodString>;
    unit: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    id?: string;
    sourceField?: string;
    label?: string;
    logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
    nullable?: boolean;
    role?: "dimension" | "measure" | "time" | "identifier";
    semanticRef?: string;
    unit?: string;
}, {
    id?: string;
    sourceField?: string;
    label?: string;
    logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
    nullable?: boolean;
    role?: "dimension" | "measure" | "time" | "identifier";
    semanticRef?: string;
    unit?: string;
}>;
export declare const analyticsParameterSchema: z.ZodObject<{
    name: z.ZodString;
    controlId: z.ZodString;
    type: z.ZodEnum<["string", "number", "boolean", "date"]>;
    required: z.ZodBoolean;
    defaultValue: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>;
    allowedValues: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>, "many">>;
}, "strict", z.ZodTypeAny, {
    type?: "string" | "number" | "boolean" | "date";
    name?: string;
    controlId?: string;
    required?: boolean;
    defaultValue?: string | number | boolean;
    allowedValues?: (string | number | boolean)[];
}, {
    type?: "string" | "number" | "boolean" | "date";
    name?: string;
    controlId?: string;
    required?: boolean;
    defaultValue?: string | number | boolean;
    allowedValues?: (string | number | boolean)[];
}>;
export declare const analyticsBindingObjectSchema: z.ZodObject<{
    id: z.ZodString;
    source: z.ZodType<AnalyticsSourceRef, z.ZodTypeDef, AnalyticsSourceRef>;
    providerId: z.ZodString;
    operation: z.ZodString;
    contractVersion: z.ZodNumber;
    payload: z.ZodType<JSONValue, z.ZodTypeDef, JSONValue>;
    parameters: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        controlId: z.ZodString;
        type: z.ZodEnum<["string", "number", "boolean", "date"]>;
        required: z.ZodBoolean;
        defaultValue: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>;
        allowedValues: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>, "many">>;
    }, "strict", z.ZodTypeAny, {
        type?: "string" | "number" | "boolean" | "date";
        name?: string;
        controlId?: string;
        required?: boolean;
        defaultValue?: string | number | boolean;
        allowedValues?: (string | number | boolean)[];
    }, {
        type?: "string" | "number" | "boolean" | "date";
        name?: string;
        controlId?: string;
        required?: boolean;
        defaultValue?: string | number | boolean;
        allowedValues?: (string | number | boolean)[];
    }>, "many">;
    output: z.ZodObject<{
        datasetId: z.ZodString;
        fields: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            sourceField: z.ZodString;
            label: z.ZodString;
            logicalType: z.ZodEnum<["string", "boolean", "int64", "float64", "decimal", "date", "timestamp"]>;
            nullable: z.ZodBoolean;
            role: z.ZodEnum<["dimension", "measure", "time", "identifier"]>;
            semanticRef: z.ZodOptional<z.ZodString>;
            unit: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }, {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }>, "many">;
        grain: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
    }, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
    }>;
}, "strict", z.ZodTypeAny, {
    id?: string;
    source?: AnalyticsSourceRef;
    providerId?: string;
    operation?: string;
    contractVersion?: number;
    payload?: JSONValue;
    parameters?: {
        type?: "string" | "number" | "boolean" | "date";
        name?: string;
        controlId?: string;
        required?: boolean;
        defaultValue?: string | number | boolean;
        allowedValues?: (string | number | boolean)[];
    }[];
    output?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
    };
}, {
    id?: string;
    source?: AnalyticsSourceRef;
    providerId?: string;
    operation?: string;
    contractVersion?: number;
    payload?: JSONValue;
    parameters?: {
        type?: "string" | "number" | "boolean" | "date";
        name?: string;
        controlId?: string;
        required?: boolean;
        defaultValue?: string | number | boolean;
        allowedValues?: (string | number | boolean)[];
    }[];
    output?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
    };
}>;
export declare function validateAnalyticsBinding(binding: Pick<z.output<typeof analyticsBindingObjectSchema>, 'output' | 'parameters' | 'payload'>, ctx: z.RefinementCtx): void;
export declare const analyticsBindingSchema: z.ZodType<AnalyticsBinding>;
export declare const analyticsControlsSchema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
export declare const analyticsQueryRequestSchema: z.ZodType<AnalyticsQueryRequest, z.ZodTypeDef, unknown>;
export declare const analyticsDiscoveryRequestObjectSchema: z.ZodObject<{
    source: z.ZodType<AnalyticsSourceRef, z.ZodTypeDef, AnalyticsSourceRef>;
    providerId: z.ZodString;
    request: z.ZodDefault<z.ZodType<JSONValue, z.ZodTypeDef, JSONValue>>;
}, "strict", z.ZodTypeAny, {
    source?: AnalyticsSourceRef;
    providerId?: string;
    request?: JSONValue;
}, {
    source?: AnalyticsSourceRef;
    providerId?: string;
    request?: JSONValue;
}>;
export declare const analyticsDiscoveryRequestSchema: z.ZodType<AnalyticsDiscoveryRequest, z.ZodTypeDef, unknown>;
export declare const analyticsDiscoveryResultSchema: z.ZodType<AnalyticsDiscoveryResult>;
/** Stable identity for source selection and scoped discovery receipts. */
export declare function analyticsSourceKey(source: AnalyticsSourceRef): string;
