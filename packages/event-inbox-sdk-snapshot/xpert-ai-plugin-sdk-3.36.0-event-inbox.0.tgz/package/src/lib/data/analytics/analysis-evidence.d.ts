import { z } from 'zod/v3';
import type { AnalysisEvidenceSnapshot } from '@xpert-ai/contracts';
export declare const analysisEvidenceSchema: z.ZodEffects<z.ZodObject<{
    schema: z.ZodLiteral<"xpert.analysis-evidence@1">;
    id: z.ZodString;
    title: z.ZodString;
    capturedAt: z.ZodString;
    source: z.ZodObject<{
        artifactId: z.ZodString;
        versionId: z.ZodString;
        projectId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    }, {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    }>;
    controls: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>, Record<string, string | number | boolean>, Record<string, string | number | boolean>>;
    datasets: z.ZodArray<z.ZodEffects<z.ZodObject<{
        schema: z.ZodLiteral<"xpert.analytics.dataset">;
        datasetId: z.ZodEffects<z.ZodString, string, string>;
        fields: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            sourceField: z.ZodString;
            label: z.ZodString;
            logicalType: z.ZodEnum<["string", "boolean", "int64", "float64", "decimal", "date", "timestamp"]>;
            nullable: z.ZodBoolean;
            role: z.ZodEnum<["dimension", "measure", "time", "identifier"]>;
            semanticRef: z.ZodOptional<z.ZodString>;
            unit: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }, {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }>, "many">;
        rows: z.ZodArray<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>, "many">;
        grain: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
        completeness: z.ZodObject<{
            returnedRows: z.ZodNumber;
            totalRows: z.ZodOptional<z.ZodNumber>;
            totalAccuracy: z.ZodEnum<["exact", "estimated", "unknown"]>;
            scope: z.ZodEnum<["full_query_result", "page", "sample", "top_n"]>;
            truncated: z.ZodBoolean;
        }, "strict", z.ZodTypeAny, {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        }, {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        }>;
        freshness: z.ZodObject<{
            executedAt: z.ZodString;
            sourceFetchedAt: z.ZodString;
            dataAsOf: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        }, {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        }>;
        provenance: z.ZodObject<{
            executionId: z.ZodEffects<z.ZodString, string, string>;
            bindingId: z.ZodEffects<z.ZodString, string, string>;
            providerId: z.ZodEffects<z.ZodString, string, string>;
            sourceVersion: z.ZodOptional<z.ZodString>;
            upstreamExecutionId: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
            auditRef: z.ZodOptional<z.ZodString>;
            certification: z.ZodOptional<z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
                status: z.ZodLiteral<"legacy_unverified">;
                kind: z.ZodLiteral<"business_metric">;
                subjectId: z.ZodString;
                verifiedAt: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            }, {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            }>, z.ZodObject<{
                status: z.ZodLiteral<"verified">;
                definitionHash: z.ZodString;
                dependency: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    id?: string;
                    version?: number;
                }, {
                    id?: string;
                    version?: number;
                }>;
                certifiedBy: z.ZodString;
                certifiedAt: z.ZodString;
                kind: z.ZodLiteral<"business_metric">;
                subjectId: z.ZodString;
                verifiedAt: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            }, {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            }>]>>;
        }, "strict", z.ZodTypeAny, {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        }, {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }>, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }, {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }>, "many">;
    statements: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<["fact", "inference", "unverified"]>;
        text: z.ZodString;
        citations: z.ZodArray<z.ZodObject<{
            datasetId: z.ZodEffects<z.ZodString, string, string>;
            row: z.ZodNumber;
            field: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            datasetId?: string;
            field?: string;
            row?: number;
        }, {
            datasetId?: string;
            field?: string;
            row?: number;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }, {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }>, "many">;
    sha256: z.ZodString;
}, "strict", z.ZodTypeAny, {
    id?: string;
    title?: string;
    source?: {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    };
    controls?: Record<string, string | number | boolean>;
    schema?: "xpert.analysis-evidence@1";
    datasets?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }[];
    capturedAt?: string;
    statements?: {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }[];
    sha256?: string;
}, {
    id?: string;
    title?: string;
    source?: {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    };
    controls?: Record<string, string | number | boolean>;
    schema?: "xpert.analysis-evidence@1";
    datasets?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }[];
    capturedAt?: string;
    statements?: {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }[];
    sha256?: string;
}>, {
    id?: string;
    title?: string;
    source?: {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    };
    controls?: Record<string, string | number | boolean>;
    schema?: "xpert.analysis-evidence@1";
    datasets?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }[];
    capturedAt?: string;
    statements?: {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }[];
    sha256?: string;
}, {
    id?: string;
    title?: string;
    source?: {
        versionId?: string;
        artifactId?: string;
        projectId?: string;
    };
    controls?: Record<string, string | number | boolean>;
    schema?: "xpert.analysis-evidence@1";
    datasets?: {
        datasetId?: string;
        fields?: {
            id?: string;
            sourceField?: string;
            label?: string;
            logicalType?: "string" | "boolean" | "date" | "int64" | "float64" | "decimal" | "timestamp";
            nullable?: boolean;
            role?: "dimension" | "measure" | "time" | "identifier";
            semanticRef?: string;
            unit?: string;
        }[];
        grain?: string[];
        rows?: Record<string, string | number | boolean>[];
        schema?: "xpert.analytics.dataset";
        completeness?: {
            scope?: "full_query_result" | "page" | "sample" | "top_n";
            returnedRows?: number;
            totalRows?: number;
            totalAccuracy?: "exact" | "unknown" | "estimated";
            truncated?: boolean;
        };
        provenance?: {
            providerId?: string;
            certification?: {
                status?: "legacy_unverified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
            } | {
                status?: "verified";
                kind?: "business_metric";
                subjectId?: string;
                verifiedAt?: string;
                definitionHash?: string;
                dependency?: {
                    id?: string;
                    version?: number;
                };
                certifiedBy?: string;
                certifiedAt?: string;
            };
            executionId?: string;
            bindingId?: string;
            sourceVersion?: string;
            upstreamExecutionId?: string;
            auditRef?: string;
        };
        freshness?: {
            executedAt?: string;
            sourceFetchedAt?: string;
            dataAsOf?: string;
        };
    }[];
    capturedAt?: string;
    statements?: {
        kind?: "fact" | "inference" | "unverified";
        text?: string;
        citations?: {
            datasetId?: string;
            field?: string;
            row?: number;
        }[];
    }[];
    sha256?: string;
}>;
/** Canonicalize validated JSON: sort object keys, but preserve array order and exact scalar values.
 * Omitted optional properties do not affect the digest. Hashing stays in the consumer's runtime. */
export declare function canonicalEvidenceJson(value: unknown): string;
/** Validate shape and cell references; callers must verify the digest and current source access separately. */
export declare function parseAnalysisEvidence(value: unknown): AnalysisEvidenceSnapshot;
/** Exclude only the digest itself; source, capture time, cells and statement classifications stay covered. */
export declare function analysisEvidenceDigestInput(value: AnalysisEvidenceSnapshot): string;
