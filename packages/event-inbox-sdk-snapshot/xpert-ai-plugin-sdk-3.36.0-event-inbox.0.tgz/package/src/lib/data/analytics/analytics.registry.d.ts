import { DiscoveryService, Reflector } from '@nestjs/core';
import { BaseStrategyRegistry } from '../../strategy';
import type { AnalyticsQueryProvider } from './analytics-provider';
export declare const ANALYTICS_PROVIDER = "ANALYTICS_QUERY_PROVIDER";
/** Mark a Nest provider registered by a plugin module; id must match its descriptor.id. */
export declare const AnalyticsProvider: (id: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
/** Uses shared plugin scoping; execution callers list providers for the current actor's organization. */
export declare class AnalyticsProviderRegistry extends BaseStrategyRegistry<AnalyticsQueryProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
}
