import type { JSONValue } from '@xpert-ai/contracts';
/** Structural feedback from the discovered provider contract. Never substitutes for provider authorization or validation. */
export declare function validateAnalyticsPayload(payload: JSONValue, schema: JSONValue): void;
