/**
 * Plugin metadata may be parsed in a provider constructor, before registry discovery.
 * Preserve Nest injection metadata while isolating validation failures from external plugins.
 * Failed contributions never become executable templates; built-in and non-validation errors still throw.
 */
import { z } from 'zod/v3';
export type PipelineContributionIssue = {
    path: (string | number)[];
    code: string;
};
export declare class UnavailablePipelineContribution {
    readonly metatype: Function;
    readonly issues: PipelineContributionIssue[];
    constructor(metatype: Function, issues: PipelineContributionIssue[]);
}
export declare function pipelineContributionIssues(error: z.ZodError): PipelineContributionIssue[];
export declare function isolatePipelineContribution<T extends Function>(target: T): T;
