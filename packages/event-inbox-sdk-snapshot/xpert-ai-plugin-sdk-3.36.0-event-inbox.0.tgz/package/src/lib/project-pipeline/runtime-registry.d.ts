import { DiscoveryService, Reflector } from '@nestjs/core';
import type { StrategySource } from '../strategy';
import type { ProjectAccessActor } from '../runtime/capabilities/project-access';
import type { ProjectPipelineSubjectResolver, ProjectPipelineEvidenceResolver, ProjectPipelineNodeHandler, ProjectPipelineCompletionEvaluator, ProjectPipelinePolicyEvaluator, ProjectPipelineValueSchema, ProjectPipelineAssistantOperation, ProjectPipelineResourceResolver, ProjectPipelineRuntimeOperation } from './adapters';
import { ProjectPipelineScopedRegistry } from './scoped-registry';
export type ProjectPipelineRuntimeAdapter = ({
    kind: 'schema';
    ref: string;
} & ProjectPipelineValueSchema) | ({
    kind: 'resource';
    ref: string;
} & ProjectPipelineResourceResolver) | ({
    kind: 'subject';
    ref: string;
} & ProjectPipelineSubjectResolver) | ({
    kind: 'evidence';
    ref: string;
} & ProjectPipelineEvidenceResolver) | ({
    kind: 'operation';
    ref: string;
} & ProjectPipelineNodeHandler) | ({
    kind: 'assistant_operation';
    ref: string;
} & ProjectPipelineAssistantOperation) | ({
    kind: 'runtime_operation';
    ref: string;
} & ProjectPipelineRuntimeOperation) | ({
    kind: 'completion';
    ref: string;
} & ProjectPipelineCompletionEvaluator) | ({
    kind: 'policy';
    ref: string;
} & ProjectPipelinePolicyEvaluator) | ({
    kind: 'subscription';
    ref: string;
} & ProjectPipelineNodeHandler);
export declare const PROJECT_PIPELINE_RUNTIME_ADAPTER = "PROJECT_PIPELINE_RUNTIME_ADAPTER";
export declare const ProjectPipelineRuntimeAdapterProvider: (kind: ProjectPipelineRuntimeAdapter["kind"], ref: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class ProjectPipelineRuntimeAdapterRegistry extends ProjectPipelineScopedRegistry<ProjectPipelineRuntimeAdapter> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
    register(key: string, adapter: ProjectPipelineRuntimeAdapter, source: StrategySource): ProjectPipelineRuntimeAdapter;
    resolve<K extends ProjectPipelineRuntimeAdapter['kind']>(kind: K, ref: string, actor: ProjectAccessActor): Extract<ProjectPipelineRuntimeAdapter, {
        kind: K;
    }>;
}
