import { BaseStrategyRegistry, type StrategySource } from '../strategy';
import type { ProjectAccessActor } from '../runtime/capabilities/project-access';
export declare function pipelineActorScopeKeys(actor: ProjectAccessActor): string[];
/** Public capabilities resolve from their explicit, authorized actor, never another ambient request. */
export declare abstract class ProjectPipelineScopedRegistry<T> extends BaseStrategyRegistry<T> {
    assertCanRegister(key: string, instance: T, source: StrategySource): void;
    upsert(instance: unknown): void;
    listForActor(actor: ProjectAccessActor): T[];
    getForActor(key: string, actor: ProjectAccessActor): T;
}
