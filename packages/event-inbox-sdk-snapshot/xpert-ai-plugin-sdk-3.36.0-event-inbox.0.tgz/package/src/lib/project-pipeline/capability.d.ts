import type { ProjectPipelineConfiguration, ProjectPipelineConfigurationCheck, ProjectPipelineGraph, ProjectPipelineSummary, ProjectPipelineConfigure, ProjectPipelineStart, ProjectPipelineStartReceipt, ProjectPipelineDecision, ProjectPipelineNextRound, ProjectPipelineEvidenceRef, ProjectPipelineJsonValue, ProjectPipelineCancel, ProjectPipelineRetry, ProjectPipelineRoundSummary, ProjectPipelineCatalog, ProjectPipelineCatalogConfigure, ProjectPipelineSavedConfiguration, ProjectPipelineCatalogRequest, ProjectPipelineProviderActions, ProjectPipelineProviderActionCommand, ProjectPipelineProviderActionView, ProjectPipelineAnalytics, ProjectPipelineAnalyticsInput, ProjectPipelinePortfolio, ProjectPipelinePortfolioInput } from '@xpert-ai/contracts';
import type { ProjectAccessActor } from '../runtime/capabilities/project-access';
import type { ProjectPipelineProjectionLinks } from './projection';
export interface ProjectPipelineContext {
    actor: ProjectAccessActor;
    projectId: string;
}
export interface ProjectPipelineAnalyticsApi {
    /** Current business state and all available linked execution history, selected by actual start time. */
    read(context: ProjectPipelineContext, input: ProjectPipelineAnalyticsInput): Promise<ProjectPipelineAnalytics>;
}
export interface ProjectPipelinePortfolioApi {
    /** Explicit selection only; every Project must be readable in the same trusted actor scope. */
    read(actor: ProjectAccessActor, input: ProjectPipelinePortfolioInput): Promise<ProjectPipelinePortfolio>;
}
export declare const ProjectPipelinePortfolioRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelinePortfolioApi>;
export declare const ProjectPipelineAnalyticsRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineAnalyticsApi>;
export interface ProjectPipelineProviderActionsApi {
    list(context: ProjectPipelineContext, input: {
        instanceId: string;
        nodeInstanceId: string;
    }): Promise<ProjectPipelineProviderActions>;
    submit(context: ProjectPipelineContext, input: ProjectPipelineProviderActionCommand): Promise<ProjectPipelineProviderActionView>;
}
export declare const ProjectPipelineProviderActionsRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineProviderActionsApi>;
export interface ProjectPipelineEvidenceApi {
    /** Reauthorize, resolve the exact immutable artifact, and validate its digest and declared schema. */
    read(context: ProjectPipelineContext, reference: ProjectPipelineEvidenceRef): Promise<ProjectPipelineJsonValue>;
}
export declare const ProjectPipelineEvidenceRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineEvidenceApi>;
export interface ProjectPipelineConfigurationApi {
    /** Metadata validation only; no persistence, domain callback, Assistant dispatch or external write. */
    check(context: ProjectPipelineContext, configuration: ProjectPipelineConfiguration): Promise<ProjectPipelineConfigurationCheck>;
}
export interface ProjectPipelineCatalogApi {
    list(context: ProjectPipelineContext, input?: import('@xpert-ai/contracts').ProjectPipelineCatalogRequest): Promise<ProjectPipelineCatalog>;
    bindings(context: ProjectPipelineContext, input?: ProjectPipelineCatalogRequest & {
        after?: string;
        limit?: number;
    }): Promise<{
        items: ProjectPipelineSavedConfiguration[];
        next: string | null;
    }>;
    binding(context: ProjectPipelineContext, bindingId: string, input?: ProjectPipelineCatalogRequest): Promise<ProjectPipelineSavedConfiguration>;
    /** Resolve the current scoped template and allowlisted fields; save a binding without starting work. */
    configure(context: ProjectPipelineContext, input: ProjectPipelineCatalogConfigure): Promise<{
        bindingId: string;
        revision: number;
        definitionDigest: string;
    }>;
}
export declare const ProjectPipelineCatalogRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineCatalogApi>;
export declare const ProjectPipelineConfigurationRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineConfigurationApi>;
export interface ProjectPipelinesApi {
    list(context: ProjectPipelineContext, input?: {
        after?: string;
        limit?: number;
    }): Promise<{
        items: ProjectPipelineSummary[];
        next: string | null;
    }>;
    graph(context: ProjectPipelineContext, instanceId: string, input?: {
        roundId?: string;
    }): Promise<ProjectPipelineGraph>;
    rounds(context: ProjectPipelineContext, instanceId: string, input?: {
        after?: string;
        limit?: number;
    }): Promise<{
        items: ProjectPipelineRoundSummary[];
        next: string | null;
    }>;
    /** A durable refresh only reads provider facts. It never starts business work. */
    refresh(context: ProjectPipelineContext, input: {
        providerRef: string;
        sourceKey: string;
    }): Promise<{
        status: 'queued';
    }>;
    /** Await the authoritative projection and its receipt before a provider dispatches work. Does not dispatch. */
    synchronize(context: ProjectPipelineContext, input: {
        providerRef: string;
        sourceKey: string;
    }): Promise<ProjectPipelineProjectionLinks | null>;
}
export declare const ProjectPipelinesRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelinesApi>;
export interface ProjectPipelineCommandsApi {
    configure(context: ProjectPipelineContext, request: ProjectPipelineConfigure): Promise<{
        bindingId: string;
        revision: number;
        definitionDigest: string;
    }>;
    start(context: ProjectPipelineContext, request: ProjectPipelineStart): Promise<ProjectPipelineStartReceipt>;
    decide(context: ProjectPipelineContext, request: ProjectPipelineDecision): Promise<{
        decisionId: string;
    }>;
    nextRound(context: ProjectPipelineContext, request: ProjectPipelineNextRound): Promise<ProjectPipelineStartReceipt>;
    cancel(context: ProjectPipelineContext, request: ProjectPipelineCancel): Promise<ProjectPipelineStartReceipt>;
    retry(context: ProjectPipelineContext, request: ProjectPipelineRetry): Promise<ProjectPipelineStartReceipt>;
}
export declare const ProjectPipelineCommandsRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ProjectPipelineCommandsApi>;
