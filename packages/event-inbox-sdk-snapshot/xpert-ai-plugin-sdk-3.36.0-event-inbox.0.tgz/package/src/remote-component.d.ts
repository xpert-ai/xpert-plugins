export interface RemoteComponentInit {
    locale: string;
    theme?: {
        mode?: string;
        density?: 'default' | 'compact';
        tokens?: Record<string, string | number>;
    };
}
/** Subscribe before rendering. The returned cleanup releases the listener and all outstanding requests. */
export declare function connect(init: (context: RemoteComponentInit, changed: boolean) => void, contextChanged: () => void): () => void;
export declare function request(type: string, body?: object): Promise<unknown>;
/** Bind a request before asynchronous preparation, so a context switch cannot redirect it. */
export declare function scopedRequest(): typeof request;
