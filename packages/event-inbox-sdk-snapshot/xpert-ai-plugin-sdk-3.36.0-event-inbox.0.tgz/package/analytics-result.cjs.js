'use strict';

var v3 = require('zod/v3');
var _extends = require('./_extends.cjs.js');

const key = v3.z.string().regex(/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/);
const value = v3.z.union([
    v3.z.string().max(4000),
    v3.z.number().finite(),
    v3.z.boolean(),
    v3.z.null()
]);
const json = v3.z.lazy(()=>v3.z.union([
        v3.z.string().max(32000),
        v3.z.number().finite(),
        v3.z.boolean(),
        v3.z.null(),
        v3.z.array(json).max(1000),
        v3.z.record(json)
    ]));
const analyticsSourceRefSchema = v3.z.discriminatedUnion('kind', [
    v3.z.object({
        kind: v3.z.literal('data-source'),
        dataSourceId: v3.z.string().uuid()
    }).strict(),
    v3.z.object({
        kind: v3.z.literal('definition'),
        definitionId: v3.z.string().uuid(),
        versionId: v3.z.string().uuid()
    }).strict(),
    v3.z.object({
        kind: v3.z.literal('artifact'),
        artifactId: v3.z.string().uuid(),
        versionId: v3.z.string().uuid()
    }).strict()
]);
const analyticsOptionsSchema = v3.z.record(json);
const analyticsFieldSchema = v3.z.object({
    id: key,
    sourceField: v3.z.string().min(1).max(256),
    label: v3.z.string().min(1).max(160),
    logicalType: v3.z.enum([
        'string',
        'boolean',
        'int64',
        'float64',
        'decimal',
        'date',
        'timestamp'
    ]),
    nullable: v3.z.boolean(),
    role: v3.z.enum([
        'dimension',
        'measure',
        'time',
        'identifier'
    ]),
    semanticRef: v3.z.string().max(512).optional(),
    unit: v3.z.string().max(80).optional()
}).strict();
const analyticsParameterSchema = v3.z.object({
    name: key,
    controlId: key,
    type: v3.z.enum([
        'string',
        'number',
        'boolean',
        'date'
    ]),
    required: v3.z.boolean(),
    defaultValue: value.optional(),
    allowedValues: v3.z.array(value).max(200).optional()
}).strict();
const analyticsBindingObjectSchema = v3.z.object({
    id: key,
    source: analyticsSourceRefSchema,
    providerId: v3.z.string().min(1).max(160),
    operation: key,
    contractVersion: v3.z.number().int().positive(),
    payload: json,
    parameters: v3.z.array(analyticsParameterSchema).max(24),
    output: v3.z.object({
        datasetId: key,
        fields: v3.z.array(analyticsFieldSchema).min(1).max(80),
        grain: v3.z.array(key).max(20)
    }).strict()
}).strict();
function validateAnalyticsBinding(binding, ctx) {
    const fields = binding.output.fields.map((field)=>field.id);
    const names = binding.parameters.map((parameter)=>parameter.name);
    if (new Set(fields).size !== fields.length || new Set(names).size !== names.length) ctx.addIssue({
        code: 'custom',
        message: 'Duplicate field or parameter identifier'
    });
    if (new Set(binding.output.grain).size !== binding.output.grain.length || binding.output.grain.some((field)=>!fields.includes(field))) ctx.addIssue({
        code: 'custom',
        message: 'Grain references an undeclared field'
    });
    if (new TextEncoder().encode(JSON.stringify(binding.payload)).byteLength > 64000) ctx.addIssue({
        code: 'custom',
        message: 'Query payload exceeds limit'
    });
}
const analyticsBindingSchema = analyticsBindingObjectSchema.superRefine(validateAnalyticsBinding);
const analyticsControlsSchema = v3.z.record(key, value).default({});
const analyticsQueryRequestSchema = v3.z.object({
    binding: analyticsBindingSchema,
    controls: analyticsControlsSchema,
    cache: v3.z.object({
        maxAgeMs: v3.z.number().int().min(0).max(60000),
        forceRefresh: v3.z.boolean().optional()
    }).strict().optional()
}).strict();
const analyticsDiscoveryRequestObjectSchema = v3.z.object({
    source: analyticsSourceRefSchema,
    providerId: v3.z.string().min(1).max(160),
    request: json.default({})
}).strict();
const analyticsDiscoveryRequestSchema = analyticsDiscoveryRequestObjectSchema.refine((value)=>new TextEncoder().encode(JSON.stringify(value)).byteLength <= 16000, 'Discovery request exceeds limit');
const analyticsDiscoveryResultSchema = v3.z.object({
    items: v3.z.array(v3.z.object({
        id: v3.z.string().min(1).max(512),
        name: v3.z.string().min(1).max(512),
        kind: v3.z.enum([
            'collection',
            'dataset'
        ]),
        description: v3.z.string().max(4000).optional(),
        inspectRequest: json.optional(),
        metadata: json
    }).strict()).max(50),
    nextRequest: json.optional(),
    queryContract: v3.z.object({
        operation: key,
        contractVersion: v3.z.number().int().positive(),
        payloadSchema: json,
        instructions: v3.z.string().max(8000)
    }).strict()
}).strict().refine((value)=>new TextEncoder().encode(JSON.stringify(value)).byteLength <= 128000, 'Discovery response exceeds limit');
/** Stable identity for source selection and scoped discovery receipts. */ function analyticsSourceKey(source) {
    switch(source.kind){
        case 'data-source':
            return `data-source/${source.dataSourceId}`;
        case 'definition':
            return `definition/${source.definitionId}/${source.versionId}`;
        case 'artifact':
            return `artifact/${source.artifactId}/${source.versionId}`;
    }
}

const identity = {
    kind: v3.z.literal('business_metric'),
    subjectId: v3.z.string().min(1).max(160),
    verifiedAt: v3.z.string().datetime()
};
/** Parse only provider results. A valid shape alone never grants certification authority.
 * Legacy records remain explicitly unverified; approval fields require a verified source proof. */ const analyticsCertificationSchema = v3.z.discriminatedUnion('status', [
    v3.z.object(_extends._extends({}, identity, {
        status: v3.z.literal('legacy_unverified')
    })).strict(),
    v3.z.object(_extends._extends({}, identity, {
        status: v3.z.literal('verified'),
        definitionHash: v3.z.string().regex(/^[a-f0-9]{64}$/),
        dependency: v3.z.object({
            id: v3.z.string().min(1).max(160),
            version: v3.z.number().int().nonnegative()
        }).strict(),
        certifiedBy: v3.z.string().min(1).max(160),
        certifiedAt: v3.z.string().datetime()
    })).strict()
]);
/** The package supports hosts compiled without strictNullChecks; parsing still requires every field. */ function parseAnalyticsCertification(value) {
    return analyticsCertificationSchema.parse(value);
}

/** Shared wire-value rules for normalized query results and immutable evidence snapshots. */ function isAnalyticsDate(value) {
    // Date.parse normalizes some impossible dates; round-trip validation rejects that rollover.
    return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}
/** int64/decimal stay strings on the wire to avoid JavaScript number rounding; never coerce them. */ function isAnalyticsCell(type, cell, nullable) {
    if (cell === null) return nullable;
    switch(type){
        case 'string':
            return typeof cell === 'string';
        case 'boolean':
            return typeof cell === 'boolean';
        case 'float64':
            return typeof cell === 'number' && Number.isFinite(cell);
        case 'int64':
            return typeof cell === 'string' && /^-?\d{1,19}$/.test(cell) && BigInt(cell) >= -(2n ** 63n) && BigInt(cell) < 2n ** 63n;
        case 'decimal':
            return typeof cell === 'string' && /^-?\d+(\.\d+)?$/.test(cell);
        case 'date':
            return typeof cell === 'string' && isAnalyticsDate(cell);
        case 'timestamp':
            return typeof cell === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(cell) && isAnalyticsDate(cell.slice(0, 10)) && Number.isFinite(Date.parse(cell));
    }
}

function resolveAnalyticsParameters(binding, controls) {
    const allowed = new Set(binding.parameters.map((parameter)=>parameter.controlId));
    if (Object.keys(controls).some((name)=>!allowed.has(name))) throw new Error('ANALYTICS_UNKNOWN_CONTROL');
    const result = {};
    for (const parameter of binding.parameters){
        const value = Object.prototype.hasOwnProperty.call(controls, parameter.controlId) ? controls[parameter.controlId] : parameter.defaultValue;
        if (value === undefined || value === null) {
            if (parameter.required) throw new Error('ANALYTICS_PARAMETER_REQUIRED');
            result[parameter.name] = null;
            continue;
        }
        const valid = parameter.type === 'date' ? typeof value === 'string' && isAnalyticsDate(value) : typeof value === parameter.type && (typeof value !== 'number' || Number.isFinite(value));
        if (!valid || parameter.allowedValues && !parameter.allowedValues.includes(value)) throw new Error('ANALYTICS_PARAMETER_INVALID');
        result[parameter.name] = value;
    }
    return result;
}
function normalizeAnalyticsResult(binding, result, executionId, maxRows) {
    if (result.rows.length > maxRows) throw new Error('ANALYTICS_ROW_LIMIT');
    const fields = binding.output.fields;
    const keys = fields.map((field)=>{
        const matches = result.columns.filter((column)=>field.semanticRef ? column.semanticRef === field.semanticRef : column.key === field.sourceField);
        if (matches.length !== 1) throw new Error('ANALYTICS_FIELD_MISSING_OR_AMBIGUOUS');
        return matches[0].key;
    });
    const rows = result.rows.map((row)=>Object.fromEntries(fields.map((field, index)=>{
            const cell = row[keys[index]];
            if (cell === undefined || !isAnalyticsCell(field.logicalType, cell, field.nullable)) throw new Error('ANALYTICS_FIELD_TYPE_MISMATCH');
            return [
                field.id,
                cell
            ];
        })));
    if (new TextEncoder().encode(JSON.stringify(rows)).byteLength > 2000000) throw new Error('ANALYTICS_RESULT_TOO_LARGE');
    if (result.completeness.returnedRows !== rows.length) throw new Error('ANALYTICS_ROW_COUNT_MISMATCH');
    if (result.completeness.totalRows !== undefined && (!Number.isSafeInteger(result.completeness.totalRows) || result.completeness.totalRows < rows.length)) throw new Error('ANALYTICS_TOTAL_COUNT_INVALID');
    if (result.completeness.truncated && result.completeness.scope === 'full_query_result') throw new Error('ANALYTICS_COMPLETENESS_INVALID');
    if (!Number.isFinite(Date.parse(result.sourceFetchedAt))) throw new Error('ANALYTICS_FRESHNESS_INVALID');
    if (binding.output.grain.length && new Set(rows.map((row)=>JSON.stringify(binding.output.grain.map((key)=>row[key])))).size !== rows.length) throw new Error('ANALYTICS_GRAIN_MISMATCH');
    return {
        schema: 'xpert.analytics.dataset',
        datasetId: binding.output.datasetId,
        fields,
        rows,
        grain: binding.output.grain,
        completeness: result.completeness,
        freshness: {
            executedAt: new Date().toISOString(),
            sourceFetchedAt: result.sourceFetchedAt,
            dataAsOf: result.dataAsOf
        },
        provenance: _extends._extends({
            executionId,
            bindingId: binding.id,
            providerId: binding.providerId,
            sourceVersion: result.sourceVersion,
            upstreamExecutionId: result.upstreamExecutionId,
            auditRef: result.auditRef
        }, result.certification !== undefined ? {
            certification: parseAnalyticsCertification(result.certification)
        } : {})
    };
}

exports.analyticsBindingObjectSchema = analyticsBindingObjectSchema;
exports.analyticsBindingSchema = analyticsBindingSchema;
exports.analyticsCertificationSchema = analyticsCertificationSchema;
exports.analyticsControlsSchema = analyticsControlsSchema;
exports.analyticsDiscoveryRequestObjectSchema = analyticsDiscoveryRequestObjectSchema;
exports.analyticsDiscoveryRequestSchema = analyticsDiscoveryRequestSchema;
exports.analyticsDiscoveryResultSchema = analyticsDiscoveryResultSchema;
exports.analyticsFieldSchema = analyticsFieldSchema;
exports.analyticsOptionsSchema = analyticsOptionsSchema;
exports.analyticsParameterSchema = analyticsParameterSchema;
exports.analyticsQueryRequestSchema = analyticsQueryRequestSchema;
exports.analyticsSourceKey = analyticsSourceKey;
exports.analyticsSourceRefSchema = analyticsSourceRefSchema;
exports.isAnalyticsCell = isAnalyticsCell;
exports.normalizeAnalyticsResult = normalizeAnalyticsResult;
exports.parseAnalyticsCertification = parseAnalyticsCertification;
exports.resolveAnalyticsParameters = resolveAnalyticsParameters;
exports.validateAnalyticsBinding = validateAnalyticsBinding;
