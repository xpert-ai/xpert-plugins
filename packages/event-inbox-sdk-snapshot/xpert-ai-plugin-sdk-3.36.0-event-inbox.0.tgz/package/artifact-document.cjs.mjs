export * from './artifact-document.cjs.js';
export { _default as default } from './artifact-document.cjs.default.js';