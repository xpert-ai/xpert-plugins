import { z } from 'zod/v3';
import { _ as _extends } from './_extends.esm.js';

const key = z.string().regex(/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/);
const value = z.union([
    z.string().max(4000),
    z.number().finite(),
    z.boolean(),
    z.null()
]);
const json = z.lazy(()=>z.union([
        z.string().max(32000),
        z.number().finite(),
        z.boolean(),
        z.null(),
        z.array(json).max(1000),
        z.record(json)
    ]));
const analyticsSourceRefSchema = z.discriminatedUnion('kind', [
    z.object({
        kind: z.literal('data-source'),
        dataSourceId: z.string().uuid()
    }).strict(),
    z.object({
        kind: z.literal('definition'),
        definitionId: z.string().uuid(),
        versionId: z.string().uuid()
    }).strict(),
    z.object({
        kind: z.literal('artifact'),
        artifactId: z.string().uuid(),
        versionId: z.string().uuid()
    }).strict()
]);
const analyticsOptionsSchema = z.record(json);
const analyticsFieldSchema = z.object({
    id: key,
    sourceField: z.string().min(1).max(256),
    label: z.string().min(1).max(160),
    logicalType: z.enum([
        'string',
        'boolean',
        'int64',
        'float64',
        'decimal',
        'date',
        'timestamp'
    ]),
    nullable: z.boolean(),
    role: z.enum([
        'dimension',
        'measure',
        'time',
        'identifier'
    ]),
    semanticRef: z.string().max(512).optional(),
    unit: z.string().max(80).optional()
}).strict();
const analyticsParameterSchema = z.object({
    name: key,
    controlId: key,
    type: z.enum([
        'string',
        'number',
        'boolean',
        'date'
    ]),
    required: z.boolean(),
    defaultValue: value.optional(),
    allowedValues: z.array(value).max(200).optional()
}).strict();
const analyticsBindingObjectSchema = z.object({
    id: key,
    source: analyticsSourceRefSchema,
    providerId: z.string().min(1).max(160),
    operation: key,
    contractVersion: z.number().int().positive(),
    payload: json,
    parameters: z.array(analyticsParameterSchema).max(24),
    output: z.object({
        datasetId: key,
        fields: z.array(analyticsFieldSchema).min(1).max(80),
        grain: z.array(key).max(20)
    }).strict()
}).strict();
function validateAnalyticsBinding(binding, ctx) {
    const fields = binding.output.fields.map((field)=>field.id);
    const names = binding.parameters.map((parameter)=>parameter.name);
    if (new Set(fields).size !== fields.length || new Set(names).size !== names.length) ctx.addIssue({
        code: 'custom',
        message: 'Duplicate field or parameter identifier'
    });
    if (new Set(binding.output.grain).size !== binding.output.grain.length || binding.output.grain.some((field)=>!fields.includes(field))) ctx.addIssue({
        code: 'custom',
        message: 'Grain references an undeclared field'
    });
    if (new TextEncoder().encode(JSON.stringify(binding.payload)).byteLength > 64000) ctx.addIssue({
        code: 'custom',
        message: 'Query payload exceeds limit'
    });
}
const analyticsBindingSchema = analyticsBindingObjectSchema.superRefine(validateAnalyticsBinding);
const analyticsControlsSchema = z.record(key, value).default({});
const analyticsQueryRequestSchema = z.object({
    binding: analyticsBindingSchema,
    controls: analyticsControlsSchema,
    cache: z.object({
        maxAgeMs: z.number().int().min(0).max(60000),
        forceRefresh: z.boolean().optional()
    }).strict().optional()
}).strict();
const analyticsDiscoveryRequestObjectSchema = z.object({
    source: analyticsSourceRefSchema,
    providerId: z.string().min(1).max(160),
    request: json.default({})
}).strict();
const analyticsDiscoveryRequestSchema = analyticsDiscoveryRequestObjectSchema.refine((value)=>new TextEncoder().encode(JSON.stringify(value)).byteLength <= 16000, 'Discovery request exceeds limit');
const analyticsDiscoveryResultSchema = z.object({
    items: z.array(z.object({
        id: z.string().min(1).max(512),
        name: z.string().min(1).max(512),
        kind: z.enum([
            'collection',
            'dataset'
        ]),
        description: z.string().max(4000).optional(),
        inspectRequest: json.optional(),
        metadata: json
    }).strict()).max(50),
    nextRequest: json.optional(),
    queryContract: z.object({
        operation: key,
        contractVersion: z.number().int().positive(),
        payloadSchema: json,
        instructions: z.string().max(8000)
    }).strict()
}).strict().refine((value)=>new TextEncoder().encode(JSON.stringify(value)).byteLength <= 128000, 'Discovery response exceeds limit');
/** Stable identity for source selection and scoped discovery receipts. */ function analyticsSourceKey(source) {
    switch(source.kind){
        case 'data-source':
            return `data-source/${source.dataSourceId}`;
        case 'definition':
            return `definition/${source.definitionId}/${source.versionId}`;
        case 'artifact':
            return `artifact/${source.artifactId}/${source.versionId}`;
    }
}

const identity = {
    kind: z.literal('business_metric'),
    subjectId: z.string().min(1).max(160),
    verifiedAt: z.string().datetime()
};
/** Parse only provider results. A valid shape alone never grants certification authority.
 * Legacy records remain explicitly unverified; approval fields require a verified source proof. */ const analyticsCertificationSchema = z.discriminatedUnion('status', [
    z.object(_extends({}, identity, {
        status: z.literal('legacy_unverified')
    })).strict(),
    z.object(_extends({}, identity, {
        status: z.literal('verified'),
        definitionHash: z.string().regex(/^[a-f0-9]{64}$/),
        dependency: z.object({
            id: z.string().min(1).max(160),
            version: z.number().int().nonnegative()
        }).strict(),
        certifiedBy: z.string().min(1).max(160),
        certifiedAt: z.string().datetime()
    })).strict()
]);
/** The package supports hosts compiled without strictNullChecks; parsing still requires every field. */ function parseAnalyticsCertification(value) {
    return analyticsCertificationSchema.parse(value);
}

/** Shared wire-value rules for normalized query results and immutable evidence snapshots. */ function isAnalyticsDate(value) {
    // Date.parse normalizes some impossible dates; round-trip validation rejects that rollover.
    return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}
/** int64/decimal stay strings on the wire to avoid JavaScript number rounding; never coerce them. */ function isAnalyticsCell(type, cell, nullable) {
    if (cell === null) return nullable;
    switch(type){
        case 'string':
            return typeof cell === 'string';
        case 'boolean':
            return typeof cell === 'boolean';
        case 'float64':
            return typeof cell === 'number' && Number.isFinite(cell);
        case 'int64':
            return typeof cell === 'string' && /^-?\d{1,19}$/.test(cell) && BigInt(cell) >= -(2n ** 63n) && BigInt(cell) < 2n ** 63n;
        case 'decimal':
            return typeof cell === 'string' && /^-?\d+(\.\d+)?$/.test(cell);
        case 'date':
            return typeof cell === 'string' && isAnalyticsDate(cell);
        case 'timestamp':
            return typeof cell === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(cell) && isAnalyticsDate(cell.slice(0, 10)) && Number.isFinite(Date.parse(cell));
    }
}

function resolveAnalyticsParameters(binding, controls) {
    const allowed = new Set(binding.parameters.map((parameter)=>parameter.controlId));
    if (Object.keys(controls).some((name)=>!allowed.has(name))) throw new Error('ANALYTICS_UNKNOWN_CONTROL');
    const result = {};
    for (const parameter of binding.parameters){
        const value = Object.prototype.hasOwnProperty.call(controls, parameter.controlId) ? controls[parameter.controlId] : parameter.defaultValue;
        if (value === undefined || value === null) {
            if (parameter.required) throw new Error('ANALYTICS_PARAMETER_REQUIRED');
            result[parameter.name] = null;
            continue;
        }
        const valid = parameter.type === 'date' ? typeof value === 'string' && isAnalyticsDate(value) : typeof value === parameter.type && (typeof value !== 'number' || Number.isFinite(value));
        if (!valid || parameter.allowedValues && !parameter.allowedValues.includes(value)) throw new Error('ANALYTICS_PARAMETER_INVALID');
        result[parameter.name] = value;
    }
    return result;
}
function normalizeAnalyticsResult(binding, result, executionId, maxRows) {
    if (result.rows.length > maxRows) throw new Error('ANALYTICS_ROW_LIMIT');
    const fields = binding.output.fields;
    const keys = fields.map((field)=>{
        const matches = result.columns.filter((column)=>field.semanticRef ? column.semanticRef === field.semanticRef : column.key === field.sourceField);
        if (matches.length !== 1) throw new Error('ANALYTICS_FIELD_MISSING_OR_AMBIGUOUS');
        return matches[0].key;
    });
    const rows = result.rows.map((row)=>Object.fromEntries(fields.map((field, index)=>{
            const cell = row[keys[index]];
            if (cell === undefined || !isAnalyticsCell(field.logicalType, cell, field.nullable)) throw new Error('ANALYTICS_FIELD_TYPE_MISMATCH');
            return [
                field.id,
                cell
            ];
        })));
    if (new TextEncoder().encode(JSON.stringify(rows)).byteLength > 2000000) throw new Error('ANALYTICS_RESULT_TOO_LARGE');
    if (result.completeness.returnedRows !== rows.length) throw new Error('ANALYTICS_ROW_COUNT_MISMATCH');
    if (result.completeness.totalRows !== undefined && (!Number.isSafeInteger(result.completeness.totalRows) || result.completeness.totalRows < rows.length)) throw new Error('ANALYTICS_TOTAL_COUNT_INVALID');
    if (result.completeness.truncated && result.completeness.scope === 'full_query_result') throw new Error('ANALYTICS_COMPLETENESS_INVALID');
    if (!Number.isFinite(Date.parse(result.sourceFetchedAt))) throw new Error('ANALYTICS_FRESHNESS_INVALID');
    if (binding.output.grain.length && new Set(rows.map((row)=>JSON.stringify(binding.output.grain.map((key)=>row[key])))).size !== rows.length) throw new Error('ANALYTICS_GRAIN_MISMATCH');
    return {
        schema: 'xpert.analytics.dataset',
        datasetId: binding.output.datasetId,
        fields,
        rows,
        grain: binding.output.grain,
        completeness: result.completeness,
        freshness: {
            executedAt: new Date().toISOString(),
            sourceFetchedAt: result.sourceFetchedAt,
            dataAsOf: result.dataAsOf
        },
        provenance: _extends({
            executionId,
            bindingId: binding.id,
            providerId: binding.providerId,
            sourceVersion: result.sourceVersion,
            upstreamExecutionId: result.upstreamExecutionId,
            auditRef: result.auditRef
        }, result.certification !== undefined ? {
            certification: parseAnalyticsCertification(result.certification)
        } : {})
    };
}

export { analyticsCertificationSchema as a, analyticsFieldSchema as b, analyticsBindingObjectSchema as c, analyticsBindingSchema as d, analyticsControlsSchema as e, analyticsDiscoveryRequestObjectSchema as f, analyticsDiscoveryRequestSchema as g, analyticsDiscoveryResultSchema as h, isAnalyticsCell as i, analyticsOptionsSchema as j, analyticsParameterSchema as k, analyticsQueryRequestSchema as l, analyticsSourceKey as m, analyticsSourceRefSchema as n, normalizeAnalyticsResult as o, parseAnalyticsCertification as p, resolveAnalyticsParameters as r, validateAnalyticsBinding as v };
