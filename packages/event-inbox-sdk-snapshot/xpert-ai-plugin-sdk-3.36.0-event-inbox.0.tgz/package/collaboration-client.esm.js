import { _ as _extends } from './_extends.esm.js';

function createCollaborationPresenceStore(options = {}) {
    let selfClientId = null;
    let sessions = new Map();
    const readSnapshot = ()=>{
        const activeSessions = Array.from(sessions.values()).sort((left, right)=>right.updatedAt - left.updatedAt);
        const remoteSessions = activeSessions.filter((item)=>item.clientId !== selfClientId);
        const actors = new Map();
        for (const item of activeSessions)if (!actors.has(item.presenceId)) actors.set(item.presenceId, item);
        if (options.includeSelf !== false && options.selfActor) {
            const existing = activeSessions.find((item)=>{
                var _options_selfActor;
                return item.clientId === selfClientId || item.presenceId === ((_options_selfActor = options.selfActor) == null ? void 0 : _options_selfActor.presenceId);
            });
            actors.set(options.selfActor.presenceId, existing != null ? existing : actorPresence(options.selfActor, selfClientId));
        }
        const collaborators = Array.from(actors.values()).sort((left, right)=>{
            var _options_selfActor, _options_selfActor1;
            const leftSelf = left.presenceId === ((_options_selfActor = options.selfActor) == null ? void 0 : _options_selfActor.presenceId) ? 1 : 0;
            const rightSelf = right.presenceId === ((_options_selfActor1 = options.selfActor) == null ? void 0 : _options_selfActor1.presenceId) ? 1 : 0;
            return rightSelf - leftSelf || right.updatedAt - left.updatedAt;
        });
        return {
            selfClientId,
            sessions: activeSessions,
            remoteSessions,
            collaborators
        };
    };
    const publish = ()=>options.onChange == null ? void 0 : options.onChange.call(options, readSnapshot());
    return {
        setSelfClientId: (clientId)=>{
            selfClientId = clientId;
            publish();
        },
        replace: (items, clientId = selfClientId)=>{
            selfClientId = clientId;
            sessions = new Map(items.map((item)=>[
                    item.clientId,
                    item
                ]));
            publish();
        },
        upsert: (item)=>{
            sessions.set(item.clientId, item);
            publish();
        },
        remove: (clientId)=>{
            if (sessions.delete(clientId)) publish();
        },
        clear: ()=>{
            sessions.clear();
            selfClientId = null;
            publish();
        },
        snapshot: readSnapshot
    };
}
function actorPresence(actor, clientId) {
    return _extends({}, actor, {
        clientId: clientId != null ? clientId : `self:${actor.presenceId}`,
        pageId: null,
        pointer: null,
        focus: null,
        selection: null,
        viewport: null,
        mode: null,
        status: null,
        toolName: null,
        operationLabel: null,
        updatedAt: Date.now()
    });
}
/** Parse untrusted presence payloads shared by both engines; document content is ignored. */ function parseCollaborationPresence(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const item = value;
    const clientId = stringValue$1('clientId' in item ? item.clientId : undefined);
    const presenceId = stringValue$1('presenceId' in item ? item.presenceId : undefined);
    const displayName = stringValue$1('displayName' in item ? item.displayName : undefined);
    const color = stringValue$1('color' in item ? item.color : undefined);
    const actorType = 'actorType' in item ? item.actorType : undefined;
    if (!clientId || !presenceId || !displayName || !color || actorType !== 'user' && actorType !== 'agent' && actorType !== 'system') return null;
    return {
        clientId,
        presenceId,
        displayName,
        color,
        actorType,
        avatarUrl: nullableString('avatarUrl' in item ? item.avatarUrl : undefined),
        pageId: nullableString('pageId' in item ? item.pageId : undefined),
        pointer: parsePointer('pointer' in item ? item.pointer : undefined),
        focus: parseFocus('focus' in item ? item.focus : undefined),
        selection: parseSelection('selection' in item ? item.selection : undefined),
        viewport: parseViewport('viewport' in item ? item.viewport : undefined),
        mode: nullableString('mode' in item ? item.mode : undefined),
        status: actorStatus('status' in item ? item.status : undefined),
        toolName: nullableString('toolName' in item ? item.toolName : undefined),
        operationLabel: nullableString('operationLabel' in item ? item.operationLabel : undefined),
        updatedAt: 'updatedAt' in item && typeof item.updatedAt === 'number' ? item.updatedAt : Date.now()
    };
}
function parsePointer(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const item = value;
    if (!('x' in item) || typeof item.x !== 'number' || !('y' in item) || typeof item.y !== 'number') return null;
    return {
        pageId: nullableString('pageId' in item ? item.pageId : undefined),
        x: item.x,
        y: item.y,
        visible: ('visible' in item ? item.visible : undefined) !== false
    };
}
function parseFocus(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const item = value;
    const kind = stringValue$1('kind' in item ? item.kind : undefined);
    if (!kind) return null;
    return {
        kind,
        key: nullableString('key' in item ? item.key : undefined),
        pageId: nullableString('pageId' in item ? item.pageId : undefined),
        elementId: nullableString('elementId' in item ? item.elementId : undefined),
        fieldKey: nullableString('fieldKey' in item ? item.fieldKey : undefined)
    };
}
function parseSelection(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const item = value;
    const kind = 'kind' in item ? item.kind : undefined;
    if (kind === 'cells') {
        const cells = 'cells' in item ? item.cells : undefined;
        if (!cells || typeof cells !== 'object' || !('sheetId' in cells) || typeof cells.sheetId !== 'string' || !cells.sheetId || cells.sheetId.length > 256 || !('startRow' in cells) || !('endRow' in cells) || !('startColumn' in cells) || !('endColumn' in cells)) return null;
        const { sheetId, startRow, endRow, startColumn, endColumn } = cells;
        if (typeof startRow !== 'number' || typeof endRow !== 'number' || typeof startColumn !== 'number' || typeof endColumn !== 'number' || ![
            startRow,
            endRow,
            startColumn,
            endColumn
        ].every(Number.isSafeInteger) || startRow < 0 || startColumn < 0 || endRow < startRow || endColumn < startColumn || endRow > 1048575 || endColumn > 16383) return null;
        const baseRevision = 'baseRevision' in cells ? cells.baseRevision : undefined;
        if (baseRevision !== undefined && (typeof baseRevision !== 'number' || !Number.isSafeInteger(baseRevision) || baseRevision < 1)) return null;
        return {
            kind,
            cells: _extends({
                sheetId,
                startRow,
                endRow,
                startColumn,
                endColumn
            }, typeof baseRevision === 'number' ? {
                baseRevision
            } : {})
        };
    }
    if (kind !== 'text' && kind !== 'elements') return null;
    const elementIds = 'elementIds' in item ? item.elementIds : undefined;
    return {
        kind,
        fieldKey: nullableString('fieldKey' in item ? item.fieldKey : undefined),
        elementIds: Array.isArray(elementIds) ? elementIds.filter((entry)=>typeof entry === 'string') : null,
        anchorRelativeBase64: nullableString('anchorRelativeBase64' in item ? item.anchorRelativeBase64 : undefined),
        headRelativeBase64: nullableString('headRelativeBase64' in item ? item.headRelativeBase64 : undefined)
    };
}
function parseViewport(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const item = value;
    if (!('zoom' in item) || typeof item.zoom !== 'number' || !('width' in item) || typeof item.width !== 'number' || !('height' in item) || typeof item.height !== 'number') return null;
    return {
        zoom: item.zoom,
        width: item.width,
        height: item.height
    };
}
function stringValue$1(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
function nullableString(value) {
    var _stringValue;
    return (_stringValue = stringValue$1(value)) != null ? _stringValue : null;
}
function actorStatus(value) {
    return value === 'thinking' || value === 'editing' || value === 'done' || value === 'failed' ? value : null;
}

/** Adapt a caller-owned Socket.IO client to the SDK's framework-neutral transport. */ function createSocketIoTransportAdapter(socket) {
    return {
        get connected () {
            return socket.connected;
        },
        get clientId () {
            var _socket_id;
            return (_socket_id = socket.id) != null ? _socket_id : null;
        },
        connect: ()=>{
            socket.connect();
        },
        disconnect: ()=>{
            socket.disconnect();
        },
        emit: (event, payload = {})=>{
            socket.emit(event, payload);
        },
        on: (event, handler)=>{
            socket.on(event, handler);
            return ()=>{
                socket.off(event, handler);
            };
        }
    };
}

/** Wrap a caller-owned `Y.Doc` without passing it across the runtime capability boundary. */ function createYjsDocumentAdapter(document, yjs) {
    return {
        applyUpdate: (update, origin)=>yjs.applyUpdate(document, update, origin),
        encodeStateVector: ()=>yjs.encodeStateVector(document),
        mergeUpdates: (updates)=>yjs.mergeUpdates(updates),
        onUpdate: (handler)=>{
            document.on('update', handler);
            return ()=>document.off('update', handler);
        }
    };
}
/**
 * Create a Yjs collaboration client with update batching, state-vector repair, presence heartbeat,
 * and reconnect synchronization. The caller retains ownership of the document and transport.
 */ function createCollaborationClient(options) {
    // Legacy sessions omit engine and use Yjs; operations must use its notification client.
    if (options.session.engine && options.session.engine !== 'yjs') {
        throw new Error('Yjs collaboration protocol required');
    }
    const remoteOrigin = Object.freeze({
        kind: 'platform.collaboration.remote'
    });
    const batchMs = positiveInteger(options.batchMs, 40);
    const syncIntervalMs = positiveInteger(options.syncIntervalMs, 2000);
    const presenceHeartbeatMs = positiveInteger(options.presenceHeartbeatMs, 5000);
    const presenceStaleMs = positiveInteger(options.presenceStaleMs, 15000);
    var _options_initialPresence;
    let presence = _extends({}, (_options_initialPresence = options.initialPresence) != null ? _options_initialPresence : {});
    let pending = [];
    let inFlight = [];
    let synchronized = false;
    let flushTimer;
    let syncTimer;
    let presenceTimer;
    let presenceCleanupTimer;
    var _options_transport_clientId;
    let selfClientId = (_options_transport_clientId = options.transport.clientId) != null ? _options_transport_clientId : null;
    let started = false;
    const cleanups = [];
    const presenceSeenAt = new Map();
    const reportError = (error)=>options.onError == null ? void 0 : options.onError.call(options, error instanceof Error ? error : new Error(String(error)));
    const emitPresence = ()=>options.transport.emit('presence', _extends({}, presence));
    // Merge the short burst of local Yjs transactions into one network update.
    const flush = ()=>{
        if (flushTimer) clearTimeout(flushTimer);
        flushTimer = undefined;
        if (!pending.length || inFlight.length || !synchronized || !options.transport.connected) return;
        const updates = pending;
        pending = [];
        // Keep bytes until the server acknowledges persistence. Replaying a Yjs update
        // after a lost acknowledgement is idempotent; dropping it could lose an edit.
        inFlight = updates;
        options.transport.emit('update', {
            updateBase64: bytesToBase64(options.document.mergeUpdates(updates)),
            origin: 'plugin-client'
        });
    };
    // A state vector lets the server return only bytes missing from this client.
    const requestSync = ()=>{
        if (!options.transport.connected) return;
        options.transport.emit('sync-request', {
            stateVectorBase64: bytesToBase64(options.document.encodeStateVector())
        });
    };
    // Mark server updates with `remoteOrigin` so the document observer does not send them back.
    const applyRemote = (payload)=>{
        const encoded = stringValue(payload['updateBase64']);
        if (!encoded) return;
        try {
            options.document.applyUpdate(base64ToBytes(encoded), remoteOrigin);
        } catch (error) {
            reportError(error);
        }
    };
    // Register listeners once, then start repair and presence heartbeats before opening the socket.
    const connect = ()=>{
        if (started) return;
        started = true;
        options.onConnectionChange == null ? void 0 : options.onConnectionChange.call(options, 'connecting');
        cleanups.push(options.document.onUpdate((update, origin)=>{
            if (origin === remoteOrigin || options.session.access !== 'write') return;
            pending.push(update);
            if (!flushTimer) flushTimer = setTimeout(flush, batchMs);
        }));
        cleanups.push(options.transport.on('connect', ()=>{
            synchronized = false;
            var _options_transport_clientId;
            selfClientId = (_options_transport_clientId = options.transport.clientId) != null ? _options_transport_clientId : selfClientId;
            options.onConnectionChange == null ? void 0 : options.onConnectionChange.call(options, 'connected');
            requestSync();
            emitPresence();
        }));
        cleanups.push(options.transport.on('disconnect', ()=>{
            synchronized = false;
            pending = [
                ...inFlight,
                ...pending
            ];
            inFlight = [];
            options.onConnectionChange == null ? void 0 : options.onConnectionChange.call(options, 'disconnected');
        }));
        cleanups.push(options.transport.on('sync', (payload)=>{
            applyRemote(payload);
            // The initial sync is sent only after session authorization and room setup.
            // A raw socket connect can precede that setup, so do not flush on connect.
            if (stringValue(payload['updateBase64'])) {
                synchronized = true;
                flush();
            }
        }));
        cleanups.push(options.transport.on('update', applyRemote));
        cleanups.push(options.transport.on('update-ack', (payload)=>{
            const ack = parseAck(payload);
            if (ack && ack.documentId === options.session.documentId) {
                inFlight = [];
                options.onAck == null ? void 0 : options.onAck.call(options, ack);
                flush();
            }
        }));
        cleanups.push(options.transport.on('presence', (payload)=>{
            const item = parseCollaborationPresence(payload);
            if (item) {
                presenceSeenAt.set(item.clientId, Date.now());
                options.onPresence == null ? void 0 : options.onPresence.call(options, item);
            }
        }));
        cleanups.push(options.transport.on('presence-snapshot', (payload)=>{
            const rawItems = payload['items'];
            const items = Array.isArray(rawItems) ? rawItems.map(parseCollaborationPresence).filter(isPresence) : [];
            var _stringValue, _ref;
            selfClientId = (_ref = (_stringValue = stringValue(payload['selfClientId'])) != null ? _stringValue : options.transport.clientId) != null ? _ref : selfClientId;
            presenceSeenAt.clear();
            for (const item of items)presenceSeenAt.set(item.clientId, Date.now());
            options.onPresenceSnapshot == null ? void 0 : options.onPresenceSnapshot.call(options, items, {
                selfClientId
            });
        }));
        cleanups.push(options.transport.on('presence-remove', (payload)=>{
            const clientId = stringValue(payload['clientId']);
            if (clientId) {
                presenceSeenAt.delete(clientId);
                options.onPresenceRemove == null ? void 0 : options.onPresenceRemove.call(options, clientId);
            }
        }));
        cleanups.push(options.transport.on('error', (payload)=>{
            var _stringValue;
            return reportError((_stringValue = stringValue(payload['message'])) != null ? _stringValue : 'Collaboration failed.');
        }));
        syncTimer = setInterval(requestSync, syncIntervalMs);
        presenceTimer = setInterval(emitPresence, presenceHeartbeatMs);
        presenceCleanupTimer = setInterval(()=>{
            const cutoff = Date.now() - presenceStaleMs;
            for (const [clientId, seenAt] of presenceSeenAt){
                if (clientId === selfClientId || seenAt >= cutoff) continue;
                presenceSeenAt.delete(clientId);
                options.onPresenceRemove == null ? void 0 : options.onPresenceRemove.call(options, clientId);
            }
        }, Math.min(5000, Math.max(1000, Math.floor(presenceStaleMs / 3))));
        options.transport.connect();
    };
    // Flush best-effort pending state and release all timers/listeners owned by this client.
    const disconnect = ()=>{
        var _cleanups_pop;
        if (!started) return;
        flush();
        started = false;
        if (flushTimer) clearTimeout(flushTimer);
        if (syncTimer) clearInterval(syncTimer);
        if (presenceTimer) clearInterval(presenceTimer);
        if (presenceCleanupTimer) clearInterval(presenceCleanupTimer);
        flushTimer = undefined;
        syncTimer = undefined;
        presenceTimer = undefined;
        presenceCleanupTimer = undefined;
        presenceSeenAt.clear();
        while(cleanups.length)(_cleanups_pop = cleanups.pop()) == null ? void 0 : _cleanups_pop();
        options.transport.disconnect();
        options.onConnectionChange == null ? void 0 : options.onConnectionChange.call(options, 'disconnected');
    };
    return {
        get selfClientId () {
            return selfClientId;
        },
        remoteOrigin,
        connect,
        disconnect,
        flush,
        requestSync,
        setPresence: (patch)=>{
            presence = _extends({}, presence, patch);
            if (options.transport.connected) emitPresence();
        }
    };
}
/** Encode bytes in browsers without Node.js `Buffer`; chunks avoid argument-size limits. */ function bytesToBase64(bytes) {
    let binary = '';
    const chunkSize = 0x8000;
    for(let offset = 0; offset < bytes.length; offset += chunkSize){
        binary += String.fromCharCode(...bytes.subarray(offset, Math.min(offset + chunkSize, bytes.length)));
    }
    return globalThis.btoa(binary);
}
/** Decode base64 in browsers without requiring Node.js polyfills. */ function base64ToBytes(value) {
    const binary = globalThis.atob(value);
    const bytes = new Uint8Array(binary.length);
    for(let index = 0; index < binary.length; index += 1)bytes[index] = binary.charCodeAt(index);
    return bytes;
}
function parseAck(payload) {
    const documentId = stringValue(payload['documentId']);
    const stateVectorBase64 = stringValue(payload['stateVectorBase64']);
    const sequenceNumber = payload['sequenceNumber'];
    if (!documentId || !stateVectorBase64 || typeof sequenceNumber !== 'number') return null;
    const materializationStatus = payload['materializationStatus'];
    if (materializationStatus !== 'ready' && materializationStatus !== 'pending' && materializationStatus !== 'failed') return null;
    return {
        documentId,
        duplicate: payload['duplicate'] === true,
        sequenceNumber,
        updateId: stringValue(payload['updateId']),
        stateVectorBase64,
        materializationStatus
    };
}
function isPresence(value) {
    return value !== null;
}
function stringValue(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
function positiveInteger(value, fallback) {
    return Number.isFinite(value) && Number(value) > 0 ? Math.trunc(Number(value)) : fallback;
}

/**
 * Notification client for a domain-owned operation log, not an OT/CRDT implementation.
 * The domain API owns writes, validation, conflict handling and persistence. This client
 * only tracks committed revisions and ephemeral presence; it never submits business edits.
 * Revisions coalesce to one high-water mark, so consumers must refetch authoritative state.
 */ function createOperationCollaborationClient(options) {
    if (options.session.engine !== 'operations') throw new Error('Operation collaboration protocol required');
    const { transport, session } = options;
    const presence = new Map();
    let revision = -1, stopped = false, selfClientId = null;
    let patch = {};
    let presenceTimer;
    const changed = ()=>options.onPresence([
            ...presence.values()
        ], selfClientId);
    const addPresence = (value)=>{
        const item = parseCollaborationPresence(value);
        if (!item || presence.size >= 128 && !presence.has(item.clientId)) return;
        presence.set(item.clientId, item);
    };
    // Repair missed invalidations on reconnect/periodic sync; no Yjs state vector is involved.
    const sync = ()=>{
        if (!stopped && transport.connected) transport.emit('sync-request', {});
    };
    const heartbeat = ()=>{
        if (stopped) return;
        if (Date.now() >= session.expiresAt) {
            options.onError(new Error('Collaboration session expired'));
            disconnect();
            return;
        }
        if (transport.connected) transport.emit('presence', patch);
        for (const [id, item] of presence)if (item.updatedAt < Date.now() - 15000) presence.delete(id);
        changed();
    };
    const stops = [
        transport.on('connect', ()=>{
            var _transport_clientId;
            selfClientId = (_transport_clientId = transport.clientId) != null ? _transport_clientId : null;
            options.onConnection('connected');
            sync();
            heartbeat();
        }),
        transport.on('disconnect', ()=>{
            presence.clear();
            changed();
            options.onConnection('disconnected');
        }),
        transport.on('revision', (value)=>{
            if (value['documentId'] !== session.documentId || typeof value['revision'] !== 'number' || !Number.isSafeInteger(value['revision']) || value['revision'] < 0 || value['revision'] <= revision) return;
            revision = value['revision'];
            options.onRevision(revision);
        }),
        transport.on('presence-snapshot', (value)=>{
            presence.clear();
            var _transport_clientId;
            selfClientId = typeof value['selfClientId'] === 'string' ? value['selfClientId'] : (_transport_clientId = transport.clientId) != null ? _transport_clientId : null;
            if (Array.isArray(value['items'])) value['items'].slice(0, 128).forEach(addPresence);
            changed();
        }),
        transport.on('presence', (value)=>{
            addPresence(value);
            changed();
        }),
        transport.on('presence-remove', (value)=>{
            if (typeof value['clientId'] === 'string') presence.delete(value['clientId']);
            changed();
        }),
        transport.on('error', (value)=>options.onError(new Error(typeof value['message'] === 'string' ? value['message'] : 'Collaboration disconnected')))
    ];
    const heartbeatTimer = setInterval(heartbeat, 5000), syncTimer = setInterval(sync, 15000);
    function disconnect() {
        if (stopped) return;
        stopped = true;
        clearInterval(heartbeatTimer);
        clearInterval(syncTimer);
        clearTimeout(presenceTimer);
        stops.forEach((stop)=>stop());
        transport.disconnect();
        presence.clear();
        changed();
        options.onConnection('disconnected');
    }
    return {
        connect () {
            if (!stopped) transport.connect();
        },
        disconnect,
        requestSync: sync,
        setPresence (value) {
            patch = value;
            if (!stopped && !presenceTimer) presenceTimer = setTimeout(()=>{
                presenceTimer = undefined;
                if (transport.connected && !stopped) transport.emit('presence', patch);
            }, 120);
        }
    };
}

export { base64ToBytes, bytesToBase64, createCollaborationClient, createCollaborationPresenceStore, createOperationCollaborationClient, createSocketIoTransportAdapter, createYjsDocumentAdapter, parseCollaborationPresence };
