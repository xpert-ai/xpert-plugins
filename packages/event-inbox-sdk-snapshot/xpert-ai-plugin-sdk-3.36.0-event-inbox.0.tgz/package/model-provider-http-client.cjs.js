'use strict';

var _extends = require('./_extends.cjs.js');

class ModelProviderHttpError extends Error {
    constructor(message, status){
        super(message);
        this.status = status;
        this.name = 'ModelProviderHttpError';
    }
}
/**
 * Shared HTTP transport for model Provider adapters.
 *
 * Provider-specific authentication headers are supplied at construction time;
 * response parsing, task semantics, and download URL policy stay in each adapter.
 */ class ModelProviderHttpClient {
    async requestJson(pathOrUrl, init, parse) {
        const response = await this.fetchResponse(this.resolveRequestUrl(pathOrUrl), _extends._extends({}, init, {
            headers: this.mergeHeaders(init.headers)
        }), this.requestTimeoutMs);
        if (!response.ok) {
            throw await this.createHttpError(response);
        }
        return parse(await response.json());
    }
    async fetchResponse(input, init = {}, timeoutMs) {
        var _init_signal;
        if (!timeoutMs) {
            return this.fetchImpl(input, init);
        }
        const controller = new AbortController();
        let timedOut = false;
        const abortFromCaller = ()=>{
            var _init_signal;
            return controller.abort((_init_signal = init.signal) == null ? void 0 : _init_signal.reason);
        };
        if ((_init_signal = init.signal) == null ? void 0 : _init_signal.aborted) {
            abortFromCaller();
        } else {
            var _init_signal1;
            (_init_signal1 = init.signal) == null ? void 0 : _init_signal1.addEventListener('abort', abortFromCaller, {
                once: true
            });
        }
        const timeout = setTimeout(()=>{
            timedOut = true;
            controller.abort();
        }, timeoutMs);
        try {
            return await this.fetchImpl(input, _extends._extends({}, init, {
                signal: controller.signal
            }));
        } catch (error) {
            if (timedOut) {
                throw this.createTimeoutError(timeoutMs);
            }
            throw error;
        } finally{
            var _init_signal2;
            clearTimeout(timeout);
            (_init_signal2 = init.signal) == null ? void 0 : _init_signal2.removeEventListener('abort', abortFromCaller);
        }
    }
    async readBufferResponse(response, options = {}) {
        var _response_headers_get_split_, _response_headers_get;
        const contentLength = response.headers.get('content-length');
        const declaredBytes = contentLength && /^\d+$/u.test(contentLength) ? Number(contentLength) : undefined;
        if (options.maxBytes && declaredBytes && declaredBytes > options.maxBytes) {
            var _options_maxBytesError;
            throw new Error((_options_maxBytesError = options.maxBytesError) != null ? _options_maxBytesError : `${this.provider} result exceeds the download limit`);
        }
        const buffer = Buffer.from(await response.arrayBuffer());
        if (options.maxBytes && buffer.length > options.maxBytes) {
            var _options_maxBytesError1;
            throw new Error((_options_maxBytesError1 = options.maxBytesError) != null ? _options_maxBytesError1 : `${this.provider} result exceeds the download limit`);
        }
        return {
            buffer,
            mimeType: ((_response_headers_get = response.headers.get('content-type')) == null ? void 0 : (_response_headers_get_split_ = _response_headers_get.split(';')[0]) == null ? void 0 : _response_headers_get_split_.trim()) || options.defaultMimeType || undefined
        };
    }
    async createHttpError(response) {
        const text = await response.text().catch(()=>'');
        return new ModelProviderHttpError(`${this.provider} API error ${response.status}: ${text || response.statusText}`, response.status);
    }
    createTimeoutError(timeoutMs) {
        return new Error(`${this.provider} request timed out after ${timeoutMs}ms`);
    }
    resolveRequestUrl(pathOrUrl) {
        return /^https?:\/\//iu.test(pathOrUrl) ? pathOrUrl : `${this.baseUrl}${pathOrUrl.startsWith('/') ? '' : '/'}${pathOrUrl}`;
    }
    mergeHeaders(headers) {
        const merged = _extends._extends({}, this.defaultHeaders);
        const headerNames = new Map(Object.keys(merged).map((key)=>[
                key.toLowerCase(),
                key
            ]));
        new Headers(headers).forEach((value, key)=>{
            var _headerNames_get;
            const targetKey = (_headerNames_get = headerNames.get(key)) != null ? _headerNames_get : key;
            merged[targetKey] = value;
        });
        return merged;
    }
    constructor(options){
        this.provider = options.provider;
        this.baseUrl = options.baseUrl.replace(/\/$/u, '');
        var _options_defaultHeaders;
        this.defaultHeaders = (_options_defaultHeaders = options.defaultHeaders) != null ? _options_defaultHeaders : {};
        var _options_fetchImpl;
        this.fetchImpl = (_options_fetchImpl = options.fetchImpl) != null ? _options_fetchImpl : fetch;
        this.requestTimeoutMs = options.requestTimeoutMs;
    }
}

exports.ModelProviderHttpClient = ModelProviderHttpClient;
exports.ModelProviderHttpError = ModelProviderHttpError;
