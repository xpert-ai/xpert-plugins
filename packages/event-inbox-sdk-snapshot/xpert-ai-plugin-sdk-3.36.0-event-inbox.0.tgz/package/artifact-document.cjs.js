'use strict';

var v3 = require('zod/v3');
var _object_without_properties_loose = require('./_object_without_properties_loose.cjs.js');
var _extends = require('./_extends.cjs.js');

/** Wire namespace/version shared by the trusted host and its isolated document bootstrap. */ const ARTIFACT_DOCUMENT_CHANNEL = 'xpert.artifact-document';
const ARTIFACT_DOCUMENT_VERSION = 1;
/** Portable binding/control identifier; shape validation never grants resource access. */ const artifactDocumentId = v3.z.string().regex(/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/);
const artifactDocumentValue = v3.z.union([
    v3.z.string().max(4000),
    v3.z.number().finite(),
    v3.z.boolean(),
    v3.z.null()
]);
const artifactDocumentControls = v3.z.record(artifactDocumentId, artifactDocumentValue).refine((value)=>Object.keys(value).length <= 24, 'Too many controls');
/** The entire untrusted query envelope. Provider definitions, SQL and identity fields are forbidden. */ const artifactDocumentQuery = v3.z.object({
    type: v3.z.literal('query'),
    requestId: v3.z.string().min(1).max(80),
    bindingId: artifactDocumentId,
    controls: artifactDocumentControls,
    priority: v3.z.enum([
        'interactive',
        'initial',
        'refresh'
    ]).optional()
}).strict();
/** Only public presentation context may cross into the untrusted frame. Never include credentials here. */ const artifactDocumentContext = v3.z.object({
    bindingIds: v3.z.array(artifactDocumentId).max(64).refine((ids)=>new Set(ids).size === ids.length, 'Duplicate binding IDs'),
    defaults: artifactDocumentControls,
    theme: v3.z.enum([
        'light',
        'dark'
    ]),
    locale: v3.z.string().min(1).max(80)
}).strict();
/** Format/UTF-8 size gate, not a sanitizer. Isolation and server authorization enforce security. */ const artifactDocumentHtml = v3.z.string().min(1).max(300000).superRefine((html, ctx)=>{
    if (new TextEncoder().encode(html).byteLength > 300000 || !/<html[\s>]/i.test(html) || !/<body[\s>]/i.test(html)) ctx.addIssue({
        code: 'custom',
        message: 'Supply a complete UTF-8 HTML document, at most 300 KB'
    });
});

// Why this exists: dependency verification is synchronous and also runs on HTTP
// intranets and in opaque-origin documents, where Web Crypto may be unavailable.
// SHA-256 per FIPS 180-4 sections 5/6.2; only for bounded public asset integrity.
// https://doi.org/10.6028/NIST.FIPS.180-4
const ROUND_CONSTANTS = new Uint32Array([
    0x428a2f98,
    0x71374491,
    0xb5c0fbcf,
    0xe9b5dba5,
    0x3956c25b,
    0x59f111f1,
    0x923f82a4,
    0xab1c5ed5,
    0xd807aa98,
    0x12835b01,
    0x243185be,
    0x550c7dc3,
    0x72be5d74,
    0x80deb1fe,
    0x9bdc06a7,
    0xc19bf174,
    0xe49b69c1,
    0xefbe4786,
    0x0fc19dc6,
    0x240ca1cc,
    0x2de92c6f,
    0x4a7484aa,
    0x5cb0a9dc,
    0x76f988da,
    0x983e5152,
    0xa831c66d,
    0xb00327c8,
    0xbf597fc7,
    0xc6e00bf3,
    0xd5a79147,
    0x06ca6351,
    0x14292967,
    0x27b70a85,
    0x2e1b2138,
    0x4d2c6dfc,
    0x53380d13,
    0x650a7354,
    0x766a0abb,
    0x81c2c92e,
    0x92722c85,
    0xa2bfe8a1,
    0xa81a664b,
    0xc24b8b70,
    0xc76c51a3,
    0xd192e819,
    0xd6990624,
    0xf40e3585,
    0x106aa070,
    0x19a4c116,
    0x1e376c08,
    0x2748774c,
    0x34b0bcb5,
    0x391c0cb3,
    0x4ed8aa4a,
    0x5b9cca4f,
    0x682e6ff3,
    0x748f82ee,
    0x78a5636f,
    0x84c87814,
    0x8cc70208,
    0x90befffa,
    0xa4506ceb,
    0xbef9a3f7,
    0xc67178f2
]);
const rotateRight = (value, bits)=>value >>> bits | value << 32 - bits;
/** Internal one-shot digest. Callers bound asset sizes before allocating hashing buffers. */ function sha256Hex(bytes) {
    const padded = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
    padded.set(bytes);
    padded[bytes.length] = 0x80;
    const view = new DataView(padded.buffer);
    // SHA-256 appends the original bit length as a big-endian 64-bit integer.
    view.setUint32(padded.length - 8, Math.floor(bytes.length / 0x20000000));
    view.setUint32(padded.length - 4, bytes.length * 8 >>> 0);
    const state = new Uint32Array([
        0x6a09e667,
        0xbb67ae85,
        0x3c6ef372,
        0xa54ff53a,
        0x510e527f,
        0x9b05688c,
        0x1f83d9ab,
        0x5be0cd19
    ]);
    const words = new Uint32Array(64);
    for(let offset = 0; offset < padded.length; offset += 64){
        for(let i = 0; i < 16; i++)words[i] = view.getUint32(offset + i * 4);
        for(let i = 16; i < 64; i++){
            const x = words[i - 15], y = words[i - 2];
            const s0 = rotateRight(x, 7) ^ rotateRight(x, 18) ^ x >>> 3;
            const s1 = rotateRight(y, 17) ^ rotateRight(y, 19) ^ y >>> 10;
            words[i] = words[i - 16] + s0 + words[i - 7] + s1 >>> 0;
        }
        let [a, b, c, d, e, f, g, h] = state;
        for(let i = 0; i < 64; i++){
            const s1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
            const choice = e & f ^ ~e & g;
            const t1 = h + s1 + choice + ROUND_CONSTANTS[i] + words[i] >>> 0;
            const s0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
            const majority = a & b ^ a & c ^ b & c;
            const t2 = s0 + majority >>> 0;
            h = g;
            g = f;
            f = e;
            e = d + t1 >>> 0;
            d = c;
            c = b;
            b = a;
            a = t1 + t2 >>> 0;
        }
        state[0] = state[0] + a >>> 0;
        state[1] = state[1] + b >>> 0;
        state[2] = state[2] + c >>> 0;
        state[3] = state[3] + d >>> 0;
        state[4] = state[4] + e >>> 0;
        state[5] = state[5] + f >>> 0;
        state[6] = state[6] + g >>> 0;
        state[7] = state[7] + h >>> 0;
    }
    return Array.from(state, (word)=>word.toString(16).padStart(8, '0')).join('');
}

/** A lock is public metadata; only the trusted host resolves it to packaged, immutable bytes. */ const dependencyLockObject = v3.z.object({
    id: artifactDocumentId,
    version: v3.z.string().regex(/^\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?$/),
    format: v3.z.literal('classic-script'),
    global: v3.z.string().regex(/^[A-Za-z_$][A-Za-z0-9_$]{0,79}$/).refine((value)=>![
            'window',
            'self',
            'globalThis',
            'document',
            'parent',
            'top',
            'location',
            'xpertLiveArtifact',
            '__proto__',
            'constructor',
            'prototype'
        ].includes(value)),
    sha256: v3.z.string().regex(/^[a-f0-9]{64}$/)
}).strict();
// Explicit outputs keep required fields in declarations emitted by non-strict host tsconfigs.
const artifactDocumentDependencyLock = dependencyLockObject.transform((value)=>({
        id: value.id,
        version: value.version,
        format: 'classic-script',
        global: value.global,
        sha256: value.sha256
    }));
const artifactDocumentDependencyLocks = v3.z.array(artifactDocumentDependencyLock).max(8).superRefine((values, ctx)=>{
    if (new Set(values.map((value)=>value.id)).size !== values.length || new Set(values.map((value)=>value.global)).size !== values.length) ctx.addIssue({
        code: 'custom',
        message: 'Duplicate dependency ID or global'
    });
});
const artifactDocumentDependencyAssets = v3.z.array(dependencyLockObject.extend({
    source: v3.z.string().min(1).max(4000000)
}).strict().transform((value)=>({
        id: value.id,
        version: value.version,
        format: 'classic-script',
        global: value.global,
        sha256: value.sha256,
        source: value.source
    }))).max(8);
/** Browser/server identical verification. Integrity is not authorization: the caller owns library admission. */ function verifyArtifactDocumentDependencies(input, expected) {
    const assets = artifactDocumentDependencyAssets.parse(input);
    const locks = artifactDocumentDependencyLocks.parse(assets.map((_param)=>{
        var { source } = _param, lock = _object_without_properties_loose._object_without_properties_loose(_param, [
            "source"
        ]);
        return lock;
    }));
    let total = 0;
    for (const asset of assets){
        const bytes = new TextEncoder().encode(asset.source);
        total += bytes.length;
        if (bytes.length > 4000000 || total > 8000000) throw new Error('DOCUMENT_DEPENDENCY_TOO_LARGE');
        if (sha256Hex(bytes) !== asset.sha256) throw new Error('DOCUMENT_DEPENDENCY_INTEGRITY_FAILED');
    }
    if (expected && JSON.stringify(artifactDocumentDependencyLocks.parse(expected)) !== JSON.stringify(locks)) throw new Error('DOCUMENT_DEPENDENCY_LOCK_MISMATCH');
    return assets.map((asset)=>({
            id: asset.id,
            version: asset.version,
            global: asset.global,
            sha256: asset.sha256,
            source: asset.source,
            format: 'classic-script'
        }));
}
/** Assign script.textContent to preserve exact bytes without eval or HTML parser termination hazards. */ function renderArtifactDocumentDependencies(assets) {
    const literal = (value)=>JSON.stringify(value).replace(/</g, '\\u003c').replace(/>/g, '\\u003e');
    return verifyArtifactDocumentDependencies(assets).map((asset)=>`<script>(()=>{const s=document.createElement('script');s.textContent=${literal(asset.source)};document.head.appendChild(s);s.remove();if(typeof window[${literal(asset.global)}]==='undefined')throw new Error('DOCUMENT_DEPENDENCY_GLOBAL_MISSING');})();</script>`).join('');
}

// Only the trusted host supplies this policy. Authored HTML cannot expand it.
const origin = v3.z.string().max(250).refine((value)=>{
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && url.origin === value && !url.username && !url.password && /^(?:[a-z0-9.-]+|\[[a-f0-9:]+\])$/i.test(url.hostname);
    } catch (e) {
        return false;
    }
}, 'Use an exact HTTPS origin without a path, credentials or wildcard');
const origins = v3.z.array(origin).max(16);
const artifactDocumentNetworkPolicy = v3.z.object({
    mode: v3.z.enum([
        'restricted',
        'unrestricted'
    ]).optional(),
    scripts: origins.optional(),
    styles: origins.optional(),
    fonts: origins.optional(),
    images: origins.optional()
}).strict();
function artifactDocumentCsp(input) {
    const policy = artifactDocumentNetworkPolicy.parse(input != null ? input : {});
    if (policy.mode === 'unrestricted') return [
        'default-src * data: blob:',
        "script-src * data: blob: 'unsafe-inline'",
        "style-src * data: blob: 'unsafe-inline'",
        'img-src * data: blob:',
        'font-src * data: blob:',
        'connect-src * data: blob: ws: wss:',
        'media-src * data: blob:',
        'frame-src * data: blob:',
        'worker-src * data: blob:',
        "object-src 'none'",
        "base-uri 'none'",
        "form-action 'none'"
    ].join('; ');
    const sources = (values)=>(values == null ? void 0 : values.length) ? ` ${[
            ...new Set(values)
        ].join(' ')}` : '';
    return [
        "default-src 'none'",
        `script-src 'unsafe-inline'${sources(policy.scripts)}`,
        `style-src 'unsafe-inline'${sources(policy.styles)}`,
        `img-src data: blob:${sources(policy.images)}`,
        `font-src data:${sources(policy.fonts)}`,
        "connect-src 'none'",
        "frame-src 'none'",
        "worker-src 'none'",
        "object-src 'none'",
        "base-uri 'none'",
        "form-action 'none'"
    ].join('; ');
}
/** For preview browser routing; CSP remains the enforcement in the displayed frame. */ function isArtifactDocumentResourceAllowed(policy, resourceType, value) {
    let url;
    try {
        url = new URL(value);
    } catch (e) {
        return false;
    }
    if (policy.mode === 'unrestricted') return [
        'http:',
        'https:',
        'ws:',
        'wss:',
        'data:',
        'blob:'
    ].includes(url.protocol);
    if (url.protocol !== 'https:' || url.username || url.password) return false;
    const allowed = resourceType === 'script' ? policy.scripts : resourceType === 'stylesheet' ? policy.styles : resourceType === 'font' ? policy.fonts : resourceType === 'image' ? policy.images : undefined;
    var _allowed_includes;
    return (_allowed_includes = allowed == null ? void 0 : allowed.includes(url.origin)) != null ? _allowed_includes : false;
}

const ARTIFACT_DOCUMENT_CSP = artifactDocumentCsp();
/** Host-owned prefix precedes all authored markup, including malformed/duplicate heads. */ function renderArtifactDocument(html, sessionId, dependencies = [], networkPolicy) {
    artifactDocumentHtml.parse(html);
    if (!/^[a-f0-9]{32}$/.test(sessionId)) throw new Error('Invalid Artifact document session ID');
    return `<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${artifactDocumentCsp(networkPolicy)}"><script>${ARTIFACT_DOCUMENT_RUNTIME.replace('__XPERT_DOCUMENT_SESSION__', sessionId)}</script>${renderArtifactDocumentDependencies(dependencies)}${html}`;
}
const ARTIFACT_DOCUMENT_RUNTIME = String.raw`
;(() => {
  'use strict'
  const SESSION_ID = '__XPERT_DOCUMENT_SESSION__'
  const CHANNEL = 'xpert.artifact-document',
    VERSION = 1,
    pending = new Map(),
    listeners = new Map(),
    lastControls = new Map(),
    latest = new Map(),
    inFlight = new Map(),
    deliveryLocks = new Map()
  let refreshing = false
  let port,
    context,
    sequence = 0,
    resolveReady
  const ready = new Promise((resolve) => (resolveReady = resolve))
  const emit = (id, dataset) => {
    for (const fn of listeners.get(id) || [])
      try {
        fn(dataset)
      } catch (e) {
        console.error(e)
      }
  }
  const fail = (code) => Object.assign(new Error(code), { code })
  const query = async (bindingId, controls = {}, priority, owner) => {
    await ready
    if (!context.bindingIds.includes(bindingId)) {
      port.postMessage({ type: 'diagnostic', code: 'DOCUMENT_BINDING_DENIED' })
      throw fail('DOCUMENT_BINDING_DENIED')
    }
    if (deliveryLocks.has(bindingId) && deliveryLocks.get(bindingId) !== owner) deliveryLocks.delete(bindingId)
    const values = { ...context.defaults, ...controls },
      key = JSON.stringify(Object.keys(values).sort().map(id => [id, values[id]])),
      previous = inFlight.get(bindingId)
    if (previous && previous.key === key) return previous.promise
    priority = priority || (lastControls.has(bindingId) ? 'interactive' : 'initial')
    const requestId = 'q' + ++sequence
    lastControls.set(bindingId, values)
    latest.set(bindingId, requestId)
    const promise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(requestId)
        reject(fail('DOCUMENT_QUEUE_TIMEOUT'))
      }, 185000)
      pending.set(requestId, { resolve, reject, timer, bindingId })
      port.postMessage({ type: 'query', requestId, bindingId, controls: values, priority })
    })
    inFlight.set(bindingId, { key, promise })
    try { return await promise } finally {
      if (inFlight.get(bindingId)?.promise === promise) inFlight.delete(bindingId)
    }
  }
  const subscribe = (id, fn) => {
    if (typeof fn !== 'function') throw fail('DOCUMENT_INVALID_LISTENER')
    const set = listeners.get(id) || new Set()
    set.add(fn)
    listeners.set(id, set)
    return () => set.delete(fn)
  }
  const refresh = async (id) => query(id, lastControls.get(id) || {}, 'refresh')
  const queryGroup = async (requests, priority) => {
    await ready
    const ids = requests.map(request => request.bindingId)
    if (!ids.length) return { datasets: [], failures: [] }
    if (ids.length > 64 || new Set(ids).size !== ids.length || ids.some(id => !context.bindingIds.includes(id)))
      throw fail('DOCUMENT_BINDING_DENIED')
    const owner = Symbol('query-group')
    ids.forEach(id => deliveryLocks.set(id, owner))
    const results = await Promise.allSettled(requests.map(request => query(request.bindingId, request.controls, priority, owner)))
    const current = ids.every(id => deliveryLocks.get(id) === owner)
    ids.forEach(id => { if (deliveryLocks.get(id) === owner) deliveryLocks.delete(id) })
    if (!current) throw fail('DOCUMENT_QUERY_SUPERSEDED')
    const datasets = [], failures = []
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') { datasets.push(result.value); emit(ids[index], result.value) }
      else failures.push({ bindingId: ids[index], code: result.reason?.code || 'DOCUMENT_QUERY_FAILED' })
    })
    return { datasets, failures }
  }
  // Subscribers see successful members of one filter round together, after it settles.
  const queryMany = (ids, controls = {}) => queryGroup(ids.map(bindingId => ({ bindingId, controls })), 'interactive')
  const bindSelect = (element, config) => {
    if (
      !element ||
      element.tagName !== 'SELECT' ||
      !config ||
      typeof config.bindingId !== 'string' ||
      typeof config.controlId !== 'string' ||
      typeof config.fieldId !== 'string'
    )
      throw fail('DOCUMENT_INVALID_SELECT')
    const allValue = config.allValue === undefined ? null : config.allValue,
      known = new Set(),
      append = (value, label) => {
        const key = JSON.stringify(value)
        if (known.has(key)) return
        known.add(key)
        const option = document.createElement('option')
        option.value = key
        option.textContent = label
        element.append(option)
      }
    element.replaceChildren()
    append(allValue, config.allLabel || 'All')
    const update = (dataset) => {
      const selected = (lastControls.get(config.bindingId) || context.defaults)[config.controlId]
      for (const row of dataset.rows || []) {
        const value = row[config.fieldId]
        if (value !== null && ['string', 'number', 'boolean'].includes(typeof value)) append(value, String(value))
      }
      const key = JSON.stringify(selected === undefined ? allValue : selected)
      if (known.has(key)) element.value = key
    }
    const unsubscribe = subscribe(config.bindingId, update),
      change = () =>
        ready
          .then(() =>
            query(config.bindingId, {
              ...(lastControls.get(config.bindingId) || context.defaults),
              [config.controlId]: JSON.parse(element.value)
            })
          )
          .catch((error) =>
            element.dispatchEvent(new CustomEvent('xpert-query-error', { detail: { code: error.code }, bubbles: true }))
          )
    element.addEventListener('change', change)
    return () => {
      unsubscribe()
      element.removeEventListener('change', change)
    }
  }
  Object.defineProperty(window, 'xpertLiveArtifact', {
    value: Object.freeze({ ready: () => ready, query, queryMany, subscribe, refresh, bindSelect }),
    writable: false,
    configurable: false
  })
  window.addEventListener('message', (event) => {
    const data = event.data
    if (
      port ||
      event.source !== parent ||
      !data ||
      data.channel !== CHANNEL ||
      data.version !== VERSION ||
      data.type !== 'init' ||
      data.sessionId !== SESSION_ID ||
      !event.ports[0]
    )
      return
    port = event.ports[0]
    context = data.context
    document.documentElement.dataset.theme = context.theme
    document.documentElement.style.colorScheme = context.theme
    port.onmessage = (event) => {
      const data = event.data
      if (data.type === 'refresh') {
        if (data.bindingId) { refresh(data.bindingId).catch(console.error); return }
        if (refreshing) return
        refreshing = true
        queryGroup([...new Set([...listeners.keys(), ...lastControls.keys()])].map(bindingId => ({ bindingId, controls: lastControls.get(bindingId) || {} })), 'refresh')
          .catch(error => { if (error.code !== 'DOCUMENT_QUERY_SUPERSEDED') console.error(error) })
          .finally(() => { refreshing = false })
        return
      }
      if (data.type === 'query-state') {
        const entry = pending.get(data.requestId)
        if (entry && data.state === 'running') {
          clearTimeout(entry.timer)
          entry.timer = setTimeout(() => {
            pending.delete(data.requestId)
            entry.reject(fail('DOCUMENT_QUERY_TIMEOUT'))
          }, 50000)
        }
        return
      }
      if (data.type !== 'result') return
      const entry = pending.get(data.requestId)
      if (!entry) return
      pending.delete(data.requestId)
      clearTimeout(entry.timer)
      if (latest.get(entry.bindingId) !== data.requestId) {
        entry.reject(fail('DOCUMENT_QUERY_SUPERSEDED'))
        return
      }
      if (data.ok) {
        if (!deliveryLocks.has(entry.bindingId)) emit(entry.bindingId, data.dataset)
        entry.resolve(data.dataset)
      } else entry.reject(fail(data.code || 'DOCUMENT_QUERY_FAILED'))
    }
    port.start()
    resolveReady(context)
  })
  parent.postMessage({ channel: CHANNEL, version: VERSION, type: 'ready', sessionId: SESSION_ID }, '*')
})()
`;

const failure = (code)=>Object.assign(new Error(code), {
        code
    });
const keyOf = (input)=>{
    var _input_cache;
    return JSON.stringify([
        input.bindingId,
        (_input_cache = input.cache) != null ? _input_cache : null,
        Object.keys(input.controls).sort().map((key)=>[
                key,
                input.controls[key]
            ])
    ]);
};
const priorities = {
    interactive: 0,
    initial: 1,
    refresh: 2
};
const QUEUE_TIMEOUT = 180000, EXECUTION_TIMEOUT = 45000, WINDOW = 60000;
/** One trusted Artifact/version/actor generation. Queue time never consumes execution time.
 * Slots remain occupied until the underlying execution settles, even after timeout/abort.
 * Callers must propagate the signal when supported; disposal alone cannot cancel database work. */ function createArtifactQueryScheduler(options) {
    const bounded = (value, fallback, max)=>Number.isFinite(value) ? Math.max(1, Math.min(max, Math.floor(value))) : fallback;
    const concurrency = bounded(options.concurrency, 4, 8);
    const dispatchLimit = bounded(options.dispatchesPerMinute, 60, 1024);
    const queued = [], running = new Set(), latest = new Map();
    const dispatches = [];
    let disposed = false, wake;
    const observe = (fn, value)=>{
        try {
            fn == null ? void 0 : fn(value);
        } catch (e) {
        /* observer only */ }
    };
    const busy = ()=>observe(options.onBusy, !disposed && (queued.length > 0 || running.size > 0));
    const transition = (task, state, code)=>{
        task.state = _extends._extends({}, task.state, {
            state
        }, state === 'running' ? {
            startedAt: Date.now()
        } : state !== 'queued' ? {
            finishedAt: Date.now()
        } : {}, code ? {
            code
        } : {});
        observe(options.onState, _extends._extends({}, task.state));
    };
    const reject = (task, code)=>{
        if (task.settled) return;
        task.settled = true;
        clearTimeout(task.timer);
        task.controller.abort();
        transition(task, code === 'DOCUMENT_QUERY_SUPERSEDED' ? 'superseded' : 'failed', code);
        task.reject(failure(code));
        if (latest.get(task.input.bindingId) === task) latest.delete(task.input.bindingId);
    };
    const pump = ()=>{
        clearTimeout(wake);
        if (disposed) return;
        const now = Date.now();
        while(dispatches.length && dispatches[0] <= now - WINDOW)dispatches.shift();
        while(queued.length && running.size < concurrency && dispatches.length < dispatchLimit){
            queued.sort((a, b)=>a.priority - b.priority || a.state.queuedAt - b.state.queuedAt);
            const task = queued.shift();
            clearTimeout(task.timer);
            running.add(task);
            dispatches.push(Date.now());
            transition(task, 'running');
            task.timer = setTimeout(()=>reject(task, 'DOCUMENT_QUERY_TIMEOUT'), EXECUTION_TIMEOUT);
            Promise.resolve().then(()=>options.execute(task.input, task.controller.signal)).then((result)=>{
                if (disposed || task.settled) return;
                task.settled = true;
                transition(task, 'succeeded');
                task.resolve(result);
            }, ()=>reject(task, 'DOCUMENT_QUERY_FAILED')).finally(()=>{
                clearTimeout(task.timer);
                running.delete(task);
                if (latest.get(task.input.bindingId) === task) latest.delete(task.input.bindingId);
                pump();
            });
        }
        if (queued.length && dispatches.length >= dispatchLimit) wake = setTimeout(pump, Math.max(1, dispatches[0] + WINDOW - Date.now()));
        busy();
    };
    return {
        query (input, priority = 'interactive') {
            if (disposed) return Promise.reject(failure('DOCUMENT_DISPOSED'));
            const key = keyOf(input), previous = latest.get(input.bindingId);
            if ((previous == null ? void 0 : previous.key) === key && !previous.settled) {
                previous.priority = Math.min(previous.priority, priorities[priority]);
                return previous.promise;
            }
            if (previous) {
                const index = queued.indexOf(previous);
                if (index >= 0) queued.splice(index, 1);
                reject(previous, 'DOCUMENT_QUERY_SUPERSEDED');
            }
            if (queued.length >= 64) return Promise.reject(failure('DOCUMENT_QUEUE_LIMIT'));
            let resolve, rejectPromise;
            const promise = new Promise((yes, no)=>{
                resolve = yes;
                rejectPromise = no;
            });
            const task = {
                input: _extends._extends({
                    bindingId: input.bindingId,
                    controls: _extends._extends({}, input.controls)
                }, input.cache ? {
                    cache: _extends._extends({}, input.cache)
                } : {}),
                key,
                priority: priorities[priority],
                controller: new AbortController(),
                promise,
                resolve,
                reject: rejectPromise,
                state: _extends._extends({}, input, {
                    controls: _extends._extends({}, input.controls),
                    state: 'queued',
                    queuedAt: Date.now()
                }),
                settled: false
            };
            task.timer = setTimeout(()=>{
                const index = queued.indexOf(task);
                if (index >= 0) queued.splice(index, 1);
                reject(task, 'DOCUMENT_QUEUE_TIMEOUT');
                pump();
            }, QUEUE_TIMEOUT);
            latest.set(input.bindingId, task);
            queued.push(task);
            transition(task, 'queued');
            pump();
            return promise;
        },
        get busy () {
            return queued.length > 0 || running.size > 0;
        },
        dispose () {
            if (disposed) return;
            disposed = true;
            clearTimeout(wake);
            for (const task of [
                ...queued,
                ...running
            ])reject(task, 'DOCUMENT_DISPOSED');
            queued.length = 0;
            latest.clear();
            busy();
        }
    };
}

const readySchema = v3.z.object({
    channel: v3.z.literal(ARTIFACT_DOCUMENT_CHANNEL),
    version: v3.z.literal(ARTIFACT_DOCUMENT_VERSION),
    type: v3.z.literal('ready'),
    sessionId: v3.z.string().regex(/^[a-f0-9]{32}$/)
}).strict();
const diagnosticSchema = v3.z.object({
    type: v3.z.literal('diagnostic'),
    code: v3.z.literal('DOCUMENT_BINDING_DENIED')
}).strict();
/** Dedicated query bridge. Requires a dedicated host document with installArtifactDocumentFramePolicy installed. */ function mountArtifactDocument(frame, options) {
    if (!frame.ownerDocument.querySelector('meta[data-xpert-document-policy]')) {
        throw new Error('Install the Artifact document frame policy before mounting a document');
    }
    const context = artifactDocumentContext.parse(options.context);
    const sessionId = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte)=>byte.toString(16).padStart(2, '0')).join('');
    // Validate/render before allocating a channel or installing listeners.
    const source = renderArtifactDocument(options.html, sessionId, options.dependencies, options.networkPolicy);
    const channel = new MessageChannel();
    const bindingIds = new Set(context.bindingIds);
    const admissionLimit = Number.isFinite(options.dispatchesPerMinute) ? Math.max(256, Math.min(1024, options.dispatchesPerMinute)) : 256;
    const requestIds = new Set();
    const activeIds = new Map();
    const executingIds = new Set();
    const latest = new Map();
    const hostWindow = frame.ownerDocument.defaultView;
    let connected = false, disposed = false, requests = 0, started = Date.now();
    frame.setAttribute('sandbox', 'allow-scripts');
    frame.referrerPolicy = 'no-referrer';
    // Host UI observers cannot leave query accounting stuck or alter protocol completion.
    const observe = (callback, value)=>{
        try {
            callback == null ? void 0 : callback(value);
        } catch (e) {
        /* The query channel must survive a failing UI observer. */ }
    };
    const post = (message)=>{
        if (!disposed) channel.port1.postMessage(message);
    };
    const reject = (requestId, code)=>{
        post({
            type: 'result',
            requestId,
            ok: false,
            code
        });
        observe(options.onError, code);
    };
    const scheduler = createArtifactQueryScheduler({
        concurrency: options.concurrency,
        dispatchesPerMinute: options.dispatchesPerMinute,
        execute: async (input, signal)=>{
            if (signal.aborted) throw new Error('DOCUMENT_QUERY_SUPERSEDED');
            const request = [
                ...activeIds.values()
            ].find((item)=>item.bindingId === input.bindingId && Object.keys(item.controls).length === Object.keys(input.controls).length && Object.keys(input.controls).every((key)=>item.controls[key] === input.controls[key]));
            if (!request) throw new Error('DOCUMENT_QUERY_SUPERSEDED');
            executingIds.add(request.requestId);
            try {
                return await options.query(request, signal);
            } finally{
                executingIds.delete(request.requestId);
            }
        },
        onBusy: (value)=>observe(options.onBusy, value),
        onState: (state)=>{
            observe(options.onQueryState, state);
            if (state.state === 'running') {
                for (const input of activeIds.values())if (input.bindingId === state.bindingId) post({
                    type: 'query-state',
                    requestId: input.requestId,
                    state: 'running'
                });
            }
        }
    });
    channel.port1.onmessage = async (event)=>{
        if (disposed) return;
        const diagnostic = diagnosticSchema.safeParse(event.data);
        if (diagnostic.success) {
            observe(options.onError, diagnostic.data.code);
            return;
        }
        const parsed = artifactDocumentQuery.safeParse(event.data);
        if (!parsed.success) {
            observe(options.onError, 'DOCUMENT_INVALID_REQUEST');
            return;
        }
        const input = {
            type: parsed.data.type,
            requestId: parsed.data.requestId,
            bindingId: parsed.data.bindingId,
            controls: parsed.data.controls,
            priority: parsed.data.priority
        };
        if (!bindingIds.has(input.bindingId)) {
            reject(input.requestId, 'DOCUMENT_BINDING_DENIED');
            return;
        }
        if (Date.now() - started >= 60000) {
            requests = 0;
            started = Date.now();
            requestIds.clear();
        }
        // Keep in-flight IDs protected even after the one-minute replay/rate window rolls over.
        if (activeIds.has(input.requestId) || executingIds.has(input.requestId) || requestIds.has(input.requestId)) {
            reject(input.requestId, 'DOCUMENT_REQUEST_REPLAY');
            return;
        }
        if (activeIds.size >= 128 || ++requests > admissionLimit) {
            reject(input.requestId, 'DOCUMENT_QUERY_LIMIT');
            return;
        }
        requestIds.add(input.requestId);
        activeIds.set(input.requestId, input);
        latest.set(input.bindingId, input.requestId);
        post({
            type: 'query-state',
            requestId: input.requestId,
            state: 'queued'
        });
        try {
            const dataset = await scheduler.query(input, input.priority);
            if (!disposed) {
                post({
                    type: 'result',
                    requestId: input.requestId,
                    ok: true,
                    dataset
                });
                if (latest.get(input.bindingId) === input.requestId) observe(options.onResult, dataset);
            }
        } catch (error) {
            if (!disposed) {
                const code = error instanceof Error && /^DOCUMENT_[A-Z_]+$/.test(error.message) ? error.message : 'DOCUMENT_QUERY_FAILED';
                post({
                    type: 'result',
                    requestId: input.requestId,
                    ok: false,
                    code
                });
                if (latest.get(input.bindingId) === input.requestId) observe(options.onError, code);
            }
        } finally{
            activeIds.delete(input.requestId);
        }
    };
    const ready = (event)=>{
        var _frame_contentWindow;
        if (disposed || connected || event.source !== frame.contentWindow) return;
        const parsed = readySchema.safeParse(event.data);
        if (!parsed.success || parsed.data.sessionId !== sessionId) return;
        connected = true;
        (_frame_contentWindow = frame.contentWindow) == null ? void 0 : _frame_contentWindow.postMessage({
            channel: ARTIFACT_DOCUMENT_CHANNEL,
            version: ARTIFACT_DOCUMENT_VERSION,
            type: 'init',
            sessionId,
            context
        }, '*', [
            channel.port2
        ]);
    };
    hostWindow.addEventListener('message', ready);
    channel.port1.start();
    frame.srcdoc = source;
    return {
        refresh (bindingId) {
            if (bindingId !== undefined && !bindingIds.has(bindingId)) throw new Error('DOCUMENT_BINDING_DENIED');
            post(_extends._extends({
                type: 'refresh'
            }, bindingId ? {
                bindingId
            } : {}));
        },
        dispose () {
            if (disposed) return;
            disposed = true;
            scheduler.dispose();
            activeIds.clear();
            hostWindow.removeEventListener('message', ready);
            channel.port1.close();
            channel.port2.close();
            observe(options.onBusy, false);
        }
    };
}
/** Installs a document-wide policy once. Use a dedicated host: all URL-based child frames are denied; srcdoc works. */ function installArtifactDocumentFramePolicy(hostDocument) {
    if (hostDocument.querySelector('meta[data-xpert-document-policy]')) return;
    const meta = hostDocument.createElement('meta');
    meta.httpEquiv = 'Content-Security-Policy';
    meta.content = "frame-src 'none'";
    meta.dataset['xpertDocumentPolicy'] = '1';
    hostDocument.head.prepend(meta);
}

exports.ARTIFACT_DOCUMENT_CHANNEL = ARTIFACT_DOCUMENT_CHANNEL;
exports.ARTIFACT_DOCUMENT_CSP = ARTIFACT_DOCUMENT_CSP;
exports.ARTIFACT_DOCUMENT_VERSION = ARTIFACT_DOCUMENT_VERSION;
exports.artifactDocumentContext = artifactDocumentContext;
exports.artifactDocumentControls = artifactDocumentControls;
exports.artifactDocumentCsp = artifactDocumentCsp;
exports.artifactDocumentDependencyAssets = artifactDocumentDependencyAssets;
exports.artifactDocumentDependencyLock = artifactDocumentDependencyLock;
exports.artifactDocumentDependencyLocks = artifactDocumentDependencyLocks;
exports.artifactDocumentHtml = artifactDocumentHtml;
exports.artifactDocumentId = artifactDocumentId;
exports.artifactDocumentNetworkPolicy = artifactDocumentNetworkPolicy;
exports.artifactDocumentQuery = artifactDocumentQuery;
exports.artifactDocumentValue = artifactDocumentValue;
exports.createArtifactQueryScheduler = createArtifactQueryScheduler;
exports.installArtifactDocumentFramePolicy = installArtifactDocumentFramePolicy;
exports.isArtifactDocumentResourceAllowed = isArtifactDocumentResourceAllowed;
exports.mountArtifactDocument = mountArtifactDocument;
exports.renderArtifactDocument = renderArtifactDocument;
exports.renderArtifactDocumentDependencies = renderArtifactDocumentDependencies;
exports.verifyArtifactDocumentDependencies = verifyArtifactDocumentDependencies;
