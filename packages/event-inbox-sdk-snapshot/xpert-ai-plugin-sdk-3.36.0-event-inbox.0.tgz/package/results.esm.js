import { _ as _extends } from './_extends.esm.js';
import { z } from 'zod/v3';
import { agentResultPathSchema } from '@xpert-ai/contracts';

/** Opt in to the host's authorized, on-demand result View from middleware metadata. */ const AGENT_TASK_RESULTS_FEATURE = 'agent_task_results';
const common = {
    id: z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/),
    title: z.string().min(1).max(200),
    summary: z.string().max(16000)
};
/** Machine-readable result kind; file declarations are not committed artifacts or download grants. */ const agentResultItemSchema = z.discriminatedUnion('type', [
    z.object(_extends({}, common, {
        type: z.literal('analysis')
    })).strict(),
    z.object(_extends({}, common, {
        type: z.literal('changes'),
        files: z.array(z.object({
            path: agentResultPathSchema,
            change: z.enum([
                'created',
                'modified',
                'deleted'
            ])
        }).strict()).max(128)
    })).strict(),
    z.object(_extends({}, common, {
        type: z.literal('tests'),
        status: z.enum([
            'passed',
            'failed',
            'skipped'
        ]),
        command: z.string().max(2000).optional()
    })).strict(),
    z.object(_extends({}, common, {
        type: z.literal('file'),
        path: agentResultPathSchema
    })).strict()
]);
/** Report bytes are transported independently of artifact quotas and business acceptance. */ const AGENT_TASK_REPORT_MAX_BYTES = 4 * 1024 * 1024;

export { AGENT_TASK_REPORT_MAX_BYTES as A, AGENT_TASK_RESULTS_FEATURE as a, agentResultItemSchema as b };
