import { _ as _extends } from './_extends.esm.js';
import { AiModelTypeEnum } from '@xpert-ai/contracts';
import { SetMetadata, Logger } from '@nestjs/common';
import { z } from 'zod/v3';
import { BaseToolkit, StructuredTool } from '@langchain/core/tools';

function createRuntimeCapability(id, options = {}) {
    return Object.freeze({
        id,
        description: options.description
    });
}
const XPERT_RUNTIME_CAPABILITIES_TOKEN = 'XPERT_RUNTIME_CAPABILITIES';
/** Metadata key under which RuntimeCapabilityProviderExplorer discovers capability providers. */ const RUNTIME_CAPABILITY_PROVIDER = 'XPERT_RUNTIME_CAPABILITY_PROVIDER';
/** Tags a Nest provider as the platform implementation of a runtime capability. */ const RuntimeCapabilityProvider = (capability)=>SetMetadata(RUNTIME_CAPABILITY_PROVIDER, capability);
class DefaultRuntimeCapabilityRegistry {
    register(key, implementation) {
        this.capabilities.set(runtimeCapabilityId(key), implementation);
        return this;
    }
    has(key) {
        var _this_parent;
        return this.capabilities.has(runtimeCapabilityId(key)) || ((_this_parent = this.parent) == null ? void 0 : _this_parent.get(key)) !== undefined;
    }
    get(key) {
        var _this_parent;
        const id = runtimeCapabilityId(key);
        return this.capabilities.has(id) ? this.capabilities.get(id) : (_this_parent = this.parent) == null ? void 0 : _this_parent.get(key);
    }
    require(key) {
        const implementation = this.get(key);
        if (!implementation) {
            throw new Error(`Runtime capability '${runtimeCapabilityId(key)}' is not available`);
        }
        return implementation;
    }
    constructor(entries = [], parent){
        this.capabilities = new Map();
        this.parent = parent;
        entries.forEach(([key, implementation])=>this.register(key, implementation));
    }
}
function runtimeCapabilityId(key) {
    return typeof key === 'string' ? key : key.id;
}

/**
 * Base ability for all toolsets
 */ class BaseToolset extends BaseToolkit {
    /**
     * Async init tools
     *
     * @returns
     */ async initTools() {
        return this.tools;
    }
    /**
     * Get one tool
     *
     * @param toolName
     * @returns
     */ getTool(toolName) {
        var _this_getTools;
        return (_this_getTools = this.getTools()) == null ? void 0 : _this_getTools.find((tool)=>tool.name === toolName);
    }
    /**
     * Get state variables config
     *
     * @returns State variables
     */ async getVariables() {
        return null;
    }
    /**
     * Close all (connections).
     */ async close() {
    //
    }
    constructor(params){
        super();
        this.params = params;
    }
}
class BaseTool extends StructuredTool {
    constructor(...args){
        super(...args);
        this.schema = z.object({
            input: z.string().optional()
        }).transform((obj)=>obj.input);
    }
}

class BuiltinToolset extends BaseToolset {
    get tenantId() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.tenantId;
    }
    get organizationId() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.organizationId;
    }
    get commandBus() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.commandBus;
    }
    get queryBus() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.queryBus;
    }
    get xpertId() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.xpertId;
    }
    get modelRuntime() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.modelRuntime;
    }
    get managedQueue() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.managedQueue;
    }
    get pluginScopeKey() {
        var _this_params;
        return (_this_params = this.params) == null ? void 0 : _this_params.pluginScopeKey;
    }
    async validateCredentials(credentials) {
        await this._validateCredentials(credentials);
    }
    async _validateCredentials(credentials) {
        throw new Error('Method not implemented.');
    }
    getId() {
        var _this_toolset;
        return (_this_toolset = this.toolset) == null ? void 0 : _this_toolset.id;
    }
    getCredentials() {
        var _this_toolset;
        return (_this_toolset = this.toolset) == null ? void 0 : _this_toolset.credentials;
    }
    getMcpCapabilityDefinitions() {
        return this.mcpCapabilities;
    }
    getMcpCapabilitySource() {
        var _this_params, _this_params1;
        return _extends({}, ((_this_params = this.params) == null ? void 0 : _this_params.pluginName) ? {
            pluginName: this.params.pluginName
        } : {}, ((_this_params1 = this.params) == null ? void 0 : _this_params1.pluginVersion) ? {
            pluginVersion: this.params.pluginVersion
        } : {});
    }
    getToolTitle(name) {
        var _this_toolset_tools, _this_toolset, _tool_schema;
        const tool = (_this_toolset = this.toolset) == null ? void 0 : (_this_toolset_tools = _this_toolset.tools) == null ? void 0 : _this_toolset_tools.find((tool)=>tool.name === name);
        const identity = tool == null ? void 0 : (_tool_schema = tool.schema) == null ? void 0 : _tool_schema.identity;
        if (identity) {
            return identity.label;
        }
        return null;
    }
    /**
     * Get credentials schema
     *
     * @returns Credentials schema
     */ getCredentialsSchema() {
        return _extends({}, this.credentialsSchema);
    }
    /**
     * Get toolset entity
     *
     * @returns XpertToolset
     */ getToolset() {
        return this.toolset;
    }
    getName() {
        var _this_getToolset;
        return (_this_getToolset = this.getToolset()) == null ? void 0 : _this_getToolset.name;
    }
    constructor(providerName, toolset, params){
        super(params);
        this.logger = new Logger(this.constructor.name);
        this.mcpCapabilities = {};
        this.providerName = providerName;
        this.toolset = toolset;
        this.params = params;
    }
} 
BuiltinToolset.provider = '';

const ActorTokenRuntimeCapability = createRuntimeCapability('platform.actor-token', {
    description: 'Mint a short-lived host-issued actor bearer token for outbound API calls.'
});
/** Platform registry entry. The operation capability above is bound only inside a caller runtime. */ const ActorTokenRuntimeFactoryCapability = createRuntimeCapability('platform.actor-token.factory', {
    description: 'Create an actor-token API with host-bound identity, delegation claims and an isolated token cache.'
});

const ArtifactsRuntimeCapability = createRuntimeCapability('platform.artifacts', {
    description: 'Create, version, preview, download, share, archive, and delete platform-managed plugin and Agent artifacts.'
});

const ArtifactLibraryRuntimeCapability = createRuntimeCapability('platform.artifact-library', {
    description: 'Add governed Artifact references to a Project content catalog and manage their published links.'
});

/** Stable plugin/host registry key; resolve via runtime capabilities rather than dispatching host-internal CQRS classes. */ const ArtifactUseGrantsRuntimeCapability = createRuntimeCapability('platform.artifact-use-grants', {
    description: 'Human authoring Views issue and revoke fixed-version group grants; group credentials cannot manage source grants.'
});

const ArtifactDraftsRuntimeCapability = createRuntimeCapability('platform.artifact-drafts', {
    description: 'Persist working copies with optimistic concurrency; atomically publish a confirmed revision as an immutable Artifact version.'
});

const ArtifactContentRuntimeCapability = createRuntimeCapability('platform.artifact-content', {
    description: 'Store Artifact content outside ordinary workspace files and authorize reads against its published version or draft.'
});

/** Stable source identifier for portable workspace file references. */ const WORKSPACE_FILES_SOURCE = 'platform.workspace.files';
const WorkspaceFilesRuntimeCapability = createRuntimeCapability('platform.workspace.files', {
    description: 'Upload, understand, search parsed chunks, resolve, read, and delete files in Xpert workspace volumes.'
});

/** Stable machine-readable failures emitted by the Sandbox Jobs capability. */ const SANDBOX_JOB_ERROR_CODES = [
    'SANDBOX_ACTION_UNAVAILABLE',
    'SANDBOX_ACTION_INVALID',
    'SANDBOX_PROFILE_UNAVAILABLE',
    'SANDBOX_RUNTIME_UNAVAILABLE',
    'SANDBOX_VERSION_MISMATCH',
    'SANDBOX_CAPACITY_UNAVAILABLE',
    'SANDBOX_START_FAILED',
    'SANDBOX_DEPENDENCY_MISSING',
    'EXPORT_CONVERSION_FAILED',
    'EXPORT_TEXT_EXTRACTION_FAILED',
    'SANDBOX_INVOCATION_FAILED',
    'BROWSER_LAUNCH_FAILED',
    'EXPORT_TIMEOUT',
    'EXPORT_OOM',
    'EXPORT_MEDIA_FAILED',
    'EXPORT_INPUT_INVALID',
    'EXPORT_OUTPUT_INVALID',
    'SANDBOX_CANCELLED',
    'SANDBOX_CONTROL_UNCONFIRMED'
];
/** Line prefix used by trusted Actions to report structured, provider-neutral progress. */ const SANDBOX_JOB_PROGRESS_PREFIX = 'XPERT_SANDBOX_PROGRESS ';
/**
 * Stdout frame: prefix + JSON { id, operation, payload } + newline.
 * Core writes { id, value } to <workspaceRoot>/invocations/<id>.json after validation.
 * IDs are unique per attempt and restricted to 1–64 ASCII letters, digits, '_' or '-'.
 * The bridge has no network endpoint and gives the script no host credentials.
 */ const SANDBOX_JOB_INVOCATION_PREFIX = 'XPERT_SANDBOX_INVOKE ';
/** Error carrying retry policy and Job identity across plugin queue handlers. */ class SandboxJobRuntimeError extends Error {
    constructor(code, message, retryable, jobId){
        super(message);
        this.code = code;
        this.retryable = retryable;
        this.jobId = jobId;
        this.name = 'SandboxJobRuntimeError';
    }
}
const SANDBOX_JOB_ERROR_CODE_SET = new Set(SANDBOX_JOB_ERROR_CODES);
/** Narrows an unknown failure to the structured Sandbox Jobs runtime error contract. */ function isSandboxJobRuntimeError(error) {
    if (error instanceof SandboxJobRuntimeError) return true;
    if (typeof error !== 'object' || error === null) return false;
    // Dynamically loaded plugins may resolve another Plugin SDK module instance,
    // so class identity is not a reliable runtime boundary. Validate the stable shape.
    const candidate = error;
    return candidate.name === 'SandboxJobRuntimeError' && typeof candidate.message === 'string' && typeof candidate.code === 'string' && SANDBOX_JOB_ERROR_CODE_SET.has(candidate.code) && typeof candidate.retryable === 'boolean' && (candidate.jobId === undefined || typeof candidate.jobId === 'string');
}
/** Runtime capability key used to resolve SandboxJobsApi from the platform registry. */ const SandboxJobsRuntimeCapability = createRuntimeCapability('platform.sandbox.jobs', {
    description: 'Run registered plugin actions in isolated, short-lived Sandbox Runtime jobs.'
});

const ProjectProvisioningRuntimeCapability = createRuntimeCapability('platform.project.provisioning', {
    description: 'Idempotently provision a platform Chat Project and connect it to an Assistant.'
});

const ProjectAccessRuntimeCapability = createRuntimeCapability('platform.project.access', {
    description: 'Resolve Project membership and Assistant execution access for platform and plugin operations.'
});

const PluginTestAccessCapability = createRuntimeCapability('platform.plugin.test-access');

const ProjectFilesRuntimeCapability = createRuntimeCapability('platform.project.files', {
    description: 'Authorized Project file tree and conflict-aware atomic file writes.'
});

const ToolImagesRuntimeCapability = createRuntimeCapability('platform.tool-images', {
    description: 'Save scoped immutable tool images and materialize verified pixels for one model request.'
});

const AssistantMiddlewareAccessRuntimeCapability = createRuntimeCapability('platform.assistant.middleware-access', {
    description: 'Authorize a published Assistant and its exact connected middleware feature for a trusted actor.'
});

const ProjectKnowledgeRuntimeCapability = createRuntimeCapability('platform.project.knowledge', {
    description: 'Provision and bind the Project-owned built-in knowledge library.'
});

const McpClientRuntimeCapability = createRuntimeCapability('platform.mcp.client', {
    description: 'Governed MCP client access using existing connections and viewer credentials; read-only tools initially.'
});

const RestClientRuntimeCapability = createRuntimeCapability('platform.rest.client', {
    description: 'Governed JSON access through saved OpenAPI connections and platform-managed authentication.'
});

const ProjectConfigurationRuntimeCapability = createRuntimeCapability('platform.project.configuration', {
    description: 'Authorized Project configuration, membership, skills, connectors and automation operations.'
});

/** Portable Agent input; filesystem containment and authorization remain with the host. */ const workspaceRelativeFilePathSchema = z.string().min(1).max(1024).refine((value)=>!/[\\\x00-\x1f\x7f]/.test(value) && !/^[A-Za-z]:/.test(value) && value.split('/').every((part)=>part.length > 0 && part === part.trim() && part !== '.' && part !== '..'), 'Use a workspace-relative file path with non-empty segments; no absolute paths, traversal or surrounding whitespace.');
/** Directory discovery also accepts the workspace root and a trailing directory slash. */ const workspaceRelativeDirectoryPathSchema = z.string().transform((value)=>value.endsWith('/') ? value.slice(0, -1) : value).pipe(z.union([
    z.literal('.'),
    workspaceRelativeFilePathSchema
]));
/** Host-owned metadata lets plugins observe file intent without guessing tool names. */ const workspaceFileMutationMetadata = {
    workspaceFileOperation: {
        type: 'mutation',
        pathArgument: 'file_path'
    }
};
const mutationMetadata = z.object({
    workspaceFileOperation: z.object({
        type: z.literal('mutation'),
        pathArgument: z.string().min(1)
    })
});
function workspaceFileMutationPath(metadata, args) {
    const descriptor = mutationMetadata.safeParse(metadata);
    if (!descriptor.success) return undefined;
    const path = workspaceRelativeFilePathSchema.safeParse(args[descriptor.data.workspaceFileOperation.pathArgument]);
    return path.success ? path.data : undefined;
}

/**
 * Shared host-runtime plumbing for built-in tools backed by a configured model provider.
 * Provider request/response semantics remain owned by each plugin.
 */ class ModelProviderBuiltinToolset extends BuiltinToolset {
    async _validateCredentials(_credentials) {
        await this.getModelProviderRuntime();
    }
    getModelProviderRuntime() {
        var _this_modelRuntime;
        if (!((_this_modelRuntime = this.modelRuntime) == null ? void 0 : _this_modelRuntime.getModelProvider)) {
            throw new Error(this.modelProviderOptions.missingProviderMessage);
        }
        var _this_modelProvider;
        (_this_modelProvider = this.modelProvider) != null ? _this_modelProvider : this.modelProvider = this.modelRuntime.getModelProvider(this.modelProviderOptions.modelProviderName);
        return this.modelProvider;
    }
    getModelProviderCredential(modelProvider) {
        const scheme = this.modelProviderOptions.authorizationScheme;
        const match = new RegExp(`^${scheme}\\s+(.+)$`, 'i').exec(modelProvider.authorization.trim());
        if (!(match == null ? void 0 : match[1])) {
            throw new Error(this.modelProviderOptions.invalidCredentialsMessage);
        }
        return match[1];
    }
    getWorkspaceFiles() {
        var _this_params_runtimeCapabilities, _this_params;
        const workspaceFiles = (_this_params = this.params) == null ? void 0 : (_this_params_runtimeCapabilities = _this_params.runtimeCapabilities) == null ? void 0 : _this_params_runtimeCapabilities.get(WorkspaceFilesRuntimeCapability);
        if (!workspaceFiles) {
            throw new Error(this.modelProviderOptions.missingWorkspaceMessage);
        }
        return workspaceFiles;
    }
    createWorkspaceScope() {
        var _this_params, _this_params1;
        const runtimeScope = (_this_params = this.params) == null ? void 0 : _this_params.runtimeScope;
        if (runtimeScope) {
            return normalizeWorkspaceScope(runtimeScope);
        }
        if (normalizeOptionalString((_this_params1 = this.params) == null ? void 0 : _this_params1.projectId) || normalizeOptionalString(this.xpertId)) {
            throw new Error(this.modelProviderOptions.missingWorkspaceMessage);
        }
        return undefined;
    }
    async createAsyncModelClient(model, modality, purpose = 'invoke') {
        const modelProvider = await this.getModelProviderRuntime();
        const copilotId = normalizeOptionalString(modelProvider.copilotId);
        if (!copilotId) {
            throw new Error(this.modelProviderOptions.missingProviderMessage);
        }
        const modelType = modality === 'image' ? AiModelTypeEnum.IMAGE : AiModelTypeEnum.VIDEO;
        return this.modelRuntime.createModelClient({
            copilotId,
            model,
            modelType
        }, {
            purpose
        });
    }
    async createModelClient(model, modality) {
        const modelProvider = await this.getModelProviderRuntime();
        const copilotId = normalizeOptionalString(modelProvider.copilotId);
        if (!copilotId) {
            throw new Error(this.modelProviderOptions.missingProviderMessage);
        }
        const modelType = modality === 'image' ? AiModelTypeEnum.IMAGE : AiModelTypeEnum.VIDEO;
        return this.modelRuntime.createModelClient({
            copilotId,
            model,
            modelType
        }, {});
    }
    constructor(modelProviderOptions, toolset, _runtimeCapabilities, params){
        super(modelProviderOptions.toolsetProviderName, toolset, params);
        this.modelProviderOptions = modelProviderOptions;
    }
}
function normalizeOptionalString(value) {
    const normalized = value == null ? void 0 : value.trim();
    return normalized || undefined;
}
function normalizeWorkspaceScope(scope) {
    const tenantId = normalizeOptionalString(scope.tenantId);
    const organizationId = normalizeOptionalString(scope.organizationId);
    const userId = normalizeOptionalString(scope.userId);
    var _scope_catalog;
    const catalog = (_scope_catalog = scope.catalog) != null ? _scope_catalog : undefined;
    const scopeId = normalizeOptionalString(scope.scopeId);
    const projectId = normalizeOptionalString(scope.projectId);
    const knowledgeId = normalizeOptionalString(scope.knowledgeId);
    const rootId = normalizeOptionalString(scope.rootId);
    const xpertId = normalizeOptionalString(scope.xpertId);
    return _extends({}, tenantId ? {
        tenantId
    } : {}, organizationId ? {
        organizationId
    } : {}, userId ? {
        userId
    } : {}, catalog ? {
        catalog
    } : {}, scopeId ? {
        scopeId
    } : {}, projectId ? {
        projectId
    } : {}, knowledgeId ? {
        knowledgeId
    } : {}, rootId ? {
        rootId
    } : {}, xpertId ? {
        xpertId
    } : {}, typeof scope.isolateByUser === 'boolean' ? {
        isolateByUser: scope.isolateByUser
    } : {});
}

export { ActorTokenRuntimeCapability as A, BuiltinToolset as B, workspaceRelativeDirectoryPathSchema as C, DefaultRuntimeCapabilityRegistry as D, workspaceRelativeFilePathSchema as E, ModelProviderBuiltinToolset as M, PluginTestAccessCapability as P, RUNTIME_CAPABILITY_PROVIDER as R, SANDBOX_JOB_ERROR_CODES as S, ToolImagesRuntimeCapability as T, WorkspaceFilesRuntimeCapability as W, XPERT_RUNTIME_CAPABILITIES_TOKEN as X, ActorTokenRuntimeFactoryCapability as a, ArtifactContentRuntimeCapability as b, createRuntimeCapability as c, ArtifactDraftsRuntimeCapability as d, ArtifactLibraryRuntimeCapability as e, ArtifactUseGrantsRuntimeCapability as f, ArtifactsRuntimeCapability as g, AssistantMiddlewareAccessRuntimeCapability as h, BaseTool as i, BaseToolset as j, McpClientRuntimeCapability as k, ProjectAccessRuntimeCapability as l, ProjectConfigurationRuntimeCapability as m, ProjectFilesRuntimeCapability as n, ProjectKnowledgeRuntimeCapability as o, ProjectProvisioningRuntimeCapability as p, RestClientRuntimeCapability as q, RuntimeCapabilityProvider as r, SANDBOX_JOB_INVOCATION_PREFIX as s, SANDBOX_JOB_PROGRESS_PREFIX as t, SandboxJobRuntimeError as u, SandboxJobsRuntimeCapability as v, WORKSPACE_FILES_SOURCE as w, isSandboxJobRuntimeError as x, workspaceFileMutationMetadata as y, workspaceFileMutationPath as z };
