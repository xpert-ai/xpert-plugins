'use strict';

const DataSourceRuntimeCapability = Object.freeze({
    id: 'platform.datasource.workbench',
    description: 'Scoped database workbench access; credentials remain host-owned.',
    __type: undefined
});

exports.DataSourceRuntimeCapability = DataSourceRuntimeCapability;
