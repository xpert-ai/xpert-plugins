import { a as analyticsCertificationSchema, b as analyticsFieldSchema, i as isAnalyticsCell } from './analytics-result.esm.js';
export { c as analyticsBindingObjectSchema, d as analyticsBindingSchema, e as analyticsControlsSchema, f as analyticsDiscoveryRequestObjectSchema, g as analyticsDiscoveryRequestSchema, h as analyticsDiscoveryResultSchema, j as analyticsOptionsSchema, k as analyticsParameterSchema, l as analyticsQueryRequestSchema, m as analyticsSourceKey, n as analyticsSourceRefSchema, o as normalizeAnalyticsResult, p as parseAnalyticsCertification, r as resolveAnalyticsParameters, v as validateAnalyticsBinding } from './analytics-result.esm.js';
import { z } from 'zod/v3';
import { _ as _object_without_properties_loose } from './_object_without_properties_loose.esm.js';
import './_extends.esm.js';

const key$1 = z.string().trim().min(1).max(128).refine((value)=>![
        '__proto__',
        'constructor',
        'prototype'
    ].includes(value));
const scalar$1 = z.union([
    z.string().max(512),
    z.number().finite(),
    z.boolean(),
    z.null()
]);
/** Validate one predicate's shape/cardinality; field existence, logical types and allowed scope require live dataset metadata. */ const resourceAnalysisFilterSchema = z.object({
    field: key$1,
    operator: z.enum([
        'eq',
        'ne',
        'in',
        'gt',
        'gte',
        'lt',
        'lte'
    ]),
    values: z.array(scalar$1).min(1).max(50)
}).strict().refine((value)=>value.operator === 'in' || value.values.length === 1);
/**
 * Shared authoring/server policy boundary: bounded nonempty allowlists, fixed-filter fields and supported mode combinations.
 * Parsing does not establish source sharing authority or receiving-group consent; those remain runtime checks.
 */ const resourceAnalysisPolicySchema = z.object({
    execution: z.enum([
        'viewer_permissions',
        'delegated_results'
    ]).optional(),
    mode: z.enum([
        'bindings',
        'explore'
    ]),
    datasets: z.array(z.object({
        key: key$1,
        fields: z.array(key$1).min(1).max(64),
        filters: z.array(resourceAnalysisFilterSchema).max(20),
        controlValues: z.record(key$1, z.array(scalar$1).min(1).max(50)).refine((value)=>Object.keys(value).length <= 32).optional()
    }).strict()).min(1).max(20),
    allowDetails: z.boolean(),
    maxRows: z.number().int().min(1).max(100)
}).strict().refine((value)=>value.execution === 'delegated_results' || value.datasets.every((item)=>!item.controlValues)).refine((value)=>new Set(value.datasets.map((item)=>item.key)).size === value.datasets.length).refine((value)=>value.datasets.every((item)=>new Set(item.fields).size === item.fields.length && item.filters.every((filter)=>item.fields.includes(filter.field)))).refine((value)=>value.mode !== 'bindings' || value.allowDetails);
/**
 * Normalize public query input to ResourceAnalysisQuery, defaulting optional wire collections to empty values.
 * Keep limit absent so the executor uses the live policy's maxRows; validate field/mode/budget permissions before querying.
 */ const resourceAnalysisQuerySchema = z.object({
    datasetKey: key$1,
    controls: z.record(key$1, scalar$1).refine((value)=>Object.keys(value).length <= 32).default({}),
    select: z.array(key$1).max(64).default([]),
    filters: z.array(resourceAnalysisFilterSchema).max(20).default([]),
    groupBy: z.array(key$1).max(8).default([]),
    aggregates: z.array(z.object({
        field: key$1.optional(),
        key: key$1,
        operation: z.enum([
            'count',
            'sum',
            'min',
            'max'
        ])
    }).strict()).max(16).default([]),
    orderBy: z.array(z.object({
        field: key$1,
        direction: z.enum([
            'asc',
            'desc'
        ])
    }).strict()).max(8).default([]),
    limit: z.number().int().min(1).max(100).optional()
}).strict();
/**
 * Check a predicate scalar against the declared logical type, including exact-string int64/decimal wire values.
 * Shared by authoring and execution; this does not validate the operator, field allowlist or grant authority.
 */ function isResourceAnalysisFilterValue(type, value) {
    if (value === null) return true;
    if (type === 'boolean') return typeof value === 'boolean';
    if (type === 'float64') return typeof value === 'number' && Number.isFinite(value);
    if (typeof value !== 'string') return false;
    if (type === 'int64') return value.length <= 128 && /^-?\d+$/.test(value);
    if (type === 'decimal') return value.length <= 128 && /^-?\d+(\.\d+)?$/.test(value);
    if (type === 'date') return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value));
    if (type === 'timestamp') return /^\d{4}-\d{2}-\d{2}T/.test(value) && Number.isFinite(Date.parse(value));
    return true;
}

// Evidence is a bounded copy of a past result. Parsing establishes neither current source access
// nor certification authority; producers and readers enforce those checks in their own runtime.
const key = z.string().min(1).max(160).refine((value)=>![
        '__proto__',
        'constructor',
        'prototype'
    ].includes(value));
const scalar = z.union([
    z.string().max(4000),
    z.number().finite(),
    z.boolean(),
    z.null()
]);
const dataset = z.object({
    schema: z.literal('xpert.analytics.dataset'),
    datasetId: key,
    fields: z.array(analyticsFieldSchema).min(1).max(64),
    rows: z.array(z.record(key, scalar)).max(1000),
    grain: z.array(key).max(64),
    completeness: z.object({
        returnedRows: z.number().int().nonnegative(),
        totalRows: z.number().int().nonnegative().optional(),
        totalAccuracy: z.enum([
            'exact',
            'estimated',
            'unknown'
        ]),
        scope: z.enum([
            'full_query_result',
            'page',
            'sample',
            'top_n'
        ]),
        truncated: z.boolean()
    }).strict(),
    freshness: z.object({
        executedAt: z.string().datetime(),
        sourceFetchedAt: z.string().datetime(),
        dataAsOf: z.string().max(160).optional()
    }).strict(),
    provenance: z.object({
        executionId: key,
        bindingId: key,
        providerId: key,
        sourceVersion: z.string().max(512).optional(),
        upstreamExecutionId: key.optional(),
        auditRef: z.string().max(512).optional(),
        certification: analyticsCertificationSchema.optional()
    }).strict()
}).strict().superRefine((value, ctx)=>{
    const ids = new Set(value.fields.map((field)=>field.id));
    if (ids.size !== value.fields.length || new Set(value.grain).size !== value.grain.length || value.grain.some((id)=>!ids.has(id)) || value.completeness.returnedRows !== value.rows.length || value.completeness.totalRows !== undefined && value.completeness.totalRows < value.rows.length || value.completeness.truncated && value.completeness.scope === 'full_query_result') ctx.addIssue({
        code: 'custom',
        message: 'Inconsistent evidence result'
    });
    for (const row of value.rows){
        // Reuse result validation so transport never coerces values or relaxes their logical types.
        if (Object.keys(row).length !== ids.size || Object.keys(row).some((id)=>!ids.has(id)) || value.fields.some((field)=>!Object.prototype.hasOwnProperty.call(row, field.id) || !isAnalyticsCell(field.logicalType, row[field.id], field.nullable))) ctx.addIssue({
            code: 'custom',
            message: 'Invalid evidence cells'
        });
    }
});
const analysisEvidenceSchema = z.object({
    schema: z.literal('xpert.analysis-evidence@1'),
    id: z.string().uuid(),
    title: z.string().min(1).max(200),
    capturedAt: z.string().datetime(),
    source: z.object({
        artifactId: z.string().uuid(),
        versionId: z.string().uuid(),
        projectId: z.string().uuid()
    }).strict(),
    controls: z.record(key, scalar).refine((value)=>Object.keys(value).length <= 32),
    datasets: z.array(dataset).min(1).max(20),
    statements: z.array(z.object({
        kind: z.enum([
            'fact',
            'inference',
            'unverified'
        ]),
        text: z.string().min(1).max(2000),
        citations: z.array(z.object({
            datasetId: key,
            row: z.number().int().nonnegative(),
            field: key
        }).strict()).max(64)
    }).strict()).max(1000),
    sha256: z.string().regex(/^[a-f0-9]{64}$/)
}).strict().superRefine((value, ctx)=>{
    if (new Set(value.datasets.map((item)=>item.datasetId)).size !== value.datasets.length) ctx.addIssue({
        code: 'custom',
        message: 'Duplicate evidence dataset'
    });
    for (const statement of value.statements){
        // A citation identifies an existing cell; it does not prove the statement's interpretation.
        if (statement.kind === 'fact' && !statement.citations.length) ctx.addIssue({
            code: 'custom',
            message: 'Facts need cell citations'
        });
        for (const citation of statement.citations){
            const data = value.datasets.find((item)=>item.datasetId === citation.datasetId);
            if (!data || citation.row >= data.rows.length || !data.fields.some((field)=>field.id === citation.field)) ctx.addIssue({
                code: 'custom',
                message: 'Unknown evidence cell'
            });
        }
    }
    if (new TextEncoder().encode(JSON.stringify(value)).length > 2000000) ctx.addIssue({
        code: 'custom',
        message: 'Evidence exceeds limit'
    });
});
/** Canonicalize validated JSON: sort object keys, but preserve array order and exact scalar values.
 * Omitted optional properties do not affect the digest. Hashing stays in the consumer's runtime. */ function canonicalEvidenceJson(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(canonicalEvidenceJson).join(',') + ']';
    return '{' + Object.entries(value).filter(([, entry])=>entry !== undefined).sort(([a], [b])=>a < b ? -1 : a > b ? 1 : 0).map(([name, entry])=>JSON.stringify(name) + ':' + canonicalEvidenceJson(entry)).join(',') + '}';
}
/** Validate shape and cell references; callers must verify the digest and current source access separately. */ function parseAnalysisEvidence(value) {
    return analysisEvidenceSchema.parse(value);
}
/** Exclude only the digest itself; source, capture time, cells and statement classifications stay covered. */ function analysisEvidenceDigestInput(value) {
    const { sha256: _digest } = value, body = _object_without_properties_loose(value, [
        "sha256"
    ]);
    return canonicalEvidenceJson(body);
}

export { analysisEvidenceDigestInput, analysisEvidenceSchema, analyticsCertificationSchema, analyticsFieldSchema, canonicalEvidenceJson, isResourceAnalysisFilterValue, parseAnalysisEvidence, resourceAnalysisFilterSchema, resourceAnalysisPolicySchema, resourceAnalysisQuerySchema };
