export * from "./src/remote-component";
