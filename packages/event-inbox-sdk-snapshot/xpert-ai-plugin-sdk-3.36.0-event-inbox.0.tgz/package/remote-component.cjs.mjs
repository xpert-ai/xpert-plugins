export * from './remote-component.cjs.js';
export { _default as default } from './remote-component.cjs.default.js';