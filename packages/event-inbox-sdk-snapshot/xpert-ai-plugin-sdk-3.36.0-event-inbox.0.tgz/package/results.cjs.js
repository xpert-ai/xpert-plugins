'use strict';

var _extends = require('./_extends.cjs.js');
var v3 = require('zod/v3');
var contracts = require('@xpert-ai/contracts');

/** Opt in to the host's authorized, on-demand result View from middleware metadata. */ const AGENT_TASK_RESULTS_FEATURE = 'agent_task_results';
const common = {
    id: v3.z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/),
    title: v3.z.string().min(1).max(200),
    summary: v3.z.string().max(16000)
};
/** Machine-readable result kind; file declarations are not committed artifacts or download grants. */ const agentResultItemSchema = v3.z.discriminatedUnion('type', [
    v3.z.object(_extends._extends({}, common, {
        type: v3.z.literal('analysis')
    })).strict(),
    v3.z.object(_extends._extends({}, common, {
        type: v3.z.literal('changes'),
        files: v3.z.array(v3.z.object({
            path: contracts.agentResultPathSchema,
            change: v3.z.enum([
                'created',
                'modified',
                'deleted'
            ])
        }).strict()).max(128)
    })).strict(),
    v3.z.object(_extends._extends({}, common, {
        type: v3.z.literal('tests'),
        status: v3.z.enum([
            'passed',
            'failed',
            'skipped'
        ]),
        command: v3.z.string().max(2000).optional()
    })).strict(),
    v3.z.object(_extends._extends({}, common, {
        type: v3.z.literal('file'),
        path: contracts.agentResultPathSchema
    })).strict()
]);
/** Report bytes are transported independently of artifact quotas and business acceptance. */ const AGENT_TASK_REPORT_MAX_BYTES = 4 * 1024 * 1024;

exports.AGENT_TASK_REPORT_MAX_BYTES = AGENT_TASK_REPORT_MAX_BYTES;
exports.AGENT_TASK_RESULTS_FEATURE = AGENT_TASK_RESULTS_FEATURE;
exports.agentResultItemSchema = agentResultItemSchema;
