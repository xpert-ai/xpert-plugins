'use strict';

var _extends = require('./_extends.cjs.js');
var contextEvent = require('@xpert-ai/contracts/context-event');
var v3 = require('zod/v3');

const channel = 'xpertai.remote_component';
const envelope = v3.z.object({
    channel: v3.z.literal(channel),
    protocolVersion: v3.z.literal(1),
    type: v3.z.string(),
    instanceId: v3.z.string().min(1),
    scopeRevision: v3.z.number().int().nonnegative().optional(),
    event: v3.z.unknown().optional(),
    requestId: v3.z.string().optional(),
    data: v3.z.unknown().optional(),
    result: v3.z.unknown().optional(),
    message: v3.z.string().optional(),
    locale: v3.z.string().optional(),
    theme: v3.z.object({
        mode: v3.z.string().optional(),
        density: v3.z.enum([
            'default',
            'compact'
        ]).optional(),
        tokens: v3.z.record(v3.z.union([
            v3.z.string(),
            v3.z.number()
        ])).optional()
    }).optional()
});
let scope;
let disconnect;
const pending = new Map();
function invalidate(message) {
    for (const call of pending.values()){
        window.clearTimeout(call.timer);
        call.reject(new Error(message));
    }
    pending.clear();
}
/** Subscribe before rendering. The returned cleanup releases the listener and all outstanding requests. */ function connect(init, contextChanged) {
    disconnect == null ? void 0 : disconnect();
    const receive = (event)=>{
        if (event.source !== window.parent) return;
        const parsed = envelope.safeParse(event.data);
        if (!parsed.success) return;
        const message = parsed.data;
        if (message.type === 'init') {
            var _message_scopeRevision, _scope_revision;
            if ((scope == null ? void 0 : scope.instanceId) === message.instanceId && ((_message_scopeRevision = message.scopeRevision) != null ? _message_scopeRevision : -1) < ((_scope_revision = scope.revision) != null ? _scope_revision : -1)) return;
            const changed = (scope == null ? void 0 : scope.instanceId) !== message.instanceId || (scope == null ? void 0 : scope.revision) !== message.scopeRevision;
            if (changed) {
                invalidate('View context changed');
                scope = {
                    instanceId: message.instanceId,
                    revision: message.scopeRevision
                };
            }
            var _message_locale;
            init({
                locale: (_message_locale = message.locale) != null ? _message_locale : 'en-US',
                theme: message.theme
            }, changed);
            return;
        }
        if (!scope || message.instanceId !== scope.instanceId) return;
        if (message.type === 'hostEvent') {
            const context = contextEvent.viewContextEventSchema.safeParse(message.event);
            var _scope_revision1;
            if (context.success && context.data.data.revision > ((_scope_revision1 = scope.revision) != null ? _scope_revision1 : -1)) {
                invalidate('View context changed');
                scope = {
                    instanceId: scope.instanceId,
                    revision: context.data.data.revision
                };
                contextChanged();
            }
            return;
        }
        if (!message.requestId || message.scopeRevision !== undefined && message.scopeRevision !== scope.revision) return;
        const call = pending.get(message.requestId);
        if (!call) return;
        pending.delete(message.requestId);
        window.clearTimeout(call.timer);
        var _message_message;
        if (message.type === 'error') call.reject(new Error((_message_message = message.message) != null ? _message_message : 'Request failed'));
        else call.resolve('data' in message ? message.data : message.result);
    };
    window.addEventListener('message', receive);
    window.parent.postMessage({
        channel,
        protocolVersion: 1,
        type: 'ready'
    }, '*');
    const close = ()=>{
        if (disconnect !== close) return;
        disconnect = undefined;
        window.removeEventListener('message', receive);
        scope = undefined;
        invalidate('View closed');
    };
    disconnect = close;
    return close;
}
function request(type, body = {}) {
    if (!scope) return Promise.reject(new Error('View is not connected'));
    const { instanceId, revision } = scope;
    const requestId = crypto.randomUUID();
    return new Promise((resolve, reject)=>{
        const timer = window.setTimeout(()=>{
            pending.delete(requestId);
            reject(new Error('Request timed out'));
        }, 30000);
        pending.set(requestId, {
            resolve,
            reject,
            timer
        });
        try {
            window.parent.postMessage(_extends._extends({}, body, {
                channel,
                protocolVersion: 1,
                instanceId,
                scopeRevision: revision,
                type,
                requestId
            }), '*');
        } catch (error) {
            window.clearTimeout(timer);
            pending.delete(requestId);
            reject(error);
        }
    });
}
/** Bind a request before asynchronous preparation, so a context switch cannot redirect it. */ function scopedRequest() {
    const captured = scope;
    return (type, body)=>captured && captured === scope ? request(type, body) : Promise.reject(new Error('View context changed'));
}

exports.connect = connect;
exports.request = request;
exports.scopedRequest = scopedRequest;
