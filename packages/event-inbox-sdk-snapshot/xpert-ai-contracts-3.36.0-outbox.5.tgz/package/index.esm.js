import { z } from 'zod/v3';
import { z as z$1 } from 'zod';
import ShortUniqueId from 'short-unique-id';
import { parseResourceCardContent, upsertResourceCardContent, parseFileActivityContent, upsertFileActivityContent, isFileActivityContent, isResourceCardContent } from '@xpert-ai/chatkit-types';
export { createResourceCardContent, isResourceCardContent, parseResourceCard, parseResourceCardContent, resourceCardId, upsertResourceCardContent } from '@xpert-ai/chatkit-types';
export { viewContextEventSchema } from './context-event.esm.js';

var key$5 = z.string().min(1).max(256).refine(function(value) {
    return !value.includes("\x00");
});
var agentEventRefSchema = z.object({
    kind: key$5,
    key: key$5
}).strict();
var pluginAgentEventSchema = z.object({
    sourceEventId: key$5,
    bindingRevision: z.number().int().positive(),
    type: key$5,
    schemaVersion: z.number().int().positive(),
    occurredAt: z.string().datetime({
        offset: true
    }),
    subject: agentEventRefSchema,
    fact: z.object({
        key: key$5,
        revision: key$5,
        sha256: z.string().regex(/^[0-9a-f]{64}$/)
    }).strict()
}).strict();
var reasonCode = z.string().regex(/^[a-z][a-z0-9_]{0,79}$/);
var agentEventDecisionSchema = z.discriminatedUnion("status", [
    z.object({
        status: z.literal("handled"),
        operationKey: key$5,
        resultRef: agentEventRefSchema
    }).strict(),
    z.object({
        status: z.literal("ignored"),
        reasonCode: reasonCode
    }).strict(),
    z.object({
        status: z.literal("blocked"),
        reasonCode: reasonCode
    }).strict()
]);

var EVENT_INBOX_FEATURE = "platform.event-inbox";
var USER_EVENT_INBOX_SLOT = "user.event-inbox";
var EVENT_INBOX_VIEW_KEY = "platform.event-inbox__inbox";

// Application types are independent of delivery channels and external account identities.
var notificationClientSchema = z.enum([
    "web",
    "desktop"
]);
var announcementActionSchema = z.object({
    type: z.literal("link"),
    label: z.string().trim().min(1).max(80),
    url: z.string().url().max(2048).refine(function(url) {
        return /^https:\/\//i.test(url);
    })
}).strict();
var announcementContentSchema = z.object({
    title: z.string().trim().min(1).max(160),
    body: z.string().trim().min(1).max(20000),
    category: z.enum([
        "general",
        "maintenance",
        "model_retirement"
    ]).default("general"),
    severity: z.enum([
        "info",
        "important"
    ]).default("info"),
    clients: z.array(notificationClientSchema).min(1).max(2).refine(function(items) {
        return new Set(items).size === items.length;
    }),
    startsAt: z.string().datetime({
        offset: true
    }),
    expiresAt: z.string().datetime({
        offset: true
    }).nullable().default(null),
    action: announcementActionSchema.nullable().default(null)
}).strict();
var createAnnouncementSchema = announcementContentSchema.refine(function(input) {
    return !input.expiresAt || Date.parse(input.expiresAt) > Date.parse(input.startsAt);
}, {
    path: [
        "expiresAt"
    ],
    message: "Expiry must follow start"
});
var updateAnnouncementSchema = announcementContentSchema.extend({
    revision: z.number().int().positive()
}).refine(function(input) {
    return !input.expiresAt || Date.parse(input.expiresAt) > Date.parse(input.startsAt);
}, {
    path: [
        "expiresAt"
    ]
});
var announcementRevisionSchema = z.object({
    revision: z.number().int().positive()
}).strict();
var announcementSchema = announcementContentSchema.extend({
    id: z.string().uuid(),
    status: z.enum([
        "draft",
        "published",
        "withdrawn"
    ]),
    revision: z.number().int().positive(),
    createdAt: z.string().datetime({
        offset: true
    }),
    dismissedAt: z.string().datetime({
        offset: true
    }).nullable().default(null)
});
var notificationSourceSchema = z.object({
    type: z.literal("scheduled_task"),
    taskId: z.string().uuid(),
    executionId: z.string().uuid(),
    assistantId: z.string().uuid(),
    conversationId: z.string().uuid()
}).strict();
var scheduledNotificationOriginSchema = notificationSourceSchema.extend({
    threadId: z.string().uuid().optional()
});
var notificationThreadIdSchema = z.string().trim().min(1).max(128);
var openConversationActionSchema = z.object({
    type: z.literal("open_conversation"),
    assistantId: z.string().uuid(),
    conversationId: z.string().uuid(),
    threadId: notificationThreadIdSchema.nullable()
}).strict();
var taskNotificationSchema = z.object({
    id: z.string().uuid(),
    kind: z.literal("agent.completed"),
    source: notificationSourceSchema,
    createdAt: z.string().datetime({
        offset: true
    }),
    readAt: z.string().datetime({
        offset: true
    }).nullable(),
    action: openConversationActionSchema
}).strict();
var agentOutputOriginSchema = z.object({
    type: z.literal("agent_output"),
    deliveryId: z.string().uuid()
}).strict();
var outputNotificationSchema = taskNotificationSchema.extend({
    kind: z.literal("agent.output"),
    source: agentOutputOriginSchema,
    titles: z.array(z.string().min(1).max(240)).min(1).max(20),
    action: openConversationActionSchema.nullable()
});
var userNotificationSchema = z.discriminatedUnion("kind", [
    taskNotificationSchema,
    outputNotificationSchema
]);
var notificationSnapshotSchema = z.object({
    supported: z.literal(true),
    version: z.string(),
    announcements: z.array(announcementSchema),
    notifications: z.array(userNotificationSchema),
    hasMoreAnnouncements: z.boolean(),
    hasMoreNotifications: z.boolean()
}).strict();
var notificationChangeSchema = z.object({
    schemaVersion: z.literal(1),
    type: z.literal("sync.required"),
    eventId: z.string().uuid()
}).strict();
var notificationOutboxPayloadSchema = z.discriminatedUnion("type", [
    z.object({
        type: z.literal("changed")
    }).strict(),
    z.object({
        type: z.literal("agent.output.dispatch"),
        deliveryId: z.string().uuid()
    }).strict(),
    z.object({
        type: z.literal("announcement.scheduled"),
        announcementId: z.string().uuid(),
        revision: z.number().int().positive(),
        phase: z.enum([
            "start",
            "expiry"
        ])
    }).strict(),
    z.object({
        type: z.literal("agent.completed"),
        source: scheduledNotificationOriginSchema
    }).strict()
]);
// The contracts declaration build uses strictNullChecks=false, which makes Zod's emitted
// object outputs optional. These boundaries validate every required field before narrowing.
function parseAnnouncement(value) {
    return announcementSchema.parse(value);
}
function parseOpenConversationAction(value) {
    return openConversationActionSchema.parse(value);
}
function parseUserNotification(value) {
    return userNotificationSchema.parse(value);
}
function parseNotificationSnapshot(value) {
    return notificationSnapshotSchema.parse(value);
}

var AGENT_OUTPUT_ACCEPT = 'application/json; profile="xpert-agent-output-v1"';
var outputField = z.object({
    label: z.object({
        en_US: z.string().min(1).max(160),
        zh_Hans: z.string().min(1).max(160)
    }).strict(),
    value: z.string().max(4000)
}).strict();
var key$4 = z.string().min(1).max(160);
var uuid$1 = z.string().uuid();
var hhmm = z.string().regex(/^([01][0-9]|2[0-3]):[0-5][0-9]$/);
var outputQuietHoursSchema = z.object({
    zone: z.string().max(100).refine(function(value) {
        try {
            new Intl.DateTimeFormat("en", {
                timeZone: value
            });
            return true;
        } catch (e) {
            return false;
        }
    }),
    start: hhmm,
    end: hhmm
}).strict().refine(function(value) {
    return value.start !== value.end;
});
var outputPreferenceSchema = z.object({
    kind: key$4,
    channel: z.enum([
        "in_app",
        "lark"
    ]),
    enabled: z.boolean(),
    integrationId: uuid$1.nullable(),
    quiet: outputQuietHoursSchema.nullable()
}).strict().refine(function(v) {
    return v.channel === "lark" ? !v.enabled || !!v.integrationId : v.integrationId === null;
});
var agentOutputReferenceSchema = z.object({
    schemaVersion: z.literal(1),
    kind: key$4,
    key: key$4,
    revision: key$4,
    publishedAt: z.string().datetime(),
    recipientId: uuid$1
}).strict();
var agentOutputPresentationSchema = z.discriminatedUnion("status", [
    z.object({
        status: z.literal("visible"),
        title: z.string().trim().min(1).max(240),
        fields: z.array(outputField).max(20).optional(),
        conversation: z.object({
            conversationId: uuid$1,
            threadId: notificationThreadIdSchema.optional()
        }).strict().optional().catch(undefined)
    }).strict(),
    z.object({
        status: z.enum([
            "superseded",
            "forbidden",
            "unavailable"
        ])
    }).strict()
]);

var AiModelTypeEnum;
(function(AiModelTypeEnum) {
    AiModelTypeEnum["REALTIME"] = "realtime";
    AiModelTypeEnum["LLM"] = "llm";
    AiModelTypeEnum["TEXT_EMBEDDING"] = "text-embedding";
    AiModelTypeEnum["RERANK"] = "rerank";
    AiModelTypeEnum["SPEECH2TEXT"] = "speech2text";
    AiModelTypeEnum["MODERATION"] = "moderation";
    AiModelTypeEnum["TTS"] = "tts";
    AiModelTypeEnum["IMAGE"] = "image";
    /** @deprecated Use IMAGE for new image-generation model providers. */ AiModelTypeEnum["TEXT2IMG"] = "text2img";
    AiModelTypeEnum["VIDEO"] = "video";
})(AiModelTypeEnum || (AiModelTypeEnum = {}));

function _define_property$t(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$t(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$t(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$m(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$m(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$m(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var key$3 = z.string().regex(/^[a-z][a-z0-9_-]{0,79}$/);
var text$2 = z.string().trim().min(1).max(255);
var reference$2 = z.object({
    app: key$3,
    resource: key$3
}).strict();
var appPlatformAppSchema = z.object({
    key: key$3,
    appRef: z.object({
        pluginName: text$2,
        appName: text$2
    }).strict(),
    required: z.boolean(),
    enabled: z.boolean().default(true),
    configurationRef: key$3,
    dependsOn: z.array(key$3).max(32).default([])
}).strict().transform(function(app) {
    return _object_spread_props$m(_object_spread$t({}, app), {
        key: app.key,
        required: app.required,
        configurationRef: app.configurationRef,
        dependsOn: app.dependsOn,
        enabled: app.enabled,
        appRef: {
            pluginName: app.appRef.pluginName,
            appName: app.appRef.appName
        }
    });
});
/** Portable product composition. Credentials and database identities never belong here. */ var appPlatformDefinitionSchema = z.object({
    schemaVersion: z.literal(1),
    key: key$3,
    version: z.number().int().positive(),
    branding: z.object({
        name: text$2,
        description: z.string().max(1000).optional(),
        logo: z.string().regex(/^\/[a-zA-Z0-9/_\-.]+$/).optional()
    }).strict(),
    registration: z.object({
        role: z.literal("APP_USER"),
        organization: z.literal("per-account")
    }).strict(),
    apps: z.array(appPlatformAppSchema).min(1).max(32),
    bindings: z.array(z.object({
        type: z.literal("knowledgebase"),
        from: reference$2,
        to: reference$2
    }).strict()).max(100).default([]),
    experience: z.object({
        home: key$3,
        navigation: z.array(key$3).min(1).max(32)
    }).strict(),
    entitlements: z.object({
        defaultPlanRef: key$3
    }).strict()
}).strict().superRefine(function(definition, ctx) {
    var _apps_get, _apps_get1;
    var fail = function(message) {
        return ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: message
        });
    };
    var apps = new Map(definition.apps.map(function(app) {
        return [
            app.key,
            app
        ];
    }));
    if (apps.size !== definition.apps.length) fail("Duplicate application key");
    var targets = new Set(definition.apps.map(function(app) {
        return JSON.stringify(app.appRef);
    }));
    if (targets.size !== apps.size) fail("Duplicate application installation target");
    if (!((_apps_get = apps.get(definition.experience.home)) === null || _apps_get === void 0 ? void 0 : _apps_get.required)) fail("Home must reference a required application");
    if (!((_apps_get1 = apps.get(definition.experience.home)) === null || _apps_get1 === void 0 ? void 0 : _apps_get1.enabled)) fail("Home application must be enabled");
    if (!definition.experience.navigation.includes(definition.experience.home)) fail("Home must be present in navigation");
    if (new Set(definition.experience.navigation).size !== definition.experience.navigation.length) fail("Duplicate navigation entry");
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = definition.experience.navigation[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var entry = _step.value;
            if (!apps.has(entry)) fail("Unknown navigation application");
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = definition.apps[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var app = _step1.value;
            if (new Set(app.dependsOn).size !== app.dependsOn.length) fail("Duplicate dependency");
            var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
            try {
                for(var _iterator2 = app.dependsOn[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
                    var dependency = _step2.value;
                    var _apps_get2, _apps_get3;
                    if (!apps.has(dependency)) fail("Unknown application dependency");
                    if (app.enabled && !((_apps_get2 = apps.get(dependency)) === null || _apps_get2 === void 0 ? void 0 : _apps_get2.enabled)) fail("Enabled application depends on disabled application");
                    if (app.required && !((_apps_get3 = apps.get(dependency)) === null || _apps_get3 === void 0 ? void 0 : _apps_get3.required)) fail("Required application depends on optional application");
                }
            } catch (err) {
                _didIteratorError2 = true;
                _iteratorError2 = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                        _iterator2.return();
                    }
                } finally{
                    if (_didIteratorError2) {
                        throw _iteratorError2;
                    }
                }
            }
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    var complete = new Set(), active = new Set();
    var visit = function(id) {
        var _apps_get;
        if (active.has(id)) {
            fail("Application dependency cycle");
            return;
        }
        if (complete.has(id)) return;
        active.add(id);
        var _apps_get_dependsOn;
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = ((_apps_get_dependsOn = (_apps_get = apps.get(id)) === null || _apps_get === void 0 ? void 0 : _apps_get.dependsOn) !== null && _apps_get_dependsOn !== void 0 ? _apps_get_dependsOn : [])[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var dependency = _step.value;
                visit(dependency);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
        active.delete(id);
        complete.add(id);
    };
    var _iteratorNormalCompletion3 = true, _didIteratorError3 = false, _iteratorError3 = undefined;
    try {
        for(var _iterator3 = definition.apps[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true){
            var app1 = _step3.value;
            visit(app1.key);
        }
    } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion3 && _iterator3.return != null) {
                _iterator3.return();
            }
        } finally{
            if (_didIteratorError3) {
                throw _iteratorError3;
            }
        }
    }
    var consumers = new Set();
    var _iteratorNormalCompletion4 = true, _didIteratorError4 = false, _iteratorError4 = undefined;
    try {
        for(var _iterator4 = definition.bindings[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true){
            var binding = _step4.value;
            var consumer = apps.get(binding.to.app);
            if (!apps.has(binding.from.app) || !consumer) fail("Unknown resource binding application");
            if (binding.from.app === binding.to.app) fail("Resource binding must reference another application");
            if (!(consumer === null || consumer === void 0 ? void 0 : consumer.dependsOn.includes(binding.from.app))) fail("Resource binding requires an explicit dependency");
            var target = "".concat(binding.to.app, ":").concat(binding.to.resource);
            if (consumers.has(target)) fail("Resource has multiple providers");
            consumers.add(target);
        }
    } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion4 && _iterator4.return != null) {
                _iterator4.return();
            }
        } finally{
            if (_didIteratorError4) {
                throw _iteratorError4;
            }
        }
    }
});
var model = z.object({
    provider: text$2,
    model: text$2,
    role: z.enum([
        "primary",
        "secondary",
        "embedding",
        "reasoning"
    ]).optional()
}).strict();
var appPlatformEnvironmentSchema = z.object({
    schemaVersion: z.literal(1),
    configurations: z.record(key$3, z.object({
        primary: model,
        embedding: model.optional(),
        vision: model.optional(),
        speechToText: model.optional(),
        auxiliaryModels: z.array(model.extend({
            modelType: z.nativeEnum(AiModelTypeEnum)
        })).max(32).default([]),
        tools: z.array(z.object({
            provider: text$2,
            sourceName: text$2
        }).strict()).max(32).default([]).refine(function(items) {
            return new Set(items.map(function(item) {
                return item.provider;
            })).size === items.length;
        }, "Duplicate tool provider")
    }).strict()),
    plans: z.record(key$3, z.object({
        trialDays: z.number().int().min(1).max(365),
        creditLimit: z.number().positive(),
        maxProjects: z.number().int().min(1).max(10000),
        maxUploadBytes: z.number().int().positive(),
        maxStorageBytes: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).default(2 * Math.pow(1024, 3)),
        maxTemporaryBytes: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).default(256 * Math.pow(1024, 2)),
        maxConcurrentRuns: z.number().int().min(1).max(100)
    }).strict())
}).strict();
function appPlatformAppOrder(definition) {
    var apps = new Map(definition.apps.map(function(app) {
        return [
            app.key,
            app
        ];
    }));
    var ordered = [], seen = new Set();
    var visit = function(app) {
        if (seen.has(app.key)) return;
        seen.add(app.key);
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = app.dependsOn[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var id = _step.value;
                var dependency = apps.get(id);
                if (dependency) visit(dependency);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
        ordered.push(app);
    };
    definition.apps.forEach(visit);
    return ordered;
}

/** Internal boot capabilities. Online/readiness and execution settlement remain separate facts. */ var executionControlProtocols = {
    taskControl: 2,
    managedQueue: 3,
    threadControlView: 1,
    mcpControl: 1,
    sandboxControl: 1,
    invocationEvidence: 2
};
var controlledHandlerSchema = z$1.object({
    pluginName: z$1.string().min(1),
    queueName: z$1.string().min(1),
    jobName: z$1.string().min(1),
    scopeKey: z$1.string().nullable(),
    controlContract: z$1.string().min(1).max(160)
}).strict();
var executionControlCapabilitiesSchema = z$1.object({
    version: z$1.literal(1),
    validUntil: z$1.number().finite(),
    protocols: z$1.object({
        taskControl: z$1.literal(2).optional(),
        managedQueue: z$1.literal(3).optional(),
        threadControlView: z$1.literal(1).optional(),
        mcpControl: z$1.literal(1).optional(),
        sandboxControl: z$1.literal(1).optional(),
        invocationEvidence: z$1.literal(2).optional()
    }).strict(),
    queuePrefix: z$1.string().min(1).max(160),
    queuePools: z$1.array(z$1.enum([
        "default",
        "sandbox-browser"
    ])),
    handlers: z$1.array(controlledHandlerSchema)
}).strict();

function resolveI18nText(value) {
    var language = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "en-US";
    if (typeof value === "string") {
        var trimmed = value.trim();
        return trimmed || null;
    }
    if (!value || typeof value !== "object") {
        return null;
    }
    var localized = value;
    var normalizedLanguage = language.trim();
    var underscoredLanguage = normalizedLanguage.replace(/-/g, "_");
    var languagePrefix = normalizedLanguage.split(/[-_]/)[0];
    var preferredKeys = normalizedLanguage.toLowerCase().startsWith("zh") ? [
        normalizedLanguage,
        underscoredLanguage,
        "zh_Hans",
        "zh-Hans",
        "zh_CN",
        "zh-CN",
        "zh",
        "en_US",
        "en-US",
        "en"
    ] : [
        normalizedLanguage,
        underscoredLanguage,
        "en_US",
        "en-US",
        "en",
        languagePrefix,
        "zh_Hans",
        "zh-Hans",
        "zh_CN",
        "zh-CN",
        "zh"
    ];
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = preferredKeys[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var key = _step.value;
            var candidate = localized[key];
            if (typeof candidate === "string" && candidate.trim()) {
                return candidate.trim();
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = Object.values(localized)[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var candidate1 = _step1.value;
            if (typeof candidate1 === "string" && candidate1.trim()) {
                return candidate1.trim();
            }
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    return null;
}

function _array_like_to_array$y(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$l(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$y(arr);
}
function _iterable_to_array$n(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$l() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$l(arr) {
    return _array_without_holes$l(arr) || _iterable_to_array$n(arr) || _unsupported_iterable_to_array$y(arr) || _non_iterable_spread$l();
}
function _unsupported_iterable_to_array$y(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$y(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$y(o, minLen);
}
// The legacy generator extends Function; constructing it during import violates Desktop's CSP.
var uuidGenerator;
var uuid = function() {
    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
        args[_key] = arguments[_key];
    }
    var _uuidGenerator;
    uuidGenerator !== null && uuidGenerator !== void 0 ? uuidGenerator : uuidGenerator = new ShortUniqueId({
        length: 10
    });
    return (_uuidGenerator = uuidGenerator).randomUUID.apply(_uuidGenerator, _to_consumable_array$l(args));
};
// Parameters
var ParameterTypeEnum;
(function(ParameterTypeEnum) {
    ParameterTypeEnum["STRING"] = "string";
    ParameterTypeEnum["NUMBER"] = "number";
    ParameterTypeEnum["BOOLEAN"] = "boolean";
    ParameterTypeEnum["ARRAY"] = "array";
    ParameterTypeEnum["SELECT"] = "select";
    ParameterTypeEnum["SECRET_INPUT"] = "secret-input";
    ParameterTypeEnum["FILE"] = "file";
})(ParameterTypeEnum || (ParameterTypeEnum = {}));
function letterStartSUID(start) {
    return start + uuid();
}

/** A control request can address only the original environment and execution generation. */ var sandboxRuntimeTargetSchema = z.object({
    version: z.literal(1),
    kind: z.enum([
        "host",
        "engine"
    ]),
    provider: z.string().min(1),
    runtimeProfile: z.string().min(1),
    generation: z.string().uuid(),
    environmentId: z.string().min(1),
    runtimeRef: z.string().min(1)
}).strict();
/** An accepted stop, closed stream, or expired lease is never an exit receipt. */ var sandboxRuntimeEvidenceSchema = z.object({
    version: z.literal(1),
    target: sandboxRuntimeTargetSchema,
    state: z.enum([
        "running",
        "exited",
        "not_started",
        "unknown"
    ]),
    observedAt: z.string().datetime()
}).strict();
function sandboxTargetsEqual(a, b) {
    return a.version === b.version && a.kind === b.kind && a.provider === b.provider && a.runtimeProfile === b.runtimeProfile && a.generation === b.generation && a.environmentId === b.environmentId && a.runtimeRef === b.runtimeRef;
}
function sandboxEvidence(target, state) {
    return {
        version: 1,
        target: target,
        state: state,
        observedAt: new Date().toISOString()
    };
}
/** Explicit new business retry; it may proceed only after this original generation settled. */ var sandboxJobRetryReferenceSchema = z.object({
    jobId: z.string().uuid(),
    generation: z.string().uuid()
}).strict();

/** Portable presentation tokens. Clients render their own trusted icon components. */ var PROJECT_TASK_ICON_NAMES = [
    "FileText",
    "FileScan",
    "FileSearch",
    "ListChecks",
    "ListTree",
    "ShieldCheck",
    "FilePenLine",
    "Workflow",
    "Images",
    "FolderInput",
    "FileOutput"
];

/** A summary's incoming dependencies constrain its children without making them wait for the summary itself. */ function _array_like_to_array$x(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$k(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$x(arr);
}
function _iterable_to_array$m(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$k() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$k(arr) {
    return _array_without_holes$k(arr) || _iterable_to_array$m(arr) || _unsupported_iterable_to_array$x(arr) || _non_iterable_spread$k();
}
function _unsupported_iterable_to_array$x(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$x(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$x(o, minLen);
}
function schedulePredecessors(task, byId) {
    var ids = new Set(task.predecessorIds);
    var seen = new Set();
    var parentId = task.parentTaskId;
    while(parentId && !seen.has(parentId)){
        seen.add(parentId);
        var parent = byId.get(parentId);
        if (!parent || parent.kind !== "summary") break;
        parent.predecessorIds.forEach(function(id) {
            return ids.add(id);
        });
        parentId = parent.parentTaskId;
    }
    return _to_consumable_array$k(ids);
}
/** Tree containment and finish-to-start dependencies are separate acyclic graphs. */ function validateProjectTaskGraph(tasks) {
    var _loop = function(_i1, _iter1) {
        var relation = _iter1[_i1];
        var visited = new Set(), active = new Set();
        var visit = function(id) {
            if (active.has(id)) throw Error("PROJECT_TASK_".concat(relation.toUpperCase(), "_CYCLE: ").concat(id));
            if (visited.has(id)) return;
            var task = byId.get(id);
            if (!task) throw Error("PROJECT_TASK_RELATION_NOT_FOUND: ".concat(id));
            active.add(id);
            var references = relation === "tree" ? task.parentTaskId ? [
                task.parentTaskId
            ] : [] : _to_consumable_array$k(relation === "schedule" ? schedulePredecessors(task, byId) : task.predecessorIds).concat(_to_consumable_array$k(relation === "schedule" && task.kind === "summary" ? tasks.filter(function(child) {
                return child.parentTaskId === task.id;
            }).map(function(child) {
                return child.id;
            }) : []));
            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
            try {
                for(var _iterator = references[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                    var next = _step.value;
                    visit(next);
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                        _iterator.return();
                    }
                } finally{
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
            active.delete(id);
            visited.add(id);
        };
        tasks.forEach(function(task) {
            return visit(task.id);
        });
    };
    var byId = new Map(tasks.map(function(task) {
        return [
            task.id,
            task
        ];
    }));
    if (byId.size !== tasks.length) throw Error("PROJECT_TASK_DUPLICATE_ID");
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = tasks[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var task = _step.value;
            if (task.estimatedDurationMs != null && (!Number.isFinite(task.estimatedDurationMs) || task.estimatedDurationMs < 0)) {
                throw Error("PROJECT_TASK_DURATION_INVALID: ".concat(task.id));
            }
            for(var _i = 0, _iter = [
                task.plannedStartAt,
                task.plannedEndAt
            ]; _i < _iter.length; _i++){
                var date = _iter[_i];
                if (date != null && !Number.isFinite(Date.parse(date))) throw Error("PROJECT_TASK_DATE_INVALID: ".concat(task.id));
            }
            if (task.plannedStartAt && task.plannedEndAt && Date.parse(task.plannedEndAt) < Date.parse(task.plannedStartAt)) {
                throw Error("PROJECT_TASK_DATE_ORDER: ".concat(task.id));
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    for(var _i1 = 0, _iter1 = [
        "tree",
        "dependency",
        "schedule"
    ]; _i1 < _iter1.length; _i1++)_loop(_i1, _iter1);
}
/** Unknown estimates stay unknown. Summary rows never contribute another duration. */ function forecastProjectTasks(tasks, changedId) {
    validateProjectTaskGraph(tasks);
    var byId = new Map(tasks.map(function(task) {
        return [
            task.id,
            task
        ];
    }));
    var result = new Map();
    var affected = new Set(changedId ? [
        changedId
    ] : []);
    var visiting = new Set();
    var calculate = function(task) {
        var previous = result.get(task.id);
        if (previous) return previous;
        if (visiting.has(task.id)) throw Error("PROJECT_TASK_SCHEDULE_CYCLE: ".concat(task.id));
        visiting.add(task.id);
        var predecessors = schedulePredecessors(task, byId).map(function(id) {
            return calculate(byId.get(id));
        });
        if (predecessors.some(function(item) {
            return affected.has(item.taskId);
        })) affected.add(task.id);
        var startAt = null, endAt = null;
        if (task.kind === "summary") {
            var _Math, _Math1;
            var children = tasks.filter(function(child) {
                return child.parentTaskId === task.id;
            }).map(calculate);
            var starts = children.flatMap(function(child) {
                return child.startAt ? [
                    Date.parse(child.startAt)
                ] : [];
            });
            startAt = starts.length ? new Date((_Math = Math).min.apply(_Math, _to_consumable_array$k(starts))).toISOString() : null;
            endAt = children.length && children.every(function(child) {
                return child.endAt;
            }) ? new Date((_Math1 = Math).max.apply(_Math1, _to_consumable_array$k(children.map(function(child) {
                return Date.parse(child.endAt);
            })))).toISOString() : null;
            if (children.some(function(child) {
                return affected.has(child.taskId);
            })) affected.add(task.id);
        } else if (task.actualEndAt && task.status === "done") {
            startAt = task.actualStartAt;
            endAt = task.actualEndAt;
        } else {
            var _Math2;
            var _task_estimatedDurationMs;
            var duration = (_task_estimatedDurationMs = task.estimatedDurationMs) !== null && _task_estimatedDurationMs !== void 0 ? _task_estimatedDurationMs : task.plannedStartAt && task.plannedEndAt ? Date.parse(task.plannedEndAt) - Date.parse(task.plannedStartAt) : task.kind === "milestone" ? 0 : null;
            var _task_actualStartAt;
            var start = (_task_actualStartAt = task.actualStartAt) !== null && _task_actualStartAt !== void 0 ? _task_actualStartAt : task.plannedStartAt;
            var predecessorEnds = predecessors.map(function(item) {
                return item.endAt ? Date.parse(item.endAt) : null;
            });
            var earliest = task.actualStartAt ? Date.parse(task.actualStartAt) : predecessorEnds.some(function(value) {
                return value === null;
            }) ? null : start !== null || predecessorEnds.length ? (_Math2 = Math).max.apply(_Math2, _to_consumable_array$k(start !== null ? [
                Date.parse(start)
            ] : []).concat(_to_consumable_array$k(predecessorEnds.map(function(value) {
                return value;
            })))) : null;
            startAt = earliest === null ? null : new Date(earliest).toISOString();
            // A blocked task has no known release date. Show affected successors without inventing one.
            endAt = earliest === null || duration === null || [
                "blocked",
                "paused",
                "cancelled"
            ].includes(task.status) || Boolean(task.actualEndAt && task.status !== "done") ? null : new Date(earliest + duration).toISOString();
        }
        var forecast = {
            taskId: task.id,
            startAt: startAt,
            endAt: endAt,
            affected: affected.has(task.id),
            critical: false
        };
        result.set(task.id, forecast);
        visiting.delete(task.id);
        return forecast;
    };
    tasks.forEach(calculate);
    // Critical highlighting is only meaningful when every executable task has an estimate.
    var leaves = tasks.filter(function(task) {
        return task.kind !== "summary";
    });
    if (leaves.length && leaves.every(function(task) {
        return result.get(task.id).endAt !== null;
    })) {
        var _Math;
        var finish = (_Math = Math).max.apply(_Math, _to_consumable_array$k(leaves.map(function(task) {
            return Date.parse(result.get(task.id).endAt);
        })));
        var mark = function(id) {
            var item = result.get(id);
            if (item.critical) return;
            if (byId.get(id).kind === "summary") {
                tasks.filter(function(child) {
                    var _result_get;
                    return child.parentTaskId === id && ((_result_get = result.get(child.id)) === null || _result_get === void 0 ? void 0 : _result_get.endAt) === item.endAt;
                }).forEach(function(child) {
                    return mark(child.id);
                });
                return;
            }
            item.critical = true;
            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
            try {
                for(var _iterator = schedulePredecessors(byId.get(id), byId)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                    var parent = _step.value;
                    var endAt = result.get(parent).endAt;
                    if (endAt && item.startAt && Date.parse(endAt) === Date.parse(item.startAt)) mark(parent);
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                        _iterator.return();
                    }
                } finally{
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
        };
        leaves.filter(function(task) {
            return Date.parse(result.get(task.id).endAt) === finish;
        }).forEach(function(task) {
            return mark(task.id);
        });
    }
    return tasks.map(function(task) {
        return result.get(task.id);
    });
}

function _instanceof$2(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function isNil$1(value) {
    return value == null;
}
function nonNullable(value) {
    return value != null;
}
function isString(value) {
    return typeof value === "string" || _instanceof$2(value, String);
}
function isBlank(value) {
    return isNil$1(value) || isString(value) && !value.trim();
}
function nonBlank(value) {
    return !isBlank(value);
}

var OrderTypeEnum;
(function(OrderTypeEnum) {
    OrderTypeEnum["DESC"] = "DESC";
    OrderTypeEnum["ASC"] = "ASC";
})(OrderTypeEnum || (OrderTypeEnum = {}));

var DEFAULT_CURRENCIES = {
    AFN: "Afghan Afghani",
    AFA: "Afghan Afghani (1927–2002)",
    ALL: "Albanian Lek",
    ALK: "Albanian Lek (1946–1965)",
    DZD: "Algerian Dinar",
    ADP: "Andorran Peseta",
    AOA: "Angolan Kwanza",
    AOK: "Angolan Kwanza (1977–1991)",
    AON: "Angolan New Kwanza (1990–2000)",
    AOR: "Angolan Readjusted Kwanza (1995–1999)",
    ARA: "Argentine Austral",
    ARS: "Argentine Peso",
    ARM: "Argentine Peso (1881–1970)",
    ARP: "Argentine Peso (1983–1985)",
    ARL: "Argentine Peso Ley (1970–1983)",
    AMD: "Armenian Dram",
    AWG: "Aruban Florin",
    AUD: "Australian Dollar",
    ATS: "Austrian Schilling",
    AZN: "Azerbaijani Manat",
    AZM: "Azerbaijani Manat (1993–2006)",
    BSD: "Bahamian Dollar",
    BHD: "Bahraini Dinar",
    BDT: "Bangladeshi Taka",
    BBD: "Barbadian Dollar",
    BYN: "Belarusian Ruble",
    BYB: "Belarusian Ruble (1994–1999)",
    BYR: "Belarusian Ruble (2000–2016)",
    BEF: "Belgian Franc",
    BEC: "Belgian Franc (convertible)",
    BEL: "Belgian Franc (financial)",
    BZD: "Belize Dollar",
    BMD: "Bermudan Dollar",
    BTN: "Bhutanese Ngultrum",
    BOB: "Bolivian Boliviano",
    BOL: "Bolivian Boliviano (1863–1963)",
    BOV: "Bolivian Mvdol",
    BOP: "Bolivian Peso",
    BAM: "Bosnia-Herzegovina Convertible Mark",
    BAD: "Bosnia-Herzegovina Dinar (1992–1994)",
    BAN: "Bosnia-Herzegovina New Dinar (1994–1997)",
    BWP: "Botswanan Pula",
    BRC: "Brazilian Cruzado (1986–1989)",
    BRZ: "Brazilian Cruzeiro (1942–1967)",
    BRE: "Brazilian Cruzeiro (1990–1993)",
    BRR: "Brazilian Cruzeiro (1993–1994)",
    BRN: "Brazilian New Cruzado (1989–1990)",
    BRB: "Brazilian New Cruzeiro (1967–1986)",
    BRL: "Brazilian Real",
    GBP: "British Pound",
    BND: "Brunei Dollar",
    BGL: "Bulgarian Hard Lev",
    BGN: "Bulgarian Lev",
    BGO: "Bulgarian Lev (1879–1952)",
    BGM: "Bulgarian Socialist Lev",
    BUK: "Burmese Kyat",
    BIF: "Burundian Franc",
    XPF: "CFP Franc",
    KHR: "Cambodian Riel",
    CAD: "Canadian Dollar",
    CVE: "Cape Verdean Escudo",
    KYD: "Cayman Islands Dollar",
    XAF: "Central African CFA Franc",
    CLE: "Chilean Escudo",
    CLP: "Chilean Peso",
    CLF: "Chilean Unit of Account (UF)",
    CNX: "Chinese People’s Bank Dollar",
    CNY: "Chinese Yuan",
    COP: "Colombian Peso",
    COU: "Colombian Real Value Unit",
    KMF: "Comorian Franc",
    CDF: "Congolese Franc",
    CRC: "Costa Rican Col\xf3n",
    HRD: "Croatian Dinar",
    HRK: "Croatian Kuna",
    CUC: "Cuban Convertible Peso",
    CUP: "Cuban Peso",
    CYP: "Cypriot Pound",
    CZK: "Czech Koruna",
    CSK: "Czechoslovak Hard Koruna",
    DKK: "Danish Krone",
    DJF: "Djiboutian Franc",
    DOP: "Dominican Peso",
    NLG: "Dutch Guilder",
    XCD: "East Caribbean Dollar",
    DDM: "East German Mark",
    ECS: "Ecuadorian Sucre",
    ECV: "Ecuadorian Unit of Constant Value",
    EGP: "Egyptian Pound",
    GQE: "Equatorial Guinean Ekwele",
    ERN: "Eritrean Nakfa",
    EEK: "Estonian Kroon",
    ETB: "Ethiopian Birr",
    EUR: "Euro",
    XEU: "European Currency Unit",
    FKP: "Falkland Islands Pound",
    FJD: "Fijian Dollar",
    FIM: "Finnish Markka",
    FRF: "French Franc",
    XFO: "French Gold Franc",
    XFU: "French UIC-Franc",
    GMD: "Gambian Dalasi",
    GEK: "Georgian Kupon Larit",
    GEL: "Georgian Lari",
    DEM: "German Mark",
    GHS: "Ghanaian Cedi",
    GHC: "Ghanaian Cedi (1979–2007)",
    GIP: "Gibraltar Pound",
    GRD: "Greek Drachma",
    GTQ: "Guatemalan Quetzal",
    GWP: "Guinea-Bissau Peso",
    GNF: "Guinean Franc",
    GNS: "Guinean Syli",
    GYD: "Guyanaese Dollar",
    HTG: "Haitian Gourde",
    HNL: "Honduran Lempira",
    HKD: "Hong Kong Dollar",
    HUF: "Hungarian Forint",
    ISK: "Icelandic Kr\xf3na",
    ISJ: "Icelandic Kr\xf3na (1918–1981)",
    INR: "Indian Rupee",
    IDR: "Indonesian Rupiah",
    IRR: "Iranian Rial",
    IQD: "Iraqi Dinar",
    IEP: "Irish Pound",
    ILS: "Israeli New Shekel",
    ILP: "Israeli Pound",
    ILR: "Israeli Shekel (1980–1985)",
    ITL: "Italian Lira",
    JMD: "Jamaican Dollar",
    JPY: "Japanese Yen",
    JOD: "Jordanian Dinar",
    KZT: "Kazakhstani Tenge",
    KES: "Kenyan Shilling",
    KWD: "Kuwaiti Dinar",
    KGS: "Kyrgystani Som",
    LAK: "Laotian Kip",
    LVL: "Latvian Lats",
    LVR: "Latvian Ruble",
    LBP: "Lebanese Pound",
    LSL: "Lesotho Loti",
    LRD: "Liberian Dollar",
    LYD: "Libyan Dinar",
    LTL: "Lithuanian Litas",
    LTT: "Lithuanian Talonas",
    LUL: "Luxembourg Financial Franc",
    LUC: "Luxembourgian Convertible Franc",
    LUF: "Luxembourgian Franc",
    MOP: "Macanese Pataca",
    MKD: "Macedonian Denar",
    MKN: "Macedonian Denar (1992–1993)",
    MGA: "Malagasy Ariary",
    MGF: "Malagasy Franc",
    MWK: "Malawian Kwacha",
    MYR: "Malaysian Ringgit",
    MVR: "Maldivian Rufiyaa",
    MVP: "Maldivian Rupee (1947–1981)",
    MLF: "Malian Franc",
    MTL: "Maltese Lira",
    MTP: "Maltese Pound",
    MRO: "Mauritanian Ouguiya",
    MUR: "Mauritian Rupee",
    MXV: "Mexican Investment Unit",
    MXN: "Mexican Peso",
    MXP: "Mexican Silver Peso (1861–1992)",
    MDC: "Moldovan Cupon",
    MDL: "Moldovan Leu",
    MCF: "Monegasque Franc",
    MNT: "Mongolian Tugrik",
    MAD: "Moroccan Dirham",
    MAF: "Moroccan Franc",
    MZE: "Mozambican Escudo",
    MZN: "Mozambican Metical",
    MZM: "Mozambican Metical (1980–2006)",
    MMK: "Myanmar Kyat",
    NAD: "Namibian Dollar",
    NPR: "Nepalese Rupee",
    ANG: "Netherlands Antillean Guilder",
    TWD: "New Taiwan Dollar",
    NZD: "New Zealand Dollar",
    NIO: "Nicaraguan C\xf3rdoba",
    NIC: "Nicaraguan C\xf3rdoba (1988–1991)",
    NGN: "Nigerian Naira",
    KPW: "North Korean Won",
    NOK: "Norwegian Krone",
    OMR: "Omani Rial",
    PKR: "Pakistani Rupee",
    PAB: "Panamanian Balboa",
    PGK: "Papua New Guinean Kina",
    PYG: "Paraguayan Guarani",
    PEI: "Peruvian Inti",
    PEN: "Peruvian Sol",
    PES: "Peruvian Sol (1863–1965)",
    PHP: "Philippine Peso",
    PLN: "Polish Zloty",
    PLZ: "Polish Zloty (1950–1995)",
    PTE: "Portuguese Escudo",
    GWE: "Portuguese Guinea Escudo",
    QAR: "Qatari Rial",
    XRE: "RINET Funds",
    RHD: "Rhodesian Dollar",
    RON: "Romanian Leu",
    ROL: "Romanian Leu (1952–2006)",
    RUB: "Russian Ruble",
    RUR: "Russian Ruble (1991–1998)",
    RWF: "Rwandan Franc",
    SVC: "Salvadoran Col\xf3n",
    WST: "Samoan Tala",
    SAR: "Saudi Riyal",
    RSD: "Serbian Dinar",
    CSD: "Serbian Dinar (2002–2006)",
    SCR: "Seychellois Rupee",
    SLL: "Sierra Leonean Leone",
    SGD: "Singapore Dollar",
    SKK: "Slovak Koruna",
    SIT: "Slovenian Tolar",
    SBD: "Solomon Islands Dollar",
    SOS: "Somali Shilling",
    ZAR: "South African Rand",
    ZAL: "South African Rand (financial)",
    KRH: "South Korean Hwan (1953–1962)",
    KRW: "South Korean Won",
    KRO: "South Korean Won (1945–1953)",
    SSP: "South Sudanese Pound",
    SUR: "Soviet Rouble",
    ESP: "Spanish Peseta",
    ESA: "Spanish Peseta (A account)",
    ESB: "Spanish Peseta (convertible account)",
    LKR: "Sri Lankan Rupee",
    SHP: "St. Helena Pound",
    SDD: "Sudanese Dinar (1992–2007)",
    SDG: "Sudanese Pound",
    SDP: "Sudanese Pound (1957–1998)",
    SRD: "Surinamese Dollar",
    SRG: "Surinamese Guilder",
    SZL: "Swazi Lilangeni",
    SEK: "Swedish Krona",
    CHF: "Swiss Franc",
    SYP: "Syrian Pound",
    STD: "S\xe3o Tom\xe9 & Pr\xedncipe Dobra",
    TJR: "Tajikistani Ruble",
    TJS: "Tajikistani Somoni",
    TZS: "Tanzanian Shilling",
    THB: "Thai Baht",
    TPE: "Timorese Escudo",
    TOP: "Tongan Paʻanga",
    TTD: "Trinidad & Tobago Dollar",
    TND: "Tunisian Dinar",
    TRY: "Turkish Lira",
    TRL: "Turkish Lira (1922–2005)",
    TMT: "Turkmenistani Manat",
    TMM: "Turkmenistani Manat (1993–2009)",
    USD: "US Dollar",
    USN: "US Dollar (Next day)",
    USS: "US Dollar (Same day)",
    UGX: "Ugandan Shilling",
    UGS: "Ugandan Shilling (1966–1987)",
    UAH: "Ukrainian Hryvnia",
    UAK: "Ukrainian Karbovanets",
    AED: "United Arab Emirates Dirham",
    UYU: "Uruguayan Peso",
    UYP: "Uruguayan Peso (1975–1993)",
    UYI: "Uruguayan Peso (Indexed Units)",
    UZS: "Uzbekistani Som",
    VUV: "Vanuatu Vatu",
    VEF: "Venezuelan Bol\xedvar",
    VEB: "Venezuelan Bol\xedvar (1871–2008)",
    VND: "Vietnamese Dong",
    VNN: "Vietnamese Dong (1978–1985)",
    CHE: "WIR Euro",
    CHW: "WIR Franc",
    XOF: "West African CFA Franc",
    YDD: "Yemeni Dinar",
    YER: "Yemeni Rial",
    YUN: "Yugoslavian Convertible Dinar (1990–1992)",
    YUD: "Yugoslavian Hard Dinar (1966–1990)",
    YUM: "Yugoslavian New Dinar (1994–2002)",
    YUR: "Yugoslavian Reformed Dinar (1992–1993)",
    ZRN: "Zairean New Zaire (1993–1998)",
    ZRZ: "Zairean Zaire (1971–1993)",
    ZMW: "Zambian Kwacha",
    ZMK: "Zambian Kwacha (1968–2012)",
    ZWD: "Zimbabwean Dollar (1980–2008)",
    ZWR: "Zimbabwean Dollar (2008)",
    ZWL: "Zimbabwean Dollar (2009)"
};
var CurrenciesEnum;
(function(CurrenciesEnum) {
    CurrenciesEnum["AFN"] = "AFN";
    CurrenciesEnum["AFA"] = "AFA";
    CurrenciesEnum["ALL"] = "ALL";
    CurrenciesEnum["ALK"] = "ALK";
    CurrenciesEnum["DZD"] = "DZD";
    CurrenciesEnum["ADP"] = "ADP";
    CurrenciesEnum["AOA"] = "AOA";
    CurrenciesEnum["AOK"] = "AOK";
    CurrenciesEnum["AON"] = "AON";
    CurrenciesEnum["AOR"] = "AOR";
    CurrenciesEnum["ARA"] = "ARA";
    CurrenciesEnum["ARS"] = "ARS";
    CurrenciesEnum["ARM"] = "ARM";
    CurrenciesEnum["ARP"] = "ARP";
    CurrenciesEnum["ARL"] = "ARL";
    CurrenciesEnum["AMD"] = "AMD";
    CurrenciesEnum["AWG"] = "AWG";
    CurrenciesEnum["AUD"] = "AUD";
    CurrenciesEnum["ATS"] = "ATS";
    CurrenciesEnum["AZN"] = "AZN";
    CurrenciesEnum["AZM"] = "AZM";
    CurrenciesEnum["BSD"] = "BSD";
    CurrenciesEnum["BHD"] = "BHD";
    CurrenciesEnum["BDT"] = "BDT";
    CurrenciesEnum["BBD"] = "BBD";
    CurrenciesEnum["BYN"] = "BYN";
    CurrenciesEnum["BYB"] = "BYB";
    CurrenciesEnum["BYR"] = "BYR";
    CurrenciesEnum["BEF"] = "BEF";
    CurrenciesEnum["BEC"] = "BEC";
    CurrenciesEnum["BEL"] = "BEL";
    CurrenciesEnum["BZD"] = "BZD";
    CurrenciesEnum["BMD"] = "BMD";
    CurrenciesEnum["BTN"] = "BTN";
    CurrenciesEnum["BOB"] = "BOB";
    CurrenciesEnum["BOL"] = "BOL";
    CurrenciesEnum["BOV"] = "BOV";
    CurrenciesEnum["BOP"] = "BOP";
    CurrenciesEnum["BAM"] = "BAM";
    CurrenciesEnum["BAD"] = "BAD";
    CurrenciesEnum["BAN"] = "BAN";
    CurrenciesEnum["BWP"] = "BWP";
    CurrenciesEnum["BRC"] = "BRC";
    CurrenciesEnum["BRZ"] = "BRZ";
    CurrenciesEnum["BRE"] = "BRE";
    CurrenciesEnum["BRR"] = "BRR";
    CurrenciesEnum["BRN"] = "BRN";
    CurrenciesEnum["BRB"] = "BRB";
    CurrenciesEnum["BRL"] = "BRL";
    CurrenciesEnum["GBP"] = "GBP";
    CurrenciesEnum["BND"] = "BND";
    CurrenciesEnum["BGL"] = "BGL";
    CurrenciesEnum["BGN"] = "BGN";
    CurrenciesEnum["BGO"] = "BGO";
    CurrenciesEnum["BGM"] = "BGM";
    CurrenciesEnum["BUK"] = "BUK";
    CurrenciesEnum["BIF"] = "BIF";
    CurrenciesEnum["XPF"] = "XPF";
    CurrenciesEnum["KHR"] = "KHR";
    CurrenciesEnum["CAD"] = "CAD";
    CurrenciesEnum["CVE"] = "CVE";
    CurrenciesEnum["KYD"] = "KYD";
    CurrenciesEnum["XAF"] = "XAF";
    CurrenciesEnum["CLE"] = "CLE";
    CurrenciesEnum["CLP"] = "CLP";
    CurrenciesEnum["CLF"] = "CLF";
    CurrenciesEnum["CNX"] = "CNX";
    CurrenciesEnum["CNY"] = "CNY";
    CurrenciesEnum["COP"] = "COP";
    CurrenciesEnum["COU"] = "COU";
    CurrenciesEnum["KMF"] = "KMF";
    CurrenciesEnum["CDF"] = "CDF";
    CurrenciesEnum["CRC"] = "CRC";
    CurrenciesEnum["HRD"] = "HRD";
    CurrenciesEnum["HRK"] = "HRK";
    CurrenciesEnum["CUC"] = "CUC";
    CurrenciesEnum["CUP"] = "CUP";
    CurrenciesEnum["CYP"] = "CYP";
    CurrenciesEnum["CZK"] = "CZK";
    CurrenciesEnum["CSK"] = "CSK";
    CurrenciesEnum["DKK"] = "DKK";
    CurrenciesEnum["DJF"] = "DJF";
    CurrenciesEnum["DOP"] = "DOP";
    CurrenciesEnum["NLG"] = "NLG";
    CurrenciesEnum["XCD"] = "XCD";
    CurrenciesEnum["DDM"] = "DDM";
    CurrenciesEnum["ECS"] = "ECS";
    CurrenciesEnum["ECV"] = "ECV";
    CurrenciesEnum["EGP"] = "EGP";
    CurrenciesEnum["GQE"] = "GQE";
    CurrenciesEnum["ERN"] = "ERN";
    CurrenciesEnum["EEK"] = "EEK";
    CurrenciesEnum["ETB"] = "ETB";
    CurrenciesEnum["EUR"] = "EUR";
    CurrenciesEnum["XEU"] = "XEU";
    CurrenciesEnum["FKP"] = "FKP";
    CurrenciesEnum["FJD"] = "FJD";
    CurrenciesEnum["FIM"] = "FIM";
    CurrenciesEnum["FRF"] = "FRF";
    CurrenciesEnum["XFO"] = "XFO";
    CurrenciesEnum["XFU"] = "XFU";
    CurrenciesEnum["GMD"] = "GMD";
    CurrenciesEnum["GEK"] = "GEK";
    CurrenciesEnum["GEL"] = "GEL";
    CurrenciesEnum["DEM"] = "DEM";
    CurrenciesEnum["GHS"] = "GHS";
    CurrenciesEnum["GHC"] = "GHC";
    CurrenciesEnum["GIP"] = "GIP";
    CurrenciesEnum["GRD"] = "GRD";
    CurrenciesEnum["GTQ"] = "GTQ";
    CurrenciesEnum["GWP"] = "GWP";
    CurrenciesEnum["GNF"] = "GNF";
    CurrenciesEnum["GNS"] = "GNS";
    CurrenciesEnum["GYD"] = "GYD";
    CurrenciesEnum["HTG"] = "HTG";
    CurrenciesEnum["HNL"] = "HNL";
    CurrenciesEnum["HKD"] = "HKD";
    CurrenciesEnum["HUF"] = "HUF";
    CurrenciesEnum["ISK"] = "ISK";
    CurrenciesEnum["ISJ"] = "ISJ";
    CurrenciesEnum["INR"] = "INR";
    CurrenciesEnum["IDR"] = "IDR";
    CurrenciesEnum["IRR"] = "IRR";
    CurrenciesEnum["IQD"] = "IQD";
    CurrenciesEnum["IEP"] = "IEP";
    CurrenciesEnum["ILS"] = "ILS";
    CurrenciesEnum["ILP"] = "ILP";
    CurrenciesEnum["ILR"] = "ILR";
    CurrenciesEnum["ITL"] = "ITL";
    CurrenciesEnum["JMD"] = "JMD";
    CurrenciesEnum["JPY"] = "JPY";
    CurrenciesEnum["JOD"] = "JOD";
    CurrenciesEnum["KZT"] = "KZT";
    CurrenciesEnum["KES"] = "KES";
    CurrenciesEnum["KWD"] = "KWD";
    CurrenciesEnum["KGS"] = "KGS";
    CurrenciesEnum["LAK"] = "LAK";
    CurrenciesEnum["LVL"] = "LVL";
    CurrenciesEnum["LVR"] = "LVR";
    CurrenciesEnum["LBP"] = "LBP";
    CurrenciesEnum["LSL"] = "LSL";
    CurrenciesEnum["LRD"] = "LRD";
    CurrenciesEnum["LYD"] = "LYD";
    CurrenciesEnum["LTL"] = "LTL";
    CurrenciesEnum["LTT"] = "LTT";
    CurrenciesEnum["LUL"] = "LUL";
    CurrenciesEnum["LUC"] = "LUC";
    CurrenciesEnum["LUF"] = "LUF";
    CurrenciesEnum["MOP"] = "MOP";
    CurrenciesEnum["MKD"] = "MKD";
    CurrenciesEnum["MKN"] = "MKN";
    CurrenciesEnum["MGA"] = "MGA";
    CurrenciesEnum["MGF"] = "MGF";
    CurrenciesEnum["MWK"] = "MWK";
    CurrenciesEnum["MYR"] = "MYR";
    CurrenciesEnum["MVR"] = "MVR";
    CurrenciesEnum["MVP"] = "MVP";
    CurrenciesEnum["MLF"] = "MLF";
    CurrenciesEnum["MTL"] = "MTL";
    CurrenciesEnum["MTP"] = "MTP";
    CurrenciesEnum["MRO"] = "MRO";
    CurrenciesEnum["MUR"] = "MUR";
    CurrenciesEnum["MXV"] = "MXV";
    CurrenciesEnum["MXN"] = "MXN";
    CurrenciesEnum["MXP"] = "MXP";
    CurrenciesEnum["MDC"] = "MDC";
    CurrenciesEnum["MDL"] = "MDL";
    CurrenciesEnum["MCF"] = "MCF";
    CurrenciesEnum["MNT"] = "MNT";
    CurrenciesEnum["MAD"] = "MAD";
    CurrenciesEnum["MAF"] = "MAF";
    CurrenciesEnum["MZE"] = "MZE";
    CurrenciesEnum["MZN"] = "MZN";
    CurrenciesEnum["MZM"] = "MZM";
    CurrenciesEnum["MMK"] = "MMK";
    CurrenciesEnum["NAD"] = "NAD";
    CurrenciesEnum["NPR"] = "NPR";
    CurrenciesEnum["ANG"] = "ANG";
    CurrenciesEnum["TWD"] = "TWD";
    CurrenciesEnum["NZD"] = "NZD";
    CurrenciesEnum["NIO"] = "NIO";
    CurrenciesEnum["NIC"] = "NIC";
    CurrenciesEnum["NGN"] = "NGN";
    CurrenciesEnum["KPW"] = "KPW";
    CurrenciesEnum["NOK"] = "NOK";
    CurrenciesEnum["OMR"] = "OMR";
    CurrenciesEnum["PKR"] = "PKR";
    CurrenciesEnum["PAB"] = "PAB";
    CurrenciesEnum["PGK"] = "PGK";
    CurrenciesEnum["PYG"] = "PYG";
    CurrenciesEnum["PEI"] = "PEI";
    CurrenciesEnum["PEN"] = "PEN";
    CurrenciesEnum["PES"] = "PES";
    CurrenciesEnum["PHP"] = "PHP";
    CurrenciesEnum["PLN"] = "PLN";
    CurrenciesEnum["PLZ"] = "PLZ";
    CurrenciesEnum["PTE"] = "PTE";
    CurrenciesEnum["GWE"] = "GWE";
    CurrenciesEnum["QAR"] = "QAR";
    CurrenciesEnum["XRE"] = "XRE";
    CurrenciesEnum["RHD"] = "RHD";
    CurrenciesEnum["RON"] = "RON";
    CurrenciesEnum["ROL"] = "ROL";
    CurrenciesEnum["RUB"] = "RUB";
    CurrenciesEnum["RUR"] = "RUR";
    CurrenciesEnum["RWF"] = "RWF";
    CurrenciesEnum["SVC"] = "SVC";
    CurrenciesEnum["WST"] = "WST";
    CurrenciesEnum["SAR"] = "SAR";
    CurrenciesEnum["RSD"] = "RSD";
    CurrenciesEnum["CSD"] = "CSD";
    CurrenciesEnum["SCR"] = "SCR";
    CurrenciesEnum["SLL"] = "SLL";
    CurrenciesEnum["SGD"] = "SGD";
    CurrenciesEnum["SKK"] = "SKK";
    CurrenciesEnum["SIT"] = "SIT";
    CurrenciesEnum["SBD"] = "SBD";
    CurrenciesEnum["SOS"] = "SOS";
    CurrenciesEnum["ZAR"] = "ZAR";
    CurrenciesEnum["ZAL"] = "ZAL";
    CurrenciesEnum["KRH"] = "KRH";
    CurrenciesEnum["KRW"] = "KRW";
    CurrenciesEnum["KRO"] = "KRO";
    CurrenciesEnum["SSP"] = "SSP";
    CurrenciesEnum["SUR"] = "SUR";
    CurrenciesEnum["ESP"] = "ESP";
    CurrenciesEnum["ESA"] = "ESA";
    CurrenciesEnum["ESB"] = "ESB";
    CurrenciesEnum["LKR"] = "LKR";
    CurrenciesEnum["SHP"] = "SHP";
    CurrenciesEnum["SDD"] = "SDD";
    CurrenciesEnum["SDG"] = "SDG";
    CurrenciesEnum["SDP"] = "SDP";
    CurrenciesEnum["SRD"] = "SRD";
    CurrenciesEnum["SRG"] = "SRG";
    CurrenciesEnum["SZL"] = "SZL";
    CurrenciesEnum["SEK"] = "SEK";
    CurrenciesEnum["CHF"] = "CHF";
    CurrenciesEnum["SYP"] = "SYP";
    CurrenciesEnum["STD"] = "STD";
    CurrenciesEnum["TJR"] = "TJR";
    CurrenciesEnum["TJS"] = "TJS";
    CurrenciesEnum["TZS"] = "TZS";
    CurrenciesEnum["THB"] = "THB";
    CurrenciesEnum["TPE"] = "TPE";
    CurrenciesEnum["TOP"] = "TOP";
    CurrenciesEnum["TTD"] = "TTD";
    CurrenciesEnum["TND"] = "TND";
    CurrenciesEnum["TRY"] = "TRY";
    CurrenciesEnum["TRL"] = "TRL";
    CurrenciesEnum["TMT"] = "TMT";
    CurrenciesEnum["TMM"] = "TMM";
    CurrenciesEnum["USD"] = "USD";
    CurrenciesEnum["USN"] = "USN";
    CurrenciesEnum["USS"] = "USS";
    CurrenciesEnum["UGX"] = "UGX";
    CurrenciesEnum["UGS"] = "UGS";
    CurrenciesEnum["UAH"] = "UAH";
    CurrenciesEnum["UAK"] = "UAK";
    CurrenciesEnum["AED"] = "AED";
    CurrenciesEnum["UYU"] = "UYU";
    CurrenciesEnum["UYP"] = "UYP";
    CurrenciesEnum["UYI"] = "UYI";
    CurrenciesEnum["UZS"] = "UZS";
    CurrenciesEnum["VUV"] = "VUV";
    CurrenciesEnum["VEF"] = "VEF";
    CurrenciesEnum["VEB"] = "VEB";
    CurrenciesEnum["VND"] = "VND";
    CurrenciesEnum["VNN"] = "VNN";
    CurrenciesEnum["CHE"] = "CHE";
    CurrenciesEnum["CHW"] = "CHW";
    CurrenciesEnum["XOF"] = "XOF";
    CurrenciesEnum["YDD"] = "YDD";
    CurrenciesEnum["YER"] = "YER";
    CurrenciesEnum["YUN"] = "YUN";
    CurrenciesEnum["YUD"] = "YUD";
    CurrenciesEnum["YUM"] = "YUM";
    CurrenciesEnum["YUR"] = "YUR";
    CurrenciesEnum["ZRN"] = "ZRN";
    CurrenciesEnum["ZRZ"] = "ZRZ";
    CurrenciesEnum["ZMW"] = "ZMW";
    CurrenciesEnum["ZMK"] = "ZMK";
    CurrenciesEnum["ZWD"] = "ZWD";
    CurrenciesEnum["ZWR"] = "ZWR";
    CurrenciesEnum["ZWL"] = "ZWL";
})(CurrenciesEnum || (CurrenciesEnum = {}));

var EmailTemplateNameEnum;
(function(EmailTemplateNameEnum) {
    EmailTemplateNameEnum["PASSWORD_RESET"] = "password";
    EmailTemplateNameEnum["WELCOME_USER"] = "welcome-user";
    EmailTemplateNameEnum["INVITE_USER"] = "invite-user";
    EmailTemplateNameEnum["EMAIL_VERIFICATION"] = "email-verification";
})(EmailTemplateNameEnum || (EmailTemplateNameEnum = {}));
var EmailTemplateEnum;
(function(EmailTemplateEnum) {
    EmailTemplateEnum["PASSWORD_RESET"] = "password";
    EmailTemplateEnum["MULTI_TENANT_PASSWORD_RESET"] = "multi-tenant-password";
    EmailTemplateEnum["PASSWORD_LESS_AUTHENTICATION"] = "password-less-authentication";
    EmailTemplateEnum["WELCOME_USER"] = "welcome-user";
    EmailTemplateEnum["EMAIL_VERIFICATION"] = "email-verification";
    EmailTemplateEnum["INVITE_USER"] = "invite-user";
})(EmailTemplateEnum || (EmailTemplateEnum = {}));

var DEFAULT_TYPE;
(function(DEFAULT_TYPE) {
    DEFAULT_TYPE["ALL_EMPLOYEE"] = "ALL_EMPLOYEE";
    DEFAULT_TYPE["NO_EMPLOYEE"] = "NO_EMPLOYEE";
})(DEFAULT_TYPE || (DEFAULT_TYPE = {}));
var PayPeriodEnum;
(function(PayPeriodEnum) {
    PayPeriodEnum["NONE"] = "NONE";
    PayPeriodEnum["BI_WEEKLY"] = "BI_WEEKLY";
    PayPeriodEnum["WEEKLY"] = "WEEKLY";
    PayPeriodEnum["TWICE_PER_MONTH"] = "TWICE_PER_MONTH";
    PayPeriodEnum["MONTHLY"] = "MONTHLY";
})(PayPeriodEnum || (PayPeriodEnum = {}));

var FeatureStatusEnum;
(function(FeatureStatusEnum) {
    FeatureStatusEnum["INFO"] = "info";
    FeatureStatusEnum["PRIMARY"] = "primary";
    FeatureStatusEnum["SUCCESS"] = "success";
    FeatureStatusEnum["WARNING"] = "warning";
})(FeatureStatusEnum || (FeatureStatusEnum = {}));
var IFeatureToggleTypeEnum;
(function(IFeatureToggleTypeEnum) {
    IFeatureToggleTypeEnum["RELEASE"] = "release";
    IFeatureToggleTypeEnum["KILL_SWITCH"] = "kill-switch";
    IFeatureToggleTypeEnum["EXPERIMENT"] = "experiment";
    IFeatureToggleTypeEnum["OPERATIONAL"] = "operational";
    IFeatureToggleTypeEnum["PERMISSION"] = "permission";
})(IFeatureToggleTypeEnum || (IFeatureToggleTypeEnum = {}));
var FeatureEnum;
(function(FeatureEnum) {
    FeatureEnum["FEATURE_HOME"] = "FEATURE_HOME";
    FeatureEnum["FEATURE_DASHBOARD"] = "FEATURE_DASHBOARD";
    FeatureEnum["FEATURE_JOB"] = "FEATURE_JOB";
    FeatureEnum["FEATURE_EMPLOYEES"] = "FEATURE_EMPLOYEES";
    FeatureEnum["FEATURE_MANAGE_INVITE"] = "FEATURE_MANAGE_INVITE";
    FeatureEnum["FEATURE_ORGANIZATION"] = "FEATURE_ORGANIZATION";
    FeatureEnum["FEATURE_ORGANIZATION_TAG"] = "FEATURE_ORGANIZATION_TAG";
    FeatureEnum["FEATURE_ORGANIZATION_PROJECT"] = "FEATURE_ORGANIZATION_PROJECT";
    FeatureEnum["FEATURE_CONTACT"] = "FEATURE_CONTACT";
    FeatureEnum["FEATURE_USER"] = "FEATURE_USER";
    FeatureEnum["FEATURE_USERS"] = "FEATURE_USERS";
    FeatureEnum["FEATURE_USER_GROUPS"] = "FEATURE_USER_GROUPS";
    FeatureEnum["FEATURE_REFERRAL"] = "FEATURE_REFERRAL";
    FeatureEnum["FEATURE_ORGANIZATIONS"] = "FEATURE_ORGANIZATIONS";
    // FEATURE_APP_INTEGRATION = 'FEATURE_APP_INTEGRATION',
    FeatureEnum["FEATURE_SETTING"] = "FEATURE_SETTING";
    FeatureEnum["FEATURE_EMAIL_HISTORY"] = "FEATURE_EMAIL_HISTORY";
    FeatureEnum["FEATURE_EMAIL_TEMPLATE"] = "FEATURE_EMAIL_TEMPLATE";
    FeatureEnum["FEATURE_FILE_STORAGE"] = "FEATURE_FILE_STORAGE";
    FeatureEnum["FEATURE_SMS_GATEWAY"] = "FEATURE_SMS_GATEWAY";
    FeatureEnum["FEATURE_SMTP"] = "FEATURE_SMTP";
    FeatureEnum["FEATURE_ROLES_PERMISSION"] = "FEATURE_ROLES_PERMISSION";
    FeatureEnum["FEATURE_INTEGRATION"] = "FEATURE_INTEGRATION";
    FeatureEnum["FEATURE_DATA_SOURCE"] = "FEATURE_DATA_SOURCE";
})(FeatureEnum || (FeatureEnum = {}));

var FileStorageProviderEnum;
(function(FileStorageProviderEnum) {
    FileStorageProviderEnum["LOCAL"] = "LOCAL";
})(FileStorageProviderEnum || (FileStorageProviderEnum = {}));

var HttpStatus;
(function(HttpStatus) {
    HttpStatus[HttpStatus["CONTINUE"] = 100] = "CONTINUE";
    HttpStatus[HttpStatus["SWITCHING_PROTOCOLS"] = 101] = "SWITCHING_PROTOCOLS";
    HttpStatus[HttpStatus["PROCESSING"] = 102] = "PROCESSING";
    HttpStatus[HttpStatus["OK"] = 200] = "OK";
    HttpStatus[HttpStatus["CREATED"] = 201] = "CREATED";
    HttpStatus[HttpStatus["ACCEPTED"] = 202] = "ACCEPTED";
    HttpStatus[HttpStatus["NON_AUTHORITATIVE_INFORMATION"] = 203] = "NON_AUTHORITATIVE_INFORMATION";
    HttpStatus[HttpStatus["NO_CONTENT"] = 204] = "NO_CONTENT";
    HttpStatus[HttpStatus["RESET_CONTENT"] = 205] = "RESET_CONTENT";
    HttpStatus[HttpStatus["PARTIAL_CONTENT"] = 206] = "PARTIAL_CONTENT";
    HttpStatus[HttpStatus["AMBIGUOUS"] = 300] = "AMBIGUOUS";
    HttpStatus[HttpStatus["MOVED_PERMANENTLY"] = 301] = "MOVED_PERMANENTLY";
    HttpStatus[HttpStatus["FOUND"] = 302] = "FOUND";
    HttpStatus[HttpStatus["SEE_OTHER"] = 303] = "SEE_OTHER";
    HttpStatus[HttpStatus["NOT_MODIFIED"] = 304] = "NOT_MODIFIED";
    HttpStatus[HttpStatus["TEMPORARY_REDIRECT"] = 307] = "TEMPORARY_REDIRECT";
    HttpStatus[HttpStatus["PERMANENT_REDIRECT"] = 308] = "PERMANENT_REDIRECT";
    HttpStatus[HttpStatus["BAD_REQUEST"] = 400] = "BAD_REQUEST";
    HttpStatus[HttpStatus["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
    HttpStatus[HttpStatus["PAYMENT_REQUIRED"] = 402] = "PAYMENT_REQUIRED";
    HttpStatus[HttpStatus["FORBIDDEN"] = 403] = "FORBIDDEN";
    HttpStatus[HttpStatus["NOT_FOUND"] = 404] = "NOT_FOUND";
    HttpStatus[HttpStatus["METHOD_NOT_ALLOWED"] = 405] = "METHOD_NOT_ALLOWED";
    HttpStatus[HttpStatus["NOT_ACCEPTABLE"] = 406] = "NOT_ACCEPTABLE";
    HttpStatus[HttpStatus["PROXY_AUTHENTICATION_REQUIRED"] = 407] = "PROXY_AUTHENTICATION_REQUIRED";
    HttpStatus[HttpStatus["REQUEST_TIMEOUT"] = 408] = "REQUEST_TIMEOUT";
    HttpStatus[HttpStatus["CONFLICT"] = 409] = "CONFLICT";
    HttpStatus[HttpStatus["GONE"] = 410] = "GONE";
    HttpStatus[HttpStatus["LENGTH_REQUIRED"] = 411] = "LENGTH_REQUIRED";
    HttpStatus[HttpStatus["PRECONDITION_FAILED"] = 412] = "PRECONDITION_FAILED";
    HttpStatus[HttpStatus["PAYLOAD_TOO_LARGE"] = 413] = "PAYLOAD_TOO_LARGE";
    HttpStatus[HttpStatus["URI_TOO_LONG"] = 414] = "URI_TOO_LONG";
    HttpStatus[HttpStatus["UNSUPPORTED_MEDIA_TYPE"] = 415] = "UNSUPPORTED_MEDIA_TYPE";
    HttpStatus[HttpStatus["REQUESTED_RANGE_NOT_SATISFIABLE"] = 416] = "REQUESTED_RANGE_NOT_SATISFIABLE";
    HttpStatus[HttpStatus["EXPECTATION_FAILED"] = 417] = "EXPECTATION_FAILED";
    HttpStatus[HttpStatus["I_AM_A_TEAPOT"] = 418] = "I_AM_A_TEAPOT";
    HttpStatus[HttpStatus["UNPROCESSABLE_ENTITY"] = 422] = "UNPROCESSABLE_ENTITY";
    HttpStatus[HttpStatus["FAILED_DEPENDENCY"] = 424] = "FAILED_DEPENDENCY";
    HttpStatus[HttpStatus["TOO_MANY_REQUESTS"] = 429] = "TOO_MANY_REQUESTS";
    HttpStatus[HttpStatus["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
    HttpStatus[HttpStatus["NOT_IMPLEMENTED"] = 501] = "NOT_IMPLEMENTED";
    HttpStatus[HttpStatus["BAD_GATEWAY"] = 502] = "BAD_GATEWAY";
    HttpStatus[HttpStatus["SERVICE_UNAVAILABLE"] = 503] = "SERVICE_UNAVAILABLE";
    HttpStatus[HttpStatus["GATEWAY_TIMEOUT"] = 504] = "GATEWAY_TIMEOUT";
    HttpStatus[HttpStatus["HTTP_VERSION_NOT_SUPPORTED"] = 505] = "HTTP_VERSION_NOT_SUPPORTED";
})(HttpStatus || (HttpStatus = {}));
var RequestMethodEnum;
(function(RequestMethodEnum) {
    RequestMethodEnum["GET"] = "GET";
    RequestMethodEnum["POST"] = "POST";
    RequestMethodEnum["PUT"] = "PUT";
    RequestMethodEnum["DELETE"] = "DELETE";
    RequestMethodEnum["PATCH"] = "PATCH";
    RequestMethodEnum["ALL"] = "ALL";
    RequestMethodEnum["OPTIONS"] = "OPTIONS";
    RequestMethodEnum["HEAD"] = "HEAD";
})(RequestMethodEnum || (RequestMethodEnum = {}));

var ImportTypeEnum;
(function(ImportTypeEnum) {
    ImportTypeEnum["MERGE"] = "merge";
    ImportTypeEnum["CLEAN"] = "clean";
})(ImportTypeEnum || (ImportTypeEnum = {}));
var ImportHistoryStatusEnum;
(function(ImportHistoryStatusEnum) {
    ImportHistoryStatusEnum["SUCCESS"] = "Success";
    ImportHistoryStatusEnum["FAILED"] = "Failed";
    ImportHistoryStatusEnum["CANCELLED"] = "Cancelled";
})(ImportHistoryStatusEnum || (ImportHistoryStatusEnum = {}));

var OrganizationContactBudgetTypeEnum;
(function(OrganizationContactBudgetTypeEnum) {
    OrganizationContactBudgetTypeEnum["HOURS"] = "hours";
    OrganizationContactBudgetTypeEnum["COST"] = "cost";
})(OrganizationContactBudgetTypeEnum || (OrganizationContactBudgetTypeEnum = {}));
var ContactOrganizationInviteStatus;
(function(ContactOrganizationInviteStatus) {
    ContactOrganizationInviteStatus["NOT_INVITED"] = "NOT_INVITED";
    ContactOrganizationInviteStatus["INVITED"] = "INVITED";
    ContactOrganizationInviteStatus["ACCEPTED"] = "ACCEPTED";
})(ContactOrganizationInviteStatus || (ContactOrganizationInviteStatus = {}));
var ContactType;
(function(ContactType) {
    ContactType["CLIENT"] = "CLIENT";
    ContactType["CUSTOMER"] = "CUSTOMER";
    ContactType["LEAD"] = "LEAD";
})(ContactType || (ContactType = {}));

var OrganizationPermissionsEnum;
(function(OrganizationPermissionsEnum) {
    OrganizationPermissionsEnum["ALLOW_MANUAL_TIME"] = "allowManualTime";
    OrganizationPermissionsEnum["ALLOW_MODIFY_TIME"] = "allowModifyTime";
    OrganizationPermissionsEnum["ALLOW_DELETE_TIME"] = "allowDeleteTime";
    OrganizationPermissionsEnum["ALLOW_FUTURE_DATE"] = "futureDateAllowed";
})(OrganizationPermissionsEnum || (OrganizationPermissionsEnum = {}));
var ListsInputTypeEnum;
(function(ListsInputTypeEnum) {
    ListsInputTypeEnum["DEPARTMENTS"] = "DEPARTMENTS";
    ListsInputTypeEnum["POSITIONS"] = "POSITIONS";
    ListsInputTypeEnum["VENDORS"] = "VENDORS";
})(ListsInputTypeEnum || (ListsInputTypeEnum = {}));
var OrganizationSelectInput;
(function(OrganizationSelectInput) {
    OrganizationSelectInput["id"] = "id";
    OrganizationSelectInput["name"] = "name";
    OrganizationSelectInput["profile_link"] = "profile_link";
    OrganizationSelectInput["valueDate"] = "valueDate";
    OrganizationSelectInput["imageUrl"] = "imageUrl";
    OrganizationSelectInput["currency"] = "currency";
    OrganizationSelectInput["createdAt"] = "createdAt";
    OrganizationSelectInput["updatedAt"] = "updatedAt";
    OrganizationSelectInput["isActive"] = "isActive";
    OrganizationSelectInput["sidebarExpandedByDefault"] = "sidebarExpandedByDefault";
    OrganizationSelectInput["tags"] = "tags";
})(OrganizationSelectInput || (OrganizationSelectInput = {}));
var RegionsEnum;
(function(RegionsEnum) {
    RegionsEnum["EN"] = "English (United States)";
    RegionsEnum["BG"] = "Bulgarian (Bulgaria)";
    RegionsEnum["HE"] = "Hebrew (Israel)";
    RegionsEnum["RU"] = "Rusian (Russia)";
})(RegionsEnum || (RegionsEnum = {}));
var DefaultValueDateTypeEnum;
(function(DefaultValueDateTypeEnum) {
    DefaultValueDateTypeEnum["TODAY"] = "TODAY";
    DefaultValueDateTypeEnum["END_OF_MONTH"] = "END_OF_MONTH";
    DefaultValueDateTypeEnum["START_OF_MONTH"] = "START_OF_MONTH";
})(DefaultValueDateTypeEnum || (DefaultValueDateTypeEnum = {}));
var ProjectBillingEnum;
(function(ProjectBillingEnum) {
    ProjectBillingEnum["RATE"] = "RATE";
    ProjectBillingEnum["FLAT_FEE"] = "FLAT_FEE";
    ProjectBillingEnum["MILESTONES"] = "MILESTONES";
})(ProjectBillingEnum || (ProjectBillingEnum = {}));
var AlignmentOptions;
(function(AlignmentOptions) {
    AlignmentOptions["LEFT"] = "LEFT";
    AlignmentOptions["RIGHT"] = "RIGHT";
    AlignmentOptions["CENTER"] = "CENTER";
})(AlignmentOptions || (AlignmentOptions = {}));
var CurrencyPosition;
(function(CurrencyPosition) {
    CurrencyPosition["LEFT"] = "LEFT";
    CurrencyPosition["RIGHT"] = "RIGHT";
})(CurrencyPosition || (CurrencyPosition = {}));
var WeekDaysEnum;
(function(WeekDaysEnum) {
    WeekDaysEnum["MONDAY"] = "MONDAY";
    WeekDaysEnum["TUESDAY"] = "TUESDAY";
    WeekDaysEnum["WEDNESDAY"] = "WEDNESDAY";
    WeekDaysEnum["THURSDAY"] = "THURSDAY";
    WeekDaysEnum["FRIDAY"] = "FRIDAY";
    WeekDaysEnum["SATURDAY"] = "SATURDAY";
    WeekDaysEnum["SUNDAY"] = "SUNDAY";
})(WeekDaysEnum || (WeekDaysEnum = {}));
var BonusTypeEnum;
(function(BonusTypeEnum) {
    BonusTypeEnum["PROFIT_BASED_BONUS"] = "PROFIT_BASED_BONUS";
    BonusTypeEnum["REVENUE_BASED_BONUS"] = "REVENUE_BASED_BONUS";
})(BonusTypeEnum || (BonusTypeEnum = {}));
var ClientFocusEnum;
(function(ClientFocusEnum) {
    ClientFocusEnum["VERY_SMALL_BUSINESSES"] = "Very Small Businesses";
    ClientFocusEnum["SMALL_BUSINESSES"] = "Small Businesses";
    ClientFocusEnum["MEDIUM_BUSINESSES"] = "Medium Businesses";
    ClientFocusEnum["LARGE_BUSINESSES"] = "Large Businesses";
})(ClientFocusEnum || (ClientFocusEnum = {}));
var ProjectOwnerEnum;
(function(ProjectOwnerEnum) {
    ProjectOwnerEnum["CLIENT"] = "CLIENT";
    ProjectOwnerEnum["INTERNAL"] = "INTERNAL";
})(ProjectOwnerEnum || (ProjectOwnerEnum = {}));
var MinimumProjectSizeEnum;
(function(MinimumProjectSizeEnum) {
    MinimumProjectSizeEnum["ONE_THOUSAND"] = "1000+";
    MinimumProjectSizeEnum["FIVE_THOUSAND"] = "5000+";
    MinimumProjectSizeEnum["TEN_THOUSAND"] = "10000+";
    MinimumProjectSizeEnum["TWENTY_FIVE_THOUSAND"] = "25000+";
    MinimumProjectSizeEnum["FIFTY_THOUSAND"] = "50000+";
    MinimumProjectSizeEnum["ONE_HUNDRED_THOUSAND"] = "100000+";
})(MinimumProjectSizeEnum || (MinimumProjectSizeEnum = {}));
var DEFAULT_PROFIT_BASED_BONUS = 75;
var DEFAULT_REVENUE_BASED_BONUS = 10;
var DEFAULT_INVITE_EXPIRY_PERIOD = 7;
var CrudActionEnum;
(function(CrudActionEnum) {
    CrudActionEnum["CREATED"] = "CREATED";
    CrudActionEnum["UPDATED"] = "UPDATED";
    CrudActionEnum["DELETED"] = "DELETED";
})(CrudActionEnum || (CrudActionEnum = {}));
var DEFAULT_DATE_FORMATS = [
    "L",
    "LL",
    "dddd, LL"
];
var DEFAULT_TIME_FORMATS = [
    12,
    24
];
var OrganizationDemoNetworkEnum;
(function(OrganizationDemoNetworkEnum) {
    OrganizationDemoNetworkEnum["github"] = "github";
    OrganizationDemoNetworkEnum["aliyun"] = "aliyun";
})(OrganizationDemoNetworkEnum || (OrganizationDemoNetworkEnum = {}));

/** Explicit Artifact source identity for platform-owned conversation snapshots. */ var CONVERSATION_SHARE_ARTIFACT_SOURCE = {
    pluginName: "@xpert-ai/platform",
    resourceType: "conversation_snapshot"
};

function _define_property$s(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$s(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$s(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$l(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$l(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$l(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _type_of$1(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function isObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isStringList(value) {
    return Array.isArray(value) && value.every(function(item) {
        return typeof item === "string";
    });
}
function parseSelectionSet(value) {
    if (!isObject(value)) return null;
    var skills = "skills" in value ? value.skills : undefined;
    var plugins = "plugins" in value ? value.plugins : undefined;
    var subAgents = "subAgents" in value ? value.subAgents : undefined;
    var connectors = "connectors" in value ? value.connectors : undefined;
    if (skills !== undefined && (!isObject(skills) || !("ids" in skills) || !isStringList(skills.ids) || "workspaceId" in skills && skills.workspaceId !== undefined && typeof skills.workspaceId !== "string")) return null;
    if (plugins !== undefined && (!isObject(plugins) || !("nodeKeys" in plugins) || !isStringList(plugins.nodeKeys))) return null;
    if (subAgents !== undefined && (!isObject(subAgents) || !("nodeKeys" in subAgents) || !isStringList(subAgents.nodeKeys))) return null;
    if (connectors !== undefined && (!isObject(connectors) || !("bindingIds" in connectors) || !isStringList(connectors.bindingIds))) return null;
    return _object_spread$s(_object_spread_props$l(_object_spread$s({}, value), {
        skills: skills === undefined ? {
            ids: []
        } : skills,
        plugins: plugins === undefined ? {
            nodeKeys: []
        } : plugins
    }), subAgents === undefined ? {} : {
        subAgents: subAgents
    }, connectors === undefined ? {} : {
        connectors: connectors
    });
}
function parsePromptCapabilitySelection(value) {
    if (!isObject(value) || !("mode" in value) || value.mode !== "allowlist") return null;
    if ("inheritUnselected" in value && value.inheritUnselected !== undefined && typeof value.inheritUnselected !== "boolean") return null;
    var selection = parseSelectionSet(value);
    var recommended = "recommended" in value && value.recommended != null ? parseSelectionSet(value.recommended) : undefined;
    if (!selection || recommended === null) return null;
    return _object_spread$s(_object_spread_props$l(_object_spread$s({}, selection), {
        mode: "allowlist"
    }), "inheritUnselected" in value && typeof value.inheritUnselected === "boolean" ? {
        inheritUnselected: value.inheritUnselected
    } : {}, recommended ? {
        recommended: recommended
    } : {});
}
function isScopedPromptCapabilityConfig(value) {
    return isObject(value) && "type" in value && value.type === "expert_scoped_capabilities";
}
function parsePromptCapabilityConfig(value) {
    if (!isObject(value) || !("type" in value) || value.type !== "expert_scoped_capabilities" || !("version" in value) || value.version !== 1 || !("experts" in value) || !Array.isArray(value.experts)) return null;
    var defaults = "defaults" in value && value.defaults != null ? parsePromptCapabilitySelection(value.defaults) : null;
    if ("defaults" in value && value.defaults != null && !defaults) return null;
    var experts = [];
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        var _loop = function() {
            var entry = _step.value;
            if (!isObject(entry) || !("xpertId" in entry) || typeof entry.xpertId !== "string" || !entry.xpertId.trim() || !("selection" in entry) || experts.some(function(item) {
                return item.xpertId === entry.xpertId;
            })) return {
                v: null
            };
            var selection = entry.selection === null ? null : parsePromptCapabilitySelection(entry.selection);
            if (entry.selection !== null && !selection) return {
                v: null
            };
            experts.push({
                xpertId: entry.xpertId,
                selection: selection
            });
        };
        for(var _iterator = value.experts[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var _ret = _loop();
            if (_type_of$1(_ret) === "object") return _ret.v;
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return _object_spread_props$l(_object_spread$s({}, value), {
        type: "expert_scoped_capabilities",
        version: 1,
        defaults: defaults,
        experts: experts
    });
}
function resolvePromptWorkflowCapabilities(value, xpertId) {
    if (!isScopedPromptCapabilityConfig(value)) return value;
    var config = parsePromptCapabilityConfig(value);
    if (!config) return null;
    var entry = config.experts.find(function(item) {
        return item.xpertId === xpertId;
    });
    return entry ? entry.selection : config.defaults;
}

/**
 * Business roles for AI copilot (commands or contexts)
 */ var AiBusinessRole;
(function(AiBusinessRole) {
    AiBusinessRole["FinanceBP"] = "finance_bp";
    AiBusinessRole["SupplyChainExpert"] = "supply_chain_expert";
})(AiBusinessRole || (AiBusinessRole = {}));
/**
 * Providers for LLMs
 *
 * - https://js.langchain.com/docs/integrations/chat/
 */ var AiProvider;
(function(AiProvider) {
    /**
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["OpenAI"] = "openai";
    /**
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["Azure"] = "azure";
    // DashScope = 'dashscope',
    /**
     * - https://ollama.com/
     * - https://js.langchain.com/docs/integrations/chat/ollama/
     */ AiProvider["Ollama"] = "ollama";
    /**
     * - https://www.deepseek.com/zh
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["DeepSeek"] = "deepseek";
    /**
     * - https://docs.anthropic.com/en/home
     * - https://js.langchain.com/docs/integrations/chat/anthropic/
     */ AiProvider["Anthropic"] = "anthropic";
    /**
     * - https://www.aliyun.com/product/bailian
     * - https://js.langchain.com/docs/integrations/chat/alibaba_tongyi/
     */ AiProvider["AlibabaTongyi"] = "alibaba_tongyi";
    /**
     * - https://open.bigmodel.cn/
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["Zhipu"] = "zhipu";
    /**
     * - https://qianfan.cloud.baidu.com/
     * - https://js.langchain.com/docs/integrations/chat/baidu_qianfan/
     */ AiProvider["BaiduQianfan"] = "baidu_qianfan";
    /**
     * - https://www.together.ai/
     * - https://js.langchain.com/docs/integrations/chat/togetherai/
     */ AiProvider["Together"] = "together";
    /**
     * - https://platform.moonshot.cn/console
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["Moonshot"] = "moonshot";
    /**
     * - https://groq.com/
     * - https://js.langchain.com/docs/integrations/chat/openai/
     */ AiProvider["Groq"] = "groq";
    /**
     * - https://mistral.ai/
     *
     */ AiProvider["Mistral"] = "mistral";
    /**
     * - https://cohere.com/
     */ AiProvider["Cohere"] = "cohere";
})(AiProvider || (AiProvider = {}));
var AiProtocol;
(function(AiProtocol) {
    AiProtocol["OpenAI"] = "openai";
    AiProtocol["Others"] = "others";
})(AiProtocol || (AiProtocol = {}));
var OpenAIEmbeddingsProviders = [
    AiProvider.OpenAI,
    AiProvider.Azure,
    AiProvider.DeepSeek
];
var OllamaEmbeddingsProviders = [
    AiProvider.Ollama
];
var ChatMessageTypeEnum;
(function(ChatMessageTypeEnum) {
    ChatMessageTypeEnum["MESSAGE"] = "message";
    ChatMessageTypeEnum["EVENT"] = "event";
})(ChatMessageTypeEnum || (ChatMessageTypeEnum = {}));
var ChatMessageEventTypeEnum;
(function(ChatMessageEventTypeEnum) {
    ChatMessageEventTypeEnum["ON_CONVERSATION_START"] = "on_conversation_start";
    ChatMessageEventTypeEnum["ON_CONVERSATION_END"] = "on_conversation_end";
    ChatMessageEventTypeEnum["ON_MESSAGE_START"] = "on_message_start";
    ChatMessageEventTypeEnum["ON_MESSAGE_END"] = "on_message_end";
    ChatMessageEventTypeEnum["ON_TOOL_START"] = "on_tool_start";
    ChatMessageEventTypeEnum["ON_TOOL_END"] = "on_tool_end";
    ChatMessageEventTypeEnum["ON_TOOL_ERROR"] = "on_tool_error";
    ChatMessageEventTypeEnum["ON_TOOL_MESSAGE"] = "on_tool_message";
    ChatMessageEventTypeEnum["ON_AGENT_START"] = "on_agent_start";
    ChatMessageEventTypeEnum["ON_AGENT_END"] = "on_agent_end";
    ChatMessageEventTypeEnum["ON_RETRIEVER_START"] = "on_retriever_start";
    ChatMessageEventTypeEnum["ON_RETRIEVER_END"] = "on_retriever_end";
    ChatMessageEventTypeEnum["ON_RETRIEVER_ERROR"] = "on_retriever_error";
    ChatMessageEventTypeEnum["ON_INTERRUPT"] = "on_interrupt";
    ChatMessageEventTypeEnum["ON_ERROR"] = "on_error";
    ChatMessageEventTypeEnum["ON_CHAT_EVENT"] = "on_chat_event";
    ChatMessageEventTypeEnum["ON_CLIENT_EFFECT"] = "on_client_effect";
})(ChatMessageEventTypeEnum || (ChatMessageEventTypeEnum = {}));
var ChatMessageStepCategory;
(function(ChatMessageStepCategory) {
    ChatMessageStepCategory["List"] = "list";
    ChatMessageStepCategory["WebSearch"] = "web_search";
    ChatMessageStepCategory["Files"] = "files";
    ChatMessageStepCategory["File"] = "file";
    ChatMessageStepCategory["Program"] = "program";
    ChatMessageStepCategory["Iframe"] = "iframe";
    ChatMessageStepCategory["Memory"] = "memory";
    ChatMessageStepCategory["Tasks"] = "tasks";
    ChatMessageStepCategory["Knowledges"] = "knowledges";
})(ChatMessageStepCategory || (ChatMessageStepCategory = {}));

function _define_property$r(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _instanceof$1(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _object_spread$r(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$r(target, key, source[key]);
        });
    }
    return target;
}
var CHAT_EVENT_TYPE_FOLLOW_UP_CONSUMED = "follow_up_consumed";
var CHAT_EVENT_TYPE_THREAD_CONTEXT_USAGE = "thread_context_usage";
var CHAT_EVENT_TYPE_CONVERSATION_TITLE_SUMMARY = "conversation_title_summary";
var CHAT_EVENT_TYPE_THREAD_GOAL_UPDATED = "thread_goal_updated";
var CHAT_EVENT_TYPE_THREAD_GOAL_CLEARED = "thread_goal_cleared";
function createConversationTitleSummaryEvent(event) {
    return _object_spread$r({
        type: CHAT_EVENT_TYPE_CONVERSATION_TITLE_SUMMARY
    }, event);
}
function createFollowUpConsumedEvent(event) {
    return _object_spread$r({
        type: CHAT_EVENT_TYPE_FOLLOW_UP_CONSUMED
    }, event);
}
function createThreadGoalUpdatedEvent(goal) {
    var updatedAt = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : new Date();
    return {
        type: CHAT_EVENT_TYPE_THREAD_GOAL_UPDATED,
        conversationId: goal.conversationId,
        threadId: goal.threadId,
        goal: goal,
        updatedAt: toIsoString(updatedAt)
    };
}
function createThreadGoalClearedEvent(event) {
    return {
        type: CHAT_EVENT_TYPE_THREAD_GOAL_CLEARED,
        conversationId: event.conversationId,
        threadId: event.threadId,
        updatedAt: toIsoString(event.updatedAt)
    };
}
function toIsoString(value) {
    if (_instanceof$1(value, Date)) {
        return value.toISOString();
    }
    if (typeof value === "string") {
        var date = new Date(value);
        if (!Number.isNaN(date.getTime())) {
            return date.toISOString();
        }
    }
    return new Date().toISOString();
}

function _array_like_to_array$w(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$j(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$j(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$w(arr);
}
function _define_property$q(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$l(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$h(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$j() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$j() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$q(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$q(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$k(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$k(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$k(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array$h(arr, i) {
    return _array_with_holes$j(arr) || _iterable_to_array_limit$h(arr, i) || _unsupported_iterable_to_array$w(arr, i) || _non_iterable_rest$j();
}
function _to_consumable_array$j(arr) {
    return _array_without_holes$j(arr) || _iterable_to_array$l(arr) || _unsupported_iterable_to_array$w(arr) || _non_iterable_spread$j();
}
function _unsupported_iterable_to_array$w(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$w(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$w(o, minLen);
}
var AssistantCode;
(function(AssistantCode) {
    AssistantCode["CHAT_COMMON"] = "chat_common";
    AssistantCode["XPERT_SHARED"] = "xpert_shared";
    AssistantCode["CLAWXPERT"] = "clawxpert";
})(AssistantCode || (AssistantCode = {}));
var AssistantBindingScope;
(function(AssistantBindingScope) {
    AssistantBindingScope["TENANT"] = "tenant";
    AssistantBindingScope["ORGANIZATION"] = "organization";
    AssistantBindingScope["USER"] = "user";
})(AssistantBindingScope || (AssistantBindingScope = {}));
var AssistantBindingSourceScope;
(function(AssistantBindingSourceScope) {
    AssistantBindingSourceScope["NONE"] = "none";
    AssistantBindingSourceScope["TENANT"] = "tenant";
    AssistantBindingSourceScope["ORGANIZATION"] = "organization";
})(AssistantBindingSourceScope || (AssistantBindingSourceScope = {}));
function normalizeAssistantBindingPreferenceKey(value) {
    var _value_trim;
    return (_value_trim = value === null || value === void 0 ? void 0 : value.trim()) !== null && _value_trim !== void 0 ? _value_trim : "";
}
function normalizeAssistantBindingPreferenceIds(value) {
    var deduped = new Set();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = (value !== null && value !== void 0 ? value : [])[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var item = _step.value;
            var normalized = normalizeAssistantBindingPreferenceKey(item);
            if (normalized) {
                deduped.add(normalized);
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return Array.from(deduped);
}
function normalizeAssistantBindingToolPreferences(value) {
    if (!value) {
        return null;
    }
    var _value_toolsets;
    var toolsets = Object.entries((_value_toolsets = value.toolsets) !== null && _value_toolsets !== void 0 ? _value_toolsets : {}).reduce(function(acc, param) {
        var _param = _sliced_to_array$h(param, 2), key = _param[0], item = _param[1];
        var nodeKey = normalizeAssistantBindingPreferenceKey(key);
        var toolsetName = normalizeAssistantBindingPreferenceKey(item === null || item === void 0 ? void 0 : item.toolsetName);
        if (!nodeKey || !toolsetName) {
            return acc;
        }
        acc[nodeKey] = {
            toolsetId: normalizeAssistantBindingPreferenceKey(item === null || item === void 0 ? void 0 : item.toolsetId) || null,
            toolsetName: toolsetName,
            disabledTools: normalizeAssistantBindingPreferenceIds(item === null || item === void 0 ? void 0 : item.disabledTools)
        };
        return acc;
    }, {});
    var _value_middlewares;
    var middlewares = Object.entries((_value_middlewares = value.middlewares) !== null && _value_middlewares !== void 0 ? _value_middlewares : {}).reduce(function(acc, param) {
        var _param = _sliced_to_array$h(param, 2), key = _param[0], item = _param[1];
        var nodeKey = normalizeAssistantBindingPreferenceKey(key);
        var provider = normalizeAssistantBindingPreferenceKey(item === null || item === void 0 ? void 0 : item.provider);
        if (!nodeKey || !provider) {
            return acc;
        }
        acc[nodeKey] = {
            provider: provider,
            disabledTools: normalizeAssistantBindingPreferenceIds(item === null || item === void 0 ? void 0 : item.disabledTools)
        };
        return acc;
    }, {});
    var _value_skills;
    var skills = Object.entries((_value_skills = value.skills) !== null && _value_skills !== void 0 ? _value_skills : {}).reduce(function(acc, param) {
        var _param = _sliced_to_array$h(param, 2), key = _param[0], item = _param[1];
        var workspaceKey = normalizeAssistantBindingPreferenceKey(key);
        var workspaceId = normalizeAssistantBindingPreferenceKey(item === null || item === void 0 ? void 0 : item.workspaceId) || workspaceKey;
        if (!workspaceKey || !workspaceId) {
            return acc;
        }
        acc[workspaceKey] = {
            workspaceId: workspaceId,
            disabledSkillIds: normalizeAssistantBindingPreferenceIds(item === null || item === void 0 ? void 0 : item.disabledSkillIds)
        };
        return acc;
    }, {});
    if (!Object.keys(toolsets).length && !Object.keys(middlewares).length && !Object.keys(skills).length) {
        return null;
    }
    return _object_spread$q({
        version: 1
    }, Object.keys(toolsets).length ? {
        toolsets: toolsets
    } : {}, Object.keys(middlewares).length ? {
        middlewares: middlewares
    } : {}, Object.keys(skills).length ? {
        skills: skills
    } : {});
}
function isAssistantBindingToolPreferencesEmpty(preferences) {
    return !normalizeAssistantBindingToolPreferences(preferences);
}
function getAssistantBindingDisabledTools(preferences, sourceType, nodeKey) {
    var _normalizedPreferences_toolsets_normalizedNodeKey, _normalizedPreferences_toolsets, _normalizedPreferences_middlewares_normalizedNodeKey, _normalizedPreferences_middlewares;
    var normalizedNodeKey = normalizeAssistantBindingPreferenceKey(nodeKey);
    if (!normalizedNodeKey) {
        return [];
    }
    var normalizedPreferences = normalizeAssistantBindingToolPreferences(preferences);
    if (!normalizedPreferences) {
        return [];
    }
    var _normalizedPreferences_toolsets_normalizedNodeKey_disabledTools, _normalizedPreferences_middlewares_normalizedNodeKey_disabledTools;
    return sourceType === "toolset" ? (_normalizedPreferences_toolsets_normalizedNodeKey_disabledTools = (_normalizedPreferences_toolsets = normalizedPreferences.toolsets) === null || _normalizedPreferences_toolsets === void 0 ? void 0 : (_normalizedPreferences_toolsets_normalizedNodeKey = _normalizedPreferences_toolsets[normalizedNodeKey]) === null || _normalizedPreferences_toolsets_normalizedNodeKey === void 0 ? void 0 : _normalizedPreferences_toolsets_normalizedNodeKey.disabledTools) !== null && _normalizedPreferences_toolsets_normalizedNodeKey_disabledTools !== void 0 ? _normalizedPreferences_toolsets_normalizedNodeKey_disabledTools : [] : (_normalizedPreferences_middlewares_normalizedNodeKey_disabledTools = (_normalizedPreferences_middlewares = normalizedPreferences.middlewares) === null || _normalizedPreferences_middlewares === void 0 ? void 0 : (_normalizedPreferences_middlewares_normalizedNodeKey = _normalizedPreferences_middlewares[normalizedNodeKey]) === null || _normalizedPreferences_middlewares_normalizedNodeKey === void 0 ? void 0 : _normalizedPreferences_middlewares_normalizedNodeKey.disabledTools) !== null && _normalizedPreferences_middlewares_normalizedNodeKey_disabledTools !== void 0 ? _normalizedPreferences_middlewares_normalizedNodeKey_disabledTools : [];
}
function getAssistantBindingDisabledSkillIds(preferences, workspaceId) {
    var _normalizedPreferences_skills_normalizedWorkspaceId, _normalizedPreferences_skills;
    var normalizedWorkspaceId = normalizeAssistantBindingPreferenceKey(workspaceId);
    if (!normalizedWorkspaceId) {
        return [];
    }
    var normalizedPreferences = normalizeAssistantBindingToolPreferences(preferences);
    var _normalizedPreferences_skills_normalizedWorkspaceId_disabledSkillIds;
    return (_normalizedPreferences_skills_normalizedWorkspaceId_disabledSkillIds = normalizedPreferences === null || normalizedPreferences === void 0 ? void 0 : (_normalizedPreferences_skills = normalizedPreferences.skills) === null || _normalizedPreferences_skills === void 0 ? void 0 : (_normalizedPreferences_skills_normalizedWorkspaceId = _normalizedPreferences_skills[normalizedWorkspaceId]) === null || _normalizedPreferences_skills_normalizedWorkspaceId === void 0 ? void 0 : _normalizedPreferences_skills_normalizedWorkspaceId.disabledSkillIds) !== null && _normalizedPreferences_skills_normalizedWorkspaceId_disabledSkillIds !== void 0 ? _normalizedPreferences_skills_normalizedWorkspaceId_disabledSkillIds : [];
}
function isAssistantBindingToolEnabled(preferences, sourceType, nodeKey, toolName) {
    return !getAssistantBindingDisabledTools(preferences, sourceType, nodeKey).includes(normalizeAssistantBindingPreferenceKey(toolName));
}
function isAssistantBindingSkillEnabled(preferences, workspaceId, skillId) {
    return !getAssistantBindingDisabledSkillIds(preferences, workspaceId).includes(normalizeAssistantBindingPreferenceKey(skillId));
}
function filterAssistantBindingDisabledTools(tools, preferences, sourceType, nodeKey) {
    var disabledTools = getAssistantBindingDisabledTools(preferences, sourceType, nodeKey);
    if (!disabledTools.length) {
        return tools;
    }
    var disabledToolSet = new Set(disabledTools);
    return tools.filter(function(tool) {
        return !disabledToolSet.has(tool.name);
    });
}
function filterAssistantBindingDisabledSkillIds(skillIds, preferences, workspaceId) {
    var disabledSkillIds = getAssistantBindingDisabledSkillIds(preferences, workspaceId);
    if (!disabledSkillIds.length) {
        return skillIds;
    }
    var disabledSkillIdSet = new Set(disabledSkillIds);
    return skillIds.filter(function(skillId) {
        return !disabledSkillIdSet.has(skillId);
    });
}
function updateAssistantBindingToolPreferences(preferences, sourceType, nodeKey, metadata, toolName, enabled) {
    var normalizedNodeKey = normalizeAssistantBindingPreferenceKey(nodeKey);
    var normalizedToolName = normalizeAssistantBindingPreferenceKey(toolName);
    if (!normalizedNodeKey || !normalizedToolName) {
        return normalizeAssistantBindingToolPreferences(preferences);
    }
    var _normalizeAssistantBindingToolPreferences;
    var normalizedPreferences = (_normalizeAssistantBindingToolPreferences = normalizeAssistantBindingToolPreferences(preferences)) !== null && _normalizeAssistantBindingToolPreferences !== void 0 ? _normalizeAssistantBindingToolPreferences : {
        version: 1
    };
    var disabledTools = getAssistantBindingDisabledTools(normalizedPreferences, sourceType, normalizedNodeKey);
    var nextDisabledTools = enabled ? disabledTools.filter(function(item) {
        return item !== normalizedToolName;
    }) : normalizeAssistantBindingPreferenceIds(_to_consumable_array$j(disabledTools).concat([
        normalizedToolName
    ]));
    var toolsets = normalizedPreferences.toolsets ? _object_spread$q({}, normalizedPreferences.toolsets) : undefined;
    var middlewares = normalizedPreferences.middlewares ? _object_spread$q({}, normalizedPreferences.middlewares) : undefined;
    if (sourceType === "toolset") {
        var toolsetName = "toolsetName" in metadata ? normalizeAssistantBindingPreferenceKey(metadata.toolsetName) : "";
        if (!toolsetName) {
            return normalizedPreferences;
        }
        var nextToolsets = toolsets !== null && toolsets !== void 0 ? toolsets : {};
        if (nextDisabledTools.length) {
            nextToolsets[normalizedNodeKey] = {
                toolsetId: "toolsetId" in metadata ? normalizeAssistantBindingPreferenceKey(metadata.toolsetId) || null : null,
                toolsetName: toolsetName,
                disabledTools: nextDisabledTools
            };
        } else {
            delete nextToolsets[normalizedNodeKey];
        }
        return normalizeAssistantBindingToolPreferences(_object_spread$q({
            version: 1
        }, Object.keys(nextToolsets).length ? {
            toolsets: nextToolsets
        } : {}, middlewares && Object.keys(middlewares).length ? {
            middlewares: middlewares
        } : {}, normalizedPreferences.skills ? {
            skills: _object_spread$q({}, normalizedPreferences.skills)
        } : {}));
    }
    var provider = "provider" in metadata ? normalizeAssistantBindingPreferenceKey(metadata.provider) : "";
    if (!provider) {
        return normalizedPreferences;
    }
    var nextMiddlewares = middlewares !== null && middlewares !== void 0 ? middlewares : {};
    if (nextDisabledTools.length) {
        nextMiddlewares[normalizedNodeKey] = {
            provider: provider,
            disabledTools: nextDisabledTools
        };
    } else {
        delete nextMiddlewares[normalizedNodeKey];
    }
    return normalizeAssistantBindingToolPreferences(_object_spread$q({
        version: 1
    }, toolsets && Object.keys(toolsets).length ? {
        toolsets: toolsets
    } : {}, Object.keys(nextMiddlewares).length ? {
        middlewares: nextMiddlewares
    } : {}, normalizedPreferences.skills ? {
        skills: _object_spread$q({}, normalizedPreferences.skills)
    } : {}));
}
function updateAssistantBindingSkillPreferences(preferences, workspaceId, skillId, enabled) {
    var normalizedWorkspaceId = normalizeAssistantBindingPreferenceKey(workspaceId);
    var normalizedSkillId = normalizeAssistantBindingPreferenceKey(skillId);
    if (!normalizedWorkspaceId || !normalizedSkillId) {
        return normalizeAssistantBindingToolPreferences(preferences);
    }
    var _normalizeAssistantBindingToolPreferences;
    var normalizedPreferences = (_normalizeAssistantBindingToolPreferences = normalizeAssistantBindingToolPreferences(preferences)) !== null && _normalizeAssistantBindingToolPreferences !== void 0 ? _normalizeAssistantBindingToolPreferences : {
        };
    var disabledSkillIds = getAssistantBindingDisabledSkillIds(normalizedPreferences, normalizedWorkspaceId);
    var nextDisabledSkillIds = enabled ? disabledSkillIds.filter(function(item) {
        return item !== normalizedSkillId;
    }) : normalizeAssistantBindingPreferenceIds(_to_consumable_array$j(disabledSkillIds).concat([
        normalizedSkillId
    ]));
    var skills = normalizedPreferences.skills ? _object_spread$q({}, normalizedPreferences.skills) : {};
    if (nextDisabledSkillIds.length) {
        skills[normalizedWorkspaceId] = {
            workspaceId: normalizedWorkspaceId,
            disabledSkillIds: nextDisabledSkillIds
        };
    } else {
        delete skills[normalizedWorkspaceId];
    }
    return normalizeAssistantBindingToolPreferences(_object_spread$q({
        version: 1
    }, normalizedPreferences.toolsets ? {
        toolsets: _object_spread$q({}, normalizedPreferences.toolsets)
    } : {}, normalizedPreferences.middlewares ? {
        middlewares: _object_spread$q({}, normalizedPreferences.middlewares)
    } : {}, Object.keys(skills).length ? {
        skills: skills
    } : {}));
}
function ensureAssistantBindingSkillWorkspacePreference(preferences, workspaceId) {
    var normalizedWorkspaceId = normalizeAssistantBindingPreferenceKey(workspaceId);
    var _normalizeAssistantBindingToolPreferences;
    var normalizedPreferences = (_normalizeAssistantBindingToolPreferences = normalizeAssistantBindingToolPreferences(preferences)) !== null && _normalizeAssistantBindingToolPreferences !== void 0 ? _normalizeAssistantBindingToolPreferences : {
        version: 1
    };
    if (!normalizedWorkspaceId) {
        return normalizedPreferences;
    }
    var _normalizedPreferences_skills;
    var currentSkills = (_normalizedPreferences_skills = normalizedPreferences.skills) !== null && _normalizedPreferences_skills !== void 0 ? _normalizedPreferences_skills : {};
    var currentWorkspacePreference = currentSkills[normalizedWorkspaceId];
    var _currentWorkspacePreference_disabledSkillIds;
    return _object_spread_props$k(_object_spread$q({
        version: 1
    }, normalizedPreferences.toolsets ? {
        toolsets: _object_spread$q({}, normalizedPreferences.toolsets)
    } : {}, normalizedPreferences.middlewares ? {
        middlewares: _object_spread$q({}, normalizedPreferences.middlewares)
    } : {}), {
        skills: _object_spread_props$k(_object_spread$q({}, currentSkills), _define_property$q({}, normalizedWorkspaceId, {
            workspaceId: normalizeAssistantBindingPreferenceKey(currentWorkspacePreference === null || currentWorkspacePreference === void 0 ? void 0 : currentWorkspacePreference.workspaceId) || normalizedWorkspaceId,
            disabledSkillIds: (_currentWorkspacePreference_disabledSkillIds = currentWorkspacePreference === null || currentWorkspacePreference === void 0 ? void 0 : currentWorkspacePreference.disabledSkillIds) !== null && _currentWorkspacePreference_disabledSkillIds !== void 0 ? _currentWorkspacePreference_disabledSkillIds : []
        }))
    });
}
var USER_MANAGED_ASSISTANTS = new Set([
    AssistantCode.CLAWXPERT
]);
function getAssistantManagement(code) {
    return USER_MANAGED_ASSISTANTS.has(code) ? "user" : "system";
}
function isUserManagedAssistant(code) {
    return getAssistantManagement(code) === "user";
}
function isSystemManagedAssistant(code) {
    return getAssistantManagement(code) === "system";
}

// Shared by Cloud and Desktop: activity changes must not move assistant entries.
function _array_like_to_array$v(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$i(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$v(arr);
}
function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _iterable_to_array$k(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$i() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$i(arr) {
    return _array_without_holes$i(arr) || _iterable_to_array$k(arr) || _unsupported_iterable_to_array$v(arr) || _non_iterable_spread$i();
}
function _unsupported_iterable_to_array$v(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$v(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$v(o, minLen);
}
function orderAssistantXperts(items) {
    var orderedIds = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    var itemById = new Map(items.filter(function(item) {
        return typeof item.id === "string" && !!item.id.trim();
    }).map(function(item) {
        return [
            item.id,
            item
        ];
    }));
    var orderedIdSet = new Set(orderedIds);
    var unorderedItems = items.map(function(item, index) {
        return {
            item: item,
            index: index
        };
    }).filter(function(param) {
        var item = param.item;
        return !item.id || !orderedIdSet.has(item.id);
    }).sort(function(left, right) {
        var leftCreatedAt = createdAtTimestamp(left.item);
        var rightCreatedAt = createdAtTimestamp(right.item);
        return leftCreatedAt === rightCreatedAt ? left.index - right.index : rightCreatedAt > leftCreatedAt ? 1 : -1;
    }).map(function(param) {
        var item = param.item;
        return item;
    });
    return _to_consumable_array$i(unorderedItems).concat(_to_consumable_array$i(orderedIds.map(function(id) {
        return itemById.get(id);
    }).filter(function(item) {
        return !!item;
    })));
}
function createdAtTimestamp(item) {
    var value = item.createdAt;
    var timestamp = _instanceof(value, Date) ? value.getTime() : typeof value === "string" ? Date.parse(value) : Number.NaN;
    return Number.isNaN(timestamp) ? Number.NEGATIVE_INFINITY : timestamp;
}

var ASSISTANT_USER_PREFERENCES_VERSION = 1;

function _array_like_to_array$u(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$i(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$g(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$i() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$g(arr, i) {
    return _array_with_holes$i(arr) || _iterable_to_array_limit$g(arr, i) || _unsupported_iterable_to_array$u(arr, i) || _non_iterable_rest$i();
}
function _unsupported_iterable_to_array$u(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$u(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$u(o, minLen);
}
var ProviderType;
(function(ProviderType) {
    ProviderType["CUSTOM"] = "custom";
    ProviderType["SYSTEM"] = "system";
})(ProviderType || (ProviderType = {}));
/** Custom-model providers without a shared credential schema validate credentials per model. */ function usesModelScopedCredentials(provider) {
    var _provider_configurate_methods;
    return (provider === null || provider === void 0 ? void 0 : (_provider_configurate_methods = provider.configurate_methods) === null || _provider_configurate_methods === void 0 ? void 0 : _provider_configurate_methods.includes(ConfigurateMethod.CUSTOMIZABLE_MODEL)) === true && !provider.provider_credential_schema && !!provider.model_credential_schema;
}
/**
 * @todo Use JSON Schema to implement
 */ var CredentialFormTypeEnum;
(function(CredentialFormTypeEnum) {
    CredentialFormTypeEnum["TEXT_INPUT"] = "text-input";
    CredentialFormTypeEnum["SECRET_INPUT"] = "secret-input";
    CredentialFormTypeEnum["SELECT"] = "select";
    CredentialFormTypeEnum["RADIO"] = "radio";
// SWITCH = "switch", // use ParameterType.BOOLEAN
})(CredentialFormTypeEnum || (CredentialFormTypeEnum = {}));
var FetchFrom;
(function(FetchFrom) {
    FetchFrom["PREDEFINED_MODEL"] = "predefined-model";
    FetchFrom["CUSTOMIZABLE_MODEL"] = "customizable-model";
})(FetchFrom || (FetchFrom = {}));
var ModelFeature;
(function(ModelFeature) {
    ModelFeature["TOOL_CALL"] = "tool-call";
    ModelFeature["MULTI_TOOL_CALL"] = "multi-tool-call";
    ModelFeature["AGENT_THOUGHT"] = "agent-thought";
    ModelFeature["VISION"] = "vision";
    ModelFeature["STREAM_TOOL_CALL"] = "stream-tool-call";
    ModelFeature["VIDEO"] = "video";
    ModelFeature["STRUCTURED_OUTPUT"] = "structured-output";
})(ModelFeature || (ModelFeature = {}));
var ModelPropertyKey;
(function(ModelPropertyKey) {
    ModelPropertyKey["MODE"] = "mode";
    ModelPropertyKey["CONTEXT_SIZE"] = "context_size";
    ModelPropertyKey["MAX_CHUNKS"] = "max_chunks";
    ModelPropertyKey["FILE_UPLOAD_LIMIT"] = "file_upload_limit";
    ModelPropertyKey["SUPPORTED_FILE_EXTENSIONS"] = "supported_file_extensions";
    ModelPropertyKey["MAX_CHARACTERS_PER_CHUNK"] = "max_characters_per_chunk";
    ModelPropertyKey["DEFAULT_VOICE"] = "default_voice";
    ModelPropertyKey["VOICES"] = "voices";
    ModelPropertyKey["WORD_LIMIT"] = "word_limit";
    ModelPropertyKey["AUDIO_TYPE"] = "audio_type";
    ModelPropertyKey["MAX_WORKERS"] = "max_workers";
})(ModelPropertyKey || (ModelPropertyKey = {}));
var ConfigurateMethod;
(function(ConfigurateMethod) {
    ConfigurateMethod["PREDEFINED_MODEL"] = "predefined-model";
    ConfigurateMethod["CUSTOMIZABLE_MODEL"] = "customizable-model";
})(ConfigurateMethod || (ConfigurateMethod = {}));
/**
 * @todo Use JSON Schema to implement
 */ var ParameterType;
(function(ParameterType) {
    ParameterType["FLOAT"] = "float";
    ParameterType["INT"] = "int";
    ParameterType["STRING"] = "string";
    ParameterType["BOOLEAN"] = "boolean";
    ParameterType["TEXT"] = "text";
})(ParameterType || (ParameterType = {}));
var OUTPUT_TOKEN_PARAMETER_NAMES = new Set([
    "max_tokens",
    "max_output_tokens",
    "max_completion_tokens",
    "max_tokens_to_sample"
]);
function isOutputTokenParameter(rule) {
    return !!(rule === null || rule === void 0 ? void 0 : rule.name) && OUTPUT_TOKEN_PARAMETER_NAMES.has(rule.name);
}
function normalizeModelParameterValue(value, rule) {
    switch(rule.type){
        case ParameterType.FLOAT:
        case ParameterType.INT:
            {
                if (value === "" || value === null || value === undefined) {
                    return undefined;
                }
                var numericValue = typeof value === "number" ? value : typeof value === "string" ? Number(value) : Number.NaN;
                if (!Number.isFinite(numericValue)) {
                    return undefined;
                }
                var normalizedValue = rule.type === ParameterType.INT ? Math.trunc(numericValue) : numericValue;
                if (typeof rule.min === "number" && Number.isFinite(rule.min)) {
                    normalizedValue = Math.max(normalizedValue, rule.min);
                }
                if (!isOutputTokenParameter(rule) && typeof rule.max === "number" && Number.isFinite(rule.max)) {
                    normalizedValue = Math.min(normalizedValue, rule.max);
                }
                return rule.type === ParameterType.INT ? Math.trunc(normalizedValue) : normalizedValue;
            }
        case ParameterType.BOOLEAN:
            if (typeof value === "boolean") {
                return value;
            }
            if (typeof value === "string") {
                var normalizedValue1 = value.trim().toLowerCase();
                if (normalizedValue1 === "true") {
                    return true;
                }
                if (normalizedValue1 === "false") {
                    return false;
                }
            }
            if (value === 1) {
                return true;
            }
            if (value === 0) {
                return false;
            }
            return undefined;
        case ParameterType.STRING:
        case ParameterType.TEXT:
            var _rule_options;
            if (typeof value !== "string") {
                return undefined;
            }
            if (((_rule_options = rule.options) === null || _rule_options === void 0 ? void 0 : _rule_options.length) && !rule.options.includes(value)) {
                return undefined;
            }
            return value;
        default:
            return value === undefined ? undefined : value;
    }
}
function resolveModelParameterOptions(modelOptions, rules) {
    var config = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    var _config_preserveUnknown;
    var preserveUnknown = (_config_preserveUnknown = config.preserveUnknown) !== null && _config_preserveUnknown !== void 0 ? _config_preserveUnknown : true;
    var resolvedOptions = preserveUnknown ? Object.fromEntries(Object.entries(modelOptions !== null && modelOptions !== void 0 ? modelOptions : {}).filter(function(param) {
        var _param = _sliced_to_array$g(param, 2), value = _param[1];
        return config.preserveUnset || value != null;
    })) : {};
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = rules[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var rule = _step.value;
            if (!rule.name) {
                continue;
            }
            var hasSavedValue = Object.prototype.hasOwnProperty.call(modelOptions !== null && modelOptions !== void 0 ? modelOptions : {}, rule.name);
            // JSON preserves null across save/reopen; undefined would lose the user's opt-out of defaults.
            if (hasSavedValue && modelOptions[rule.name] === null && !rule.required) {
                if (config.preserveUnset) {
                    resolvedOptions[rule.name] = null;
                } else {
                    delete resolvedOptions[rule.name];
                }
                continue;
            }
            var resolvedValue = hasSavedValue ? normalizeModelParameterValue(modelOptions === null || modelOptions === void 0 ? void 0 : modelOptions[rule.name], rule) : undefined;
            if (resolvedValue === undefined && rule.default !== undefined) {
                resolvedValue = normalizeModelParameterValue(rule.default, rule);
            }
            if (resolvedValue === undefined) {
                delete resolvedOptions[rule.name];
            } else {
                resolvedOptions[rule.name] = resolvedValue;
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return Object.keys(resolvedOptions).length ? resolvedOptions : undefined;
}
var AI_MODEL_TYPE_VARIABLE = "__model_type";
var PriceType;
(function(PriceType) {
    PriceType["INPUT"] = "input";
    PriceType["OUTPUT"] = "output";
})(PriceType || (PriceType = {}));

function _array_like_to_array$t(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$h(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$t(arr);
}
function _define_property$p(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$j(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$h() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$p(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$p(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$j(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$j(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$j(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$h(arr) {
    return _array_without_holes$h(arr) || _iterable_to_array$j(arr) || _unsupported_iterable_to_array$t(arr) || _non_iterable_spread$h();
}
function _unsupported_iterable_to_array$t(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$t(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$t(o, minLen);
}
var discoverableModelTypes = [
    AiModelTypeEnum.LLM,
    AiModelTypeEnum.TEXT_EMBEDDING,
    AiModelTypeEnum.RERANK
];
var DEFAULT_EMBEDDING_BATCH_SIZE = 10;
var positiveInteger = z$1.number().int().positive().max(Number.MAX_SAFE_INTEGER);
var common$1 = {
    contextSize: positiveInteger,
    maxConcurrency: positiveInteger.max(1000)
};
/** Saved model configuration is explicit; name heuristics are only discovery suggestions. */ var modelConfigurationSchema = z$1.discriminatedUnion("modelType", [
    z$1.object(_object_spread_props$j(_object_spread$p({
        modelType: z$1.literal(AiModelTypeEnum.LLM)
    }, common$1), {
        maxOutputTokens: positiveInteger,
        defaultMaxTokens: positiveInteger,
        features: z$1.array(z$1.nativeEnum(ModelFeature)).max(20)
    })).strict(),
    z$1.object(_object_spread_props$j(_object_spread$p({
        modelType: z$1.literal(AiModelTypeEnum.TEXT_EMBEDDING)
    }, common$1), {
        dimensions: positiveInteger.optional(),
        batchSize: positiveInteger.max(2048)
    })).strict(),
    z$1.object(_object_spread$p({
        modelType: z$1.literal(AiModelTypeEnum.RERANK)
    }, common$1)).strict()
]).superRefine(function(value, ctx) {
    if (value.modelType === AiModelTypeEnum.LLM) {
        if (value.maxOutputTokens > value.contextSize) {
            ctx.addIssue({
                code: z$1.ZodIssueCode.custom,
                path: [
                    "maxOutputTokens"
                ],
                message: "Output limit exceeds context size"
            });
        }
        if (value.defaultMaxTokens > value.maxOutputTokens) {
            ctx.addIssue({
                code: z$1.ZodIssueCode.custom,
                path: [
                    "defaultMaxTokens"
                ],
                message: "Default output exceeds output limit"
            });
        }
    }
});
function defaultModelConfiguration(modelType) {
    var common = {
        contextSize: 8192,
        maxConcurrency: 1
    };
    switch(modelType){
        case AiModelTypeEnum.LLM:
            return _object_spread_props$j(_object_spread$p({
                modelType: modelType
            }, common), {
                maxOutputTokens: 2048,
                defaultMaxTokens: 2048,
                features: []
            });
        case AiModelTypeEnum.TEXT_EMBEDDING:
            return _object_spread_props$j(_object_spread$p({
                modelType: modelType
            }, common), {
                batchSize: DEFAULT_EMBEDDING_BATCH_SIZE
            });
        case AiModelTypeEnum.RERANK:
            return _object_spread$p({
                modelType: modelType
            }, common);
    }
}
/** Start with editable defaults and overlay the matching built-in YAML values. */ function configurationFromModel(modelType, model) {
    var _model_model_properties;
    var configuration = defaultModelConfiguration(modelType);
    if ((model === null || model === void 0 ? void 0 : model.model_type) && model.model_type !== modelType) return configuration;
    var context = model === null || model === void 0 ? void 0 : (_model_model_properties = model.model_properties) === null || _model_model_properties === void 0 ? void 0 : _model_model_properties[ModelPropertyKey.CONTEXT_SIZE];
    if (typeof context === "number" && Number.isSafeInteger(context) && context > 0) configuration.contextSize = context;
    if (configuration.modelType === AiModelTypeEnum.LLM) {
        var _model_parameter_rules;
        var rule = model === null || model === void 0 ? void 0 : (_model_parameter_rules = model.parameter_rules) === null || _model_parameter_rules === void 0 ? void 0 : _model_parameter_rules.find(function(item) {
            return item.name === "max_tokens";
        });
        if (typeof (rule === null || rule === void 0 ? void 0 : rule.max) === "number" && rule.max > 0) configuration.maxOutputTokens = Math.min(rule.max, configuration.contextSize);
        if (typeof (rule === null || rule === void 0 ? void 0 : rule.default) === "number" && rule.default > 0) configuration.defaultMaxTokens = rule.default;
        configuration.maxOutputTokens = Math.min(configuration.maxOutputTokens, configuration.contextSize);
        configuration.defaultMaxTokens = Math.min(configuration.defaultMaxTokens, configuration.maxOutputTokens);
        var _model_features;
        configuration.features = _to_consumable_array$h((_model_features = model === null || model === void 0 ? void 0 : model.features) !== null && _model_features !== void 0 ? _model_features : []);
    }
    if (configuration.modelType === AiModelTypeEnum.TEXT_EMBEDDING) {
        var _model_model_properties1, _model_parameter_rules_find, _model_parameter_rules1;
        var batchSize = model === null || model === void 0 ? void 0 : (_model_model_properties1 = model.model_properties) === null || _model_model_properties1 === void 0 ? void 0 : _model_model_properties1[ModelPropertyKey.MAX_CHUNKS];
        var dimensions = model === null || model === void 0 ? void 0 : (_model_parameter_rules1 = model.parameter_rules) === null || _model_parameter_rules1 === void 0 ? void 0 : (_model_parameter_rules_find = _model_parameter_rules1.find(function(item) {
            return item.name === "dimensions";
        })) === null || _model_parameter_rules_find === void 0 ? void 0 : _model_parameter_rules_find.default;
        if (typeof batchSize === "number" && Number.isSafeInteger(batchSize) && batchSize > 0 && batchSize <= 2048) {
            configuration.batchSize = batchSize;
        }
        if (typeof dimensions === "number" && Number.isSafeInteger(dimensions) && dimensions > 0) {
            configuration.dimensions = dimensions;
        }
    }
    return configuration;
}
function isDiscoverableModelType(value) {
    return value === AiModelTypeEnum.LLM || value === AiModelTypeEnum.TEXT_EMBEDDING || value === AiModelTypeEnum.RERANK;
}
/** Parse the persisted JSON field once when entering the model configuration boundary. */ function readModelConfiguration(properties) {
    var value = properties === null || properties === void 0 ? void 0 : properties.model_configuration;
    if (value == null) return undefined;
    return modelConfigurationSchema.parse(value);
}
/** Legacy fallback only; explicit model_configuration.features remains authoritative. */ function legacyModelFeatures(properties) {
    var features = [];
    if ((properties === null || properties === void 0 ? void 0 : properties["vision_support"]) === "support") features.push(ModelFeature.VISION);
    if ((properties === null || properties === void 0 ? void 0 : properties["function_calling_type"]) === "tool_call" || (properties === null || properties === void 0 ? void 0 : properties["function_calling_type"]) === "multi_tool_call") {
        features.push(ModelFeature.TOOL_CALL);
    }
    if ((properties === null || properties === void 0 ? void 0 : properties["function_calling_type"]) === "multi_tool_call") features.push(ModelFeature.MULTI_TOOL_CALL);
    if ((properties === null || properties === void 0 ? void 0 : properties["stream_function_calling"]) === "supported") features.push(ModelFeature.STREAM_TOOL_CALL);
    if ((properties === null || properties === void 0 ? void 0 : properties["agent_though_support"]) === "supported") features.push(ModelFeature.AGENT_THOUGHT);
    return features;
}
function configuredModelSource(model) {
    var _model_modelProperties, _model_modelProperties1;
    var _model_modelProperties_configuration_source;
    return (_model_modelProperties_configuration_source = (_model_modelProperties = model.modelProperties) === null || _model_modelProperties === void 0 ? void 0 : _model_modelProperties.configuration_source) !== null && _model_modelProperties_configuration_source !== void 0 ? _model_modelProperties_configuration_source : ((_model_modelProperties1 = model.modelProperties) === null || _model_modelProperties1 === void 0 ? void 0 : _model_modelProperties1.discovery_model_id) ? "discovered" : "manual";
}
function usesConfiguredModelCatalog(provider) {
    var _provider_options_modelDiscovery, _provider_options;
    return ((_provider_options = provider.options) === null || _provider_options === void 0 ? void 0 : (_provider_options_modelDiscovery = _provider_options.modelDiscovery) === null || _provider_options_modelDiscovery === void 0 ? void 0 : _provider_options_modelDiscovery.mode) === "configured";
}
/** Shared by management UI, pickers and execution authorization. Manual additions remain explicit opt-ins. */ function isConfiguredModelAvailable(provider, model) {
    var _model_modelProperties;
    if (!usesConfiguredModelCatalog(provider)) return true;
    if (!model) return false;
    var sourceId = (_model_modelProperties = model.modelProperties) === null || _model_modelProperties === void 0 ? void 0 : _model_modelProperties.discovery_model_id;
    return !sourceId || provider.options.modelDiscovery.availableModelIds.includes(sourceId);
}
var modelImportSchema = z$1.object({
    models: z$1.array(z$1.object({
        model: z$1.string().trim().min(1).max(512),
        configuration: modelConfigurationSchema
    }).strict()).max(1000)
}).strict().refine(function(value) {
    return new Set(value.models.map(function(model) {
        return model.model;
    })).size === value.models.length;
}, {
    message: "Duplicate model IDs"
});

var providerCredentialValidationTargetSchema = z$1.object({
    modelType: z$1.nativeEnum(AiModelTypeEnum),
    model: z$1.string().trim().min(1).max(512)
}).strict();
var providerCredentialCheckSchema = z$1.object({
    credentials: z$1.record(z$1.unknown()),
    validationTarget: providerCredentialValidationTargetSchema.optional()
}).strict();

var THREAD_GOAL_STATUS_VALUES = [
    "active",
    "paused",
    "blocked",
    // Reserved for future usage-quota enforcement. No backend path emits this status yet.
    "usage_limited",
    "budget_limited",
    "complete"
];
function isRunnableThreadGoalStatus(status) {
    return status === "active";
}

/** Why a derived conversation thread was created. */ var ChatThreadPurpose = {
    SideChat: "side-chat",
    MessageEdit: "message-edit"
};
/**
 * @deprecated use ChatMessageEventTypeEnum
 */ var ChatGatewayEvent;
(function(ChatGatewayEvent) {
    ChatGatewayEvent["ACK"] = "ack";
    ChatGatewayEvent["ConversationCreated"] = "conversation_created";
    ChatGatewayEvent["Message"] = "message";
    ChatGatewayEvent["MessageStream"] = "message_stream";
    ChatGatewayEvent["StepStart"] = "step_start";
    ChatGatewayEvent["StepEnd"] = "step_end";
    ChatGatewayEvent["ToolStart"] = "tool_start";
    ChatGatewayEvent["ToolEnd"] = "tool_end";
    ChatGatewayEvent["ChainStart"] = "chain_start";
    ChatGatewayEvent["ChainEnd"] = "chain_end";
    ChatGatewayEvent["CancelChain"] = "cancel_chain";
    ChatGatewayEvent["ChainAborted"] = "chain_aborted";
    ChatGatewayEvent["Error"] = "error";
    ChatGatewayEvent["Agent"] = "agent";
})(ChatGatewayEvent || (ChatGatewayEvent = {}));

/** Persistence boundary: unknown versions stay hidden until this host understands their policy. */ function chatMessagePresentation(message) {
    var envelope = message.messageEnvelope;
    if (envelope == null) return "message";
    if (typeof envelope === "object" && !Array.isArray(envelope) && "version" in envelope && envelope.version === 1 && "presentation" in envelope && (envelope.presentation === "message" || envelope.presentation === "event")) return envelope.presentation;
    return "runtime";
}
function isRuntimeChatMessage(message) {
    return chatMessagePresentation(message) === "runtime";
}

// Type guards
/**
 * @deprecated use content in message
 */ function isMessageGroup(message) {
    return "messages" in message;
}

var ChatMessageFeedbackRatingEnum;
(function(ChatMessageFeedbackRatingEnum) {
    ChatMessageFeedbackRatingEnum["LIKE"] = "like";
    ChatMessageFeedbackRatingEnum["DISLIKE"] = "dislike";
})(ChatMessageFeedbackRatingEnum || (ChatMessageFeedbackRatingEnum = {}));

var COPILOT_CHECKPOINT_RETENTION_DAYS_SETTING = "copilotCheckpointRetentionDays";
var COPILOT_CHECKPOINT_RETENTION_ENABLED_SETTING = "copilotCheckpointRetentionEnabled";
var MIN_COPILOT_CHECKPOINT_RETENTION_DAYS = 1;
var DEFAULT_COPILOT_CHECKPOINT_RETENTION_DAYS = 60;
var MAX_COPILOT_CHECKPOINT_RETENTION_DAYS = 3650;

var USAGE_HOUR_FORMAT = "yyyy-MM-dd HH";

/** @deprecated Use DefaultModelRole for default assignments; connections have no default purpose. */ var AiProviderRole;
(function(AiProviderRole) {
    AiProviderRole["Primary"] = "primary";
    AiProviderRole["Secondary"] = "secondary";
    AiProviderRole["Embedding"] = "embedding";
    AiProviderRole["Reasoning"] = "reasoning";
})(AiProviderRole || (AiProviderRole = {}));

var CONNECTION_REFERENCE_KINDS = [
    "defaults",
    "assistants",
    "knowledgebases",
    "projects",
    "connections",
    "gateways",
    "membershipPlans",
    "accessGrants",
    "accessRequests",
    "executions",
    "voiceSessions"
];

var AiFeatureEnum;
(function(AiFeatureEnum) {
    AiFeatureEnum["FEATURE_COPILOT"] = "FEATURE_COPILOT";
    AiFeatureEnum["FEATURE_COPILOT_KNOWLEDGEBASE"] = "FEATURE_COPILOT_KNOWLEDGEBASE";
    AiFeatureEnum["FEATURE_COPILOT_CHAT"] = "FEATURE_COPILOT_CHAT";
    AiFeatureEnum["FEATURE_COPILOT_MONITORING"] = "FEATURE_COPILOT_MONITORING";
    AiFeatureEnum["FEATURE_MEMBERSHIP_PLAN"] = "FEATURE_MEMBERSHIP_PLAN";
    AiFeatureEnum["FEATURE_MEMBERSHIP_PURCHASE"] = "FEATURE_MEMBERSHIP_PURCHASE";
    AiFeatureEnum["FEATURE_MODEL_ACCESS_REQUEST"] = "FEATURE_MODEL_ACCESS_REQUEST";
    AiFeatureEnum["FEATURE_MODEL_GATEWAY"] = "FEATURE_MODEL_GATEWAY";
    AiFeatureEnum["FEATURE_XPERT"] = "FEATURE_XPERT";
    AiFeatureEnum["FEATURE_XPERT_PROJECT"] = "FEATURE_XPERT_PROJECT";
    AiFeatureEnum["FEATURE_XPERT_CLAWXPERT"] = "FEATURE_XPERT_CLAWXPERT";
    AiFeatureEnum["FEATURE_XPERT_CODEXPERT"] = "FEATURE_XPERT_CODEXPERT";
    AiFeatureEnum["FEATURE_XPERT_DEEP_RESEARCH"] = "FEATURE_XPERT_DEEP_RESEARCH";
    AiFeatureEnum["FEATURE_XPERT_DATA_ONTOLOGY"] = "FEATURE_XPERT_DATA_ONTOLOGY";
    AiFeatureEnum["FEATURE_XPERT_MARKETPLACE"] = "FEATURE_XPERT_MARKETPLACE";
})(AiFeatureEnum || (AiFeatureEnum = {}));

var MembershipPlanStatusEnum;
(function(MembershipPlanStatusEnum) {
    MembershipPlanStatusEnum["Active"] = "active";
    MembershipPlanStatusEnum["Archived"] = "archived";
})(MembershipPlanStatusEnum || (MembershipPlanStatusEnum = {}));
var MembershipPeriodEnum;
(function(MembershipPeriodEnum) {
    MembershipPeriodEnum["Monthly"] = "monthly";
})(MembershipPeriodEnum || (MembershipPeriodEnum = {}));
var MembershipStatusEnum;
(function(MembershipStatusEnum) {
    MembershipStatusEnum["Active"] = "active";
    MembershipStatusEnum["Paused"] = "paused";
    MembershipStatusEnum["Expired"] = "expired";
})(MembershipStatusEnum || (MembershipStatusEnum = {}));
var MembershipSourceEnum;
(function(MembershipSourceEnum) {
    MembershipSourceEnum["TenantDefault"] = "tenant_default";
    MembershipSourceEnum["Organization"] = "organization";
    MembershipSourceEnum["Admin"] = "admin";
    MembershipSourceEnum["External"] = "external";
})(MembershipSourceEnum || (MembershipSourceEnum = {}));
var MembershipRenewalModeEnum;
(function(MembershipRenewalModeEnum) {
    MembershipRenewalModeEnum["Auto"] = "auto";
    MembershipRenewalModeEnum["Manual"] = "manual";
})(MembershipRenewalModeEnum || (MembershipRenewalModeEnum = {}));
var MembershipPeriodStatusEnum;
(function(MembershipPeriodStatusEnum) {
    MembershipPeriodStatusEnum["Scheduled"] = "scheduled";
    MembershipPeriodStatusEnum["RefundPending"] = "refund_pending";
    MembershipPeriodStatusEnum["Active"] = "active";
    MembershipPeriodStatusEnum["Completed"] = "completed";
    MembershipPeriodStatusEnum["Cancelled"] = "cancelled";
})(MembershipPeriodStatusEnum || (MembershipPeriodStatusEnum = {}));
var DEFAULT_MEMBERSHIP_CNY_PER_POINT = 0.1;
var MEMBERSHIP_CNY_PER_POINT_SETTING = "membershipCnyPerPoint";
var MembershipLedgerSourceEnum;
(function(MembershipLedgerSourceEnum) {
    MembershipLedgerSourceEnum["Assignment"] = "assignment";
    MembershipLedgerSourceEnum["Grant"] = "grant";
    MembershipLedgerSourceEnum["Renew"] = "renew";
    MembershipLedgerSourceEnum["Upgrade"] = "upgrade";
    MembershipLedgerSourceEnum["Usage"] = "usage";
    MembershipLedgerSourceEnum["Adjustment"] = "adjustment";
    MembershipLedgerSourceEnum["StatusChange"] = "status_change";
    MembershipLedgerSourceEnum["PersonalAdjustment"] = "personal_adjustment";
    MembershipLedgerSourceEnum["PersonalUsage"] = "personal_usage";
    MembershipLedgerSourceEnum["ModelUsage"] = "model_usage";
})(MembershipLedgerSourceEnum || (MembershipLedgerSourceEnum = {}));
var MembershipAdminUserStatusEnum;
(function(MembershipAdminUserStatusEnum) {
    MembershipAdminUserStatusEnum["Active"] = "active";
    MembershipAdminUserStatusEnum["Paused"] = "paused";
    MembershipAdminUserStatusEnum["Expired"] = "expired";
    MembershipAdminUserStatusEnum["Unassigned"] = "unassigned";
})(MembershipAdminUserStatusEnum || (MembershipAdminUserStatusEnum = {}));
var MembershipBulkActionEnum;
(function(MembershipBulkActionEnum) {
    MembershipBulkActionEnum["Assign"] = "assign";
    MembershipBulkActionEnum["Renew"] = "renew";
    MembershipBulkActionEnum["Pause"] = "pause";
    MembershipBulkActionEnum["Resume"] = "resume";
    MembershipBulkActionEnum["Revoke"] = "revoke";
})(MembershipBulkActionEnum || (MembershipBulkActionEnum = {}));

var ModelAccessRequestStatusEnum;
(function(ModelAccessRequestStatusEnum) {
    ModelAccessRequestStatusEnum["Requested"] = "requested";
    ModelAccessRequestStatusEnum["Approved"] = "approved";
    ModelAccessRequestStatusEnum["Rejected"] = "rejected";
    ModelAccessRequestStatusEnum["Withdrawn"] = "withdrawn";
    ModelAccessRequestStatusEnum["Closed"] = "closed";
})(ModelAccessRequestStatusEnum || (ModelAccessRequestStatusEnum = {}));
var UserModelGrantStatusEnum;
(function(UserModelGrantStatusEnum) {
    UserModelGrantStatusEnum["Active"] = "active";
    UserModelGrantStatusEnum["Expired"] = "expired";
    UserModelGrantStatusEnum["Revoked"] = "revoked";
})(UserModelGrantStatusEnum || (UserModelGrantStatusEnum = {}));
var ModelAccessOwnershipScopeEnum;
(function(ModelAccessOwnershipScopeEnum) {
    ModelAccessOwnershipScopeEnum["Tenant"] = "tenant";
    ModelAccessOwnershipScopeEnum["Organization"] = "organization";
})(ModelAccessOwnershipScopeEnum || (ModelAccessOwnershipScopeEnum = {}));
var ModelAccessChannelEnum;
(function(ModelAccessChannelEnum) {
    ModelAccessChannelEnum["Xpert"] = "xpert";
    ModelAccessChannelEnum["ExternalApi"] = "external_api";
})(ModelAccessChannelEnum || (ModelAccessChannelEnum = {}));
var ModelAccessSourceEnum;
(function(ModelAccessSourceEnum) {
    ModelAccessSourceEnum["Direct"] = "direct";
    ModelAccessSourceEnum["Plan"] = "plan";
    ModelAccessSourceEnum["Grant"] = "grant";
})(ModelAccessSourceEnum || (ModelAccessSourceEnum = {}));
var ModelAccessUnavailableReasonEnum;
(function(ModelAccessUnavailableReasonEnum) {
    ModelAccessUnavailableReasonEnum["FeatureDisabled"] = "feature_disabled";
    ModelAccessUnavailableReasonEnum["ModelDisabled"] = "model_disabled";
    ModelAccessUnavailableReasonEnum["ModelDeleted"] = "model_deleted";
    ModelAccessUnavailableReasonEnum["GrantExpired"] = "grant_expired";
    ModelAccessUnavailableReasonEnum["GrantRevoked"] = "grant_revoked";
    ModelAccessUnavailableReasonEnum["QuotaExhausted"] = "quota_exhausted";
    ModelAccessUnavailableReasonEnum["MembershipRequired"] = "membership_required";
    ModelAccessUnavailableReasonEnum["TechnicalUser"] = "technical_user";
    ModelAccessUnavailableReasonEnum["ExternalApiIneligible"] = "external_api_ineligible";
})(ModelAccessUnavailableReasonEnum || (ModelAccessUnavailableReasonEnum = {}));
var ModelAccessClosedReasonCodeEnum;
(function(ModelAccessClosedReasonCodeEnum) {
    ModelAccessClosedReasonCodeEnum["PlanIncluded"] = "plan_included";
    ModelAccessClosedReasonCodeEnum["ModelDeleted"] = "model_deleted";
    ModelAccessClosedReasonCodeEnum["UserLeftOrganization"] = "user_left_organization";
    ModelAccessClosedReasonCodeEnum["Other"] = "other";
})(ModelAccessClosedReasonCodeEnum || (ModelAccessClosedReasonCodeEnum = {}));
var ModelAccessEventTypeEnum;
(function(ModelAccessEventTypeEnum) {
    ModelAccessEventTypeEnum["Requested"] = "requested";
    ModelAccessEventTypeEnum["Withdrawn"] = "withdrawn";
    ModelAccessEventTypeEnum["Approved"] = "approved";
    ModelAccessEventTypeEnum["Rejected"] = "rejected";
    ModelAccessEventTypeEnum["Extended"] = "extended";
    ModelAccessEventTypeEnum["Revoked"] = "revoked";
    ModelAccessEventTypeEnum["GrantActivated"] = "grant_activated";
    ModelAccessEventTypeEnum["GrantExpired"] = "grant_expired";
    ModelAccessEventTypeEnum["SystemClosed"] = "system_closed";
    ModelAccessEventTypeEnum["ModelSuspended"] = "model_suspended";
    ModelAccessEventTypeEnum["ModelRestored"] = "model_restored";
    ModelAccessEventTypeEnum["ModelDeleted"] = "model_deleted";
    ModelAccessEventTypeEnum["UserLeftOrganization"] = "user_left_organization";
})(ModelAccessEventTypeEnum || (ModelAccessEventTypeEnum = {}));
var ModelAccessActorTypeEnum;
(function(ModelAccessActorTypeEnum) {
    ModelAccessActorTypeEnum["User"] = "user";
    ModelAccessActorTypeEnum["System"] = "system";
})(ModelAccessActorTypeEnum || (ModelAccessActorTypeEnum = {}));

var ModelGatewayApiKeyStatusEnum;
(function(ModelGatewayApiKeyStatusEnum) {
    ModelGatewayApiKeyStatusEnum["Active"] = "active";
    ModelGatewayApiKeyStatusEnum["Expired"] = "expired";
    ModelGatewayApiKeyStatusEnum["Revoked"] = "revoked";
})(ModelGatewayApiKeyStatusEnum || (ModelGatewayApiKeyStatusEnum = {}));
var ModelGatewayApiKeyLifetimeEnum;
(function(ModelGatewayApiKeyLifetimeEnum) {
    ModelGatewayApiKeyLifetimeEnum["Days30"] = "30_days";
    ModelGatewayApiKeyLifetimeEnum["Days90"] = "90_days";
    ModelGatewayApiKeyLifetimeEnum["Days180"] = "180_days";
    ModelGatewayApiKeyLifetimeEnum["Permanent"] = "permanent";
})(ModelGatewayApiKeyLifetimeEnum || (ModelGatewayApiKeyLifetimeEnum = {}));
var ModelGatewayCallStatusEnum;
(function(ModelGatewayCallStatusEnum) {
    ModelGatewayCallStatusEnum["Started"] = "started";
    ModelGatewayCallStatusEnum["SettlementPending"] = "settlement_pending";
    ModelGatewayCallStatusEnum["Succeeded"] = "succeeded";
    ModelGatewayCallStatusEnum["Failed"] = "failed";
})(ModelGatewayCallStatusEnum || (ModelGatewayCallStatusEnum = {}));
var ModelGatewayUsageSourceEnum;
(function(ModelGatewayUsageSourceEnum) {
    ModelGatewayUsageSourceEnum["Provider"] = "provider";
    ModelGatewayUsageSourceEnum["Estimated"] = "estimated";
    ModelGatewayUsageSourceEnum["None"] = "none";
})(ModelGatewayUsageSourceEnum || (ModelGatewayUsageSourceEnum = {}));
var ModelGatewayUsageChannelEnum;
(function(ModelGatewayUsageChannelEnum) {
    ModelGatewayUsageChannelEnum["Xpert"] = "xpert";
    ModelGatewayUsageChannelEnum["ExternalApi"] = "external_api";
    /** Managed agent invocation usage, regardless of where the runtime executes. */ ModelGatewayUsageChannelEnum["AgentRuntime"] = "agent_runtime";
    /** User-launched CLI session usage, separate from managed invocations. */ ModelGatewayUsageChannelEnum["Cli"] = "cli";
    /** CLI child launched by an Assistant shell execution. */ ModelGatewayUsageChannelEnum["Shell"] = "shell";
})(ModelGatewayUsageChannelEnum || (ModelGatewayUsageChannelEnum = {}));
var MODEL_GATEWAY_REQUESTS_PER_MINUTE_SETTING = "modelGatewayRequestsPerMinute";
var MODEL_GATEWAY_EXTERNAL_API_BASE_URL_SETTING = "modelGatewayExternalApiBaseUrl";
var MAX_MODEL_GATEWAY_EXTERNAL_API_BASE_URL_LENGTH = 2048;
var DEFAULT_MODEL_GATEWAY_REQUESTS_PER_MINUTE = 60;
var MIN_MODEL_GATEWAY_REQUESTS_PER_MINUTE = 1;
var MAX_MODEL_GATEWAY_REQUESTS_PER_MINUTE = 10000;
var MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS_SETTING = "modelGatewayMaxConcurrentRequests";
var DEFAULT_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS = 5;
var MIN_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS = 1;
var MAX_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS = 100;
var DEFAULT_MODEL_GATEWAY_BODY_RETENTION_DAYS = 7;
var MIN_MODEL_GATEWAY_BODY_RETENTION_DAYS = 1;
var MAX_MODEL_GATEWAY_BODY_RETENTION_DAYS = 3650;
var MODEL_GATEWAY_CALL_RETENTION_ENABLED_SETTING = "modelGatewayCallRetentionEnabled";
var MODEL_GATEWAY_CALL_RETENTION_DAYS_SETTING = "modelGatewayCallRetentionDays";
var DEFAULT_MODEL_GATEWAY_CALL_RETENTION_DAYS = 60;
var MIN_MODEL_GATEWAY_CALL_RETENTION_DAYS = 1;
var MAX_MODEL_GATEWAY_CALL_RETENTION_DAYS = 3650;
/** Client-facing HTTP(S) base URL; an empty value restores the deployment default. */ function isModelGatewayExternalApiBaseUrl(value) {
    var candidate = value.trim();
    if (!candidate) return true;
    if (candidate.length > MAX_MODEL_GATEWAY_EXTERNAL_API_BASE_URL_LENGTH || !/^https?:\/\//i.test(candidate) || /[\s\\?#]/.test(candidate)) return false;
    try {
        var url = new URL(candidate);
        return !!url.hostname && !url.username && !url.password;
    } catch (e) {
        return false;
    }
}

var VectorTypeEnum;
(function(VectorTypeEnum) {
    VectorTypeEnum["ANALYTICDB"] = "analyticdb";
    VectorTypeEnum["CHROMA"] = "chroma";
    VectorTypeEnum["MILVUS"] = "milvus";
    VectorTypeEnum["MYSCALE"] = "myscale";
    VectorTypeEnum["PGVECTOR"] = "pgvector";
    VectorTypeEnum["PGVECTO_RS"] = "pgvecto-rs";
    VectorTypeEnum["QDRANT"] = "qdrant";
    VectorTypeEnum["RELYT"] = "relyt";
    VectorTypeEnum["TIDB_VECTOR"] = "tidb_vector";
    VectorTypeEnum["WEAVIATE"] = "weaviate";
    VectorTypeEnum["OPENSEARCH"] = "opensearch";
    VectorTypeEnum["TENCENT"] = "tencent";
    VectorTypeEnum["ORACLE"] = "oracle";
    VectorTypeEnum["ELASTICSEARCH"] = "elasticsearch";
    VectorTypeEnum["ELASTICSEARCH_JA"] = "elasticsearch-ja";
    VectorTypeEnum["LINDORM"] = "lindorm";
    VectorTypeEnum["COUCHBASE"] = "couchbase";
    VectorTypeEnum["BAIDU"] = "baidu";
    VectorTypeEnum["VIKINGDB"] = "vikingdb";
    VectorTypeEnum["UPSTASH"] = "upstash";
    VectorTypeEnum["TIDB_ON_QDRANT"] = "tidb_on_qdrant";
    VectorTypeEnum["OCEANBASE"] = "oceanbase";
})(VectorTypeEnum || (VectorTypeEnum = {}));

var KDocumentWebTypeEnum;
(function(KDocumentWebTypeEnum) {
    KDocumentWebTypeEnum["Playwright"] = "playwright";
    KDocumentWebTypeEnum["FireCrawl"] = "firecrawl";
    KDocumentWebTypeEnum["Notion"] = "notion";
})(KDocumentWebTypeEnum || (KDocumentWebTypeEnum = {}));
var KDocumentWebTypeOptions = [
    {
        value: KDocumentWebTypeEnum.Playwright,
        label: {
            en_US: "Playwright"
        },
        icon: '<svg width="100%" height="100%" viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M136.444 221.556C123.558 225.213 115.104 231.625 109.535 238.032C114.869 233.364 122.014 229.08 131.652 226.348C141.51 223.554 149.92 223.574 156.869 224.915V219.481C150.941 218.939 144.145 219.371 136.444 221.556ZM108.946 175.876L61.0895 188.484C61.0895 188.484 61.9617 189.716 63.5767 191.36L104.153 180.668C104.153 180.668 103.578 188.077 98.5847 194.705C108.03 187.559 108.946 175.876 108.946 175.876ZM149.005 288.347C81.6582 306.486 46.0272 228.438 35.2396 187.928C30.2556 169.229 28.0799 155.067 27.5 145.928C27.4377 144.979 27.4665 144.179 27.5336 143.446C24.04 143.657 22.3674 145.473 22.7077 150.721C23.2876 159.855 25.4633 174.016 30.4473 192.721C41.2301 233.225 76.8659 311.273 144.213 293.134C158.872 289.185 169.885 281.992 178.152 272.81C170.532 279.692 160.995 285.112 149.005 288.347ZM161.661 128.11V132.903H188.077C187.535 131.206 186.989 129.677 186.447 128.11H161.661Z" fill="#2D4552"/>\n<path d="M193.981 167.584C205.861 170.958 212.144 179.287 215.465 186.658L228.711 190.42C228.711 190.42 226.904 164.623 203.57 157.995C181.741 151.793 168.308 170.124 166.674 172.496C173.024 167.972 182.297 164.268 193.981 167.584ZM299.422 186.777C277.573 180.547 264.145 198.916 262.535 201.255C268.89 196.736 278.158 193.031 289.837 196.362C301.698 199.741 307.976 208.06 311.307 215.436L324.572 219.212C324.572 219.212 322.736 193.41 299.422 186.777ZM286.262 254.795L176.072 223.99C176.072 223.99 177.265 230.038 181.842 237.869L274.617 263.805C282.255 259.386 286.262 254.795 286.262 254.795ZM209.867 321.102C122.618 297.71 133.166 186.543 147.284 133.865C153.097 112.156 159.073 96.0203 164.029 85.204C161.072 84.5953 158.623 86.1529 156.203 91.0746C150.941 101.747 144.212 119.124 137.7 143.45C123.586 196.127 113.038 307.29 200.283 330.682C241.406 341.699 273.442 324.955 297.323 298.659C274.655 319.19 245.714 330.701 209.867 321.102Z" fill="#2D4552"/>\n<path d="M161.661 262.296V239.863L99.3324 257.537C99.3324 257.537 103.938 230.777 136.444 221.556C146.302 218.762 154.713 218.781 161.661 220.123V128.11H192.869C189.471 117.61 186.184 109.526 183.423 103.909C178.856 94.612 174.174 100.775 163.545 109.665C156.059 115.919 137.139 129.261 108.668 136.933C80.1966 144.61 57.179 142.574 47.5752 140.911C33.9601 138.562 26.8387 135.572 27.5049 145.928C28.0847 155.062 30.2605 169.224 35.2445 187.928C46.0272 228.433 81.663 306.481 149.01 288.342C166.602 283.602 179.019 274.233 187.626 262.291H161.661V262.296ZM61.0848 188.484L108.946 175.876C108.946 175.876 107.551 194.288 89.6087 199.018C71.6614 203.743 61.0848 188.484 61.0848 188.484Z" fill="#E2574C"/>\n<path d="M341.786 129.174C329.345 131.355 299.498 134.072 262.612 124.185C225.716 114.304 201.236 97.0224 191.537 88.8994C177.788 77.3834 171.74 69.3802 165.788 81.4857C160.526 92.163 153.797 109.54 147.284 133.866C133.171 186.543 122.623 297.706 209.867 321.098C297.093 344.47 343.53 242.92 357.644 190.238C364.157 165.917 367.013 147.5 367.799 135.625C368.695 122.173 359.455 126.078 341.786 129.174ZM166.497 172.756C166.497 172.756 180.246 151.372 203.565 158C226.899 164.628 228.706 190.425 228.706 190.425L166.497 172.756ZM223.42 268.713C182.403 256.698 176.077 223.99 176.077 223.99L286.262 254.796C286.262 254.791 264.021 280.578 223.42 268.713ZM262.377 201.495C262.377 201.495 276.107 180.126 299.422 186.773C322.736 193.411 324.572 219.208 324.572 219.208L262.377 201.495Z" fill="#2EAD33"/>\n<path d="M139.88 246.04L99.3324 257.532C99.3324 257.532 103.737 232.44 133.607 222.496L110.647 136.33L108.663 136.933C80.1918 144.611 57.1742 142.574 47.5704 140.911C33.9554 138.563 26.834 135.572 27.5001 145.929C28.08 155.063 30.2557 169.224 35.2397 187.929C46.0225 228.433 81.6583 306.481 149.005 288.342L150.989 287.719L139.88 246.04ZM61.0848 188.485L108.946 175.876C108.946 175.876 107.551 194.288 89.6087 199.018C71.6615 203.743 61.0848 188.485 61.0848 188.485Z" fill="#D65348"/>\n<path d="M225.27 269.163L223.415 268.712C182.398 256.698 176.072 223.99 176.072 223.99L232.89 239.872L262.971 124.281L262.607 124.185C225.711 114.304 201.232 97.0224 191.532 88.8994C177.783 77.3834 171.735 69.3802 165.783 81.4857C160.526 92.163 153.797 109.54 147.284 133.866C133.171 186.543 122.623 297.706 209.867 321.097L211.655 321.5L225.27 269.163ZM166.497 172.756C166.497 172.756 180.246 151.372 203.565 158C226.899 164.628 228.706 190.425 228.706 190.425L166.497 172.756Z" fill="#1D8D22"/>\n<path d="M141.946 245.451L131.072 248.537C133.641 263.019 138.169 276.917 145.276 289.195C146.513 288.922 147.74 288.687 149 288.342C152.302 287.451 155.364 286.348 158.312 285.145C150.371 273.361 145.118 259.789 141.946 245.451ZM137.7 143.451C132.112 164.307 127.113 194.326 128.489 224.436C130.952 223.367 133.554 222.371 136.444 221.551L138.457 221.101C136.003 188.939 141.308 156.165 147.284 133.866C148.799 128.225 150.318 122.978 151.832 118.085C149.393 119.637 146.767 121.228 143.776 122.867C141.759 129.093 139.722 135.898 137.7 143.451Z" fill="#C04B41"/>\n</svg>'
    },
    {
        value: KDocumentWebTypeEnum.FireCrawl,
        label: {
            en_US: "FireCrawl"
        },
        icon: "\uD83D\uDD25"
    }
];

var WorkflowNodeTypeEnum;
(function(WorkflowNodeTypeEnum) {
    WorkflowNodeTypeEnum["START"] = "start";
    WorkflowNodeTypeEnum["END"] = "end";
    /**
     * Trigger
     */ WorkflowNodeTypeEnum["TRIGGER"] = "trigger";
    /**
     * State Variable Assigner
     */ WorkflowNodeTypeEnum["ASSIGNER"] = "assigner";
    /**
     * Router
     */ WorkflowNodeTypeEnum["IF_ELSE"] = "if-else";
    WorkflowNodeTypeEnum["LIST_OPERATOR"] = "list-operator";
    WorkflowNodeTypeEnum["VARIABLE_AGGREGATOR"] = "variable-aggregator";
    /**
     * @deprecated use ITERATOR instead
     */ WorkflowNodeTypeEnum["ITERATING"] = "iterating";
    WorkflowNodeTypeEnum["ITERATOR"] = "iterator";
    WorkflowNodeTypeEnum["HTTP"] = "http";
    WorkflowNodeTypeEnum["SUBFLOW"] = "subflow";
    WorkflowNodeTypeEnum["TOOL"] = "tool";
    WorkflowNodeTypeEnum["AGENT_WORKFLOW"] = "agent-workflow";
    /**
     * @deprecated use AGENT_WORKFLOW instead
     */ WorkflowNodeTypeEnum["AGENT_TOOL"] = "agent-tool";
    WorkflowNodeTypeEnum["NOTE"] = "note";
    /**
     * Task node, distribute tasks to sub-agents
     */ WorkflowNodeTypeEnum["TASK"] = "task";
    // Knowledge Pipeline nodes
    WorkflowNodeTypeEnum["SOURCE"] = "source";
    WorkflowNodeTypeEnum["PROCESSOR"] = "processor";
    WorkflowNodeTypeEnum["CHUNKER"] = "chunker";
    WorkflowNodeTypeEnum["UNDERSTANDING"] = "understanding";
    WorkflowNodeTypeEnum["KNOWLEDGE_BASE"] = "knowledgebase";
    // ===============================
    // 📦 Transform Nodes
    // ===============================
    WorkflowNodeTypeEnum["CLASSIFIER"] = "classifier";
    WorkflowNodeTypeEnum["KNOWLEDGE"] = "knowledge";
    WorkflowNodeTypeEnum["CODE"] = "code";
    WorkflowNodeTypeEnum["TEMPLATE"] = "template";
    WorkflowNodeTypeEnum["ANSWER"] = "answer";
    WorkflowNodeTypeEnum["JSON_STRINGIFY"] = "json-stringify";
    WorkflowNodeTypeEnum["JSON_PARSE"] = "json-parse";
    // ===============================
    // 📦 Database Operation Nodes
    // ===============================
    /**
     * Custom SQL
     */ WorkflowNodeTypeEnum["DB_SQL"] = "db-sql";
    /**
     * Insert data (INSERT)
     */ WorkflowNodeTypeEnum["DB_INSERT"] = "db-insert";
    /**
     * Update data (UPDATE)
     */ WorkflowNodeTypeEnum["DB_UPDATE"] = "db-update";
    /**
     * Delete data (DELETE)
     */ WorkflowNodeTypeEnum["DB_DELETE"] = "db-delete";
    /**
     * Query data (SELECT)
     */ WorkflowNodeTypeEnum["DB_QUERY"] = "db-query";
    // ===============================
    // 🏆 Pro Nodes
    // ===============================
    WorkflowNodeTypeEnum["MIDDLEWARE"] = "middleware";
    WorkflowNodeTypeEnum["SKILL"] = "skill";
})(WorkflowNodeTypeEnum || (WorkflowNodeTypeEnum = {}));
var VariableOperationEnum;
(function(VariableOperationEnum) {
    VariableOperationEnum["APPEND"] = "append";
    VariableOperationEnum["EXTEND"] = "extend";
    VariableOperationEnum["OVERWRITE"] = "overwrite";
    VariableOperationEnum["CLEAR"] = "clear";
})(VariableOperationEnum || (VariableOperationEnum = {}));
/**
 * @deprecated use `IteratorItemParameterName` instead
 */ var IteratingItemParameterName = "$item";
/**
 * @deprecated use `IteratorIndexParameterName` instead
 */ var IteratingIndexParameterName = "$index";
/**
 * The parameter name that represents the entire current element in array
 */ var IteratorItemParameterName = "$item";
var IteratorIndexParameterName = "$index";
var WorkflowLogicalOperator;
(function(WorkflowLogicalOperator) {
    WorkflowLogicalOperator["AND"] = "and";
    WorkflowLogicalOperator["OR"] = "or";
})(WorkflowLogicalOperator || (WorkflowLogicalOperator = {}));
var WorkflowComparisonOperator;
(function(WorkflowComparisonOperator) {
    WorkflowComparisonOperator["CONTAINS"] = "contains";
    WorkflowComparisonOperator["NOT_CONTAINS"] = "not-contains";
    WorkflowComparisonOperator["EQUAL"] = "equal";
    WorkflowComparisonOperator["NOT_EQUAL"] = "not-equal";
    WorkflowComparisonOperator["GT"] = "gt";
    WorkflowComparisonOperator["LT"] = "lt";
    WorkflowComparisonOperator["GE"] = "ge";
    WorkflowComparisonOperator["LE"] = "le";
    WorkflowComparisonOperator["STARTS_WITH"] = "starts-with";
    WorkflowComparisonOperator["ENDS_WITH"] = "ends-with";
    WorkflowComparisonOperator["EMPTY"] = "empty";
    WorkflowComparisonOperator["NOT_EMPTY"] = "not-empty";
    WorkflowComparisonOperator["IS_TRUE"] = "is-true";
    WorkflowComparisonOperator["IS_FALSE"] = "is-false";
    WorkflowComparisonOperator["LIKE"] = "like";
    WorkflowComparisonOperator["NOT_LIKE"] = "not-like";
})(WorkflowComparisonOperator || (WorkflowComparisonOperator = {}));
function isAgentWorkflowNodeType(type) {
    return type === WorkflowNodeTypeEnum.AGENT_WORKFLOW || type === WorkflowNodeTypeEnum.AGENT_TOOL;
}
function isAgentWorkflowNode(node) {
    return isAgentWorkflowNodeType(node === null || node === void 0 ? void 0 : node.type);
}
function genXpertTriggerKey() {
    return letterStartSUID("Trigger_");
}
function genListOperatorKey() {
    return letterStartSUID("ListOperator_");
}
function genVariableAggregatorKey() {
    return letterStartSUID("VariableAggregator_");
}
function genJSONStringifyKey() {
    return letterStartSUID("JSONStringify_");
}
function genJSONParseKey() {
    return letterStartSUID("JSONParse_");
}
function genXpertIteratorKey() {
    return letterStartSUID("Iterator_");
}
function genXpertStartKey(key) {
    return key + "_start";
}
function isAgentKey(key) {
    return key === null || key === void 0 ? void 0 : key.toLowerCase().startsWith("agent_");
}
function isRouterKey(key) {
    return key === null || key === void 0 ? void 0 : key.toLowerCase().startsWith("router_");
}
/**
 * @deprecated use `isIteratorKey` instead
 */ function isIteratingKey(key) {
    return key === null || key === void 0 ? void 0 : key.toLowerCase().startsWith("iterating_");
}
function isIteratorKey(key) {
    return key === null || key === void 0 ? void 0 : key.toLowerCase().startsWith("iterator_");
}
function workflowNodeIdentifier(node) {
    return node.title || node.key;
}

function _define_property$o(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$o(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$o(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$i(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$i(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$i(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _object_without_properties$2(source, excluded) {
    if (source == null) return {};
    var target = _object_without_properties_loose$2(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _object_without_properties_loose$2(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
var XpertTypeEnum;
(function(XpertTypeEnum) {
    /**
     * Chat Agents
     */ XpertTypeEnum["Agent"] = "agent";
    /**
     * @deprecated use Chatkit with agent instead.
     */ XpertTypeEnum["Copilot"] = "copilot";
    /**
     * Knowledge Workflow
     */ XpertTypeEnum["Knowledge"] = "knowledge";
})(XpertTypeEnum || (XpertTypeEnum = {}));
function toXpertOpenerPrompt(question) {
    return typeof question === "string" ? {
        label: question,
        prompt: question
    } : {
        label: question.label,
        prompt: question.prompt
    };
}
var DEFAULT_XPERT_WORKSPACE_DATA_SCOPE = "shared";
var XpertWorkbenchInitialLayoutEnum;
(function(XpertWorkbenchInitialLayoutEnum) {
    XpertWorkbenchInitialLayoutEnum["TwoColumns"] = "two-columns";
    XpertWorkbenchInitialLayoutEnum["OverlayDialog"] = "overlay-dialog";
    XpertWorkbenchInitialLayoutEnum["ChatkitMaximized"] = "chatkit-maximized";
    XpertWorkbenchInitialLayoutEnum["WorkbenchMaximized"] = "workbench-maximized";
})(XpertWorkbenchInitialLayoutEnum || (XpertWorkbenchInitialLayoutEnum = {}));
/**
 * Config for Agent execution (Langgraph.js)
 */ var DEFAULT_XPERT_AGENT_RECURSION_LIMIT = 1000;
function getXpertAgentRecursionLimit(agentConfig) {
    return typeof (agentConfig === null || agentConfig === void 0 ? void 0 : agentConfig.recursionLimit) === "number" ? agentConfig.recursionLimit : DEFAULT_XPERT_AGENT_RECURSION_LIMIT;
}
function normalizeXpertAgentConfig(agentConfig) {
    // Legacy imports may carry this unsupported scheduler option (LangGraph.js #2656).
    var _ref = agentConfig !== null && agentConfig !== void 0 ? agentConfig : {}; _ref.maxConcurrency; var config = _object_without_properties$2(_ref, [
        "maxConcurrency"
    ]);
    return _object_spread_props$i(_object_spread$o({}, config), {
        recursionLimit: getXpertAgentRecursionLimit(agentConfig)
    });
}
var XpertParameterTypeEnum;
(function(XpertParameterTypeEnum) {
    /**
     * @deprecated use string
     */ XpertParameterTypeEnum["TEXT"] = "text";
    /**
     * @deprecated use string
     */ XpertParameterTypeEnum["PARAGRAPH"] = "paragraph";
    XpertParameterTypeEnum["STRING"] = "string";
    XpertParameterTypeEnum["NUMBER"] = "number";
    XpertParameterTypeEnum["OBJECT"] = "object";
    XpertParameterTypeEnum["SELECT"] = "select";
    XpertParameterTypeEnum["FILE"] = "file";
    XpertParameterTypeEnum["ARRAY_STRING"] = "array[string]";
    XpertParameterTypeEnum["ARRAY_NUMBER"] = "array[number]";
    XpertParameterTypeEnum["ARRAY"] = "array[object]";
    XpertParameterTypeEnum["ARRAY_FILE"] = "array[file]";
    XpertParameterTypeEnum["ARRAY_DOCUMENT"] = "array[document]";
    XpertParameterTypeEnum["ARRAY_MESSAGE"] = "array[message]";
    XpertParameterTypeEnum["BOOLEAN"] = "boolean";
    XpertParameterTypeEnum["SECRET"] = "secret";
})(XpertParameterTypeEnum || (XpertParameterTypeEnum = {}));
var ENTERPRISE_H5_PLATFORMS = [
    "dingtalk"
];
function isEnterpriseH5Platform(value) {
    return typeof value === "string" && ENTERPRISE_H5_PLATFORMS.includes(value);
}
// Helper guards
function isXpertNodeType(type) {
    return function(node) {
        return node.type === type;
    };
}

function agentLabel(agent) {
    return agent.title || agent.name || agent.key;
}
function agentUniqueName(agent) {
    return agent ? convertToUrlPath(agent.name) || agent.key : null;
}
function convertToUrlPath(title) {
    return title === null || title === void 0 ? void 0 : title.toLowerCase() // Convert to lowercase
    .replace(/\s+/g, "-") // Replace spaces with -
    .replace(/[^a-z0-9-]/g, ""); // Remove non-alphanumeric characters
}
var VariableOperations = [
    {
        value: "append",
        label: {
            zh_Hans: "追加",
            en_US: "Append"
        }
    },
    {
        value: "extends",
        label: {
            zh_Hans: "扩展",
            en_US: "Extend"
        }
    },
    {
        value: "overwrite",
        label: {
            zh_Hans: "覆盖",
            en_US: "Overwrite"
        }
    },
    {
        value: "clear",
        label: {
            zh_Hans: "清除",
            en_US: "Clear"
        }
    }
];

function _array_like_to_array$s(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$h(arr) {
    if (Array.isArray(arr)) return arr;
}
function _define_property$n(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit$f(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$h() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$n(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$n(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$h(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$h(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$h(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array$f(arr, i) {
    return _array_with_holes$h(arr) || _iterable_to_array_limit$f(arr, i) || _unsupported_iterable_to_array$s(arr, i) || _non_iterable_rest$h();
}
function _unsupported_iterable_to_array$s(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$s(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$s(o, minLen);
}
/**
 * @deprecated can use getCurrentTaskInput instead?
 */ var CONTEXT_VARIABLE_CURRENTSTATE = "currentState";
var STATE_VARIABLE_SYS = "sys";
var GRAPH_NODE_SUMMARIZE_CONVERSATION = "summarize_conversation";
var GRAPH_NODE_TITLE_CONVERSATION = "title_conversation";
var STATE_VARIABLE_FILES = "files";
var STATE_VARIABLE_INPUT = "input";
var STATE_SYS_VOLUME = "volume";
/**
 * Workspace path in sandbox environment
 */ var STATE_SYS_WORKSPACE_PATH = "workspace_path";
/**
 * URL for workspace files in sandbox environment
 */ var STATE_SYS_WORKSPACE_URL = "workspace_url";
var STATE_SYS_WORKSPACE_ROOT = "workspace_root";
var STATE_SYS_SHARED_WORKSPACE_PATH = "shared_workspace_path";
var STATE_SYS_AGENT_WORKSPACE_PATH = "agent_workspace_path";
var STATE_SYS_SESSION_WORKSPACE_PATH = "session_workspace_path";
var STATE_SYS_MEMORY_WORKSPACE_PATH = "memory_workspace_path";
/**
 * Current runtime thread id
 */ var STATE_SYS_THREAD_ID = "thread_id";
var STATE_VARIABLE_TITLE_CHANNEL = channelName("title");
// Helpers
function channelName(name) {
    return name.toLowerCase() + "_channel";
}
function messageContentText(content) {
    return typeof content === "string" ? content : content.type === "text" ? content.text : "";
}
/**
 * Get workspace folder for sandbox from runnable configurable
 *
 * @param configurable
 * @returns
 */ function getWorkspaceFromRunnable(configurable) {
    return (configurable === null || configurable === void 0 ? void 0 : configurable.projectId) ? {
        type: "project",
        id: ""
    } : (configurable === null || configurable === void 0 ? void 0 : configurable.userId) || (configurable === null || configurable === void 0 ? void 0 : configurable.thread_id) ? {
        type: "user",
        id: ""
    } : {};
}
function getToolCallFromConfig(config) {
    var _config_configurable;
    return (config === null || config === void 0 ? void 0 : config.toolCall) || (config === null || config === void 0 ? void 0 : (_config_configurable = config.configurable) === null || _config_configurable === void 0 ? void 0 : _config_configurable.toolCall);
}
function getToolCallIdFromConfig(config) {
    var _config_metadata, _config_configurable, _getToolCallFromConfig;
    return ((_config_metadata = config.metadata) === null || _config_metadata === void 0 ? void 0 : _config_metadata.tool_call_id) || (config === null || config === void 0 ? void 0 : (_config_configurable = config.configurable) === null || _config_configurable === void 0 ? void 0 : _config_configurable.tool_call_id) || ((_getToolCallFromConfig = getToolCallFromConfig(config)) === null || _getToolCallFromConfig === void 0 ? void 0 : _getToolCallFromConfig.id);
}
/**
 * Compute long-term memory namespace:
 * 1. When a user talks to a digital expert individually, use `ExpertId` + `UserId` to store memory
 * 2. When talking to a digital expert in a project, all users and digital experts share `ProjectId` to store memory
 *
 * @param config
 * @returns
 */ function getStoreNamespace(config) {
    var configurable = config.configurable;
    return configurableStoreNamespace(configurable);
}
function configurableStoreNamespace(configurable) {
    return (configurable === null || configurable === void 0 ? void 0 : configurable.projectId) ? [
        configurable === null || configurable === void 0 ? void 0 : configurable.projectId
    ] : (configurable === null || configurable === void 0 ? void 0 : configurable.userId) ? [
        configurable.xpertId,
        configurable.userId
    ] : [];
}
/**
 * Set value into variable of state.
 *
 * @param state
 * @param varName
 * @param value
 * @returns
 */ function setStateVariable(state, varName, value) {
    var _varName_split = _sliced_to_array$f(varName.split("."), 2), agentChannelName = _varName_split[0], variableName = _varName_split[1];
    if (variableName) {
        var _state_agentChannelName;
        state[agentChannelName] = _object_spread_props$h(_object_spread$n({}, (_state_agentChannelName = state[agentChannelName]) !== null && _state_agentChannelName !== void 0 ? _state_agentChannelName : {}), _define_property$n({}, variableName, value));
    } else {
        state[agentChannelName] = value;
    }
    return state;
}
/**
 * Get agent variable group from graph.
 *
 * @param key
 * @param graph
 * @returns
 */ function getAgentVarGroup(key, graph) {
    var _agent_options;
    var node = graph.nodes.find(function(_) {
        return _.type === "agent" && _.key === key;
    });
    var variables = [];
    var varGroup = {
        group: {
            name: channelName(node.key),
            description: {
                en_US: agentLabel(node.entity)
            }
        },
        variables: variables
    };
    variables.push({
        name: "messages",
        type: XpertParameterTypeEnum.ARRAY_MESSAGE,
        description: {
            zh_Hans: "消息列表",
            en_US: "Message List"
        }
    });
    variables.push({
        name: "output",
        type: XpertParameterTypeEnum.STRING,
        description: {
            zh_Hans: "输出",
            en_US: "Output"
        }
    });
    variables.push({
        name: "error",
        type: XpertParameterTypeEnum.STRING,
        description: {
            zh_Hans: "错误",
            en_US: "Error"
        }
    });
    var agent = node.entity;
    if (((_agent_options = agent.options) === null || _agent_options === void 0 ? void 0 : _agent_options.structuredOutputMethod) && agent.outputVariables) {
        agent.outputVariables.forEach(function(variable) {
            variables.push({
                name: variable.name || "",
                type: variable.type,
                description: variable.description,
                item: variable.item
            });
        });
    }
    return varGroup;
}
// Swarm
/**
 * Get swarm partners of agent in team
 *
 * @param graph
 * @param agentKey
 */ function getSwarmPartners(graph, agentKey, partners, leaderKey) {
    var connections = graph.connections.filter(function(conn) {
        return conn.type === "agent" && conn.to === agentKey && (leaderKey ? conn.from !== leaderKey : true) && graph.connections.some(function(_) {
            return _.type === "agent" && _.to === conn.from && _.from === agentKey;
        });
    });
    connections.forEach(function(conn) {
        var key = conn.from;
        if (partners.indexOf(key) < 0) {
            partners.push(key);
            getSwarmPartners(graph, key, partners);
        }
    });
    return partners;
}
function getWorkflowTriggers(graph, from) {
    return graph.nodes.filter(function(node) {
        return node.type === "workflow" && node.entity.type === WorkflowNodeTypeEnum.TRIGGER && node.entity.from === from;
    });
}

function _define_property$m(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$m(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$m(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$g(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$g(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$g(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
/**
 * Non-internal types should remain the same as IntegrationEnum.
 */ var KnowledgeProviderEnum;
(function(KnowledgeProviderEnum) {
    KnowledgeProviderEnum["Internal"] = "internal";
})(KnowledgeProviderEnum || (KnowledgeProviderEnum = {}));
var KnowledgebaseTypeEnum;
(function(KnowledgebaseTypeEnum) {
    KnowledgebaseTypeEnum["Standard"] = "standard";
    KnowledgebaseTypeEnum["FAQ"] = "faq";
    KnowledgebaseTypeEnum["External"] = "external";
})(KnowledgebaseTypeEnum || (KnowledgebaseTypeEnum = {}));
/**
 * Knowledge bases created before the type discriminator was introduced are document knowledge bases.
 */ function isDocumentKnowledgebaseType(type) {
    return type == null || type === KnowledgebaseTypeEnum.Standard;
}
var DEFAULT_KNOWLEDGEBASE_FAQ_CONFIG = {
    indexMode: "question_only",
    questionIndexMode: "separate",
    negativeMatchMode: "exact"
};
var KnowledgebaseStatusEnum;
(function(KnowledgebaseStatusEnum) {
    KnowledgebaseStatusEnum["READY"] = "ready";
    KnowledgebaseStatusEnum["REBUILD_REQUIRED"] = "rebuild_required";
    KnowledgebaseStatusEnum["REBUILDING"] = "rebuilding";
    KnowledgebaseStatusEnum["REBUILD_FAILED"] = "rebuild_failed";
})(KnowledgebaseStatusEnum || (KnowledgebaseStatusEnum = {}));
var KnowledgeStructureEnum;
(function(KnowledgeStructureEnum) {
    KnowledgeStructureEnum["General"] = "general";
    KnowledgeStructureEnum["ParentChild"] = "parent-child";
    KnowledgeStructureEnum["QA"] = "qa";
})(KnowledgeStructureEnum || (KnowledgeStructureEnum = {}));
/**
 * Knowledgebase permission levels
 */ var KnowledgebasePermission;
(function(KnowledgebasePermission) {
    /**
     * Only visible to you
     * @default
     */ KnowledgebasePermission["Private"] = "private";
    /**
     * Visible to all members in the organization
     */ KnowledgebasePermission["Organization"] = "organization";
    /**
     * Visible to all members in the tenant
     */ KnowledgebasePermission["Public"] = "public";
})(KnowledgebasePermission || (KnowledgebasePermission = {}));
var DEFAULT_KNOWLEDGE_RRF_RANK_CONSTANT = 60;
var DEFAULT_KNOWLEDGE_RRF_WEIGHTS = {
    vector: 0.65,
    graph: 0.35,
    keyword: 0.3
};
var DEFAULT_KNOWLEDGEBASE_FAQ_RECALL = {
    mode: "hybrid",
    fusion: {
        mode: "weighted_rrf",
        rankConstant: DEFAULT_KNOWLEDGE_RRF_RANK_CONSTANT,
        weights: {
            vector: 0.7,
            keyword: 0.3,
            graph: 0
        }
    }
};
var KNOWLEDGEBASE_FAQ_RETRIEVAL_MODES = [
    "vector",
    "keyword",
    "hybrid"
];
/**
 * FAQ retrieval only uses question vectors and keyword indexes. Graph retrieval is not supported.
 */ function normalizeKnowledgebaseFAQRecall(recall) {
    var _recall_fusion, _recall_fusion1;
    var requestedMode = recall === null || recall === void 0 ? void 0 : recall.mode;
    var mode = KNOWLEDGEBASE_FAQ_RETRIEVAL_MODES.some(function(candidate) {
        return candidate === requestedMode;
    }) ? requestedMode : DEFAULT_KNOWLEDGEBASE_FAQ_RECALL.mode;
    var _recall_fusion2, _recall_fusion_mode, _recall_fusion_weights;
    return _object_spread_props$g(_object_spread$m({}, DEFAULT_KNOWLEDGEBASE_FAQ_RECALL, recall !== null && recall !== void 0 ? recall : {}), {
        mode: mode,
        fusion: _object_spread_props$g(_object_spread$m({}, DEFAULT_KNOWLEDGEBASE_FAQ_RECALL.fusion, (_recall_fusion2 = recall === null || recall === void 0 ? void 0 : recall.fusion) !== null && _recall_fusion2 !== void 0 ? _recall_fusion2 : {}), {
            mode: mode === "hybrid" ? "weighted_rrf" : (_recall_fusion_mode = recall === null || recall === void 0 ? void 0 : (_recall_fusion = recall.fusion) === null || _recall_fusion === void 0 ? void 0 : _recall_fusion.mode) !== null && _recall_fusion_mode !== void 0 ? _recall_fusion_mode : DEFAULT_KNOWLEDGEBASE_FAQ_RECALL.fusion.mode,
            weights: _object_spread_props$g(_object_spread$m({}, DEFAULT_KNOWLEDGEBASE_FAQ_RECALL.fusion.weights, (_recall_fusion_weights = recall === null || recall === void 0 ? void 0 : (_recall_fusion1 = recall.fusion) === null || _recall_fusion1 === void 0 ? void 0 : _recall_fusion1.weights) !== null && _recall_fusion_weights !== void 0 ? _recall_fusion_weights : {}), {
                graph: 0
            })
        })
    });
}
/**
 * Channel name for knowledgebase pipeline
 */ var KnowledgebaseChannel = channelName("knowledgebase");
/**
 * Task ID of a knowledgebase run
 */ var KnowledgeTask = "task_id";
/**
 * Specify the data source to run
 */ var KNOWLEDGE_SOURCES_NAME = "sources";
/** Workflow-state key carrying the requested document processing resume point. */ var KNOWLEDGE_PROCESSING_MODE_NAME = "processing_mode";
var KNOWLEDGE_DOCUMENTS_NAME = "documents";
var KNOWLEDGE_FOLDER_ID_NAME = "folder_id";
var KNOWLEDGE_STAGE_NAME = "stage";
var _retrieval_recall_contentScope;
/** Check the sources that can execute within the selected content scope. */ function hasEnabledKnowledgeRetrievalSource(retrieval) {
    var allowGraphRetrieval = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true, contentScope = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : function() {
        var _retrieval_recall;
        return (_retrieval_recall_contentScope = retrieval === null || retrieval === void 0 ? void 0 : (_retrieval_recall = retrieval.recall) === null || _retrieval_recall === void 0 ? void 0 : _retrieval_recall.contentScope) !== null && _retrieval_recall_contentScope !== void 0 ? _retrieval_recall_contentScope : "all";
    }();
    var _retrieval_recall, _retrieval_graphRag, _retrieval_graphRag1, _retrieval_recall1;
    var _retrieval_mode, _ref, _ref1;
    var mode = (_ref1 = (_ref = (_retrieval_mode = retrieval === null || retrieval === void 0 ? void 0 : retrieval.mode) !== null && _retrieval_mode !== void 0 ? _retrieval_mode : retrieval === null || retrieval === void 0 ? void 0 : (_retrieval_recall = retrieval.recall) === null || _retrieval_recall === void 0 ? void 0 : _retrieval_recall.mode) !== null && _ref !== void 0 ? _ref : retrieval === null || retrieval === void 0 ? void 0 : (_retrieval_graphRag = retrieval.graphRag) === null || _retrieval_graphRag === void 0 ? void 0 : _retrieval_graphRag.mode) !== null && _ref1 !== void 0 ? _ref1 : "vector";
    var graphAvailable = allowGraphRetrieval && contentScope !== "wiki" && (retrieval === null || retrieval === void 0 ? void 0 : (_retrieval_graphRag1 = retrieval.graphRag) === null || _retrieval_graphRag1 === void 0 ? void 0 : _retrieval_graphRag1.enabled) === true;
    if (mode === "graph") return graphAvailable;
    var _retrieval_recall_fusion;
    var fusion = (_retrieval_recall_fusion = retrieval === null || retrieval === void 0 ? void 0 : (_retrieval_recall1 = retrieval.recall) === null || _retrieval_recall1 === void 0 ? void 0 : _retrieval_recall1.fusion) !== null && _retrieval_recall_fusion !== void 0 ? _retrieval_recall_fusion : retrieval === null || retrieval === void 0 ? void 0 : retrieval.fusion;
    if (mode !== "hybrid" || (fusion === null || fusion === void 0 ? void 0 : fusion.mode) !== "weighted_rrf") {
        return true;
    }
    var weights = fusion.weights;
    var enabledWeights = [
        (weights === null || weights === void 0 ? void 0 : weights.vector) === undefined ? DEFAULT_KNOWLEDGE_RRF_WEIGHTS.vector : weights.vector,
        graphAvailable ? (weights === null || weights === void 0 ? void 0 : weights.graph) === undefined ? DEFAULT_KNOWLEDGE_RRF_WEIGHTS.graph : weights.graph : 0,
        (weights === null || weights === void 0 ? void 0 : weights.keyword) === undefined ? DEFAULT_KNOWLEDGE_RRF_WEIGHTS.keyword : weights.keyword
    ];
    return enabledWeights.every(function(weight) {
        return typeof weight === "number" && Number.isFinite(weight) && weight >= 0;
    }) && enabledWeights.some(function(weight) {
        return weight > 0;
    });
}

function _array_like_to_array$r(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$g(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$r(arr);
}
function _iterable_to_array$i(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$g() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$g(arr) {
    return _array_without_holes$g(arr) || _iterable_to_array$i(arr) || _unsupported_iterable_to_array$r(arr) || _non_iterable_spread$g();
}
function _unsupported_iterable_to_array$r(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$r(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$r(o, minLen);
}
var BUILTIN_KNOWLEDGE_PARSER = "builtin";
/** Only formats with a real builtin reader; unknown binary formats are not advertised as text. */ var BUILTIN_KNOWLEDGE_FILE_TYPES = [
    "pdf",
    "docx",
    "pptx",
    "epub",
    "md",
    "mdx",
    "markdown",
    "txt",
    "json",
    "csv",
    "xls",
    "xlsx",
    "apng",
    "avif",
    "bmp",
    "gif",
    "heic",
    "heif",
    "jpeg",
    "jpg",
    "png",
    "svg",
    "tif",
    "tiff",
    "webp"
];
var MIME_SUBTYPE_EXTENSIONS = {
    plain: "txt",
    "x-rtf": "rtf",
    msword: "doc",
    "vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "vnd.ms-word.document.macroenabled.12": "docm",
    "vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "vnd.ms-powerpoint": "ppt",
    "vnd.ms-powerpoint.presentation.macroenabled.12": "pptm",
    "vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "vnd.ms-excel": "xls",
    "vnd.ms-excel.sheet.macroenabled.12": "xlsm",
    "vnd.oasis.opendocument.presentation": "odp",
    "vnd.oasis.opendocument.spreadsheet": "ods",
    "vnd.oasis.opendocument.text": "odt",
    "epub+zip": "epub",
    "x-mimearchive": "mhtml",
    rfc822: "mhtml",
    "x-markdown": "markdown",
    "x-png": "png",
    mpeg: "mp3",
    "x-wav": "wav",
    "x-m4a": "m4a",
    "x-flac": "flac",
    "vnd.xmind.workbook": "xmind"
};
function knowledgeDocumentFileType(document) {
    var value = document.type && document.type !== "unknown" ? document.type : document.mimeType;
    var _value_split__trim_toLowerCase_replace_replace;
    var subtype = (_value_split__trim_toLowerCase_replace_replace = value === null || value === void 0 ? void 0 : value.split(";")[0].trim().toLowerCase().replace(/^.*\//, "").replace(/^\./, "")) !== null && _value_split__trim_toLowerCase_replace_replace !== void 0 ? _value_split__trim_toLowerCase_replace_replace : "";
    return Object.prototype.hasOwnProperty.call(MIME_SUBTYPE_EXTENSIONS, subtype) ? MIME_SUBTYPE_EXTENSIONS[subtype] : subtype;
}
function knowledgebaseParserSelection(config, documentType) {
    var format = knowledgeDocumentFileType({
        type: documentType
    });
    if ((config === null || config === void 0 ? void 0 : config.parsers) && Object.prototype.hasOwnProperty.call(config.parsers, format)) {
        var _config_parsers_format;
        return (_config_parsers_format = config.parsers[format]) !== null && _config_parsers_format !== void 0 ? _config_parsers_format : undefined;
    }
    return format === "pdf" ? config === null || config === void 0 ? void 0 : config.pdfParser : undefined;
}
/** Existing uploader/importer defaults plus capabilities advertised by installed document parsers.
 * Explicit caller restrictions remain authoritative; this does not grant builtin parsing support.
 */ function knowledgeUploadFileTypes(defaults, providers, accepts) {
    var candidates = (accepts === null || accepts === void 0 ? void 0 : accepts.length) ? accepts : _to_consumable_array$g(defaults).concat(_to_consumable_array$g(providers.flatMap(function(provider) {
        var _provider_supportedFileTypes;
        return (_provider_supportedFileTypes = provider.supportedFileTypes) !== null && _provider_supportedFileTypes !== void 0 ? _provider_supportedFileTypes : [];
    })));
    return _to_consumable_array$g(new Set(candidates.filter(function(type) {
        return /^\.?[a-z0-9]+$|^(application|text|image|audio|video)\/[a-z0-9.+-]+(?:;.*)?$/i.test(type.trim());
    }).map(function(type) {
        return knowledgeDocumentFileType({
            type: type
        });
    }).filter(function(type) {
        return /^[a-z0-9]+$/.test(type);
    })));
}

function _array_like_to_array$q(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$f(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$q(arr);
}
function _define_property$l(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$h(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$f() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$l(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$l(target, key, source[key]);
        });
    }
    return target;
}
function _to_consumable_array$f(arr) {
    return _array_without_holes$f(arr) || _iterable_to_array$h(arr) || _unsupported_iterable_to_array$q(arr) || _non_iterable_spread$f();
}
function _unsupported_iterable_to_array$q(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$q(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$q(o, minLen);
}
/** Only copy configured defaults; do not turn built-in defaults into document overrides. */ function knowledgebaseDocumentParserDefaults(config, documentType) {
    if (!config) return {};
    return _object_spread$l({}, config.spreadsheet ? {
        spreadsheet: _object_spread$l({}, config.spreadsheet)
    } : {}, config.tableMetadataRequirements !== undefined ? {
        tableMetadataRequirements: config.tableMetadataRequirements
    } : {}, config.questionGeneration ? {
        questionGeneration: _object_spread$l({}, config.questionGeneration)
    } : {}, config.chunkLanguageHint !== undefined ? {
        chunkLanguageHint: config.chunkLanguageHint
    } : {}, config.maxChunkTokens !== undefined ? {
        maxChunkTokens: config.maxChunkTokens
    } : {}, config.chunkSize != null ? {
        chunkSize: config.chunkSize
    } : {}, config.chunkOverlap != null ? {
        chunkOverlap: config.chunkOverlap
    } : {}, config.delimiter != null ? {
        delimiter: config.delimiter
    } : {}, config.textSplitterType ? {
        textSplitterType: config.textSplitterType
    } : {}, config.textSplitter || config.chunkSize != null || config.chunkOverlap != null ? {
        textSplitter: _object_spread$l({}, config.chunkSize != null ? {
            chunkSize: config.chunkSize
        } : {}, config.chunkOverlap != null ? {
            chunkOverlap: config.chunkOverlap
        } : {}, config.textSplitter)
    } : {}, config.separators ? {
        separators: _to_consumable_array$f(config.separators)
    } : {}, config.imageUnderstandingEnabled !== undefined ? {
        imageUnderstandingEnabled: config.imageUnderstandingEnabled
    } : {}, config.imageUnderstandingType ? {
        imageUnderstandingType: config.imageUnderstandingType
    } : {}, config.imageUnderstanding ? {
        imageUnderstanding: _object_spread$l({}, config.imageUnderstanding)
    } : {}, knowledgebaseParserSelection(config, documentType !== null && documentType !== void 0 ? documentType : ""));
}
/** Arrays are the canonical ordered format; retain the plugin's legacy comma syntax. */ function decodeKnowledgeSeparators(value) {
    var items = Array.isArray(value) ? value : value ? value.replace(/,,/g, "\x00").split(",").map(function(item) {
        return item.replace(/\0/g, ",");
    }) : [
        "\n\n",
        "\n",
        " ",
        ""
    ];
    return items.map(function(item) {
        return item.replace(/\\(n|r|t|\\)/g, function(_, escape) {
            switch(escape){
                case "n":
                    return "\n";
                case "r":
                    return "\r";
                case "t":
                    return "	";
                default:
                    return "\\";
            }
        });
    });
}

/**
 * Category of document source provider
 */ var DocumentSourceProviderCategoryEnum;
(function(DocumentSourceProviderCategoryEnum) {
    /**
     * Local files uploaded directly to the system
     */ DocumentSourceProviderCategoryEnum["LocalFile"] = "local-file";
    /**
     * Remote file systems, e.g. S3, FTP, etc.
     */ DocumentSourceProviderCategoryEnum["FileSystem"] = "file-system";
    /**
     * Online documents, e.g. public URLs, Google Docs, etc.
     */ DocumentSourceProviderCategoryEnum["OnlineDocument"] = "online-document";
    /**
     * Web crawling from public websites
     */ DocumentSourceProviderCategoryEnum["WebCrawl"] = "web-crawl";
    /**
     * Database connections, e.g. MySQL, PostgreSQL, etc.
     * @deprecated Planning
     */ DocumentSourceProviderCategoryEnum["Database"] = "database";
})(DocumentSourceProviderCategoryEnum || (DocumentSourceProviderCategoryEnum = {}));
function genPipelineSourceKey() {
    return letterStartSUID("Source_");
}
function genPipelineProcessorKey() {
    return letterStartSUID("Processor_");
}
function genPipelineChunkerKey() {
    return letterStartSUID("Chunker_");
}
function genPipelineUnderstandingKey() {
    return letterStartSUID("Understanding_");
}
function genPipelineKnowledgeBaseKey() {
    return letterStartSUID("KnowledgeBase_");
}

function _define_property$k(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$k(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$k(target, key, source[key]);
        });
    }
    return target;
}
/**
 * Import Type:
 * - file: local file
 * - web: web document
 * ...
 */ var DocumentTypeEnum;
(function(DocumentTypeEnum) {
    /**
     * Folder, parent of other documents
     */ DocumentTypeEnum["FOLDER"] = "folder";
    /**
     * Local files
     * @deprecated use DocumentSourceProviderCategoryEnum local file type instead
     */ DocumentTypeEnum["FILE"] = "file";
})(DocumentTypeEnum || (DocumentTypeEnum = {}));
var KDocumentSourceType = _object_spread$k({}, DocumentSourceProviderCategoryEnum, DocumentTypeEnum);
/**
 * Document type category, determine how to process the document.
 */ var KBDocumentCategoryEnum;
(function(KBDocumentCategoryEnum) {
    KBDocumentCategoryEnum["Text"] = "text";
    KBDocumentCategoryEnum["Image"] = "image";
    KBDocumentCategoryEnum["Audio"] = "audio";
    KBDocumentCategoryEnum["Video"] = "video";
    KBDocumentCategoryEnum["Sheet"] = "sheet";
    KBDocumentCategoryEnum["Other"] = "other";
})(KBDocumentCategoryEnum || (KBDocumentCategoryEnum = {}));
var KBDocumentStatusEnum;
(function(KBDocumentStatusEnum) {
    KBDocumentStatusEnum["WAITING"] = "waiting";
    KBDocumentStatusEnum["VALIDATE"] = "validate";
    KBDocumentStatusEnum["RUNNING"] = "running";
    KBDocumentStatusEnum["TRANSFORMED"] = "transformed";
    KBDocumentStatusEnum["SPLITTED"] = "splitted";
    KBDocumentStatusEnum["UNDERSTOOD"] = "understood";
    KBDocumentStatusEnum["EMBEDDING"] = "embedding";
    KBDocumentStatusEnum["CANCEL"] = "cancel";
    KBDocumentStatusEnum["FINISH"] = "finish";
    KBDocumentStatusEnum["ERROR"] = "error";
})(KBDocumentStatusEnum || (KBDocumentStatusEnum = {}));
var KNOWLEDGE_DOCUMENT_AGENT_WRITER_TYPE = "agent-writer";
/** Agent publications are inspectable; internal Wiki/FAQ backing indexes stay hidden. */ function isKnowledgeDocumentVisible(metadata) {
    return (metadata === null || metadata === void 0 ? void 0 : metadata.systemManaged) !== true || metadata.systemManagedType === KNOWLEDGE_DOCUMENT_AGENT_WRITER_TYPE;
}
function isDocumentSheet(type) {
    return [
        "csv",
        "xls",
        "xlsx",
        "ods",
        "vnd.ms-excel",
        "vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ].includes(type);
}
function isImageType(type) {
    return [
        "jpg",
        "jpeg",
        "png",
        "gif",
        "bmp",
        "tiff",
        "svg",
        "webp"
    ].includes(type);
}
function isVideoType(type) {
    return [
        "mp4",
        "avi",
        "mov",
        "wmv",
        "flv",
        "mkv",
        "webm"
    ].includes(type);
}
function isAudioType(type) {
    return [
        "mp3",
        "wav",
        "aac",
        "flac",
        "ogg",
        "m4a"
    ].includes(type);
}
function classificateDocumentCategory(entity) {
    return isDocumentSheet(entity.type) ? KBDocumentCategoryEnum.Sheet : isImageType(entity.type) ? KBDocumentCategoryEnum.Image : isVideoType(entity.type) ? KBDocumentCategoryEnum.Video : isAudioType(entity.type) ? KBDocumentCategoryEnum.Audio : KBDocumentCategoryEnum.Text;
}
/**
 * System standard Metadata field definition constants
 * It can be used for rendering, validation, sorting, displaying descriptions, etc.
 */ var STANDARD_METADATA_FIELDS = [
    // Document Info
    {
        group: {
            en_US: "Document Info",
            zh_Hans: "文档信息"
        },
        fields: [
            {
                key: "title",
                label: {
                    en_US: "Original File Name",
                    zh_Hans: "原始文件名称"
                },
                type: "string"
            }
        ]
    },
    // Technical Parameters
    {
        group: {
            en_US: "Technical Parameters",
            zh_Hans: "技术参数"
        },
        fields: [
            {
                key: "tokens",
                label: {
                    en_US: "Tokens",
                    zh_Hans: "词元"
                },
                type: "number"
            }
        ]
    }
];

function isNativeKnowledgeTableDocument(document) {
    var _document_type, _document_parserConfig_spreadsheet, _document_parserConfig, _document_parserConfig1;
    var type = (_document_type = document.type) === null || _document_type === void 0 ? void 0 : _document_type.replace(/^\./, "").toLowerCase();
    return document.category === KBDocumentCategoryEnum.Sheet && [
        "csv",
        "xls",
        "xlsx",
        "vnd.ms-excel",
        "vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ].includes(type !== null && type !== void 0 ? type : "") && !document.sourceConfig && ((_document_parserConfig = document.parserConfig) === null || _document_parserConfig === void 0 ? void 0 : (_document_parserConfig_spreadsheet = _document_parserConfig.spreadsheet) === null || _document_parserConfig_spreadsheet === void 0 ? void 0 : _document_parserConfig_spreadsheet.interpretation) !== "form_document" && (!((_document_parserConfig1 = document.parserConfig) === null || _document_parserConfig1 === void 0 ? void 0 : _document_parserConfig1.transformerType) || document.parserConfig.transformerType === "default" || document.parserConfig.transformerType === "builtin");
}
/** Parse persisted JSON at the read boundary before using the shared result contract. */ function isKnowledgeTableMetadata(value) {
    return !!value && typeof value === "object" && "schemaVersion" in value && value.schemaVersion === 1 && "status" in value && typeof value.status === "string" && [
        "generating",
        "generated",
        "ready",
        "failed",
        "skipped"
    ].includes(value.status) && "inputHash" in value && typeof value.inputHash === "string" && (!("sourceFingerprint" in value) || value.sourceFingerprint === undefined || typeof value.sourceFingerprint === "string") && (!("language" in value) || value.language === undefined || typeof value.language === "string" && /^[a-z]{2,3}$/.test(value.language)) && "generationId" in value && typeof value.generationId === "string" && "updatedAt" in value && typeof value.updatedAt === "string" && (!("resultHash" in value) || value.resultHash === undefined || typeof value.resultHash === "string") && (!("appliedResultHash" in value) || value.appliedResultHash === undefined || typeof value.appliedResultHash === "string") && (!("error" in value) || value.error === undefined || typeof value.error === "string") && (!("completedColumns" in value) || value.completedColumns === undefined || !!value.completedColumns && typeof value.completedColumns === "object" && !Array.isArray(value.completedColumns) && Object.values(value.completedColumns).every(function(columns) {
        return Array.isArray(columns) && columns.every(function(column) {
            return typeof column === "string";
        });
    })) && (!("reason" in value) || value.reason === undefined || value.reason === "missing_model" || value.reason === "no_data" || value.reason === "unsupported") && "tables" in value && Array.isArray(value.tables) && value.tables.every(isKnowledgeTableResult);
}
function isKnowledgeTableResult(value) {
    return !!value && typeof value === "object" && "tableId" in value && typeof value.tableId === "string" && "sheetName" in value && typeof value.sheetName === "string" && "range" in value && typeof value.range === "string" && "rowCount" in value && typeof value.rowCount === "number" && Number.isSafeInteger(value.rowCount) && value.rowCount >= 0 && (!("headerRow" in value) || value.headerRow === undefined || typeof value.headerRow === "number" && Number.isSafeInteger(value.headerRow)) && "summary" in value && typeof value.summary === "string" && "columns" in value && Array.isArray(value.columns) && value.columns.every(isKnowledgeTableColumnDescription);
}
function isKnowledgeTableColumnDescription(value) {
    return !!value && typeof value === "object" && (!("valueType" in value) || value.valueType === undefined || value.valueType === "boolean") && "columnId" in value && typeof value.columnId === "string" && "key" in value && typeof value.key === "string" && "label" in value && typeof value.label === "string" && "column" in value && typeof value.column === "number" && Number.isSafeInteger(value.column) && value.column > 0 && "description" in value && typeof value.description === "string" && (!("unit" in value) || value.unit === undefined || typeof value.unit === "string") && (!("valueMeanings" in value) || value.valueMeanings === undefined || typeof value.valueMeanings === "string");
}

/** Shared fallback for ordinary documents without an explicitly configured strategy. */ var DEFAULT_KNOWLEDGE_TEXT_SPLITTER = "auto";
/** Shared revision for structured execution diagnostics and cache invalidation. */ var KNOWLEDGE_CHUNKING_ALGORITHM_VERSION = 5;

var KNOWLEDGE_FAQ_STANDARD_QUESTION_MAX_LENGTH = 500;
var KNOWLEDGE_FAQ_SIMILAR_QUESTION_MAX_COUNT = 10;
var KNOWLEDGE_FAQ_SIMILAR_QUESTION_MAX_LENGTH = 500;
var KNOWLEDGE_FAQ_NEGATIVE_QUESTION_MAX_COUNT = 10;
var KNOWLEDGE_FAQ_NEGATIVE_QUESTION_MAX_LENGTH = 500;
var KNOWLEDGE_FAQ_ANSWER_BLOCK_MAX_COUNT = 5;
var KNOWLEDGE_FAQ_ANSWER_TOTAL_MAX_LENGTH = 10000;
var KNOWLEDGE_FAQ_MAX_LOGICAL_VECTOR_COUNT = 1 + KNOWLEDGE_FAQ_SIMILAR_QUESTION_MAX_COUNT + KNOWLEDGE_FAQ_ANSWER_BLOCK_MAX_COUNT;

var KNOWLEDGE_WIKI_SCHEMA_VERSION = 1;
var KNOWLEDGE_WIKI_MAX_CUSTOM_INSTRUCTION_LENGTH = 4000;
var DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG = {
    enabled: false,
    extractionGranularity: "standard",
    contentGenerationRequirements: "",
    extractionFocus: ""
};
function normalizeKnowledgebaseWikiConfig(config) {
    var _config_enabled, _config_extractionGranularity, _config_contentGenerationRequirements, _config_extractionFocus;
    return {
        enabled: (_config_enabled = config === null || config === void 0 ? void 0 : config.enabled) !== null && _config_enabled !== void 0 ? _config_enabled : DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG.enabled,
        extractionGranularity: (_config_extractionGranularity = config === null || config === void 0 ? void 0 : config.extractionGranularity) !== null && _config_extractionGranularity !== void 0 ? _config_extractionGranularity : DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG.extractionGranularity,
        contentGenerationRequirements: (_config_contentGenerationRequirements = config === null || config === void 0 ? void 0 : config.contentGenerationRequirements) !== null && _config_contentGenerationRequirements !== void 0 ? _config_contentGenerationRequirements : DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG.contentGenerationRequirements,
        extractionFocus: (_config_extractionFocus = config === null || config === void 0 ? void 0 : config.extractionFocus) !== null && _config_extractionFocus !== void 0 ? _config_extractionFocus : DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG.extractionFocus
    };
}
var KNOWLEDGE_WIKI_DOCUMENT_STATUS_BATCH_SIZE = 100;
var KNOWLEDGE_WIKI_MAX_ALIASES = 20;
var KNOWLEDGE_WIKI_MAX_FACTS = 100;
var KNOWLEDGE_WIKI_MAX_SUGGESTED_LINKS = 50;
var KNOWLEDGE_WIKI_MAX_SOURCE_CHUNKS_PER_FACT = 50;
var KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH = 512;
var KNOWLEDGE_WIKI_MAX_SUMMARY_LENGTH = 8000;
var KNOWLEDGE_WIKI_MAX_FACT_LENGTH = 4000;
function isBoundedString(value, maxLength) {
    var allowEmpty = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    return typeof value === "string" && value.length <= maxLength && (allowEmpty || value.trim().length > 0);
}
function isBoundedStringArray(value, maxItems, maxItemLength) {
    return Array.isArray(value) && value.length <= maxItems && value.every(function(item) {
        return isBoundedString(item, maxItemLength);
    });
}
function isKnowledgeWikiFact(value) {
    var aggregated = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    return !!value && typeof value === "object" && "text" in value && isBoundedString(value.text, KNOWLEDGE_WIKI_MAX_FACT_LENGTH) && "sourceChunkIds" in value && isBoundedStringArray(value.sourceChunkIds, aggregated ? Infinity : KNOWLEDGE_WIKI_MAX_SOURCE_CHUNKS_PER_FACT, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH) && value.sourceChunkIds.length > 0;
}
function isKnowledgeWikiSuggestedLink(value) {
    return !!value && typeof value === "object" && "targetType" in value && isWikiPageType(value.targetType) && "targetCanonicalName" in value && isBoundedString(value.targetCanonicalName, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH) && (!("label" in value) || value.label === undefined || isBoundedString(value.label, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH));
}
function isKnowledgeWikiPageContributionPayload(value) {
    return isWikiContribution(value, false);
}
function isKnowledgeWikiPageSourcePayload(value) {
    return isWikiContribution(value, true);
}
function isWikiContribution(value, aggregated) {
    return !!value && typeof value === "object" && "schemaVersion" in value && value.schemaVersion === KNOWLEDGE_WIKI_SCHEMA_VERSION && "pageType" in value && (value.pageType === "summary" || value.pageType === "entity" || value.pageType === "concept") && "canonicalName" in value && isBoundedString(value.canonicalName, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH) && "aliases" in value && isBoundedStringArray(value.aliases, aggregated ? Infinity : KNOWLEDGE_WIKI_MAX_ALIASES, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH) && "summary" in value && isBoundedString(value.summary, aggregated ? Infinity : KNOWLEDGE_WIKI_MAX_SUMMARY_LENGTH) && "facts" in value && Array.isArray(value.facts) && (aggregated || value.facts.length <= KNOWLEDGE_WIKI_MAX_FACTS) && value.facts.every(function(fact) {
        return isKnowledgeWikiFact(fact, aggregated);
    }) && "suggestedLinks" in value && Array.isArray(value.suggestedLinks) && (aggregated || value.suggestedLinks.length <= KNOWLEDGE_WIKI_MAX_SUGGESTED_LINKS) && value.suggestedLinks.every(isKnowledgeWikiSuggestedLink);
}
function isWikiPageType(value) {
    return value === "summary" || value === "entity" || value === "concept" || value === "index";
}
function isWikiProjectionStatus(value) {
    return value === "pending" || value === "ready" || value === "failed" || value === "disabled";
}
function isKnowledgeWikiChunkMetadata(value) {
    return !!value && typeof value === "object" && "chunkId" in value && typeof value.chunkId === "string" && "contentKind" in value && value.contentKind === "wiki" && "wikiPageId" in value && typeof value.wikiPageId === "string" && "wikiPageVersionId" in value && typeof value.wikiPageVersionId === "string" && "wikiPageKey" in value && typeof value.wikiPageKey === "string" && "wikiPageType" in value && isWikiPageType(value.wikiPageType) && "wikiRevision" in value && typeof value.wikiRevision === "number" && Number.isInteger(value.wikiRevision) && value.wikiRevision >= 0 && "sectionAnchor" in value && typeof value.sectionAnchor === "string" && "projectionStatus" in value && isWikiProjectionStatus(value.projectionStatus);
}
var KNOWLEDGE_WIKI_DEFAULT_PAGE_SIZE = 50;
var KNOWLEDGE_WIKI_MAX_PAGE_SIZE = 100;
var KNOWLEDGE_WIKI_MAX_SEARCH_LENGTH = 200;
var KNOWLEDGE_WIKI_FAILED_CONTENT_RETENTION_DAYS = 7;
var KNOWLEDGE_WIKI_OPERATION_RETENTION_DAYS = 30;
var KNOWLEDGE_WIKI_DELETION_RECEIPT_RETENTION_DAYS = 90;
var KNOWLEDGE_WIKI_STALE_VECTOR_CLEANUP_SLO_HOURS = 24;

var KNOWLEDGE_FILTER_VERSION = 2;
var KNOWLEDGE_FILTER_MAX_DEPTH = 3;
var KNOWLEDGE_FILTER_MAX_CONDITIONS = 20;
var KNOWLEDGE_FILTER_MAX_SET_VALUES = 100;
var KNOWLEDGE_FILTER_MAX_STRING_LENGTH = 512;
var KNOWLEDGE_SYSTEM_FILTER_FIELDS = [
    "document.fileName",
    "document.folderPath",
    "document.fileExtension",
    "document.mimeType",
    "document.category",
    "document.sourceType",
    "document.createdAt",
    "document.updatedAt"
];

/**
 * AI feature permissions used by endpoint declarations and capability checks.
 * Grants do not imply other permissions or replace resource scope and entitlement checks.
 */ var AIPermissionsEnum;
(function(AIPermissionsEnum) {
    /**
     * Manage knowledge bases, documents, FAQs and related configuration in the authorized scope.
     * Runtime retrieval through an Assistant uses its resource authorization separately.
     */ AIPermissionsEnum["KNOWLEDGEBASE_EDIT"] = "KNOWLEDGEBASE_EDIT";
    /**
     * Legacy model-related viewing entry points; marked deprecated in the role editor.
     * Does not authorize provider configuration APIs, which require COPILOT_EDIT.
     */ AIPermissionsEnum["COPILOT_VIEW"] = "COPILOT_VIEW";
    /** Manage model providers, credentials, models and Copilot configuration in the authorized scope. */ AIPermissionsEnum["COPILOT_EDIT"] = "COPILOT_EDIT";
    /** Read model usage monitoring data in the authorized scope; does not grant model configuration rights. */ AIPermissionsEnum["MODEL_USAGE_MONITOR"] = "MODEL_USAGE_MONITOR";
    /** Administer membership plans, user entitlements, quotas and membership records in the authorized scope. */ AIPermissionsEnum["MEMBERSHIP_EDIT"] = "MEMBERSHIP_EDIT";
    /** Access the current user's membership, billing overview and usage; does not grant membership administration. */ AIPermissionsEnum["MEMBERSHIP_USE"] = "MEMBERSHIP_USE";
    /** Read administrative model-access requests, grants and audit events without approving or changing grants. */ AIPermissionsEnum["MODEL_ACCESS_REQUEST_VIEW"] = "MODEL_ACCESS_REQUEST_VIEW";
    /** Approve/reject model-access requests and extend/revoke model grants, subject to scope and workflow checks. */ AIPermissionsEnum["MODEL_ACCESS_REQUEST_EDIT"] = "MODEL_ACCESS_REQUEST_EDIT";
    /**
     * Use model gateway self-service: catalog, requests, own grants, API keys and call records.
     * Model calls and execution sessions still require valid credentials, model grants and entitlements.
     */ AIPermissionsEnum["MODEL_GATEWAY_USE"] = "MODEL_GATEWAY_USE";
    /**
     * Administer gateway settings, scoped API keys and call records.
     * Does not imply MODEL_GATEWAY_USE or permission to configure model providers.
     */ AIPermissionsEnum["MODEL_GATEWAY_MANAGE"] = "MODEL_GATEWAY_MANAGE";
    /** Billing product-management permission contract; billing endpoints must explicitly enforce it. */ AIPermissionsEnum["BILLING_PRODUCT_EDIT"] = "BILLING_PRODUCT_EDIT";
    /** Refund permission contract; billing endpoints must enforce it alongside refund eligibility checks. */ AIPermissionsEnum["BILLING_REFUND"] = "BILLING_REFUND";
    /** Payment-provider configuration permission contract; payment endpoints must explicitly enforce it. */ AIPermissionsEnum["PAYMENT_PROVIDER_EDIT"] = "PAYMENT_PROVIDER_EDIT";
    /**
     * Read authorized authoring resources; does not unlock the complete Studio configuration UI.
     * Published Assistant runtime access is separate.
     */ AIPermissionsEnum["XPERT_VIEW"] = "XPERT_VIEW";
    /**
     * Manage tenant/shared authoring workspaces within the current scope.
     * Resource authorization and action permissions such as XPERT_EDIT still apply.
     */ AIPermissionsEnum["XPERT_WORKSPACE_MANAGE"] = "XPERT_WORKSPACE_MANAGE";
    /**
     * Create, edit or publish Assistants and access authoring configuration APIs.
     * Requires workspace authorization; workspace reading and chat use have separate permissions.
     */ AIPermissionsEnum["XPERT_EDIT"] = "XPERT_EDIT";
    /**
     * Use assigned applications and access their delivery status/retry operations.
     * Does not grant installation or authoring; chat also requires CHAT_VIEW and Assistant access.
     */ AIPermissionsEnum["APPLICATION_USE"] = "APPLICATION_USE";
    /**
     * Initialize or update plugin applications and operate managed application deliveries.
     * Organization membership and installation/service scope restrictions still apply.
     */ AIPermissionsEnum["APPLICATION_INSTALL"] = "APPLICATION_INSTALL";
    /** Read projects and their business views subject to project membership and resource authorization. */ AIPermissionsEnum["XPERT_PROJECT_VIEW"] = "XPERT_PROJECT_VIEW";
    /** Create or duplicate projects; project type and Assistant access checks still apply. */ AIPermissionsEnum["XPERT_PROJECT_CREATE"] = "XPERT_PROJECT_CREATE";
    /** Edit project content and perform contribution actions when the project's resource policy permits them. */ AIPermissionsEnum["XPERT_PROJECT_EDIT"] = "XPERT_PROJECT_EDIT";
    /** Manage projects, membership and pipeline configuration subject to project management authorization. */ AIPermissionsEnum["XPERT_PROJECT_MANAGE"] = "XPERT_PROJECT_MANAGE";
    /**
     * Run authorized published Assistants and use chat, conversation and runtime business APIs.
     * This includes execution and authorized writes, not just viewing; it grants no authoring access.
     */ AIPermissionsEnum["CHAT_VIEW"] = "CHAT_VIEW";
    /** Read Agent Evolution dashboards, learning records, evaluations and change history in the authorized scope. */ AIPermissionsEnum["EVOLUTION_VIEW"] = "EVOLUTION_VIEW";
    /** Manage Agent Evolution proposals, evaluations, approvals and releases, subject to governance checks. */ AIPermissionsEnum["EVOLUTION_MANAGE"] = "EVOLUTION_MANAGE";
})(AIPermissionsEnum || (AIPermissionsEnum = {}));

/**
 * Corresponds to the status of Run in [Agent Protocol](https://github.com/langchain-ai/agent-protocol).
 */ var XpertAgentExecutionStatusEnum;
(function(XpertAgentExecutionStatusEnum) {
    XpertAgentExecutionStatusEnum["RUNNING"] = "running";
    XpertAgentExecutionStatusEnum["SUCCESS"] = "success";
    XpertAgentExecutionStatusEnum["ERROR"] = "error";
    XpertAgentExecutionStatusEnum["PENDING"] = "pending";
    XpertAgentExecutionStatusEnum["TIMEOUT"] = "timeout";
    XpertAgentExecutionStatusEnum["INTERRUPTED"] = "interrupted";
})(XpertAgentExecutionStatusEnum || (XpertAgentExecutionStatusEnum = {}));

var SANDBOX_TERMINAL_NAMESPACE = "sandbox-terminal";
var SandboxTerminalClientEvent;
(function(SandboxTerminalClientEvent) {
    SandboxTerminalClientEvent["Open"] = "open";
    SandboxTerminalClientEvent["Input"] = "input";
    SandboxTerminalClientEvent["Resize"] = "resize";
    SandboxTerminalClientEvent["Close"] = "close";
})(SandboxTerminalClientEvent || (SandboxTerminalClientEvent = {}));
var SandboxTerminalServerEvent;
(function(SandboxTerminalServerEvent) {
    SandboxTerminalServerEvent["Opened"] = "opened";
    SandboxTerminalServerEvent["Output"] = "output";
    SandboxTerminalServerEvent["Exit"] = "exit";
    SandboxTerminalServerEvent["Error"] = "error";
    SandboxTerminalServerEvent["Closed"] = "closed";
})(SandboxTerminalServerEvent || (SandboxTerminalServerEvent = {}));
var SandboxTerminalClosedReason;
(function(SandboxTerminalClosedReason) {
    SandboxTerminalClosedReason["ClientClosed"] = "client_closed";
    SandboxTerminalClosedReason["Error"] = "error";
    SandboxTerminalClosedReason["OpenFailed"] = "open_failed";
    SandboxTerminalClosedReason["ProcessExited"] = "process_exited";
    SandboxTerminalClosedReason["SocketDisconnected"] = "socket_disconnected";
    SandboxTerminalClosedReason["UnsupportedProvider"] = "unsupported_provider";
})(SandboxTerminalClosedReason || (SandboxTerminalClosedReason = {}));
var SandboxTerminalErrorCode;
(function(SandboxTerminalErrorCode) {
    SandboxTerminalErrorCode["CloseFailed"] = "close_failed";
    SandboxTerminalErrorCode["ComputerDesktopRequired"] = "computer_desktop_required";
    SandboxTerminalErrorCode["ConversationNotFound"] = "conversation_not_found";
    SandboxTerminalErrorCode["ConversationRequired"] = "conversation_required";
    SandboxTerminalErrorCode["InputFailed"] = "input_failed";
    SandboxTerminalErrorCode["OpenFailed"] = "open_failed";
    SandboxTerminalErrorCode["ProviderUnavailable"] = "provider_unavailable";
    SandboxTerminalErrorCode["ResizeFailed"] = "resize_failed";
    SandboxTerminalErrorCode["SandboxDisabled"] = "sandbox_disabled";
    SandboxTerminalErrorCode["SessionNotFound"] = "session_not_found";
    SandboxTerminalErrorCode["UnsupportedProvider"] = "unsupported_provider";
})(SandboxTerminalErrorCode || (SandboxTerminalErrorCode = {}));

var SANDBOX_MANAGED_SERVICE_STATUSES = [
    "starting",
    "running",
    "stopping",
    "stopped",
    "failed",
    "lost"
];
var SANDBOX_MANAGED_SERVICE_TRANSPORT_MODES = [
    "none",
    "http"
];
var SandboxManagedServiceErrorCode;
(function(SandboxManagedServiceErrorCode) {
    SandboxManagedServiceErrorCode["ConversationNotFound"] = "conversation_not_found";
    SandboxManagedServiceErrorCode["ConversationRequired"] = "conversation_required";
    SandboxManagedServiceErrorCode["PortRequired"] = "port_required";
    SandboxManagedServiceErrorCode["ProviderUnavailable"] = "provider_unavailable";
    SandboxManagedServiceErrorCode["PreviewUnavailable"] = "preview_unavailable";
    SandboxManagedServiceErrorCode["SandboxDisabled"] = "sandbox_disabled";
    SandboxManagedServiceErrorCode["ServiceNameConflict"] = "service_name_conflict";
    SandboxManagedServiceErrorCode["ServiceNotFound"] = "service_not_found";
    SandboxManagedServiceErrorCode["ServiceStartFailed"] = "service_start_failed";
    SandboxManagedServiceErrorCode["ServiceStopFailed"] = "service_stop_failed";
    SandboxManagedServiceErrorCode["UnsupportedProvider"] = "unsupported_provider";
})(SandboxManagedServiceErrorCode || (SandboxManagedServiceErrorCode = {}));

var ToolParameterType;
(function(ToolParameterType) {
    ToolParameterType["STRING"] = "string";
    ToolParameterType["NUMBER"] = "number";
    ToolParameterType["BOOLEAN"] = "boolean";
    ToolParameterType["ARRAY"] = "array";
    ToolParameterType["SELECT"] = "select";
    ToolParameterType["SECRET_INPUT"] = "secret-input";
    ToolParameterType["FILE"] = "file";
})(ToolParameterType || (ToolParameterType = {}));
var ToolParameterForm;
(function(ToolParameterForm) {
    ToolParameterForm["SCHEMA"] = "schema";
    ToolParameterForm["FORM"] = "form";
    ToolParameterForm["LLM"] = "llm"; // will be set by LLM
})(ToolParameterForm || (ToolParameterForm = {}));
var TOOL_NAME_REGEX = /^[a-zA-Z0-9_-]+$/;
// Helper functions for tools
/**
 *
 * @param tool Tool
 * @param disableToolDefault Is default disable tools
 * @returns Tool is enabled?
 */ function isToolEnabled(tool) {
    var disableToolDefault = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    var disabled = tool.disabled;
    if (disabled == null && tool.enabled != null) {
        disabled = !tool.enabled;
    }
    if (disabled == null) {
        disabled = disableToolDefault;
    }
    return !disabled;
}
/**
 * Tool is enabled?
 *
 * @deprecated use isToolEnabled
 */ function isEnableTool(tool, toolset) {
    var disabled = tool.disabled;
    if (disabled == null && tool.enabled != null) {
        disabled = !tool.enabled;
    }
    if (disabled == null) {
        var _toolset_options;
        disabled = (_toolset_options = toolset.options) === null || _toolset_options === void 0 ? void 0 : _toolset_options.disableToolDefault;
    }
    return !disabled;
}
function getEnabledTools(toolset) {
    var _toolset_options, _toolset_options1, _toolset_tools;
    if (!toolset) return null;
    var disableToolDefault = (_toolset_options = toolset.options) === null || _toolset_options === void 0 ? void 0 : _toolset_options.disableToolDefault;
    var positions = toolset === null || toolset === void 0 ? void 0 : (_toolset_options1 = toolset.options) === null || _toolset_options1 === void 0 ? void 0 : _toolset_options1.toolPositions;
    var tools = toolset === null || toolset === void 0 ? void 0 : (_toolset_tools = toolset.tools) === null || _toolset_tools === void 0 ? void 0 : _toolset_tools.filter(function(_) {
        return isToolEnabled(_, disableToolDefault);
    });
    return positions && tools ? tools.sort(function(a, b) {
        var _positions_a_name, _positions_b_name;
        return ((_positions_a_name = positions[a.name]) !== null && _positions_a_name !== void 0 ? _positions_a_name : Infinity) - ((_positions_b_name = positions[b.name]) !== null && _positions_b_name !== void 0 ? _positions_b_name : Infinity);
    }) : tools;
}
function getToolLabel(tool) {
    var _tool_schema;
    if (!tool) return "";
    if (tool.label) {
        return tool.label;
    }
    var identity = (_tool_schema = tool.schema) === null || _tool_schema === void 0 ? void 0 : _tool_schema.identity;
    if (identity) {
        return identity.label || tool.name || "";
    }
    return tool.name || "";
}

var XpertToolsetCategoryEnum;
(function(XpertToolsetCategoryEnum) {
    XpertToolsetCategoryEnum["BUILTIN"] = "builtin";
    XpertToolsetCategoryEnum["API"] = "api";
    /**
     * [Anthropic Model Context Protocol (MCP)](https://modelcontextprotocol.io/introduction)
     */ XpertToolsetCategoryEnum["MCP"] = "mcp";
    /**
     * @deprecated
     */ XpertToolsetCategoryEnum["WORKFLOW"] = "workflow";
})(XpertToolsetCategoryEnum || (XpertToolsetCategoryEnum = {}));
var CredentialsType;
(function(CredentialsType) {
    CredentialsType["SECRET_INPUT"] = "secret-input";
    CredentialsType["TEXT_INPUT"] = "text-input";
    CredentialsType["SELECT"] = "select";
    CredentialsType["REMOTE_SELECT"] = "remote-select";
    CredentialsType["COPILOT_MODEL"] = "copilot-model";
    CredentialsType["BOOLEAN"] = "boolean";
    CredentialsType["INT"] = "int";
    CredentialsType["NUMBER"] = "number";
})(CredentialsType || (CredentialsType = {}));
var ApiProviderSchemaType;
(function(ApiProviderSchemaType) {
    /**
     * Enum class for api provider schema type.
     */ ApiProviderSchemaType["OPENAPI"] = "openapi";
    ApiProviderSchemaType["SWAGGER"] = "swagger";
    ApiProviderSchemaType["OPENAI_PLUGIN"] = "openai_plugin";
    ApiProviderSchemaType["OPENAI_ACTIONS"] = "openai_actions";
})(ApiProviderSchemaType || (ApiProviderSchemaType = {}));
var ToolTagEnum;
(function(ToolTagEnum) {
    ToolTagEnum["SEARCH"] = "search";
    ToolTagEnum["IMAGE"] = "image";
    ToolTagEnum["VIDEOS"] = "videos";
    ToolTagEnum["WEATHER"] = "weather";
    ToolTagEnum["FINANCE"] = "finance";
    ToolTagEnum["DESIGN"] = "design";
    ToolTagEnum["TRAVEL"] = "travel";
    ToolTagEnum["SOCIAL"] = "social";
    ToolTagEnum["NEWS"] = "news";
    ToolTagEnum["MEDICAL"] = "medical";
    ToolTagEnum["PRODUCTIVITY"] = "productivity";
    ToolTagEnum["EDUCATION"] = "education";
    ToolTagEnum["BUSINESS"] = "business";
    ToolTagEnum["ENTERTAINMENT"] = "entertainment";
    ToolTagEnum["UTILITIES"] = "utilities";
    ToolTagEnum["ANALYSIS"] = "analysis";
    ToolTagEnum["SANDBOX"] = "sandbox";
    ToolTagEnum["PROJECT"] = "project";
    ToolTagEnum["AGENT"] = "agent";
    ToolTagEnum["OTHER"] = "other";
})(ToolTagEnum || (ToolTagEnum = {}));

/** Normalizes missing or unknown persisted values to the secure `private` default. */ function getXpertWorkspaceVisibility(workspace) {
    var _workspace_settings_access, _workspace_settings;
    var visibility = workspace === null || workspace === void 0 ? void 0 : (_workspace_settings = workspace.settings) === null || _workspace_settings === void 0 ? void 0 : (_workspace_settings_access = _workspace_settings.access) === null || _workspace_settings_access === void 0 ? void 0 : _workspace_settings_access.visibility;
    return visibility === "tenant-shared" || visibility === "organization-shared" ? visibility : "private";
}
function isTenantSharedXpertWorkspace(workspace) {
    return getXpertWorkspaceVisibility(workspace) === "tenant-shared";
}
/**
 * Returns whether an organization workspace is intentionally shared with all
 * current organization members instead of an explicit member list.
 */ function isOrganizationSharedXpertWorkspace(workspace) {
    return getXpertWorkspaceVisibility(workspace) === "organization-shared";
}

/**
 * Table status
 */ var XpertTableStatus;
(function(XpertTableStatus) {
    XpertTableStatus["DRAFT"] = "draft";
    XpertTableStatus["READY"] = "ready";
    XpertTableStatus["PENDING_ACTIVATION"] = "pendingActivation";
    XpertTableStatus["ACTIVE"] = "active";
    XpertTableStatus["NEEDS_MIGRATION"] = "needsMigration";
    XpertTableStatus["DEPRECATED"] = "deprecated";
    XpertTableStatus["ERROR"] = "error";
})(XpertTableStatus || (XpertTableStatus = {}));
function genXpertDBInsertKey() {
    return letterStartSUID("DBInsert_");
}
function genXpertDBUpdateKey() {
    return letterStartSUID("DBUpdate_");
}
function genXpertDBDeleteKey() {
    return letterStartSUID("DBDelete_");
}
function genXpertDBQueryKey() {
    return letterStartSUID("DBQuery_");
}
function genXpertDBSqlKey() {
    return letterStartSUID("DBSql_");
}

/** Stable placement scopes declared by plugin application contributions. */ function _array_like_to_array$p(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$e(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$p(arr);
}
function _iterable_to_array$g(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$e() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$e(arr) {
    return _array_without_holes$e(arr) || _iterable_to_array$g(arr) || _unsupported_iterable_to_array$p(arr) || _non_iterable_spread$e();
}
function _unsupported_iterable_to_array$p(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$p(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$p(o, minLen);
}
var PLUGIN_APPLICATION_SCOPE = {
    TENANT: "tenant",
    ORGANIZATION: "organization",
    PERSONAL: "personal"
};
/**
 * Lifecycle states persisted for a governed plugin application installation.
 * `degraded` means the installation record exists but one or more managed
 * resources failed the host health check.
 */ var PLUGIN_APPLICATION_INSTALLATION_STATUS = {
    CONFIGURING: "configuring",
    INITIALIZING: "initializing",
    READY: "ready",
    FAILED: "failed",
    DEGRADED: "degraded"
};
/** Validate portable metadata without inferring a scope from names or presentation text. */ function getPluginApplicationScopes(value) {
    var values = Array.isArray(value) ? value : [
        value
    ];
    if (!values.length || !values.every(isPluginApplicationScope)) return [];
    return _to_consumable_array$e(new Set(values));
}
function isPluginApplicationScope(value) {
    return value === "organization" || value === "personal" || value === "tenant";
}

var PLUGIN_LEVEL = {
    SYSTEM: "system",
    TENANT: "tenant",
    ORGANIZATION: "organization"
};
var PLUGIN_SOURCE = {
    MARKETPLACE: "marketplace",
    LOCAL: "local",
    GIT: "git",
    URL: "url",
    NPM: "npm",
    CODE: "code",
    ENV: "env"
};
var PLUGIN_CONFIGURATION_STATUS = {
    VALID: "valid",
    INVALID: "invalid"
};
var PLUGIN_LOAD_STATUS = {
    LOADED: "loaded",
    PENDING_RESTART: "pending_restart",
    FAILED: "failed"
};
var PLUGIN_COMPONENT_TYPE = {
    SKILL: "skill",
    MCP_SERVER: "mcp_server",
    TOOLSET: "toolset",
    APP: "app",
    HOOK: "hook",
    ASSET: "asset"
};
var PLUGIN_MARKETPLACE_INSTALLATION_POLICY = {
    AVAILABLE: "AVAILABLE",
    INSTALLED_BY_DEFAULT: "INSTALLED_BY_DEFAULT",
    NOT_AVAILABLE: "NOT_AVAILABLE"
};
var PLUGIN_MARKETPLACE_AUTHENTICATION_POLICY = {
    ON_INSTALL: "ON_INSTALL",
    ON_FIRST_USE: "ON_FIRST_USE",
    NONE: "NONE"
};
var PLUGIN_MCP_TOOL_APPROVAL_MODE = {
    PROMPT: "prompt",
    APPROVE: "approve",
    DENY: "deny"
};
var PLUGIN_RESOURCE_RUNTIME_TYPE = {
    SKILL_PACKAGE: "skill_package",
    TOOLSET: "toolset",
    HOOK_PROFILE: "hook_profile",
    APP_CONNECTOR: "app_connector"
};
var PLUGIN_RESOURCE_INSTALLATION_STATUS = {
    READY: "ready",
    PENDING_AUTH: "pending_auth",
    BLOCKED: "blocked",
    FAILED: "failed"
};
var PLUGIN_RESOURCE_ERROR_CODE = {
    NO_MATCHING_COMPONENTS: "PLUGIN_RESOURCE_NO_MATCHING_COMPONENTS"
};
var PLUGIN_MARKETPLACE_CATEGORIES = [
    "featured",
    "business-operations",
    "communication",
    "creativity",
    "data-analytics",
    "developer-tools",
    "education-research",
    "finance",
    "productivity",
    "research",
    "security",
    "travel",
    "sales",
    "other"
];
/**
 * Technical subcategories used by the plugin marketplace.
 * marketplace.category describes the business-facing group; marketplace.subcategory describes the technical type.
 */ var PLUGIN_MARKETPLACE_SUBCATEGORIES = [
    "connector",
    "middleware",
    "integration",
    "database",
    "tools",
    "model",
    "vlm",
    "vector-store",
    "doc-source",
    "datasource",
    "agent",
    "set"
];
var PluginMarketplaceDetailErrorCode;
(function(PluginMarketplaceDetailErrorCode) {
    PluginMarketplaceDetailErrorCode["Unavailable"] = "PLUGIN_MARKETPLACE_DETAIL_UNAVAILABLE";
    PluginMarketplaceDetailErrorCode["LookupFailed"] = "PLUGIN_MARKETPLACE_LOOKUP_FAILED";
})(PluginMarketplaceDetailErrorCode || (PluginMarketplaceDetailErrorCode = {}));

var XpertMarketplaceBusinessCategories = PLUGIN_MARKETPLACE_CATEGORIES;
var XpertMarketplaceCollaborationModes = [
    "single-agent",
    "multi-agent",
    "human-in-loop"
];
var XpertMarketplaceTechnicalCategories = [
    "knowledge-retrieval",
    "tool-calling",
    "workflow",
    "external-xpert",
    "file-understanding",
    "sandbox",
    "trigger",
    "http",
    "code",
    "database",
    "structured-output"
];
var XpertAccessRequestStatusEnum;
(function(XpertAccessRequestStatusEnum) {
    XpertAccessRequestStatusEnum["REQUESTED"] = "requested";
    XpertAccessRequestStatusEnum["APPROVED"] = "approved";
    XpertAccessRequestStatusEnum["REJECTED"] = "rejected";
})(XpertAccessRequestStatusEnum || (XpertAccessRequestStatusEnum = {}));
var databaseWorkflowTypes = new Set([
    WorkflowNodeTypeEnum.DB_SQL,
    WorkflowNodeTypeEnum.DB_INSERT,
    WorkflowNodeTypeEnum.DB_UPDATE,
    WorkflowNodeTypeEnum.DB_DELETE,
    WorkflowNodeTypeEnum.DB_QUERY
]);
function addUnique(items, item) {
    if (!items.includes(item)) {
        items.push(item);
    }
}
function hasEnabledFileUnderstanding(node) {
    var _node_entity_options_fileUnderstanding, _node_entity_options, _node_entity_options_attachment, _node_entity_options1;
    return ((_node_entity_options = node.entity.options) === null || _node_entity_options === void 0 ? void 0 : (_node_entity_options_fileUnderstanding = _node_entity_options.fileUnderstanding) === null || _node_entity_options_fileUnderstanding === void 0 ? void 0 : _node_entity_options_fileUnderstanding.enabled) === true || ((_node_entity_options1 = node.entity.options) === null || _node_entity_options1 === void 0 ? void 0 : (_node_entity_options_attachment = _node_entity_options1.attachment) === null || _node_entity_options_attachment === void 0 ? void 0 : _node_entity_options_attachment.enabled) === true;
}
function hasStructuredOutput(node) {
    var _node_entity_outputVariables, _node_entity_options;
    return !!((_node_entity_outputVariables = node.entity.outputVariables) === null || _node_entity_outputVariables === void 0 ? void 0 : _node_entity_outputVariables.length) || !!((_node_entity_options = node.entity.options) === null || _node_entity_options === void 0 ? void 0 : _node_entity_options.structuredOutputMethod);
}
function deriveXpertMarketplaceTechnicalProfile(draft) {
    var _draft_team_features_sandbox, _draft_team_features, _draft_team_agentConfig_interruptBefore, _draft_team_agentConfig;
    var _draft_nodes;
    var nodes = (_draft_nodes = draft === null || draft === void 0 ? void 0 : draft.nodes) !== null && _draft_nodes !== void 0 ? _draft_nodes : [];
    var _draft_connections;
    var connections = (_draft_connections = draft === null || draft === void 0 ? void 0 : draft.connections) !== null && _draft_connections !== void 0 ? _draft_connections : [];
    var categories = [];
    var workflowNodeTypes = [];
    var agentNodes = nodes.filter(function(node) {
        return node.type === "agent";
    });
    var knowledgebaseCount = nodes.filter(function(node) {
        return node.type === "knowledge";
    }).length;
    var toolsetCount = nodes.filter(function(node) {
        return node.type === "toolset";
    }).length;
    var externalXpertCount = nodes.filter(function(node) {
        return node.type === "xpert";
    }).length;
    var workflowNodes = nodes.filter(function(node) {
        return node.type === "workflow";
    });
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = workflowNodes[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var node = _step.value;
            addUnique(workflowNodeTypes, node.entity.type);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    if (knowledgebaseCount > 0 || workflowNodeTypes.includes(WorkflowNodeTypeEnum.KNOWLEDGE)) {
        addUnique(categories, "knowledge-retrieval");
    }
    if (toolsetCount > 0 || workflowNodeTypes.includes(WorkflowNodeTypeEnum.TOOL) || workflowNodeTypes.includes(WorkflowNodeTypeEnum.AGENT_TOOL)) {
        addUnique(categories, "tool-calling");
    }
    if (workflowNodes.length > 0 || connections.some(function(connection) {
        return connection.type === "edge";
    })) {
        addUnique(categories, "workflow");
    }
    if (externalXpertCount > 0 || connections.some(function(connection) {
        return connection.type === "xpert";
    })) {
        addUnique(categories, "external-xpert");
    }
    if (agentNodes.some(hasEnabledFileUnderstanding)) {
        addUnique(categories, "file-understanding");
    }
    if (draft === null || draft === void 0 ? void 0 : (_draft_team_features = draft.team.features) === null || _draft_team_features === void 0 ? void 0 : (_draft_team_features_sandbox = _draft_team_features.sandbox) === null || _draft_team_features_sandbox === void 0 ? void 0 : _draft_team_features_sandbox.enabled) {
        addUnique(categories, "sandbox");
    }
    if (workflowNodeTypes.includes(WorkflowNodeTypeEnum.TRIGGER)) {
        addUnique(categories, "trigger");
    }
    if (workflowNodeTypes.includes(WorkflowNodeTypeEnum.HTTP)) {
        addUnique(categories, "http");
    }
    if (workflowNodeTypes.includes(WorkflowNodeTypeEnum.CODE)) {
        addUnique(categories, "code");
    }
    if (workflowNodeTypes.some(function(type) {
        return databaseWorkflowTypes.has(type);
    })) {
        addUnique(categories, "database");
    }
    if (agentNodes.some(hasStructuredOutput)) {
        addUnique(categories, "structured-output");
    }
    var collaborationModes = [];
    if (agentNodes.length > 1 || externalXpertCount > 0 || connections.some(function(connection) {
        return connection.type === "agent";
    })) {
        addUnique(collaborationModes, "multi-agent");
    } else {
        addUnique(collaborationModes, "single-agent");
    }
    if (draft === null || draft === void 0 ? void 0 : (_draft_team_agentConfig = draft.team.agentConfig) === null || _draft_team_agentConfig === void 0 ? void 0 : (_draft_team_agentConfig_interruptBefore = _draft_team_agentConfig.interruptBefore) === null || _draft_team_agentConfig_interruptBefore === void 0 ? void 0 : _draft_team_agentConfig_interruptBefore.length) {
        addUnique(collaborationModes, "human-in-loop");
    }
    return {
        agentCount: agentNodes.length,
        toolsetCount: toolsetCount,
        knowledgebaseCount: knowledgebaseCount,
        externalXpertCount: externalXpertCount,
        workflowNodeCount: workflowNodes.length,
        workflowNodeTypes: workflowNodeTypes,
        categories: categories,
        collaborationModes: collaborationModes
    };
}
function buildXpertMarketplaceProfileSnapshot(input, draft) {
    var _input_summary, _input_capabilityTags;
    var technical = deriveXpertMarketplaceTechnicalProfile(draft);
    var summary = (input === null || input === void 0 ? void 0 : (_input_summary = input.summary) === null || _input_summary === void 0 ? void 0 : _input_summary.trim()) || null;
    var _input_capabilityTags_map_filter;
    var capabilityTags = Array.from(new Set((_input_capabilityTags_map_filter = input === null || input === void 0 ? void 0 : (_input_capabilityTags = input.capabilityTags) === null || _input_capabilityTags === void 0 ? void 0 : _input_capabilityTags.map(function(tag) {
        return tag.trim();
    }).filter(Boolean)) !== null && _input_capabilityTags_map_filter !== void 0 ? _input_capabilityTags_map_filter : []));
    var _input_businessCategories;
    return {
        summary: summary,
        businessCategories: (_input_businessCategories = input === null || input === void 0 ? void 0 : input.businessCategories) !== null && _input_businessCategories !== void 0 ? _input_businessCategories : [],
        capabilityTags: capabilityTags,
        collaborationModes: technical.collaborationModes,
        technical: technical,
        featured: (input === null || input === void 0 ? void 0 : input.featured) === true
    };
}

// Helpers
function _array_like_to_array$o(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$d(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$o(arr);
}
function _define_property$j(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$f(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$d() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$j(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$j(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$f(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$f(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$f(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _object_without_properties$1(source, excluded) {
    if (source == null) return {};
    var target = _object_without_properties_loose$1(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _object_without_properties_loose$1(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
function _to_consumable_array$d(arr) {
    return _array_without_holes$d(arr) || _iterable_to_array$f(arr) || _unsupported_iterable_to_array$o(arr) || _non_iterable_spread$d();
}
function _unsupported_iterable_to_array$o(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$o(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$o(o, minLen);
}
function omitXpertRelations(xpert) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    var _ref = xpert !== null && xpert !== void 0 ? xpert : {}; _ref.draft; _ref.agent; _ref.agents; _ref.executors; _ref.leaders; _ref.knowledgebases; _ref.knowledgebase; _ref.environment; _ref.integrations; _ref.toolsets; _ref.userGroups; var rest = _object_without_properties$1(_ref, [
        "draft",
        "agent",
        "agents",
        "executors",
        "leaders",
        "knowledgebases",
        "knowledgebase",
        "environment",
        "integrations",
        "toolsets",
        "userGroups"
    ]);
    return rest;
}
/**
 * Figure out latest xpert or draft xpert.
 *
 * @param xpert
 * @param isDraft Is draft
 * @returns
 */ function figureOutXpert(xpert, isDraft) {
    var _xpert_draft;
    var _ref;
    return (_ref = isDraft ? (_xpert_draft = xpert.draft) === null || _xpert_draft === void 0 ? void 0 : _xpert_draft.team : xpert) !== null && _ref !== void 0 ? _ref : xpert;
}
function resolveRuntimeXpert(xpert, isDraft) {
    var _draft_team, _draft_team1, _draft_team2, _draft_team3, _draft_team4;
    if (!isDraft || !xpert.draft) {
        return xpert;
    }
    var draft = xpert.draft;
    var graph = resolveDraftRuntimeGraph(xpert, draft);
    var agent = resolveDraftPrimaryAgent(xpert, draft, graph);
    var _draft_team5, _draft_team_workspaceId, _draft_team_agentConfig, _draft_team_commandProfile, _draft_team_features, _draft_team_options;
    return _object_spread_props$f(_object_spread$j({}, xpert, (_draft_team5 = draft.team) !== null && _draft_team5 !== void 0 ? _draft_team5 : {}), {
        id: xpert.id,
        tenantId: xpert.tenantId,
        organizationId: xpert.organizationId,
        workspaceId: (_draft_team_workspaceId = (_draft_team = draft.team) === null || _draft_team === void 0 ? void 0 : _draft_team.workspaceId) !== null && _draft_team_workspaceId !== void 0 ? _draft_team_workspaceId : xpert.workspaceId,
        workspaceDataScope: xpert.workspaceDataScope,
        draft: xpert.draft,
        graph: graph,
        agent: agent,
        agentConfig: (_draft_team_agentConfig = (_draft_team1 = draft.team) === null || _draft_team1 === void 0 ? void 0 : _draft_team1.agentConfig) !== null && _draft_team_agentConfig !== void 0 ? _draft_team_agentConfig : xpert.agentConfig,
        commandProfile: (_draft_team_commandProfile = (_draft_team2 = draft.team) === null || _draft_team2 === void 0 ? void 0 : _draft_team2.commandProfile) !== null && _draft_team_commandProfile !== void 0 ? _draft_team_commandProfile : xpert.commandProfile,
        features: (_draft_team_features = (_draft_team3 = draft.team) === null || _draft_team3 === void 0 ? void 0 : _draft_team3.features) !== null && _draft_team_features !== void 0 ? _draft_team_features : xpert.features,
        options: (_draft_team_options = (_draft_team4 = draft.team) === null || _draft_team4 === void 0 ? void 0 : _draft_team4.options) !== null && _draft_team_options !== void 0 ? _draft_team_options : xpert.options
    });
}
function resolveDraftRuntimeGraph(xpert, draft) {
    var _xpert_graph, _xpert_graph1;
    var _draft_nodes, _ref, _draft_connections, _ref1;
    return {
        nodes: (_ref = (_draft_nodes = draft.nodes) !== null && _draft_nodes !== void 0 ? _draft_nodes : (_xpert_graph = xpert.graph) === null || _xpert_graph === void 0 ? void 0 : _xpert_graph.nodes) !== null && _ref !== void 0 ? _ref : [],
        connections: (_ref1 = (_draft_connections = draft.connections) !== null && _draft_connections !== void 0 ? _draft_connections : (_xpert_graph1 = xpert.graph) === null || _xpert_graph1 === void 0 ? void 0 : _xpert_graph1.connections) !== null && _ref1 !== void 0 ? _ref1 : []
    };
}
function resolveDraftPrimaryAgent(xpert, draft, graph) {
    var _draft_team, _xpert_agent;
    var draftAgent = (_draft_team = draft.team) === null || _draft_team === void 0 ? void 0 : _draft_team.agent;
    var _draftAgent_key;
    var targetKey = (_draftAgent_key = draftAgent === null || draftAgent === void 0 ? void 0 : draftAgent.key) !== null && _draftAgent_key !== void 0 ? _draftAgent_key : (_xpert_agent = xpert.agent) === null || _xpert_agent === void 0 ? void 0 : _xpert_agent.key;
    var agentNode = targetKey ? graph.nodes.find(function(node) {
        var _node_entity;
        return node.type === "agent" && (node.key === targetKey || ((_node_entity = node.entity) === null || _node_entity === void 0 ? void 0 : _node_entity.key) === targetKey);
    }) : null;
    var _agentNode_entity, _ref;
    return (_ref = (_agentNode_entity = agentNode === null || agentNode === void 0 ? void 0 : agentNode.entity) !== null && _agentNode_entity !== void 0 ? _agentNode_entity : draftAgent) !== null && _ref !== void 0 ? _ref : xpert.agent;
}
function xpertLabel(agent) {
    return agent.title || agent.name;
}
function createXpertGraph(xpert, position) {
    var _xpert_graph;
    var graph = (_xpert_graph = xpert.graph) !== null && _xpert_graph !== void 0 ? _xpert_graph : xpert.draft;
    var _locateNodes = locateNodes(graph.nodes, position), nodes = _locateNodes.nodes, size = _locateNodes.size;
    return {
        nodes: nodes,
        size: size,
        connections: graph.connections
    };
}
function locateNodes(nodes, position) {
    var _Math, _Math1, _Math2, _Math3;
    // Extract the area by positions of all nodes
    var positions = nodes.map(function(node) {
        return node.position;
    });
    var x0Positions = positions.map(function(pos) {
        return pos.x;
    });
    var x1Positions = nodes.map(function(node) {
        var _node_size;
        var _node_size_width;
        return node.position.x + ((_node_size_width = (_node_size = node.size) === null || _node_size === void 0 ? void 0 : _node_size.width) !== null && _node_size_width !== void 0 ? _node_size_width : 240);
    }); // Node width min 240
    var y0Positions = positions.map(function(pos) {
        return pos.y;
    });
    var y1Positions = nodes.map(function(node) {
        var _node_size;
        var _node_size_height;
        return node.position.y + ((_node_size_height = (_node_size = node.size) === null || _node_size === void 0 ? void 0 : _node_size.height) !== null && _node_size_height !== void 0 ? _node_size_height : 70);
    }); // Node height min 70
    var xRange = {
        min: (_Math = Math).min.apply(_Math, _to_consumable_array$d(x0Positions)),
        max: (_Math1 = Math).max.apply(_Math1, _to_consumable_array$d(x1Positions))
    };
    var yRange = {
        min: (_Math2 = Math).min.apply(_Math2, _to_consumable_array$d(y0Positions)),
        max: (_Math3 = Math).max.apply(_Math3, _to_consumable_array$d(y1Positions))
    };
    var size = {
        width: xRange.max - xRange.min + 50,
        height: yRange.max - yRange.min + 80
    };
    nodes.forEach(function(node) {
        var _node_position, _node_position1;
        node.position = {
            x: position.x + (((_node_position = node.position) === null || _node_position === void 0 ? void 0 : _node_position.x) ? node.position.x - xRange.min : 0) + 10,
            y: position.y + (((_node_position1 = node.position) === null || _node_position1 === void 0 ? void 0 : _node_position1.y) ? node.position.y - yRange.min : 0) + 40
        };
    });
    return {
        size: size,
        nodes: nodes
    };
}
/**
 * Create all nodes of xpert and it's area size
 *
 * @param xpert
 * @returns
 */ function createXpertNodes(xpert, position) {
    var // Agents
    _nodes, // knowledgebases
    _nodes1, // Toolsets
    _nodes2, _Math, _Math1, _Math2, _Math3;
    var _xpert_agent_options, _xpert_agents, // External experts
    _xpert_executors;
    var nodes = [];
    var agents = [];
    if (!((_xpert_agent_options = xpert.agent.options) === null || _xpert_agent_options === void 0 ? void 0 : _xpert_agent_options.hidden)) {
        agents.push(xpert.agent);
    }
    if ((_xpert_agents = xpert.agents) === null || _xpert_agents === void 0 ? void 0 : _xpert_agents.length) {
        var _agents;
        (_agents = agents).push.apply(_agents, _to_consumable_array$d(xpert.agents));
    }
    (_nodes = nodes).push.apply(_nodes, _to_consumable_array$d(agents.map(function(_) {
        var _xpert_options_agent___key, _xpert_options_agent, _xpert_options, _xpert_options_agent___key1, _xpert_options_agent1, _xpert_options1;
        var _xpert_options_agent___key_position;
        return {
            type: "agent",
            key: _.key,
            position: (_xpert_options_agent___key_position = (_xpert_options = xpert.options) === null || _xpert_options === void 0 ? void 0 : (_xpert_options_agent = _xpert_options.agent) === null || _xpert_options_agent === void 0 ? void 0 : (_xpert_options_agent___key = _xpert_options_agent[_.key]) === null || _xpert_options_agent___key === void 0 ? void 0 : _xpert_options_agent___key.position) !== null && _xpert_options_agent___key_position !== void 0 ? _xpert_options_agent___key_position : {
                x: 0,
                y: 0
            },
            size: (_xpert_options1 = xpert.options) === null || _xpert_options1 === void 0 ? void 0 : (_xpert_options_agent1 = _xpert_options1.agent) === null || _xpert_options_agent1 === void 0 ? void 0 : (_xpert_options_agent___key1 = _xpert_options_agent1[_.key]) === null || _xpert_options_agent___key1 === void 0 ? void 0 : _xpert_options_agent___key1.size,
            entity: _
        };
    })));
    (_xpert_executors = xpert.executors) === null || _xpert_executors === void 0 ? void 0 : _xpert_executors.forEach(function(executor) {
        var _xpert_options_xpert_executor_id, _xpert_options_xpert, _xpert_options;
        var _xpert_options_xpert_executor_id_position;
        var position = (_xpert_options_xpert_executor_id_position = (_xpert_options = xpert.options) === null || _xpert_options === void 0 ? void 0 : (_xpert_options_xpert = _xpert_options.xpert) === null || _xpert_options_xpert === void 0 ? void 0 : (_xpert_options_xpert_executor_id = _xpert_options_xpert[executor.id]) === null || _xpert_options_xpert_executor_id === void 0 ? void 0 : _xpert_options_xpert_executor_id.position) !== null && _xpert_options_xpert_executor_id_position !== void 0 ? _xpert_options_xpert_executor_id_position : {
            x: 0,
            y: 0
        };
        var executorGraph = createXpertNodes(executor, position);
        nodes.push({
            type: "xpert",
            key: executor.id,
            position: position,
            size: executorGraph.size,
            entity: executor,
            nodes: executorGraph.nodes
        });
    });
    var _xpert_knowledgebases;
    (_nodes1 = nodes).push.apply(_nodes1, _to_consumable_array$d(((_xpert_knowledgebases = xpert.knowledgebases) !== null && _xpert_knowledgebases !== void 0 ? _xpert_knowledgebases : []).map(function(x) {
        var _xpert_options_knowledge_x_id, _xpert_options_knowledge, _xpert_options, _xpert_options_knowledge_x_id1, _xpert_options_knowledge1, _xpert_options1;
        var _xpert_options_knowledge_x_id_position;
        return {
            key: x.id,
            type: "knowledge",
            position: (_xpert_options_knowledge_x_id_position = (_xpert_options = xpert.options) === null || _xpert_options === void 0 ? void 0 : (_xpert_options_knowledge = _xpert_options.knowledge) === null || _xpert_options_knowledge === void 0 ? void 0 : (_xpert_options_knowledge_x_id = _xpert_options_knowledge[x.id]) === null || _xpert_options_knowledge_x_id === void 0 ? void 0 : _xpert_options_knowledge_x_id.position) !== null && _xpert_options_knowledge_x_id_position !== void 0 ? _xpert_options_knowledge_x_id_position : {
                x: 0,
                y: 0
            },
            size: (_xpert_options1 = xpert.options) === null || _xpert_options1 === void 0 ? void 0 : (_xpert_options_knowledge1 = _xpert_options1.knowledge) === null || _xpert_options_knowledge1 === void 0 ? void 0 : (_xpert_options_knowledge_x_id1 = _xpert_options_knowledge1[x.id]) === null || _xpert_options_knowledge_x_id1 === void 0 ? void 0 : _xpert_options_knowledge_x_id1.size,
            entity: x
        };
    })));
    var _xpert_toolsets;
    (_nodes2 = nodes).push.apply(_nodes2, _to_consumable_array$d(((_xpert_toolsets = xpert.toolsets) !== null && _xpert_toolsets !== void 0 ? _xpert_toolsets : []).map(function(x) {
        var _xpert_options_toolset_x_id, _xpert_options_toolset, _xpert_options, _xpert_options_toolset_x_id1, _xpert_options_toolset1, _xpert_options1;
        var _xpert_options_toolset_x_id_position;
        return {
            key: x.id,
            type: "toolset",
            position: (_xpert_options_toolset_x_id_position = (_xpert_options = xpert.options) === null || _xpert_options === void 0 ? void 0 : (_xpert_options_toolset = _xpert_options.toolset) === null || _xpert_options_toolset === void 0 ? void 0 : (_xpert_options_toolset_x_id = _xpert_options_toolset[x.id]) === null || _xpert_options_toolset_x_id === void 0 ? void 0 : _xpert_options_toolset_x_id.position) !== null && _xpert_options_toolset_x_id_position !== void 0 ? _xpert_options_toolset_x_id_position : {
                x: 0,
                y: 0
            },
            size: (_xpert_options1 = xpert.options) === null || _xpert_options1 === void 0 ? void 0 : (_xpert_options_toolset1 = _xpert_options1.toolset) === null || _xpert_options_toolset1 === void 0 ? void 0 : (_xpert_options_toolset_x_id1 = _xpert_options_toolset1[x.id]) === null || _xpert_options_toolset_x_id1 === void 0 ? void 0 : _xpert_options_toolset_x_id1.size,
            entity: x
        };
    })));
    // Extract the area by positions of all nodes
    var positions = nodes.map(function(node) {
        return node.position;
    });
    var x0Positions = positions.map(function(pos) {
        return pos.x;
    });
    var x1Positions = nodes.map(function(node) {
        var _node_size;
        var _node_size_width;
        return node.position.x + ((_node_size_width = (_node_size = node.size) === null || _node_size === void 0 ? void 0 : _node_size.width) !== null && _node_size_width !== void 0 ? _node_size_width : 240);
    }); // Node width min 240
    var y0Positions = positions.map(function(pos) {
        return pos.y;
    });
    var y1Positions = nodes.map(function(node) {
        var _node_size;
        var _node_size_height;
        return node.position.y + ((_node_size_height = (_node_size = node.size) === null || _node_size === void 0 ? void 0 : _node_size.height) !== null && _node_size_height !== void 0 ? _node_size_height : 70);
    }); // Node height min 70
    var xRange = {
        min: (_Math = Math).min.apply(_Math, _to_consumable_array$d(x0Positions)),
        max: (_Math1 = Math).max.apply(_Math1, _to_consumable_array$d(x1Positions))
    };
    var yRange = {
        min: (_Math2 = Math).min.apply(_Math2, _to_consumable_array$d(y0Positions)),
        max: (_Math3 = Math).max.apply(_Math3, _to_consumable_array$d(y1Positions))
    };
    var size = {
        width: xRange.max - xRange.min + 50,
        height: yRange.max - yRange.min + 80
    };
    nodes.forEach(function(node) {
        var _node_position, _node_position1;
        node.position = {
            x: position.x + (((_node_position = node.position) === null || _node_position === void 0 ? void 0 : _node_position.x) ? node.position.x - xRange.min : 0) + 10,
            y: position.y + (((_node_position1 = node.position) === null || _node_position1 === void 0 ? void 0 : _node_position1.y) ? node.position.y - yRange.min : 0) + 40
        };
    });
    return {
        nodes: nodes,
        size: size
    };
}
function createAgentConnections(agent, collaborators) {
    var // collaborators
    _agent_collaboratorNames, // knowledgebases
    _agent_knowledgebaseIds, // toolsets
    _agent_toolsetIds;
    var connections = [];
    var from = agent.leaderKey;
    var to = agent.key;
    if (from && to) {
        connections.push({
            type: "agent",
            key: from + "/" + to,
            from: from,
            to: to
        });
    }
    (_agent_collaboratorNames = agent.collaboratorNames) === null || _agent_collaboratorNames === void 0 ? void 0 : _agent_collaboratorNames.forEach(function(name) {
        var collaborator = collaborators.find(function(_) {
            return _.name === name;
        });
        if (collaborator) {
            var from = agent.key;
            var to = collaborator.id;
            connections.push({
                type: "xpert",
                key: from + "/" + to,
                from: from,
                to: to
            });
        }
    });
    (_agent_knowledgebaseIds = agent.knowledgebaseIds) === null || _agent_knowledgebaseIds === void 0 ? void 0 : _agent_knowledgebaseIds.forEach(function(knowledgebaseId) {
        var from = agent.key;
        var to = knowledgebaseId;
        connections.push({
            type: "knowledge",
            key: from + "/" + to,
            from: from,
            to: to
        });
    });
    (_agent_toolsetIds = agent.toolsetIds) === null || _agent_toolsetIds === void 0 ? void 0 : _agent_toolsetIds.forEach(function(toolsetId) {
        var from = agent.key;
        var to = toolsetId;
        connections.push({
            type: "toolset",
            key: from + "/" + to,
            from: from,
            to: to
        });
    });
    return connections;
}
function replaceAgentInDraft(draft, sourceKey, agent, options) {
    var _draft_nodes, _draft_connections;
    var targetKey = agent === null || agent === void 0 ? void 0 : agent.key;
    if (!targetKey) {
        throw new Error("Target agent key is required");
    }
    var replacedNode = false;
    var nodes = (_draft_nodes = draft.nodes) === null || _draft_nodes === void 0 ? void 0 : _draft_nodes.map(function(node) {
        if (node.type === "agent" && node.key === sourceKey) {
            replacedNode = true;
            var _node_entity;
            return _object_spread_props$f(_object_spread$j({}, node), {
                key: targetKey,
                entity: _object_spread_props$f(_object_spread$j({}, (_node_entity = node.entity) !== null && _node_entity !== void 0 ? _node_entity : {}, agent), {
                    key: targetKey
                })
            });
        }
        return node;
    });
    if (!replacedNode && (options === null || options === void 0 ? void 0 : options.requireNode) !== false) {
        throw new Error("Can't find agent for key: ".concat(sourceKey));
    }
    var connections = (_draft_connections = draft.connections) === null || _draft_connections === void 0 ? void 0 : _draft_connections.map(function(connection) {
        var from = connection.from === sourceKey ? targetKey : connection.from;
        var to = connection.to === sourceKey ? targetKey : connection.to;
        if (from === connection.from && to === connection.to) {
            return connection;
        }
        return _object_spread_props$f(_object_spread$j({}, connection), {
            from: from,
            to: to,
            key: "".concat(from, "/").concat(to)
        });
    });
    return _object_spread_props$f(_object_spread$j({}, draft), {
        team: draft.team ? _object_spread_props$f(_object_spread$j({}, draft.team), {
            agent: draft.team.agent ? _object_spread_props$f(_object_spread$j({}, draft.team.agent, agent), {
                key: targetKey
            }) : _object_spread_props$f(_object_spread$j({}, agent), {
                key: targetKey
            })
        }) : draft.team,
        nodes: nodes,
        connections: connections
    });
}

var ApiAuthType;
(function(ApiAuthType) {
    /**
     * Enum class for api provider auth type.
     */ ApiAuthType["NONE"] = "none";
    ApiAuthType["API_KEY"] = "api_key";
    ApiAuthType["BASIC"] = "basic";
})(ApiAuthType || (ApiAuthType = {}));
/**
 * Embedding status of an entity, such as an bi indicator or kb document.
 */ var EmbeddingStatusEnum;
(function(EmbeddingStatusEnum) {
    EmbeddingStatusEnum["PROCESSING"] = "processing";
    EmbeddingStatusEnum["SUCCESS"] = "success";
    EmbeddingStatusEnum["FAILED"] = "failed";
    EmbeddingStatusEnum["REQUIRED"] = "required";
})(EmbeddingStatusEnum || (EmbeddingStatusEnum = {}));
var Attachment_Type_Options = [
    {
        key: "document",
        value: "TXT, MD, MDX, MARKDOWN, PDF, HTML, XLSX, XLS, DOC, DOCX, CSV, EML, MSG, PPTX, PPT, XML, EPUB",
        label: {
            zh_Hans: "文档",
            en_US: "Document"
        }
    },
    {
        key: "image",
        value: "JPG, JPEG, PNG, GIF, WEBP, SVG",
        label: {
            zh_Hans: "图片",
            en_US: "Image"
        }
    },
    {
        key: "audio",
        value: "MP3, M4A, WAV, AMR, MPGA",
        label: {
            zh_Hans: "音频",
            en_US: "Audio"
        }
    },
    {
        key: "video",
        value: "MP4, MOV, MPEG, WEBM",
        label: {
            zh_Hans: "视频",
            en_US: "Video"
        }
    },
    {
        key: "others",
        value: "",
        label: {
            zh_Hans: "其他文件类型",
            en_US: "Other file types"
        }
    }
];

var XPERT_TASK_SCHEDULE_PROPERTY_PREFIX = "xpert_task_";
var XPERT_TASK_SCHEDULE_IDEMPOTENCY_KEY = "__idempotency_key";

var TASK_DESCRIPTION_PREFIX = "Launch a new agent to handle complex, multi-step tasks autonomously. \n\nAvailable agent types and the tools they have access to:";
var TASK_DESCRIPTION_SUFFIX = 'When using the Task tool, you must specify a subagent_type parameter to select which agent type to use.\n\nWhen to use the Agent tool:\n- When you are instructed to execute custom slash commands. Use the Agent tool with the slash command invocation as the entire prompt. The slash command can take arguments. For example: Task(description="Check the file")\n\nWhen NOT to use the Agent tool:\n- If you want to read a specific file path, use the Read or Glob tool instead of the Agent tool, to find the match more quickly\n- If you are searching for a specific term or definition within a known location, use the Glob tool instead, to find the match more quickly\n- If you are searching for content within a specific file or set of 2-3 files, use the Read tool instead of the Agent tool, to find the match more quickly\n- Other tasks that are not related to the agent descriptions above\n\n\nUsage notes:\n1. Launch multiple agents concurrently whenever possible, to maximize performance; to do that, use a single message with multiple tool uses\n2. When the agent is done, it will return a single message back to you. The result returned by the agent is not visible to the user. To show the user the result, you should send a text message back to the user with a concise summary of the result.\n3. Each agent invocation is stateless. You will not be able to send additional messages to the agent, nor will the agent be able to communicate with you outside of its final report. Therefore, your prompt should contain a highly detailed task description for the agent to perform autonomously and you should specify exactly what information the agent should return back to you in its final and only message to you.\n4. The agent\'s outputs should generally be trusted\n5. Clearly tell the agent whether you expect it to create content, perform analysis, or just do research (search, file reads, web fetches, etc.), since it is not aware of the user\'s intent\n6. If the agent description mentions that it should be used proactively, then you should try your best to use it without the user having to ask for it first. Use your judgement.\n\nExample usage:\n\n<example_agent_descriptions>\n"content-reviewer": use this agent after you are done creating significant content or documents\n"greeting-responder": use this agent when to respond to user greetings with a friendly joke\n"research-analyst": use this agent to conduct thorough research on complex topics\n</example_agent_description>\n\n<example>\nuser: "Please write a function that checks if a number is prime"\nassistant: Sure let me write a function that checks if a number is prime\nassistant: First let me use the Write tool to write a function that checks if a number is prime\nassistant: I\'m going to use the Write tool to write the following code:\n<code>\nfunction isPrime(n) {\n  if (n <= 1) return false\n  for (let i = 2; i * i <= n; i++) {\n    if (n % i === 0) return false\n  }\n  return true\n}\n</code>\n<commentary>\nSince significant content was created and the task was completed, now use the content-reviewer agent to review the work\n</commentary>\nassistant: Now let me use the content-reviewer agent to review the code\nassistant: Uses the Task tool to launch with the content-reviewer agent \n</example>\n\n<example>\nuser: "Can you help me research the environmental impact of different renewable energy sources and create a comprehensive report?"\n<commentary>\nThis is a complex research task that would benefit from using the research-analyst agent to conduct thorough analysis\n</commentary>\nassistant: I\'ll help you research the environmental impact of renewable energy sources. Let me use the research-analyst agent to conduct comprehensive research on this topic.\nassistant: Uses the Task tool to launch with the research-analyst agent, providing detailed instructions about what research to conduct and what format the report should take\n</example>\n\n<example>\nuser: "Hello"\n<commentary>\nSince the user is greeting, use the greeting-responder agent to respond with a friendly joke\n</commentary>\nassistant: "I\'m going to use the Task tool to launch with the greeting-responder agent"\n</example>';

var MCPServerType;
(function(MCPServerType) {
    MCPServerType["SSE"] = "sse";
    MCPServerType["STDIO"] = "stdio";
    MCPServerType["CODE"] = "code";
    MCPServerType["HTTP"] = "http";
})(MCPServerType || (MCPServerType = {}));
/** Supported authentication modes for a host-consumed MCP server. */ var MCP_CONSUMER_AUTH_TYPES = [
    "none",
    "manual_header",
    "api_key",
    "oauth",
    "connector"
];
var MCP_APP_RESOURCE_MIME_TYPE = "text/html;profile=mcp-app";

var XpertProjectTaskStatusEnum;
(function(XpertProjectTaskStatusEnum) {
    XpertProjectTaskStatusEnum["TODO"] = "todo";
    XpertProjectTaskStatusEnum["IN_PROGRESS"] = "in_progress";
    XpertProjectTaskStatusEnum["REVIEW"] = "review";
    XpertProjectTaskStatusEnum["PAUSED"] = "paused";
    XpertProjectTaskStatusEnum["DONE"] = "done";
    XpertProjectTaskStatusEnum["BLOCKED"] = "blocked";
    XpertProjectTaskStatusEnum["CANCELLED"] = "cancelled";
})(XpertProjectTaskStatusEnum || (XpertProjectTaskStatusEnum = {}));
var XpertProjectTaskPriorityEnum;
(function(XpertProjectTaskPriorityEnum) {
    XpertProjectTaskPriorityEnum["URGENT"] = "urgent";
    XpertProjectTaskPriorityEnum["HIGH"] = "high";
    XpertProjectTaskPriorityEnum["MEDIUM"] = "medium";
    XpertProjectTaskPriorityEnum["LOW"] = "low";
})(XpertProjectTaskPriorityEnum || (XpertProjectTaskPriorityEnum = {}));
var XpertProjectPlanViewEnum;
(function(XpertProjectPlanViewEnum) {
    XpertProjectPlanViewEnum["BOARD"] = "board";
    XpertProjectPlanViewEnum["TABLE"] = "table";
    XpertProjectPlanViewEnum["GANTT"] = "gantt";
    XpertProjectPlanViewEnum["CALENDAR"] = "calendar";
    XpertProjectPlanViewEnum["LIST"] = "list";
})(XpertProjectPlanViewEnum || (XpertProjectPlanViewEnum = {}));
var XpertProjectAssetSourceEnum;
(function(XpertProjectAssetSourceEnum) {
    XpertProjectAssetSourceEnum["UPLOAD"] = "upload";
    XpertProjectAssetSourceEnum["AI_OUTPUT"] = "ai_output";
    XpertProjectAssetSourceEnum["CONVERSATION"] = "conversation";
    XpertProjectAssetSourceEnum["IMPORT"] = "import";
})(XpertProjectAssetSourceEnum || (XpertProjectAssetSourceEnum = {}));
var XpertProjectAutomationTriggerEnum;
(function(XpertProjectAutomationTriggerEnum) {
    XpertProjectAutomationTriggerEnum["SCHEDULE"] = "schedule";
    XpertProjectAutomationTriggerEnum["TASK_STATUS_CHANGED"] = "task.status_changed";
    XpertProjectAutomationTriggerEnum["ASSET_CREATED"] = "asset.created";
    XpertProjectAutomationTriggerEnum["CONVERSATION_COMPLETED"] = "conversation.completed";
})(XpertProjectAutomationTriggerEnum || (XpertProjectAutomationTriggerEnum = {}));
var XpertProjectAutomationRunStatusEnum;
(function(XpertProjectAutomationRunStatusEnum) {
    XpertProjectAutomationRunStatusEnum["QUEUED"] = "queued";
    XpertProjectAutomationRunStatusEnum["RUNNING"] = "running";
    XpertProjectAutomationRunStatusEnum["SUCCEEDED"] = "succeeded";
    XpertProjectAutomationRunStatusEnum["FAILED"] = "failed";
    XpertProjectAutomationRunStatusEnum["CANCELLED"] = "cancelled";
})(XpertProjectAutomationRunStatusEnum || (XpertProjectAutomationRunStatusEnum = {}));

var GENERAL_PROJECT_TYPE = {
    applicationKey: "platform",
    projectTypeKey: "general"
};
/** File-backed collaborative writing workspace using the ordinary Project lifecycle. */ var SPACE_PROJECT_TYPE = {
    applicationKey: "platform",
    projectTypeKey: "space"
};

function _define_property$i(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$i(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$i(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$e(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$e(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$e(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var valueSchema = z.lazy(function() {
    return z.union([
        z.string(),
        z.number().finite(),
        z.boolean(),
        z.null(),
        z.array(valueSchema),
        z.record(valueSchema)
    ]);
});
var projectConfigurationValuesSchema = z.record(valueSchema).refine(function(values) {
    return JSON.stringify(values).length <= 65536;
}, "Project configuration is too large");
var projectConfigurationUpdateSchema = z.object({
    revision: z.number().int().nonnegative(),
    values: projectConfigurationValuesSchema
}).strict();
/** Reserved host setting; custom type settings remain uninterpreted by the runtime. */ var projectTaskDurationSchema = z.number().int().min(60).max(86400);
function projectTaskConfigurationSchema(defaultSeconds) {
    return {
        type: "object",
        additionalProperties: false,
        properties: {
            taskExecutionMaxDurationSeconds: _object_spread_props$e(_object_spread$i({
                type: "integer",
                minimum: 60,
                maximum: 86400
            }, defaultSeconds === undefined ? {} : {
                default: defaultSeconds
            }), {
                title: {
                    en_US: "Task execution limit (seconds)",
                    zh_Hans: "单次任务执行上限（秒）"
                },
                description: {
                    en_US: "7200 seconds is 2 hours. Applies to new implementation and review attempts, within the tenant limit.",
                    zh_Hans: "7200 秒为 2 小时。在租户允许的上限内，对新的开发和验收执行生效。"
                }
            })
        }
    };
}

var PROJECT_CONFIGURATION_PROVIDER = "platform.project-configuration";
var PROJECT_CONFIGURATION_VIEW = "".concat(PROJECT_CONFIGURATION_PROVIDER, "__configuration");
var projectConfigurationSectionSchema = z.enum([
    "type",
    "experts",
    "members",
    "skills",
    "connectors",
    "automations",
    "delete"
]);
var PROJECT_CONFIGURATION_ACTION_HANDLERS = {
    "type": "editors",
    "type-save": "editors",
    "experts": "editors",
    "expert-add": "editors",
    "expert-remove": "editors",
    "members": "editors",
    "member-add": "editors",
    "member-role": "editors",
    "member-remove": "editors",
    "member-owner": "editors",
    "member-invite": "editors",
    "invitation-revoke": "editors",
    "skill-catalog": "editors",
    "skill-install": "editors",
    "skill-toggle": "editors",
    "skill-remove": "editors",
    "connectors": "connectors",
    "connector-add": "connectors",
    "connector-remove": "connectors",
    "connector-connect": "connectors",
    "connector-status": "connectors",
    "connector-cancel": "connectors",
    "automations": "automations",
    "automation-save": "automations",
    "automation-options": "automations",
    "automation-pause": "automations",
    "automation-resume": "automations",
    "automation-delete": "automations",
    "automation-propose": "automations",
    "automation-accept": "automations",
    "automation-connectors": "automations",
    "delete": "editors"
};
var projectConfigurationActionSchema = z.custom(function(value) {
    return typeof value === "string" && Object.prototype.hasOwnProperty.call(PROJECT_CONFIGURATION_ACTION_HANDLERS, value);
});
var PROJECT_CONFIGURATION_ACTIONS = Object.keys(PROJECT_CONFIGURATION_ACTION_HANDLERS).map(function(key) {
    return projectConfigurationActionSchema.parse(key);
});

/**
 * Build a hierarchical tree structure from a flat list of DocumentInterface objects,
 * preserving explicit chunkIndex order whenever it is available.
 *
 * @template Metadata - Type of metadata, defaults to IDocChunkMetadata
 * @param documents - A flat array of DocumentInterface objects
 * @returns the hierarchical tree (root-level DocumentInterface[])
 */ function _define_property$h(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$h(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$h(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$d(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$d(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$d(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function buildChunkTree(documents) {
    if (!documents || documents.length === 0) return [];
    // Step 1. Build a lookup map for quick access by chunkId
    var map = new Map();
    // Keep the original retrieval/insertion order as a deterministic fallback.
    var inputOrder = new Map();
    documents.forEach(function(doc, index) {
        var chunkId = getChunkNodeId(doc);
        if (chunkId) {
            map.set(chunkId, _object_spread_props$d(_object_spread$h({}, doc), {
                metadata: _object_spread_props$d(_object_spread$h({}, doc.metadata), {
                    chunkId: chunkId,
                    children: []
                })
            }));
            inputOrder.set(chunkId, index);
        }
    });
    // Step 2. Organize nodes into tree
    var roots = [];
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = map.values()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var doc = _step.value;
            var parentId = doc.metadata.parentId;
            if (parentId && map.has(parentId)) {
                var parent = map.get(parentId);
                parent.metadata.children = parent.metadata.children || [];
                parent.metadata.children.push(doc);
            } else {
                roots.push(doc);
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    sortChunkNodes(roots, inputOrder);
    return roots;
}
function getChunkNodeId(document) {
    var _document_metadata;
    if ((_document_metadata = document.metadata) === null || _document_metadata === void 0 ? void 0 : _document_metadata.chunkId) {
        return document.metadata.chunkId;
    }
    if ("id" in document && typeof document.id === "string" && document.id) {
        return document.id;
    }
    return undefined;
}
function sortChunkNodes(nodes, inputOrder) {
    // Sort every sibling group, including nested children, so the rendered tree matches document flow.
    nodes.sort(function(left, right) {
        return compareChunkNodes(left, right, inputOrder);
    });
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = nodes[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var node = _step.value;
            var _node_metadata_children;
            if ((_node_metadata_children = node.metadata.children) === null || _node_metadata_children === void 0 ? void 0 : _node_metadata_children.length) {
                sortChunkNodes(node.metadata.children, inputOrder);
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
}
function compareChunkNodes(left, right, inputOrder) {
    // chunkIndex is the canonical document-order signal; input order is only a fallback.
    var leftIndex = getFiniteNumber(left.metadata.chunkIndex);
    var rightIndex = getFiniteNumber(right.metadata.chunkIndex);
    if (leftIndex !== undefined && rightIndex !== undefined && leftIndex !== rightIndex) {
        return leftIndex - rightIndex;
    }
    if (leftIndex !== undefined || rightIndex !== undefined) {
        return leftIndex !== undefined ? -1 : 1;
    }
    var _inputOrder_get;
    var leftOrder = (_inputOrder_get = inputOrder.get(left.metadata.chunkId)) !== null && _inputOrder_get !== void 0 ? _inputOrder_get : 0;
    var _inputOrder_get1;
    var rightOrder = (_inputOrder_get1 = inputOrder.get(right.metadata.chunkId)) !== null && _inputOrder_get1 !== void 0 ? _inputOrder_get1 : 0;
    return leftOrder - rightOrder;
}
function getFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}
/**
 * Find all leaf nodes (nodes without children).
 *
 * @param roots
 * @returns
 */ function collectTreeLeaves(roots) {
    var leaves = [];
    var collectLeaves = function(node) {
        var children = node.metadata.children;
        if (!children || children.length === 0) {
            leaves.push(node);
        } else {
            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
            try {
                for(var _iterator = children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                    var child = _step.value;
                    collectLeaves(child);
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                        _iterator.return();
                    }
                } finally{
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
        }
    };
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = roots[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var root = _step.value;
            collectLeaves(root);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return leaves;
}

var KnowledgeGraphStatus;
(function(KnowledgeGraphStatus) {
    KnowledgeGraphStatus["DISABLED"] = "disabled";
    KnowledgeGraphStatus["INDEXING"] = "indexing";
    KnowledgeGraphStatus["READY"] = "ready";
    KnowledgeGraphStatus["FAILED"] = "failed";
    KnowledgeGraphStatus["REBUILD_REQUIRED"] = "rebuild_required";
})(KnowledgeGraphStatus || (KnowledgeGraphStatus = {}));
var KnowledgeGraphIndexJobStatus;
(function(KnowledgeGraphIndexJobStatus) {
    KnowledgeGraphIndexJobStatus["QUEUED"] = "queued";
    KnowledgeGraphIndexJobStatus["RUNNING"] = "running";
    KnowledgeGraphIndexJobStatus["SUCCESS"] = "success";
    KnowledgeGraphIndexJobStatus["FAILED"] = "failed";
    KnowledgeGraphIndexJobStatus["CANCELLED"] = "cancelled";
})(KnowledgeGraphIndexJobStatus || (KnowledgeGraphIndexJobStatus = {}));
var KNOWLEDGE_GRAPH_DOCUMENT_STATUS_BATCH_SIZE = 100;

// Skill types
function _array_like_to_array$n(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$g(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array$e(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_rest$g() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_array$1(arr) {
    return _array_with_holes$g(arr) || _iterable_to_array$e(arr) || _unsupported_iterable_to_array$n(arr) || _non_iterable_rest$g();
}
function _unsupported_iterable_to_array$n(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$n(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$n(o, minLen);
}
var RUNTIME_SKILL_CAPABILITY_ID_PREFIX = "runtime-skill/v1";
function createRuntimeSkillCapabilityId(source) {
    return [
        RUNTIME_SKILL_CAPABILITY_ID_PREFIX,
        source.type,
        encodeURIComponent(source.ownerId),
        encodeURIComponent(source.skillId)
    ].join("/");
}
function parseRuntimeSkillCapabilityId(id) {
    var _id_split = _to_array$1(id.split("/")), prefix = _id_split[0], version = _id_split[1], type = _id_split[2], encodedOwnerId = _id_split[3], encodedSkillId = _id_split[4], rest = _id_split.slice(5);
    if (prefix !== "runtime-skill" || version !== "v1" || type !== "xpert" && type !== "project" || !encodedOwnerId || !encodedSkillId || rest.length) {
        return null;
    }
    try {
        var ownerId = decodeURIComponent(encodedOwnerId).trim();
        var skillId = decodeURIComponent(encodedSkillId).trim();
        return ownerId && skillId ? {
            type: type,
            ownerId: ownerId,
            skillId: skillId
        } : null;
    } catch (e) {
        return null;
    }
}
var WORKSPACE_PUBLIC_SKILL_SOURCE_PROVIDER = "workspace-public";
var WORKSPACE_PUBLIC_SKILL_REPOSITORY_NAME = "Workspace Shared Skills";
function genXpertSkillKey() {
    return letterStartSUID("Skill_");
}

function _array_like_to_array$m(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$f(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$e(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$f() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$e(arr, i) {
    return _array_with_holes$f(arr) || _iterable_to_array_limit$e(arr, i) || _unsupported_iterable_to_array$m(arr, i) || _non_iterable_rest$f();
}
function _unsupported_iterable_to_array$m(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$m(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$m(o, minLen);
}
var IGNORED_BOOLEAN_FLAGS = new Set([
    "-y",
    "--yes",
    "-g",
    "--global",
    "--copy"
]);
var REJECTED_FLAGS = new Set([
    "--list",
    "-l"
]);
function parseGithubSkillInstallCommand(input) {
    var tokens = tokenizeShellLike(input);
    if (!tokens.length) {
        throw new Error("GitHub skill install command is required");
    }
    var index = readCommandPrefix(tokens);
    var source = null;
    var branch = "";
    var repositoryPath = "";
    var skills = [];
    var installAll = false;
    while(index < tokens.length){
        var token = tokens[index];
        if (!token) {
            throw new Error("Empty arguments are not supported");
        }
        if (REJECTED_FLAGS.has(token)) {
            throw new Error("".concat(token, " is not supported for workspace skill installation"));
        }
        if (IGNORED_BOOLEAN_FLAGS.has(token)) {
            index += 1;
            continue;
        }
        if (token === "-a" || token === "--agent" || token.startsWith("--agent=")) {
            var result = readFlagValue(tokens, index, token, "--agent");
            index = result.nextIndex;
            continue;
        }
        if (token === "-s" || token === "--skill" || token.startsWith("--skill=")) {
            var result1 = readFlagValue(tokens, index, token, "--skill");
            var skill = result1.value.trim();
            if (!skill) {
                throw new Error("--skill requires a non-empty value");
            }
            skills.push(skill);
            index = result1.nextIndex;
            continue;
        }
        if (token === "--branch" || token.startsWith("--branch=")) {
            var result2 = readFlagValue(tokens, index, token, "--branch");
            branch = normalizeNonEmptyFlagValue(result2.value, "--branch");
            index = result2.nextIndex;
            continue;
        }
        if (token === "--path" || token.startsWith("--path=")) {
            var result3 = readFlagValue(tokens, index, token, "--path");
            repositoryPath = normalizeRepositoryPath(result3.value);
            if (!repositoryPath) {
                throw new Error("--path requires a non-empty value");
            }
            index = result3.nextIndex;
            continue;
        }
        if (token === "--all") {
            installAll = true;
            index += 1;
            continue;
        }
        if (token.startsWith("-")) {
            throw new Error('Unsupported option "'.concat(token, '"'));
        }
        if (source) {
            throw new Error('Unexpected argument "'.concat(token, '"'));
        }
        source = parseGithubSource(token);
        index += 1;
    }
    if (!source) {
        throw new Error("GitHub repository source is required");
    }
    if (installAll && skills.length) {
        throw new Error("--all cannot be used with --skill");
    }
    if (source.branch && branch && source.branch !== branch) {
        throw new Error("GitHub tree URL branch conflicts with --branch");
    }
    if (source.repositoryPath && repositoryPath && source.repositoryPath !== repositoryPath) {
        throw new Error("GitHub tree URL path conflicts with --path");
    }
    return {
        repositoryUrl: source.repositoryUrl,
        repositoryPath: repositoryPath || source.repositoryPath,
        branch: branch || source.branch,
        skills: skills,
        installAll: installAll
    };
}
function tokenizeShellLike(input) {
    var raw = typeof input === "string" ? input.trim() : "";
    if (!raw) {
        return [];
    }
    var tokens = [];
    var token = "";
    var tokenStarted = false;
    var quote = null;
    for(var index = 0; index < raw.length; index += 1){
        var char = raw[index];
        if (quote) {
            if (char === quote) {
                quote = null;
                tokenStarted = true;
                continue;
            }
            if (quote === '"' && char === "\\" && index + 1 < raw.length) {
                index += 1;
                token += raw[index];
                tokenStarted = true;
                continue;
            }
            token += char;
            tokenStarted = true;
            continue;
        }
        if (/\s/.test(char)) {
            if (tokenStarted) {
                tokens.push(token);
                token = "";
                tokenStarted = false;
            }
            continue;
        }
        if (char === '"' || char === "'") {
            quote = char;
            tokenStarted = true;
            continue;
        }
        if (char === "\\" && index + 1 < raw.length) {
            index += 1;
            token += raw[index];
            tokenStarted = true;
            continue;
        }
        token += char;
        tokenStarted = true;
    }
    if (quote) {
        throw new Error("Unclosed quote in install command");
    }
    if (tokenStarted) {
        tokens.push(token);
    }
    return tokens;
}
function readCommandPrefix(tokens) {
    if (tokens[0] === "npx") {
        var index = 1;
        while(tokens[index] === "-y" || tokens[index] === "--yes"){
            index += 1;
        }
        if (tokens[index] !== "skills" || tokens[index + 1] !== "add") {
            throw new Error('Use "npx skills add <github-source>" to install workspace skills');
        }
        return index + 2;
    }
    if (tokens[0] === "skills") {
        if (tokens[1] !== "add") {
            throw new Error('Use "skills add <github-source>" to install workspace skills');
        }
        return 2;
    }
    return 0;
}
function readFlagValue(tokens, index, token, flagName) {
    var equalsIndex = token.indexOf("=");
    if (equalsIndex > -1) {
        return {
            value: token.slice(equalsIndex + 1),
            nextIndex: index + 1
        };
    }
    var value = tokens[index + 1];
    if (!value || value.startsWith("-")) {
        throw new Error("".concat(flagName, " requires a value"));
    }
    return {
        value: value,
        nextIndex: index + 2
    };
}
function normalizeNonEmptyFlagValue(value, flagName) {
    var normalized = value.trim();
    if (!normalized) {
        throw new Error("".concat(flagName, " requires a non-empty value"));
    }
    return normalized;
}
function parseGithubSource(source) {
    var raw = source.trim();
    if (!raw) {
        throw new Error("GitHub repository source is required");
    }
    if (isLocalPath(raw)) {
        throw new Error("Local paths are not supported for workspace skill installation");
    }
    if (/^git@/i.test(raw)) {
        throw new Error("SSH Git URLs are not supported for workspace skill installation");
    }
    if (/^https?:\/\//i.test(raw) || /^github\.com\//i.test(raw)) {
        return parseGithubUrl(raw);
    }
    if (/^[^/\s]+\/[^/\s]+$/.test(raw)) {
        var _raw_split = _sliced_to_array$e(raw.split("/"), 2), owner = _raw_split[0], repoSegment = _raw_split[1];
        var repo = repoSegment.replace(/\.git$/i, "");
        if (!repo) {
            throw new Error("GitHub repository source must include owner and repository name");
        }
        return {
            repositoryUrl: "https://github.com/".concat(owner, "/").concat(repo),
            repositoryPath: "",
            branch: ""
        };
    }
    throw new Error("Only GitHub repository URLs or owner/repo sources are supported");
}
function parseGithubUrl(raw) {
    var _segments_, _segments_1, _segments_2;
    var candidate = /^https?:\/\//i.test(raw) ? raw : "https://".concat(raw);
    var url;
    try {
        url = new URL(candidate);
    } catch (e) {
        throw new Error("GitHub repository URL is invalid");
    }
    if (url.hostname.toLowerCase() !== "github.com") {
        throw new Error("Only github.com repository URLs are supported");
    }
    var segments = url.pathname.replace(/^\/+|\/+$/g, "").split("/").filter(Boolean).map(function(segment) {
        return decodeURIComponent(segment);
    });
    var owner = (_segments_ = segments[0]) === null || _segments_ === void 0 ? void 0 : _segments_.trim();
    var repo = (_segments_1 = segments[1]) === null || _segments_1 === void 0 ? void 0 : _segments_1.replace(/\.git$/i, "").trim();
    if (!owner || !repo) {
        throw new Error("GitHub repository URL must include owner and repository name");
    }
    if (segments.length > 2 && segments[2] !== "tree") {
        throw new Error("Only GitHub repository and tree URLs are supported");
    }
    var _segments__trim;
    var treeBranch = segments[2] === "tree" ? (_segments__trim = (_segments_2 = segments[3]) === null || _segments_2 === void 0 ? void 0 : _segments_2.trim()) !== null && _segments__trim !== void 0 ? _segments__trim : "" : "";
    var treePath = segments[2] === "tree" ? normalizeRepositoryPath(segments.slice(4).join("/")) : "";
    return {
        repositoryUrl: "https://github.com/".concat(owner, "/").concat(repo),
        repositoryPath: treePath,
        branch: treeBranch
    };
}
function normalizeRepositoryPath(value) {
    return value.trim().replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
}
function isLocalPath(value) {
    return value.startsWith(".") || value.startsWith("/") || value.startsWith("~") || /^file:/i.test(value) || /^[a-z]:[\\/]/i.test(value);
}

/** Boundary validation for persisted and API-provided scenario lists. */ function isPromptWorkflowScenarios(value) {
    return Array.isArray(value) && value.length <= 20 && value.every(function(item) {
        return !!item && typeof item === "object" && "id" in item && typeof item.id === "string" && !!item.id.trim() && item.id.length <= 100 && "label" in item && typeof item.label === "string" && !!item.label.trim() && item.label.length <= 120 && "args" in item && typeof item.args === "string" && !!item.args.trim() && item.args.length <= 20000;
    }) && new Set(value.map(function(item) {
        return item.id;
    })).size === value.length;
}

function _define_property$g(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$g(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$g(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$c(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$c(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$c(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var LEGACY_SANDBOX_COMPRESSION_MIDDLEWARE_NAME = "SandboxCompressionMiddleware";
var CONTEXT_COMPRESSION_MIDDLEWARE_NAME = "ContextCompressionMiddleware";
var XPERT_FILE_MEMORY_MIDDLEWARE_NAME = "XpertFileMemoryMiddleware";
var SKILLS_MIDDLEWARE_NAME = "skillsMiddleware";
function isMiddlewareToolEnabled(config) {
    if (typeof config === "boolean") {
        return config;
    }
    return (config === null || config === void 0 ? void 0 : config.enabled) !== false;
}
function isRequiredMiddleware(entity) {
    return (entity === null || entity === void 0 ? void 0 : entity.required) === true;
}
/** Default only omitted options. Preserve null and other invalid values for provider validation. */ function normalizeMiddlewareOptions(options) {
    return options === undefined ? {} : options;
}
function genXpertMiddlewareKey() {
    return letterStartSUID("Middleware_");
}
function normalizeMiddlewareProvider(provider) {
    if (provider === LEGACY_SANDBOX_COMPRESSION_MIDDLEWARE_NAME) {
        return CONTEXT_COMPRESSION_MIDDLEWARE_NAME;
    }
    return provider !== null && provider !== void 0 ? provider : "";
}
function normalizeMiddlewareNode(node) {
    var _node_entity;
    if ((node === null || node === void 0 ? void 0 : node.type) !== "workflow" || ((_node_entity = node.entity) === null || _node_entity === void 0 ? void 0 : _node_entity.type) !== WorkflowNodeTypeEnum.MIDDLEWARE) {
        return node;
    }
    var entity = node.entity;
    var provider = normalizeMiddlewareProvider(entity.provider);
    if (provider === entity.provider) {
        return node;
    }
    return _object_spread_props$c(_object_spread$g({}, node), {
        entity: _object_spread_props$c(_object_spread$g({}, entity), {
            provider: provider
        })
    });
}
function normalizeMiddlewareNodes(nodes) {
    return (nodes !== null && nodes !== void 0 ? nodes : []).map(function(node) {
        return normalizeMiddlewareNode(node);
    });
}
function isUserAddableAgentMiddleware(meta) {
    return (meta === null || meta === void 0 ? void 0 : meta.builtin) !== true;
}
var normalizeNodeKey = function(key) {
    var _key_split;
    return key === null || key === void 0 ? void 0 : (_key_split = key.split("/")) === null || _key_split === void 0 ? void 0 : _key_split[0];
};
function getAgentMiddlewareNodes(graph, agentKey) {
    var _graph_connections;
    var _graph_connections_filter_map_filter;
    var middlewares = (_graph_connections_filter_map_filter = (_graph_connections = graph.connections) === null || _graph_connections === void 0 ? void 0 : _graph_connections.filter(function(conn) {
        return conn.type === "workflow" && conn.from === agentKey;
    }).map(function(conn) {
        var _graph_nodes;
        var to = normalizeNodeKey(conn.to);
        return (_graph_nodes = graph.nodes) === null || _graph_nodes === void 0 ? void 0 : _graph_nodes.find(function(node) {
            return node.key === to;
        });
    }).filter(function(node) {
        return (node === null || node === void 0 ? void 0 : node.entity).type === WorkflowNodeTypeEnum.MIDDLEWARE;
    })) !== null && _graph_connections_filter_map_filter !== void 0 ? _graph_connections_filter_map_filter : [];
    return middlewares;
}

var CONTEXT_COMPRESSION_COMPONENT_TYPE = "context-compression";
function isContextCompressionComponentData(value) {
    if (!value || typeof value !== "object") {
        return false;
    }
    var candidate = value;
    return candidate.category === "Tool" && candidate.type === CONTEXT_COMPRESSION_COMPONENT_TYPE && (candidate.status === "running" || candidate.status === "success" || candidate.status === "fail");
}

/** Supported ownership scopes for interactive sandboxes and isolated background jobs. */ var SANDBOX_WORK_FOR_TYPES = [
    "user",
    "project",
    "environment",
    "job"
];

function _array_like_to_array$l(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$e(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$c(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$l(arr);
}
function _define_property$f(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$d(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$d(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$e() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$c() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$f(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$f(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$b(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$b(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$b(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _object_without_properties(source, excluded) {
    if (source == null) return {};
    var target = _object_without_properties_loose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _object_without_properties_loose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
function _sliced_to_array$d(arr, i) {
    return _array_with_holes$e(arr) || _iterable_to_array_limit$d(arr, i) || _unsupported_iterable_to_array$l(arr, i) || _non_iterable_rest$e();
}
function _to_consumable_array$c(arr) {
    return _array_without_holes$c(arr) || _iterable_to_array$d(arr) || _unsupported_iterable_to_array$l(arr) || _non_iterable_spread$c();
}
function _unsupported_iterable_to_array$l(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$l(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$l(o, minLen);
}
function isNil(value) {
    return value === null || value === undefined;
}
function isTextContent(content) {
    return !!content && typeof content === "object" && content.type === "text";
}
function isReasoningContent(content) {
    return !!content && typeof content === "object" && content.type === "reasoning";
}
function isComponentContent(content) {
    return !!content && typeof content === "object" && content.type === "component";
}
function inferContentSource(content) {
    if (typeof content === "string") {
        return "text";
    }
    switch(content === null || content === void 0 ? void 0 : content.type){
        case "text":
            return "text";
        case "reasoning":
            return "reasoning";
        case "component":
            return "component";
        case "memory":
            return "memory";
        default:
            return "content";
    }
}
function mapJoinHint(hint) {
    switch(hint){
        case "none":
            return "";
        case "space":
            return " ";
        case "line":
            return "\n";
        case "paragraph":
            return "\n\n";
        default:
            return "";
    }
}
function endsWithCodeFence(text) {
    var normalized = (text !== null && text !== void 0 ? text : "").replace(/[ \t]+$/g, "");
    return normalized.endsWith("```");
}
function shouldJoinWithoutSeparator(previous, current) {
    return !!(previous === null || previous === void 0 ? void 0 : previous.streamId) && previous.source === current.source && previous.streamId === current.streamId;
}
function getSeparator(previousType, previousText, nextText, joinHint) {
    if (!nextText || /^\s/.test(nextText)) {
        return "";
    }
    if (joinHint) {
        return mapJoinHint(joinHint);
    }
    if (endsWithCodeFence(previousText)) {
        return "\n";
    }
    if (previousText && !/[\s\n]$/.test(previousText)) {
        return "\n";
    }
    return "";
}
function normalizeIncomingContent(content, context) {
    if (typeof content !== "string") {
        return content;
    }
    return _object_spread$f({
        type: "text",
        text: content
    }, context.streamId ? {
        id: context.streamId
    } : {});
}
function ensureArrayContent(content) {
    if (Array.isArray(content)) {
        return content;
    }
    if (typeof content === "string" && content.length > 0) {
        return [
            {
                type: "text",
                text: content
            }
        ];
    }
    return [];
}
function findLastTextChunkIndexById(chunks, id) {
    for(var index = chunks.length - 1; index >= 0; index -= 1){
        var chunk = chunks[index];
        if (isTextContent(chunk) && chunk.id === id) {
            return index;
        }
    }
    return -1;
}
function getContentChunkSeparator(previous, nextText, joinHint) {
    if (!nextText || /^\s/.test(nextText)) {
        return "";
    }
    if (joinHint) {
        return mapJoinHint(joinHint);
    }
    if (!isTextContent(previous) || endsWithCodeFence(previous.text)) {
        return "";
    }
    if (previous.text && !/[\s\n]$/.test(previous.text)) {
        return "\n";
    }
    return "";
}
function stringifySingle(content) {
    if (isFileActivityContent(content) || isResourceCardContent(content)) return "";
    if (content.type === "text") {
        return content.text;
    }
    if (content.type === "component") {
        return JSON.stringify(content.data);
    }
    return JSON.stringify(content);
}
function filterText(content) {
    if (typeof content === "string") {
        return content;
    }
    if ((content === null || content === void 0 ? void 0 : content.type) === "text") {
        return content.text;
    }
    return "";
}
function mergeTextChunkForDisplay(previous, incoming) {
    return _object_spread$f(_object_spread_props$b(_object_spread$f({}, previous), {
        text: "".concat(previous.text).concat(incoming.text)
    }), !previous.id && incoming.id ? {
        id: incoming.id
    } : {}, !previous.agentKey && incoming.agentKey ? {
        agentKey: incoming.agentKey
    } : {}, !previous.xpertName && incoming.xpertName ? {
        xpertName: incoming.xpertName
    } : {});
}
function stripAutoDisplaySeparator(incoming, previousOriginal) {
    if ((previousOriginal === null || previousOriginal === void 0 ? void 0 : previousOriginal.type) === "component" && incoming.text.startsWith("\n\n")) {
        return _object_spread_props$b(_object_spread$f({}, incoming), {
            text: incoming.text.slice(1)
        });
    }
    return incoming;
}
function mergeComponentData(previous, incoming) {
    var _previous_data, _incoming_data;
    var _incoming_data1;
    var mergedIncomingData = Object.entries((_incoming_data1 = incoming.data) !== null && _incoming_data1 !== void 0 ? _incoming_data1 : {}).reduce(function(acc, param) {
        var _param = _sliced_to_array$d(param, 2), key = _param[0], value = _param[1];
        if (!isNil(value)) {
            acc[key] = value;
        }
        return acc;
    }, {});
    var _previous_data1;
    return _object_spread_props$b(_object_spread$f({}, previous, incoming), {
        data: _object_spread_props$b(_object_spread$f({}, (_previous_data1 = previous.data) !== null && _previous_data1 !== void 0 ? _previous_data1 : {}, mergedIncomingData), {
            created_date: ((_previous_data = previous.data) === null || _previous_data === void 0 ? void 0 : _previous_data.created_date) || ((_incoming_data = incoming.data) === null || _incoming_data === void 0 ? void 0 : _incoming_data.created_date)
        })
    });
}
function inferMessageAppendContext(content, fallbackSource) {
    return _object_spread$f({
        source: fallbackSource !== null && fallbackSource !== void 0 ? fallbackSource : inferContentSource(content)
    }, typeof content !== "string" && (content === null || content === void 0 ? void 0 : content.id) ? {
        streamId: String(content.id)
    } : {});
}
function resolveMessageAppendContext(options) {
    var inferredContext = inferMessageAppendContext(options.incoming, options.fallbackSource);
    var appendContext = typeof options.incoming === "string" && !inferredContext.streamId && options.fallbackStreamId ? _object_spread_props$b(_object_spread$f({}, inferredContext), {
        streamId: options.fallbackStreamId
    }) : inferredContext;
    var messageContext = shouldJoinWithoutSeparator(options.previous, appendContext) ? _object_spread_props$b(_object_spread$f({}, appendContext), {
        joinHint: "none"
    }) : appendContext;
    return {
        appendContext: appendContext,
        messageContext: messageContext
    };
}
/**
 * Stateful helper for streaming append.
 *
 * It keeps the previous append context and resolves the current one, so callers
 * can avoid passing `previous` manually for every chunk and still get stable
 * join behavior (for example, same source + same stream -> `joinHint: 'none'`).
 *
 * Call `reset()` at turn/session boundaries to prevent cross-turn contamination.
 */ function createMessageAppendContextTracker() {
    var initial = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
    var previous = initial;
    return {
        resolve: function resolve(options) {
            var resolved = resolveMessageAppendContext(_object_spread_props$b(_object_spread$f({}, options), {
                previous: previous
            }));
            if (!isFileActivityContent(options.incoming) && !isResourceCardContent(options.incoming)) previous = resolved.appendContext;
            return resolved;
        },
        reset: function reset() {
            previous = null;
        },
        current: function current() {
            return previous;
        }
    };
}
/**
 * Append one incoming chunk into a chat message in place.
 *
 * Behavior:
 * - Keeps `aiMessage` object reference stable (caller may hold this object).
 * - Updates message properties with new references (`content`/`reasoning` arrays)
 *   so UI change detection that relies on reference changes can react reliably.
 * - Applies context-aware merge rules for text/reasoning/component chunks.
 * - `previous` must be supplied by caller when same-stream join inference is needed.
 */ function appendMessageContent(aiMessage, incoming, context) {
    var card = parseResourceCardContent(incoming);
    if (card) {
        aiMessage.content = upsertResourceCardContent(ensureArrayContent(aiMessage.content), card);
        return;
    }
    var receipt = parseFileActivityContent(incoming);
    if (receipt) {
        aiMessage.content = upsertFileActivityContent(ensureArrayContent(aiMessage.content), receipt);
        return;
    }
    aiMessage.status = "answering";
    var _ref = context !== null && context !== void 0 ? context : {}, _ref_previous = _ref.previous, previous = _ref_previous === void 0 ? null : _ref_previous, contextWithoutPrevious = _object_without_properties(_ref, [
        "previous"
    ]);
    var appendContext = _object_spread$f({}, inferMessageAppendContext(incoming), contextWithoutPrevious);
    var _appendContext_joinHint;
    var joinHint = (_appendContext_joinHint = appendContext.joinHint) !== null && _appendContext_joinHint !== void 0 ? _appendContext_joinHint : shouldJoinWithoutSeparator(previous, appendContext) ? "none" : undefined;
    var messageContext = joinHint ? _object_spread_props$b(_object_spread$f({}, appendContext), {
        joinHint: joinHint
    }) : appendContext;
    var content = normalizeIncomingContent(incoming, appendContext);
    if (isReasoningContent(content)) {
        var _aiMessage_reasoning;
        var reasoning = (_aiMessage_reasoning = aiMessage.reasoning) !== null && _aiMessage_reasoning !== void 0 ? _aiMessage_reasoning : [];
        var lastReasoning = reasoning[reasoning.length - 1];
        if ((lastReasoning === null || lastReasoning === void 0 ? void 0 : lastReasoning.id) === content.id) {
            var mergedReasoning = _object_spread_props$b(_object_spread$f({}, lastReasoning), {
                text: "".concat(lastReasoning.text).concat(content.text)
            });
            aiMessage.reasoning = _to_consumable_array$c(reasoning.slice(0, reasoning.length - 1)).concat([
                mergedReasoning
            ]);
        } else {
            aiMessage.reasoning = _to_consumable_array$c(reasoning).concat([
                content
            ]);
        }
        aiMessage.status = "reasoning";
        return;
    }
    var chunks = ensureArrayContent(aiMessage.content);
    if (isTextContent(content)) {
        if (content.id) {
            var index = chunks.findIndex(function(item) {
                return isTextContent(item) && item.id === content.id;
            });
            if (index > -1) {
                var mergedContent = _object_spread$f(_object_spread_props$b(_object_spread$f({}, chunks[index]), {
                    text: "".concat(chunks[index].text).concat(content.text)
                }), !chunks[index].id && content.id ? {
                    id: content.id
                } : {}, !chunks[index].agentKey && content.agentKey ? {
                    agentKey: content.agentKey
                } : {}, !chunks[index].xpertName && content.xpertName ? {
                    xpertName: content.xpertName
                } : {});
                aiMessage.content = _to_consumable_array$c(chunks.slice(0, index)).concat([
                    mergedContent
                ], _to_consumable_array$c(chunks.slice(index + 1)));
                return;
            }
        }
        var lastContent = chunks[chunks.length - 1];
        // When the incoming chunk has an id (streamId), search backward for an existing
        // chunk with the same id so that interleaved concurrent streams (A→B→A) are
        // merged into the correct segment rather than appended as new fragments.
        if (!!content.id) {
            var existingIndex = findLastTextChunkIndexById(chunks, content.id);
            if (existingIndex > -1) {
                var existing = chunks[existingIndex];
                var merged = _object_spread_props$b(_object_spread$f({}, existing), {
                    text: "".concat(existing.text).concat(content.text)
                });
                var nextChunks = _to_consumable_array$c(chunks);
                nextChunks[existingIndex] = merged;
                aiMessage.content = nextChunks;
                return;
            }
        } else if (isTextContent(lastContent) && messageContext.joinHint === "none") {
            var mergedLastContent = _object_spread_props$b(_object_spread$f({}, lastContent), {
                text: "".concat(lastContent.text).concat(content.text)
            });
            aiMessage.content = _to_consumable_array$c(chunks.slice(0, chunks.length - 1)).concat([
                mergedLastContent
            ]);
            return;
        }
        var separator = getContentChunkSeparator(lastContent, content.text, messageContext.joinHint);
        var appended = _object_spread_props$b(_object_spread$f({}, content), {
            text: separator + content.text
        });
        aiMessage.content = _to_consumable_array$c(chunks).concat([
            appended
        ]);
        return;
    }
    var nextChunks1 = _to_consumable_array$c(chunks);
    if (isComponentContent(content) && content.id) {
        var index1 = nextChunks1.findIndex(function(item) {
            return isComponentContent(item) && item.id === content.id;
        });
        if (index1 > -1) {
            nextChunks1[index1] = mergeComponentData(nextChunks1[index1], content);
        } else {
            nextChunks1.push(content);
        }
    } else {
        nextChunks1.push(content);
    }
    aiMessage.content = nextChunks1;
}
function appendMessagePlainText(accumulator, incoming, context) {
    var resolvedContext = _object_spread$f({}, inferMessageAppendContext(incoming), context !== null && context !== void 0 ? context : {});
    var nextText = filterText(incoming);
    if (!nextText) {
        return accumulator !== null && accumulator !== void 0 ? accumulator : "";
    }
    var previous = accumulator !== null && accumulator !== void 0 ? accumulator : "";
    var separator = getSeparator("text", previous, nextText, resolvedContext.joinHint);
    return previous + separator + nextText;
}
/**
 * Creates a display-only content view that reassembles text chunks belonging to
 * the same stream id. This preserves markdown continuity without changing the
 * underlying stored/streamed message structure.
 */ function mergeMessageContentForDisplay(content) {
    if (!content) {
        return null;
    }
    if (typeof content === "string") {
        return content.length ? [
            {
                type: "text",
                text: content
            }
        ] : null;
    }
    if (!Array.isArray(content)) {
        return [
            content
        ];
    }
    var merged = [];
    var textIndexById = new Map();
    content.forEach(function(item, itemIndex) {
        if (!isTextContent(item)) {
            merged.push(item);
            return;
        }
        if (item.id) {
            var mergedIndex = textIndexById.get(item.id);
            if (mergedIndex !== undefined && isTextContent(merged[mergedIndex])) {
                var previousOriginal = content[itemIndex - 1];
                merged[mergedIndex] = mergeTextChunkForDisplay(merged[mergedIndex], stripAutoDisplaySeparator(item, previousOriginal));
                return;
            }
            textIndexById.set(item.id, merged.length);
            merged.push(_object_spread$f({}, item));
            return;
        }
        var lastItem = merged[merged.length - 1];
        if (isTextContent(lastItem) && !lastItem.id && lastItem.agentKey === item.agentKey && lastItem.xpertName === item.xpertName) {
            merged[merged.length - 1] = mergeTextChunkForDisplay(lastItem, item);
            return;
        }
        merged.push(_object_spread$f({}, item));
    });
    return merged.length ? merged : null;
}
function stringifyMessageContent(content) {
    if (typeof content === "string") {
        return content;
    }
    if (Array.isArray(content)) {
        var result = "";
        var previousContext = null;
        content.forEach(function(item) {
            if (isFileActivityContent(item) || isResourceCardContent(item)) return;
            var itemContext = inferMessageAppendContext(item);
            var joinHint = shouldJoinWithoutSeparator(previousContext, itemContext) ? "none" : undefined;
            result = appendMessagePlainText(result, stringifySingle(item), _object_spread$f({}, itemContext, joinHint ? {
                joinHint: joinHint
            } : {}));
            previousContext = itemContext;
        });
        return result;
    }
    return stringifySingle(content);
}
function filterMessageText(content) {
    if (typeof content === "string") {
        return content;
    }
    if (Array.isArray(content)) {
        var result = "";
        var previousContext = null;
        content.forEach(function(item) {
            var nextText = filterText(item);
            if (!nextText) {
                return;
            }
            var itemContext = inferMessageAppendContext(item);
            var joinHint = shouldJoinWithoutSeparator(previousContext, itemContext) ? "none" : undefined;
            result = appendMessagePlainText(result, nextText, _object_spread$f({}, itemContext, joinHint ? {
                joinHint: joinHint
            } : {}));
            previousContext = itemContext;
        });
        return result || null;
    }
    return filterText(content) || null;
}

var SANDBOX_FILE_OUTPUT_RULES = [
    {
        extension: ".docx",
        kind: "document",
        mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        format: "docx"
    },
    {
        extension: ".xlsx",
        kind: "spreadsheet",
        mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        format: "xlsx"
    },
    {
        extension: ".pptx",
        kind: "presentation",
        mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        format: "pptx"
    },
    {
        extension: ".pdf",
        kind: "document",
        mimeType: "application/pdf",
        format: "pdf"
    },
    {
        extension: ".json",
        kind: "file",
        mimeType: "application/json",
        format: "json"
    },
    {
        extension: ".md",
        kind: "document",
        mimeType: "text/markdown",
        format: "utf8"
    },
    {
        extension: ".txt",
        kind: "file",
        mimeType: "text/plain",
        format: "utf8"
    },
    {
        extension: ".csv",
        kind: "spreadsheet",
        mimeType: "text/csv",
        format: "utf8"
    },
    {
        extension: ".tsv",
        kind: "spreadsheet",
        mimeType: "text/tab-separated-values",
        format: "utf8"
    },
    {
        extension: ".html",
        kind: "file",
        mimeType: "text/html",
        format: "utf8"
    },
    {
        extension: ".png",
        kind: "image",
        mimeType: "image/png",
        format: "png"
    },
    {
        extension: ".jpg",
        kind: "image",
        mimeType: "image/jpeg",
        format: "jpeg"
    },
    {
        extension: ".jpeg",
        kind: "image",
        mimeType: "image/jpeg",
        format: "jpeg"
    },
    {
        extension: ".svg",
        kind: "image",
        mimeType: "image/svg+xml",
        format: "utf8"
    }
];

function isEvidenceProposal(value) {
    return "strategy" in value && "candidateId" in value && !!value.strategy && !!value.candidateId;
}
function isLearningProposal(value) {
    return value.sourceKind === "learning_events";
}
function isPreparedCandidate(value) {
    return !!value.strategy && value.definition !== undefined;
}
function isProviderEvaluation(value) {
    return value.evaluatorKind === "strategy_checks";
}
function isReplayEvaluation(value) {
    return value.evaluatorKind === "golden_replay";
}
function isProviderRelease(value) {
    return value.publicationKind === "provider_version";
}
function isStagedRelease(value) {
    return value.publicationKind === "staged_rollout";
}

var FEEDBACK_LEARNING_STRATEGY = {
    id: "feedback_learning",
    version: "1",
    label: {
        en_US: "Feedback learning",
        zh_Hans: "反馈学习进化"
    },
    inputs: [
        "learning_events"
    ],
    learning: {
        mode: "feedback",
        minimumEvents: 3,
        minimumSubjects: 2,
        maximumAgeDays: 90,
        trustLevels: [
            "L2",
            "L3",
            "L4"
        ]
    },
    evidenceKinds: [
        "execution"
    ],
    candidate: {
        builder: "change_set"
    },
    evaluations: [
        {
            key: "golden_replay",
            kind: "golden_replay",
            requiredChecks: []
        }
    ],
    approval: "human",
    publication: {
        mode: "staged_rollout",
        effect: "activation"
    }
};
function evidenceDrivenStrategy(input) {
    var _input_effect;
    return {
        id: "evidence_driven",
        version: input.version,
        label: {
            en_US: "Evidence-driven evolution",
            zh_Hans: "证据驱动进化"
        },
        inputs: [
            "business_evidence"
        ],
        learning: {
            mode: "none"
        },
        evidenceKinds: input.evidenceKinds,
        candidate: {
            builder: "target_draft"
        },
        evaluations: [
            {
                key: "domain_checks",
                kind: "target_checks",
                requiredChecks: input.requiredChecks
            }
        ],
        approval: "human",
        publication: {
            mode: "version_write",
            effect: (_input_effect = input.effect) !== null && _input_effect !== void 0 ? _input_effect : "explicit_adoption"
        }
    };
}
var HUMAN_PROPOSAL_STRATEGY = {
    id: "human_proposal",
    version: "1",
    label: {
        en_US: "Human proposal",
        zh_Hans: "人工提案进化"
    },
    inputs: [
        "manual"
    ],
    learning: {
        mode: "none"
    },
    evidenceKinds: [
        "feedback",
        "artifact"
    ],
    candidate: {
        builder: "target_draft"
    },
    evaluations: [],
    approval: "human",
    publication: {
        mode: "version_write",
        effect: "activation"
    }
};

var MCP_CAPABILITY_DESCRIPTOR_VERSION = 1;
var MCP_CAPABILITY_TYPES = [
    "tool",
    "resource",
    "resource_template",
    "prompt",
    "app"
];
var MCP_TOOL_RISKS = [
    "read",
    "write",
    "dangerous"
];
var MCP_TOOL_SIDE_EFFECTS = [
    "none",
    "reversible",
    "irreversible"
];
var MCP_TOOL_IDEMPOTENCY = [
    "safe",
    "idempotent",
    "non_idempotent"
];
var MCP_REQUIRED_CONTEXTS = [
    "tenant",
    "organization",
    "workspace",
    "principal",
    "project",
    "conversation",
    "agent",
    "execution",
    "store",
    "checkpoint"
];
var MCP_CAPABILITY_VISIBILITIES = [
    "model",
    "app"
];
/** Resolve the declaration default; callers must apply explicit Publication policy first. */ function defaultMcpToolApprovalMode(descriptor) {
    var _descriptor_defaultApprovalMode;
    return (_descriptor_defaultApprovalMode = descriptor.defaultApprovalMode) !== null && _descriptor_defaultApprovalMode !== void 0 ? _descriptor_defaultApprovalMode : descriptor.behavior.risk === "read" ? "allow" : descriptor.behavior.risk === "write" ? "confirm" : "deny";
}
/** Dangerous tools may run directly only when their owner explicitly declares that policy. */ function canAllowMcpToolDirectly(descriptor) {
    return descriptor.behavior.risk !== "dangerous" || descriptor.defaultApprovalMode === "allow";
}

/** Opaque form placeholder. Array secrets append a source reference; clients must return it unchanged. */ var MCP_CONFIGURATION_SECRET_MASK = "__xpert_mcp_secret_unchanged__";
var MCP_PROTOCOL_VERSION = "2026-07-28";
var MCP_TASK_EXTENSION_ID = "io.modelcontextprotocol/tasks";
var MCP_HTTP_CORS_REQUEST_HEADERS = [
    "MCP-Protocol-Version",
    "Mcp-Session-Id",
    "Mcp-Method",
    "Mcp-Name",
    "Traceparent",
    "Tracestate",
    "Baggage",
    "X-Request-Id"
];
var MCP_HTTP_CORS_EXPOSED_HEADERS = [
    "Content-Location",
    "WWW-Authenticate",
    "MCP-Protocol-Version",
    "Mcp-Session-Id",
    "X-Request-Id"
];
var MCP_PUBLICATION_STATUSES = [
    "draft",
    "active",
    "disabled"
];
var MCP_PUBLICATION_REVIEW_STATUSES = [
    "current",
    "required"
];
var MCP_AUTH_METHODS = [
    "api_key",
    "oauth"
];
var MCP_CAPABILITY_APPROVAL_MODES = [
    "deny",
    "allow",
    "confirm"
];
var MCP_TASK_STATUSES = [
    "working",
    "input_required",
    "completed",
    "failed",
    "cancelled"
];

var MCP_API_KEY_SUBJECT_TYPES = [
    "user",
    "service_account"
];

var MCP_INVOCATION_STATUSES = [
    "started",
    "succeeded",
    "failed",
    "denied"
];

var KNOWLEDGE_AUTOMATIC_TAG_CANDIDATES = 50;
var KNOWLEDGE_AUTOMATIC_TAG_MAXIMUM = 10;
var KNOWLEDGE_AUTOMATIC_TAG_TEXT_BUDGET = 12000;

var DEFAULT_KNOWLEDGE_KEYWORD_ANALYZER = "basic";

/** Exhaustive attribution shared by queries, ledger export and UI. */ function modelExecutionEntry(source) {
    switch(source.type){
        case "cli_session":
            return "cli";
        case "agent_invocation":
            return "agent_runtime";
        case "shell_execution":
            return "shell";
    }
}
function modelExecutionSourceId(source) {
    switch(source.type){
        case "cli_session":
            return source.cliSessionId;
        case "agent_invocation":
            return source.invocationId;
        case "shell_execution":
            return source.executionId;
    }
}
var MODEL_EXECUTION_POLICY_SETTING = "modelExecutionPolicy";
/** Explicit model policy source in a Runtime binding; independent of the calling Agent identity. */ var agentRuntimeModelSourceSchema = z.object({
    type: z.literal("assistant"),
    xpertId: z.string().uuid()
}).strict();

/** Credential-free tuning snapshot. Null persists an explicit opt-out of optional provider defaults. */ var modelExecutionParametersSchema = z.object({
    temperature: z.number().finite().nullable().optional(),
    top_p: z.number().finite().nullable().optional(),
    top_k: z.number().int().nonnegative().nullable().optional(),
    presence_penalty: z.number().finite().nullable().optional(),
    frequency_penalty: z.number().finite().nullable().optional(),
    repetition_penalty: z.number().finite().nullable().optional(),
    seed: z.number().int().nonnegative().nullable().optional(),
    max_tokens: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).nullable().optional(),
    enable_thinking: z.boolean().nullable().optional(),
    thinking_budget: z.number().int().nonnegative().nullable().optional(),
    reasoning_effort: z.enum([
        "none",
        "minimal",
        "low",
        "medium",
        "high",
        "xhigh",
        "max"
    ]).nullable().optional(),
    thinking: z.enum([
        "enabled",
        "disabled",
        "adaptive"
    ]).nullable().optional(),
    budget_tokens: z.number().int().nonnegative().nullable().optional()
}).strict();

/**
 * Running means accepted; actual work start requires an observation.
 * Only succeeded, failed and cancelled are terminal. Unknown must be reconciled without replay.
 */ var agentInvocationStatusSchema = z.enum([
    "queued",
    "running",
    "waiting",
    "cancelling",
    "succeeded",
    "failed",
    "cancelled",
    "unknown"
]);
var agentInvocationTerminalStatusSchema = z.enum([
    "succeeded",
    "failed",
    "cancelled"
]);
/** Activity and reported progress are separate from business acceptance. No invented percentage. */ var agentRuntimeProgressSchema = z.object({
    source: z.enum([
        "executor",
        "host"
    ]),
    observedAt: z.string().datetime({
        offset: true
    }),
    startedAt: z.string().datetime({
        offset: true
    }).optional(),
    phase: z.string().trim().min(1).max(200).optional(),
    summary: z.string().max(2000).optional(),
    steps: z.object({
        completed: z.number().int().nonnegative(),
        total: z.number().int().positive()
    }).strict().refine(function(steps) {
        return steps.completed <= steps.total;
    }).optional()
}).strict();

/** Host-owned routing context for a native Assistant invocation, not a separate runtime provider. */ var assistantTaskGroupContextSchema = z.object({
    type: z.literal("group_member"),
    groupId: z.string().uuid(),
    participantId: z.string().uuid(),
    sourceParticipantId: z.string().uuid(),
    projectId: z.string().uuid()
}).strict();
function assistantTaskGroupContext(target) {
    if (target.provider !== "xpert-task") return null;
    var parsed = z.object({
        executionContext: assistantTaskGroupContextSchema
    }).safeParse(target.configuration);
    return parsed.success ? parsed.data.executionContext : null;
}

var AGENT_OUTPUT_MAX_PATHS = 128;
/** Relative file selections only. A declaration does not grant filesystem access. */ var agentResultPathSchema = z.string().min(1).max(1024).refine(function(path) {
    return !path.startsWith("/") && !/^[a-zA-Z]:/.test(path) && !path.includes("\\") && !/[\x00-\x1f]/.test(path) && path.split("/").every(function(part) {
        return part !== "" && part !== "." && part !== "..";
    });
}, "Expected a relative file path");
/** An export selection is a list of exact files, never a filesystem search. */ var deliveryPathsSchema = z.array(agentResultPathSchema.refine(function(path) {
    return !/[*?\[\]{}]/.test(path);
}, "Delivery paths must be exact relative file paths, without wildcards. Select paths explicitly when they are known.")).min(1).max(AGENT_OUTPUT_MAX_PATHS).optional().describe("Exact file paths relative to the task working directory. No wildcards/globs or directories. If filenames are determined during execution, collect them with delivery recovery once the exact paths are known.");
/** Omission means no file delivery. A report file is optional and independent of artifact export mode. */ var agentOutputDeliverySchema = z.discriminatedUnion("mode", [
    z.object({
        mode: z.literal("none"),
        reportPath: agentResultPathSchema.optional()
    }).strict(),
    z.object({
        mode: z.literal("files"),
        paths: deliveryPathsSchema,
        reportPath: agentResultPathSchema.optional()
    }).strict(),
    z.object({
        mode: z.literal("archive"),
        paths: deliveryPathsSchema,
        reportPath: agentResultPathSchema.optional()
    }).strict()
]);
/** A delivery retry cannot relaunch the executor or change its originally selected report. */ var agentDeliveryRecoverySchema = z.object({
    expectedRevision: z.number().int().nonnegative(),
    paths: deliveryPathsSchema
}).strict();

var projectTaskSpecificationDigestSchema = z.string().regex(/^sha256:[a-f0-9]{64}$/);
/** Only requirements belong here; status, progress, assignment and generic revision do not. */ var projectTaskSpecificationSchema = z.object({
    version: z.literal(1),
    title: z.string().trim().min(1).max(500),
    description: z.string().max(32000).optional(),
    requirements: z.array(z.string().trim().min(1).max(4000)).min(1).max(64),
    steps: z.array(z.object({
        stepIndex: z.number().int().positive(),
        description: z.string().trim().min(1).max(4000)
    }).strict()).max(128)
}).strict().refine(function(specification) {
    return new Set(specification.steps.map(function(step) {
        return step.stepIndex;
    })).size === specification.steps.length;
}, "Step indices must be unique");
/** The host verifies the digest against the specification at the persistence boundary. */ var projectTaskSpecificationSnapshotSchema = z.object({
    digest: projectTaskSpecificationDigestSchema,
    specification: projectTaskSpecificationSchema
}).strict();
/** Versioned references, not paths or access grants. Resolve and authorize before reading. */ var projectTaskEvidenceReferenceSchema = z.discriminatedUnion("type", [
    z.object({
        type: z.literal("artifact"),
        artifactId: z.string().uuid(),
        versionId: z.string().uuid()
    }).strict(),
    z.object({
        type: z.literal("invocation_result"),
        invocationId: z.string().uuid(),
        revision: z.number().int().nonnegative()
    }).strict(),
    z.object({
        type: z.literal("workspace_snapshot"),
        snapshotId: z.string().uuid(),
        digest: projectTaskSpecificationDigestSchema
    }).strict()
]);
var projectTaskReviewerSchema = z.object({
    bindingId: z.string().uuid(),
    mode: z.enum([
        "evidence_only",
        "execution"
    ])
}).strict();
/** Host-owned identity of a review work item; retries cannot change its candidate. */ var projectTaskReviewSubjectSchema = z.object({
    implementationTaskId: z.string().uuid(),
    implementationExecutionId: z.string().uuid(),
    specificationDigest: projectTaskSpecificationDigestSchema
}).strict();
var projectTaskReworkSchema = z.object({
    reviewExecutionId: z.string().uuid(),
    feedback: z.string().trim().min(1).max(16000).describe("Concrete rework instructions based on the referenced Markdown review.")
}).strict();
/** Relative paths are references, never access grants. Runtimes own snapshot exclusions and containment. */ var projectTaskRelativePathSchema = z.string().min(1).max(1000).refine(function(value) {
    return !/^(?:\/|[a-zA-Z]:)/.test(value) && !value.includes("\\") && !/[\x00-\x1f\x7f]/.test(value) && value.split("/").every(function(part) {
        return part.length > 0 && part !== "." && part !== "..";
    });
});
var projectTaskCandidatePathSchema = projectTaskRelativePathSchema.describe("Candidate path relative to the authorized project workspace.");
var projectTaskEvidencePathSchema = projectTaskRelativePathSchema.describe("Evidence path relative to the review workspace.");
var projectTaskExecutionPurposeFieldsSchema = z.discriminatedUnion("type", [
    z.object({
        type: z.literal("implementation"),
        reviewer: projectTaskReviewerSchema.optional(),
        coordination: z.object({
            taskId: z.string().uuid(),
            specificationDigest: projectTaskSpecificationDigestSchema
        }).strict().optional(),
        rework: projectTaskReworkSchema.optional()
    }).strict(),
    z.object({
        type: z.literal("review"),
        mode: z.enum([
            "evidence_only",
            "execution"
        ]).optional(),
        candidatePaths: z.array(projectTaskCandidatePathSchema).min(1).max(64).optional(),
        implementationExecutionId: z.string().uuid(),
        implementationTaskId: z.string().uuid().optional(),
        implementationInvocationId: z.string().uuid(),
        specificationDigest: projectTaskSpecificationDigestSchema,
        evidence: z.array(projectTaskEvidenceReferenceSchema).min(1).max(64)
    }).strict()
]);
function validateReviewCandidate(purpose, context) {
    if (purpose.type !== "review") return;
    if (purpose.mode === "execution" !== Boolean(purpose.candidatePaths)) context.addIssue({
        code: "custom",
        path: [
            "candidatePaths"
        ],
        message: "Execution review requires candidate paths; evidence-only review does not use a workspace."
    });
    if (purpose.candidatePaths && new Set(purpose.candidatePaths).size !== purpose.candidatePaths.length) context.addIssue({
        code: "custom",
        path: [
            "candidatePaths"
        ],
        message: "Candidate paths must be unique."
    });
}
var projectTaskExecutionPurposeSchema = projectTaskExecutionPurposeFieldsSchema.superRefine(validateReviewCandidate);
var projectTaskExecutionReferenceSchema = z.object({
    projectId: z.string().uuid(),
    projectTaskId: z.string().uuid(),
    taskExecutionId: z.string().uuid()
}).strict();
/** Host-owned attempt context. Review is a new attempt and grants no completion authority. */ var projectTaskExecutionContextSchema = projectTaskExecutionReferenceSchema.extend({
    specification: projectTaskSpecificationSnapshotSchema,
    purpose: projectTaskExecutionPurposeSchema
}).strict().superRefine(function(value, ctx) {
    if (value.purpose.type !== "review") return;
    if (value.purpose.implementationExecutionId === value.taskExecutionId) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            path: [
                "purpose"
            ],
            message: "Review must reference another attempt"
        });
    }
    if (value.purpose.specificationDigest !== value.specification.digest) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            path: [
                "purpose"
            ],
            message: "Review specification must match its subject"
        });
    }
});
/** A receipt is neither a business completion decision nor proof that the process has started. */ var projectTaskDispatchReceiptSchema = projectTaskExecutionReferenceSchema.extend({
    invocationId: z.string().uuid(),
    status: agentInvocationStatusSchema
}).strict();
/** Explicit delegation. Routing and actor identity come from the host. */ var projectTaskDispatchFieldsSchema = z.object({
    requestId: z.string().uuid(),
    taskId: z.string().uuid(),
    expectedRevision: z.number().int().positive(),
    bindingId: z.string().uuid().optional(),
    target: z.object({
        type: z.literal("group_member"),
        participantId: z.string().uuid()
    }).strict().optional(),
    purpose: projectTaskExecutionPurposeSchema.optional(),
    reviewAsSubtask: z.boolean().optional().describe("Create or resume a review subtask for the pinned implementation. taskId identifies the implementation task."),
    delivery: agentOutputDeliverySchema.optional(),
    instructions: z.string().trim().max(16000).default("")
}).strict();
var hasOneDispatchTarget = function(input) {
    return Boolean(input.bindingId) !== Boolean(input.target);
};
var projectTaskDispatchInputSchema = projectTaskDispatchFieldsSchema.refine(hasOneDispatchTarget, "Choose exactly one Runtime binding or group member");
var projectTaskDispatchToolInputSchema = projectTaskDispatchFieldsSchema.omit({
    requestId: true
}).extend({
    purpose: z.discriminatedUnion("type", [
        projectTaskExecutionPurposeFieldsSchema.options[0].omit({
            coordination: true
        }),
        projectTaskExecutionPurposeFieldsSchema.options[1].omit({
            implementationTaskId: true
        })
    ]).superRefine(validateReviewCandidate).optional()
}).refine(hasOneDispatchTarget, "Choose exactly one Runtime binding or group member");
/** Markdown is authored evidence. Only an explicit coordinator decision accepts a task. */ var projectTaskReviewReportSchema = z.object({
    format: z.literal("markdown"),
    markdown: z.string().min(1)
}).strict();
// Agent-facing references bind an observed candidate; authorization remains with the host.
var projectTaskDecisionToolInputSchema = z.object({
    decisionRef: z.string().max(200).regex(/^pd1\/[0-9a-f-]{36}\/[0-9a-f-]{36}\/[0-9a-f]{64}$/),
    outcome: z.enum([
        "accept",
        "rework"
    ]),
    rationale: z.string().trim().min(1).max(8000),
    checks: z.array(z.string().trim().min(1).max(4000)).max(64).optional()
}).strict();
var projectTaskDecisionInputSchema = z.object({
    requestId: z.string().uuid(),
    taskId: z.string().uuid(),
    expectedRevision: z.number().int().positive(),
    implementationExecutionId: z.string().uuid(),
    specificationDigest: projectTaskSpecificationDigestSchema,
    evidence: z.array(projectTaskEvidenceReferenceSchema).min(1).max(64),
    reviewExecutionId: z.string().uuid().optional(),
    outcome: z.enum([
        "accept",
        "rework"
    ]),
    rationale: z.string().trim().min(1).max(8000),
    checks: z.array(z.string().trim().min(1).max(4000)).max(64)
}).strict();
var projectTaskDecisionSchema = projectTaskDecisionInputSchema.extend({
    actorId: z.string().uuid(),
    actorType: z.enum([
        "user",
        "xpert",
        "project_agent"
    ]),
    executionId: z.string().uuid().optional(),
    reviewResult: z.object({
        invocationId: z.string().uuid(),
        revision: z.number().int().nonnegative(),
        sha256: z.string().regex(/^[a-f0-9]{64}$/)
    }).strict().optional(),
    decidedAt: z.string().datetime(),
    taskRevision: z.number().int().positive()
}).strict();

/** Machine keys are independent of labels. Reserve mutation keys; record readers must still check own fields. */ var projectPipelineKeySchema = z.string().min(1).max(160).regex(/^[a-zA-Z0-9][a-zA-Z0-9_.:-]*$/).refine(function(key) {
    return ![
        "__proto__",
        "constructor",
        "prototype"
    ].includes(key);
}, "Reserved key");
var projectPipelineRefSchema = z.string().min(3).max(240).regex(/^[a-zA-Z0-9][a-zA-Z0-9_.:/-]*@[a-zA-Z0-9][a-zA-Z0-9_.-]*$/);
function boundedJson(depth) {
    var primitive = z.union([
        z.string().max(16384),
        z.number().finite(),
        z.boolean(),
        z.null()
    ]);
    if (depth === 0) return primitive;
    var child = boundedJson(depth - 1);
    return z.union([
        primitive,
        z.array(child).max(1000),
        z.record(projectPipelineKeySchema, child).refine(function(value) {
            return Object.keys(value).length <= 256;
        }, "Too many parameter fields")
    ]);
}
var projectPipelineJsonSchema = boundedJson(8);
var projectPipelineParticipantKindSchema = z.enum([
    "assistant",
    "runtime_binding",
    "human",
    "service"
]);
var projectPipelineRoleSchema = z.object({
    key: projectPipelineKeySchema,
    allowedKinds: z.array(projectPipelineParticipantKindSchema).min(1).max(4)
}).strict();
var projectPipelineLaneSchema = z.object({
    key: projectPipelineKeySchema,
    roleKey: projectPipelineKeySchema,
    label: z.string().min(1).max(240),
    order: z.number().int().nonnegative()
}).strict();
/** Bundled presentation icons only; no executable content or external asset URLs. */ var projectPipelineIconSchema = z.enum([
    "layers",
    "file-text",
    "folder-open",
    "list-checks",
    "search",
    "scan-search",
    "boxes",
    "package",
    "settings",
    "clipboard-check",
    "shield-check",
    "git-pull-request",
    "code",
    "test-tube",
    "git-merge",
    "calculator",
    "file-check",
    "truck"
]);
var projectPipelineStageSchema = z.object({
    key: projectPipelineKeySchema,
    label: z.string().min(1).max(240),
    icon: projectPipelineIconSchema.optional(),
    order: z.number().int().nonnegative()
}).strict();
var projectPipelineOutputBindingSchema = z.object({
    from: z.literal("node_output"),
    nodeKey: projectPipelineKeySchema,
    port: projectPipelineKeySchema
}).strict();
var projectPipelineInputBindingSchema = z.discriminatedUnion("from", [
    z.object({
        from: z.literal("subject")
    }).strict(),
    z.object({
        from: z.literal("parameter"),
        key: projectPipelineKeySchema
    }).strict(),
    projectPipelineOutputBindingSchema,
    z.object({
        from: z.literal("collection"),
        items: z.array(projectPipelineOutputBindingSchema).min(1).max(100)
    }).strict()
]);
var projectPipelineEdgeSchema = z.object({
    from: projectPipelineKeySchema,
    to: projectPipelineKeySchema,
    outcome: projectPipelineKeySchema.optional()
}).strict();

function _define_property$e(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$e(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$e(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$a(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$a(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$a(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var base$1 = {
    key: projectPipelineKeySchema,
    label: z.string().min(1).max(240).optional(),
    stageKey: projectPipelineKeySchema,
    inputBindings: z.record(projectPipelineKeySchema, projectPipelineInputBindingSchema).optional(),
    outputPorts: z.record(projectPipelineKeySchema, projectPipelineRefSchema).optional()
};
var outcomes = z.array(projectPipelineKeySchema).min(2).max(32);
/** Only explicit primitives can control flow; configuration cannot embed executable expressions. */ var projectPipelineNodeSchema = z.discriminatedUnion("kind", [
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("work"),
        laneKey: projectPipelineKeySchema,
        presentation: z.object({
            foldIntoApproval: projectPipelineKeySchema
        }).strict().optional(),
        operationRef: projectPipelineRefSchema,
        executorSlot: projectPipelineKeySchema,
        completionRef: projectPipelineRefSchema,
        resourceResolverRef: projectPipelineRefSchema.optional(),
        outputSchemaRef: projectPipelineRefSchema.optional()
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("fork")
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("join"),
        join: z.object({
            mode: z.literal("all_selected"),
            accept: z.literal("completed")
        }).strict()
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("router"),
        policyRef: projectPipelineRefSchema,
        outcomes: outcomes,
        unmatched: z.literal("block")
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("human_gate"),
        laneKey: projectPipelineKeySchema,
        policyRef: projectPipelineRefSchema,
        candidateRoleKey: projectPipelineKeySchema,
        outcomes: outcomes,
        outcomeLabels: z.record(projectPipelineKeySchema, z.string().min(1).max(120)).optional()
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("external_wait"),
        laneKey: projectPipelineKeySchema,
        subscriptionRef: projectPipelineRefSchema
    })).strict(),
    z.object(_object_spread_props$a(_object_spread$e({}, base$1), {
        kind: z.literal("terminal"),
        outcome: projectPipelineKeySchema,
        disposition: z.enum([
            "complete",
            "await_new_subject"
        ]).optional()
    })).strict()
]);

/** Bounded symbolic execution proves required outputs exist on every selected branch. */ function _array_like_to_array$k(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$d(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$b(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$k(arr);
}
function _iterable_to_array$c(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$c(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$d() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$b() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$c(arr, i) {
    return _array_with_holes$d(arr) || _iterable_to_array_limit$c(arr, i) || _unsupported_iterable_to_array$k(arr, i) || _non_iterable_rest$d();
}
function _to_consumable_array$b(arr) {
    return _array_without_holes$b(arr) || _iterable_to_array$c(arr) || _unsupported_iterable_to_array$k(arr) || _non_iterable_spread$b();
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function _unsupported_iterable_to_array$k(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$k(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$k(o, minLen);
}
function validateProjectPipelineDataflow(definition, ordered) {
    var issues = [];
    var reported = new Set();
    var report = function(code, index, input) {
        var key = JSON.stringify([
            code,
            index,
            input
        ]);
        if (!reported.has(key)) issues.push({
            code: code,
            path: [
                "nodes",
                index,
                "inputBindings",
                input
            ]
        });
        reported.add(key);
    };
    var byKey = new Map(definition.nodes.map(function(node, index) {
        return [
            node.key,
            {
                node: node,
                index: index
            }
        ];
    }));
    var ancestors = new Map();
    var scenarios = [
        {
            active: new Set(),
            selectedEdges: new Set()
        }
    ];
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        var _loop = function() {
            var key = _step.value;
            var item = byKey.get(key);
            if (!item) return "continue";
            var node = item.node, index = item.index;
            var inputs = definition.edges.flatMap(function(edge, i) {
                return edge.to === key ? [
                    i
                ] : [];
            });
            var outputs = definition.edges.flatMap(function(edge, i) {
                return edge.from === key ? [
                    i
                ] : [];
            });
            var upstream = new Set();
            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
            try {
                for(var _iterator = inputs[Symbol.iterator](), _step1; !(_iteratorNormalCompletion = (_step1 = _iterator.next()).done); _iteratorNormalCompletion = true){
                    var i = _step1.value;
                    var source = definition.edges[i].from;
                    upstream.add(source);
                    var _ancestors_get;
                    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
                    try {
                        for(var _iterator1 = ((_ancestors_get = ancestors.get(source)) !== null && _ancestors_get !== void 0 ? _ancestors_get : [])[Symbol.iterator](), _step2; !(_iteratorNormalCompletion1 = (_step2 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                            var ancestor = _step2.value;
                            upstream.add(ancestor);
                        }
                    } catch (err) {
                        _didIteratorError1 = true;
                        _iteratorError1 = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                                _iterator1.return();
                            }
                        } finally{
                            if (_didIteratorError1) {
                                throw _iteratorError1;
                            }
                        }
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                        _iterator.return();
                    }
                } finally{
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
            ancestors.set(key, upstream);
            var _node_inputBindings;
            var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
            try {
                for(var _iterator2 = Object.entries((_node_inputBindings = node.inputBindings) !== null && _node_inputBindings !== void 0 ? _node_inputBindings : {})[Symbol.iterator](), _step3; !(_iteratorNormalCompletion2 = (_step3 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
                    var _step_value = _sliced_to_array$c(_step3.value, 2), name = _step_value[0], binding = _step_value[1];
                    var refs = binding.from === "collection" ? binding.items : binding.from === "node_output" ? [
                        binding
                    ] : [];
                    var _iteratorNormalCompletion3 = true, _didIteratorError3 = false, _iteratorError3 = undefined;
                    try {
                        for(var _iterator3 = refs[Symbol.iterator](), _step4; !(_iteratorNormalCompletion3 = (_step4 = _iterator3.next()).done); _iteratorNormalCompletion3 = true){
                            var ref = _step4.value;
                            var _byKey_get;
                            var ports = (_byKey_get = byKey.get(ref.nodeKey)) === null || _byKey_get === void 0 ? void 0 : _byKey_get.node.outputPorts;
                            if (!ports || !Object.prototype.hasOwnProperty.call(ports, ref.port)) report("OUTPUT_PORT_NOT_FOUND", index, name);
                            if (!upstream.has(ref.nodeKey)) report("OUTPUT_NOT_UPSTREAM", index, name);
                        }
                    } catch (err) {
                        _didIteratorError3 = true;
                        _iteratorError3 = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion3 && _iterator3.return != null) {
                                _iterator3.return();
                            }
                        } finally{
                            if (_didIteratorError3) {
                                throw _iteratorError3;
                            }
                        }
                    }
                }
            } catch (err) {
                _didIteratorError2 = true;
                _iteratorError2 = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                        _iterator2.return();
                    }
                } finally{
                    if (_didIteratorError2) {
                        throw _iteratorError2;
                    }
                }
            }
            var next = [];
            var _iteratorNormalCompletion4 = true, _didIteratorError4 = false, _iteratorError4 = undefined;
            try {
                var _loop = function() {
                    var scenario = _step5.value;
                    if (key !== definition.roundPolicy.entryNodeKey && !inputs.some(function(i) {
                        return scenario.selectedEdges.has(i);
                    })) {
                        next.push(scenario);
                        return "continue";
                    }
                    var _node_inputBindings;
                    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                    try {
                        for(var _iterator = Object.entries((_node_inputBindings = node.inputBindings) !== null && _node_inputBindings !== void 0 ? _node_inputBindings : {})[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                            var _step_value = _sliced_to_array$c(_step.value, 2), name = _step_value[0], binding = _step_value[1];
                            var refs = binding.from === "collection" ? binding.items : binding.from === "node_output" ? [
                                binding
                            ] : [];
                            if (refs.some(function(ref) {
                                return !scenario.active.has(ref.nodeKey);
                            })) report("OUTPUT_NOT_ALWAYS_AVAILABLE", index, name);
                        }
                    } catch (err) {
                        _didIteratorError = true;
                        _iteratorError = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion && _iterator.return != null) {
                                _iterator.return();
                            }
                        } finally{
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                    }
                    var choices = "outcomes" in node ? node.outcomes : [
                        undefined
                    ];
                    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
                    try {
                        for(var _iterator1 = choices[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                            var outcome = _step1.value;
                            var selectedEdges = new Set(scenario.selectedEdges);
                            var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
                            try {
                                for(var _iterator2 = outputs[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
                                    var i = _step2.value;
                                    if (definition.edges[i].outcome === outcome) selectedEdges.add(i);
                                }
                            } catch (err) {
                                _didIteratorError2 = true;
                                _iteratorError2 = err;
                            } finally{
                                try {
                                    if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                                        _iterator2.return();
                                    }
                                } finally{
                                    if (_didIteratorError2) {
                                        throw _iteratorError2;
                                    }
                                }
                            }
                            next.push({
                                active: new Set(_to_consumable_array$b(scenario.active).concat([
                                    key
                                ])),
                                selectedEdges: selectedEdges
                            });
                            if (next.length > 4096) {
                                return {
                                    v: _to_consumable_array$b(issues).concat([
                                        {
                                            code: "DATAFLOW_COMPLEXITY_LIMIT",
                                            path: [
                                                "nodes"
                                            ]
                                        }
                                    ])
                                };
                            }
                        }
                    } catch (err) {
                        _didIteratorError1 = true;
                        _iteratorError1 = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                                _iterator1.return();
                            }
                        } finally{
                            if (_didIteratorError1) {
                                throw _iteratorError1;
                            }
                        }
                    }
                };
                for(var _iterator4 = scenarios[Symbol.iterator](), _step5; !(_iteratorNormalCompletion4 = (_step5 = _iterator4.next()).done); _iteratorNormalCompletion4 = true){
                    var _ret = _loop();
                    if (_type_of(_ret) === "object") return {
                        v: _ret.v
                    };
                }
            } catch (err) {
                _didIteratorError4 = true;
                _iteratorError4 = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion4 && _iterator4.return != null) {
                        _iterator4.return();
                    }
                } finally{
                    if (_didIteratorError4) {
                        throw _iteratorError4;
                    }
                }
            }
            scenarios = next;
        };
        for(var _iterator = ordered[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var _ret = _loop();
            if (_type_of(_ret) === "object") return _ret.v;
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return issues;
}

function _array_like_to_array$j(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$a(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$j(arr);
}
function _iterable_to_array$b(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$a() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$a(arr) {
    return _array_without_holes$a(arr) || _iterable_to_array$b(arr) || _unsupported_iterable_to_array$j(arr) || _non_iterable_spread$a();
}
function _unsupported_iterable_to_array$j(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$j(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$j(o, minLen);
}
/** Pure semantic checks shared by configuration APIs, plugin registrations and persisted snapshots. */ function validateProjectPipelineDefinition(definition) {
    var // Upstream reachability alone is insufficient: a value on an unselected branch may not exist.
    // Propagate alternative decision assignments. A join requires ALL selected predecessors;
    // a normal merge can be reached through any predecessor. See dataflow.validation.ts.
    _issues;
    var _incoming_get;
    var issues = [];
    var issue = function(code) {
        for(var _len = arguments.length, path = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            path[_key - 1] = arguments[_key];
        }
        return issues.push({
            code: code,
            path: path
        });
    };
    var unique = function(keys) {
        for(var _len = arguments.length, path = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            path[_key - 1] = arguments[_key];
        }
        if (new Set(keys).size !== keys.length) issue.apply(void 0, [
            "DUPLICATE_KEY"
        ].concat(_to_consumable_array$a(path)));
    };
    unique(definition.roles.map(function(role) {
        return role.key;
    }), "roles");
    unique(definition.lanes.map(function(lane) {
        return lane.key;
    }), "lanes");
    unique(definition.stages.map(function(stage) {
        return stage.key;
    }), "stages");
    definition.roles.forEach(function(role, index) {
        return unique(role.allowedKinds, "roles", index, "allowedKinds");
    });
    var roles = new Map(definition.roles.map(function(role) {
        return [
            role.key,
            role
        ];
    }));
    var lanes = new Map(definition.lanes.map(function(lane) {
        return [
            lane.key,
            lane
        ];
    }));
    var stages = new Set(definition.stages.map(function(stage) {
        return stage.key;
    }));
    definition.lanes.forEach(function(lane, index) {
        if (!roles.has(lane.roleKey)) issue("ROLE_NOT_FOUND", "lanes", index, "roleKey");
    });
    if (definition.executionAuthority === "provider") return issues;
    var nodes = definition.nodes, edges = definition.edges, roundPolicy = definition.roundPolicy;
    unique(nodes.map(function(node) {
        return node.key;
    }), "nodes");
    unique(edges.map(function(edge) {
        var _edge_outcome;
        return JSON.stringify([
            edge.from,
            edge.to,
            (_edge_outcome = edge.outcome) !== null && _edge_outcome !== void 0 ? _edge_outcome : null
        ]);
    }), "edges");
    unique(roundPolicy.terminalOutcomes, "roundPolicy", "terminalOutcomes");
    var byKey = new Map(nodes.map(function(node) {
        return [
            node.key,
            node
        ];
    }));
    var incoming = new Map(nodes.map(function(node) {
        return [
            node.key,
            edges.filter(function(edge) {
                return edge.to === node.key;
            })
        ];
    }));
    var outgoing = new Map(nodes.map(function(node) {
        return [
            node.key,
            edges.filter(function(edge) {
                return edge.from === node.key;
            })
        ];
    }));
    edges.forEach(function(edge, index) {
        if (!byKey.has(edge.from) || !byKey.has(edge.to)) issue("EDGE_NODE_NOT_FOUND", "edges", index);
    });
    nodes.forEach(function(node, index) {
        var _node_presentation, _roles_get, _incoming_get;
        if (!stages.has(node.stageKey)) issue("STAGE_NOT_FOUND", "nodes", index, "stageKey");
        if ("laneKey" in node && !lanes.has(node.laneKey)) issue("LANE_NOT_FOUND", "nodes", index, "laneKey");
        if (node.kind === "work" && ((_node_presentation = node.presentation) === null || _node_presentation === void 0 ? void 0 : _node_presentation.foldIntoApproval)) {
            var _roles_get1;
            var approval = byKey.get(node.presentation.foldIntoApproval);
            var _incoming_get1;
            var entries = (_incoming_get1 = incoming.get(node.key)) !== null && _incoming_get1 !== void 0 ? _incoming_get1 : [];
            if ((approval === null || approval === void 0 ? void 0 : approval.kind) !== "human_gate" || !entries.length || entries.some(function(edge) {
                return edge.from !== approval.key;
            })) {
                issue("APPROVAL_STEP_PARENT_INVALID", "nodes", index, "presentation", "foldIntoApproval");
            }
            var lane = lanes.get(node.laneKey);
            if (lane && !((_roles_get1 = roles.get(lane.roleKey)) === null || _roles_get1 === void 0 ? void 0 : _roles_get1.allowedKinds.includes("service"))) {
                issue("APPROVAL_STEP_SERVICE_REQUIRED", "nodes", index, "presentation", "foldIntoApproval");
            }
        }
        if (node.kind === "human_gate" && !((_roles_get = roles.get(node.candidateRoleKey)) === null || _roles_get === void 0 ? void 0 : _roles_get.allowedKinds.includes("human"))) {
            issue("HUMAN_ROLE_REQUIRED", "nodes", index, "candidateRoleKey");
        }
        var _outgoing_get;
        var exits = (_outgoing_get = outgoing.get(node.key)) !== null && _outgoing_get !== void 0 ? _outgoing_get : [];
        if ("outcomes" in node) {
            if (node.kind === "human_gate" && node.outcomeLabels && Object.keys(node.outcomeLabels).some(function(key) {
                return !node.outcomes.includes(key);
            })) issue("UNKNOWN_OUTCOME_LABEL", "nodes", index, "outcomeLabels");
            unique(node.outcomes, "nodes", index, "outcomes");
            if (exits.some(function(edge) {
                return !edge.outcome || !node.outcomes.includes(edge.outcome);
            }) || node.outcomes.some(function(outcome) {
                return exits.filter(function(edge) {
                    return edge.outcome === outcome;
                }).length !== 1;
            })) {
                issue("OUTCOME_COVERAGE", "nodes", index);
            }
        } else {
            if (exits.some(function(edge) {
                return edge.outcome !== undefined;
            })) issue("UNEXPECTED_OUTCOME", "nodes", index);
            if (node.kind === "terminal" ? exits.length !== 0 : node.kind === "fork" ? exits.length < 2 : exits.length !== 1) {
                issue("EXIT_CARDINALITY", "nodes", index);
            }
        }
        var _incoming_get_length;
        if (node.kind === "join" && ((_incoming_get_length = (_incoming_get = incoming.get(node.key)) === null || _incoming_get === void 0 ? void 0 : _incoming_get.length) !== null && _incoming_get_length !== void 0 ? _incoming_get_length : 0) < 2) issue("JOIN_INPUTS", "nodes", index);
        if (node.kind === "terminal" && node.disposition !== "await_new_subject" && !roundPolicy.terminalOutcomes.includes(node.outcome)) {
            issue("TERMINAL_OUTCOME_NOT_DECLARED", "nodes", index, "outcome");
        }
    });
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        var _loop = function() {
            var outcome = _step.value;
            if (!nodes.some(function(node) {
                return node.kind === "terminal" && node.outcome === outcome;
            })) {
                issue("TERMINAL_OUTCOME_NOT_USED", "roundPolicy", "terminalOutcomes");
            }
        };
        for(var _iterator = roundPolicy.terminalOutcomes[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true)_loop();
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var entry = roundPolicy.entryNodeKey;
    var _incoming_get_length;
    if (!byKey.has(entry) || ((_incoming_get_length = (_incoming_get = incoming.get(entry)) === null || _incoming_get === void 0 ? void 0 : _incoming_get.length) !== null && _incoming_get_length !== void 0 ? _incoming_get_length : 0) !== 0) issue("INVALID_ENTRY", "roundPolicy", "entryNodeKey");
    var reached = new Set();
    var pending = [
        entry
    ];
    while(pending.length){
        var _pending;
        var key = pending.pop();
        if (reached.has(key)) continue;
        reached.add(key);
        var _outgoing_get;
        (_pending = pending).push.apply(_pending, _to_consumable_array$a(((_outgoing_get = outgoing.get(key)) !== null && _outgoing_get !== void 0 ? _outgoing_get : []).map(function(edge) {
            return edge.to;
        })));
    }
    if (nodes.some(function(node) {
        return !reached.has(node.key);
    })) issue("UNREACHABLE_NODE", "nodes");
    var degree = new Map(nodes.map(function(node) {
        var _incoming_get;
        var _incoming_get_length;
        return [
            node.key,
            (_incoming_get_length = (_incoming_get = incoming.get(node.key)) === null || _incoming_get === void 0 ? void 0 : _incoming_get.length) !== null && _incoming_get_length !== void 0 ? _incoming_get_length : 0
        ];
    }));
    var queue = nodes.filter(function(node) {
        return degree.get(node.key) === 0;
    }).map(function(node) {
        return node.key;
    });
    var ordered = [];
    while(queue.length){
        var key1 = queue.shift();
        ordered.push(key1);
        var _outgoing_get1;
        var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
        try {
            for(var _iterator1 = ((_outgoing_get1 = outgoing.get(key1)) !== null && _outgoing_get1 !== void 0 ? _outgoing_get1 : [])[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                var edge = _step1.value;
                var _degree_get;
                var next = ((_degree_get = degree.get(edge.to)) !== null && _degree_get !== void 0 ? _degree_get : 0) - 1;
                degree.set(edge.to, next);
                if (next === 0) queue.push(edge.to);
            }
        } catch (err) {
            _didIteratorError1 = true;
            _iteratorError1 = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                    _iterator1.return();
                }
            } finally{
                if (_didIteratorError1) {
                    throw _iteratorError1;
                }
            }
        }
    }
    if (ordered.length !== nodes.length) {
        issue("CYCLE", "edges");
        return issues;
    }
    (_issues = issues).push.apply(_issues, _to_consumable_array$a(validateProjectPipelineDataflow(definition, ordered)));
    return issues;
}

var version = z.number().int().min(1).max(1000);
var versions = z.array(version).min(1).max(20).refine(function(values) {
    return new Set(values).size === values.length;
});
var bounded = function(value) {
    return z.record(projectPipelineKeySchema, value).refine(function(values) {
        return Object.keys(values).length <= 100;
    });
};
/** Feature versions are exact protocols, not package semver or an implicit minimum version. */ var projectPipelineHostRequirementsSchema = z.object({
    protocol: version,
    features: bounded(version)
}).strict();
var projectPipelineHostCapabilitiesSchema = z.object({
    protocols: versions,
    features: bounded(versions)
}).strict();

/** Explicit application/type identities; plugin availability alone never implies applicability. */ var projectPipelineProjectTypesSchema = z.array(z.object({
    applicationKey: z.string().trim().min(1).max(300),
    projectTypeKey: z.string().regex(/^[a-z][a-z0-9_-]{0,99}$/)
}).strict()).min(1).max(100).superRefine(function(types, context) {
    if (new Set(types.map(function(type) {
        return JSON.stringify([
            type.applicationKey,
            type.projectTypeKey
        ]);
    })).size !== types.length) context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "DUPLICATE_PIPELINE_PROJECT_TYPE"
    });
});
function isProjectPipelineApplicable(definition, project) {
    var _definition_projectTypes;
    var _definition_projectTypes_some;
    return (_definition_projectTypes_some = (_definition_projectTypes = definition.projectTypes) === null || _definition_projectTypes === void 0 ? void 0 : _definition_projectTypes.some(function(type) {
        return type.applicationKey === project.applicationKey && type.projectTypeKey === project.projectTypeKey;
    })) !== null && _definition_projectTypes_some !== void 0 ? _definition_projectTypes_some : false;
}

// Invariants: definitions describe versioned topology and explicit execution authority.
// Business meaning stays behind provider references; labels and icons never drive execution.
function _define_property$d(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$d(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$d(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$9(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$9(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$9(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var common = {
    hostRequirements: projectPipelineHostRequirementsSchema.optional(),
    key: projectPipelineKeySchema,
    version: z.string().max(80).regex(/^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/),
    title: z.string().min(1).max(240),
    projectTypes: projectPipelineProjectTypesSchema,
    subjectResolverRef: projectPipelineRefSchema,
    roles: z.array(projectPipelineRoleSchema).min(1).max(100),
    lanes: z.array(projectPipelineLaneSchema).min(1).max(100),
    stages: z.array(projectPipelineStageSchema).min(1).max(100),
    presentation: z.object({
        views: z.array(z.enum([
            "tasks",
            "pipeline",
            "agent_timeline"
        ])).min(1).max(3),
        nodeDetailRef: projectPipelineRefSchema.optional(),
        evidenceTypes: z.array(projectPipelineRefSchema).max(100).optional()
    }).strict().optional(),
    metrics: z.object({
        dimensionRefs: z.array(projectPipelineRefSchema).max(100),
        metricRefs: z.array(projectPipelineRefSchema).max(100)
    }).strict().optional()
};
// A provider owns topology and advancement. A managed definition owns a bounded DAG per round.
var projectPipelineDefinitionShapeSchema = z.discriminatedUnion("executionAuthority", [
    z.object(_object_spread_props$9(_object_spread$d({}, common), {
        executionAuthority: z.literal("provider"),
        providerRef: projectPipelineRefSchema,
        topology: z.object({
            source: z.literal("provider"),
            presentationAdapterRef: projectPipelineRefSchema
        }).strict(),
        actionRefs: z.array(projectPipelineRefSchema).max(100).optional()
    })).strict(),
    z.object(_object_spread_props$9(_object_spread$d({}, common), {
        executionAuthority: z.literal("platform"),
        topology: z.object({
            source: z.literal("definition")
        }).strict(),
        nodes: z.array(projectPipelineNodeSchema).min(1).max(500),
        edges: z.array(projectPipelineEdgeSchema).max(2000),
        roundPolicy: z.object({
            entryNodeKey: projectPipelineKeySchema,
            maxRounds: z.number().int().min(1).max(100),
            onRework: z.literal("await_new_subject_then_next_round"),
            onLimit: z.literal("attention"),
            newVersionWhileActive: z.literal("supersede_round"),
            terminalOutcomes: z.array(projectPipelineKeySchema).min(1).max(32)
        }).strict(),
        failurePolicy: z.object({
            requiredNodeFailure: z.literal("block_and_attention"),
            unknownExecution: z.literal("inspect_without_replay")
        }).strict()
    })).strict()
]);
var projectPipelineDefinitionSchema = projectPipelineDefinitionShapeSchema.superRefine(function(definition, context) {
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = validateProjectPipelineDefinition(definition)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var issue = _step.value;
            context.addIssue({
                code: z.ZodIssueCode.custom,
                path: issue.path,
                message: issue.code
            });
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
});

/** Admission controls for host-native LLM requests; provider-internal retries and currency are not hard quotas. */ var projectPipelineNativeModelBudgetSchema = z.object({
    maxCalls: z.number().int().min(1).max(1000000),
    maxTokens: z.number().int().min(1).max(1000000000000),
    reservationTokens: z.number().int().min(1).max(1000000000)
}).strict().superRefine(function(value, context) {
    if (value.reservationTokens > value.maxTokens) context.addIssue({
        code: "custom",
        message: "RESERVATION_EXCEEDS_BUDGET",
        path: [
            "reservationTokens"
        ]
    });
});
/** Human management command. maxTokens is the new total ceiling, not an additional allowance. */ var projectPipelineModelBudgetIncreaseSchema = z.object({
    instanceId: z.string().uuid(),
    requestId: z.string().uuid(),
    expectedRevision: z.number().int().nonnegative().safe(),
    maxTokens: z.number().int().min(1).max(1000000000000),
    reason: z.string().trim().min(1).max(2000)
}).strict();
var projectPipelineModelBudgetIncreaseRecordSchema = z.object({
    requestId: z.string().uuid(),
    previousMaxTokens: z.number().int().min(1).max(1000000000000),
    maxTokens: z.number().int().min(1).max(1000000000000),
    reason: z.string().trim().min(1).max(2000)
}).strict();
var projectPipelineNativeModelBudgetStatusSchema = z.object({
    scope: z.literal("instance_native_llm"),
    policy: projectPipelineNativeModelBudgetSchema,
    calls: z.number().int().nonnegative().safe(),
    heldCalls: z.number().int().nonnegative().safe(),
    actualTokens: z.number().int().nonnegative().safe(),
    chargedAndReservedTokens: z.number().int().nonnegative().safe(),
    admissionBlocked: z.boolean()
}).strict();

function _array_like_to_array$i(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$c(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$b(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$c() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$b(arr, i) {
    return _array_with_holes$c(arr) || _iterable_to_array_limit$b(arr, i) || _unsupported_iterable_to_array$i(arr, i) || _non_iterable_rest$c();
}
function _unsupported_iterable_to_array$i(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$i(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$i(o, minLen);
}
var participantSelection = z.object({
    kind: projectPipelineParticipantKindSchema,
    selectionKey: projectPipelineKeySchema,
    requiredCapabilities: z.array(projectPipelineKeySchema).max(100).optional()
}).strict();
var projectPipelineBindingSchema = z.object({
    templateRef: projectPipelineRefSchema,
    roleBindings: z.record(projectPipelineKeySchema, participantSelection),
    executorBindings: z.record(projectPipelineKeySchema, participantSelection.extend({
        roleKey: projectPipelineKeySchema,
        workspaceId: z.string().uuid().optional()
    }).superRefine(function(executor, context) {
        if (executor.workspaceId && executor.kind !== "runtime_binding") context.addIssue({
            code: "custom",
            message: "RUNTIME_WORKSPACE_ONLY",
            path: [
                "workspaceId"
            ]
        });
    })).optional(),
    providerConfiguration: z.record(projectPipelineKeySchema, projectPipelineJsonSchema).optional(),
    parameters: z.record(projectPipelineKeySchema, projectPipelineJsonSchema),
    limits: z.object({
        maxConcurrentExecutions: z.number().int().min(1).max(100),
        maxTechnicalAttemptsPerNode: z.number().int().min(1).max(20),
        runTimeoutMinutes: z.number().int().min(1).max(43200),
        nativeModelBudget: projectPipelineNativeModelBudgetSchema.optional()
    }).strict().optional(),
    triggers: z.array(z.object({
        adapterRef: projectPipelineRefSchema,
        events: z.array(projectPipelineKeySchema).min(1).max(100)
    }).strict()).max(100).optional()
}).strict();
/** Selectors are portable configuration, not trusted participant identities or credentials. */ var projectPipelineConfigurationSchema = z.object({
    schemaVersion: z.literal(1),
    template: projectPipelineDefinitionSchema,
    binding: projectPipelineBindingSchema
}).strict().superRefine(function(param, context) {
    var template = param.template, binding = param.binding;
    var _binding_limits, _template_hostRequirements;
    var issue = function(message) {
        for(var _len = arguments.length, path = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            path[_key - 1] = arguments[_key];
        }
        return context.addIssue({
            code: z.ZodIssueCode.custom,
            message: message,
            path: path
        });
    };
    if (binding.templateRef !== "".concat(template.key, "@").concat(template.version)) issue("TEMPLATE_VERSION_MISMATCH", "binding", "templateRef");
    var roles = new Map(template.roles.map(function(role) {
        return [
            role.key,
            role
        ];
    }));
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = Object.entries(binding.roleBindings)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var _step_value = _sliced_to_array$b(_step.value, 2), key = _step_value[0], participant = _step_value[1];
            var _roles_get;
            if (!((_roles_get = roles.get(key)) === null || _roles_get === void 0 ? void 0 : _roles_get.allowedKinds.includes(participant.kind))) issue("ROLE_KIND_MISMATCH", "binding", "roleBindings", key);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    if (template.executionAuthority === "provider") {
        if (binding.executorBindings !== undefined || binding.triggers !== undefined || binding.limits !== undefined) {
            issue("PROVIDER_CONTROLS_EXECUTION", "binding");
        }
        var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
        try {
            for(var _iterator1 = template.roles[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                var role = _step1.value;
                if (!Object.prototype.hasOwnProperty.call(binding.roleBindings, role.key)) issue("ROLE_BINDING_MISSING", "binding", "roleBindings", role.key);
            }
        } catch (err) {
            _didIteratorError1 = true;
            _iteratorError1 = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                    _iterator1.return();
                }
            } finally{
                if (_didIteratorError1) {
                    throw _iteratorError1;
                }
            }
        }
        return;
    }
    if (binding.providerConfiguration !== undefined) issue("PLATFORM_CONTROLS_EXECUTION", "binding", "providerConfiguration");
    if (!binding.limits) issue("EXECUTION_LIMITS_REQUIRED", "binding", "limits");
    if (((_binding_limits = binding.limits) === null || _binding_limits === void 0 ? void 0 : _binding_limits.nativeModelBudget) && ((_template_hostRequirements = template.hostRequirements) === null || _template_hostRequirements === void 0 ? void 0 : _template_hostRequirements.features["pipeline.native_model_budget"]) !== 1) issue("MODEL_BUDGET_PROTOCOL_REQUIRED", "template", "hostRequirements");
    var _binding_executorBindings;
    var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
    try {
        var _loop = function() {
            var _step_value = _sliced_to_array$b(_step2.value, 2), slot = _step_value[0], executor = _step_value[1];
            var _roles_get;
            if (!((_roles_get = roles.get(executor.roleKey)) === null || _roles_get === void 0 ? void 0 : _roles_get.allowedKinds.includes(executor.kind)) || executor.kind === "human") {
                issue("EXECUTOR_ROLE_MISMATCH", "binding", "executorBindings", slot);
            }
            if (!template.nodes.some(function(node) {
                return node.kind === "work" && node.executorSlot === slot;
            })) {
                issue("EXECUTOR_SLOT_UNUSED", "binding", "executorBindings", slot);
            }
        };
        for(var _iterator2 = Object.entries((_binding_executorBindings = binding.executorBindings) !== null && _binding_executorBindings !== void 0 ? _binding_executorBindings : {})[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true)_loop();
    } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                _iterator2.return();
            }
        } finally{
            if (_didIteratorError2) {
                throw _iteratorError2;
            }
        }
    }
    var lanes = new Map(template.lanes.map(function(lane) {
        return [
            lane.key,
            lane
        ];
    }));
    var _iteratorNormalCompletion3 = true, _didIteratorError3 = false, _iteratorError3 = undefined;
    try {
        for(var _iterator3 = template.nodes.entries()[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true){
            var _step_value1 = _sliced_to_array$b(_step3.value, 2), index = _step_value1[0], node = _step_value1[1];
            var _binding_roleBindings_node_candidateRoleKey;
            if (node.kind === "work") {
                var _binding_executorBindings1, _node_presentation, _lanes_get;
                var executor = (_binding_executorBindings1 = binding.executorBindings) === null || _binding_executorBindings1 === void 0 ? void 0 : _binding_executorBindings1[node.executorSlot];
                if (((_node_presentation = node.presentation) === null || _node_presentation === void 0 ? void 0 : _node_presentation.foldIntoApproval) && executor && executor.kind !== "service") {
                    issue("APPROVAL_STEP_SERVICE_REQUIRED", "binding", "executorBindings", node.executorSlot);
                }
                // Native Assistant/file tools need a separate enforcement bridge before opting in.
                if (node.resourceResolverRef && (executor === null || executor === void 0 ? void 0 : executor.kind) !== "service") {
                    issue("RESOURCE_EXECUTOR_UNSUPPORTED", "template", "nodes", index, "resourceResolverRef");
                }
                if (!executor || executor.roleKey !== ((_lanes_get = lanes.get(node.laneKey)) === null || _lanes_get === void 0 ? void 0 : _lanes_get.roleKey)) {
                    issue("EXECUTOR_BINDING_MISSING_OR_WRONG_LANE", "template", "nodes", index, "executorSlot");
                }
            }
            if (node.kind === "human_gate" && ((_binding_roleBindings_node_candidateRoleKey = binding.roleBindings[node.candidateRoleKey]) === null || _binding_roleBindings_node_candidateRoleKey === void 0 ? void 0 : _binding_roleBindings_node_candidateRoleKey.kind) !== "human") {
                issue("HUMAN_BINDING_REQUIRED", "binding", "roleBindings", node.candidateRoleKey);
            }
            var _node_inputBindings;
            var _iteratorNormalCompletion4 = true, _didIteratorError4 = false, _iteratorError4 = undefined;
            try {
                for(var _iterator4 = Object.entries((_node_inputBindings = node.inputBindings) !== null && _node_inputBindings !== void 0 ? _node_inputBindings : {})[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true){
                    var _step_value2 = _sliced_to_array$b(_step4.value, 2), key1 = _step_value2[0], input = _step_value2[1];
                    if (input.from === "parameter" && !Object.prototype.hasOwnProperty.call(binding.parameters, input.key)) {
                        issue("PARAMETER_NOT_FOUND", "template", "nodes", index, "inputBindings", key1);
                    }
                }
            } catch (err) {
                _didIteratorError4 = true;
                _iteratorError4 = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion4 && _iterator4.return != null) {
                        _iterator4.return();
                    }
                } finally{
                    if (_didIteratorError4) {
                        throw _iteratorError4;
                    }
                }
            }
        }
    } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion3 && _iterator3.return != null) {
                _iterator3.return();
            }
        } finally{
            if (_didIteratorError3) {
                throw _iteratorError3;
            }
        }
    }
});

function _define_property$c(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$c(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$c(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$8(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$8(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$8(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var scopedIdentity = {
    id: z.string().uuid(),
    tenantId: z.string().uuid(),
    organizationId: z.string().uuid().nullable(),
    projectId: z.string().uuid()
};
var definitionRef = z.object({
    templateRef: projectPipelineRefSchema,
    digest: z.string().regex(/^[a-f0-9]{64}$/)
}).strict();
var projectPipelineProjectBindingSchema = z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
    definition: definitionRef,
    revision: z.number().int().positive(),
    configuration: projectPipelineBindingSchema
})).strict();
var projectPipelineInstanceSchema = z.discriminatedUnion("executionAuthority", [
    z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
        executionAuthority: z.literal("provider"),
        providerRef: projectPipelineRefSchema,
        sourceKey: z.string().min(1).max(500),
        definition: definitionRef,
        subject: z.object({
            resolverRef: projectPipelineRefSchema,
            objectKey: z.string().min(1).max(500)
        }).strict(),
        revision: z.number().int().nonnegative()
    })).strict(),
    z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
        executionAuthority: z.literal("platform"),
        bindingId: z.string().uuid(),
        sourceKey: z.string().min(1).max(500),
        definition: definitionRef,
        subject: z.object({
            resolverRef: projectPipelineRefSchema,
            objectKey: z.string().min(1).max(500)
        }).strict(),
        revision: z.number().int().nonnegative()
    })).strict()
]);
var projectPipelineRunSchema = z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
    instanceId: z.string().uuid(),
    triggerKey: z.string().min(1).max(500),
    definition: definitionRef,
    bindingSnapshot: projectPipelineBindingSchema,
    state: z.enum([
        "pending",
        "active",
        "waiting",
        "cancelling",
        "completed",
        "failed",
        "cancelled",
        "superseded"
    ]),
    revision: z.number().int().nonnegative(),
    startedAt: z.string().datetime().nullable(),
    completedAt: z.string().datetime().nullable()
})).strict();
var projectPipelineSubjectVersionSchema = z.object({
    resolverRef: projectPipelineRefSchema,
    objectKey: z.string().min(1).max(500),
    version: z.string().min(1).max(500),
    digest: z.string().regex(/^[a-f0-9]{64}$/)
}).strict();
/** Scope and ownership are resolved by the host; possession of this reference grants no access. */ var projectPipelineEvidenceRefSchema = projectPipelineSubjectVersionSchema.extend({
    schemaRef: projectPipelineRefSchema,
    producerOperationId: z.string().uuid().optional()
}).strict();
var projectPipelineNodeStateSchema = z.object({
    lifecycle: z.enum([
        "pending",
        "active",
        "completed",
        "failed",
        "cancelled"
    ]),
    readiness: z.enum([
        "waiting",
        "ready",
        "blocked"
    ]),
    applicability: z.enum([
        "undetermined",
        "selected",
        "excluded"
    ]),
    freshness: z.enum([
        "current",
        "superseded"
    ]),
    runtime: z.enum([
        "none",
        "queued",
        "running",
        "waiting",
        "cancelling",
        "succeeded",
        "failed",
        "cancelled",
        "unknown"
    ])
}).strict();
var projectPipelineWorkContextSchema = z.object({
    instanceId: z.string().uuid(),
    runId: z.string().uuid(),
    roundId: z.string().uuid(),
    nodeInstanceId: z.string().uuid(),
    operationId: z.string().uuid(),
    inputDigest: z.string().regex(/^[a-f0-9]{64}$/),
    generation: z.number().int().positive()
}).strict();
var projectPipelineRoundSchema = z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
    runId: z.string().uuid(),
    sequence: z.number().int().positive(),
    generation: z.number().int().positive(),
    state: z.enum([
        "active",
        "completed",
        "awaiting_new_subject",
        "failed",
        "cancelled",
        "superseded"
    ]),
    inputDigest: z.string().regex(/^[a-f0-9]{64}$/),
    subjectVersionSet: z.array(projectPipelineSubjectVersionSchema).min(1).max(100),
    supersedes: z.string().uuid().nullable()
})).strict();
var projectPipelineNodeInstanceSchema = z.object(_object_spread_props$8(_object_spread$c({}, scopedIdentity), {
    roundId: z.string().uuid(),
    nodeKey: projectPipelineKeySchema,
    /** Stable source identity; never a list index. */ expansionKey: z.string().min(1).max(500),
    laneKey: projectPipelineKeySchema.nullable(),
    stageKey: projectPipelineKeySchema,
    state: projectPipelineNodeStateSchema,
    taskIds: z.array(z.string().uuid()).max(100),
    evidence: z.array(projectPipelineEvidenceRefSchema).max(100),
    revision: z.number().int().nonnegative()
})).strict();

function _define_property$b(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$b(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$b(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$7(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$7(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$7(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var reference$1 = {
    ref: projectPipelineRefSchema
};
var projectPipelinePortDescriptorSchema = z.object({
    schemaRef: projectPipelineRefSchema,
    cardinality: z.enum([
        "one",
        "collection"
    ])
}).strict();
/** Declarations allow configuration checks. They never prove a runtime executor is currently available. */ var projectPipelineExtensionDescriptorSchema = z.discriminatedUnion("kind", [
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("schema")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("resource")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("subject"),
        outputSchemaRef: projectPipelineRefSchema
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("operation"),
        effects: z.enum([
            "read_only",
            "isolated_write",
            "external_write"
        ]),
        idempotency: z.enum([
            "read_only",
            "keyed_receipt"
        ]),
        retry: z.enum([
            "never",
            "after_confirmed_failure"
        ]).optional(),
        requiredCapabilities: z.array(projectPipelineKeySchema).max(100),
        inputs: z.record(projectPipelineKeySchema, projectPipelinePortDescriptorSchema),
        outputs: z.record(projectPipelineKeySchema, projectPipelineRefSchema)
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("completion")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("policy"),
        outcomes: z.array(projectPipelineKeySchema).min(1).max(32)
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("projection")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("presentation")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("action")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("metric")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("dimension")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("trigger")
    })).strict(),
    z.object(_object_spread_props$7(_object_spread$b({}, reference$1), {
        kind: z.literal("subscription"),
        outputs: z.record(projectPipelineKeySchema, projectPipelineRefSchema)
    })).strict()
]);

/** Checks declared dependencies only. Participant authorization and live capabilities require runtime resolution. */ function _array_like_to_array$h(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$b(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$9(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$h(arr);
}
function _iterable_to_array$a(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$a(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$b() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$9() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$a(arr, i) {
    return _array_with_holes$b(arr) || _iterable_to_array_limit$a(arr, i) || _unsupported_iterable_to_array$h(arr, i) || _non_iterable_rest$b();
}
function _to_consumable_array$9(arr) {
    return _array_without_holes$9(arr) || _iterable_to_array$a(arr) || _unsupported_iterable_to_array$h(arr) || _non_iterable_spread$9();
}
function _unsupported_iterable_to_array$h(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$h(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$h(o, minLen);
}
function checkProjectPipelineConfiguration(configuration, descriptors) {
    var _template_presentation, _template_presentation_evidenceTypes, _template_presentation1, _template_metrics, _template_metrics1;
    var template = configuration.template, binding = configuration.binding;
    var issues = [];
    var requiredCapabilities = [];
    var catalog = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = descriptors[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var descriptor = _step.value;
            var key = "".concat(descriptor.kind, ":").concat(descriptor.ref);
            if (catalog.has(key)) issues.push({
                code: "AMBIGUOUS_EXTENSION",
                path: [],
                ref: descriptor.ref
            });
            catalog.set(key, descriptor);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var requireRef = function(kind, ref, path) {
        var descriptor = catalog.get("".concat(kind, ":").concat(ref));
        if (!descriptor) issues.push({
            code: "EXTENSION_NOT_REGISTERED",
            path: path,
            ref: ref
        });
        return descriptor;
    };
    var subject = requireRef("subject", template.subjectResolverRef, [
        "template",
        "subjectResolverRef"
    ]);
    if ((subject === null || subject === void 0 ? void 0 : subject.kind) === "subject") requireRef("schema", subject.outputSchemaRef, [
        "template",
        "subjectResolverRef"
    ]);
    if ((_template_presentation = template.presentation) === null || _template_presentation === void 0 ? void 0 : _template_presentation.nodeDetailRef) requireRef("presentation", template.presentation.nodeDetailRef, [
        "template",
        "presentation",
        "nodeDetailRef"
    ]);
    (_template_presentation1 = template.presentation) === null || _template_presentation1 === void 0 ? void 0 : (_template_presentation_evidenceTypes = _template_presentation1.evidenceTypes) === null || _template_presentation_evidenceTypes === void 0 ? void 0 : _template_presentation_evidenceTypes.forEach(function(ref, i) {
        return requireRef("schema", ref, [
            "template",
            "presentation",
            "evidenceTypes",
            i
        ]);
    });
    (_template_metrics = template.metrics) === null || _template_metrics === void 0 ? void 0 : _template_metrics.dimensionRefs.forEach(function(ref, i) {
        return requireRef("dimension", ref, [
            "template",
            "metrics",
            "dimensionRefs",
            i
        ]);
    });
    (_template_metrics1 = template.metrics) === null || _template_metrics1 === void 0 ? void 0 : _template_metrics1.metricRefs.forEach(function(ref, i) {
        return requireRef("metric", ref, [
            "template",
            "metrics",
            "metricRefs",
            i
        ]);
    });
    if (template.executionAuthority === "provider") {
        var _template_actionRefs;
        requireRef("projection", template.providerRef, [
            "template",
            "providerRef"
        ]);
        requireRef("presentation", template.topology.presentationAdapterRef, [
            "template",
            "topology",
            "presentationAdapterRef"
        ]);
        (_template_actionRefs = template.actionRefs) === null || _template_actionRefs === void 0 ? void 0 : _template_actionRefs.forEach(function(ref, i) {
            return requireRef("action", ref, [
                "template",
                "actionRefs",
                i
            ]);
        });
    } else {
        var _binding_triggers;
        (_binding_triggers = binding.triggers) === null || _binding_triggers === void 0 ? void 0 : _binding_triggers.forEach(function(trigger, i) {
            return requireRef("trigger", trigger.adapterRef, [
                "binding",
                "triggers",
                i
            ]);
        });
        var nodes = new Map(template.nodes.map(function(node) {
            return [
                node.key,
                node
            ];
        }));
        var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
        try {
            var _loop = function() {
                var _step_value = _sliced_to_array$a(_step1.value, 2), index = _step_value[0], node = _step_value[1];
                var _binding_executorBindings_node_executorSlot, _binding_executorBindings;
                var path = [
                    "template",
                    "nodes",
                    index
                ];
                var _node_outputPorts;
                var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                try {
                    for(var _iterator = Object.entries((_node_outputPorts = node.outputPorts) !== null && _node_outputPorts !== void 0 ? _node_outputPorts : {})[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                        var _step_value1 = _sliced_to_array$a(_step.value, 2), port = _step_value1[0], schemaRef = _step_value1[1];
                        requireRef("schema", schemaRef, _to_consumable_array$9(path).concat([
                            "outputPorts",
                            port
                        ]));
                    }
                } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                } finally{
                    try {
                        if (!_iteratorNormalCompletion && _iterator.return != null) {
                            _iterator.return();
                        }
                    } finally{
                        if (_didIteratorError) {
                            throw _iteratorError;
                        }
                    }
                }
                if (node.kind === "router" || node.kind === "human_gate") {
                    var policy = requireRef("policy", node.policyRef, _to_consumable_array$9(path).concat([
                        "policyRef"
                    ]));
                    if ((policy === null || policy === void 0 ? void 0 : policy.kind) === "policy" && (policy.outcomes.length !== node.outcomes.length || policy.outcomes.some(function(outcome) {
                        return !node.outcomes.includes(outcome);
                    }))) {
                        issues.push({
                            code: "POLICY_OUTCOMES_MISMATCH",
                            path: _to_consumable_array$9(path).concat([
                                "outcomes"
                            ]),
                            ref: node.policyRef
                        });
                    }
                }
                if (node.kind === "external_wait") {
                    var subscription = requireRef("subscription", node.subscriptionRef, _to_consumable_array$9(path).concat([
                        "subscriptionRef"
                    ]));
                    var _node_outputPorts1;
                    if ((subscription === null || subscription === void 0 ? void 0 : subscription.kind) === "subscription") checkOutputs(subscription.outputs, (_node_outputPorts1 = node.outputPorts) !== null && _node_outputPorts1 !== void 0 ? _node_outputPorts1 : {}, path);
                }
                if (node.kind !== "work") return "continue";
                if (node.resourceResolverRef) requireRef("resource", node.resourceResolverRef, _to_consumable_array$9(path).concat([
                    "resourceResolverRef"
                ]));
                requireRef("completion", node.completionRef, _to_consumable_array$9(path).concat([
                    "completionRef"
                ]));
                if (node.outputSchemaRef) requireRef("schema", node.outputSchemaRef, _to_consumable_array$9(path).concat([
                    "outputSchemaRef"
                ]));
                var operation = requireRef("operation", node.operationRef, _to_consumable_array$9(path).concat([
                    "operationRef"
                ]));
                if ((operation === null || operation === void 0 ? void 0 : operation.kind) !== "operation") return "continue";
                if (operation.effects !== "read_only" && operation.idempotency !== "keyed_receipt") {
                    issues.push({
                        code: "WRITE_REQUIRES_IDEMPOTENCY",
                        path: _to_consumable_array$9(path).concat([
                            "operationRef"
                        ]),
                        ref: operation.ref
                    });
                }
                var _binding_executorBindings_node_executorSlot_requiredCapabilities;
                var capabilities = new Set(_to_consumable_array$9(operation.requiredCapabilities).concat(_to_consumable_array$9((_binding_executorBindings_node_executorSlot_requiredCapabilities = (_binding_executorBindings = binding.executorBindings) === null || _binding_executorBindings === void 0 ? void 0 : (_binding_executorBindings_node_executorSlot = _binding_executorBindings[node.executorSlot]) === null || _binding_executorBindings_node_executorSlot === void 0 ? void 0 : _binding_executorBindings_node_executorSlot.requiredCapabilities) !== null && _binding_executorBindings_node_executorSlot_requiredCapabilities !== void 0 ? _binding_executorBindings_node_executorSlot_requiredCapabilities : [])));
                var previous = requiredCapabilities.find(function(item) {
                    return item.executorSlot === node.executorSlot;
                });
                if (previous) previous.capabilities = _to_consumable_array$9(new Set(_to_consumable_array$9(previous.capabilities).concat(_to_consumable_array$9(capabilities)))).sort();
                else requiredCapabilities.push({
                    executorSlot: node.executorSlot,
                    capabilities: _to_consumable_array$9(capabilities).sort()
                });
                var _node_outputPorts2;
                checkOutputs(operation.outputs, (_node_outputPorts2 = node.outputPorts) !== null && _node_outputPorts2 !== void 0 ? _node_outputPorts2 : {}, path);
                var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
                try {
                    var _loop = function() {
                        var _step_value = _sliced_to_array$a(_step2.value, 2), port = _step_value[0], expected = _step_value[1];
                        var _nodes_get_outputPorts, _nodes_get;
                        requireRef("schema", expected.schemaRef, _to_consumable_array$9(path).concat([
                            "inputBindings",
                            port
                        ]));
                        var input = node.inputBindings && Object.prototype.hasOwnProperty.call(node.inputBindings, port) ? node.inputBindings[port] : undefined;
                        if (!input) {
                            issues.push({
                                code: "OPERATION_INPUT_MISSING",
                                path: _to_consumable_array$9(path).concat([
                                    "inputBindings",
                                    port
                                ])
                            });
                            return "continue";
                        }
                        if (input.from === "collection" !== (expected.cardinality === "collection")) {
                            issues.push({
                                code: "INPUT_CARDINALITY_MISMATCH",
                                path: _to_consumable_array$9(path).concat([
                                    "inputBindings",
                                    port
                                ])
                            });
                        }
                        var sourceSchemas = input.from === "collection" ? input.items.map(function(item) {
                            var _nodes_get_outputPorts, _nodes_get;
                            return (_nodes_get = nodes.get(item.nodeKey)) === null || _nodes_get === void 0 ? void 0 : (_nodes_get_outputPorts = _nodes_get.outputPorts) === null || _nodes_get_outputPorts === void 0 ? void 0 : _nodes_get_outputPorts[item.port];
                        }) : input.from === "node_output" ? [
                            (_nodes_get = nodes.get(input.nodeKey)) === null || _nodes_get === void 0 ? void 0 : (_nodes_get_outputPorts = _nodes_get.outputPorts) === null || _nodes_get_outputPorts === void 0 ? void 0 : _nodes_get_outputPorts[input.port]
                        ] : input.from === "subject" && (subject === null || subject === void 0 ? void 0 : subject.kind) === "subject" ? [
                            subject.outputSchemaRef
                        ] : [];
                        if (sourceSchemas.some(function(ref) {
                            return ref !== expected.schemaRef;
                        })) {
                            issues.push({
                                code: "INPUT_SCHEMA_MISMATCH",
                                path: _to_consumable_array$9(path).concat([
                                    "inputBindings",
                                    port
                                ])
                            });
                        }
                    };
                    for(var _iterator1 = Object.entries(operation.inputs)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion1 = (_step2 = _iterator1.next()).done); _iteratorNormalCompletion1 = true)_loop();
                } catch (err) {
                    _didIteratorError1 = true;
                    _iteratorError1 = err;
                } finally{
                    try {
                        if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                            _iterator1.return();
                        }
                    } finally{
                        if (_didIteratorError1) {
                            throw _iteratorError1;
                        }
                    }
                }
                var _node_inputBindings;
                var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
                try {
                    for(var _iterator2 = Object.keys((_node_inputBindings = node.inputBindings) !== null && _node_inputBindings !== void 0 ? _node_inputBindings : {})[Symbol.iterator](), _step3; !(_iteratorNormalCompletion2 = (_step3 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
                        var port1 = _step3.value;
                        if (!Object.prototype.hasOwnProperty.call(operation.inputs, port1)) issues.push({
                            code: "OPERATION_INPUT_UNKNOWN",
                            path: _to_consumable_array$9(path).concat([
                                "inputBindings",
                                port1
                            ])
                        });
                    }
                } catch (err) {
                    _didIteratorError2 = true;
                    _iteratorError2 = err;
                } finally{
                    try {
                        if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                            _iterator2.return();
                        }
                    } finally{
                        if (_didIteratorError2) {
                            throw _iteratorError2;
                        }
                    }
                }
            };
            for(var _iterator1 = template.nodes.entries()[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true)_loop();
        } catch (err) {
            _didIteratorError1 = true;
            _iteratorError1 = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                    _iterator1.return();
                }
            } finally{
                if (_didIteratorError1) {
                    throw _iteratorError1;
                }
            }
        }
    }
    return {
        valid: issues.length === 0,
        runtimeReadiness: "not_checked",
        issues: issues,
        requiredCapabilities: requiredCapabilities
    };
    function checkOutputs(expected, actual, path) {
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = new Set(_to_consumable_array$9(Object.keys(expected)).concat(_to_consumable_array$9(Object.keys(actual))))[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var port = _step.value;
                if (!actual[port] || actual[port] !== expected[port]) issues.push({
                    code: "OUTPUT_SCHEMA_MISMATCH",
                    path: _to_consumable_array$9(path).concat([
                        "outputPorts",
                        port
                    ])
                });
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
}

function _array_like_to_array$g(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$a(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$8(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$g(arr);
}
function _iterable_to_array$9(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$9(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$a() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$8() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$9(arr, i) {
    return _array_with_holes$a(arr) || _iterable_to_array_limit$9(arr, i) || _unsupported_iterable_to_array$g(arr, i) || _non_iterable_rest$a();
}
function _to_consumable_array$8(arr) {
    return _array_without_holes$8(arr) || _iterable_to_array$9(arr) || _unsupported_iterable_to_array$g(arr) || _non_iterable_spread$8();
}
function _unsupported_iterable_to_array$g(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$g(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$g(o, minLen);
}
var key$2 = z.string().min(1).max(500);
var timestamp = z.string().datetime({
    offset: true
});
var projectPipelineTaskProjectionSchema = z.object({
    key: key$2,
    title: z.string().min(1).max(1000),
    status: z.enum([
        "todo",
        "in_progress",
        "review",
        "paused",
        "done",
        "blocked",
        "cancelled"
    ]),
    progress: z.number().min(0).max(100).nullable().optional(),
    kind: z.enum([
        "task",
        "summary",
        "milestone"
    ]),
    taskType: z.string().min(1).nullable().optional(),
    parentKey: key$2.optional(),
    predecessorKeys: z.array(key$2).max(500),
    diagnostic: z.string().max(4000).optional(),
    assigneeXpertId: z.string().uuid().optional(),
    executions: z.array(z.object({
        key: key$2,
        attempt: z.number().int().positive(),
        invocationId: z.string().uuid().optional(),
        agentExecutionId: z.string().uuid().optional(),
        conversationId: z.string().uuid().optional(),
        threadId: z.string().min(1).optional(),
        xpertId: z.string().uuid().optional(),
        agentKey: key$2.optional(),
        status: z.enum([
            "queued",
            "running",
            "succeeded",
            "failed",
            "cancelled"
        ]),
        startedAt: timestamp.optional(),
        completedAt: timestamp.optional(),
        error: z.string().max(4000).optional(),
        outputSummary: z.string().max(4000).optional()
    }).strict()).max(1000)
}).strict();
/** Display facts supplied by a provider; never authorization or executable instructions. */ var presentationField = z.object({
    label: z.string().min(1).max(200),
    value: z.string().max(4000)
}).strict();
var projectPipelineNodePresentationSchema = z.object({
    description: z.string().max(4000).optional(),
    blockers: z.array(z.string().min(1).max(1000)).max(100).optional(),
    nextActionable: z.boolean().optional(),
    operationUnavailableReason: z.string().max(1000).optional(),
    roleDetails: z.array(presentationField).max(30).optional(),
    technicalDetails: z.array(presentationField).max(30).optional(),
    decision: z.object({
        outcome: projectPipelineKeySchema,
        label: z.string().max(240),
        reason: z.string().max(4000),
        decidedAt: timestamp.optional(),
        version: z.string().max(500)
    }).strict().optional()
}).strict();
var projectPipelineProjectionNodeSchema = z.object({
    key: key$2,
    nodeKey: projectPipelineKeySchema,
    expansionKey: key$2,
    title: z.string().min(1).max(1000),
    kind: z.enum([
        "work",
        "fork",
        "join",
        "router",
        "human_gate",
        "external_wait",
        "terminal"
    ]),
    laneKey: projectPipelineKeySchema.nullable(),
    stageKey: projectPipelineKeySchema,
    state: projectPipelineNodeStateSchema,
    /** A registered Project type resolves the destination again when opened. No URL or business parameters. */ navigation: z.object({
        kind: z.literal("project_application")
    }).strict().optional(),
    presentation: projectPipelineNodePresentationSchema.optional(),
    taskKeys: z.array(key$2).max(100),
    evidence: z.array(projectPipelineEvidenceRefSchema).max(100)
}).strict();
var projectPipelineProjectionEdgeSchema = z.object({
    key: key$2,
    from: key$2,
    to: key$2,
    outcome: projectPipelineKeySchema.optional(),
    selection: z.enum([
        "undetermined",
        "selected",
        "excluded"
    ]),
    label: z.string().max(240).optional()
}).strict();
var tombstone = z.object({
    key: key$2,
    reason: z.enum([
        "removed",
        "excluded",
        "superseded"
    ])
}).strict();
/** A complete snapshot covers ONE instance/round. Absence is never a cancellation instruction. */ var projectPipelineProjectionSchema = z.object({
    schemaVersion: z.literal(1),
    sourceKey: key$2,
    sourceEpoch: z.string().uuid(),
    sourceSequence: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
    title: z.string().min(1).max(1000),
    definition: projectPipelineDefinitionSchema,
    subject: z.object({
        resolverRef: z.string().min(1),
        objectKey: key$2
    }).strict(),
    run: z.object({
        key: key$2,
        state: z.enum([
            "pending",
            "active",
            "waiting",
            "cancelling",
            "completed",
            "failed",
            "cancelled",
            "superseded"
        ])
    }).strict(),
    round: z.object({
        key: key$2,
        sequence: z.number().int().positive(),
        generation: z.number().int().positive(),
        supersedesKey: key$2.optional(),
        state: z.enum([
            "active",
            "completed",
            "awaiting_new_subject",
            "failed",
            "cancelled",
            "superseded"
        ]),
        inputDigest: z.string().regex(/^[a-f0-9]{64}$/),
        subjectVersionSet: z.array(projectPipelineSubjectVersionSchema).min(1).max(100)
    }).strict(),
    nodes: z.array(projectPipelineProjectionNodeSchema).max(2000),
    edges: z.array(projectPipelineProjectionEdgeSchema).max(8000),
    tasks: z.array(projectPipelineTaskProjectionSchema).max(2000),
    taskTombstones: z.array(tombstone).max(2000),
    nodeTombstones: z.array(tombstone).max(2000)
}).strict().superRefine(function(snapshot, context) {
    var _loop = function(_i1, _iter1) {
        var field = _iter1[_i1];
        var active = field === "taskTombstones" ? taskKeys : nodeKeys;
        if (snapshot[field].some(function(item) {
            return active.has(item.key);
        })) issue("ACTIVE_TOMBSTONE_CONFLICT", [
            field
        ]);
    };
    var issue = function(message, path) {
        return context.addIssue({
            code: "custom",
            message: message,
            path: path
        });
    };
    if (snapshot.definition.executionAuthority !== "provider") issue("PROJECTION_AUTHORITY_REQUIRED", [
        "definition"
    ]);
    if (snapshot.subject.resolverRef !== snapshot.definition.subjectResolverRef) issue("SUBJECT_RESOLVER_MISMATCH", [
        "subject"
    ]);
    for(var _i = 0, _iter = [
        "nodes",
        "edges",
        "tasks",
        "taskTombstones",
        "nodeTombstones"
    ]; _i < _iter.length; _i++){
        var field = _iter[_i];
        var keys = snapshot[field].map(function(item) {
            return item.key;
        });
        if (new Set(keys).size !== keys.length) issue("DUPLICATE_KEY", [
            field
        ]);
    }
    var nodeKeys = new Set(snapshot.nodes.map(function(node) {
        return node.key;
    }));
    var taskKeys = new Set(snapshot.tasks.map(function(task) {
        return task.key;
    }));
    for(var _i1 = 0, _iter1 = [
        "taskTombstones",
        "nodeTombstones"
    ]; _i1 < _iter1.length; _i1++)_loop(_i1, _iter1);
    var lanes = new Set(snapshot.definition.lanes.map(function(lane) {
        return lane.key;
    }));
    var stages = new Set(snapshot.definition.stages.map(function(stage) {
        return stage.key;
    }));
    var identities = snapshot.nodes.map(function(node) {
        return JSON.stringify([
            node.nodeKey,
            node.expansionKey
        ]);
    });
    if (new Set(identities).size !== identities.length) issue("DUPLICATE_NODE_IDENTITY", [
        "nodes"
    ]);
    snapshot.nodes.forEach(function(node, i) {
        if (!stages.has(node.stageKey) || node.laneKey !== null && !lanes.has(node.laneKey)) issue("NODE_LAYOUT_REFERENCE_INVALID", [
            "nodes",
            i
        ]);
        if ([
            "work",
            "human_gate",
            "external_wait"
        ].includes(node.kind) && node.laneKey === null) issue("NODE_LANE_REQUIRED", [
            "nodes",
            i
        ]);
        if (node.taskKeys.some(function(key) {
            return !taskKeys.has(key);
        })) issue("NODE_TASK_NOT_FOUND", [
            "nodes",
            i,
            "taskKeys"
        ]);
    });
    snapshot.edges.forEach(function(edge, i) {
        if (!nodeKeys.has(edge.from) || !nodeKeys.has(edge.to)) issue("EDGE_NODE_NOT_FOUND", [
            "edges",
            i
        ]);
    });
    var degree = new Map(snapshot.nodes.map(function(node) {
        return [
            node.key,
            0
        ];
    }));
    snapshot.edges.forEach(function(edge) {
        var _degree_get;
        return degree.set(edge.to, ((_degree_get = degree.get(edge.to)) !== null && _degree_get !== void 0 ? _degree_get : 0) + 1);
    });
    var queue = _to_consumable_array$8(degree).filter(function(param) {
        var _param = _sliced_to_array$9(param, 2), n = _param[1];
        return n === 0;
    }).map(function(param) {
        var _param = _sliced_to_array$9(param, 1), key = _param[0];
        return key;
    });
    var visited = 0;
    while(queue.length){
        var key = queue.shift();
        visited++;
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = snapshot.edges.filter(function(edge) {
                return edge.from === key;
            })[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var edge = _step.value;
                var n = degree.get(edge.to) - 1;
                degree.set(edge.to, n);
                if (n === 0) queue.push(edge.to);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    if (visited !== snapshot.nodes.length) issue("CYCLE", [
        "edges"
    ]);
});

function _define_property$a(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$a(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$a(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$6(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$6(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$6(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var subject = z.discriminatedUnion("kind", [
    z.object({
        kind: z.literal("execution"),
        id: z.string().min(1)
    }).strict(),
    z.object({
        kind: z.literal("invocation"),
        id: z.string().min(1)
    }).strict()
]);
var base = {
    version: z.literal(1),
    observedAt: z.string().datetime()
};
/** Host-assigned attempt identity. A new host boot or execution never inherits an old target. */ var executionRuntimeTargetSchema = z.discriminatedUnion("kind", [
    z.object({
        version: z.literal(1),
        kind: z.literal("host"),
        generation: z.string().uuid(),
        hostId: z.string().uuid()
    }).strict(),
    z.object({
        version: z.literal(1),
        kind: z.literal("provider"),
        generation: z.string().uuid()
    }).strict()
]);
function executionRuntimeTargetsEqual(left, right) {
    if (!left || !right) return left === right;
    return left.version === right.version && left.kind === right.kind && left.generation === right.generation && (left.kind !== "host" || right.kind === "host" && left.hostId === right.hostId);
}
/** Control acknowledgements never constitute completion evidence. Missing evidence stays unknown. */ var executionControlEvidenceSchema = z.discriminatedUnion("source", [
    z.object(_object_spread_props$6(_object_spread$a({}, base), {
        source: z.literal("unavailable"),
        subject: subject,
        state: z.literal("unknown"),
        reason: z.enum([
            "unregistered",
            "unconfirmed",
            "unsupported"
        ])
    })).strict(),
    z.object(_object_spread_props$6(_object_spread$a({}, base), {
        source: z.literal("platform"),
        subject: subject,
        scope: z.literal("owned_subtree"),
        state: z.enum([
            "running",
            "pausing",
            "paused",
            "terminating",
            "settled"
        ]),
        desired: z.enum([
            "running",
            "paused",
            "terminated"
        ]),
        taskId: z.string().uuid(),
        rootId: z.string().uuid(),
        revision: z.number().int().positive(),
        executionId: z.string().uuid(),
        threadId: z.string().min(1)
    })).strict(),
    z.object(_object_spread_props$6(_object_spread$a({}, base), {
        source: z.literal("provider"),
        subject: z.object({
            kind: z.literal("invocation"),
            id: z.string().min(1)
        }).strict(),
        scope: z.literal("operation"),
        state: z.literal("settled"),
        outcome: z.enum([
            "succeeded",
            "failed",
            "cancelled"
        ]),
        sessionId: z.string().min(1),
        runId: z.string().min(1),
        receiptKey: z.string().min(1).max(500),
        target: executionRuntimeTargetSchema.optional()
    })).strict(),
    z.object(_object_spread_props$6(_object_spread$a({}, base), {
        source: z.literal("native_graph"),
        subject: z.object({
            kind: z.literal("invocation"),
            id: z.string().min(1)
        }).strict(),
        scope: z.literal("operation"),
        state: z.literal("settled"),
        outcome: z.literal("cancelled"),
        executionId: z.string().min(1)
    })).strict(),
    z.object(_object_spread_props$6(_object_spread$a({}, base), {
        source: z.literal("host_admission"),
        subject: z.object({
            kind: z.literal("invocation"),
            id: z.string().min(1)
        }).strict(),
        scope: z.literal("operation"),
        state: z.literal("settled"),
        outcome: z.enum([
            "failed",
            "cancelled"
        ]),
        reason: z.literal("not_started")
    })).strict()
]);
function unknownExecutionControl(subject) {
    var reason = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "unconfirmed";
    return {
        version: 1,
        source: "unavailable",
        subject: subject,
        state: "unknown",
        reason: reason,
        observedAt: new Date().toISOString()
    };
}

function _define_property$9(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$9(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$9(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$5(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$5(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$5(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
var projectPipelineOperationInputSchema = z.discriminatedUnion("kind", [
    z.object({
        kind: z.literal("evidence"),
        value: projectPipelineEvidenceRefSchema
    }).strict(),
    z.object({
        kind: z.literal("evidence_collection"),
        value: z.array(projectPipelineEvidenceRefSchema).max(100)
    }).strict(),
    z.object({
        kind: z.literal("subjects"),
        value: z.array(projectPipelineSubjectVersionSchema).min(1).max(100)
    }).strict(),
    z.object({
        kind: z.literal("parameter"),
        value: projectPipelineJsonSchema
    }).strict()
]);
var projectPipelineAssistantInputSchema = z.object({
    prompt: z.string().min(1).max(100000),
    context: z.record(projectPipelineKeySchema, projectPipelineJsonSchema).optional(),
    humanInput: z.record(projectPipelineKeySchema, projectPipelineJsonSchema).optional()
}).strict();
var projectPipelineRuntimeInputSchema = z.object({
    prompt: z.string().min(1).max(100000),
    context: z.record(projectPipelineKeySchema, projectPipelineJsonSchema).optional(),
    parameters: z.record(projectPipelineKeySchema, projectPipelineJsonSchema).optional()
}).strict();
var projectPipelineAssistantExecutionSchema = z.object({
    kind: z.literal("assistant_task"),
    executionId: z.string().uuid(),
    conversationId: z.string().uuid(),
    xpertId: z.string().uuid(),
    publishedVersion: z.string().min(1).max(500),
    status: z.enum([
        "queued",
        "running",
        "waiting",
        "succeeded",
        "failed",
        "cancelled",
        "unknown"
    ])
}).strict();
var projectPipelineRuntimeExecutionSchema = z.object({
    kind: z.literal("runtime_invocation"),
    invocationId: z.string().uuid(),
    bindingId: z.string().uuid(),
    provider: z.string().min(1).max(200),
    revision: z.string().min(1).max(500),
    status: agentInvocationStatusSchema
}).strict();
var receipt = {
    control: executionControlEvidenceSchema.optional(),
    receiptKey: z.string().min(1).max(500),
    execution: z.discriminatedUnion("kind", [
        projectPipelineAssistantExecutionSchema,
        projectPipelineRuntimeExecutionSchema
    ]).optional()
};
var projectPipelineOperationReceiptSchema = z.discriminatedUnion("status", [
    z.object(_object_spread_props$5(_object_spread$9({}, receipt), {
        status: z.literal("pending")
    })).strict(),
    z.object(_object_spread_props$5(_object_spread$9({}, receipt), {
        status: z.literal("succeeded"),
        outputs: z.record(projectPipelineKeySchema, projectPipelineEvidenceRefSchema).refine(function(value) {
            return Object.keys(value).length <= 100;
        }, "Too many output ports")
    })).strict(),
    z.object(_object_spread_props$5(_object_spread$9({}, receipt), {
        status: z.literal("failed"),
        code: projectPipelineKeySchema
    })).strict(),
    z.object(_object_spread_props$5(_object_spread$9({}, receipt), {
        status: z.literal("cancelled")
    })).strict(),
    z.object({
        control: receipt.control,
        receiptKey: receipt.receiptKey.optional(),
        execution: receipt.execution,
        status: z.literal("unknown")
    }).strict()
]);
var projectPipelineCompletionReceiptSchema = z.discriminatedUnion("status", [
    z.object({
        status: z.literal("accepted"),
        evidence: z.array(projectPipelineEvidenceRefSchema).max(100)
    }).strict(),
    z.object({
        status: z.literal("pending"),
        code: projectPipelineKeySchema
    }).strict(),
    z.object({
        status: z.literal("rejected"),
        code: projectPipelineKeySchema
    }).strict()
]);
var projectPipelinePolicyReceiptSchema = z.discriminatedUnion("status", [
    z.object({
        status: z.literal("decided"),
        outcome: projectPipelineKeySchema,
        evidence: z.array(projectPipelineEvidenceRefSchema).max(100)
    }).strict(),
    z.object({
        status: z.literal("blocked"),
        code: projectPipelineKeySchema
    }).strict()
]);

var projectPipelineConfigureSchema = z.object({
    requestId: z.string().uuid(),
    configuration: projectPipelineConfigurationSchema
}).strict();
var projectPipelineStartSchema = z.object({
    bindingId: z.string().uuid(),
    objectKey: z.string().min(1).max(500),
    triggerKey: z.string().min(1).max(500),
    title: z.string().min(1).max(1000)
}).strict();
var projectPipelineDecisionSchema = z.object({
    requestId: z.string().uuid(),
    attentionId: z.string().uuid(),
    expectedRevision: z.number().int().positive(),
    inputDigest: z.string().regex(/^[a-f0-9]{64}$/),
    generation: z.number().int().positive(),
    outcome: projectPipelineKeySchema,
    evidence: z.array(projectPipelineEvidenceRefSchema).max(100)
}).strict();
var projectPipelineNextRoundSchema = z.object({
    instanceId: z.string().uuid(),
    requestId: z.string().uuid(),
    expectedRevision: z.number().int().positive()
}).strict();
var projectPipelineCancelSchema = z.object({
    instanceId: z.string().uuid(),
    requestId: z.string().uuid(),
    expectedRevision: z.number().int().positive()
}).strict();
var projectPipelineRetrySchema = z.object({
    instanceId: z.string().uuid(),
    requestId: z.string().uuid(),
    expectedRevision: z.number().int().positive(),
    operationId: z.string().uuid(),
    inputDigest: z.string().regex(/^[a-f0-9]{64}$/),
    generation: z.number().int().positive()
}).strict();

function _array_like_to_array$f(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$7(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$f(arr);
}
function _define_property$8(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$8(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$7() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$8(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$8(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$4(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$4(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$4(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$7(arr) {
    return _array_without_holes$7(arr) || _iterable_to_array$8(arr) || _unsupported_iterable_to_array$f(arr) || _non_iterable_spread$7();
}
function _unsupported_iterable_to_array$f(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$f(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$f(o, minLen);
}
var count$5 = z.number().int().nonnegative();
var pipelineAttemptCountsSchema = z.object({
    total: count$5,
    queued: count$5,
    running: count$5,
    waiting: count$5.optional(),
    succeeded: count$5,
    failed: count$5,
    cancelled: count$5,
    unknown: count$5,
    terminal: count$5,
    successRate: z.number().min(0).max(1).nullable(),
    retries: count$5,
    additionalAttempts: count$5.optional(),
    unclassifiedAttempts: count$5.optional()
}).strict();
var pipelineExecutionTimingSchema = z.object({
    samples: count$5,
    unavailable: count$5,
    totalMs: z.number().nonnegative().nullable(),
    meanMs: z.number().nonnegative().nullable(),
    medianMs: z.number().nonnegative().nullable(),
    p95Ms: z.number().nonnegative().nullable()
}).strict();
var pipelineExecutorStatisticsSchema = z.object({
    xpertId: z.string().nullable(),
    agentKey: z.string().nullable(),
    provider: z.string().nullable(),
    toolId: z.string().nullable(),
    serviceRef: z.string().nullable().optional(),
    attempts: pipelineAttemptCountsSchema,
    timing: pipelineExecutionTimingSchema
}).strict();
/** Full Invocation outcomes preserve waiting/unknown states lost by the legacy Task status.
 * Runtime observation takes precedence over business acceptance; absence retains the legacy fallback.
 */ function status(fact) {
    var _fact_invocationStatus;
    var observed = (_fact_invocationStatus = fact.invocationStatus) !== null && _fact_invocationStatus !== void 0 ? _fact_invocationStatus : fact.runtimeStatus;
    if (!observed) return fact.status;
    switch(observed){
        case "success":
        case "succeeded":
            return "succeeded";
        case "error":
        case "failed":
        case "timeout":
            return "failed";
        case "running":
            return "running";
        case "pending":
        case "queued":
            return "queued";
        case "interrupted":
        case "waiting":
            return "waiting";
        case "cancelled":
            return "cancelled";
        default:
            return "unknown";
    }
}
function pipelineAttemptCounts(facts) {
    var result = {
        total: facts.length,
        queued: 0,
        running: 0,
        waiting: 0,
        succeeded: 0,
        failed: 0,
        cancelled: 0,
        unknown: 0,
        terminal: 0,
        successRate: null,
        retries: 0,
        additionalAttempts: 0,
        unclassifiedAttempts: 0
    };
    var perTask = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = facts[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var fact = _step.value;
            result[status(fact)]++;
            if (fact.pipelineAttemptKind === "technical_retry") result.retries++;
            else if (!fact.pipelineAttemptKind) result.unclassifiedAttempts++;
            var _perTask_get;
            perTask.set(fact.taskId, ((_perTask_get = perTask.get(fact.taskId)) !== null && _perTask_get !== void 0 ? _perTask_get : 0) + 1);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    result.terminal = result.succeeded + result.failed + result.cancelled;
    result.successRate = result.terminal ? result.succeeded / result.terminal : null;
    result.additionalAttempts = _to_consumable_array$7(perTask.values()).reduce(function(sum, count) {
        return sum + Math.max(0, count - 1);
    }, 0);
    return result;
}
/** Only recorded, terminal runtime intervals contribute. Missing times are not zero-duration runs. */ function pipelineExecutionTiming(facts) {
    var intervals = facts.flatMap(function(fact) {
        if (![
            "succeeded",
            "failed",
            "cancelled"
        ].includes(status(fact)) || !fact.runtimeStartedAt || !fact.runtimeCompletedAt) return [];
        var start = Date.parse(fact.runtimeStartedAt), end = Date.parse(fact.runtimeCompletedAt);
        return Number.isFinite(start) && Number.isFinite(end) && end >= start ? [
            end - start
        ] : [];
    }).sort(function(a, b) {
        return a - b;
    });
    var totalMs = intervals.length ? intervals.reduce(function(sum, value) {
        return sum + value;
    }, 0) : null;
    return {
        samples: intervals.length,
        unavailable: facts.length - intervals.length,
        totalMs: totalMs,
        meanMs: totalMs === null ? null : totalMs / intervals.length,
        medianMs: intervals.length ? (intervals[Math.floor((intervals.length - 1) / 2)] + intervals[Math.floor(intervals.length / 2)]) / 2 : null,
        p95Ms: intervals.length ? intervals[Math.ceil(intervals.length * 0.95) - 1] : null
    };
}
function pipelineExecutorStatistics(facts) {
    var groups = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = facts[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var fact = _step.value;
            var _fact_xpertId, _fact_agentKey, _fact_runtimeProvider, _fact_runtimeToolId, _fact_runtimeServiceRef;
            var identity = {
                xpertId: (_fact_xpertId = fact.xpertId) !== null && _fact_xpertId !== void 0 ? _fact_xpertId : null,
                agentKey: (_fact_agentKey = fact.agentKey) !== null && _fact_agentKey !== void 0 ? _fact_agentKey : null,
                provider: (_fact_runtimeProvider = fact.runtimeProvider) !== null && _fact_runtimeProvider !== void 0 ? _fact_runtimeProvider : null,
                toolId: (_fact_runtimeToolId = fact.runtimeToolId) !== null && _fact_runtimeToolId !== void 0 ? _fact_runtimeToolId : null,
                serviceRef: (_fact_runtimeServiceRef = fact.runtimeServiceRef) !== null && _fact_runtimeServiceRef !== void 0 ? _fact_runtimeServiceRef : null
            };
            var _groups_get;
            var key = JSON.stringify(identity), group = (_groups_get = groups.get(key)) !== null && _groups_get !== void 0 ? _groups_get : {
                identity: identity,
                facts: []
            };
            group.facts.push(fact);
            groups.set(key, group);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return _to_consumable_array$7(groups.values()).map(function(param) {
        var identity = param.identity, _$facts = param.facts;
        return _object_spread_props$4(_object_spread$8({}, identity), {
            attempts: pipelineAttemptCounts(_$facts),
            timing: pipelineExecutionTiming(_$facts)
        });
    });
}

function _array_like_to_array$e(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$6(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$e(arr);
}
function _define_property$7(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$7(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$6() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$7(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$7(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$3(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$3(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$3(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array$6(arr) {
    return _array_without_holes$6(arr) || _iterable_to_array$7(arr) || _unsupported_iterable_to_array$e(arr) || _non_iterable_spread$6();
}
function _unsupported_iterable_to_array$e(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$e(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$e(o, minLen);
}
var count$4 = z.number().int().nonnegative();
var tokens = z.number().int().nonnegative().safe();
var pipelineModelUsageStatisticsSchema = z.object({
    scope: z.literal("linked_native_llm_calls"),
    requestedExecutions: count$4,
    executionsWithRecords: count$4,
    truncated: z.boolean(),
    rejectedRecords: count$4,
    calls: count$4,
    inputTokens: count$4.nullable(),
    outputTokens: count$4.nullable(),
    totalTokens: count$4.nullable(),
    unpricedCalls: count$4,
    chargedPoints: z.number().nonnegative().nullable(),
    byModel: z.array(z.object({
        provider: z.string(),
        model: z.string(),
        calls: count$4,
        inputTokens: count$4.nullable(),
        outputTokens: count$4.nullable(),
        totalTokens: count$4.nullable()
    }).strict())
}).strict();
/** Parsed ledger facts only. Request/metric identity is independent of task and parent execution links. */ var pipelineModelUsageFactSchema = z.object({
    originExecutionId: z.string(),
    providerScopeId: z.string(),
    requestId: z.string(),
    metricKey: z.string(),
    revision: count$4,
    provider: z.string(),
    model: z.string(),
    promptTokens: tokens.nullable(),
    completionTokens: tokens.nullable(),
    totalTokens: tokens.nullable(),
    pricingStatus: z.enum([
        "priced",
        "free",
        "unpriced"
    ]),
    priceCurrency: z.string().nullable(),
    priceAmount: z.number().nonnegative().nullable()
});
function pipelineModelUsageStatistics(facts, coverage) {
    var chargedPoints = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
    var distinct = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = facts[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var fact = _step.value;
            var _distinct_get;
            var key = JSON.stringify([
                fact.providerScopeId,
                fact.requestId,
                fact.metricKey
            ]);
            var _distinct_get_revision;
            if (((_distinct_get_revision = (_distinct_get = distinct.get(key)) === null || _distinct_get === void 0 ? void 0 : _distinct_get.revision) !== null && _distinct_get_revision !== void 0 ? _distinct_get_revision : -1) < fact.revision) distinct.set(key, fact);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var calls = _to_consumable_array$6(distinct.values());
    var totals = function(items) {
        var sum = function(field) {
            if (!items.length || items.some(function(item) {
                return item[field] === null;
            })) return null;
            var value = items.reduce(function(sum, item) {
                return sum + item[field];
            }, 0);
            return Number.isSafeInteger(value) ? value : null;
        };
        return {
            calls: items.length,
            inputTokens: sum("promptTokens"),
            outputTokens: sum("completionTokens"),
            totalTokens: sum("totalTokens")
        };
    };
    var unpricedCalls = calls.filter(function(call) {
        return call.pricingStatus === "unpriced" || !call.priceCurrency || call.priceAmount === null;
    }).length;
    var models = new Map();
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = calls[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var call = _step1.value;
            var _models_get;
            var key1 = JSON.stringify([
                call.provider,
                call.model
            ]), group = (_models_get = models.get(key1)) !== null && _models_get !== void 0 ? _models_get : [];
            group.push(call);
            models.set(key1, group);
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    return _object_spread_props$3(_object_spread$7({
        scope: "linked_native_llm_calls"
    }, coverage, totals(calls)), {
        unpricedCalls: unpricedCalls,
        chargedPoints: chargedPoints,
        byModel: _to_consumable_array$6(models.values()).map(function(group) {
            return _object_spread$7({
                provider: group[0].provider,
                model: group[0].model
            }, totals(group));
        })
    });
}

/** This is a host observation, never a claim about when a person started or stopped working. */ var pipelineHumanWaitSnapshotSchema = z.object({
    schemaVersion: z.literal(1),
    observedAt: z.string().datetime(),
    nodeIds: z.array(z.string().uuid()).max(10000)
}).strict().refine(function(value) {
    return new Set(value.nodeIds).size === value.nodeIds.length;
}, "PIPELINE_WAIT_DUPLICATE_NODE");
function pipelineNodeNeedsHuman(node) {
    var historical = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    return node.kind === "human_gate" && node.state.applicability === "selected" && (historical || node.state.freshness === "current") && [
        "pending",
        "active"
    ].includes(node.state.lifecycle) && node.state.readiness === "ready";
}

function _array_like_to_array$d(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$5(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$d(arr);
}
function _iterable_to_array$6(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$5() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$5(arr) {
    return _array_without_holes$5(arr) || _iterable_to_array$6(arr) || _unsupported_iterable_to_array$d(arr) || _non_iterable_spread$5();
}
function _unsupported_iterable_to_array$d(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$d(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$d(o, minLen);
}
var count$3 = z.number().int().nonnegative();
var projectPipelineWorkCountsSchema = z.object({
    total: count$3,
    completed: count$3,
    failed: count$3,
    cancelled: count$3,
    running: count$3,
    blocked: count$3,
    unknown: count$3
}).strict();
var projectPipelineStatisticsSchema = z.object({
    scope: z.literal("round"),
    executionScope: z.enum([
        "round",
        "linked_task_history"
    ]).optional(),
    work: projectPipelineWorkCountsSchema,
    /** Business nodes include work, human gates and external confirmations; controls are excluded. */ business: projectPipelineWorkCountsSchema.optional(),
    needsYou: count$3,
    attempts: pipelineAttemptCountsSchema,
    timing: pipelineExecutionTimingSchema.optional(),
    byExecutor: z.array(pipelineExecutorStatisticsSchema).optional(),
    modelUsage: pipelineModelUsageStatisticsSchema.optional(),
    nativeModelBudget: projectPipelineNativeModelBudgetStatusSchema.optional(),
    byLane: z.array(z.object({
        key: z.string().nullable(),
        work: projectPipelineWorkCountsSchema
    }).strict()),
    byStage: z.array(z.object({
        key: z.string(),
        work: projectPipelineWorkCountsSchema
    }).strict())
}).strict();
var isBusinessNode = function(kind) {
    return kind === "work" || kind === "human_gate" || kind === "external_wait";
};
function selectedPipelineAttemptFacts(nodes, executions) {
    var historical = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    var selected = nodes.filter(function(param) {
        var _param_projection = param.projection, kind = _param_projection.kind, state = _param_projection.state;
        return isBusinessNode(kind) && state.applicability === "selected" && (historical || state.freshness === "current");
    });
    var legacyTasks = new Set(selected.filter(function(node) {
        return node.executionIds === undefined;
    }).flatMap(function(node) {
        return node.taskIds;
    }));
    var executionIds = new Set(selected.flatMap(function(node) {
        var _node_executionIds;
        return (_node_executionIds = node.executionIds) !== null && _node_executionIds !== void 0 ? _node_executionIds : [];
    }));
    var facts = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = executions[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var execution = _step.value;
            if (!(execution.id !== undefined && executionIds.has(execution.id)) && !legacyTasks.has(execution.taskId)) continue;
            var identity = execution.agentExecutionId ? "native:".concat(execution.agentExecutionId) : execution.invocationId ? "invocation:".concat(execution.invocationId) : execution.id ? "attempt:".concat(execution.id) : null;
            if (identity && !facts.has(identity)) facts.set(identity, execution);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return _to_consumable_array$5(facts.values());
}
/** Compute on the server from a complete, authorized MVCC snapshot; never from a filtered page. */ function projectPipelineStatistics(nodes, executions) {
    var historical = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false, executionScope = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "linked_task_history";
    var selected = nodes.filter(function(param) {
        var state = param.projection.state;
        return state.applicability === "selected" && (historical || state.freshness === "current");
    });
    var work = selected.filter(function(node) {
        return node.projection.kind === "work";
    });
    var counts = function(items) {
        return {
            total: items.length,
            completed: items.filter(function(node) {
                return node.projection.state.lifecycle === "completed";
            }).length,
            failed: items.filter(function(node) {
                return node.projection.state.lifecycle === "failed";
            }).length,
            cancelled: items.filter(function(node) {
                return node.projection.state.lifecycle === "cancelled";
            }).length,
            running: items.filter(function(node) {
                return node.projection.state.runtime === "running";
            }).length,
            blocked: items.filter(function(node) {
                return [
                    "pending",
                    "active",
                    "failed"
                ].includes(node.projection.state.lifecycle) && node.projection.state.readiness === "blocked";
            }).length,
            unknown: items.filter(function(node) {
                return node.projection.state.runtime === "unknown";
            }).length
        };
    };
    // Execution identity counts once even if the same fact is linked to multiple work items.
    var recorded = selectedPipelineAttemptFacts(nodes, executions, historical);
    var attempts = pipelineAttemptCounts(recorded);
    return {
        scope: "round",
        executionScope: executionScope,
        work: counts(work),
        business: counts(selected.filter(function(node) {
            return isBusinessNode(node.projection.kind);
        })),
        attempts: attempts,
        timing: pipelineExecutionTiming(recorded),
        byExecutor: pipelineExecutorStatistics(recorded),
        needsYou: selected.filter(function(node) {
            return pipelineNodeNeedsHuman(node.projection, historical);
        }).length,
        byLane: _to_consumable_array$5(new Set(work.map(function(node) {
            return node.projection.laneKey;
        }))).map(function(key) {
            return {
                key: key,
                work: counts(work.filter(function(node) {
                    return node.projection.laneKey === key;
                }))
            };
        }),
        byStage: _to_consumable_array$5(new Set(work.map(function(node) {
            return node.projection.stageKey;
        }))).map(function(key) {
            return {
                key: key,
                work: counts(work.filter(function(node) {
                    return node.projection.stageKey === key;
                }))
            };
        })
    };
}

/** Credential support for durable pipeline commands; Project permissions remain independently required. */ var projectPipelineCommandCapabilitySchema = z.discriminatedUnion("allowed", [
    z.object({
        allowed: z.literal(true)
    }).strict(),
    z.object({
        allowed: z.literal(false),
        reason: z.literal("PIPELINE_SCOPED_DELEGATION_UNAVAILABLE")
    }).strict()
]);

function _array_like_to_array$c(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$9(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$4(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$c(arr);
}
function _define_property$6(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$5(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$8(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$9() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$4() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$6(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$6(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$2(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$2(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$2(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array$8(arr, i) {
    return _array_with_holes$9(arr) || _iterable_to_array_limit$8(arr, i) || _unsupported_iterable_to_array$c(arr, i) || _non_iterable_rest$9();
}
function _to_consumable_array$4(arr) {
    return _array_without_holes$4(arr) || _iterable_to_array$5(arr) || _unsupported_iterable_to_array$c(arr) || _non_iterable_spread$4();
}
function _unsupported_iterable_to_array$c(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$c(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$c(o, minLen);
}
var label$1 = z.object({
    en_US: z.string().min(1).max(200),
    zh_Hans: z.string().min(1).max(200).optional()
}).strict();
var field = {
    key: projectPipelineKeySchema,
    label: label$1,
    description: label$1.optional()
};
var option = z.object({
    value: z.string().min(1).max(200),
    label: label$1
}).strict();
var projectPipelineParameterFieldSchema = z.discriminatedUnion("type", [
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("boolean")
    })).strict(),
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("text"),
        maxLength: z.number().int().min(1).max(4000),
        minLength: z.number().int().min(0).max(4000)
    })).strict(),
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("number"),
        min: z.number().finite(),
        max: z.number().finite(),
        integer: z.boolean()
    })).strict(),
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("choice"),
        options: z.array(option).min(1).max(100)
    })).strict(),
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("multi_choice"),
        options: z.array(option).min(1).max(100),
        minItems: z.number().int().min(0).max(100).default(0)
    })).strict(),
    z.object(_object_spread_props$2(_object_spread$6({}, field), {
        type: z.literal("string_list"),
        maxItems: z.number().int().min(1).max(100),
        itemMaxLength: z.number().int().min(1).max(500)
    })).strict()
]);
var projectPipelineConfigurationFormSchema = z.object({
    templateRef: projectPipelineRefSchema,
    description: label$1,
    assistantSlots: z.array(z.object({
        slot: projectPipelineKeySchema,
        label: label$1,
        description: label$1.optional()
    }).strict()).max(100),
    runtimeSlots: z.array(z.object({
        slot: projectPipelineKeySchema,
        label: label$1,
        description: label$1.optional()
    }).strict()).max(100).optional(),
    /** Optional maxima for the three editable admission values; not an execution budget by itself. */ nativeModelBudget: projectPipelineNativeModelBudgetSchema.optional(),
    parameters: z.array(projectPipelineParameterFieldSchema).max(100)
}).strict().superRefine(function(form, context) {
    var _form_runtimeSlots;
    for(var _i = 0, _iter = [
        [
            "assistantSlots",
            _to_consumable_array$4(form.assistantSlots).concat(_to_consumable_array$4((_form_runtimeSlots = form.runtimeSlots) !== null && _form_runtimeSlots !== void 0 ? _form_runtimeSlots : [])).map(function(item) {
                return item.slot;
            })
        ],
        [
            "parameters",
            form.parameters.map(function(item) {
                return item.key;
            })
        ]
    ]; _i < _iter.length; _i++){
        var _iter__i = _sliced_to_array$8(_iter[_i], 2), path = _iter__i[0], keys = _iter__i[1];
        if (new Set(keys).size !== keys.length) context.addIssue({
            code: "custom",
            message: "DUPLICATE_CONFIGURATION_FIELD",
            path: [
                path
            ]
        });
    }
    form.parameters.forEach(function(item, index) {
        if (item.type === "number" && item.min > item.max || item.type === "text" && item.minLength > item.maxLength || item.type === "multi_choice" && item.minItems > item.options.length || (item.type === "choice" || item.type === "multi_choice") && new Set(item.options.map(function(option) {
            return option.value;
        })).size !== item.options.length) context.addIssue({
            code: "custom",
            message: "INVALID_CONFIGURATION_FIELD",
            path: [
                "parameters",
                index
            ]
        });
    });
});
var projectPipelineRuntimeSelectionSchema = z.object({
    bindingId: z.string().uuid(),
    workspaceId: z.string().uuid()
}).strict();
var projectPipelineCatalogConfigureSchema = z.object({
    requestId: z.string().uuid(),
    contributionKey: projectPipelineKeySchema,
    templateRef: projectPipelineRefSchema,
    assistants: z.record(projectPipelineKeySchema, z.string().uuid()),
    runtimes: z.record(projectPipelineKeySchema, projectPipelineRuntimeSelectionSchema).optional(),
    nativeModelBudget: projectPipelineNativeModelBudgetSchema.optional(),
    parameters: z.record(projectPipelineKeySchema, projectPipelineJsonSchema)
}).strict();
/** Catalog wire format; independent of the definition's execution protocol requirements. */ var projectPipelineCatalogProtocolSchema = z.union([
    z.literal(1),
    z.literal(2),
    z.literal(3)
]);
var projectPipelineCatalogRequestSchema = z.object({
    protocol: projectPipelineCatalogProtocolSchema.optional()
}).strict();
function canReadProjectPipelineConfiguration(configuration, request, form) {
    var _configuration_binding_limits;
    if (request.protocol === undefined && configuration.template.hostRequirements) return false;
    var _request_protocol;
    return ((_request_protocol = request.protocol) !== null && _request_protocol !== void 0 ? _request_protocol : 1) >= 2 || !(((_configuration_binding_limits = configuration.binding.limits) === null || _configuration_binding_limits === void 0 ? void 0 : _configuration_binding_limits.nativeModelBudget) || (form === null || form === void 0 ? void 0 : form.nativeModelBudget));
}
var projectPipelineCatalogSchema = z.object({
    hostCapabilities: projectPipelineHostCapabilitiesSchema.optional(),
    /** Protocol 3 support for saving configuration; does not grant permission to execute a pipeline. */ commandCapability: projectPipelineCommandCapabilitySchema.optional(),
    canManage: z.boolean(),
    items: z.array(z.object({
        contributionKey: projectPipelineKeySchema,
        configuration: projectPipelineConfigurationSchema,
        form: projectPipelineConfigurationFormSchema.optional()
    }).strict()),
    assistants: z.array(z.object({
        id: z.string().uuid(),
        name: z.string(),
        publishedVersion: z.string()
    }).strict()),
    runtimeBindings: z.array(z.object({
        id: z.string().uuid(),
        title: z.string(),
        provider: z.string(),
        revision: z.string(),
        workspaces: z.array(z.object({
            id: z.string().uuid(),
            name: z.string()
        }).strict()).min(1).max(100)
    }).strict()).optional()
}).strict();
var projectPipelineSavedConfigurationSchema = z.object({
    id: z.string().uuid(),
    revision: z.number().int().positive(),
    createdAt: z.string().datetime(),
    configuration: projectPipelineConfigurationSchema
}).strict();
var projectPipelineConfigurationPageSchema = z.object({
    items: z.array(projectPipelineSavedConfigurationSchema),
    next: z.string().uuid().nullable()
}).strict();
function parameterSchema(field) {
    switch(field.type){
        case "boolean":
            return z.boolean();
        case "text":
            return z.string().min(field.minLength).max(field.maxLength);
        case "number":
            return (field.integer ? z.number().int() : z.number()).finite().min(field.min).max(field.max);
        case "choice":
            return z.string().refine(function(value) {
                return field.options.some(function(option) {
                    return option.value === value;
                });
            });
        case "multi_choice":
            return z.array(z.string()).min(field.minItems).max(field.options.length).refine(function(values) {
                return new Set(values).size === values.length && values.every(function(value) {
                    return field.options.some(function(option) {
                        return option.value === value;
                    });
                });
            });
        case "string_list":
            return z.array(z.string().min(1).max(field.itemMaxLength)).max(field.maxItems);
    }
}
/** Strict allowlist shared by saved configuration and provider action forms. */ function parseProjectPipelineParameters(fields, values) {
    if (fields.some(function(item) {
        return item.type === "number" && item.min > item.max || item.type === "text" && item.minLength > item.maxLength || item.type === "multi_choice" && item.minItems > item.options.length || (item.type === "choice" || item.type === "multi_choice") && new Set(item.options.map(function(option) {
            return option.value;
        })).size !== item.options.length;
    })) throw new Error("PIPELINE_CONFIGURATION_FIELD_INVALID");
    var keys = fields.map(function(field) {
        return field.key;
    });
    if (new Set(keys).size !== keys.length || Object.keys(values).length !== keys.length || Object.keys(values).some(function(key) {
        return !keys.includes(key);
    })) throw new Error("PIPELINE_CONFIGURATION_FIELDS_MISMATCH");
    return Object.fromEntries(fields.map(function(field) {
        return [
            field.key,
            parameterSchema(field).parse(values[field.key])
        ];
    }));
}
/** Expose only declared fields; immutable topology, selectors and undisclosed defaults stay server-owned. */ function configureProjectPipelineFromForm(configuration, form, input) {
    if (form.templateRef !== configuration.binding.templateRef || configuration.template.executionAuthority !== "platform") throw new Error("PIPELINE_CONFIGURATION_FORM_MISMATCH");
    var sameKeys = function(actual, expected) {
        return actual.length === expected.length && actual.every(function(key) {
            return expected.includes(key);
        });
    };
    var _configuration_binding_executorBindings;
    if (!sameKeys(form.assistantSlots.map(function(item) {
        return item.slot;
    }), Object.entries((_configuration_binding_executorBindings = configuration.binding.executorBindings) !== null && _configuration_binding_executorBindings !== void 0 ? _configuration_binding_executorBindings : {}).filter(function(param) {
        var _param = _sliced_to_array$8(param, 2), executor = _param[1];
        return executor.kind === "assistant";
    }).map(function(param) {
        var _param = _sliced_to_array$8(param, 1), slot = _param[0];
        return slot;
    }))) throw new Error("PIPELINE_CONFIGURATION_SLOTS_INCOMPLETE");
    var _form_runtimeSlots, _input_runtimes;
    var runtimeSlots = (_form_runtimeSlots = form.runtimeSlots) !== null && _form_runtimeSlots !== void 0 ? _form_runtimeSlots : [], runtimes = (_input_runtimes = input.runtimes) !== null && _input_runtimes !== void 0 ? _input_runtimes : {};
    var _configuration_binding_executorBindings1;
    if (!sameKeys(runtimeSlots.map(function(item) {
        return item.slot;
    }), Object.entries((_configuration_binding_executorBindings1 = configuration.binding.executorBindings) !== null && _configuration_binding_executorBindings1 !== void 0 ? _configuration_binding_executorBindings1 : {}).filter(function(param) {
        var _param = _sliced_to_array$8(param, 2), executor = _param[1];
        return executor.kind === "runtime_binding";
    }).map(function(param) {
        var _param = _sliced_to_array$8(param, 1), slot = _param[0];
        return slot;
    }))) throw new Error("PIPELINE_CONFIGURATION_SLOTS_INCOMPLETE");
    if (!sameKeys(Object.keys(input.assistants), form.assistantSlots.map(function(item) {
        return item.slot;
    })) || !sameKeys(Object.keys(runtimes), runtimeSlots.map(function(item) {
        return item.slot;
    })) || !sameKeys(Object.keys(input.parameters), form.parameters.map(function(item) {
        return item.key;
    }))) throw new Error("PIPELINE_CONFIGURATION_FIELDS_MISMATCH");
    var _configuration_binding_executorBindings2;
    var binding = _object_spread_props$2(_object_spread$6({}, configuration.binding), {
        parameters: _object_spread$6({}, configuration.binding.parameters),
        executorBindings: Object.fromEntries(Object.entries((_configuration_binding_executorBindings2 = configuration.binding.executorBindings) !== null && _configuration_binding_executorBindings2 !== void 0 ? _configuration_binding_executorBindings2 : {}).map(function(param) {
            var _param = _sliced_to_array$8(param, 2), key = _param[0], executor = _param[1];
            return [
                key,
                _object_spread$6({}, executor)
            ];
        }))
    });
    if (form.nativeModelBudget) {
        var _binding_limits;
        if (!((_binding_limits = binding.limits) === null || _binding_limits === void 0 ? void 0 : _binding_limits.nativeModelBudget)) throw new Error("PIPELINE_CONFIGURATION_BUDGET_DEFAULT_REQUIRED");
        var budget = projectPipelineNativeModelBudgetSchema.parse(input.nativeModelBudget);
        for(var _i = 0, _iter = [
            "maxCalls",
            "maxTokens",
            "reservationTokens"
        ]; _i < _iter.length; _i++){
            var key = _iter[_i];
            if (budget[key] > form.nativeModelBudget[key]) throw new Error("PIPELINE_CONFIGURATION_BUDGET_LIMIT");
        }
        binding.limits = _object_spread_props$2(_object_spread$6({}, binding.limits), {
            nativeModelBudget: budget
        });
    } else if (input.nativeModelBudget !== undefined) throw new Error("PIPELINE_CONFIGURATION_FIELDS_MISMATCH");
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = form.assistantSlots[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var item = _step.value;
            var _binding_executorBindings;
            var executor = (_binding_executorBindings = binding.executorBindings) === null || _binding_executorBindings === void 0 ? void 0 : _binding_executorBindings[item.slot];
            if (!executor || executor.kind !== "assistant") throw new Error("PIPELINE_CONFIGURATION_SLOT_MISMATCH");
            executor.selectionKey = z.string().uuid().parse(input.assistants[item.slot]);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = runtimeSlots[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var item1 = _step1.value;
            var executor1 = binding.executorBindings[item1.slot];
            if (!executor1 || executor1.kind !== "runtime_binding") throw new Error("PIPELINE_CONFIGURATION_SLOT_MISMATCH");
            var selection = projectPipelineRuntimeSelectionSchema.parse(runtimes[item1.slot]);
            executor1.selectionKey = selection.bindingId;
            executor1.workspaceId = selection.workspaceId;
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
    try {
        for(var _iterator2 = form.parameters[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
            var field = _step2.value;
            if (!Object.prototype.hasOwnProperty.call(binding.parameters, field.key)) throw new Error("PIPELINE_CONFIGURATION_PARAMETER_MISSING");
            binding.parameters[field.key] = parameterSchema(field).parse(input.parameters[field.key]);
        }
    } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                _iterator2.return();
            }
        } finally{
            if (_didIteratorError2) {
                throw _iteratorError2;
            }
        }
    }
    return projectPipelineConfigurationSchema.parse(_object_spread_props$2(_object_spread$6({}, configuration), {
        binding: binding
    }));
}
/** Registration validates defaults without requiring portable Assistant placeholders to be UUIDs. */ function validateProjectPipelineConfigurationForm(configuration, form) {
    var _configuration_binding_limits;
    var _form_runtimeSlots;
    return configureProjectPipelineFromForm(configuration, form, _object_spread_props$2(_object_spread$6({}, form.nativeModelBudget ? {
        nativeModelBudget: (_configuration_binding_limits = configuration.binding.limits) === null || _configuration_binding_limits === void 0 ? void 0 : _configuration_binding_limits.nativeModelBudget
    } : {}), {
        assistants: Object.fromEntries(form.assistantSlots.map(function(item) {
            return [
                item.slot,
                "00000000-0000-4000-8000-000000000001"
            ];
        })),
        runtimes: Object.fromEntries(((_form_runtimeSlots = form.runtimeSlots) !== null && _form_runtimeSlots !== void 0 ? _form_runtimeSlots : []).map(function(item) {
            return [
                item.slot,
                {
                    bindingId: "00000000-0000-4000-8000-000000000001",
                    workspaceId: "00000000-0000-4000-8000-000000000002"
                }
            ];
        })),
        parameters: Object.fromEntries(form.parameters.map(function(item) {
            return [
                item.key,
                configuration.binding.parameters[item.key]
            ];
        }))
    }));
}

var label = z.object({
    en_US: z.string().min(1).max(200),
    zh_Hans: z.string().min(1).max(200).optional()
}).strict();
var projectPipelineProviderActionDescriptorSchema = z.object({
    ref: projectPipelineRefSchema,
    label: label,
    description: label.optional(),
    sourceRevision: z.string().min(1).max(500),
    effects: z.enum([
        "read_only",
        "domain_write",
        "external_write"
    ]),
    idempotency: z.literal("keyed_receipt"),
    parameters: z.array(projectPipelineParameterFieldSchema).max(30),
    defaults: z.record(projectPipelineKeySchema, projectPipelineJsonSchema)
}).strict().superRefine(function(action, context) {
    try {
        parseProjectPipelineParameters(action.parameters, action.defaults);
    } catch (e) {
        context.addIssue({
            code: "custom",
            message: "INVALID_ACTION_PARAMETERS",
            path: [
                "parameters"
            ]
        });
    }
});
var projectPipelineProviderActionTargetSchema = z.object({
    instanceId: z.string().uuid(),
    nodeInstanceId: z.string().uuid(),
    roundId: z.string().uuid(),
    expectedRevision: z.number().int().nonnegative(),
    generation: z.number().int().positive(),
    inputDigest: z.string().regex(/^[a-f0-9]{64}$/)
}).strict();
var projectPipelineProviderActionCommandSchema = projectPipelineProviderActionTargetSchema.extend({
    requestId: z.string().uuid(),
    actionRef: projectPipelineRefSchema,
    sourceRevision: z.string().min(1).max(500),
    parameters: z.record(projectPipelineKeySchema, projectPipelineJsonSchema)
}).strict();
var projectPipelineProviderActionReceiptSchema = z.object({
    status: z.enum([
        "pending",
        "unknown",
        "succeeded",
        "failed"
    ]),
    receiptKey: z.string().min(1).max(500).optional(),
    reasonCode: z.string().regex(/^[A-Z][A-Z0-9_]{0,99}$/).optional()
}).strict();
var projectPipelineProviderActionViewSchema = z.object({
    id: z.string().uuid(),
    nodeInstanceId: z.string().uuid(),
    actionRef: projectPipelineRefSchema,
    state: z.enum([
        "queued",
        "dispatching",
        "pending",
        "unknown",
        "succeeded",
        "failed",
        "superseded"
    ]),
    reasonCode: z.string().nullable(),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
    projectionPending: z.boolean()
}).strict();
var projectPipelineProviderActionsSchema = z.object({
    dispatchEnabled: z.boolean().optional(),
    target: projectPipelineProviderActionTargetSchema,
    items: z.array(projectPipelineProviderActionDescriptorSchema).max(100),
    operations: z.array(projectPipelineProviderActionViewSchema).max(50)
}).strict();

function _array_like_to_array$b(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$3(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$b(arr);
}
function _iterable_to_array$4(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$3() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$3(arr) {
    return _array_without_holes$3(arr) || _iterable_to_array$4(arr) || _unsupported_iterable_to_array$b(arr) || _non_iterable_spread$3();
}
function _unsupported_iterable_to_array$b(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$b(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$b(o, minLen);
}
var count$2 = z.number().int().nonnegative();
var metrics = z.object({
    total: count$2,
    dispatched: count$2,
    queued: count$2,
    unavailable: count$2,
    dispatchWait: pipelineExecutionTimingSchema,
    pendingWait: z.object({
        samples: count$2,
        totalMs: z.number().nonnegative().nullable(),
        oldestMs: z.number().nonnegative().nullable()
    }).strict()
}).strict();
var pipelineQueueStatisticsSchema = z.object({
    scope: z.literal("recorded_dispatch_outbox_created_in_window"),
    coverage: z.object({
        recorded: count$2,
        missingCreatedAt: count$2,
        outsideWindow: count$2
    }).strict(),
    total: metrics,
    bySource: z.array(z.object({
        source: z.enum([
            "managed_operation",
            "provider_action"
        ]),
        metrics: metrics
    }).strict())
}).strict();
/** Outbox admission to first dispatch, not Agent runtime or human approval time.
 * Unknown/closed records without a dispatch timestamp are not zero-duration waits. */ function pipelineQueueStatistics(facts, window, snapshotAt) {
    var recorded = _to_consumable_array$3(new Map(facts.map(function(fact) {
        return [
            "".concat(fact.source, ":").concat(fact.id),
            fact
        ];
    })).values());
    var from = Date.parse(window.from), to = Date.parse(window.to), now = Date.parse(snapshotAt);
    var selected = [];
    var missingCreatedAt = 0, outsideWindow = 0;
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = recorded[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var fact = _step.value;
            var start = fact.createdAt ? Date.parse(fact.createdAt) : NaN;
            if (!Number.isFinite(start)) missingCreatedAt++;
            else if (start < from || start >= to) outsideWindow++;
            else selected.push(fact);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var aggregate = function(rows) {
        var completed = [], pending = [];
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = rows[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var row = _step.value;
                var start = Date.parse(row.createdAt), end = row.dispatchStartedAt ? Date.parse(row.dispatchStartedAt) : NaN;
                if (row.dispatchStartedAt && Number.isFinite(end) && end >= start && end <= now) completed.push(end - start);
                else if (!row.dispatchStartedAt && row.waiting && start <= now) pending.push(now - start);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
        completed.sort(function(a, b) {
            return a - b;
        });
        var totalMs = completed.length ? completed.reduce(function(sum, value) {
            return sum + value;
        }, 0) : null;
        return {
            total: rows.length,
            dispatched: completed.length,
            queued: pending.length,
            unavailable: rows.length - completed.length - pending.length,
            dispatchWait: {
                samples: completed.length,
                unavailable: rows.length - completed.length,
                totalMs: totalMs,
                meanMs: totalMs === null ? null : totalMs / completed.length,
                medianMs: completed.length ? (completed[Math.floor((completed.length - 1) / 2)] + completed[Math.floor(completed.length / 2)]) / 2 : null,
                p95Ms: completed.length ? completed[Math.ceil(completed.length * 0.95) - 1] : null
            },
            pendingWait: {
                samples: pending.length,
                totalMs: pending.length ? pending.reduce(function(sum, value) {
                    return sum + value;
                }, 0) : null,
                oldestMs: pending.length ? pending.reduce(function(maximum, value) {
                    return Math.max(maximum, value);
                }, 0) : null
            }
        };
    };
    var sources = [
        "managed_operation",
        "provider_action"
    ];
    return {
        scope: "recorded_dispatch_outbox_created_in_window",
        coverage: {
            recorded: recorded.length,
            missingCreatedAt: missingCreatedAt,
            outsideWindow: outsideWindow
        },
        total: aggregate(selected),
        bySource: sources.map(function(source) {
            return {
                source: source,
                metrics: aggregate(selected.filter(function(row) {
                    return row.source === source;
                }))
            };
        })
    };
}

function _array_like_to_array$a(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$8(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes$2(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$a(arr);
}
function _define_property$5(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array$3(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit$7(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$8() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread$2() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$5(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$5(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$1(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$1(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$1(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array$7(arr, i) {
    return _array_with_holes$8(arr) || _iterable_to_array_limit$7(arr, i) || _unsupported_iterable_to_array$a(arr, i) || _non_iterable_rest$8();
}
function _to_consumable_array$2(arr) {
    return _array_without_holes$2(arr) || _iterable_to_array$3(arr) || _unsupported_iterable_to_array$a(arr) || _non_iterable_spread$2();
}
function _unsupported_iterable_to_array$a(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$a(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$a(o, minLen);
}
var count$1 = z.number().int().nonnegative();
var pipelineHumanWaitStatisticsSchema = z.object({
    scope: z.literal("observed_human_ready_intervals_intersecting_window"),
    intervals: count$1,
    ongoing: count$1,
    censored: count$1,
    observedNodeMs: z.number().nonnegative().nullable(),
    observedUnionMs: z.number().nonnegative().nullable(),
    coverage: z.object({
        snapshots: count$1,
        missingEvents: count$1,
        invalidEvents: count$1,
        currentUntrackedNodes: count$1,
        observedWindowMs: z.number().nonnegative()
    }).strict()
}).strict();
function unionDuration(ranges) {
    var duration = 0, until = -Infinity;
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = _to_consumable_array$2(ranges).sort(function(a, b) {
            return a[0] - b[0];
        })[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var _step_value = _sliced_to_array$7(_step.value, 2), start = _step_value[0], end = _step_value[1];
            duration += Math.max(0, end - Math.max(start, until));
            until = Math.max(until, end);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return duration;
}
/** Reconstruct only observed ready intervals. A missing event breaks continuity;
 * an initial ready snapshot supplies a lower bound, never a fabricated historical start. */ function pipelineHumanWaitStatistics(events, currentWaitingNodeIds, window, snapshotAt) {
    var now = Date.parse(snapshotAt), from = Date.parse(window.from), to = Math.min(now, Date.parse(window.to));
    var intervals = [], tracked = new Set();
    var covered = [];
    var currentWaiting = new Set(currentWaitingNodeIds);
    var groups = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = events[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var event = _step.value;
            var _groups_get;
            var group = (_groups_get = groups.get(event.instanceId)) !== null && _groups_get !== void 0 ? _groups_get : [];
            group.push(event);
            groups.set(event.instanceId, group);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var snapshots = 0, missingEvents = 0, invalidEvents = 0;
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        var _loop = function() {
            var group = _step1.value;
            var open = new Map();
            var lastAt = null, previousRevision = null, continuous = false;
            var breakContinuity = function() {
                var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                try {
                    for(var _iterator = open.values()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                        var value = _step.value;
                        intervals.push(_object_spread_props$1(_object_spread$5({}, value), {
                            end: lastAt,
                            ongoing: false,
                            censored: true
                        }));
                    }
                } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                } finally{
                    try {
                        if (!_iteratorNormalCompletion && _iterator.return != null) {
                            _iterator.return();
                        }
                    } finally{
                        if (_didIteratorError) {
                            throw _iteratorError;
                        }
                    }
                }
                open.clear();
                continuous = false;
            };
            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
            try {
                for(var _iterator = _to_consumable_array$2(group).sort(function(a, b) {
                    return a.revision - b.revision;
                })[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                    var event = _step.value;
                    if (previousRevision !== null && event.revision !== previousRevision + 1) {
                        breakContinuity();
                        invalidEvents++;
                    }
                    previousRevision = event.revision;
                    var observation = event.snapshot;
                    var at = observation ? Date.parse(observation.observedAt) : NaN;
                    if (!observation || !Number.isFinite(at) || at > now || lastAt !== null && at < lastAt) {
                        if (event.invalid || observation) invalidEvents++;
                        else missingEvents++;
                        breakContinuity();
                        continue;
                    }
                    snapshots++;
                    if (continuous && lastAt !== null) covered.push([
                        lastAt,
                        at
                    ]);
                    var ready = new Set(observation.nodeIds);
                    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
                    try {
                        for(var _iterator1 = open[Symbol.iterator](), _step2; !(_iteratorNormalCompletion1 = (_step2 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                            var _step_value = _sliced_to_array$7(_step2.value, 2), id = _step_value[0], value = _step_value[1];
                            if (!ready.has(id)) {
                                intervals.push(_object_spread_props$1(_object_spread$5({}, value), {
                                    end: at,
                                    ongoing: false
                                }));
                                open.delete(id);
                            }
                        }
                    } catch (err) {
                        _didIteratorError1 = true;
                        _iteratorError1 = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                                _iterator1.return();
                            }
                        } finally{
                            if (_didIteratorError1) {
                                throw _iteratorError1;
                            }
                        }
                    }
                    var _iteratorNormalCompletion2 = true, _didIteratorError2 = false, _iteratorError2 = undefined;
                    try {
                        for(var _iterator2 = ready[Symbol.iterator](), _step3; !(_iteratorNormalCompletion2 = (_step3 = _iterator2.next()).done); _iteratorNormalCompletion2 = true){
                            var id1 = _step3.value;
                            if (!open.has(id1)) open.set(id1, {
                                start: at,
                                censored: !continuous
                            });
                        }
                    } catch (err) {
                        _didIteratorError2 = true;
                        _iteratorError2 = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
                                _iterator2.return();
                            }
                        } finally{
                            if (_didIteratorError2) {
                                throw _iteratorError2;
                            }
                        }
                    }
                    lastAt = at;
                    continuous = true;
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                        _iterator.return();
                    }
                } finally{
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
            var currentMatches = true;
            var _iteratorNormalCompletion3 = true, _didIteratorError3 = false, _iteratorError3 = undefined;
            try {
                for(var _iterator3 = open[Symbol.iterator](), _step4; !(_iteratorNormalCompletion3 = (_step4 = _iterator3.next()).done); _iteratorNormalCompletion3 = true){
                    var _step_value1 = _sliced_to_array$7(_step4.value, 2), id2 = _step_value1[0], value1 = _step_value1[1];
                    // Current state is independently read from the same MVCC snapshot. Divergence must not extend an interval.
                    if (currentWaiting.has(id2)) {
                        intervals.push(_object_spread_props$1(_object_spread$5({}, value1), {
                            end: now,
                            ongoing: true
                        }));
                        tracked.add(id2);
                    } else {
                        intervals.push(_object_spread_props$1(_object_spread$5({}, value1), {
                            end: lastAt,
                            ongoing: false,
                            censored: true
                        }));
                        currentMatches = false;
                    }
                }
            } catch (err) {
                _didIteratorError3 = true;
                _iteratorError3 = err;
            } finally{
                try {
                    if (!_iteratorNormalCompletion3 && _iterator3.return != null) {
                        _iterator3.return();
                    }
                } finally{
                    if (_didIteratorError3) {
                        throw _iteratorError3;
                    }
                }
            }
            if (continuous && currentMatches && lastAt !== null) covered.push([
                lastAt,
                now
            ]);
        };
        for(var _iterator1 = groups.values()[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true)_loop();
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    var selected = intervals.filter(function(interval) {
        return interval.start < to && interval.end >= from && interval.end >= interval.start;
    }).map(function(interval) {
        return _object_spread_props$1(_object_spread$5({}, interval), {
            start: Math.max(from, interval.start),
            end: Math.min(to, interval.end)
        });
    });
    var ranges = selected.map(function(interval) {
        return [
            interval.start,
            interval.end
        ];
    });
    var observedWindowMs = unionDuration(covered.filter(function(param) {
        var _param = _sliced_to_array$7(param, 2), start = _param[0], end = _param[1];
        return start < to && end > from;
    }).map(function(param) {
        var _param = _sliced_to_array$7(param, 2), start = _param[0], end = _param[1];
        return [
            Math.max(start, from),
            Math.min(end, to)
        ];
    }));
    return {
        scope: "observed_human_ready_intervals_intersecting_window",
        intervals: selected.length,
        ongoing: selected.filter(function(interval) {
            return interval.ongoing;
        }).length,
        censored: selected.filter(function(interval) {
            return interval.censored;
        }).length,
        observedNodeMs: observedWindowMs ? selected.reduce(function(sum, interval) {
            return sum + interval.end - interval.start;
        }, 0) : null,
        observedUnionMs: observedWindowMs ? unionDuration(ranges) : null,
        coverage: {
            snapshots: snapshots,
            missingEvents: missingEvents,
            invalidEvents: invalidEvents,
            observedWindowMs: observedWindowMs,
            currentUntrackedNodes: _to_consumable_array$2(currentWaiting).filter(function(id) {
                return !tracked.has(id);
            }).length
        }
    };
}

function _define_property$4(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$4(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$4(target, key, source[key]);
        });
    }
    return target;
}
var projectPipelineAnalyticsInputSchema = z.object({
    from: z.string().datetime({
        offset: true
    }),
    to: z.string().datetime({
        offset: true
    })
}).strict().superRefine(function(value, context) {
    var duration = Date.parse(value.to) - Date.parse(value.from);
    if (duration <= 0 || duration > 93 * 86400000) context.addIssue({
        code: "custom",
        message: "PIPELINE_ANALYTICS_WINDOW_INVALID"
    });
});
var count = z.number().int().nonnegative();
var currentSchema = z.object({
    work: projectPipelineWorkCountsSchema,
    business: projectPipelineWorkCountsSchema,
    needsYou: count
}).strict();
var executionSchema = z.object({
    attempts: pipelineAttemptCountsSchema,
    timing: pipelineExecutionTimingSchema
}).strict();
var projectPipelineAnalyticsSchema = z.object({
    projectId: z.string().uuid(),
    snapshotAt: z.string().datetime(),
    businessScope: z.literal("current_rounds"),
    executionScope: z.literal("recorded_history_started_in_window"),
    window: projectPipelineAnalyticsInputSchema,
    current: currentSchema,
    executions: executionSchema,
    coverage: z.object({
        instances: count,
        instancesWithoutCurrentRound: count,
        recordedAttempts: count,
        attemptsWithoutStartTime: count,
        attemptsOutsideWindow: count,
        sharedAcrossInstances: count
    }).strict(),
    byInstance: z.array(z.object({
        id: z.string().uuid(),
        title: z.string(),
        templateKey: z.string(),
        templateVersion: z.string(),
        authority: z.enum([
            "provider",
            "platform"
        ]),
        runState: z.string(),
        current: currentSchema,
        executions: executionSchema
    }).strict()),
    byExecutor: z.array(pipelineExecutorStatisticsSchema),
    modelUsage: pipelineModelUsageStatisticsSchema.optional(),
    queue: pipelineQueueStatisticsSchema.optional(),
    humanWait: pipelineHumanWaitStatisticsSchema.optional()
}).strict();
/** Historical execution membership is independent of current path selection or business acceptance. */ function pipelineAnalyticsFacts(instances, executions, window) {
    // Explicit ownership is authoritative; omitted IDs retain the legacy helper contract.
    var nodes = instances.flatMap(function(instance) {
        return instance.historyNodes;
    }).filter(function(node) {
        return [
            "work",
            "human_gate",
            "external_wait"
        ].includes(node.projection.kind);
    });
    var taskIds = new Set(nodes.filter(function(node) {
        return node.executionIds === undefined;
    }).flatMap(function(node) {
        return node.taskIds;
    }));
    var executionIds = new Set(nodes.flatMap(function(node) {
        var _node_executionIds;
        return (_node_executionIds = node.executionIds) !== null && _node_executionIds !== void 0 ? _node_executionIds : [];
    }));
    var recorded = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = executions[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var execution = _step.value;
            if (!taskIds.has(execution.taskId) && !(execution.id && executionIds.has(execution.id))) continue;
            var key = execution.agentExecutionId ? "native:".concat(execution.agentExecutionId) : execution.invocationId ? "invocation:".concat(execution.invocationId) : execution.id ? "attempt:".concat(execution.id) : null;
            if (key && !recorded.has(key)) recorded.set(key, execution);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var from = Date.parse(window.from), to = Date.parse(window.to), selected = [];
    var attemptsWithoutStartTime = 0, attemptsOutsideWindow = 0;
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = recorded.values()[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var fact = _step1.value;
            var startedAt = fact.runtimeStartedAt ? Date.parse(fact.runtimeStartedAt) : NaN;
            if (!Number.isFinite(startedAt)) attemptsWithoutStartTime++;
            else if (startedAt < from || startedAt >= to) attemptsOutsideWindow++;
            else selected.push(fact);
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    return {
        selected: selected,
        recordedAttempts: recorded.size,
        attemptsWithoutStartTime: attemptsWithoutStartTime,
        attemptsOutsideWindow: attemptsOutsideWindow
    };
}
/** One complete authorized snapshot, with a start-time cohort separate from current business state. */ function projectPipelineAnalytics(projectId, instances, executions, window, snapshotAt) {
    var instancesWithoutCurrentRound = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 0;
    return _object_spread$4({
        projectId: projectId
    }, aggregatePipelineAnalytics(instances, executions, window, snapshotAt, instancesWithoutCurrentRound));
}
/** Aggregate only authorized raw facts, never sums of per-Project percentages or percentiles. */ function aggregatePipelineAnalytics(instances, executions, window, snapshotAt) {
    var instancesWithoutCurrentRound = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
    var current = function(nodes) {
        var statistics = projectPipelineStatistics(nodes, []);
        return {
            work: statistics.work,
            business: statistics.business,
            needsYou: statistics.needsYou
        };
    };
    var metrics = function(facts) {
        return {
            attempts: pipelineAttemptCounts(facts),
            timing: pipelineExecutionTiming(facts)
        };
    };
    var facts = pipelineAnalyticsFacts(instances, executions, window);
    var byInstance = instances.map(function(instance) {
        return {
            id: instance.id,
            title: instance.title,
            templateKey: instance.templateKey,
            templateVersion: instance.templateVersion,
            authority: instance.authority,
            runState: instance.runState,
            current: current(instance.currentNodes),
            executions: metrics(pipelineAnalyticsFacts([
                instance
            ], executions, window).selected)
        };
    });
    return {
        snapshotAt: snapshotAt,
        businessScope: "current_rounds",
        executionScope: "recorded_history_started_in_window",
        window: window,
        current: current(instances.flatMap(function(instance) {
            return instance.currentNodes;
        })),
        executions: metrics(facts.selected),
        coverage: {
            instances: instances.length,
            instancesWithoutCurrentRound: instancesWithoutCurrentRound,
            recordedAttempts: facts.recordedAttempts,
            attemptsWithoutStartTime: facts.attemptsWithoutStartTime,
            attemptsOutsideWindow: facts.attemptsOutsideWindow,
            sharedAcrossInstances: byInstance.reduce(function(sum, item) {
                return sum + item.executions.attempts.total;
            }, 0) - facts.selected.length
        },
        byInstance: byInstance,
        byExecutor: pipelineExecutorStatistics(facts.selected)
    };
}

function _array_like_to_array$9(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes$1(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$9(arr);
}
function _iterable_to_array$2(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread$1() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array$1(arr) {
    return _array_without_holes$1(arr) || _iterable_to_array$2(arr) || _unsupported_iterable_to_array$9(arr) || _non_iterable_spread$1();
}
function _unsupported_iterable_to_array$9(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$9(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$9(o, minLen);
}
/** Keys identify actual resources across Projects/tenants, never caller-supplied aliases or paths. */ var projectPipelineResourceClaimSchema = z.object({
    key: z.string().regex(/^[a-f0-9]{64}$/),
    mode: z.enum([
        "shared",
        "exclusive"
    ])
}).strict();
var projectPipelineResourceClaimsSchema = z.array(projectPipelineResourceClaimSchema).min(1).max(32).superRefine(function(claims, context) {
    if (new Set(claims.map(function(claim) {
        return claim.key;
    })).size !== claims.length) context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "RESOURCE_KEYS_MUST_BE_UNIQUE"
    });
}).transform(function(claims) {
    return _to_consumable_array$1(claims).sort(function(left, right) {
        return left.key.localeCompare(right.key);
    });
});
var projectPipelineResourceReservationSchema = z.object({
    resolverRef: projectPipelineRefSchema,
    claims: projectPipelineResourceClaimsSchema
}).strict();

var projectPipelinePortfolioInputSchema = z.object({
    projectIds: z.array(z.string().uuid()).min(1).max(50).refine(function(ids) {
        return new Set(ids).size === ids.length;
    }, "DUPLICATE_PROJECT"),
    window: projectPipelineAnalyticsInputSchema
}).strict();
var projectPipelinePortfolioSchema = z.object({
    snapshotAt: z.string().datetime(),
    window: projectPipelineAnalyticsInputSchema,
    selectionScope: z.literal("explicit_authorized_projects"),
    totals: projectPipelineAnalyticsSchema.omit({
        projectId: true,
        byInstance: true,
        queue: true,
        humanWait: true
    }),
    byProject: z.array(projectPipelineAnalyticsSchema).max(50),
    sharedAcrossProjects: z.number().int().nonnegative()
}).strict();

/** Derive requirements from typed execution semantics even when a legacy template omits its declaration. */ function _array_like_to_array$8(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$7(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$6(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$7() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$6(arr, i) {
    return _array_with_holes$7(arr) || _iterable_to_array_limit$6(arr, i) || _unsupported_iterable_to_array$8(arr, i) || _non_iterable_rest$7();
}
function _unsupported_iterable_to_array$8(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$8(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$8(o, minLen);
}
function checkProjectPipelineHostCompatibility(definition, binding, host) {
    var _definition_hostRequirements, _definition_hostRequirements1;
    var issues = [];
    var _definition_hostRequirements_protocol;
    var protocol = (_definition_hostRequirements_protocol = (_definition_hostRequirements = definition.hostRequirements) === null || _definition_hostRequirements === void 0 ? void 0 : _definition_hostRequirements.protocol) !== null && _definition_hostRequirements_protocol !== void 0 ? _definition_hostRequirements_protocol : 1;
    if (!host.protocols.includes(protocol)) issues.push({
        code: "HOST_PROTOCOL_UNSUPPORTED",
        path: [
            "template",
            "hostRequirements",
            "protocol"
        ]
    });
    var requireFeature = function(ref) {
        var version = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1, path = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [
            "template",
            "hostRequirements",
            "features",
            ref
        ];
        var versions = Object.prototype.hasOwnProperty.call(host.features, ref) ? host.features[ref] : undefined;
        if (!(versions === null || versions === void 0 ? void 0 : versions.includes(version)) && !issues.some(function(issue) {
            return issue.ref === ref;
        })) issues.push({
            code: "HOST_FEATURE_UNSUPPORTED",
            path: path,
            ref: ref
        });
    };
    requireFeature("pipeline.core");
    if (definition.executionAuthority === "provider") {
        var _definition_actionRefs;
        requireFeature("pipeline.provider_projection");
        if ((_definition_actionRefs = definition.actionRefs) === null || _definition_actionRefs === void 0 ? void 0 : _definition_actionRefs.length) requireFeature("pipeline.provider_actions");
    } else {
        var _binding_limits;
        requireFeature("pipeline.managed");
        if (binding === null || binding === void 0 ? void 0 : (_binding_limits = binding.limits) === null || _binding_limits === void 0 ? void 0 : _binding_limits.nativeModelBudget) requireFeature("pipeline.native_model_budget", 1, [
            "binding",
            "limits",
            "nativeModelBudget"
        ]);
        definition.nodes.forEach(function(node, index) {
            if (node.kind === "work" && node.resourceResolverRef) requireFeature("pipeline.resources", 1, [
                "template",
                "nodes",
                index,
                "resourceResolverRef"
            ]);
        });
        var _binding_executorBindings;
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = Object.entries((_binding_executorBindings = binding === null || binding === void 0 ? void 0 : binding.executorBindings) !== null && _binding_executorBindings !== void 0 ? _binding_executorBindings : {})[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var _step_value = _sliced_to_array$6(_step.value, 2), slot = _step_value[0], executor = _step_value[1];
                if (executor.kind === "assistant") requireFeature("pipeline.assistant", 1, [
                    "binding",
                    "executorBindings",
                    slot
                ]);
                if (executor.kind === "runtime_binding") {
                    requireFeature("pipeline.runtime_binding", 1, [
                        "binding",
                        "executorBindings",
                        slot
                    ]);
                    if (executor.workspaceId) requireFeature("pipeline.runtime_workspace", 1, [
                        "binding",
                        "executorBindings",
                        slot,
                        "workspaceId"
                    ]);
                }
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    var _definition_hostRequirements_features;
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = Object.entries((_definition_hostRequirements_features = (_definition_hostRequirements1 = definition.hostRequirements) === null || _definition_hostRequirements1 === void 0 ? void 0 : _definition_hostRequirements1.features) !== null && _definition_hostRequirements_features !== void 0 ? _definition_hostRequirements_features : {})[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var _step_value1 = _sliced_to_array$6(_step1.value, 2), feature = _step_value1[0], version = _step_value1[1];
            requireFeature(feature, version);
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    return issues;
}

/** Host-issued dispatch lease; a reference is not authorization until revalidated against durable work. */ var projectPipelineNativeDispatchSchema = z.object({
    kind: z.literal("provider_action"),
    operationId: z.string().uuid(),
    leaseOwner: z.string().uuid(),
    leaseFence: z.number().int().positive().safe()
}).strict();
var projectPipelineNativeSourceSchema = projectPipelineNativeDispatchSchema.extend({
    callKey: projectPipelineKeySchema
});

var projectPipelineContributionSchema = z.object({
    key: projectPipelineKeySchema,
    configurations: z.array(projectPipelineConfigurationSchema).max(100),
    descriptors: z.array(projectPipelineExtensionDescriptorSchema).max(1000),
    forms: z.array(projectPipelineConfigurationFormSchema).max(100).optional()
}).strict().superRefine(function(value, context) {
    var keys = value.configurations.map(function(item) {
        return "".concat(item.template.key, "@").concat(item.template.version);
    });
    var refs = value.descriptors.map(function(descriptor) {
        return "".concat(descriptor.kind, ":").concat(descriptor.ref);
    });
    if (new Set(keys).size !== keys.length || new Set(refs).size !== refs.length) {
        context.addIssue({
            code: z.ZodIssueCode.custom,
            message: "DUPLICATE_PIPELINE_CONTRIBUTION"
        });
    }
    var _value_forms;
    var forms = (_value_forms = value.forms) !== null && _value_forms !== void 0 ? _value_forms : [];
    if (new Set(forms.map(function(form) {
        return form.templateRef;
    })).size !== forms.length) context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "DUPLICATE_CONFIGURATION_FORM"
    });
    forms.forEach(function(form, index) {
        var configuration = value.configurations.find(function(item) {
            return item.binding.templateRef === form.templateRef;
        });
        try {
            if (!configuration) throw new Error("CONFIGURATION_MISSING");
            validateProjectPipelineConfigurationForm(configuration, form);
        } catch (e) {
            context.addIssue({
                code: z.ZodIssueCode.custom,
                message: "INVALID_CONFIGURATION_FORM",
                path: [
                    "forms",
                    index
                ]
            });
        }
    });
});

/** Portable node contract. Only the host executes installation; plugins supply immutable inputs. */ var projectPluginDeploymentRefs = {
    operation: "platform.plugin-deployment@1",
    request: "platform.plugin-deployment-request@1",
    receipt: "platform.plugin-deployment-receipt@1",
    evidence: "platform.plugin-deployment-evidence@1"
};
var projectPluginDeploymentRequestSchema = z.object({
    target: z.literal("current-instance"),
    artifactId: z.string().uuid(),
    artifactVersionId: z.string().uuid(),
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
    fileName: z.string().min(1).max(240).regex(/^[^/\\\u0000]+$/),
    packageName: z.string().min(1).max(240),
    packageVersion: z.string().min(1).max(80),
    allowReplace: z.boolean(),
    allowRestart: z.boolean()
}).strict();
var projectPluginDeploymentReceiptSchema = z.object({
    operationId: z.string().uuid(),
    request: projectPluginDeploymentRequestSchema,
    approval: projectPipelineEvidenceRefSchema,
    scopeKey: z.string().min(1),
    runtimeRevision: z.string().min(1),
    installed: z.literal(true),
    loaded: z.literal(true)
}).strict();

var templateDependencyVersionsSchema = z$1.array(z$1.object({
    pluginName: z$1.string().min(1).max(214),
    version: z$1.string().min(1).max(100)
}).strict()).max(100);
var templateDependencyLocksSchema = z$1.array(z$1.object({
    pluginName: z$1.string().trim().min(1).max(300),
    version: z$1.string().trim().min(1).max(300),
    /** Explicit template requirement, distinct from the automatically recorded installation version. */ requiredVersion: z$1.string().trim().min(1).max(300).optional(),
    source: z$1.object({
        kind: z$1.literal("agent-plugin"),
        name: z$1.string().min(1).max(300),
        digest: z$1.string().regex(/^[a-f0-9]{64}$/),
        bindingId: z$1.string().uuid(),
        bindingVersion: z$1.string().min(1).max(300)
    }).strict().optional(),
    providers: z$1.array(z$1.object({
        kind: z$1.enum([
            "middleware",
            "sandbox",
            "toolset"
        ]),
        key: z$1.string().min(1).max(300)
    }).strict()).max(300).optional(),
    components: z$1.array(z$1.object({
        type: z$1.enum([
            "skill",
            "mcp_server",
            "toolset",
            "app",
            "hook",
            "asset"
        ]),
        key: z$1.string().min(1).max(128),
        hash: z$1.string().min(1).max(300)
    }).strict()).max(300)
}).strict()).max(200);

function _array_like_to_array$7(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$6(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$5(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$6() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$5(arr, i) {
    return _array_with_holes$6(arr) || _iterable_to_array_limit$5(arr, i) || _unsupported_iterable_to_array$7(arr, i) || _non_iterable_rest$6();
}
function _unsupported_iterable_to_array$7(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$7(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$7(o, minLen);
}
var text$1 = z$1.string().trim().min(1).max(300);
var key$1 = z$1.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/);
var required = z$1.boolean().default(true);
/** Portable paths only. Volume remains responsible for canonical containment and symlink checks. */ var templateFilePathSchema = z$1.string().min(1).max(512).refine(function(value) {
    return(// Control characters are intentionally rejected in untrusted template paths.
    // eslint-disable-next-line no-control-regex
    !/[\\:\x00-\x1f]/.test(value) && value.split("/").every(function(part) {
        return !!part && part !== "." && part !== ".." && part.toLowerCase() !== ".apps" && !part.toLowerCase().startsWith(".workspace-write-");
    }));
});
var fileEntrySchema = z$1.discriminatedUnion("kind", [
    z$1.object({
        kind: z$1.literal("directory"),
        path: templateFilePathSchema
    }).strict(),
    z$1.object({
        kind: z$1.literal("file"),
        path: templateFilePathSchema,
        content: z$1.string().max(262144),
        contentVersion: text$1,
        policy: z$1.literal("create-only")
    }).strict(),
    z$1.object({
        kind: z$1.literal("ledger"),
        path: templateFilePathSchema.refine(function(path) {
            return path.endsWith(".json");
        }),
        structureVersion: text$1,
        columns: z$1.array(z$1.object({
            key: key$1,
            label: text$1,
            type: z$1.enum([
                "string",
                "number",
                "boolean",
                "date"
            ])
        }).strict()).min(1).max(64),
        policy: z$1.literal("create-only")
    }).strict()
]);
var templateFilesSchema = z$1.object({
    scope: z$1.enum([
        "shared",
        "user"
    ]),
    entries: z$1.array(fileEntrySchema).min(1).max(100)
}).strict().superRefine(function(param, ctx) {
    var entries = param.entries;
    var paths = new Set();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        var _loop = function() {
            var _step_value = _sliced_to_array$5(_step.value, 2), index = _step_value[0], entry = _step_value[1];
            var path = entry.path.toLowerCase();
            if (paths.has(path)) ctx.addIssue({
                code: "custom",
                path: [
                    "entries",
                    index,
                    "path"
                ],
                message: "Duplicate path"
            });
            paths.add(path);
            if (entries.some(function(other) {
                return other.kind !== "directory" && path.startsWith("".concat(other.path.toLowerCase(), "/"));
            })) ctx.addIssue({
                code: "custom",
                path: [
                    "entries",
                    index,
                    "path"
                ],
                message: "File cannot be a parent"
            });
            if (entry.kind === "ledger" && new Set(entry.columns.map(function(column) {
                return column.key;
            })).size !== entry.columns.length) ctx.addIssue({
                code: "custom",
                path: [
                    "entries",
                    index,
                    "columns"
                ],
                message: "Duplicate column"
            });
        };
        for(var _iterator = entries.entries()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true)_loop();
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    if (entries.reduce(function(size, entry) {
        return size + (entry.kind === "file" ? entry.content.length : 0);
    }, 0) > 1048576) ctx.addIssue({
        code: "custom",
        message: "Initial content exceeds limit"
    });
});
/** Versioned, credential-free declarations. Missing manifest preserves the legacy template contract. */ var templateManifestV1Schema = z$1.object({
    schemaVersion: z$1.literal(1),
    version: text$1,
    skills: z$1.array(z$1.object({
        pluginName: text$1.optional(),
        componentKey: key$1
    }).strict()).max(100).optional(),
    files: templateFilesSchema.optional(),
    onboarding: z$1.object({
        skill: key$1,
        required: required,
        preferences: z$1.array(key$1).max(50).refine(function(items) {
            return new Set(items).size === items.length;
        }),
        completionCriteria: text$1
    }).strict().optional(),
    connectors: z$1.array(z$1.object({
        key: key$1,
        provider: text$1,
        required: required,
        purpose: text$1,
        permissions: z$1.array(text$1).max(50)
    }).strict()).max(50).refine(function(items) {
        return new Set(items.map(function(item) {
            return item.key;
        })).size === items.length;
    }).refine(function(items) {
        return new Set(items.map(function(item) {
            return item.provider;
        })).size === items.length;
    }).optional(),
    routines: z$1.array(z$1.object({
        key: key$1,
        required: z$1.boolean().default(false),
        trigger: z$1.enum([
            "schedule",
            "event"
        ]),
        expression: text$1,
        timezone: z$1.enum([
            "user",
            "organization"
        ]),
        skill: key$1,
        output: text$1,
        enabled: z$1.literal(false).default(false)
    }).strict()).max(50).refine(function(items) {
        return new Set(items.map(function(item) {
            return item.key;
        })).size === items.length;
    }).optional(),
    execution: z$1.object({
        modelFeatures: z$1.array(z$1.nativeEnum(ModelFeature)).max(20).optional(),
        sandbox: z$1.enum([
            "server",
            "cloud-computer"
        ]).optional(),
        localCapabilities: z$1.array(key$1).max(20).optional(),
        offline: z$1.enum([
            "requires-online",
            "local-only"
        ]).optional()
    }).strict().optional()
}).strict();
/** V2 keeps only initialization and requirements that the DSL cannot express. */ var assistantTemplateManifestSchema = templateManifestV1Schema.omit({
    skills: true,
    execution: true
}).extend({
    schemaVersion: z$1.literal(2),
    execution: templateManifestV1Schema.shape.execution.unwrap().omit({
        sandbox: true
    }).optional()
}).strict();
var templateManifestSchema = z$1.discriminatedUnion("schemaVersion", [
    templateManifestV1Schema,
    assistantTemplateManifestSchema
]);

var key = z$1.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/);
var templatePreferenceValuesSchema = z$1.record(key, z$1.string().trim().max(2000)).refine(function(values) {
    return Object.keys(values).length <= 50;
});
var assistantTemplateSetupStateSchema = z$1.object({
    revision: z$1.number().int().nonnegative(),
    preferences: templatePreferenceValuesSchema,
    completedAt: z$1.string().datetime().optional(),
    firstResult: z$1.string().trim().min(1).max(4000).optional(),
    connectors: z$1.record(key, z$1.discriminatedUnion("choice", [
        z$1.object({
            choice: z$1.literal("binding"),
            bindingId: z$1.string().uuid()
        }).strict(),
        z$1.object({
            choice: z$1.literal("skip")
        }).strict()
    ]))
}).strict();
var templateSetupUpdateSchema = z$1.object({
    revision: z$1.number().int().nonnegative(),
    preferences: templatePreferenceValuesSchema.optional(),
    firstResult: z$1.string().trim().min(1).max(4000).optional(),
    connector: z$1.object({
        key: key,
        selection: z$1.discriminatedUnion("choice", [
            z$1.object({
                choice: z$1.literal("binding"),
                bindingId: z$1.string().uuid()
            }).strict(),
            z$1.object({
                choice: z$1.literal("skip")
            }).strict()
        ])
    }).strict().optional()
}).strict();
/** Assistant execution policy, independent of template delivery metadata. Exact tool names only. */ var assistantOperationPolicySchema = z$1.object({
    default: z$1.enum([
        "allow",
        "approve",
        "deny"
    ]),
    rules: z$1.array(z$1.object({
        tool: key,
        decision: z$1.enum([
            "allow",
            "approve",
            "deny"
        ]),
        reason: z$1.string().trim().min(1).max(500)
    }).strict()).max(300)
}).strict().refine(function(policy) {
    return new Set(policy.rules.map(function(rule) {
        return rule.tool;
    })).size === policy.rules.length;
});

var templateActivityReadSchema = z$1.object({
    keys: z$1.array(z$1.string().regex(/^[a-f0-9-]{36}:(pending|running|awaiting_approval|paused|succeeded|failed)$/)).max(50)
}).strict();

var templatePublicationInputSchema = z$1.object({
    revision: z$1.string().regex(/^[a-f0-9]{64}$/),
    contentHash: z$1.string().regex(/^[a-f0-9]{64}$/),
    visibility: z$1.enum([
        "team",
        "public"
    ]),
    version: z$1.string().trim().regex(/^\d+\.\d+\.\d+$/),
    releaseNotes: z$1.string().trim().max(4000).default("")
}).strict();
var templateUpgradeSectionSchema = z$1.enum([
    "presentation",
    "instructions",
    "runtime",
    "definition"
]);
var templateUpgradeInputSchema = z$1.object({
    targetTemplateId: z$1.string().trim().min(1).max(500).optional(),
    revision: z$1.string().regex(/^[a-f0-9]{64}$/),
    sourceHash: z$1.string().regex(/^[a-f0-9]{64}$/),
    choices: z$1.record(templateUpgradeSectionSchema, z$1.enum([
        "keep",
        "replace"
    ]))
}).strict();
var templateUpgradeActionSchema = z$1.object({
    operationId: z$1.string().uuid()
}).strict();

var executionObservationStatusSchema = z.enum([
    "running",
    "success",
    "error",
    "pending",
    "timeout",
    "interrupted",
    "unknown"
]);
var executionObservationFilterSchema = z.object({
    from: z.string().datetime({
        offset: true
    }).describe("Inclusive UTC/offset timestamp."),
    to: z.string().datetime({
        offset: true
    }).describe("Exclusive timestamp, at most 31 days after from."),
    timeZone: z.string().max(80).default("UTC").refine(function(value) {
        try {
            new Intl.DateTimeFormat("en", {
                timeZone: value
            });
            return true;
        } catch (e) {
            return false;
        }
    }, "Use an IANA time zone"),
    countingUnit: z.enum([
        "root_execution",
        "assistant_invocation"
    ]).default("root_execution"),
    assistantId: z.string().uuid().optional(),
    conversationId: z.string().uuid().optional().describe("Exact persisted conversation ID; includes all matching threads."),
    threadId: z.string().min(1).max(100).optional().describe("Exact persisted thread ID."),
    unknownAssistantOnly: z.boolean().optional().describe("Only records with no persisted Assistant identity."),
    workspaceId: z.string().uuid().optional(),
    recordedById: z.string().uuid().optional().describe("Record creator, not necessarily the end user or billed actor."),
    source: z.string().trim().min(1).max(80).optional(),
    statuses: z.array(executionObservationStatusSchema).max(7).optional(),
    search: z.string().trim().max(80).optional(),
    asOf: z.string().datetime({
        offset: true
    }).optional().describe("Interval clipping boundary; this does not freeze mutable database records.")
}).strict();
var executionObservationQuerySchema = executionObservationFilterSchema.extend({
    page: z.number().int().min(1).max(10000).default(1),
    pageSize: z.number().int().min(1).max(100).default(25)
}).strict().superRefine(function(input, context) {
    var duration = Date.parse(input.to) - Date.parse(input.from);
    if (duration <= 0 || duration > 31 * 86400000) context.addIssue({
        code: "custom",
        path: [
            "to"
        ],
        message: "Choose a positive range of at most 31 days."
    });
});
var executionObservationRecordSchema = z.object({
    id: z.string(),
    assistantId: z.string().nullable(),
    assistantName: z.string().nullable(),
    workspaceId: z.string().nullable(),
    workspaceName: z.string().nullable(),
    conversationId: z.string().nullable(),
    threadId: z.string().nullable(),
    parentId: z.string().nullable(),
    parentThreadId: z.string().nullable(),
    forkedFromMessageId: z.string().nullable(),
    title: z.string().nullable(),
    source: z.string().nullable(),
    recordedById: z.string().nullable(),
    status: executionObservationStatusSchema,
    createdAt: z.string(),
    completedAt: z.string().nullable(),
    elapsedTimeMs: z.number().nullable(),
    invocationKind: z.enum([
        "external_assistant",
        "sub_agent"
    ]).nullable(),
    endKnown: z.boolean(),
    hasError: z.boolean(),
    timingBasis: z.literal("record_lifecycle"),
    phasesAvailable: z.literal(false)
});
var executionObservationSegmentSchema = z.object({
    start: z.string(),
    end: z.string(),
    count: z.number().int().positive()
});
var executionObservationSummarySchema = z.object({
    total: z.number(),
    assistants: z.number(),
    conversations: z.number(),
    statuses: z.object({
        running: z.number(),
        success: z.number(),
        error: z.number(),
        pending: z.number(),
        timeout: z.number(),
        interrupted: z.number(),
        unknown: z.number()
    }),
    successRate: z.number().nullable(),
    p50ElapsedMs: z.number().nullable(),
    p95ElapsedMs: z.number().nullable(),
    durationSamples: z.number(),
    peakOverlap: z.number(),
    overlap: z.array(executionObservationSegmentSchema),
    knownIntervals: z.number(),
    unknownEnds: z.number(),
    timingBasis: z.literal("record_lifecycle"),
    phaseCoverage: z.literal("unavailable"),
    observedAt: z.string(),
    asOf: z.string(),
    usage: z.object({
        records: z.number(),
        totalTokens: z.number().nullable(),
        unpricedRecords: z.number(),
        currencies: z.array(z.object({
            currency: z.string(),
            amount: z.number()
        })),
        basis: z.literal("direct_execution_ledger"),
        coveredExecutions: z.number()
    })
});
/** Static avatar projection; animated appearance assets are unnecessary in dense rows. */ var executionObservationAvatarSchema = z.object({
    url: z.string().optional(),
    background: z.string().optional(),
    emoji: z.object({
        id: z.string(),
        unified: z.string().optional()
    }).optional()
});
var executionObservationAssistantSchema = z.object({
    id: z.string().nullable(),
    name: z.string().nullable(),
    workspaceId: z.string().nullable(),
    workspaceName: z.string().nullable(),
    avatar: executionObservationAvatarSchema.nullable(),
    total: z.number(),
    running: z.number(),
    pending: z.number(),
    interrupted: z.number(),
    failed: z.number(),
    failures: z.array(z.object({
        id: z.string(),
        completedAt: z.string()
    })).max(50),
    failureMarkersTruncated: z.boolean(),
    overlap: z.array(executionObservationSegmentSchema)
});
var executionObservationOverviewSchema = z.object({
    query: executionObservationQuerySchema,
    summary: executionObservationSummarySchema.omit({
        usage: true
    }),
    assistants: z.array(executionObservationAssistantSchema),
    totalAssistants: z.number(),
    page: z.number(),
    pageSize: z.number()
});
var executionObservationListSchema = z.object({
    items: z.array(executionObservationRecordSchema),
    total: z.number(),
    page: z.number(),
    pageSize: z.number(),
    asOf: z.string(),
    observedAt: z.string()
});
var executionObservationWorkspacesSchema = z.object({
    items: z.array(z.object({
        id: z.string(),
        name: z.string()
    })),
    hasMore: z.boolean()
});
var executionObservationDetailSchema = z.object({
    item: executionObservationRecordSchema,
    children: z.array(executionObservationRecordSchema),
    childTotal: z.number(),
    childPage: z.number(),
    usage: executionObservationSummarySchema.shape.usage,
    observedAt: z.string()
});
var executionObservationDetailQuerySchema = z.object({
    executionId: z.string().uuid(),
    childPage: z.number().int().min(1).max(10000).default(1)
}).strict();
var executionObservationCompareSchema = z.object({
    current: executionObservationQuerySchema,
    baseline: executionObservationQuerySchema
}).strict();
var executionObservationAnomalySchema = z.object({
    query: executionObservationQuerySchema,
    rule: z.enum([
        "failed",
        "long_running",
        "slow_completed"
    ]).default("failed"),
    thresholdMs: z.number().int().min(1000).max(31 * 86400000).default(300000),
    limit: z.number().int().min(1).max(100).default(20)
}).strict();
/** Complete conversation groups, paginated after aggregation so a group is never split. */ var executionObservationConversationSchema = z.object({
    key: z.string(),
    conversationId: z.string().nullable(),
    threadId: z.string().nullable(),
    executionId: z.string().nullable(),
    total: z.number(),
    threads: z.number(),
    branches: z.number(),
    childExecutions: z.number(),
    failed: z.number(),
    unknownEnds: z.number(),
    overlap: z.array(executionObservationSegmentSchema),
    failures: z.array(z.object({
        id: z.string(),
        completedAt: z.string()
    })).max(50)
});
var executionObservationConversationsSchema = z.object({
    items: z.array(executionObservationConversationSchema),
    total: z.number(),
    page: z.number(),
    pageSize: z.number(),
    asOf: z.string(),
    observedAt: z.string()
});

function _array_like_to_array$6(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$5(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$4(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$5() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$4(arr, i) {
    return _array_with_holes$5(arr) || _iterable_to_array_limit$4(arr, i) || _unsupported_iterable_to_array$6(arr, i) || _non_iterable_rest$5();
}
function _unsupported_iterable_to_array$6(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$6(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$6(o, minLen);
}
/**
 * Channels of all upstream and downstream nodes relative to the starting point startKey.
 *
 * @param graph
 * @param startKey
 */ function allChannels(graph, startKey) {
    graph = getCurrentGraph(graph, startKey);
    return graph.nodes.filter(function(node) {
        return !(node.type === "workflow" && isRouterKey(node.key));
    }).map(function(node) {
        return node.key;
    });
}
function findStartNodes(graph, key) {
    var toMap = new Map();
    var _graph_connections;
    // Consider only horizontal processes
    var connections = ((_graph_connections = graph.connections) !== null && _graph_connections !== void 0 ? _graph_connections : []).filter(function(connection) {
        return connection.type === "edge" && typeof connection.from === "string" && typeof connection.to === "string";
    });
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        // Construct toMap: record all upstream nodes of each node
        for(var _iterator = connections[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var conn = _step.value;
            if (!toMap.has(conn.to)) toMap.set(conn.to, []);
            var _conn_from_split = _sliced_to_array$4(conn.from.split("/"), 1), fromKey = _conn_from_split[0];
            if (conn.type === "edge") {
                toMap.get(conn.to).push(fromKey);
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var result = new Set();
    var checked = [];
    // Recursively search upstream until you reach the starting point
    function dfsUp(nodeKey) {
        checked.push(nodeKey);
        var parents = toMap.get(nodeKey);
        // There is no upstream, this is the starting point
        if (!parents || parents.length === 0) {
            result.add(nodeKey);
            return;
        }
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = parents[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var parent = _step.value;
                // There is a cycle
                if (checked.includes(parent)) {
                    return;
                }
                dfsUp(parent);
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    dfsUp(key);
    return Array.from(result);
}
/**
 * Keep the content in the same graph as the key node (including the node, its connected nodes, and the 'edge' type connections between them)
 *
 * @param graph
 * @param key
 * @returns
 */ function getCurrentGraph(graph, key) {
    var validConnections = graph.connections.filter(function(conn) {
        return conn.type === "edge";
    });
    // Extract the primary key (remove the / suffix)
    var normalize = function(k) {
        return k.split("/")[0];
    };
    // Adjacency list: bidirectional (because you want to traverse the current graph)
    var adjacency = new Map();
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = validConnections[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var conn = _step.value;
            var from = normalize(conn.from);
            var to = normalize(conn.to);
            if (!adjacency.has(from)) adjacency.set(from, new Set());
            if (!adjacency.has(to)) adjacency.set(to, new Set());
            adjacency.get(from).add(to);
            adjacency.get(to).add(from);
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var visited = new Set();
    var queue = key ? [
        normalize(key)
    ] : [];
    // BFS/DFS collects all nodes in the same graph
    while(queue.length > 0){
        var current = queue.pop();
        if (visited.has(current)) continue;
        visited.add(current);
        var neighbors = adjacency.get(current) || new Set();
        var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
        try {
            for(var _iterator1 = neighbors[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
                var neighbor = _step1.value;
                if (!visited.has(neighbor)) {
                    queue.push(neighbor);
                }
            }
        } catch (err) {
            _didIteratorError1 = true;
            _iteratorError1 = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                    _iterator1.return();
                }
            } finally{
                if (_didIteratorError1) {
                    throw _iteratorError1;
                }
            }
        }
    }
    new Set(graph.nodes.map(function(n) {
        return n.key;
    }));
    var keptNodes = graph.nodes.filter(function(n) {
        return visited.has(normalize(n.key));
    });
    new Set(keptNodes.map(function(n) {
        return n.key;
    }));
    var keptConnections = validConnections.filter(function(conn) {
        var from = normalize(conn.from);
        var to = normalize(conn.to);
        return visited.has(from) && visited.has(to);
    });
    return {
        nodes: keptNodes,
        connections: keptConnections
    };
}
function shortTitle(input) {
    if (input) {
        return input.length <= 50 ? input : input.slice(0, 50) + "...";
    }
    return null;
}

function _array_like_to_array$5(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$4(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array$1(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_rest$4() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_array(arr) {
    return _array_with_holes$4(arr) || _iterable_to_array$1(arr) || _unsupported_iterable_to_array$5(arr) || _non_iterable_rest$4();
}
function _unsupported_iterable_to_array$5(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$5(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$5(o, minLen);
}
/**
 *
 * Returns the variable schema for a given variable name.
 * The variable name can be in the format of 'groupName.variableName' or just 'variableName'.
 *
 * @param variables
 * @param variable
 * @returns
 */ function getVariableSchema(variables, variable) {
    if (!(variables === null || variables === void 0 ? void 0 : variables.length) || !variable) {
        return {
            group: undefined,
            variable: undefined
        };
    }
    var _variable_split = _to_array(variable.split(".")), groupName = _variable_split[0], rest = _variable_split.slice(1);
    if (rest.length) {
        var grouped = findVariableInGroup(variables, groupName, rest.join("."));
        if (grouped.variable) {
            return grouped;
        }
    }
    var ungrouped = findVariableInGroup(variables, "", variable);
    if (ungrouped.variable) {
        return ungrouped;
    }
    return rest.length ? findVariableInGroup(variables, groupName, rest.join(".")) : ungrouped;
}
function findVariableInGroup(variables, groupName, variableName) {
    var group = variables.find(function(item) {
        var _item_group, _item_group1;
        return groupName ? ((_item_group = item.group) === null || _item_group === void 0 ? void 0 : _item_group.name) === groupName : !((_item_group1 = item.group) === null || _item_group1 === void 0 ? void 0 : _item_group1.name);
    });
    var selectVariable = group === null || group === void 0 ? void 0 : group.variables.find(function(item) {
        return item.name === variableName;
    });
    return {
        group: group,
        variable: selectVariable
    };
}
var FILE_VARIABLES = [
    {
        name: "filePath",
        type: XpertParameterTypeEnum.STRING,
        description: {
            en_US: "The path to the file",
            zh_Hans: "文件的路径"
        }
    },
    {
        name: "fileName",
        type: XpertParameterTypeEnum.STRING,
        description: {
            en_US: "The name of the file",
            zh_Hans: "文件的名称"
        }
    },
    {
        name: "fileUrl",
        type: XpertParameterTypeEnum.STRING,
        description: {
            en_US: "The URL of the file",
            zh_Hans: "文件的URL地址"
        }
    },
    {
        name: "fileSize",
        type: XpertParameterTypeEnum.NUMBER,
        description: {
            en_US: "The size of the file in bytes",
            zh_Hans: "文件的大小，单位为字节"
        }
    },
    {
        name: "mimeType",
        type: XpertParameterTypeEnum.STRING,
        description: {
            en_US: "The MIME type of the file",
            zh_Hans: "文件的MIME类型"
        }
    }
];

function isInterruptMessage(obj) {
    return obj && typeof obj === "object" && "type" in obj && "category" in obj;
}

/** A default assignment's purpose, independent of connection identity and model type. */ var DefaultModelRole = {
    Primary: "primary",
    Secondary: "secondary",
    Reasoning: "reasoning",
    Embedding: "embedding",
    Realtime: "realtime",
    TextToSpeech: "tts",
    SpeechToText: "speech2text",
    ImageGeneration: "image",
    VideoGeneration: "video",
    Rerank: "rerank",
    Moderation: "moderation"
};
var defaultModelRoleSchema = z$1.nativeEnum(DefaultModelRole);
var legacyProviderRoleSchema = z$1.enum([
    "primary",
    "secondary",
    "reasoning",
    "embedding"
]);
var DEFAULT_MODEL_DEFINITIONS = [
    {
        role: DefaultModelRole.Primary,
        modelType: AiModelTypeEnum.LLM,
        group: "roles",
        legacyRole: "primary"
    },
    {
        role: DefaultModelRole.Secondary,
        modelType: AiModelTypeEnum.LLM,
        group: "roles",
        legacyRole: "secondary"
    },
    {
        role: DefaultModelRole.Reasoning,
        modelType: AiModelTypeEnum.LLM,
        group: "roles",
        legacyRole: "reasoning"
    },
    {
        role: DefaultModelRole.Embedding,
        modelType: AiModelTypeEnum.TEXT_EMBEDDING,
        group: "roles",
        legacyRole: "embedding"
    },
    {
        role: DefaultModelRole.Realtime,
        modelType: AiModelTypeEnum.REALTIME,
        group: "types"
    },
    {
        role: DefaultModelRole.TextToSpeech,
        modelType: AiModelTypeEnum.TTS,
        group: "types"
    },
    {
        role: DefaultModelRole.SpeechToText,
        modelType: AiModelTypeEnum.SPEECH2TEXT,
        group: "types"
    },
    {
        role: DefaultModelRole.ImageGeneration,
        modelType: AiModelTypeEnum.IMAGE,
        group: "types"
    },
    {
        role: DefaultModelRole.VideoGeneration,
        modelType: AiModelTypeEnum.VIDEO,
        group: "types"
    },
    {
        role: DefaultModelRole.Rerank,
        modelType: AiModelTypeEnum.RERANK,
        group: "types"
    },
    {
        role: DefaultModelRole.Moderation,
        modelType: AiModelTypeEnum.MODERATION,
        group: "types"
    }
];
function defaultModelDefinition(role) {
    return DEFAULT_MODEL_DEFINITIONS.find(function(item) {
        return item.role === role;
    });
}

function _array_like_to_array$4(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$3(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$3(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$3() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$3(arr, i) {
    return _array_with_holes$3(arr) || _iterable_to_array_limit$3(arr, i) || _unsupported_iterable_to_array$4(arr, i) || _non_iterable_rest$3();
}
function _unsupported_iterable_to_array$4(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$4(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$4(o, minLen);
}
var modelIdentitySchema = z$1.object({
    copilotId: z$1.string().uuid(),
    modelType: z$1.nativeEnum(AiModelTypeEnum),
    model: z$1.string().trim().min(1).max(512)
}).strict();
var modelBindingSchema = modelIdentitySchema.extend({
    options: z$1.record(z$1.union([
        z$1.string(),
        z$1.number().finite(),
        z$1.boolean(),
        z$1.null()
    ])).optional()
});
var roleDefaultInputSchema = z$1.discriminatedUnion("mode", [
    z$1.object({
        role: defaultModelRoleSchema,
        mode: z$1.literal("fixed"),
        binding: modelBindingSchema
    }).strict(),
    z$1.object({
        role: defaultModelRoleSchema,
        mode: z$1.literal("inherit")
    }).strict(),
    z$1.object({
        role: defaultModelRoleSchema,
        mode: z$1.literal("disabled")
    }).strict()
]);
var saveRoleDefaultsSchema = z$1.object({
    defaults: z$1.array(roleDefaultInputSchema).max(DEFAULT_MODEL_DEFINITIONS.length)
}).strict().refine(function(value) {
    return new Set(value.defaults.map(function(item) {
        return item.role;
    })).size === value.defaults.length;
});
function modelIdentityKey(model) {
    return JSON.stringify([
        model.modelType,
        model.model
    ]);
}
function sameModelIdentity(left, right) {
    return !!left && !!right && left.copilotId === right.copilotId && left.modelType === right.modelType && left.model === right.model;
}
/** Switching uses the target schema only; missing rules never preserve arbitrary old keys. */ function transitionModelParameters(previous, rules, policy) {
    var options = {};
    var missing = [];
    var changes = [];
    var names = new Set(rules.map(function(rule) {
        return rule.name;
    }).filter(Boolean));
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = Object.entries(previous !== null && previous !== void 0 ? previous : {})[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var _step_value = _sliced_to_array$3(_step.value, 2), name = _step_value[0], before = _step_value[1];
            if (!names.has(name)) changes.push({
                name: name,
                before: before,
                after: undefined,
                action: "removed"
            });
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    var _iteratorNormalCompletion1 = true, _didIteratorError1 = false, _iteratorError1 = undefined;
    try {
        for(var _iterator1 = rules[Symbol.iterator](), _step1; !(_iteratorNormalCompletion1 = (_step1 = _iterator1.next()).done); _iteratorNormalCompletion1 = true){
            var rule = _step1.value;
            if (!rule.name) continue;
            var before1 = previous === null || previous === void 0 ? void 0 : previous[rule.name];
            // A cleared optional field must remain unset through JSON save/reopen.
            if (policy === "compatible" && before1 === null && !rule.required) {
                options[rule.name] = null;
                changes.push({
                    name: rule.name,
                    before: before1,
                    after: null,
                    action: "retained"
                });
                continue;
            }
            var compatible = policy === "compatible" && isValidParameter(before1, rule);
            var candidate = compatible ? before1 : normalizeModelParameterValue(rule.default, rule);
            if (isValidParameter(candidate, rule)) options[rule.name] = candidate;
            else if (rule.required) missing.push(rule.name);
            if (before1 !== undefined || options[rule.name] !== undefined) {
                changes.push({
                    name: rule.name,
                    before: before1,
                    after: options[rule.name],
                    action: compatible ? "retained" : "reset"
                });
            }
        }
    } catch (err) {
        _didIteratorError1 = true;
        _iteratorError1 = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion1 && _iterator1.return != null) {
                _iterator1.return();
            }
        } finally{
            if (_didIteratorError1) {
                throw _iteratorError1;
            }
        }
    }
    return {
        options: options,
        missing: missing,
        changes: changes
    };
}
function isValidParameter(value, rule) {
    var _rule_options;
    if (rule.type === ParameterType.INT || rule.type === ParameterType.FLOAT) {
        return typeof value === "number" && Number.isFinite(value) && (rule.type !== ParameterType.INT || Number.isInteger(value)) && (rule.min === undefined || value >= rule.min) && (rule.max === undefined || value <= rule.max);
    }
    if (rule.type === ParameterType.BOOLEAN) return typeof value === "boolean";
    return typeof value === "string" && (!((_rule_options = rule.options) === null || _rule_options === void 0 ? void 0 : _rule_options.length) || rule.options.includes(value));
}
/** Undefined is a legacy catalog; an empty array deliberately enables nothing. */ function isProviderModelEnabled(provider, model) {
    var _provider_options;
    var enabled = (_provider_options = provider.options) === null || _provider_options === void 0 ? void 0 : _provider_options.enabledModels;
    return enabled === undefined || enabled.some(function(item) {
        return item.model === model.model && item.modelType === model.modelType;
    });
}
var enabledModelsSchema = z$1.object({
    models: z$1.array(modelIdentitySchema.omit({
        copilotId: true
    })).max(2000)
}).strict().refine(function(value) {
    return new Set(value.models.map(modelIdentityKey)).size === value.models.length;
});

var llmIdentity = modelIdentitySchema.extend({
    modelType: z$1.literal(AiModelTypeEnum.LLM)
});
var modelReplacementScopeSchema = z$1.object({
    workspaceId: z$1.string().uuid().optional()
}).strict();
var modelReplacementSchema = z$1.object({
    source: llmIdentity,
    target: llmIdentity,
    policy: z$1.enum([
        "reset",
        "compatible"
    ]),
    workspaceId: z$1.string().uuid().optional()
}).strict().refine(function(value) {
    return value.source.copilotId !== value.target.copilotId || value.source.model !== value.target.model;
});
var executeModelReplacementSchema = z$1.object({
    input: modelReplacementSchema,
    selections: z$1.array(z$1.object({
        id: z$1.string().uuid(),
        revision: z$1.string().regex(/^[a-f0-9]{64}$/)
    }).strict()).min(1).max(100)
}).strict().refine(function(value) {
    return new Set(value.selections.map(function(item) {
        return item.id;
    })).size === value.selections.length;
});

var STATE_VARIABLE_HUMAN = "human";

var PermissionsEnum;
(function(PermissionsEnum) {
    PermissionsEnum["ANNOUNCEMENT_MANAGE"] = "ANNOUNCEMENT_MANAGE";
    PermissionsEnum["PROFILE_EDIT"] = "PROFILE_EDIT";
    PermissionsEnum["ADMIN_DASHBOARD_VIEW"] = "ADMIN_DASHBOARD_VIEW";
    PermissionsEnum["ORG_EMPLOYEES_VIEW"] = "ORG_EMPLOYEES_VIEW";
    PermissionsEnum["ORG_EMPLOYEES_EDIT"] = "ORG_EMPLOYEES_EDIT";
    PermissionsEnum["ORG_TAGS_EDIT"] = "ORG_TAGS_EDIT";
    PermissionsEnum["ORG_USERS_VIEW"] = "ORG_USERS_VIEW";
    PermissionsEnum["ORG_USERS_EDIT"] = "ORG_USERS_EDIT";
    PermissionsEnum["ORG_INVITE_VIEW"] = "ORG_INVITE_VIEW";
    PermissionsEnum["ORG_INVITE_EDIT"] = "ORG_INVITE_EDIT";
    PermissionsEnum["ALL_ORG_VIEW"] = "ALL_ORG_VIEW";
    PermissionsEnum["ALL_ORG_EDIT"] = "ALL_ORG_EDIT";
    PermissionsEnum["APPROVAL_POLICY_VIEW"] = "APPROVALS_POLICY_VIEW";
    PermissionsEnum["APPROVAL_POLICY_EDIT"] = "APPROVALS_POLICY_EDIT";
    PermissionsEnum["CHANGE_SELECTED_ORGANIZATION"] = "CHANGE_SELECTED_ORGANIZATION";
    PermissionsEnum["CHANGE_ROLES_PERMISSIONS"] = "CHANGE_ROLES_PERMISSIONS";
    PermissionsEnum["SUPER_ADMIN_EDIT"] = "SUPER_ADMIN_EDIT";
    PermissionsEnum["PUBLIC_PAGE_EDIT"] = "PUBLIC_PAGE_EDIT";
    PermissionsEnum["VIEW_ALL_EMAILS"] = "VIEW_ALL_EMAILS";
    PermissionsEnum["VIEW_ALL_EMAIL_TEMPLATES"] = "VIEW_ALL_EMAIL_TEMPLATES";
    PermissionsEnum["ORG_HELP_CENTER_EDIT"] = "ORG_HELP_CENTER_EDIT";
    PermissionsEnum["ORG_CONTACT_EDIT"] = "ORG_CONTACT_EDIT";
    PermissionsEnum["ORG_CONTACT_VIEW"] = "ORG_CONTACT_VIEW";
    PermissionsEnum["ORG_DEMO_EDIT"] = "ORG_DEMO_EDIT";
    PermissionsEnum["INTEGRATION_EDIT"] = "INTEGRATION_EDIT";
    PermissionsEnum["INTEGRATION_VIEW"] = "INTEGRATION_VIEW";
    PermissionsEnum["DATA_SOURCE_VIEW"] = "DATA_SOURCE_VIEW";
    PermissionsEnum["DATA_SOURCE_EDIT"] = "DATA_SOURCE_EDIT";
    PermissionsEnum["BUSINESS_AREA_VIEW"] = "BUSINESS_AREA_VIEW";
    PermissionsEnum["BUSINESS_AREA_MANAGE"] = "BUSINESS_AREA_MANAGE";
    PermissionsEnum["BUSINESS_AREA_ASSIGN"] = "BUSINESS_AREA_ASSIGN";
    PermissionsEnum["FILE_STORAGE_VIEW"] = "FILE_STORAGE_VIEW";
    PermissionsEnum["SMS_GATEWAY_VIEW"] = "SMS_GATEWAY_VIEW";
    PermissionsEnum["CUSTOM_SMTP_VIEW"] = "CUSTOM_SMTP_VIEW";
    PermissionsEnum["VIEW_ALL_ACCOUNTING_TEMPLATES"] = "VIEW_ALL_ACCOUNTING_TEMPLATES";
    PermissionsEnum["ACCESS_DELETE_ACCOUNT"] = "ACCESS_DELETE_ACCOUNT";
    PermissionsEnum["ACCESS_DELETE_ALL_DATA"] = "ACCESS_DELETE_ALL_DATA";
    PermissionsEnum["REFERRAL_VIEW"] = "REFERRAL_VIEW";
})(PermissionsEnum || (PermissionsEnum = {}));
var PermissionGroups = {
    //Permissions which can be given to any role
    GENERAL: [
        PermissionsEnum.PROFILE_EDIT,
        PermissionsEnum.ADMIN_DASHBOARD_VIEW,
        PermissionsEnum.ORG_INVITE_VIEW,
        PermissionsEnum.ORG_INVITE_EDIT,
        // PermissionsEnum.ORG_TAGS_EDIT,
        PermissionsEnum.VIEW_ALL_EMAILS,
        PermissionsEnum.VIEW_ALL_EMAIL_TEMPLATES,
        // PermissionsEnum.ORG_HELP_CENTER_EDIT,
        PermissionsEnum.INTEGRATION_EDIT,
        // PermissionsEnum.ORG_CONTACT_VIEW,
        PermissionsEnum.ORG_DEMO_EDIT,
        // PermissionsEnum.VIEW_ALL_ACCOUNTING_TEMPLATES,
        // AI
        AIPermissionsEnum.KNOWLEDGEBASE_EDIT,
        AIPermissionsEnum.COPILOT_VIEW,
        AIPermissionsEnum.COPILOT_EDIT,
        AIPermissionsEnum.MODEL_USAGE_MONITOR,
        AIPermissionsEnum.MEMBERSHIP_EDIT,
        AIPermissionsEnum.MEMBERSHIP_USE,
        AIPermissionsEnum.MODEL_ACCESS_REQUEST_VIEW,
        AIPermissionsEnum.MODEL_ACCESS_REQUEST_EDIT,
        AIPermissionsEnum.MODEL_GATEWAY_USE,
        AIPermissionsEnum.MODEL_GATEWAY_MANAGE,
        AIPermissionsEnum.BILLING_PRODUCT_EDIT,
        AIPermissionsEnum.BILLING_REFUND,
        AIPermissionsEnum.PAYMENT_PROVIDER_EDIT,
        AIPermissionsEnum.XPERT_VIEW,
        AIPermissionsEnum.XPERT_WORKSPACE_MANAGE,
        AIPermissionsEnum.XPERT_EDIT,
        AIPermissionsEnum.APPLICATION_USE,
        AIPermissionsEnum.APPLICATION_INSTALL,
        AIPermissionsEnum.XPERT_PROJECT_VIEW,
        AIPermissionsEnum.XPERT_PROJECT_CREATE,
        AIPermissionsEnum.XPERT_PROJECT_EDIT,
        AIPermissionsEnum.XPERT_PROJECT_MANAGE,
        AIPermissionsEnum.CHAT_VIEW,
        AIPermissionsEnum.EVOLUTION_VIEW,
        AIPermissionsEnum.EVOLUTION_MANAGE,
        // DataSource
        PermissionsEnum.DATA_SOURCE_VIEW,
        PermissionsEnum.DATA_SOURCE_EDIT,
        // Business Area
        PermissionsEnum.BUSINESS_AREA_VIEW,
        PermissionsEnum.BUSINESS_AREA_MANAGE,
        PermissionsEnum.BUSINESS_AREA_ASSIGN
    ],
    //Readonly permissions, are only enabled for admin role
    ADMINISTRATION: [
        PermissionsEnum.ANNOUNCEMENT_MANAGE,
        PermissionsEnum.ORG_USERS_VIEW,
        PermissionsEnum.ORG_USERS_EDIT,
        PermissionsEnum.ALL_ORG_VIEW,
        PermissionsEnum.ALL_ORG_EDIT,
        PermissionsEnum.CHANGE_SELECTED_ORGANIZATION,
        PermissionsEnum.CHANGE_ROLES_PERMISSIONS,
        PermissionsEnum.SUPER_ADMIN_EDIT,
        PermissionsEnum.INTEGRATION_VIEW,
        PermissionsEnum.ACCESS_DELETE_ACCOUNT,
        PermissionsEnum.ACCESS_DELETE_ALL_DATA,
        PermissionsEnum.REFERRAL_VIEW
    ]
};

function _array_like_to_array$3(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$3(arr);
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array$3(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array$3(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$3(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$3(o, minLen);
}
var modulePermissions = [
    {
        module: "ai",
        permissions: [
            AIPermissionsEnum.KNOWLEDGEBASE_EDIT,
            AIPermissionsEnum.COPILOT_VIEW,
            AIPermissionsEnum.COPILOT_EDIT,
            AIPermissionsEnum.MODEL_USAGE_MONITOR,
            AIPermissionsEnum.MODEL_ACCESS_REQUEST_VIEW,
            AIPermissionsEnum.MODEL_ACCESS_REQUEST_EDIT,
            AIPermissionsEnum.MODEL_GATEWAY_USE,
            AIPermissionsEnum.MODEL_GATEWAY_MANAGE,
            AIPermissionsEnum.XPERT_VIEW,
            AIPermissionsEnum.XPERT_WORKSPACE_MANAGE,
            AIPermissionsEnum.APPLICATION_USE,
            AIPermissionsEnum.APPLICATION_INSTALL,
            AIPermissionsEnum.XPERT_EDIT,
            AIPermissionsEnum.CHAT_VIEW,
            AIPermissionsEnum.EVOLUTION_VIEW,
            AIPermissionsEnum.EVOLUTION_MANAGE
        ]
    },
    {
        module: "projects",
        permissions: [
            AIPermissionsEnum.XPERT_PROJECT_VIEW,
            AIPermissionsEnum.XPERT_PROJECT_CREATE,
            AIPermissionsEnum.XPERT_PROJECT_EDIT,
            AIPermissionsEnum.XPERT_PROJECT_MANAGE
        ]
    },
    {
        module: "members",
        permissions: [
            PermissionsEnum.ANNOUNCEMENT_MANAGE,
            PermissionsEnum.ADMIN_DASHBOARD_VIEW,
            PermissionsEnum.ORG_INVITE_VIEW,
            PermissionsEnum.ORG_INVITE_EDIT,
            PermissionsEnum.ORG_DEMO_EDIT,
            PermissionsEnum.ORG_USERS_VIEW,
            PermissionsEnum.ORG_USERS_EDIT,
            PermissionsEnum.ALL_ORG_VIEW,
            PermissionsEnum.ALL_ORG_EDIT,
            PermissionsEnum.CHANGE_SELECTED_ORGANIZATION,
            PermissionsEnum.CHANGE_ROLES_PERMISSIONS,
            PermissionsEnum.SUPER_ADMIN_EDIT,
            PermissionsEnum.ACCESS_DELETE_ACCOUNT,
            PermissionsEnum.ACCESS_DELETE_ALL_DATA,
            PermissionsEnum.REFERRAL_VIEW
        ]
    },
    {
        module: "billing",
        permissions: [
            AIPermissionsEnum.MEMBERSHIP_EDIT,
            AIPermissionsEnum.MEMBERSHIP_USE,
            AIPermissionsEnum.BILLING_PRODUCT_EDIT,
            AIPermissionsEnum.BILLING_REFUND,
            AIPermissionsEnum.PAYMENT_PROVIDER_EDIT
        ]
    },
    {
        module: "data",
        permissions: [
            PermissionsEnum.VIEW_ALL_EMAILS,
            PermissionsEnum.VIEW_ALL_EMAIL_TEMPLATES,
            PermissionsEnum.INTEGRATION_EDIT,
            PermissionsEnum.INTEGRATION_VIEW,
            PermissionsEnum.DATA_SOURCE_VIEW,
            PermissionsEnum.DATA_SOURCE_EDIT,
            PermissionsEnum.BUSINESS_AREA_VIEW,
            PermissionsEnum.BUSINESS_AREA_MANAGE,
            PermissionsEnum.BUSINESS_AREA_ASSIGN
        ]
    },
    {
        module: "personal",
        permissions: [
            PermissionsEnum.PROFILE_EDIT
        ]
    }
];
var ROLE_PERMISSION_MODULES = new Map(modulePermissions.flatMap(function(param) {
    var module = param.module, permissions = param.permissions;
    return permissions.map(function(permission) {
        return [
            permission,
            module
        ];
    });
}));
var DEPRECATED_ROLE_PERMISSIONS = [
    PermissionsEnum.ADMIN_DASHBOARD_VIEW,
    PermissionsEnum.VIEW_ALL_EMAILS,
    PermissionsEnum.ORG_DEMO_EDIT,
    AIPermissionsEnum.COPILOT_VIEW,
    PermissionsEnum.CHANGE_SELECTED_ORGANIZATION,
    PermissionsEnum.ACCESS_DELETE_ACCOUNT
];
var UNWIRED_AI_PERMISSIONS = [
    AIPermissionsEnum.BILLING_PRODUCT_EDIT,
    AIPermissionsEnum.BILLING_REFUND,
    AIPermissionsEnum.PAYMENT_PROVIDER_EDIT
];
/** Complete UI/documentation catalog; presence here never grants access or implies endpoint enforcement. */ var ROLE_PERMISSION_CATALOG = _to_consumable_array(Object.values(PermissionsEnum)).concat(_to_consumable_array(Object.values(AIPermissionsEnum))).map(function(permission) {
    var _ROLE_PERMISSION_MODULES_get;
    return {
        permission: permission,
        module: (_ROLE_PERMISSION_MODULES_get = ROLE_PERMISSION_MODULES.get(permission)) !== null && _ROLE_PERMISSION_MODULES_get !== void 0 ? _ROLE_PERMISSION_MODULES_get : "other",
        deprecated: DEPRECATED_ROLE_PERMISSIONS.includes(permission),
        configurable: _to_consumable_array(PermissionGroups.GENERAL).concat(_to_consumable_array(PermissionGroups.ADMINISTRATION)).some(function(code) {
            return code === permission;
        }),
        contractOnly: UNWIRED_AI_PERMISSIONS.includes(permission)
    };
});

function getTagTargets(tag) {
    var _tag_targets;
    return ((_tag_targets = tag.targets) === null || _tag_targets === void 0 ? void 0 : _tag_targets.length) ? tag.targets : tag.category ? [
        tag.category
    ] : [];
}
var TagCategoryEnum;
(function(TagCategoryEnum) {
    TagCategoryEnum["INDICATOR"] = "indicator";
    TagCategoryEnum["STORY"] = "story";
    TagCategoryEnum["TOOLSET"] = "toolset";
    TagCategoryEnum["XPERT"] = "xpert";
})(TagCategoryEnum || (TagCategoryEnum = {}));
var TAG_TARGETS = [
    TagCategoryEnum.XPERT,
    "knowledgebase",
    "prompt_workflow",
    TagCategoryEnum.TOOLSET,
    TagCategoryEnum.INDICATOR,
    TagCategoryEnum.STORY,
    "people",
    "integration"
];

var DEFAULT_TENANT = "Default Tenant";

var TranslationLanguageMap = {
    "zh-CN": "zh",
    "zh-Hans": "zh"
};
function mapTranslationLanguage(languageCode) {
    return TranslationLanguageMap[languageCode] || languageCode;
}

/**
 * Built-in permission presets. Effective access still requires enabled permissions
 * and resource authorization; role names alone do not grant access.
 */ var RolesEnum;
(function(RolesEnum) {
    /** Platform administration, including management of other administrators. */ RolesEnum["SUPER_ADMIN"] = "SUPER_ADMIN";
    /** Tenant/organization administration, including members, billing and AI resources. */ RolesEnum["ADMIN"] = "ADMIN";
    /** AI authoring: configure models, build Assistants and install applications. */ RolesEnum["AI_BUILDER"] = "AI_BUILDER";
    /** Consume authorized chat and read permitted resources without authoring privileges. */ RolesEnum["VIEWER"] = "VIEWER";
    /**
     * Managed application consumer: use assigned apps, published Assistants and projects.
     * No model-provider configuration, Assistant authoring or installation by default.
     */ RolesEnum["APP_USER"] = "APP_USER";
    /**
     * Non-interactive service identity for application initialization and upgrades.
     * Uses scoped installation/authoring permissions and normal resource authorization.
     */ RolesEnum["APPLICATION_PROVISIONER"] = "APPLICATION_PROVISIONER";
    /** Platform trial with authoring privileges; membership entitlements define trial limits. */ RolesEnum["TRIAL"] = "TRIAL";
})(RolesEnum || (RolesEnum = {}));
var DEFAULT_SYSTEM_ROLES = [
    RolesEnum.SUPER_ADMIN,
    RolesEnum.ADMIN,
    RolesEnum.TRIAL,
    RolesEnum.AI_BUILDER,
    RolesEnum.VIEWER,
    RolesEnum.APP_USER,
    RolesEnum.APPLICATION_PROVISIONER
];

var USER_ORGANIZATION_ENTRY_GUIDE_CLAWXPERT = "clawxpert";
function isUserOrganizationEntryGuideKey(value) {
    return value === USER_ORGANIZATION_ENTRY_GUIDE_CLAWXPERT;
}

var UserGroupManagedByEnum;
(function(UserGroupManagedByEnum) {
    UserGroupManagedByEnum["XPERT_SHARING"] = "xpert-sharing";
    UserGroupManagedByEnum["XPERT_MARKETPLACE"] = "xpert-marketplace";
})(UserGroupManagedByEnum || (UserGroupManagedByEnum = {}));
var UserGroupManagedEntityTypeEnum;
(function(UserGroupManagedEntityTypeEnum) {
    UserGroupManagedEntityTypeEnum["XPERT"] = "xpert";
})(UserGroupManagedEntityTypeEnum || (UserGroupManagedEntityTypeEnum = {}));

var UserType;
(function(UserType) {
    UserType["USER"] = "user";
    UserType["COMMUNICATION"] = "communication"; // Backend communication & integration account
})(UserType || (UserType = {}));
/**
 * Browser http header `Language`
 */ var LanguagesEnum;
(function(LanguagesEnum) {
    LanguagesEnum["Chinese"] = "zh-CN";
    LanguagesEnum["SimplifiedChinese"] = "zh-Hans";
    LanguagesEnum["TraditionalChinese"] = "zh-Hant";
    LanguagesEnum["English"] = "en";
})(LanguagesEnum || (LanguagesEnum = {}));
var LanguagesMap = {
    "zh-CN": LanguagesEnum.SimplifiedChinese,
    "zh-Hans": LanguagesEnum.SimplifiedChinese,
    zh: LanguagesEnum.SimplifiedChinese
};
// export enum ComponentLayoutStyleEnum {
// 	CARDS_GRID = 'CARDS_GRID',
// 	TABLE = 'TABLE'
// }
var ProviderEnum;
(function(ProviderEnum) {
    ProviderEnum["GOOGLE"] = "google";
    ProviderEnum["FACEBOOK"] = "facebook";
})(ProviderEnum || (ProviderEnum = {}));

var SMTPSecureEnum;
(function(SMTPSecureEnum) {
    SMTPSecureEnum["TRUE"] = "True";
    SMTPSecureEnum["FALSE"] = "False";
})(SMTPSecureEnum || (SMTPSecureEnum = {}));

var AuthenticationEnum;
(function(AuthenticationEnum) {
    AuthenticationEnum["NONE"] = "NONE";
    AuthenticationEnum["BASIC"] = "BASIC";
})(AuthenticationEnum || (AuthenticationEnum = {}));
var DataSourceTypeEnum;
(function(DataSourceTypeEnum) {
    DataSourceTypeEnum["NONE"] = "NONE";
})(DataSourceTypeEnum || (DataSourceTypeEnum = {}));

function _array_like_to_array$2(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$2(arr) {
    if (Array.isArray(arr)) return arr;
}
function _define_property$3(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit$2(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$2() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$3(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$3(target, key, source[key]);
        });
    }
    return target;
}
function _sliced_to_array$2(arr, i) {
    return _array_with_holes$2(arr) || _iterable_to_array_limit$2(arr, i) || _unsupported_iterable_to_array$2(arr, i) || _non_iterable_rest$2();
}
function _unsupported_iterable_to_array$2(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$2(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$2(o, minLen);
}
// Public diagnostics are authored separately from driver errors. This is defense in depth,
// not a sanitizer for arbitrary logs: producers must never copy raw exceptions into message.
var privateText = /[\u0000-\u001f\u007f]|(?:https?|jdbc|postgres(?:ql)?|mysql):|\b(?:password|passwd|pwd|secret|token|authorization|cookie|api[_-]?key)\s*[:=]|\bBearer\s|-----BEGIN|\b(?:SELECT|WITH)\b[\s\S]*\bFROM\b|\b(?:INSERT\s+INTO|UPDATE\s+\S+\s+SET|DELETE\s+FROM)\b|<\/?[a-z][^>]*>|(?:\/Users\/|\/home\/|\/private\/|[A-Z]:\\)|\bat\s+\S+\s*\(/i;
var publicText = z.string().trim().min(1).max(600).refine(function(value) {
    return !privateText.test(value);
});
var reference = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/);
/** Portable HTTP/provider failure contract. No arbitrary details, cause, query or connection fields. */ var analyticsDiagnosticSchema = z.object({
    schema: z.literal("xpert.analytics.diagnostic"),
    version: z.literal(1),
    code: z.string().regex(/^[A-Z][A-Z0-9_-]{2,79}$/),
    stage: z.enum([
        "request",
        "source",
        "validation",
        "authorization",
        "execution",
        "result",
        "dependency"
    ]),
    message: publicText,
    retryable: z.boolean(),
    upstreamExecutionId: reference.optional(),
    auditRef: reference.optional()
}).strict().refine(function(value) {
    return !value.retryable || value.stage === "execution" || value.stage === "dependency";
});
/** Invalid provider diagnostics fail closed; never return Zod errors containing received input. */ function parseAnalyticsDiagnostic(value) {
    try {
        if (!value || typeof value !== "object") return undefined;
        var properties = Object.getOwnPropertyDescriptors(value);
        if (Object.values(properties).some(function(property) {
            return !("value" in property);
        })) return undefined;
        var parsed = analyticsDiagnosticSchema.safeParse(Object.fromEntries(Object.entries(properties).map(function(param) {
            var _param = _sliced_to_array$2(param, 2), key = _param[0], property = _param[1];
            return [
                key,
                property.value
            ];
        })));
        if (!parsed.success) return undefined;
        var _parsed_data = parsed.data, schema = _parsed_data.schema, version = _parsed_data.version, code = _parsed_data.code, stage = _parsed_data.stage, message = _parsed_data.message, retryable = _parsed_data.retryable, upstreamExecutionId = _parsed_data.upstreamExecutionId, auditRef = _parsed_data.auditRef;
        return _object_spread$3({
            schema: schema,
            version: version,
            code: code,
            stage: stage,
            message: message,
            retryable: retryable
        }, upstreamExecutionId ? {
            upstreamExecutionId: upstreamExecutionId
        } : {}, auditRef ? {
            auditRef: auditRef
        } : {});
    } catch (e) {
        return undefined;
    }
}

var DataSourceSyntaxEnum;
(function(DataSourceSyntaxEnum) {
    DataSourceSyntaxEnum["SQL"] = "sql";
    DataSourceSyntaxEnum["MDX"] = "mdx";
})(DataSourceSyntaxEnum || (DataSourceSyntaxEnum = {}));
var DataSourceProtocolEnum;
(function(DataSourceProtocolEnum) {
    DataSourceProtocolEnum["SQL"] = "sql";
    DataSourceProtocolEnum["XMLA"] = "xmla";
})(DataSourceProtocolEnum || (DataSourceProtocolEnum = {}));

/**
 * @deprecated use Plugins instead
 */ var IntegrationEnum;
(function(IntegrationEnum) {
    IntegrationEnum["UPWORK"] = "Upwork";
    IntegrationEnum["HUBSTAFF"] = "Hubstaff";
    IntegrationEnum["LARK"] = "Lark";
    IntegrationEnum["DINGTALK"] = "DingTalk";
    IntegrationEnum["WECOM"] = "WeCom";
    IntegrationEnum["FIRECRAWL"] = "firecrawl";
    IntegrationEnum["KNOWLEDGEBASE"] = "knowledgebase";
    IntegrationEnum["GITHUB"] = "github";
    IntegrationEnum["RAGFlow"] = "ragflow";
    IntegrationEnum["Dify"] = "dify";
    IntegrationEnum["FastGPT"] = "fastgpt";
})(IntegrationEnum || (IntegrationEnum = {}));
var IntegrationFeatureEnum;
(function(IntegrationFeatureEnum) {
    IntegrationFeatureEnum["KNOWLEDGE"] = "knowledge";
    IntegrationFeatureEnum["AGENT"] = "agent";
    IntegrationFeatureEnum["SSO"] = "sso";
})(IntegrationFeatureEnum || (IntegrationFeatureEnum = {}));
var IntegrationFilterEnum;
(function(IntegrationFilterEnum) {
    IntegrationFilterEnum["ALL"] = "All";
    IntegrationFilterEnum["FREE"] = "Free";
    IntegrationFilterEnum["PAID"] = "Paid";
})(IntegrationFilterEnum || (IntegrationFilterEnum = {}));
var DEFAULT_INTEGRATION_PAID_FILTERS = [
    {
        label: IntegrationFilterEnum.ALL,
        value: "all"
    },
    {
        label: IntegrationFilterEnum.FREE,
        value: "false"
    },
    {
        label: IntegrationFilterEnum.PAID,
        value: "true"
    }
];

var InviteStatusEnum;
(function(InviteStatusEnum) {
    InviteStatusEnum["INVITED"] = "INVITED";
    InviteStatusEnum["ACCEPTED"] = "ACCEPTED";
})(InviteStatusEnum || (InviteStatusEnum = {}));
var InvitationTypeEnum;
(function(InvitationTypeEnum) {
    InvitationTypeEnum["USER"] = "USER";
    InvitationTypeEnum["EMPLOYEE"] = "EMPLOYEE";
    InvitationTypeEnum["CANDIDATE"] = "CANDIDATE";
})(InvitationTypeEnum || (InvitationTypeEnum = {}));
var InvitationExpirationEnum;
(function(InvitationExpirationEnum) {
    InvitationExpirationEnum[InvitationExpirationEnum["DAY"] = 1] = "DAY";
    InvitationExpirationEnum[InvitationExpirationEnum["WEEK"] = 7] = "WEEK";
    InvitationExpirationEnum[InvitationExpirationEnum["TWO_WEEK"] = 14] = "TWO_WEEK";
    InvitationExpirationEnum[InvitationExpirationEnum["MONTH"] = 30] = "MONTH";
    InvitationExpirationEnum["NEVER"] = "Never";
})(InvitationExpirationEnum || (InvitationExpirationEnum = {}));

var TaskListTypeEnum;
(function(TaskListTypeEnum) {
    TaskListTypeEnum["GRID"] = "GRID";
    TaskListTypeEnum["SPRINT"] = "SPRINT";
})(TaskListTypeEnum || (TaskListTypeEnum = {}));
var OrganizationProjectBudgetTypeEnum;
(function(OrganizationProjectBudgetTypeEnum) {
    OrganizationProjectBudgetTypeEnum["HOURS"] = "hours";
    OrganizationProjectBudgetTypeEnum["COST"] = "cost";
})(OrganizationProjectBudgetTypeEnum || (OrganizationProjectBudgetTypeEnum = {}));

/** Immutable authorization source; live access is rechecked on every delegated request. */ var clientSecretGrantSourceSchema = z$1.discriminatedUnion("kind", [
    z$1.object({
        kind: z$1.literal("assistant")
    }).strict(),
    z$1.object({
        kind: z$1.literal("project"),
        projectId: z$1.string().min(1)
    }).strict(),
    z$1.object({
        kind: z$1.literal("conversation"),
        conversationId: z$1.string().min(1),
        requesterXpertId: z$1.string().min(1)
    }).strict()
]);
/**
 * Selects how an opaque client secret is authorized and how entityId is
 * interpreted. createdById alone does not distinguish
 * an API-key grant, a delegated user session, or a public assistant session.
 */ var SecretTokenBindingType;
(function(SecretTokenBindingType) {
    /** entityId is an ApiKey id and the request runs as that API principal. */ SecretTokenBindingType["API_KEY"] = "api_key";
    /**
     * entityId is the only Xpert this session may access; createdById is loaded
     * as the acting business user for the interactive ChatKit run.
     */ SecretTokenBindingType["USER_XPERT"] = "user_xpert";
    /**
     * entityId is one conversation, initially a group. createdById is the real
     * authenticated human. This grant never authorizes unrelated conversations,
     * direct Assistant APIs or session issuance; live domain access still applies.
     */ SecretTokenBindingType["USER_CONVERSATION"] = "user_conversation";
    /**
     * entityId is the only Xpert this verified enterprise identity may access;
     * createdById is the AccountBinding-resolved Xpert user.
     */ SecretTokenBindingType["ENTERPRISE_XPERT"] = "enterprise_xpert";
    /** entityId is a public Xpert id and public-app access rules apply. */ SecretTokenBindingType["PUBLIC_XPERT"] = "public_xpert";
})(SecretTokenBindingType || (SecretTokenBindingType = {}));

var Visibility;
(function(Visibility) {
    Visibility["Public"] = "public";
    Visibility["Internal"] = "internal";
    Visibility["Secret"] = "secret";
    Visibility["Private"] = "private";
})(Visibility || (Visibility = {}));

var RequestScopeLevel;
(function(RequestScopeLevel) {
    RequestScopeLevel["TENANT"] = "tenant";
    RequestScopeLevel["ORGANIZATION"] = "organization";
})(RequestScopeLevel || (RequestScopeLevel = {}));

/**
 * Transform GitHub API installation data to our simplified format
 */ var transformInstallation = function(installation) {
    if (!installation.account) {
        throw new Error("Installation account is null");
    }
    // Handle both User and Organization account types
    var accountName;
    if ("login" in installation.account && installation.account.login) {
        accountName = installation.account.login;
    } else if ("slug" in installation.account && installation.account.slug) {
        accountName = installation.account.slug;
    } else if ("name" in installation.account && installation.account.name) {
        accountName = installation.account.name;
    } else {
        accountName = "Unknown";
    }
    var accountType = installation.target_type;
    return {
        id: installation.id,
        accountName: accountName,
        accountType: accountType,
        avatarUrl: installation.account.avatar_url
    };
};

/**
 * @deprecated use plugin
 */ var IntegrationLarkProvider = {
    name: IntegrationEnum.LARK,
    label: {
        en_US: "Lark",
        zh_Hans: "飞书"
    },
    avatar: "lark.png",
    webhook: true,
    schema: {
        type: "object",
        properties: {
            isLark: {
                type: "boolean",
                title: {
                    en_US: "Is Lark",
                    zh_Hans: "国际版"
                }
            },
            appId: {
                type: "string",
                title: "App ID"
            },
            appSecret: {
                type: "string",
                title: "App Secret"
            },
            verificationToken: {
                type: "string",
                title: "Verification Token"
            },
            encryptKey: {
                type: "string",
                title: {
                    en_US: "Encrypt Key"
                }
            },
            xpertId: {
                type: "remote-select",
                title: {
                    en_US: "Xpert",
                    zh_Hans: "数字专家"
                },
                placeholder: {
                    en_US: "Choose a corresponding digital expert",
                    zh_Hans: "选择一个对应的数字专家"
                },
                selectUrl: "/api/xpert/select-options"
            },
            preferLanguage: {
                type: "select",
                title: {
                    en_US: "Preferred Language",
                    zh_Hans: "首选语言"
                },
                options: [
                    {
                        value: "en",
                        label: {
                            en_US: "English",
                            zh_Hans: "英语"
                        }
                    },
                    {
                        value: "zh",
                        label: {
                            en_US: "Chinese",
                            zh_Hans: "中文"
                        }
                    }
                ]
            }
        },
        required: [
            "appId",
            "appSecret"
        ],
        secret: [
            "appSecret",
            "verificationToken",
            "encryptKey"
        ]
    }
};

/** @deprecated Discover providers through the host integration registry/API. */ var INTEGRATION_PROVIDERS = {};

/**
 * Optional request header used by third-party callers to explicitly set the
 * business user represented by the current request context.
 */ var API_PRINCIPAL_USER_ID_HEADER = "x-principal-user-id";
/**
 * Stable binding kinds used to resolve personal or resource credentials.
 */ var ApiKeyBindingType;
(function(ApiKeyBindingType) {
    /** A fixed human owner, without an Assistant or workspace audience. */ ApiKeyBindingType["USER"] = "user";
    ApiKeyBindingType["ASSISTANT"] = "assistant";
    ApiKeyBindingType["WORKSPACE"] = "workspace";
    ApiKeyBindingType["INTEGRATION"] = "integration";
    ApiKeyBindingType["CLIENT"] = "client";
    /**
     * @deprecated legacy type, do not use for new keys. Will be resolved as assistant for backward compatibility.
     */ ApiKeyBindingType["KNOWLEDGEBASE"] = "knowledgebase";
})(ApiKeyBindingType || (ApiKeyBindingType = {}));

/** A personal credential uses existing API-key endpoints as its human owner, subject to their current permissions. */ var PERSONAL_API_KEY_LIFETIMES = [
    "30",
    "90",
    "365",
    "never"
];

/**
 * Authoring View -> signed-in host command for source grant management.
 * The host verifies the declared View, Assistant and source Project before forwarding the action.
 * Embedded/group credentials never become source-management authority and no login token is returned to the View.
 */ var ARTIFACT_USE_GRANT_MANAGE_COMMAND = "artifact.use-grants.manage";

/** Host-owned opening avoids inheriting a remote component's iframe sandbox. */ var ARTIFACT_PRESENTATION_OPEN_COMMAND = "artifact.presentation.open";

var BusinessType;
(function(BusinessType) {
    BusinessType["SEMANTIC_MODEL"] = "SEMANTIC_MODEL";
    BusinessType["STORY"] = "STORY";
    BusinessType["INDICATOR"] = "INDICATOR";
})(BusinessType || (BusinessType = {}));

function _array_like_to_array$1(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$1(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit$1(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$1() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array$1(arr, i) {
    return _array_with_holes$1(arr) || _iterable_to_array_limit$1(arr, i) || _unsupported_iterable_to_array$1(arr, i) || _non_iterable_rest$1();
}
function _unsupported_iterable_to_array$1(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$1(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$1(o, minLen);
}
var ScheduleTaskStatus;
(function(ScheduleTaskStatus) {
    ScheduleTaskStatus["PAUSED"] = "paused";
    ScheduleTaskStatus["ARCHIVED"] = "archived";
    ScheduleTaskStatus["SCHEDULED"] = "scheduled";
})(ScheduleTaskStatus || (ScheduleTaskStatus = {}));
var TaskFrequency;
(function(TaskFrequency) {
    TaskFrequency["Once"] = "Once";
    TaskFrequency["Daily"] = "Daily";
    TaskFrequency["Weekly"] = "Weekly";
    TaskFrequency["Monthly"] = "Monthly";
    TaskFrequency["Yearly"] = "Yearly";
})(TaskFrequency || (TaskFrequency = {}));
/**
 * Generate cron expression: Minutes Hour Day Month Week
 *
 * @param schedule
 * @returns
 */ function generateCronExpression(schedule) {
    if (!schedule.time) throw new Error("Time is required for scheduling");
    var _schedule_time_split = _sliced_to_array$1(schedule.time.split(":"), 2), hourStr = _schedule_time_split[0], minuteStr = _schedule_time_split[1];
    var hour = parseInt(hourStr, 10);
    var minute = parseInt(minuteStr, 10);
    if (isNaN(hour) || isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        throw new Error("Invalid time format. Expected HH:mm with valid hour and minute.");
    }
    switch(schedule.frequency){
        case TaskFrequency.Once:
            {
                if (!schedule.date) throw new Error("Date is required for Once schedule");
                var date = new Date(schedule.date);
                // if (isNaN(date.getTime())) throw new Error('Invalid date format for Once schedule');
                return "".concat(minute, " ").concat(hour, " ").concat(date.getDate(), " ").concat(date.getMonth() + 1, " *");
            }
        case TaskFrequency.Daily:
            return "".concat(minute, " ").concat(hour, " * * *");
        case TaskFrequency.Weekly:
            if (schedule.dayOfWeek === undefined || schedule.dayOfWeek < 0 || schedule.dayOfWeek > 6) throw new Error("Valid dayOfWeek (0-6) is required for Weekly schedule");
            return "".concat(minute, " ").concat(hour, " * * ").concat(schedule.dayOfWeek);
        case TaskFrequency.Monthly:
            if (!schedule.dayOfMonth || schedule.dayOfMonth < 1 || schedule.dayOfMonth > 31) throw new Error("Valid dayOfMonth (1-31) is required for Monthly schedule");
            return "".concat(minute, " ").concat(hour, " ").concat(schedule.dayOfMonth, " * *");
        case TaskFrequency.Yearly:
            {
                if (!schedule.date) throw new Error("Date is required for Yearly schedule");
                var date1 = new Date(schedule.date);
                // if (isNaN(date.getTime())) throw new Error('Invalid date format for Yearly schedule');
                return "".concat(minute, " ").concat(hour, " ").concat(date1.getDate(), " ").concat(date1.getMonth() + 1, " *");
            }
        default:
            throw new Error("Unsupported frequency: ".concat(schedule.frequency));
    }
}

var InterruptMessageType;
(function(InterruptMessageType) {
    InterruptMessageType["SlidesTemplate"] = "slides_template";
    InterruptMessageType["SwitchGitHubRepository"] = "switch_github_repository";
    InterruptMessageType["Select"] = "select";
})(InterruptMessageType || (InterruptMessageType = {}));

var XPERT_REMOTE_COMPONENT_INVOKE_CLIENT_COMMAND_MESSAGE_TYPE = "invokeClientCommand";
var ASSISTANT_CHAT_SEND_MESSAGE_COMMAND = "assistant.chat.send_message";
/** Append text selections to the current draft without sending or replacing it. */ var ASSISTANT_COMPOSER_APPEND_REFERENCES_COMMAND = "assistant.composer.append_references";
/** Append editable context to the current composer. Never starts a run or changes thread. */ var ASSISTANT_COMPOSER_INSERT_COMMAND = "assistant.composer.insert";
var ASSISTANT_CONTEXT_SET_COMMAND = "assistant.context.set";
var WORKBENCH_FILE_OPEN_COMMAND = "workbench.file.open";
var WORKBENCH_NAVIGATION_OPEN_COMMAND = "workbench.navigation.open";
var WORKBENCH_AGENT_EVOLUTION_TARGET = "agent-evolution.target";
var WORKBENCH_AGENT_EVOLUTION_CHANGE_TARGET = "agent-evolution.change";
var WORKBENCH_ASSISTANT_CONVERSATION_TARGET = "assistant.conversation";
/** Locate a public message in the currently open group; never opens an Assistant's private runtime. */ var WORKBENCH_GROUP_MESSAGE_TARGET = "group.message";
/** Inspect an exact execution; embedded clients may open it without changing the active conversation. */ var WORKBENCH_ASSISTANT_EXECUTION_TARGET = "assistant.execution";
/** Opens the current Assistant inside a Project-scoped workbench route. */ var WORKBENCH_ASSISTANT_PROJECT_TARGET = "assistant.project";
var WORKBENCH_EXTENSION_VIEW_TARGET = "workbench.view";
var WORKBENCH_KNOWLEDGEBASE_DOCUMENTS_TARGET = "knowledgebase.documents";
/** Resolve the Project's application entry through its registered type and current access checks. */ var WORKBENCH_PROJECT_APPLICATION_TARGET = "project.application";
/** Open full Project pipeline management in the configured platform. */ var WORKBENCH_PROJECT_PIPELINES_TARGET = "project.pipelines";
/** Host-owned browser persistence. Plugins never choose an account/storage namespace. */ var WORKBENCH_CONTENT_DRAFT_COMMAND = "workbench.content.draft";

// Preserve existing imports while client-command contracts live in their own module.
var XPERT_VIEW_PROJECT_ID_HEADER = "x-xpert-view-project-id";
var XPERT_VIEW_CONVERSATION_ID_HEADER = "x-xpert-view-conversation-id";
var ASSISTANT_CITATION_OPEN_EVENT = "assistant.citation.open";
var KNOWLEDGEBASE_OPEN_CITATION_EFFECT = "knowledgebase.open_citation";

var AGENT_PROFILE_TABS_SLOT = "agent.profile.tabs";

/** Assistant Workbench slot; openMode controls initial tab opening separately. */ var AGENT_WORKBENCH_SLOT = "agent.workbench";
/** Legacy plugin declarations and client requests; normalized to AGENT_WORKBENCH_SLOT by the host. */ var LEGACY_AGENT_WORKBENCH_SLOTS = [
    "agent.workbench.fixed",
    "agent.workbench.main"
];
/** Platform-provided navigation, available without Assistant middleware. */ var CONVERSATION_MAP_FEATURE = "platform.conversation-map";

/** Live-only UI request. Project scope is mandatory; history playback must not reopen Views. */ function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _define_property$2(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$2(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$2(target, key, source[key]);
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
var WORKBENCH_VIEW_OPEN_EVENT = "workbench.view.open";
/**
 * Parse the public lg.chat.event shape and paired replay metadata, keeping arbitrary logs out of navigation.
 * Returns null for invalid payloads. Shape validation does not perform access, active-scope or freshness checks.
 */ function parseWorkbenchViewOpenEvent(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || !("type" in value) || value.type !== WORKBENCH_VIEW_OPEN_EVENT || !("viewKey" in value) || typeof value.viewKey !== "string" || !value.viewKey.trim() || !("projectId" in value) || typeof value.projectId !== "string" || !value.projectId.trim()) return null;
    if ("requestId" in value && (typeof value.requestId !== "string" || !value.requestId.trim())) return null;
    if ("issuedAt" in value && (typeof value.issuedAt !== "number" || !Number.isSafeInteger(value.issuedAt) || value.issuedAt <= 0)) return null;
    if ("requestId" in value !== "issuedAt" in value) return null;
    if ("conversationId" in value && typeof value.conversationId !== "string") return null;
    if ("selectionId" in value && typeof value.selectionId !== "string") return null;
    var parameters = {};
    if ("parameters" in value) {
        if (!value.parameters || typeof value.parameters !== "object" || Array.isArray(value.parameters)) return null;
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = Object.entries(value.parameters)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var _step_value = _sliced_to_array(_step.value, 2), key = _step_value[0], item = _step_value[1];
                if (isViewScalar(item)) parameters[key] = item;
                else if (Array.isArray(item) && item.every(isViewScalar)) parameters[key] = item;
                else return null;
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    }
    return _object_spread$2({
        type: WORKBENCH_VIEW_OPEN_EVENT,
        viewKey: value.viewKey,
        projectId: value.projectId
    }, "requestId" in value && "issuedAt" in value ? {
        requestId: value.requestId,
        issuedAt: value.issuedAt
    } : {}, "conversationId" in value ? {
        conversationId: value.conversationId
    } : {}, "selectionId" in value ? {
        selectionId: value.selectionId
    } : {}, "parameters" in value ? {
        parameters: parameters
    } : {});
}
function isViewScalar(value) {
    return value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value);
}

function _define_property$1(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread$1(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$1(target, key, source[key]);
        });
    }
    return target;
}
var authorizationFields = {
    authMethodId: z.string().trim().min(1).max(128).optional(),
    integrationId: z.string().uuid().optional()
};
var hasIntegrationMethod = function(value) {
    return !value.integrationId || !!value.authMethodId;
};
/** An integration reference must name the Connector authentication method that consumes it. */ var workspaceConnectorAuthorizationSchema = z.object(authorizationFields).strict().refine(hasIntegrationMethod);
/** Intent only: the host resolves workspace identity, permissions and available Connector definitions. */ var workspaceConnectorConnectPayloadSchema = z.object(_object_spread$1({
    provider: z.string().regex(/^[a-z][a-z0-9_-]{0,63}$/)
}, authorizationFields)).strict().refine(hasIntegrationMethod);

var RUNTIME_RESTART_CONFIRMATION = "RESTART";
/** Terminal transport interruption; it does not indicate that the background task completed or failed. */ var RUNTIME_STREAM_INTERRUPTED_EVENT = "runtime-interrupted";

function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
/** Runtime-owned activity semantics. Display names and model prose are never classifiers. */ var trailActivityKindSchema = z.enum([
    "task",
    "explore",
    "change",
    "verify",
    "answer",
    "other"
]);
var trailStatusSchema = z.enum([
    "running",
    "success",
    "error",
    "pending",
    "waiting",
    "cancelling",
    "idle",
    "interrupted",
    "unknown"
]);
var anchor = {
    messageId: z.string().optional(),
    threadId: z.string().optional(),
    executionId: z.string().optional()
};
var trailStepSchema = z.object(_object_spread_props(_object_spread({
    id: z.string(),
    laneId: z.string(),
    kind: z.enum([
        "turn",
        "tool",
        "message"
    ]),
    activity: trailActivityKindSchema,
    title: z.string(),
    status: trailStatusSchema,
    order: z.number().int().nonnegative()
}, anchor), {
    toolCallId: z.string().optional(),
    startedAt: z.string().optional(),
    endedAt: z.string().optional(),
    preview: z.string().optional(),
    answer: z.string().optional(),
    input: z.string().optional(),
    output: z.string().optional()
}));
var trailLaneSchema = z.object(_object_spread_props(_object_spread({
    id: z.string(),
    parentId: z.string().nullable(),
    spawnStepId: z.string().optional(),
    title: z.string(),
    primary: z.boolean(),
    status: trailStatusSchema
}, anchor), {
    invocationKind: z.enum([
        "sub_agent",
        "external_assistant",
        "activity"
    ]).optional(),
    purpose: z.enum([
        "side-chat",
        "message-edit"
    ]).optional(),
    elapsedMs: z.number().nonnegative().optional(),
    outcome: z.object({
        status: z.string(),
        accepted: z.boolean(),
        message: z.string().optional()
    }).optional()
}));
var trailEpisodeSchema = z.object({
    id: z.string(),
    laneId: z.string(),
    activity: trailActivityKindSchema,
    stepIds: z.array(z.string())
});
var trailGraphSchema = z.object({
    version: z.literal(1),
    layer: z.enum([
        "conversation",
        "execution"
    ]),
    conversationId: z.string(),
    threadId: z.string(),
    messageId: z.string().optional(),
    title: z.string(),
    lanes: z.array(trailLaneSchema).max(500),
    steps: z.array(trailStepSchema).max(5000),
    episodes: z.array(trailEpisodeSchema),
    coverage: z.array(z.enum([
        "record_limit",
        "missing_identity",
        "no_execution",
        "timing_unavailable",
        "activity_unavailable",
        "historical"
    ])),
    source: z.object({
        conversationId: z.string(),
        threadId: z.string(),
        messageId: z.string()
    }).optional(),
    live: z.boolean()
});

var codingExecutionViewKey = "platform.coding-execution__execution";
var executionActivityCapabilitiesSchema = z.object({
    version: z.literal(1),
    presentation: z.literal("coding")
}).strict();
var text = z.string().max(65536);
var change = z.object({
    path: z.string().max(4096),
    change: z.enum([
        "created",
        "modified",
        "deleted",
        "reported"
    ]),
    patch: text.optional()
}).strict();
var executionActivityItemSchema = z.object({
    id: z.string().min(1).max(512),
    occurredAt: z.string().datetime({
        offset: true
    }).optional(),
    content: z.discriminatedUnion("kind", [
        z.object({
            kind: z.literal("message"),
            text: text
        }).strict(),
        z.object({
            kind: z.literal("tool"),
            activityKind: trailActivityKindSchema.optional(),
            name: z.string().max(256).optional(),
            status: z.enum([
                "running",
                "succeeded",
                "failed",
                "unknown"
            ]),
            input: text.optional(),
            output: z.string().max(2 * 1024 * 1024).optional(),
            truncated: z.boolean().optional(),
            outputRef: z.object({
                key: z.string().regex(/^[a-f0-9]{64}$/),
                length: z.number().int().positive()
            }).strict().optional(),
            detail: z.discriminatedUnion("type", [
                z.object({
                    type: z.literal("command"),
                    command: text,
                    cwd: z.string().max(4096).optional(),
                    exitCode: z.number().int().optional(),
                    outputMode: z.literal("merged")
                }).strict(),
                z.object({
                    type: z.literal("file_change"),
                    files: z.array(change).max(100)
                }).strict()
            ]).optional()
        }).strict(),
        z.object({
            kind: z.literal("diagnostic"),
            code: z.string().max(128),
            text: text
        }).strict()
    ])
}).strict();
var executionActivityBatchSchema = z.object({
    items: z.array(executionActivityItemSchema).max(100),
    sourceCursor: z.string().max(8192).optional(),
    expectedSourceCursor: z.string().max(8192).optional(),
    complete: z.boolean().optional(),
    gaps: z.array(z.enum([
        "source_truncated",
        "storage_unavailable",
        "capture_limit",
        "interrupted",
        "source_lost"
    ])).max(5).optional()
}).strict();

/** Official resource packages imported into the selected organization, without publishing workspace bindings. */ var DEFAULT_AGENT_PLUGINS_SOURCE = {
    url: "https://github.com/xpert-ai/xpert-plugins.git",
    ref: "main",
    subdirectory: "agent-plugins",
    browseUrl: "https://github.com/xpert-ai/xpert-plugins/tree/main/agent-plugins"
};

/**
 * Resolve an authorized resource to its registered editor, without opening UI.
 * Send the returned navigation through workbench.navigation.open in the same
 * Remote View bridge so the Workbench that contains the caller owns the tab.
 */ var CONTENT_EDITOR_RESOLVE_COMMAND = "workbench.content.resolve";
/** Authorize a document and return its stable URL without changing navigation or clipboard. */ var CONTENT_EDITOR_LINK_COMMAND = "workbench.content.link";
/** Explicit document-reference discriminator in share URLs; consumers must reauthorize the ID. */ var CONTENT_DOCUMENT_LINK_RESOURCE_PARAM = "contentResource";
var ASSISTANT_CONTENT_REVIEW_COMMAND = "assistant.content.review";
var CONTENT_EDITOR_STATUS_COMMAND = "workbench.content.status";

var CONTENT_CATALOG_PROVIDER = "platform.content.catalog";

/** Negotiated Xpert extension. MCP cancellation acknowledgements are not exit evidence. */ var MCP_EXECUTION_CONTROL_EXTENSION_ID = "ai.xpert/execution-control";
var MCP_EXECUTION_CONTROL_METHOD = "xpert/tasks/control";
/** Additive tools/list metadata for 2026, which removed top-level Tool.execution. */ var mcpExecutionToolDeclarationSchema = z.object({
    version: z.literal(1),
    taskSupport: z.enum([
        "required",
        "optional",
        "forbidden"
    ])
});
var mcpOperationIdentitySchema = z.object({
    version: z.literal(1),
    operationId: z.string().uuid(),
    generation: z.string().uuid(),
    inputHash: z.string().regex(/^[a-f0-9]{64}$/),
    toolName: z.string().min(1).max(191)
}).strict();
var mcpExecutionControlRequestSchema = mcpOperationIdentitySchema.extend({
    serverId: z.string().uuid(),
    action: z.enum([
        "inspect",
        "terminate"
    ])
}).strict();
var mcpExecutionReceiptSchema = z.object({
    version: z.literal(1),
    serverId: z.string().uuid(),
    operationId: z.string().uuid(),
    generation: z.string().uuid(),
    taskId: z.string().uuid().nullable(),
    state: z.enum([
        "pending",
        "settled",
        "unknown"
    ]),
    intent: z.enum([
        "running",
        "paused",
        "terminated"
    ]),
    revision: z.number().int().nonnegative(),
    handlerExited: z.boolean(),
    descendantsSettled: z.boolean()
}).strict();
var mcpExecutionCapabilitySchema = z.object({
    version: z.literal(1),
    serverId: z.string().uuid()
}).strict();

/** Public presentation only. Every command revalidates permission and execution admission. */ var threadControlActionsSchema = z.object({
    canPause: z.boolean(),
    canResume: z.boolean(),
    canTerminate: z.boolean(),
    canSend: z.boolean(),
    canQueue: z.boolean(),
    canRetry: z.boolean(),
    canRespond: z.boolean()
}).strict();
var threadControlViewSchema = z.object({
    version: z.literal(1),
    threadId: z.string().min(1),
    runId: z.string().min(1).nullable(),
    revision: z.string().regex(/^[1-9][0-9]*$/),
    state: z.enum([
        "idle",
        "running",
        "pausing",
        "paused",
        "stopping",
        "settling",
        "input_required",
        "confirming",
        "completed",
        "stopped",
        "failed"
    ]),
    actions: threadControlActionsSchema,
    pauseId: z.string().optional()
}).strict();

var taskStatusSchema = z$1.enum(MCP_TASK_STATUSES);
var mcpTaskStartResultSchema = z$1.object({
    resultType: z$1.literal("task"),
    taskId: z$1.string().min(1),
    status: taskStatusSchema,
    statusMessage: z$1.string().optional(),
    createdAt: z$1.string(),
    lastUpdatedAt: z$1.string(),
    ttlMs: z$1.number().nonnegative().nullable(),
    pollIntervalMs: z$1.number().positive().optional(),
    progress: z$1.number().min(0).max(1).nullable().optional(),
    content: z$1.array(z$1.unknown()).optional()
}).passthrough();
var mcpTaskResultSchema = z$1.object({
    resultType: z$1.literal("complete"),
    taskId: z$1.string().min(1),
    status: taskStatusSchema,
    statusMessage: z$1.string().optional(),
    createdAt: z$1.string(),
    lastUpdatedAt: z$1.string(),
    ttlMs: z$1.number().nonnegative().nullable(),
    pollIntervalMs: z$1.number().positive().optional(),
    progress: z$1.number().min(0).max(1).nullable().optional(),
    inputRequests: z$1.unknown().optional(),
    result: z$1.unknown().optional(),
    error: z$1.unknown().optional()
}).passthrough();
var mcpTaskAcknowledgementSchema = z$1.object({
    resultType: z$1.literal("complete")
}).passthrough();

var BUSINESS_AREA_ACCESS_ROLES = [
    "consumer",
    "publisher",
    "domain_admin"
];
function businessAreaRoleAllows(role, action) {
    return action === "view" || (action === "publish" ? role !== "consumer" : role === "domain_admin");
}

/** Opens a discovered resource through its native authorization adapter in the current Workbench scope. */ var WORKBENCH_RESOURCE_OPEN_COMMAND = "workbench.resource.open";

/** Public presentation metadata only. Renderers retain their own sandbox and URL policies. */ var iconDefinitionSchema = z.object({
    type: z.enum([
        "image",
        "svg",
        "font",
        "emoji",
        "lottie"
    ]),
    value: z.string().min(1).max(65536),
    color: z.string().optional(),
    size: z.number().finite().positive().optional(),
    alt: z.string().optional(),
    style: z.record(z.string()).optional()
});

export { AGENT_OUTPUT_ACCEPT, AGENT_OUTPUT_MAX_PATHS, AGENT_PROFILE_TABS_SLOT, AGENT_WORKBENCH_SLOT, AIPermissionsEnum, AI_MODEL_TYPE_VARIABLE, API_PRINCIPAL_USER_ID_HEADER, ARTIFACT_PRESENTATION_OPEN_COMMAND, ARTIFACT_USE_GRANT_MANAGE_COMMAND, ASSISTANT_CHAT_SEND_MESSAGE_COMMAND, ASSISTANT_CITATION_OPEN_EVENT, ASSISTANT_COMPOSER_APPEND_REFERENCES_COMMAND, ASSISTANT_COMPOSER_INSERT_COMMAND, ASSISTANT_CONTENT_REVIEW_COMMAND, ASSISTANT_CONTEXT_SET_COMMAND, ASSISTANT_USER_PREFERENCES_VERSION, AiBusinessRole, AiFeatureEnum, AiModelTypeEnum, AiProtocol, AiProvider, AiProviderRole, AlignmentOptions, ApiAuthType, ApiKeyBindingType, ApiProviderSchemaType, AssistantBindingScope, AssistantBindingSourceScope, AssistantCode, Attachment_Type_Options, AuthenticationEnum, BUILTIN_KNOWLEDGE_FILE_TYPES, BUILTIN_KNOWLEDGE_PARSER, BUSINESS_AREA_ACCESS_ROLES, BonusTypeEnum, BusinessType, CHAT_EVENT_TYPE_CONVERSATION_TITLE_SUMMARY, CHAT_EVENT_TYPE_FOLLOW_UP_CONSUMED, CHAT_EVENT_TYPE_THREAD_CONTEXT_USAGE, CHAT_EVENT_TYPE_THREAD_GOAL_CLEARED, CHAT_EVENT_TYPE_THREAD_GOAL_UPDATED, CONNECTION_REFERENCE_KINDS, CONTENT_CATALOG_PROVIDER, CONTENT_DOCUMENT_LINK_RESOURCE_PARAM, CONTENT_EDITOR_LINK_COMMAND, CONTENT_EDITOR_RESOLVE_COMMAND, CONTENT_EDITOR_STATUS_COMMAND, CONTEXT_COMPRESSION_COMPONENT_TYPE, CONTEXT_COMPRESSION_MIDDLEWARE_NAME, CONTEXT_VARIABLE_CURRENTSTATE, CONVERSATION_MAP_FEATURE, CONVERSATION_SHARE_ARTIFACT_SOURCE, COPILOT_CHECKPOINT_RETENTION_DAYS_SETTING, COPILOT_CHECKPOINT_RETENTION_ENABLED_SETTING, ChatGatewayEvent, ChatMessageEventTypeEnum, ChatMessageFeedbackRatingEnum, ChatMessageStepCategory, ChatMessageTypeEnum, ChatThreadPurpose, ClientFocusEnum, ConfigurateMethod, ContactOrganizationInviteStatus, ContactType, CredentialFormTypeEnum, CredentialsType, CrudActionEnum, CurrenciesEnum, CurrencyPosition, DEFAULT_AGENT_PLUGINS_SOURCE, DEFAULT_COPILOT_CHECKPOINT_RETENTION_DAYS, DEFAULT_CURRENCIES, DEFAULT_DATE_FORMATS, DEFAULT_EMBEDDING_BATCH_SIZE, DEFAULT_INTEGRATION_PAID_FILTERS, DEFAULT_INVITE_EXPIRY_PERIOD, DEFAULT_KNOWLEDGEBASE_FAQ_CONFIG, DEFAULT_KNOWLEDGEBASE_FAQ_RECALL, DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG, DEFAULT_KNOWLEDGE_KEYWORD_ANALYZER, DEFAULT_KNOWLEDGE_RRF_RANK_CONSTANT, DEFAULT_KNOWLEDGE_RRF_WEIGHTS, DEFAULT_KNOWLEDGE_TEXT_SPLITTER, DEFAULT_MEMBERSHIP_CNY_PER_POINT, DEFAULT_MODEL_DEFINITIONS, DEFAULT_MODEL_GATEWAY_BODY_RETENTION_DAYS, DEFAULT_MODEL_GATEWAY_CALL_RETENTION_DAYS, DEFAULT_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS, DEFAULT_MODEL_GATEWAY_REQUESTS_PER_MINUTE, DEFAULT_PROFIT_BASED_BONUS, DEFAULT_REVENUE_BASED_BONUS, DEFAULT_SYSTEM_ROLES, DEFAULT_TENANT, DEFAULT_TIME_FORMATS, DEFAULT_TYPE, DEFAULT_XPERT_AGENT_RECURSION_LIMIT, DEFAULT_XPERT_WORKSPACE_DATA_SCOPE, DEPRECATED_ROLE_PERMISSIONS, DataSourceProtocolEnum, DataSourceSyntaxEnum, DataSourceTypeEnum, DefaultModelRole, DefaultValueDateTypeEnum, DocumentSourceProviderCategoryEnum, DocumentTypeEnum, ENTERPRISE_H5_PLATFORMS, EVENT_INBOX_FEATURE, EVENT_INBOX_VIEW_KEY, EmailTemplateEnum, EmailTemplateNameEnum, EmbeddingStatusEnum, FEEDBACK_LEARNING_STRATEGY, FILE_VARIABLES, FeatureEnum, FeatureStatusEnum, FetchFrom, FileStorageProviderEnum, GENERAL_PROJECT_TYPE, GRAPH_NODE_SUMMARIZE_CONVERSATION, GRAPH_NODE_TITLE_CONVERSATION, HUMAN_PROPOSAL_STRATEGY, HttpStatus, IFeatureToggleTypeEnum, INTEGRATION_PROVIDERS, ImportHistoryStatusEnum, ImportTypeEnum, IntegrationEnum, IntegrationFeatureEnum, IntegrationFilterEnum, IntegrationLarkProvider, InterruptMessageType, InvitationExpirationEnum, InvitationTypeEnum, InviteStatusEnum, IteratingIndexParameterName, IteratingItemParameterName, IteratorIndexParameterName, IteratorItemParameterName, KBDocumentCategoryEnum, KBDocumentStatusEnum, KDocumentSourceType, KDocumentWebTypeEnum, KDocumentWebTypeOptions, KNOWLEDGEBASE_FAQ_RETRIEVAL_MODES, KNOWLEDGEBASE_OPEN_CITATION_EFFECT, KNOWLEDGE_AUTOMATIC_TAG_CANDIDATES, KNOWLEDGE_AUTOMATIC_TAG_MAXIMUM, KNOWLEDGE_AUTOMATIC_TAG_TEXT_BUDGET, KNOWLEDGE_CHUNKING_ALGORITHM_VERSION, KNOWLEDGE_DOCUMENTS_NAME, KNOWLEDGE_DOCUMENT_AGENT_WRITER_TYPE, KNOWLEDGE_FAQ_ANSWER_BLOCK_MAX_COUNT, KNOWLEDGE_FAQ_ANSWER_TOTAL_MAX_LENGTH, KNOWLEDGE_FAQ_MAX_LOGICAL_VECTOR_COUNT, KNOWLEDGE_FAQ_NEGATIVE_QUESTION_MAX_COUNT, KNOWLEDGE_FAQ_NEGATIVE_QUESTION_MAX_LENGTH, KNOWLEDGE_FAQ_SIMILAR_QUESTION_MAX_COUNT, KNOWLEDGE_FAQ_SIMILAR_QUESTION_MAX_LENGTH, KNOWLEDGE_FAQ_STANDARD_QUESTION_MAX_LENGTH, KNOWLEDGE_FILTER_MAX_CONDITIONS, KNOWLEDGE_FILTER_MAX_DEPTH, KNOWLEDGE_FILTER_MAX_SET_VALUES, KNOWLEDGE_FILTER_MAX_STRING_LENGTH, KNOWLEDGE_FILTER_VERSION, KNOWLEDGE_FOLDER_ID_NAME, KNOWLEDGE_GRAPH_DOCUMENT_STATUS_BATCH_SIZE, KNOWLEDGE_PROCESSING_MODE_NAME, KNOWLEDGE_SOURCES_NAME, KNOWLEDGE_STAGE_NAME, KNOWLEDGE_SYSTEM_FILTER_FIELDS, KNOWLEDGE_WIKI_DEFAULT_PAGE_SIZE, KNOWLEDGE_WIKI_DELETION_RECEIPT_RETENTION_DAYS, KNOWLEDGE_WIKI_DOCUMENT_STATUS_BATCH_SIZE, KNOWLEDGE_WIKI_FAILED_CONTENT_RETENTION_DAYS, KNOWLEDGE_WIKI_MAX_ALIASES, KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH, KNOWLEDGE_WIKI_MAX_CUSTOM_INSTRUCTION_LENGTH, KNOWLEDGE_WIKI_MAX_FACTS, KNOWLEDGE_WIKI_MAX_FACT_LENGTH, KNOWLEDGE_WIKI_MAX_PAGE_SIZE, KNOWLEDGE_WIKI_MAX_SEARCH_LENGTH, KNOWLEDGE_WIKI_MAX_SOURCE_CHUNKS_PER_FACT, KNOWLEDGE_WIKI_MAX_SUGGESTED_LINKS, KNOWLEDGE_WIKI_MAX_SUMMARY_LENGTH, KNOWLEDGE_WIKI_OPERATION_RETENTION_DAYS, KNOWLEDGE_WIKI_SCHEMA_VERSION, KNOWLEDGE_WIKI_STALE_VECTOR_CLEANUP_SLO_HOURS, KnowledgeGraphIndexJobStatus, KnowledgeGraphStatus, KnowledgeProviderEnum, KnowledgeStructureEnum, KnowledgeTask, KnowledgebaseChannel, KnowledgebasePermission, KnowledgebaseStatusEnum, KnowledgebaseTypeEnum, LEGACY_AGENT_WORKBENCH_SLOTS, LEGACY_SANDBOX_COMPRESSION_MIDDLEWARE_NAME, LanguagesEnum, LanguagesMap, ListsInputTypeEnum, MAX_COPILOT_CHECKPOINT_RETENTION_DAYS, MAX_MODEL_GATEWAY_BODY_RETENTION_DAYS, MAX_MODEL_GATEWAY_CALL_RETENTION_DAYS, MAX_MODEL_GATEWAY_EXTERNAL_API_BASE_URL_LENGTH, MAX_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS, MAX_MODEL_GATEWAY_REQUESTS_PER_MINUTE, MCPServerType, MCP_API_KEY_SUBJECT_TYPES, MCP_APP_RESOURCE_MIME_TYPE, MCP_AUTH_METHODS, MCP_CAPABILITY_APPROVAL_MODES, MCP_CAPABILITY_DESCRIPTOR_VERSION, MCP_CAPABILITY_TYPES, MCP_CAPABILITY_VISIBILITIES, MCP_CONFIGURATION_SECRET_MASK, MCP_CONSUMER_AUTH_TYPES, MCP_EXECUTION_CONTROL_EXTENSION_ID, MCP_EXECUTION_CONTROL_METHOD, MCP_HTTP_CORS_EXPOSED_HEADERS, MCP_HTTP_CORS_REQUEST_HEADERS, MCP_INVOCATION_STATUSES, MCP_PROTOCOL_VERSION, MCP_PUBLICATION_REVIEW_STATUSES, MCP_PUBLICATION_STATUSES, MCP_REQUIRED_CONTEXTS, MCP_TASK_EXTENSION_ID, MCP_TASK_STATUSES, MCP_TOOL_IDEMPOTENCY, MCP_TOOL_RISKS, MCP_TOOL_SIDE_EFFECTS, MEMBERSHIP_CNY_PER_POINT_SETTING, MIN_COPILOT_CHECKPOINT_RETENTION_DAYS, MIN_MODEL_GATEWAY_BODY_RETENTION_DAYS, MIN_MODEL_GATEWAY_CALL_RETENTION_DAYS, MIN_MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS, MIN_MODEL_GATEWAY_REQUESTS_PER_MINUTE, MODEL_EXECUTION_POLICY_SETTING, MODEL_GATEWAY_CALL_RETENTION_DAYS_SETTING, MODEL_GATEWAY_CALL_RETENTION_ENABLED_SETTING, MODEL_GATEWAY_EXTERNAL_API_BASE_URL_SETTING, MODEL_GATEWAY_MAX_CONCURRENT_REQUESTS_SETTING, MODEL_GATEWAY_REQUESTS_PER_MINUTE_SETTING, MembershipAdminUserStatusEnum, MembershipBulkActionEnum, MembershipLedgerSourceEnum, MembershipPeriodEnum, MembershipPeriodStatusEnum, MembershipPlanStatusEnum, MembershipRenewalModeEnum, MembershipSourceEnum, MembershipStatusEnum, MinimumProjectSizeEnum, ModelAccessActorTypeEnum, ModelAccessChannelEnum, ModelAccessClosedReasonCodeEnum, ModelAccessEventTypeEnum, ModelAccessOwnershipScopeEnum, ModelAccessRequestStatusEnum, ModelAccessSourceEnum, ModelAccessUnavailableReasonEnum, ModelFeature, ModelGatewayApiKeyLifetimeEnum, ModelGatewayApiKeyStatusEnum, ModelGatewayCallStatusEnum, ModelGatewayUsageChannelEnum, ModelGatewayUsageSourceEnum, ModelPropertyKey, OllamaEmbeddingsProviders, OpenAIEmbeddingsProviders, OrderTypeEnum, OrganizationContactBudgetTypeEnum, OrganizationDemoNetworkEnum, OrganizationPermissionsEnum, OrganizationProjectBudgetTypeEnum, OrganizationSelectInput, PERSONAL_API_KEY_LIFETIMES, PLUGIN_APPLICATION_INSTALLATION_STATUS, PLUGIN_APPLICATION_SCOPE, PLUGIN_COMPONENT_TYPE, PLUGIN_CONFIGURATION_STATUS, PLUGIN_LEVEL, PLUGIN_LOAD_STATUS, PLUGIN_MARKETPLACE_AUTHENTICATION_POLICY, PLUGIN_MARKETPLACE_CATEGORIES, PLUGIN_MARKETPLACE_INSTALLATION_POLICY, PLUGIN_MARKETPLACE_SUBCATEGORIES, PLUGIN_MCP_TOOL_APPROVAL_MODE, PLUGIN_RESOURCE_ERROR_CODE, PLUGIN_RESOURCE_INSTALLATION_STATUS, PLUGIN_RESOURCE_RUNTIME_TYPE, PLUGIN_SOURCE, PROJECT_CONFIGURATION_ACTIONS, PROJECT_CONFIGURATION_ACTION_HANDLERS, PROJECT_CONFIGURATION_PROVIDER, PROJECT_CONFIGURATION_VIEW, PROJECT_TASK_ICON_NAMES, ParameterType, ParameterTypeEnum, PayPeriodEnum, PermissionGroups, PermissionsEnum, PluginMarketplaceDetailErrorCode, PriceType, ProjectBillingEnum, ProjectOwnerEnum, ProviderEnum, ProviderType, ROLE_PERMISSION_CATALOG, ROLE_PERMISSION_MODULES, RUNTIME_RESTART_CONFIRMATION, RUNTIME_STREAM_INTERRUPTED_EVENT, RegionsEnum, RequestMethodEnum, RequestScopeLevel, RolesEnum, SANDBOX_FILE_OUTPUT_RULES, SANDBOX_MANAGED_SERVICE_STATUSES, SANDBOX_MANAGED_SERVICE_TRANSPORT_MODES, SANDBOX_TERMINAL_NAMESPACE, SANDBOX_WORK_FOR_TYPES, SKILLS_MIDDLEWARE_NAME, SMTPSecureEnum, SPACE_PROJECT_TYPE, STANDARD_METADATA_FIELDS, STATE_SYS_AGENT_WORKSPACE_PATH, STATE_SYS_MEMORY_WORKSPACE_PATH, STATE_SYS_SESSION_WORKSPACE_PATH, STATE_SYS_SHARED_WORKSPACE_PATH, STATE_SYS_THREAD_ID, STATE_SYS_VOLUME, STATE_SYS_WORKSPACE_PATH, STATE_SYS_WORKSPACE_ROOT, STATE_SYS_WORKSPACE_URL, STATE_VARIABLE_FILES, STATE_VARIABLE_HUMAN, STATE_VARIABLE_INPUT, STATE_VARIABLE_SYS, STATE_VARIABLE_TITLE_CHANNEL, SandboxManagedServiceErrorCode, SandboxTerminalClientEvent, SandboxTerminalClosedReason, SandboxTerminalErrorCode, SandboxTerminalServerEvent, ScheduleTaskStatus, SecretTokenBindingType, TAG_TARGETS, TASK_DESCRIPTION_PREFIX, TASK_DESCRIPTION_SUFFIX, THREAD_GOAL_STATUS_VALUES, TOOL_NAME_REGEX, TagCategoryEnum, TaskFrequency, TaskListTypeEnum, ToolParameterForm, ToolParameterType, ToolTagEnum, TranslationLanguageMap, UNWIRED_AI_PERMISSIONS, USAGE_HOUR_FORMAT, USER_EVENT_INBOX_SLOT, USER_ORGANIZATION_ENTRY_GUIDE_CLAWXPERT, UserGroupManagedByEnum, UserGroupManagedEntityTypeEnum, UserModelGrantStatusEnum, UserType, VariableOperationEnum, VariableOperations, VectorTypeEnum, Visibility, WORKBENCH_AGENT_EVOLUTION_CHANGE_TARGET, WORKBENCH_AGENT_EVOLUTION_TARGET, WORKBENCH_ASSISTANT_CONVERSATION_TARGET, WORKBENCH_ASSISTANT_EXECUTION_TARGET, WORKBENCH_ASSISTANT_PROJECT_TARGET, WORKBENCH_CONTENT_DRAFT_COMMAND, WORKBENCH_EXTENSION_VIEW_TARGET, WORKBENCH_FILE_OPEN_COMMAND, WORKBENCH_GROUP_MESSAGE_TARGET, WORKBENCH_KNOWLEDGEBASE_DOCUMENTS_TARGET, WORKBENCH_NAVIGATION_OPEN_COMMAND, WORKBENCH_PROJECT_APPLICATION_TARGET, WORKBENCH_PROJECT_PIPELINES_TARGET, WORKBENCH_RESOURCE_OPEN_COMMAND, WORKBENCH_VIEW_OPEN_EVENT, WORKSPACE_PUBLIC_SKILL_REPOSITORY_NAME, WORKSPACE_PUBLIC_SKILL_SOURCE_PROVIDER, WeekDaysEnum, WorkflowComparisonOperator, WorkflowLogicalOperator, WorkflowNodeTypeEnum, XPERT_FILE_MEMORY_MIDDLEWARE_NAME, XPERT_REMOTE_COMPONENT_INVOKE_CLIENT_COMMAND_MESSAGE_TYPE, XPERT_TASK_SCHEDULE_IDEMPOTENCY_KEY, XPERT_TASK_SCHEDULE_PROPERTY_PREFIX, XPERT_VIEW_CONVERSATION_ID_HEADER, XPERT_VIEW_PROJECT_ID_HEADER, XpertAccessRequestStatusEnum, XpertAgentExecutionStatusEnum, XpertMarketplaceBusinessCategories, XpertMarketplaceCollaborationModes, XpertMarketplaceTechnicalCategories, XpertParameterTypeEnum, XpertProjectAssetSourceEnum, XpertProjectAutomationRunStatusEnum, XpertProjectAutomationTriggerEnum, XpertProjectPlanViewEnum, XpertProjectTaskPriorityEnum, XpertProjectTaskStatusEnum, XpertTableStatus, XpertToolsetCategoryEnum, XpertTypeEnum, XpertWorkbenchInitialLayoutEnum, agentDeliveryRecoverySchema, agentEventDecisionSchema, agentEventRefSchema, agentInvocationStatusSchema, agentInvocationTerminalStatusSchema, agentLabel, agentOutputDeliverySchema, agentOutputOriginSchema, agentOutputPresentationSchema, agentOutputReferenceSchema, agentResultPathSchema, agentRuntimeModelSourceSchema, agentRuntimeProgressSchema, agentUniqueName, aggregatePipelineAnalytics, allChannels, analyticsDiagnosticSchema, announcementActionSchema, announcementContentSchema, announcementRevisionSchema, announcementSchema, appPlatformAppOrder, appPlatformAppSchema, appPlatformDefinitionSchema, appPlatformEnvironmentSchema, appendMessageContent, appendMessagePlainText, assistantOperationPolicySchema, assistantTaskGroupContext, assistantTaskGroupContextSchema, assistantTemplateManifestSchema, assistantTemplateSetupStateSchema, buildChunkTree, buildXpertMarketplaceProfileSnapshot, businessAreaRoleAllows, canAllowMcpToolDirectly, canReadProjectPipelineConfiguration, channelName, chatMessagePresentation, checkProjectPipelineConfiguration, checkProjectPipelineHostCompatibility, classificateDocumentCategory, clientSecretGrantSourceSchema, codingExecutionViewKey, collectTreeLeaves, configurableStoreNamespace, configurationFromModel, configureProjectPipelineFromForm, configuredModelSource, controlledHandlerSchema, convertToUrlPath, createAgentConnections, createAnnouncementSchema, createConversationTitleSummaryEvent, createFollowUpConsumedEvent, createMessageAppendContextTracker, createRuntimeSkillCapabilityId, createThreadGoalClearedEvent, createThreadGoalUpdatedEvent, createXpertGraph, createXpertNodes, decodeKnowledgeSeparators, defaultMcpToolApprovalMode, defaultModelConfiguration, defaultModelDefinition, defaultModelRoleSchema, deriveXpertMarketplaceTechnicalProfile, discoverableModelTypes, enabledModelsSchema, ensureAssistantBindingSkillWorkspacePreference, evidenceDrivenStrategy, executeModelReplacementSchema, executionActivityBatchSchema, executionActivityCapabilitiesSchema, executionActivityItemSchema, executionControlCapabilitiesSchema, executionControlEvidenceSchema, executionControlProtocols, executionObservationAnomalySchema, executionObservationAssistantSchema, executionObservationAvatarSchema, executionObservationCompareSchema, executionObservationConversationSchema, executionObservationConversationsSchema, executionObservationDetailQuerySchema, executionObservationDetailSchema, executionObservationFilterSchema, executionObservationListSchema, executionObservationOverviewSchema, executionObservationQuerySchema, executionObservationRecordSchema, executionObservationSegmentSchema, executionObservationStatusSchema, executionObservationSummarySchema, executionObservationWorkspacesSchema, executionRuntimeTargetSchema, executionRuntimeTargetsEqual, figureOutXpert, filterAssistantBindingDisabledSkillIds, filterAssistantBindingDisabledTools, filterMessageText, findStartNodes, forecastProjectTasks, genJSONParseKey, genJSONStringifyKey, genListOperatorKey, genPipelineChunkerKey, genPipelineKnowledgeBaseKey, genPipelineProcessorKey, genPipelineSourceKey, genPipelineUnderstandingKey, genVariableAggregatorKey, genXpertDBDeleteKey, genXpertDBInsertKey, genXpertDBQueryKey, genXpertDBSqlKey, genXpertDBUpdateKey, genXpertIteratorKey, genXpertMiddlewareKey, genXpertSkillKey, genXpertStartKey, genXpertTriggerKey, generateCronExpression, getAgentMiddlewareNodes, getAgentVarGroup, getAssistantBindingDisabledSkillIds, getAssistantBindingDisabledTools, getAssistantManagement, getCurrentGraph, getEnabledTools, getPluginApplicationScopes, getStoreNamespace, getSwarmPartners, getTagTargets, getToolCallFromConfig, getToolCallIdFromConfig, getToolLabel, getVariableSchema, getWorkflowTriggers, getWorkspaceFromRunnable, getXpertAgentRecursionLimit, getXpertWorkspaceVisibility, hasEnabledKnowledgeRetrievalSource, iconDefinitionSchema, inferMessageAppendContext, isAgentKey, isAgentWorkflowNode, isAgentWorkflowNodeType, isAssistantBindingSkillEnabled, isAssistantBindingToolEnabled, isAssistantBindingToolPreferencesEmpty, isAudioType, isBlank, isConfiguredModelAvailable, isContextCompressionComponentData, isDiscoverableModelType, isDocumentKnowledgebaseType, isDocumentSheet, isEnableTool, isEnterpriseH5Platform, isEvidenceProposal, isImageType, isInterruptMessage, isIteratingKey, isIteratorKey, isKnowledgeDocumentVisible, isKnowledgeTableMetadata, isKnowledgeWikiChunkMetadata, isKnowledgeWikiPageContributionPayload, isKnowledgeWikiPageSourcePayload, isLearningProposal, isMessageGroup, isMiddlewareToolEnabled, isModelGatewayExternalApiBaseUrl, isNativeKnowledgeTableDocument, isNil$1 as isNil, isOrganizationSharedXpertWorkspace, isOutputTokenParameter, isPluginApplicationScope, isPreparedCandidate, isProjectPipelineApplicable, isPromptWorkflowScenarios, isProviderEvaluation, isProviderModelEnabled, isProviderRelease, isReplayEvaluation, isRequiredMiddleware, isRouterKey, isRunnableThreadGoalStatus, isRuntimeChatMessage, isScopedPromptCapabilityConfig, isStagedRelease, isString, isSystemManagedAssistant, isTenantSharedXpertWorkspace, isToolEnabled, isUserAddableAgentMiddleware, isUserManagedAssistant, isUserOrganizationEntryGuideKey, isVideoType, isXpertNodeType, knowledgeDocumentFileType, knowledgeUploadFileTypes, knowledgebaseDocumentParserDefaults, knowledgebaseParserSelection, legacyModelFeatures, legacyProviderRoleSchema, letterStartSUID, locateNodes, mapTranslationLanguage, mcpExecutionCapabilitySchema, mcpExecutionControlRequestSchema, mcpExecutionReceiptSchema, mcpExecutionToolDeclarationSchema, mcpOperationIdentitySchema, mcpTaskAcknowledgementSchema, mcpTaskResultSchema, mcpTaskStartResultSchema, mergeMessageContentForDisplay, messageContentText, modelBindingSchema, modelConfigurationSchema, modelExecutionEntry, modelExecutionParametersSchema, modelExecutionSourceId, modelIdentityKey, modelIdentitySchema, modelImportSchema, modelReplacementSchema, modelReplacementScopeSchema, nonBlank, nonNullable, normalizeAssistantBindingToolPreferences, normalizeKnowledgebaseFAQRecall, normalizeKnowledgebaseWikiConfig, normalizeMiddlewareNode, normalizeMiddlewareNodes, normalizeMiddlewareOptions, normalizeMiddlewareProvider, normalizeModelParameterValue, normalizeXpertAgentConfig, notificationChangeSchema, notificationClientSchema, notificationOutboxPayloadSchema, notificationSnapshotSchema, notificationSourceSchema, notificationThreadIdSchema, omitXpertRelations, openConversationActionSchema, orderAssistantXperts, outputPreferenceSchema, outputQuietHoursSchema, parseAnalyticsDiagnostic, parseAnnouncement, parseGithubSkillInstallCommand, parseNotificationSnapshot, parseOpenConversationAction, parseProjectPipelineParameters, parsePromptCapabilityConfig, parsePromptCapabilitySelection, parseRuntimeSkillCapabilityId, parseUserNotification, parseWorkbenchViewOpenEvent, pipelineAnalyticsFacts, pipelineAttemptCounts, pipelineAttemptCountsSchema, pipelineExecutionTiming, pipelineExecutionTimingSchema, pipelineExecutorStatistics, pipelineExecutorStatisticsSchema, pipelineHumanWaitSnapshotSchema, pipelineHumanWaitStatistics, pipelineHumanWaitStatisticsSchema, pipelineModelUsageFactSchema, pipelineModelUsageStatistics, pipelineModelUsageStatisticsSchema, pipelineNodeNeedsHuman, pipelineQueueStatistics, pipelineQueueStatisticsSchema, pluginAgentEventSchema, projectConfigurationActionSchema, projectConfigurationSectionSchema, projectConfigurationUpdateSchema, projectConfigurationValuesSchema, projectPipelineAnalytics, projectPipelineAnalyticsInputSchema, projectPipelineAnalyticsSchema, projectPipelineAssistantExecutionSchema, projectPipelineAssistantInputSchema, projectPipelineBindingSchema, projectPipelineCancelSchema, projectPipelineCatalogConfigureSchema, projectPipelineCatalogProtocolSchema, projectPipelineCatalogRequestSchema, projectPipelineCatalogSchema, projectPipelineCommandCapabilitySchema, projectPipelineCompletionReceiptSchema, projectPipelineConfigurationFormSchema, projectPipelineConfigurationPageSchema, projectPipelineConfigurationSchema, projectPipelineConfigureSchema, projectPipelineContributionSchema, projectPipelineDecisionSchema, projectPipelineDefinitionSchema, projectPipelineDefinitionShapeSchema, projectPipelineEdgeSchema, projectPipelineEvidenceRefSchema, projectPipelineExtensionDescriptorSchema, projectPipelineHostCapabilitiesSchema, projectPipelineHostRequirementsSchema, projectPipelineIconSchema, projectPipelineInputBindingSchema, projectPipelineInstanceSchema, projectPipelineJsonSchema, projectPipelineKeySchema, projectPipelineLaneSchema, projectPipelineModelBudgetIncreaseRecordSchema, projectPipelineModelBudgetIncreaseSchema, projectPipelineNativeDispatchSchema, projectPipelineNativeModelBudgetSchema, projectPipelineNativeModelBudgetStatusSchema, projectPipelineNativeSourceSchema, projectPipelineNextRoundSchema, projectPipelineNodeInstanceSchema, projectPipelineNodePresentationSchema, projectPipelineNodeSchema, projectPipelineNodeStateSchema, projectPipelineOperationInputSchema, projectPipelineOperationReceiptSchema, projectPipelineOutputBindingSchema, projectPipelineParameterFieldSchema, projectPipelineParticipantKindSchema, projectPipelinePolicyReceiptSchema, projectPipelinePortDescriptorSchema, projectPipelinePortfolioInputSchema, projectPipelinePortfolioSchema, projectPipelineProjectBindingSchema, projectPipelineProjectTypesSchema, projectPipelineProjectionEdgeSchema, projectPipelineProjectionNodeSchema, projectPipelineProjectionSchema, projectPipelineProviderActionCommandSchema, projectPipelineProviderActionDescriptorSchema, projectPipelineProviderActionReceiptSchema, projectPipelineProviderActionTargetSchema, projectPipelineProviderActionViewSchema, projectPipelineProviderActionsSchema, projectPipelineRefSchema, projectPipelineResourceClaimSchema, projectPipelineResourceClaimsSchema, projectPipelineResourceReservationSchema, projectPipelineRetrySchema, projectPipelineRoleSchema, projectPipelineRoundSchema, projectPipelineRunSchema, projectPipelineRuntimeExecutionSchema, projectPipelineRuntimeInputSchema, projectPipelineRuntimeSelectionSchema, projectPipelineSavedConfigurationSchema, projectPipelineStageSchema, projectPipelineStartSchema, projectPipelineStatistics, projectPipelineStatisticsSchema, projectPipelineSubjectVersionSchema, projectPipelineTaskProjectionSchema, projectPipelineWorkContextSchema, projectPipelineWorkCountsSchema, projectPluginDeploymentReceiptSchema, projectPluginDeploymentRefs, projectPluginDeploymentRequestSchema, projectTaskCandidatePathSchema, projectTaskConfigurationSchema, projectTaskDecisionInputSchema, projectTaskDecisionSchema, projectTaskDecisionToolInputSchema, projectTaskDispatchInputSchema, projectTaskDispatchReceiptSchema, projectTaskDispatchToolInputSchema, projectTaskDurationSchema, projectTaskEvidencePathSchema, projectTaskEvidenceReferenceSchema, projectTaskExecutionContextSchema, projectTaskExecutionPurposeSchema, projectTaskExecutionReferenceSchema, projectTaskReviewReportSchema, projectTaskReviewSubjectSchema, projectTaskReviewerSchema, projectTaskReworkSchema, projectTaskSpecificationDigestSchema, projectTaskSpecificationSchema, projectTaskSpecificationSnapshotSchema, providerCredentialCheckSchema, providerCredentialValidationTargetSchema, readModelConfiguration, replaceAgentInDraft, resolveDraftPrimaryAgent, resolveDraftRuntimeGraph, resolveI18nText, resolveMessageAppendContext, resolveModelParameterOptions, resolvePromptWorkflowCapabilities, resolveRuntimeXpert, roleDefaultInputSchema, sameModelIdentity, sandboxEvidence, sandboxJobRetryReferenceSchema, sandboxRuntimeEvidenceSchema, sandboxRuntimeTargetSchema, sandboxTargetsEqual, saveRoleDefaultsSchema, scheduledNotificationOriginSchema, selectedPipelineAttemptFacts, setStateVariable, shortTitle, stringifyMessageContent, templateActivityReadSchema, templateDependencyLocksSchema, templateDependencyVersionsSchema, templateFilePathSchema, templateFilesSchema, templateManifestSchema, templateManifestV1Schema, templatePreferenceValuesSchema, templatePublicationInputSchema, templateSetupUpdateSchema, templateUpgradeActionSchema, templateUpgradeInputSchema, templateUpgradeSectionSchema, threadControlActionsSchema, threadControlViewSchema, toXpertOpenerPrompt, trailActivityKindSchema, trailEpisodeSchema, trailGraphSchema, trailLaneSchema, trailStatusSchema, trailStepSchema, transformInstallation, transitionModelParameters, unknownExecutionControl, updateAnnouncementSchema, updateAssistantBindingSkillPreferences, updateAssistantBindingToolPreferences, userNotificationSchema, usesConfiguredModelCatalog, usesModelScopedCredentials, uuid, validateProjectPipelineConfigurationForm, validateProjectPipelineDefinition, validateProjectTaskGraph, workflowNodeIdentifier, workspaceConnectorAuthorizationSchema, workspaceConnectorConnectPayloadSchema, xpertLabel };
