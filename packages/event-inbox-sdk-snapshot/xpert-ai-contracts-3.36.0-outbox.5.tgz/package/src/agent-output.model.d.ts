import { z } from 'zod/v3';
import { type OpenConversationAction } from './user-notification.schema';
export declare const AGENT_OUTPUT_ACCEPT = "application/json; profile=\"xpert-agent-output-v1\"";
export type AgentOutputField = {
    label: {
        en_US: string;
        zh_Hans: string;
    };
    value: string;
};
export interface AgentOutputItem {
    id: string;
    title: string;
    action: OpenConversationAction | null;
    fields?: AgentOutputField[];
}
export declare const outputQuietHoursSchema: z.ZodEffects<z.ZodObject<{
    zone: z.ZodEffects<z.ZodString, string, string>;
    start: z.ZodString;
    end: z.ZodString;
}, "strict", z.ZodTypeAny, {
    end?: string;
    start?: string;
    zone?: string;
}, {
    end?: string;
    start?: string;
    zone?: string;
}>, {
    end?: string;
    start?: string;
    zone?: string;
}, {
    end?: string;
    start?: string;
    zone?: string;
}>;
export type OutputQuietHours = {
    zone: string;
    start: string;
    end: string;
};
export declare const outputPreferenceSchema: z.ZodEffects<z.ZodObject<{
    kind: z.ZodString;
    channel: z.ZodEnum<["in_app", "lark"]>;
    enabled: z.ZodBoolean;
    integrationId: z.ZodNullable<z.ZodString>;
    quiet: z.ZodNullable<z.ZodEffects<z.ZodObject<{
        zone: z.ZodEffects<z.ZodString, string, string>;
        start: z.ZodString;
        end: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        end?: string;
        start?: string;
        zone?: string;
    }, {
        end?: string;
        start?: string;
        zone?: string;
    }>, {
        end?: string;
        start?: string;
        zone?: string;
    }, {
        end?: string;
        start?: string;
        zone?: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    kind?: string;
    enabled?: boolean;
    channel?: "lark" | "in_app";
    integrationId?: string;
    quiet?: {
        end?: string;
        start?: string;
        zone?: string;
    };
}, {
    kind?: string;
    enabled?: boolean;
    channel?: "lark" | "in_app";
    integrationId?: string;
    quiet?: {
        end?: string;
        start?: string;
        zone?: string;
    };
}>, {
    kind?: string;
    enabled?: boolean;
    channel?: "lark" | "in_app";
    integrationId?: string;
    quiet?: {
        end?: string;
        start?: string;
        zone?: string;
    };
}, {
    kind?: string;
    enabled?: boolean;
    channel?: "lark" | "in_app";
    integrationId?: string;
    quiet?: {
        end?: string;
        start?: string;
        zone?: string;
    };
}>;
export type OutputPreference = {
    kind: string;
    channel: 'in_app' | 'lark';
    enabled: boolean;
    integrationId: string | null;
    quiet: OutputQuietHours | null;
};
export declare const agentOutputReferenceSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    kind: z.ZodString;
    key: z.ZodString;
    revision: z.ZodString;
    publishedAt: z.ZodString;
    recipientId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind?: string;
    key?: string;
    schemaVersion?: 1;
    revision?: string;
    recipientId?: string;
    publishedAt?: string;
}, {
    kind?: string;
    key?: string;
    schemaVersion?: 1;
    revision?: string;
    recipientId?: string;
    publishedAt?: string;
}>;
export type AgentOutputReference = Required<z.output<typeof agentOutputReferenceSchema>>;
export declare const agentOutputPresentationSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"visible">;
    title: z.ZodString;
    fields: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            zh_Hans?: string;
            en_US?: string;
        }, {
            zh_Hans?: string;
            en_US?: string;
        }>;
        value: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        value?: string;
        label?: {
            zh_Hans?: string;
            en_US?: string;
        };
    }, {
        value?: string;
        label?: {
            zh_Hans?: string;
            en_US?: string;
        };
    }>, "many">>;
    conversation: z.ZodCatch<z.ZodOptional<z.ZodObject<{
        conversationId: z.ZodString;
        threadId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        conversationId?: string;
        threadId?: string;
    }, {
        conversationId?: string;
        threadId?: string;
    }>>>;
}, "strict", z.ZodTypeAny, {
    status?: "visible";
    conversation?: {
        conversationId?: string;
        threadId?: string;
    };
    title?: string;
    fields?: {
        value?: string;
        label?: {
            zh_Hans?: string;
            en_US?: string;
        };
    }[];
}, {
    status?: "visible";
    conversation?: unknown;
    title?: string;
    fields?: {
        value?: string;
        label?: {
            zh_Hans?: string;
            en_US?: string;
        };
    }[];
}>, z.ZodObject<{
    status: z.ZodEnum<["superseded", "forbidden", "unavailable"]>;
}, "strict", z.ZodTypeAny, {
    status?: "unavailable" | "superseded" | "forbidden";
}, {
    status?: "unavailable" | "superseded" | "forbidden";
}>]>;
export type AgentOutputPresentation = {
    status: 'visible';
    title: string;
    fields?: AgentOutputField[];
    conversation?: {
        conversationId: string;
        threadId?: string;
    };
} | {
    status: 'superseded' | 'forbidden' | 'unavailable';
};
