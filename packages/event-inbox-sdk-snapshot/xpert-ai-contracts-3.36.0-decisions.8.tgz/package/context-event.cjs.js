'use strict';

var v3 = require('zod/v3');

/** Context revision and runtime scope delivered by an authorized Remote View host. */ var viewContextEventSchema = v3.z.object({
    type: v3.z.literal("view.context.changed"),
    data: v3.z.object({
        revision: v3.z.number().int().nonnegative(),
        runtimeScope: v3.z.object({
            projectId: v3.z.string().nullish(),
            conversationId: v3.z.string().nullish()
        })
    })
}).transform(function(param) {
    var type = param.type, data = param.data;
    return {
        type: type,
        // Keep required envelope fields explicit in declarations built without strictNullChecks.
        data: {
            revision: data.revision,
            runtimeScope: data.runtimeScope
        }
    };
});

exports.viewContextEventSchema = viewContextEventSchema;
