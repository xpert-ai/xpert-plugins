export declare enum ScheduleTaskStatus {
    PAUSED = "paused",
    ARCHIVED = "archived",
    SCHEDULED = "scheduled"
}
export declare enum TaskFrequency {
    Once = "Once",
    Daily = "Daily",
    Weekly = "Weekly",
    Monthly = "Monthly",
    Yearly = "Yearly"
}
export type TScheduleOptions = {
    frequency: TaskFrequency;
    time: string;
    dayOfWeek?: number;
    dayOfMonth?: number;
    month?: number;
    date?: string;
};
/**
 * Generate cron expression: Minutes Hour Day Month Week
 *
 * @param schedule
 * @returns
 */
export declare function generateCronExpression(schedule: TScheduleOptions): string;
