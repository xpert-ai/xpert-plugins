import { IBasePerTenantAndOrganizationEntityModel } from './base-entity.model';
import { _TFile } from './types';
export type TFile = _TFile & {
    fileType?: string;
    contents?: string;
    /** Authority resolved by the file service for this request, never inferred from MIME or identity. */
    capabilities?: {
        canRead: boolean;
        canWrite: boolean;
    };
    previewText?: string;
    description?: string;
    size?: number;
    createdAt?: Date;
    updatedAt?: Date;
    storageFileId?: string;
};
/**
 * @deprecated IStorageFile is kept only as a legacy storage-layer compatibility
 * bridge. Use FileAsset/AgentFile for new file flows; this interface will be
 * removed in v4.0.
 */
export interface IStorageFile extends IBasePerTenantAndOrganizationEntityModel {
    file: string;
    url?: string;
    thumb?: string;
    fileUrl?: string;
    thumbUrl?: string;
    originalName?: string;
    encoding?: string;
    size?: number;
    mimetype?: string;
    recordedAt?: Date;
    storageProvider?: string;
}
export interface ICreateStorageFileInput extends IBasePerTenantAndOrganizationEntityModel {
    activityTimestamp: string;
    employeeId?: string;
    file: string;
    thumb?: string;
    recordedAt: Date | string;
}
export interface IUpdateStorageFileInput extends ICreateStorageFileInput {
    id: string;
}
export type TFileDirectory = TFile & {
    fullPath?: string;
    directory?: string;
    hasChildren?: boolean;
    children?: TFileDirectory[];
};
