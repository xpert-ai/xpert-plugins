import { z } from 'zod/v3';
export declare const notificationClientSchema: z.ZodEnum<["web", "desktop"]>;
export type NotificationClient = z.infer<typeof notificationClientSchema>;
export declare const announcementActionSchema: z.ZodObject<{
    type: z.ZodLiteral<"link">;
    label: z.ZodString;
    url: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    type: "link";
    label: string;
    url: string;
}, {
    type: "link";
    label: string;
    url: string;
}>;
export declare const announcementContentSchema: z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("web" | "desktop")[], ("web" | "desktop")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type: "link";
        label: string;
        url: string;
    }, {
        type: "link";
        label: string;
        url: string;
    }>>>;
}, "strict", z.ZodTypeAny, {
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
}, {
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
}>;
export declare const createAnnouncementSchema: z.ZodEffects<z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("web" | "desktop")[], ("web" | "desktop")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type: "link";
        label: string;
        url: string;
    }, {
        type: "link";
        label: string;
        url: string;
    }>>>;
}, "strict", z.ZodTypeAny, {
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
}, {
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
}>, {
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
}, {
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
}>;
export declare const updateAnnouncementSchema: z.ZodEffects<z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("web" | "desktop")[], ("web" | "desktop")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type: "link";
        label: string;
        url: string;
    }, {
        type: "link";
        label: string;
        url: string;
    }>>>;
} & {
    revision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    revision: number;
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
}, {
    revision: number;
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
}>, {
    revision: number;
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
}, {
    revision: number;
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
}>;
export declare const announcementRevisionSchema: z.ZodObject<{
    revision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    revision: number;
}, {
    revision: number;
}>;
export declare const announcementSchema: z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("web" | "desktop")[], ("web" | "desktop")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type: "link";
        label: string;
        url: string;
    }, {
        type: "link";
        label: string;
        url: string;
    }>>>;
} & {
    id: z.ZodString;
    status: z.ZodEnum<["draft", "published", "withdrawn"]>;
    revision: z.ZodNumber;
    createdAt: z.ZodString;
    dismissedAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    status: "draft" | "published" | "withdrawn";
    revision: number;
    title: string;
    body: string;
    category: "general" | "maintenance" | "model_retirement";
    severity: "info" | "important";
    clients: ("web" | "desktop")[];
    startsAt: string;
    expiresAt: string | null;
    action: {
        type: "link";
        label: string;
        url: string;
    } | null;
    id: string;
    createdAt: string;
    dismissedAt: string | null;
}, {
    status: "draft" | "published" | "withdrawn";
    revision: number;
    title: string;
    body: string;
    clients: ("web" | "desktop")[];
    startsAt: string;
    id: string;
    createdAt: string;
    category?: "general" | "maintenance" | "model_retirement" | undefined;
    severity?: "info" | "important" | undefined;
    expiresAt?: string | null | undefined;
    action?: {
        type: "link";
        label: string;
        url: string;
    } | null | undefined;
    dismissedAt?: string | null | undefined;
}>;
export type AnnouncementInput = z.output<typeof createAnnouncementSchema>;
export type Announcement = Omit<Required<z.output<typeof announcementSchema>>, 'action'> & {
    action: Required<z.output<typeof announcementActionSchema>> | null;
};
export declare const notificationSourceSchema: z.ZodObject<{
    type: z.ZodLiteral<"scheduled_task">;
    taskId: z.ZodString;
    executionId: z.ZodString;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "scheduled_task";
    taskId: string;
    executionId: string;
    assistantId: string;
    conversationId: string;
}, {
    type: "scheduled_task";
    taskId: string;
    executionId: string;
    assistantId: string;
    conversationId: string;
}>;
export declare const scheduledNotificationOriginSchema: z.ZodObject<{
    type: z.ZodLiteral<"scheduled_task">;
    taskId: z.ZodString;
    executionId: z.ZodString;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
} & {
    threadId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    type: "scheduled_task";
    taskId: string;
    executionId: string;
    assistantId: string;
    conversationId: string;
    threadId?: string | undefined;
}, {
    type: "scheduled_task";
    taskId: string;
    executionId: string;
    assistantId: string;
    conversationId: string;
    threadId?: string | undefined;
}>;
export declare const notificationThreadIdSchema: z.ZodString;
export declare const openConversationActionSchema: z.ZodObject<{
    type: z.ZodLiteral<"open_conversation">;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
    threadId: z.ZodNullable<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    type: "open_conversation";
    assistantId: string;
    conversationId: string;
    threadId: string | null;
}, {
    type: "open_conversation";
    assistantId: string;
    conversationId: string;
    threadId: string | null;
}>;
export type OpenConversationAction = Required<z.output<typeof openConversationActionSchema>>;
declare const taskNotificationSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<"agent.completed">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"scheduled_task">;
        taskId: z.ZodString;
        executionId: z.ZodString;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    }, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    }>;
    createdAt: z.ZodString;
    readAt: z.ZodNullable<z.ZodString>;
    action: z.ZodObject<{
        type: z.ZodLiteral<"open_conversation">;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodNullable<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }>;
}, "strict", z.ZodTypeAny, {
    kind: "agent.completed";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    };
    id: string;
    createdAt: string;
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    };
    readAt: string | null;
}, {
    kind: "agent.completed";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    };
    id: string;
    createdAt: string;
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    };
    readAt: string | null;
}>;
type TaskNotification = Omit<Required<z.output<typeof taskNotificationSchema>>, 'source' | 'action'> & {
    source: Required<z.output<typeof notificationSourceSchema>>;
    action: Required<NonNullable<z.output<typeof userNotificationSchema>['action']>>;
};
export declare const agentOutputOriginSchema: z.ZodObject<{
    type: z.ZodLiteral<"agent_output">;
    deliveryId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "agent_output";
    deliveryId: string;
}, {
    type: "agent_output";
    deliveryId: string;
}>;
export declare const userNotificationSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<"agent.completed">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"scheduled_task">;
        taskId: z.ZodString;
        executionId: z.ZodString;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    }, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    }>;
    createdAt: z.ZodString;
    readAt: z.ZodNullable<z.ZodString>;
    action: z.ZodObject<{
        type: z.ZodLiteral<"open_conversation">;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodNullable<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }>;
}, "strict", z.ZodTypeAny, {
    kind: "agent.completed";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    };
    id: string;
    createdAt: string;
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    };
    readAt: string | null;
}, {
    kind: "agent.completed";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    };
    id: string;
    createdAt: string;
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
    };
    readAt: string | null;
}>, z.ZodObject<{
    id: z.ZodString;
    createdAt: z.ZodString;
    readAt: z.ZodNullable<z.ZodString>;
} & {
    kind: z.ZodLiteral<"agent.output">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"agent_output">;
        deliveryId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "agent_output";
        deliveryId: string;
    }, {
        type: "agent_output";
        deliveryId: string;
    }>;
    titles: z.ZodArray<z.ZodString, "many">;
    action: z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"open_conversation">;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodNullable<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }, {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    }>>;
}, "strict", z.ZodTypeAny, {
    kind: "agent.output";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    } | null;
    id: string;
    createdAt: string;
    source: {
        type: "agent_output";
        deliveryId: string;
    };
    readAt: string | null;
    titles: string[];
}, {
    kind: "agent.output";
    action: {
        type: "open_conversation";
        assistantId: string;
        conversationId: string;
        threadId: string | null;
    } | null;
    id: string;
    createdAt: string;
    source: {
        type: "agent_output";
        deliveryId: string;
    };
    readAt: string | null;
    titles: string[];
}>]>;
export type UserNotification = TaskNotification | {
    id: string;
    kind: 'agent.output';
    createdAt: string;
    readAt: string | null;
    source: Required<z.output<typeof agentOutputOriginSchema>>;
    titles: string[];
    action: OpenConversationAction | null;
};
export declare const notificationSnapshotSchema: z.ZodObject<{
    supported: z.ZodLiteral<true>;
    version: z.ZodString;
    announcements: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
        severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
        clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("web" | "desktop")[], ("web" | "desktop")[]>;
        startsAt: z.ZodString;
        expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            type: z.ZodLiteral<"link">;
            label: z.ZodString;
            url: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            type: "link";
            label: string;
            url: string;
        }, {
            type: "link";
            label: string;
            url: string;
        }>>>;
    } & {
        id: z.ZodString;
        status: z.ZodEnum<["draft", "published", "withdrawn"]>;
        revision: z.ZodNumber;
        createdAt: z.ZodString;
        dismissedAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        status: "draft" | "published" | "withdrawn";
        revision: number;
        title: string;
        body: string;
        category: "general" | "maintenance" | "model_retirement";
        severity: "info" | "important";
        clients: ("web" | "desktop")[];
        startsAt: string;
        expiresAt: string | null;
        action: {
            type: "link";
            label: string;
            url: string;
        } | null;
        id: string;
        createdAt: string;
        dismissedAt: string | null;
    }, {
        status: "draft" | "published" | "withdrawn";
        revision: number;
        title: string;
        body: string;
        clients: ("web" | "desktop")[];
        startsAt: string;
        id: string;
        createdAt: string;
        category?: "general" | "maintenance" | "model_retirement" | undefined;
        severity?: "info" | "important" | undefined;
        expiresAt?: string | null | undefined;
        action?: {
            type: "link";
            label: string;
            url: string;
        } | null | undefined;
        dismissedAt?: string | null | undefined;
    }>, "many">;
    notifications: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodLiteral<"agent.completed">;
        source: z.ZodObject<{
            type: z.ZodLiteral<"scheduled_task">;
            taskId: z.ZodString;
            executionId: z.ZodString;
            assistantId: z.ZodString;
            conversationId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        }, {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        }>;
        createdAt: z.ZodString;
        readAt: z.ZodNullable<z.ZodString>;
        action: z.ZodObject<{
            type: z.ZodLiteral<"open_conversation">;
            assistantId: z.ZodString;
            conversationId: z.ZodString;
            threadId: z.ZodNullable<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        }, {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        }>;
    }, "strict", z.ZodTypeAny, {
        kind: "agent.completed";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        };
        id: string;
        createdAt: string;
        source: {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        };
        readAt: string | null;
    }, {
        kind: "agent.completed";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        };
        id: string;
        createdAt: string;
        source: {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        };
        readAt: string | null;
    }>, z.ZodObject<{
        id: z.ZodString;
        createdAt: z.ZodString;
        readAt: z.ZodNullable<z.ZodString>;
    } & {
        kind: z.ZodLiteral<"agent.output">;
        source: z.ZodObject<{
            type: z.ZodLiteral<"agent_output">;
            deliveryId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "agent_output";
            deliveryId: string;
        }, {
            type: "agent_output";
            deliveryId: string;
        }>;
        titles: z.ZodArray<z.ZodString, "many">;
        action: z.ZodNullable<z.ZodObject<{
            type: z.ZodLiteral<"open_conversation">;
            assistantId: z.ZodString;
            conversationId: z.ZodString;
            threadId: z.ZodNullable<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        }, {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        }>>;
    }, "strict", z.ZodTypeAny, {
        kind: "agent.output";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        } | null;
        id: string;
        createdAt: string;
        source: {
            type: "agent_output";
            deliveryId: string;
        };
        readAt: string | null;
        titles: string[];
    }, {
        kind: "agent.output";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        } | null;
        id: string;
        createdAt: string;
        source: {
            type: "agent_output";
            deliveryId: string;
        };
        readAt: string | null;
        titles: string[];
    }>]>, "many">;
    hasMoreAnnouncements: z.ZodBoolean;
    hasMoreNotifications: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    supported: true;
    version: string;
    announcements: {
        status: "draft" | "published" | "withdrawn";
        revision: number;
        title: string;
        body: string;
        category: "general" | "maintenance" | "model_retirement";
        severity: "info" | "important";
        clients: ("web" | "desktop")[];
        startsAt: string;
        expiresAt: string | null;
        action: {
            type: "link";
            label: string;
            url: string;
        } | null;
        id: string;
        createdAt: string;
        dismissedAt: string | null;
    }[];
    notifications: ({
        kind: "agent.completed";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        };
        id: string;
        createdAt: string;
        source: {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        };
        readAt: string | null;
    } | {
        kind: "agent.output";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        } | null;
        id: string;
        createdAt: string;
        source: {
            type: "agent_output";
            deliveryId: string;
        };
        readAt: string | null;
        titles: string[];
    })[];
    hasMoreAnnouncements: boolean;
    hasMoreNotifications: boolean;
}, {
    supported: true;
    version: string;
    announcements: {
        status: "draft" | "published" | "withdrawn";
        revision: number;
        title: string;
        body: string;
        clients: ("web" | "desktop")[];
        startsAt: string;
        id: string;
        createdAt: string;
        category?: "general" | "maintenance" | "model_retirement" | undefined;
        severity?: "info" | "important" | undefined;
        expiresAt?: string | null | undefined;
        action?: {
            type: "link";
            label: string;
            url: string;
        } | null | undefined;
        dismissedAt?: string | null | undefined;
    }[];
    notifications: ({
        kind: "agent.completed";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        };
        id: string;
        createdAt: string;
        source: {
            type: "scheduled_task";
            taskId: string;
            executionId: string;
            assistantId: string;
            conversationId: string;
        };
        readAt: string | null;
    } | {
        kind: "agent.output";
        action: {
            type: "open_conversation";
            assistantId: string;
            conversationId: string;
            threadId: string | null;
        } | null;
        id: string;
        createdAt: string;
        source: {
            type: "agent_output";
            deliveryId: string;
        };
        readAt: string | null;
        titles: string[];
    })[];
    hasMoreAnnouncements: boolean;
    hasMoreNotifications: boolean;
}>;
export type NotificationSnapshot = Omit<Required<z.output<typeof notificationSnapshotSchema>>, 'announcements' | 'notifications'> & {
    announcements: Announcement[];
    notifications: UserNotification[];
};
export declare const notificationChangeSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"sync.required">;
    eventId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "sync.required";
    schemaVersion: 1;
    eventId: string;
}, {
    type: "sync.required";
    schemaVersion: 1;
    eventId: string;
}>;
export declare const notificationOutboxPayloadSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"changed">;
}, "strict", z.ZodTypeAny, {
    type: "changed";
}, {
    type: "changed";
}>, z.ZodObject<{
    type: z.ZodLiteral<"agent.output.dispatch">;
    deliveryId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "agent.output.dispatch";
    deliveryId: string;
}, {
    type: "agent.output.dispatch";
    deliveryId: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"announcement.scheduled">;
    announcementId: z.ZodString;
    revision: z.ZodNumber;
    phase: z.ZodEnum<["start", "expiry"]>;
}, "strict", z.ZodTypeAny, {
    type: "announcement.scheduled";
    revision: number;
    announcementId: string;
    phase: "start" | "expiry";
}, {
    type: "announcement.scheduled";
    revision: number;
    announcementId: string;
    phase: "start" | "expiry";
}>, z.ZodObject<{
    type: z.ZodLiteral<"agent.completed">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"scheduled_task">;
        taskId: z.ZodString;
        executionId: z.ZodString;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
    } & {
        threadId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
        threadId?: string | undefined;
    }, {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
        threadId?: string | undefined;
    }>;
}, "strict", z.ZodTypeAny, {
    type: "agent.completed";
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
        threadId?: string | undefined;
    };
}, {
    type: "agent.completed";
    source: {
        type: "scheduled_task";
        taskId: string;
        executionId: string;
        assistantId: string;
        conversationId: string;
        threadId?: string | undefined;
    };
}>]>;
export type NotificationOutboxPayload = z.output<typeof notificationOutboxPayloadSchema>;
export type NotificationDeliveryState = 'pending' | 'accepted' | 'delivered' | 'failed' | 'unknown' | 'cancelled';
export type NotificationDestination = {
    type: 'in_app';
    tenantId: string;
    userId: string;
} | {
    type: 'external_identity';
    tenantId: string;
    userId: string;
    integrationId: string;
    bindingId: string;
    bindingRevision: number;
};
export declare function parseAnnouncement(value: unknown): Announcement;
export declare function parseOpenConversationAction(value: unknown): OpenConversationAction;
export declare function parseUserNotification(value: unknown): UserNotification;
export declare function parseNotificationSnapshot(value: unknown): NotificationSnapshot;
export {};
