export interface FileStorageOption {
    dest: string | CallableFunction;
    provider?: string;
    prefix?: string;
    filename?: string | CallableFunction;
}
export interface FileSystem {
    rootPath: string;
    baseUrl?: string;
}
export declare enum FileStorageProviderEnum {
    LOCAL = "LOCAL"
}
export interface UploadedFile {
    fieldname: string;
    key: string;
    originalname: string;
    size: number;
    encoding?: string;
    mimetype?: string;
    filename: string;
    url: string;
    path: string;
}
export interface S3FileStorageProviderConfig {
    aws_access_key_id?: string;
    aws_secret_access_key?: string;
    aws_default_region?: string;
    aws_bucket?: string;
    aws_endpoint?: string;
}
