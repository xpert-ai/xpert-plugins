import { JsonSchema7TypeUnion } from 'zod-to-json-schema';
import { I18nObject, TSelectOption } from '../types';
import { TXpertAttachmentType, XpertParameterTypeEnum } from './xpert.model';
export type TErrorHandling = {
    type?: null | 'defaultValue' | 'failBranch';
    defaultValue?: {
        content?: string;
    } & Record<string, any>;
    failBranch?: string;
};
export declare enum ApiAuthType {
    /**
     * Enum class for api provider auth type.
     */
    NONE = "none",
    API_KEY = "api_key",
    BASIC = "basic"
}
/**
 * Reference variable (parameter)
 */
export type TXpertRefParameter = {
    type?: XpertParameterTypeEnum;
    name: string;
    optional?: boolean;
    /**
     * Referencing other variable
     */
    variable?: string;
};
/**
 * Embedding status of an entity, such as an bi indicator or kb document.
 */
export declare enum EmbeddingStatusEnum {
    PROCESSING = "processing",
    SUCCESS = "success",
    FAILED = "failed",
    REQUIRED = "required"
}
export declare const Attachment_Type_Options: TSelectOption<string, TXpertAttachmentType>[];
export type JsonSchemaUIDependency = string | {
    name: string;
    alias?: string;
    source?: 'model' | 'context';
};
export type JsonSchemaUIVisibilityCondition = {
    name: string;
    source?: 'model' | 'context';
    value?: unknown;
    values?: unknown[];
    exists?: boolean;
    not?: boolean;
};
export type JsonSchemaUIExtensions = {
    /**
     * Field title used by generic JSON-schema forms.
     */
    title?: I18nObject | string;
    /**
     * Field description used by generic JSON-schema forms.
     */
    description?: I18nObject | string;
    /**
     * UI component variant, or custom component name
     */
    component?: 'textarea' | 'select' | 'radio' | 'checkbox' | 'switch' | 'password' | string;
    /**
     * UI component display span (for grid layouts)
     */
    span?: number;
    /**
     * UI component column count (for grid layouts)
     */
    cols?: number;
    /**
     * Additional inputs for the Custom UI component
     */
    inputs?: Record<string, unknown>;
    /**
     * Whether this component supports selecting LangGraph state variables
     */
    variable?: boolean;
    enumLabels?: Record<string, I18nObject | string>;
    styles?: Record<string, string>;
    /**
     * Help url for this field
     */
    help?: I18nObject;
    /**
     * Field dependencies
     */
    depends?: JsonSchemaUIDependency[];
    /**
     * Field visibility conditions evaluated against the current form model or explicit context.
     */
    visibleWhen?: JsonSchemaUIVisibilityCondition | JsonSchemaUIVisibilityCondition[];
    /**
     * Whether multiple values can be selected (for select component)
     */
    multiple?: boolean;
    /**
     * Options values url for remote select component
     */
    selectUrl?: string;
    revealable?: boolean;
};
type JsonSchema7Meta = {
    title?: I18nObject;
    default?: any;
    description?: I18nObject;
    markdownDescription?: I18nObject;
    /**
     * UI schema extensions
     */
    'x-ui'?: JsonSchemaUIExtensions;
};
export type JsonSchemaObjectType = {
    type: 'object';
    /** Display title for a configuration form, including a plugin MCP configuration tab. */
    title?: I18nObject;
    properties: Record<string, JsonSchema7Type>;
    additionalProperties?: boolean | JsonSchema7Type;
    required?: string[];
};
type JsonSchema7Type = (JsonSchema7TypeUnion | JsonSchemaObjectType) & JsonSchema7Meta;
export {};
