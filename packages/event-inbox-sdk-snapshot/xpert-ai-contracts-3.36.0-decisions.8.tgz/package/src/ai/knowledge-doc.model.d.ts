import type { IKnowledgeDocumentTag } from './knowledge-tag.model';
import type { KnowledgeChunkLanguageHint } from './knowledge-chunking.model';
import type { KnowledgeQuestionGenerationConfig } from './knowledge-question.model';
import type { KnowledgeTableMetadata } from './knowledge-table.model';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IIntegration } from '../integration.model';
import { IStorageFile } from '../storage-file.model';
import { IKnowledgeDocumentPage } from './knowledge-doc-page.model';
import { IKnowledgebaseTask } from './knowledgebase-task.model';
import { IKnowledgebase, KBMetadataFieldDef } from './knowledgebase.model';
import { TRagWebOptions } from './rag-web';
import { DocumentAnalysisMetadata, IKnowledgeDocumentChunk } from './knowledge-doc-chunk.model';
import { DocumentSourceProviderCategoryEnum } from './knowledge-pipeline';
import { TCopilotModel } from './copilot-model.model';
import { I18nObject } from '../types';
export type DocumentParserConfig = {
    /** Optional business guidance; an empty value uses the default table metadata prompt. */
    tableMetadataRequirements?: string;
    /** Additional cl100k_base token cap for text retrieval chunks; 0 disables it. Context parents are retained. */
    maxChunkTokens?: number;
    /** Public natural-language boundary hint; absence means auto. */
    chunkLanguageHint?: KnowledgeChunkLanguageHint;
    questionGeneration?: KnowledgeQuestionGenerationConfig;
    pages?: number[][];
    replaceWhitespace?: boolean;
    removeSensitive?: boolean;
    textSplitterType?: string;
    /** Ordered literal separators. Unlike the legacy plugin string, commas need no escaping. */
    separators?: string[];
    textSplitter?: {
        [key: string]: unknown;
    };
    transformerType?: string;
    transformerIntegration?: string;
    transformer?: {
        [key: string]: unknown;
    };
    imageUnderstandingType?: string;
    /** False is an explicit opt-out; absence retains legacy per-format defaults. */
    imageUnderstandingEnabled?: boolean;
    imageUnderstandingIntegration?: string;
    imageUnderstanding?: {
        [key: string]: unknown;
    };
    imageUnderstandingModel?: TCopilotModel;
};
export type DocumentTextParserConfig = DocumentParserConfig & {
    delimiter?: string;
    chunkSize?: number | null;
    chunkOverlap?: number | null;
};
export type DocumentChunkSplitOptions = {
    /** Ordered splitting priorities. An empty list splits only at maxChars; takes precedence over separator. */
    separators?: string[];
    /** Legacy single separator, used when separators is absent. */
    separator?: string;
    /** Maximum character count; this splitter does not count tokens. */
    maxChars?: number;
};
export type DocumentParentChildParserConfig = {
    parent: DocumentChunkSplitOptions & {
        mode?: 'paragraph' | 'full';
    };
    child: DocumentChunkSplitOptions;
};
export type SpreadsheetInterpretation = 'records' | 'form_document';
export type SpreadsheetContextUnit = 'row' | 'sheet' | 'workbook';
export type SpreadsheetOversizePolicy = 'sheet' | 'reject';
export type SpreadsheetOutputFormat = 'anchored_markdown';
/**
 * Spreadsheet-specific behavior used by the platform default parser.
 * Custom document transformers take precedence over this configuration.
 */
export type DocumentSpreadsheetParserConfig = {
    /** Native Excel record parsing only. Absence preserves the legacy first-row header behavior. */
    firstRowAsHeader?: boolean;
    interpretation?: SpreadsheetInterpretation;
    contextUnit?: SpreadsheetContextUnit;
    oversizePolicy?: SpreadsheetOversizePolicy;
    maxChunkTokens?: number;
    includeSheets?: string[];
    includeHiddenSheets?: boolean;
    preserveMergedCells?: boolean;
    emitCellAnchors?: boolean;
    outputFormat?: SpreadsheetOutputFormat;
};
export type DocumentSheetParserConfig = DocumentParserConfig & {
    fields?: string[];
    indexedFields?: string[];
    spreadsheet?: DocumentSpreadsheetParserConfig;
};
/**
 * Import Type:
 * - file: local file
 * - web: web document
 * ...
 */
export declare enum DocumentTypeEnum {
    /**
     * Folder, parent of other documents
     */
    FOLDER = "folder",
    /**
     * Local files
     * @deprecated use DocumentSourceProviderCategoryEnum local file type instead
     */
    FILE = "file"
}
export declare const KDocumentSourceType: {
    FOLDER: DocumentTypeEnum.FOLDER;
    FILE: DocumentTypeEnum.FILE;
    LocalFile: DocumentSourceProviderCategoryEnum.LocalFile;
    FileSystem: DocumentSourceProviderCategoryEnum.FileSystem;
    OnlineDocument: DocumentSourceProviderCategoryEnum.OnlineDocument;
    WebCrawl: DocumentSourceProviderCategoryEnum.WebCrawl;
    Database: DocumentSourceProviderCategoryEnum.Database;
};
/**
 * Document type category, determine how to process the document.
 */
export declare enum KBDocumentCategoryEnum {
    Text = "text",
    Image = "image",
    Audio = "audio",
    Video = "video",
    Sheet = "sheet",
    Other = "other"
}
export declare enum KBDocumentStatusEnum {
    WAITING = "waiting",
    VALIDATE = "validate",
    RUNNING = "running",
    TRANSFORMED = "transformed",
    SPLITTED = "splitted",
    UNDERSTOOD = "understood",
    EMBEDDING = "embedding",
    CANCEL = "cancel",
    FINISH = "finish",
    ERROR = "error"
}
export type KnowledgeDocumentIncrementalSyncMode = 'incremental' | 'full' | 'skipped';
/** `rechunk` reuses the saved pre-split transformer output and never invokes the converter. */
export type KnowledgeDocumentProcessingMode = 'full' | 'rechunk';
/** Converter identity included in fingerprints so credentials/config changes invalidate stale snapshots. */
export type KnowledgeDocumentTransformerIdentity = {
    provider: string;
    integrationId?: string | null;
    config?: {
        [key: string]: unknown;
    } | null;
};
/** Integrity-checked reference to the pre-split converter output used by rechunk processing. */
export type KnowledgeDocumentTransformSnapshotRef = {
    schemaVersion: 1;
    filePath: string;
    manifestPath: string;
    sha256: string;
    size: number;
    itemCount: number;
    chunkCount: number;
    transformFingerprint: string;
    sourceHash?: string | null;
    transformer: KnowledgeDocumentTransformerIdentity;
    createdAt: string;
};
/** Reference to the immutable, paged layout snapshot consumed by the analysis-preview API. */
export type KnowledgeDocumentAnalysisSnapshotRef = {
    schemaVersion: 1;
    manifestPath: string;
    manifestSha256: string;
    manifestSize: number;
    transformFingerprint: string;
    sourceHash?: string | null;
    provider: string;
    engine?: string;
    pageCount: number;
    createdAt: string;
};
/** Server-computed actions available for a document under its current source and converter fingerprint. */
export type KnowledgeDocumentReprocessCapabilities = {
    full: true;
    rechunk: {
        available: boolean;
        reason?: 'missing' | 'stale' | 'corrupt';
        snapshot?: KnowledgeDocumentTransformSnapshotRef;
    };
};
export type KnowledgeDocumentLastIncrementalSync = {
    mode: KnowledgeDocumentIncrementalSyncMode;
    total: number;
    skipped: number;
    added: number;
    updated: number;
    deleted: number;
    embeddingTokens: number;
    processedAt: string;
};
export type TDocumentWebOptions = TRagWebOptions & {};
export type TDocSourceConfig = {
    key?: string;
};
export type TKnowledgeDocument = {
    disabled?: boolean;
    /** Soft-delete marker; ordinary read paths exclude these documents. */
    deletedAt?: Date | null;
    /** Hard-delete writer gate. A pending document is never eligible for read or publication. */
    hardDeletePendingAt?: Date | null;
    /** Monotonic fence captured by every document-derived writer. */
    publicationEpoch?: number;
    knowledgebaseId?: string;
    /**
     * @deprecated use fileUrl instead
     */
    storageFileId?: string;
    /**
     * @deprecated use fileUrl instead
     */
    storageFile?: IStorageFile;
    /**
     * thumbnail base64 string
     */
    thumbnail?: string;
    /**
     * default parser ID
     * @deprecated unused
     */
    parserId: string;
    parserConfig: DocumentTextParserConfig & Partial<DocumentSheetParserConfig>;
    /**
     * where dose this document come from
     */
    sourceType?: DocumentSourceProviderCategoryEnum | DocumentTypeEnum;
    sourceConfig?: TDocSourceConfig;
    /**
     * Stable source identity used for ingestion-time incremental sync.
     */
    sourceKey?: string | null;
    /**
     * Stable hash of the original source bytes or external source content.
     */
    sourceHash?: string | null;
    /**
     * Stable hash of sourceHash and parser/source processing configuration.
     */
    processingHash?: string | null;
    /**
     * Stable aggregate hash of the ordered processed chunks.
     */
    contentHash?: string | null;
    /**
     * Optimistic-lock version for user edits.
     */
    version?: number;
    /**
     * document type category
     */
    category?: KBDocumentCategoryEnum | null;
    /**
     * Local file extension or Web doc provider
     */
    type: string;
    /**
     * file name or web url
     */
    name: string;
    /**
     * where does it store
     */
    filePath: string;
    fileUrl?: string;
    /**
     * Folder path in server for this document file.
     * Init it in creating document entity.
     */
    folder?: string;
    size?: string;
    mimeType?: string;
    tokenNum?: number | null;
    chunkNum?: number | null;
    progress?: number | null;
    /**
     * process message
     */
    processMsg?: string | null;
    processBeginAt?: Date | null;
    processDuation?: number | null;
    processDuration?: number | null;
    /**
     * is it validate (0: wasted，1: validate)
     */
    status?: KBDocumentStatusEnum;
    /**
     * The background job id
     */
    jobId?: string;
    /** Server-owned pipeline attempt allowed to update this document on dispatch failure. */
    processingExecutionId?: string | null;
    options?: TDocumentWebOptions;
    integrationId?: string;
    integration?: IIntegration;
    /**
     * @deprecated use chunks instead
     */
    pages?: IKnowledgeDocumentPage[];
    chunks?: IKnowledgeDocumentChunk[];
    tasks?: IKnowledgebaseTask[];
};
/**
 * Document, include file, web pages, folder, virtual, etc.
 */
export interface IKnowledgeDocument<T extends KnowledgeDocumentMetadata = KnowledgeDocumentMetadata> extends TKnowledgeDocument, IBasePerTenantAndOrganizationEntityModel {
    parent?: IKnowledgeDocument | null;
    children?: IKnowledgeDocument[];
    /** Existing manual and automatic associations, included when requested for display. */
    tagAssignments?: IKnowledgeDocumentTag[];
    knowledgebase?: IKnowledgebase;
    draft?: TKnowledgeDocument;
    metadata?: T;
}
/**
 * System built-in standard document Metadata structure
 */
export interface StandardDocumentMetadata {
    originalFileName?: string;
    originalFileSize?: string | null;
    uploadTime?: string;
    lastUpdatedTime?: string;
    source?: string;
    segmentRule?: string;
    segmentLength?: number;
    averageSegmentLength?: string;
    segmentCount?: number;
    recallRate?: string;
    embedTime?: string;
    embedCost?: string | null;
    tokens?: number;
    lastIncrementalSync?: KnowledgeDocumentLastIncrementalSync;
}
/** Page coverage reported by the parser and completed by the shared image-understanding stage. */
export type DocumentParserDiagnostics = {
    schemaVersion: 1;
    pages: {
        page: number;
        status: 'text' | 'blank' | 'needs-ocr' | 'recognized';
        imagePaths: string[];
    }[];
};
export type KnowledgeImageUnderstandingWarning = {
    type: 'image_understanding_skipped' | 'image_understanding_failed';
    message: string;
    assetCount?: number;
    imagePath?: string;
    imageUrl?: string;
    parentChunkId?: string;
};
export interface KnowledgeDocumentMetadata extends StandardDocumentMetadata {
    /** Server-owned identity and label of the last completed document conversion. */
    parser?: string;
    parserLabel?: I18nObject;
    parserDiagnostics?: DocumentParserDiagnostics;
    imageUnderstandingWarnings?: KnowledgeImageUnderstandingWarning[];
    /** Server-owned generated table descriptions and publication state. */
    tableMetadata?: KnowledgeTableMetadata;
    /** Existing source summary, available to optional document classifiers. */
    summary?: string;
    /** Ownership is independent of visibility in the document browser. */
    systemManaged?: boolean;
    systemManagedType?: string;
    transformSnapshot?: KnowledgeDocumentTransformSnapshotRef;
    analysisSnapshot?: KnowledgeDocumentAnalysisSnapshotRef;
    documentAnalysis?: DocumentAnalysisMetadata;
    [key: string]: any;
}
export declare const KNOWLEDGE_DOCUMENT_AGENT_WRITER_TYPE = "agent-writer";
/** Agent publications are inspectable; internal Wiki/FAQ backing indexes stay hidden. */
export declare function isKnowledgeDocumentVisible(metadata?: KnowledgeDocumentMetadata | null): boolean;
export interface IKnowledgeDocumentCreateInput extends IKnowledgeDocument, IBasePerTenantAndOrganizationEntityModel {
}
export interface IKnowledgeDocumentUpdateInput extends Partial<IKnowledgeDocumentCreateInput> {
    id?: string;
}
export interface IKnowledgeDocumentFindInput extends IBasePerTenantAndOrganizationEntityModel, IKnowledgeDocument {
}
export declare function isDocumentSheet(type: string): boolean;
export declare function isImageType(type: string): boolean;
export declare function isVideoType(type: string): boolean;
export declare function isAudioType(type: string): boolean;
export declare function classificateDocumentCategory(entity: Partial<IKnowledgeDocument>): KBDocumentCategoryEnum;
/**
 * System standard Metadata field definition constants
 * It can be used for rendering, validation, sorting, displaying descriptions, etc.
 */
export declare const STANDARD_METADATA_FIELDS: {
    group: I18nObject;
    fields: KBMetadataFieldDef[];
}[];
export type StandardMetadataFieldKey = (typeof STANDARD_METADATA_FIELDS)[number]['fields'][number]['key'];
/** Bulk import keeps the legacy document array valid; tags apply to the whole batch. */
export type KnowledgeDocumentBulkCreateInput = Partial<IKnowledgeDocument>[] | {
    documents: Partial<IKnowledgeDocument>[];
    tagIds: string[];
};
