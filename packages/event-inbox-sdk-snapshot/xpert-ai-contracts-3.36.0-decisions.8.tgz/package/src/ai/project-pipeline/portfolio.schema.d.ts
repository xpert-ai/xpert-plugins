import { z } from 'zod/v3';
export declare const projectPipelinePortfolioInputSchema: z.ZodObject<{
    projectIds: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
    window: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        from: string;
        to: string;
    }, {
        from: string;
        to: string;
    }>, {
        from: string;
        to: string;
    }, {
        from: string;
        to: string;
    }>;
}, "strict", z.ZodTypeAny, {
    window: {
        from: string;
        to: string;
    };
    projectIds: string[];
}, {
    window: {
        from: string;
        to: string;
    };
    projectIds: string[];
}>;
export declare const projectPipelinePortfolioSchema: z.ZodObject<{
    snapshotAt: z.ZodString;
    window: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        from: string;
        to: string;
    }, {
        from: string;
        to: string;
    }>, {
        from: string;
        to: string;
    }, {
        from: string;
        to: string;
    }>;
    selectionScope: z.ZodLiteral<"explicit_authorized_projects">;
    totals: z.ZodObject<Omit<{
        projectId: z.ZodString;
        snapshotAt: z.ZodString;
        businessScope: z.ZodLiteral<"current_rounds">;
        executionScope: z.ZodLiteral<"recorded_history_started_in_window">;
        window: z.ZodEffects<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            from: string;
            to: string;
        }, {
            from: string;
            to: string;
        }>, {
            from: string;
            to: string;
        }, {
            from: string;
            to: string;
        }>;
        current: z.ZodObject<{
            work: z.ZodObject<{
                total: z.ZodNumber;
                completed: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                running: z.ZodNumber;
                blocked: z.ZodNumber;
                unknown: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }>;
            business: z.ZodObject<{
                total: z.ZodNumber;
                completed: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                running: z.ZodNumber;
                blocked: z.ZodNumber;
                unknown: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }>;
            needsYou: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        }, {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        }>;
        executions: z.ZodObject<{
            attempts: z.ZodObject<{
                total: z.ZodNumber;
                queued: z.ZodNumber;
                running: z.ZodNumber;
                waiting: z.ZodOptional<z.ZodNumber>;
                succeeded: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                unknown: z.ZodNumber;
                terminal: z.ZodNumber;
                successRate: z.ZodNullable<z.ZodNumber>;
                retries: z.ZodNumber;
                additionalAttempts: z.ZodOptional<z.ZodNumber>;
                unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }>;
            timing: z.ZodObject<{
                samples: z.ZodNumber;
                unavailable: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                meanMs: z.ZodNullable<z.ZodNumber>;
                medianMs: z.ZodNullable<z.ZodNumber>;
                p95Ms: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }>;
        }, "strict", z.ZodTypeAny, {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        }, {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        }>;
        coverage: z.ZodObject<{
            instances: z.ZodNumber;
            instancesWithoutCurrentRound: z.ZodNumber;
            recordedAttempts: z.ZodNumber;
            attemptsWithoutStartTime: z.ZodNumber;
            attemptsOutsideWindow: z.ZodNumber;
            sharedAcrossInstances: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        }, {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        }>;
        byInstance: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            templateKey: z.ZodString;
            templateVersion: z.ZodString;
            authority: z.ZodEnum<["provider", "platform"]>;
            runState: z.ZodString;
            current: z.ZodObject<{
                work: z.ZodObject<{
                    total: z.ZodNumber;
                    completed: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    running: z.ZodNumber;
                    blocked: z.ZodNumber;
                    unknown: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }>;
                business: z.ZodObject<{
                    total: z.ZodNumber;
                    completed: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    running: z.ZodNumber;
                    blocked: z.ZodNumber;
                    unknown: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }>;
                needsYou: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            }, {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            }>;
            executions: z.ZodObject<{
                attempts: z.ZodObject<{
                    total: z.ZodNumber;
                    queued: z.ZodNumber;
                    running: z.ZodNumber;
                    waiting: z.ZodOptional<z.ZodNumber>;
                    succeeded: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    unknown: z.ZodNumber;
                    terminal: z.ZodNumber;
                    successRate: z.ZodNullable<z.ZodNumber>;
                    retries: z.ZodNumber;
                    additionalAttempts: z.ZodOptional<z.ZodNumber>;
                    unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                }, {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                }>;
                timing: z.ZodObject<{
                    samples: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    meanMs: z.ZodNullable<z.ZodNumber>;
                    medianMs: z.ZodNullable<z.ZodNumber>;
                    p95Ms: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }>;
            }, "strict", z.ZodTypeAny, {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            }, {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            }>;
        }, "strict", z.ZodTypeAny, {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }, {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }>, "many">;
        byExecutor: z.ZodArray<z.ZodObject<{
            xpertId: z.ZodNullable<z.ZodString>;
            agentKey: z.ZodNullable<z.ZodString>;
            provider: z.ZodNullable<z.ZodString>;
            toolId: z.ZodNullable<z.ZodString>;
            serviceRef: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            attempts: z.ZodObject<{
                total: z.ZodNumber;
                queued: z.ZodNumber;
                running: z.ZodNumber;
                waiting: z.ZodOptional<z.ZodNumber>;
                succeeded: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                unknown: z.ZodNumber;
                terminal: z.ZodNumber;
                successRate: z.ZodNullable<z.ZodNumber>;
                retries: z.ZodNumber;
                additionalAttempts: z.ZodOptional<z.ZodNumber>;
                unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }>;
            timing: z.ZodObject<{
                samples: z.ZodNumber;
                unavailable: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                meanMs: z.ZodNullable<z.ZodNumber>;
                medianMs: z.ZodNullable<z.ZodNumber>;
                p95Ms: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }>;
        }, "strict", z.ZodTypeAny, {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }, {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }>, "many">;
        modelUsage: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"linked_native_llm_calls">;
            requestedExecutions: z.ZodNumber;
            executionsWithRecords: z.ZodNumber;
            truncated: z.ZodBoolean;
            rejectedRecords: z.ZodNumber;
            calls: z.ZodNumber;
            inputTokens: z.ZodNullable<z.ZodNumber>;
            outputTokens: z.ZodNullable<z.ZodNumber>;
            totalTokens: z.ZodNullable<z.ZodNumber>;
            unpricedCalls: z.ZodNumber;
            chargedPoints: z.ZodNullable<z.ZodNumber>;
            byModel: z.ZodArray<z.ZodObject<{
                provider: z.ZodString;
                model: z.ZodString;
                calls: z.ZodNumber;
                inputTokens: z.ZodNullable<z.ZodNumber>;
                outputTokens: z.ZodNullable<z.ZodNumber>;
                totalTokens: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }, {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        }, {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        }>>;
        queue: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"recorded_dispatch_outbox_created_in_window">;
            coverage: z.ZodObject<{
                recorded: z.ZodNumber;
                missingCreatedAt: z.ZodNumber;
                outsideWindow: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            }, {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            }>;
            total: z.ZodObject<{
                total: z.ZodNumber;
                dispatched: z.ZodNumber;
                queued: z.ZodNumber;
                unavailable: z.ZodNumber;
                dispatchWait: z.ZodObject<{
                    samples: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    meanMs: z.ZodNullable<z.ZodNumber>;
                    medianMs: z.ZodNullable<z.ZodNumber>;
                    p95Ms: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }>;
                pendingWait: z.ZodObject<{
                    samples: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    oldestMs: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                }, {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                }>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            }, {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            }>;
            bySource: z.ZodArray<z.ZodObject<{
                source: z.ZodEnum<["managed_operation", "provider_action"]>;
                metrics: z.ZodObject<{
                    total: z.ZodNumber;
                    dispatched: z.ZodNumber;
                    queued: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    dispatchWait: z.ZodObject<{
                        samples: z.ZodNumber;
                        unavailable: z.ZodNumber;
                        totalMs: z.ZodNullable<z.ZodNumber>;
                        meanMs: z.ZodNullable<z.ZodNumber>;
                        medianMs: z.ZodNullable<z.ZodNumber>;
                        p95Ms: z.ZodNullable<z.ZodNumber>;
                    }, "strict", z.ZodTypeAny, {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    }, {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    }>;
                    pendingWait: z.ZodObject<{
                        samples: z.ZodNumber;
                        totalMs: z.ZodNullable<z.ZodNumber>;
                        oldestMs: z.ZodNullable<z.ZodNumber>;
                    }, "strict", z.ZodTypeAny, {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    }, {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    }>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                }, {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                }>;
            }, "strict", z.ZodTypeAny, {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }, {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        }, {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        }>>;
        humanWait: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"observed_human_ready_intervals_intersecting_window">;
            intervals: z.ZodNumber;
            ongoing: z.ZodNumber;
            censored: z.ZodNumber;
            observedNodeMs: z.ZodNullable<z.ZodNumber>;
            observedUnionMs: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodObject<{
                snapshots: z.ZodNumber;
                missingEvents: z.ZodNumber;
                invalidEvents: z.ZodNumber;
                currentUntrackedNodes: z.ZodNumber;
                observedWindowMs: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            }, {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            }>;
        }, "strict", z.ZodTypeAny, {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        }, {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        }>>;
    }, "projectId" | "byInstance" | "queue" | "humanWait">, "strict", z.ZodTypeAny, {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
    }, {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
    }>;
    byProject: z.ZodArray<z.ZodObject<{
        projectId: z.ZodString;
        snapshotAt: z.ZodString;
        businessScope: z.ZodLiteral<"current_rounds">;
        executionScope: z.ZodLiteral<"recorded_history_started_in_window">;
        window: z.ZodEffects<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            from: string;
            to: string;
        }, {
            from: string;
            to: string;
        }>, {
            from: string;
            to: string;
        }, {
            from: string;
            to: string;
        }>;
        current: z.ZodObject<{
            work: z.ZodObject<{
                total: z.ZodNumber;
                completed: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                running: z.ZodNumber;
                blocked: z.ZodNumber;
                unknown: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }>;
            business: z.ZodObject<{
                total: z.ZodNumber;
                completed: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                running: z.ZodNumber;
                blocked: z.ZodNumber;
                unknown: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }, {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            }>;
            needsYou: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        }, {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        }>;
        executions: z.ZodObject<{
            attempts: z.ZodObject<{
                total: z.ZodNumber;
                queued: z.ZodNumber;
                running: z.ZodNumber;
                waiting: z.ZodOptional<z.ZodNumber>;
                succeeded: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                unknown: z.ZodNumber;
                terminal: z.ZodNumber;
                successRate: z.ZodNullable<z.ZodNumber>;
                retries: z.ZodNumber;
                additionalAttempts: z.ZodOptional<z.ZodNumber>;
                unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }>;
            timing: z.ZodObject<{
                samples: z.ZodNumber;
                unavailable: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                meanMs: z.ZodNullable<z.ZodNumber>;
                medianMs: z.ZodNullable<z.ZodNumber>;
                p95Ms: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }>;
        }, "strict", z.ZodTypeAny, {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        }, {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        }>;
        coverage: z.ZodObject<{
            instances: z.ZodNumber;
            instancesWithoutCurrentRound: z.ZodNumber;
            recordedAttempts: z.ZodNumber;
            attemptsWithoutStartTime: z.ZodNumber;
            attemptsOutsideWindow: z.ZodNumber;
            sharedAcrossInstances: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        }, {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        }>;
        byInstance: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            templateKey: z.ZodString;
            templateVersion: z.ZodString;
            authority: z.ZodEnum<["provider", "platform"]>;
            runState: z.ZodString;
            current: z.ZodObject<{
                work: z.ZodObject<{
                    total: z.ZodNumber;
                    completed: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    running: z.ZodNumber;
                    blocked: z.ZodNumber;
                    unknown: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }>;
                business: z.ZodObject<{
                    total: z.ZodNumber;
                    completed: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    running: z.ZodNumber;
                    blocked: z.ZodNumber;
                    unknown: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }, {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                }>;
                needsYou: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            }, {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            }>;
            executions: z.ZodObject<{
                attempts: z.ZodObject<{
                    total: z.ZodNumber;
                    queued: z.ZodNumber;
                    running: z.ZodNumber;
                    waiting: z.ZodOptional<z.ZodNumber>;
                    succeeded: z.ZodNumber;
                    failed: z.ZodNumber;
                    cancelled: z.ZodNumber;
                    unknown: z.ZodNumber;
                    terminal: z.ZodNumber;
                    successRate: z.ZodNullable<z.ZodNumber>;
                    retries: z.ZodNumber;
                    additionalAttempts: z.ZodOptional<z.ZodNumber>;
                    unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                }, {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                }>;
                timing: z.ZodObject<{
                    samples: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    meanMs: z.ZodNullable<z.ZodNumber>;
                    medianMs: z.ZodNullable<z.ZodNumber>;
                    p95Ms: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }>;
            }, "strict", z.ZodTypeAny, {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            }, {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            }>;
        }, "strict", z.ZodTypeAny, {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }, {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }>, "many">;
        byExecutor: z.ZodArray<z.ZodObject<{
            xpertId: z.ZodNullable<z.ZodString>;
            agentKey: z.ZodNullable<z.ZodString>;
            provider: z.ZodNullable<z.ZodString>;
            toolId: z.ZodNullable<z.ZodString>;
            serviceRef: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            attempts: z.ZodObject<{
                total: z.ZodNumber;
                queued: z.ZodNumber;
                running: z.ZodNumber;
                waiting: z.ZodOptional<z.ZodNumber>;
                succeeded: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
                unknown: z.ZodNumber;
                terminal: z.ZodNumber;
                successRate: z.ZodNullable<z.ZodNumber>;
                retries: z.ZodNumber;
                additionalAttempts: z.ZodOptional<z.ZodNumber>;
                unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }, {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            }>;
            timing: z.ZodObject<{
                samples: z.ZodNumber;
                unavailable: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                meanMs: z.ZodNullable<z.ZodNumber>;
                medianMs: z.ZodNullable<z.ZodNumber>;
                p95Ms: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }>;
        }, "strict", z.ZodTypeAny, {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }, {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }>, "many">;
        modelUsage: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"linked_native_llm_calls">;
            requestedExecutions: z.ZodNumber;
            executionsWithRecords: z.ZodNumber;
            truncated: z.ZodBoolean;
            rejectedRecords: z.ZodNumber;
            calls: z.ZodNumber;
            inputTokens: z.ZodNullable<z.ZodNumber>;
            outputTokens: z.ZodNullable<z.ZodNumber>;
            totalTokens: z.ZodNullable<z.ZodNumber>;
            unpricedCalls: z.ZodNumber;
            chargedPoints: z.ZodNullable<z.ZodNumber>;
            byModel: z.ZodArray<z.ZodObject<{
                provider: z.ZodString;
                model: z.ZodString;
                calls: z.ZodNumber;
                inputTokens: z.ZodNullable<z.ZodNumber>;
                outputTokens: z.ZodNullable<z.ZodNumber>;
                totalTokens: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }, {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        }, {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        }>>;
        queue: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"recorded_dispatch_outbox_created_in_window">;
            coverage: z.ZodObject<{
                recorded: z.ZodNumber;
                missingCreatedAt: z.ZodNumber;
                outsideWindow: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            }, {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            }>;
            total: z.ZodObject<{
                total: z.ZodNumber;
                dispatched: z.ZodNumber;
                queued: z.ZodNumber;
                unavailable: z.ZodNumber;
                dispatchWait: z.ZodObject<{
                    samples: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    meanMs: z.ZodNullable<z.ZodNumber>;
                    medianMs: z.ZodNullable<z.ZodNumber>;
                    p95Ms: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }, {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                }>;
                pendingWait: z.ZodObject<{
                    samples: z.ZodNumber;
                    totalMs: z.ZodNullable<z.ZodNumber>;
                    oldestMs: z.ZodNullable<z.ZodNumber>;
                }, "strict", z.ZodTypeAny, {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                }, {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                }>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            }, {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            }>;
            bySource: z.ZodArray<z.ZodObject<{
                source: z.ZodEnum<["managed_operation", "provider_action"]>;
                metrics: z.ZodObject<{
                    total: z.ZodNumber;
                    dispatched: z.ZodNumber;
                    queued: z.ZodNumber;
                    unavailable: z.ZodNumber;
                    dispatchWait: z.ZodObject<{
                        samples: z.ZodNumber;
                        unavailable: z.ZodNumber;
                        totalMs: z.ZodNullable<z.ZodNumber>;
                        meanMs: z.ZodNullable<z.ZodNumber>;
                        medianMs: z.ZodNullable<z.ZodNumber>;
                        p95Ms: z.ZodNullable<z.ZodNumber>;
                    }, "strict", z.ZodTypeAny, {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    }, {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    }>;
                    pendingWait: z.ZodObject<{
                        samples: z.ZodNumber;
                        totalMs: z.ZodNullable<z.ZodNumber>;
                        oldestMs: z.ZodNullable<z.ZodNumber>;
                    }, "strict", z.ZodTypeAny, {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    }, {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    }>;
                }, "strict", z.ZodTypeAny, {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                }, {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                }>;
            }, "strict", z.ZodTypeAny, {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }, {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        }, {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        }>>;
        humanWait: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"observed_human_ready_intervals_intersecting_window">;
            intervals: z.ZodNumber;
            ongoing: z.ZodNumber;
            censored: z.ZodNumber;
            observedNodeMs: z.ZodNullable<z.ZodNumber>;
            observedUnionMs: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodObject<{
                snapshots: z.ZodNumber;
                missingEvents: z.ZodNumber;
                invalidEvents: z.ZodNumber;
                currentUntrackedNodes: z.ZodNumber;
                observedWindowMs: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            }, {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            }>;
        }, "strict", z.ZodTypeAny, {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        }, {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        }>>;
    }, "strict", z.ZodTypeAny, {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        projectId: string;
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        byInstance: {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }[];
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
        queue?: {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        } | undefined;
        humanWait?: {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        } | undefined;
    }, {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        projectId: string;
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        byInstance: {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }[];
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
        queue?: {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        } | undefined;
        humanWait?: {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        } | undefined;
    }>, "many">;
    sharedAcrossProjects: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    snapshotAt: string;
    window: {
        from: string;
        to: string;
    };
    selectionScope: "explicit_authorized_projects";
    totals: {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
    };
    byProject: {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        projectId: string;
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        byInstance: {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }[];
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
        queue?: {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        } | undefined;
        humanWait?: {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        } | undefined;
    }[];
    sharedAcrossProjects: number;
}, {
    snapshotAt: string;
    window: {
        from: string;
        to: string;
    };
    selectionScope: "explicit_authorized_projects";
    totals: {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
    };
    byProject: {
        coverage: {
            instances: number;
            instancesWithoutCurrentRound: number;
            recordedAttempts: number;
            attemptsWithoutStartTime: number;
            attemptsOutsideWindow: number;
            sharedAcrossInstances: number;
        };
        projectId: string;
        current: {
            work: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            business: {
                unknown: number;
                blocked: number;
                failed: number;
                cancelled: number;
                running: number;
                completed: number;
                total: number;
            };
            needsYou: number;
        };
        executions: {
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
        };
        executionScope: "recorded_history_started_in_window";
        byExecutor: {
            provider: string | null;
            xpertId: string | null;
            agentKey: string | null;
            toolId: string | null;
            attempts: {
                unknown: number;
                failed: number;
                cancelled: number;
                running: number;
                succeeded: number;
                terminal: number;
                total: number;
                queued: number;
                successRate: number | null;
                retries: number;
                waiting?: number | undefined;
                additionalAttempts?: number | undefined;
                unclassifiedAttempts?: number | undefined;
            };
            timing: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            serviceRef?: string | null | undefined;
        }[];
        snapshotAt: string;
        businessScope: "current_rounds";
        window: {
            from: string;
            to: string;
        };
        byInstance: {
            title: string;
            id: string;
            current: {
                work: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                business: {
                    unknown: number;
                    blocked: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    completed: number;
                    total: number;
                };
                needsYou: number;
            };
            executions: {
                attempts: {
                    unknown: number;
                    failed: number;
                    cancelled: number;
                    running: number;
                    succeeded: number;
                    terminal: number;
                    total: number;
                    queued: number;
                    successRate: number | null;
                    retries: number;
                    waiting?: number | undefined;
                    additionalAttempts?: number | undefined;
                    unclassifiedAttempts?: number | undefined;
                };
                timing: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
            };
            templateKey: string;
            templateVersion: string;
            authority: "provider" | "platform";
            runState: string;
        }[];
        modelUsage?: {
            truncated: boolean;
            scope: "linked_native_llm_calls";
            calls: number;
            requestedExecutions: number;
            executionsWithRecords: number;
            rejectedRecords: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            unpricedCalls: number;
            chargedPoints: number | null;
            byModel: {
                provider: string;
                calls: number;
                inputTokens: number | null;
                outputTokens: number | null;
                totalTokens: number | null;
                model: string;
            }[];
        } | undefined;
        queue?: {
            coverage: {
                recorded: number;
                missingCreatedAt: number;
                outsideWindow: number;
            };
            scope: "recorded_dispatch_outbox_created_in_window";
            total: {
                unavailable: number;
                total: number;
                queued: number;
                dispatched: number;
                dispatchWait: {
                    unavailable: number;
                    samples: number;
                    totalMs: number | null;
                    meanMs: number | null;
                    medianMs: number | null;
                    p95Ms: number | null;
                };
                pendingWait: {
                    samples: number;
                    totalMs: number | null;
                    oldestMs: number | null;
                };
            };
            bySource: {
                source: "provider_action" | "managed_operation";
                metrics: {
                    unavailable: number;
                    total: number;
                    queued: number;
                    dispatched: number;
                    dispatchWait: {
                        unavailable: number;
                        samples: number;
                        totalMs: number | null;
                        meanMs: number | null;
                        medianMs: number | null;
                        p95Ms: number | null;
                    };
                    pendingWait: {
                        samples: number;
                        totalMs: number | null;
                        oldestMs: number | null;
                    };
                };
            }[];
        } | undefined;
        humanWait?: {
            coverage: {
                snapshots: number;
                missingEvents: number;
                invalidEvents: number;
                currentUntrackedNodes: number;
                observedWindowMs: number;
            };
            scope: "observed_human_ready_intervals_intersecting_window";
            intervals: number;
            ongoing: number;
            censored: number;
            observedNodeMs: number | null;
            observedUnionMs: number | null;
        } | undefined;
    }[];
    sharedAcrossProjects: number;
}>;
export type ProjectPipelinePortfolioInput = z.output<typeof projectPipelinePortfolioInputSchema>;
export type ProjectPipelinePortfolio = z.output<typeof projectPipelinePortfolioSchema>;
