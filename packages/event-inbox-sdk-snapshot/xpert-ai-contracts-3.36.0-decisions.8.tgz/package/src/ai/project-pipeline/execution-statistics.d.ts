import { z } from 'zod/v3';
export declare const pipelineAttemptCountsSchema: z.ZodObject<{
    total: z.ZodNumber;
    queued: z.ZodNumber;
    running: z.ZodNumber;
    waiting: z.ZodOptional<z.ZodNumber>;
    succeeded: z.ZodNumber;
    failed: z.ZodNumber;
    cancelled: z.ZodNumber;
    unknown: z.ZodNumber;
    terminal: z.ZodNumber;
    successRate: z.ZodNullable<z.ZodNumber>;
    retries: z.ZodNumber;
    additionalAttempts: z.ZodOptional<z.ZodNumber>;
    unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    unknown: number;
    failed: number;
    cancelled: number;
    running: number;
    succeeded: number;
    terminal: number;
    total: number;
    queued: number;
    successRate: number | null;
    retries: number;
    waiting?: number | undefined;
    additionalAttempts?: number | undefined;
    unclassifiedAttempts?: number | undefined;
}, {
    unknown: number;
    failed: number;
    cancelled: number;
    running: number;
    succeeded: number;
    terminal: number;
    total: number;
    queued: number;
    successRate: number | null;
    retries: number;
    waiting?: number | undefined;
    additionalAttempts?: number | undefined;
    unclassifiedAttempts?: number | undefined;
}>;
export declare const pipelineExecutionTimingSchema: z.ZodObject<{
    samples: z.ZodNumber;
    unavailable: z.ZodNumber;
    totalMs: z.ZodNullable<z.ZodNumber>;
    meanMs: z.ZodNullable<z.ZodNumber>;
    medianMs: z.ZodNullable<z.ZodNumber>;
    p95Ms: z.ZodNullable<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    unavailable: number;
    samples: number;
    totalMs: number | null;
    meanMs: number | null;
    medianMs: number | null;
    p95Ms: number | null;
}, {
    unavailable: number;
    samples: number;
    totalMs: number | null;
    meanMs: number | null;
    medianMs: number | null;
    p95Ms: number | null;
}>;
export declare const pipelineExecutorStatisticsSchema: z.ZodObject<{
    xpertId: z.ZodNullable<z.ZodString>;
    agentKey: z.ZodNullable<z.ZodString>;
    provider: z.ZodNullable<z.ZodString>;
    toolId: z.ZodNullable<z.ZodString>;
    serviceRef: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    attempts: z.ZodObject<{
        total: z.ZodNumber;
        queued: z.ZodNumber;
        running: z.ZodNumber;
        waiting: z.ZodOptional<z.ZodNumber>;
        succeeded: z.ZodNumber;
        failed: z.ZodNumber;
        cancelled: z.ZodNumber;
        unknown: z.ZodNumber;
        terminal: z.ZodNumber;
        successRate: z.ZodNullable<z.ZodNumber>;
        retries: z.ZodNumber;
        additionalAttempts: z.ZodOptional<z.ZodNumber>;
        unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    }, {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    }>;
    timing: z.ZodObject<{
        samples: z.ZodNumber;
        unavailable: z.ZodNumber;
        totalMs: z.ZodNullable<z.ZodNumber>;
        meanMs: z.ZodNullable<z.ZodNumber>;
        medianMs: z.ZodNullable<z.ZodNumber>;
        p95Ms: z.ZodNullable<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    }, {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    }>;
}, "strict", z.ZodTypeAny, {
    provider: string | null;
    xpertId: string | null;
    agentKey: string | null;
    toolId: string | null;
    attempts: {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    };
    timing: {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    };
    serviceRef?: string | null | undefined;
}, {
    provider: string | null;
    xpertId: string | null;
    agentKey: string | null;
    toolId: string | null;
    attempts: {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    };
    timing: {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    };
    serviceRef?: string | null | undefined;
}>;
export type PipelineAttemptFact = {
    id?: string;
    taskId: string;
    agentExecutionId?: string | null;
    invocationId?: string | null;
    xpertId?: string | null;
    agentKey?: string | null;
    runtimeProvider?: string;
    runtimeToolId?: string;
    runtimeServiceRef?: string;
    pipelineAttemptKind?: 'initial' | 'technical_retry';
    status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
    runtimeStatus?: string;
    invocationStatus?: string;
    runtimeStartedAt?: string | null;
    runtimeCompletedAt?: string | null;
};
export declare function pipelineAttemptCounts(facts: readonly PipelineAttemptFact[]): {
    total: number;
    queued: number;
    running: number;
    waiting: number;
    succeeded: number;
    failed: number;
    cancelled: number;
    unknown: number;
    terminal: number;
    successRate: number | null;
    retries: number;
    additionalAttempts: number;
    unclassifiedAttempts: number;
};
/** Only recorded, terminal runtime intervals contribute. Missing times are not zero-duration runs. */
export declare function pipelineExecutionTiming(facts: readonly PipelineAttemptFact[]): {
    samples: number;
    unavailable: number;
    totalMs: number | null;
    meanMs: number | null;
    medianMs: number | null;
    p95Ms: number | null;
};
export declare function pipelineExecutorStatistics(facts: readonly PipelineAttemptFact[]): {
    attempts: {
        total: number;
        queued: number;
        running: number;
        waiting: number;
        succeeded: number;
        failed: number;
        cancelled: number;
        unknown: number;
        terminal: number;
        successRate: number | null;
        retries: number;
        additionalAttempts: number;
        unclassifiedAttempts: number;
    };
    timing: {
        samples: number;
        unavailable: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    };
    xpertId: string | null;
    agentKey: string | null;
    provider: string | null;
    toolId: string | null;
    serviceRef: string | null;
}[];
