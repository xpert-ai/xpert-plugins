import { z } from 'zod/v3';
/** Portable node contract. Only the host executes installation; plugins supply immutable inputs. */
export declare const projectPluginDeploymentRefs: {
    readonly operation: "platform.plugin-deployment@1";
    readonly request: "platform.plugin-deployment-request@1";
    readonly receipt: "platform.plugin-deployment-receipt@1";
    readonly evidence: "platform.plugin-deployment-evidence@1";
};
export declare const projectPluginDeploymentRequestSchema: z.ZodObject<{
    target: z.ZodLiteral<"current-instance">;
    artifactId: z.ZodString;
    artifactVersionId: z.ZodString;
    sha256: z.ZodString;
    fileName: z.ZodString;
    packageName: z.ZodString;
    packageVersion: z.ZodString;
    allowReplace: z.ZodBoolean;
    allowRestart: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    sha256: string;
    target: "current-instance";
    artifactId: string;
    artifactVersionId: string;
    fileName: string;
    packageName: string;
    packageVersion: string;
    allowReplace: boolean;
    allowRestart: boolean;
}, {
    sha256: string;
    target: "current-instance";
    artifactId: string;
    artifactVersionId: string;
    fileName: string;
    packageName: string;
    packageVersion: string;
    allowReplace: boolean;
    allowRestart: boolean;
}>;
export declare const projectPluginDeploymentReceiptSchema: z.ZodObject<{
    operationId: z.ZodString;
    request: z.ZodObject<{
        target: z.ZodLiteral<"current-instance">;
        artifactId: z.ZodString;
        artifactVersionId: z.ZodString;
        sha256: z.ZodString;
        fileName: z.ZodString;
        packageName: z.ZodString;
        packageVersion: z.ZodString;
        allowReplace: z.ZodBoolean;
        allowRestart: z.ZodBoolean;
    }, "strict", z.ZodTypeAny, {
        sha256: string;
        target: "current-instance";
        artifactId: string;
        artifactVersionId: string;
        fileName: string;
        packageName: string;
        packageVersion: string;
        allowReplace: boolean;
        allowRestart: boolean;
    }, {
        sha256: string;
        target: "current-instance";
        artifactId: string;
        artifactVersionId: string;
        fileName: string;
        packageName: string;
        packageVersion: string;
        allowReplace: boolean;
        allowRestart: boolean;
    }>;
    approval: z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>;
    scopeKey: z.ZodString;
    runtimeRevision: z.ZodString;
    installed: z.ZodLiteral<true>;
    loaded: z.ZodLiteral<true>;
}, "strict", z.ZodTypeAny, {
    operationId: string;
    request: {
        sha256: string;
        target: "current-instance";
        artifactId: string;
        artifactVersionId: string;
        fileName: string;
        packageName: string;
        packageVersion: string;
        allowReplace: boolean;
        allowRestart: boolean;
    };
    approval: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    };
    scopeKey: string;
    runtimeRevision: string;
    installed: true;
    loaded: true;
}, {
    operationId: string;
    request: {
        sha256: string;
        target: "current-instance";
        artifactId: string;
        artifactVersionId: string;
        fileName: string;
        packageName: string;
        packageVersion: string;
        allowReplace: boolean;
        allowRestart: boolean;
    };
    approval: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    };
    scopeKey: string;
    runtimeRevision: string;
    installed: true;
    loaded: true;
}>;
export type ProjectPluginDeploymentRequest = z.output<typeof projectPluginDeploymentRequestSchema>;
export type ProjectPluginDeploymentReceipt = z.output<typeof projectPluginDeploymentReceiptSchema>;
