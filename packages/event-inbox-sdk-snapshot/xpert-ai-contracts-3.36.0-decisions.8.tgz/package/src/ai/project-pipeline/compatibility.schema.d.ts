import { z } from 'zod/v3';
/** Feature versions are exact protocols, not package semver or an implicit minimum version. */
export declare const projectPipelineHostRequirementsSchema: z.ZodObject<{
    protocol: z.ZodNumber;
    features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodNumber>, Record<string, number>, Record<string, number>>;
}, "strict", z.ZodTypeAny, {
    protocol: number;
    features: Record<string, number>;
}, {
    protocol: number;
    features: Record<string, number>;
}>;
export declare const projectPipelineHostCapabilitiesSchema: z.ZodObject<{
    protocols: z.ZodEffects<z.ZodArray<z.ZodNumber, "many">, number[], number[]>;
    features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodEffects<z.ZodArray<z.ZodNumber, "many">, number[], number[]>>, Record<string, number[]>, Record<string, number[]>>;
}, "strict", z.ZodTypeAny, {
    features: Record<string, number[]>;
    protocols: number[];
}, {
    features: Record<string, number[]>;
    protocols: number[];
}>;
export type ProjectPipelineHostRequirements = z.output<typeof projectPipelineHostRequirementsSchema>;
export type ProjectPipelineHostCapabilities = z.output<typeof projectPipelineHostCapabilitiesSchema>;
export interface ProjectPipelineCompatibilityIssue {
    code: 'HOST_PROTOCOL_UNSUPPORTED' | 'HOST_FEATURE_UNSUPPORTED';
    path: Array<string | number>;
    ref?: string;
}
