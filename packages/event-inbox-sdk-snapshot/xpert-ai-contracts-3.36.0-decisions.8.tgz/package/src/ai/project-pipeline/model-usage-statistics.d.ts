import { z } from 'zod/v3';
export declare const pipelineModelUsageStatisticsSchema: z.ZodObject<{
    scope: z.ZodLiteral<"linked_native_llm_calls">;
    requestedExecutions: z.ZodNumber;
    executionsWithRecords: z.ZodNumber;
    truncated: z.ZodBoolean;
    rejectedRecords: z.ZodNumber;
    calls: z.ZodNumber;
    inputTokens: z.ZodNullable<z.ZodNumber>;
    outputTokens: z.ZodNullable<z.ZodNumber>;
    totalTokens: z.ZodNullable<z.ZodNumber>;
    unpricedCalls: z.ZodNumber;
    chargedPoints: z.ZodNullable<z.ZodNumber>;
    byModel: z.ZodArray<z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
        calls: z.ZodNumber;
        inputTokens: z.ZodNullable<z.ZodNumber>;
        outputTokens: z.ZodNullable<z.ZodNumber>;
        totalTokens: z.ZodNullable<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        provider: string;
        calls: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        model: string;
    }, {
        provider: string;
        calls: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        model: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    truncated: boolean;
    scope: "linked_native_llm_calls";
    calls: number;
    requestedExecutions: number;
    executionsWithRecords: number;
    rejectedRecords: number;
    inputTokens: number | null;
    outputTokens: number | null;
    totalTokens: number | null;
    unpricedCalls: number;
    chargedPoints: number | null;
    byModel: {
        provider: string;
        calls: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        model: string;
    }[];
}, {
    truncated: boolean;
    scope: "linked_native_llm_calls";
    calls: number;
    requestedExecutions: number;
    executionsWithRecords: number;
    rejectedRecords: number;
    inputTokens: number | null;
    outputTokens: number | null;
    totalTokens: number | null;
    unpricedCalls: number;
    chargedPoints: number | null;
    byModel: {
        provider: string;
        calls: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        model: string;
    }[];
}>;
export type PipelineModelUsageStatistics = z.output<typeof pipelineModelUsageStatisticsSchema>;
/** Parsed ledger facts only. Request/metric identity is independent of task and parent execution links. */
export declare const pipelineModelUsageFactSchema: z.ZodObject<{
    originExecutionId: z.ZodString;
    providerScopeId: z.ZodString;
    requestId: z.ZodString;
    metricKey: z.ZodString;
    revision: z.ZodNumber;
    provider: z.ZodString;
    model: z.ZodString;
    promptTokens: z.ZodNullable<z.ZodNumber>;
    completionTokens: z.ZodNullable<z.ZodNumber>;
    totalTokens: z.ZodNullable<z.ZodNumber>;
    pricingStatus: z.ZodEnum<["priced", "free", "unpriced"]>;
    priceCurrency: z.ZodNullable<z.ZodString>;
    priceAmount: z.ZodNullable<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    revision: number;
    requestId: string;
    provider: string;
    totalTokens: number | null;
    model: string;
    originExecutionId: string;
    providerScopeId: string;
    metricKey: string;
    promptTokens: number | null;
    completionTokens: number | null;
    pricingStatus: "priced" | "free" | "unpriced";
    priceCurrency: string | null;
    priceAmount: number | null;
}, {
    revision: number;
    requestId: string;
    provider: string;
    totalTokens: number | null;
    model: string;
    originExecutionId: string;
    providerScopeId: string;
    metricKey: string;
    promptTokens: number | null;
    completionTokens: number | null;
    pricingStatus: "priced" | "free" | "unpriced";
    priceCurrency: string | null;
    priceAmount: number | null;
}>;
export type PipelineModelUsageFact = z.output<typeof pipelineModelUsageFactSchema>;
export declare function pipelineModelUsageStatistics(facts: readonly PipelineModelUsageFact[], coverage: Pick<PipelineModelUsageStatistics, 'requestedExecutions' | 'executionsWithRecords' | 'truncated' | 'rejectedRecords'>, chargedPoints?: number | null): PipelineModelUsageStatistics;
