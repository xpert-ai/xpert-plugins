import type { ProjectPipelineBinding } from './configuration.schema';
import type { ProjectPipelineDefinition } from './definition.schema';
import type { ProjectPipelineCompatibilityIssue, ProjectPipelineHostCapabilities } from './compatibility.schema';
/** Derive requirements from typed execution semantics even when a legacy template omits its declaration. */
export declare function checkProjectPipelineHostCompatibility(definition: ProjectPipelineDefinition, binding: ProjectPipelineBinding | null | undefined, host: ProjectPipelineHostCapabilities): ProjectPipelineCompatibilityIssue[];
