import { z } from 'zod/v3';
/** Keys identify actual resources across Projects/tenants, never caller-supplied aliases or paths. */
export declare const projectPipelineResourceClaimSchema: z.ZodObject<{
    key: z.ZodString;
    mode: z.ZodEnum<["shared", "exclusive"]>;
}, "strict", z.ZodTypeAny, {
    key: string;
    mode: "shared" | "exclusive";
}, {
    key: string;
    mode: "shared" | "exclusive";
}>;
export declare const projectPipelineResourceClaimsSchema: z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
    key: z.ZodString;
    mode: z.ZodEnum<["shared", "exclusive"]>;
}, "strict", z.ZodTypeAny, {
    key: string;
    mode: "shared" | "exclusive";
}, {
    key: string;
    mode: "shared" | "exclusive";
}>, "many">, {
    key: string;
    mode: "shared" | "exclusive";
}[], {
    key: string;
    mode: "shared" | "exclusive";
}[]>, {
    key: string;
    mode: "shared" | "exclusive";
}[], {
    key: string;
    mode: "shared" | "exclusive";
}[]>;
export declare const projectPipelineResourceReservationSchema: z.ZodObject<{
    resolverRef: z.ZodString;
    claims: z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        mode: z.ZodEnum<["shared", "exclusive"]>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        mode: "shared" | "exclusive";
    }, {
        key: string;
        mode: "shared" | "exclusive";
    }>, "many">, {
        key: string;
        mode: "shared" | "exclusive";
    }[], {
        key: string;
        mode: "shared" | "exclusive";
    }[]>, {
        key: string;
        mode: "shared" | "exclusive";
    }[], {
        key: string;
        mode: "shared" | "exclusive";
    }[]>;
}, "strict", z.ZodTypeAny, {
    resolverRef: string;
    claims: {
        key: string;
        mode: "shared" | "exclusive";
    }[];
}, {
    resolverRef: string;
    claims: {
        key: string;
        mode: "shared" | "exclusive";
    }[];
}>;
export type ProjectPipelineResourceClaim = z.output<typeof projectPipelineResourceClaimSchema>;
export type ProjectPipelineResourceReservation = z.output<typeof projectPipelineResourceReservationSchema>;
