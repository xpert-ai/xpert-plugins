import { z } from 'zod/v3';
/** Credential support for durable pipeline commands; Project permissions remain independently required. */
export declare const projectPipelineCommandCapabilitySchema: z.ZodDiscriminatedUnion<"allowed", [z.ZodObject<{
    allowed: z.ZodLiteral<true>;
}, "strict", z.ZodTypeAny, {
    allowed: true;
}, {
    allowed: true;
}>, z.ZodObject<{
    allowed: z.ZodLiteral<false>;
    reason: z.ZodLiteral<"PIPELINE_SCOPED_DELEGATION_UNAVAILABLE">;
}, "strict", z.ZodTypeAny, {
    reason: "PIPELINE_SCOPED_DELEGATION_UNAVAILABLE";
    allowed: false;
}, {
    reason: "PIPELINE_SCOPED_DELEGATION_UNAVAILABLE";
    allowed: false;
}>]>;
export type ProjectPipelineCommandCapability = z.output<typeof projectPipelineCommandCapabilitySchema>;
