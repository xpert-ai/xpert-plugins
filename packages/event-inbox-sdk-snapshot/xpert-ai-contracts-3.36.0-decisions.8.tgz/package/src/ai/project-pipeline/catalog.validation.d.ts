import type { ProjectPipelineConfiguration } from './configuration.schema';
import type { ProjectPipelineConfigurationCheck, ProjectPipelineExtensionDescriptor } from './catalog.schema';
/** Checks declared dependencies only. Participant authorization and live capabilities require runtime resolution. */
export declare function checkProjectPipelineConfiguration(configuration: ProjectPipelineConfiguration, descriptors: readonly ProjectPipelineExtensionDescriptor[]): ProjectPipelineConfigurationCheck;
