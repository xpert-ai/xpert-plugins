import { z } from 'zod/v3';
import type { ProjectPipelineProjectionNode } from './projection.schema';
/** This is a host observation, never a claim about when a person started or stopped working. */
export declare const pipelineHumanWaitSnapshotSchema: z.ZodEffects<z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    observedAt: z.ZodString;
    nodeIds: z.ZodArray<z.ZodString, "many">;
}, "strict", z.ZodTypeAny, {
    schemaVersion: 1;
    observedAt: string;
    nodeIds: string[];
}, {
    schemaVersion: 1;
    observedAt: string;
    nodeIds: string[];
}>, {
    schemaVersion: 1;
    observedAt: string;
    nodeIds: string[];
}, {
    schemaVersion: 1;
    observedAt: string;
    nodeIds: string[];
}>;
export type PipelineHumanWaitSnapshot = z.output<typeof pipelineHumanWaitSnapshotSchema>;
export declare function pipelineNodeNeedsHuman(node: ProjectPipelineProjectionNode, historical?: boolean): boolean;
