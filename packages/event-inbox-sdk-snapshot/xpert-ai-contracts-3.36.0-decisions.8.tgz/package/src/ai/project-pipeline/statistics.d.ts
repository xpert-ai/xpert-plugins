import { type PipelineAttemptFact } from './execution-statistics';
import { z } from 'zod/v3';
import type { ProjectPipelineProjectionNode } from './projection.schema';
export declare const projectPipelineWorkCountsSchema: z.ZodObject<{
    total: z.ZodNumber;
    completed: z.ZodNumber;
    failed: z.ZodNumber;
    cancelled: z.ZodNumber;
    running: z.ZodNumber;
    blocked: z.ZodNumber;
    unknown: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    unknown: number;
    blocked: number;
    failed: number;
    cancelled: number;
    running: number;
    completed: number;
    total: number;
}, {
    unknown: number;
    blocked: number;
    failed: number;
    cancelled: number;
    running: number;
    completed: number;
    total: number;
}>;
export declare const projectPipelineStatisticsSchema: z.ZodObject<{
    scope: z.ZodLiteral<"round">;
    executionScope: z.ZodOptional<z.ZodEnum<["round", "linked_task_history"]>>;
    work: z.ZodObject<{
        total: z.ZodNumber;
        completed: z.ZodNumber;
        failed: z.ZodNumber;
        cancelled: z.ZodNumber;
        running: z.ZodNumber;
        blocked: z.ZodNumber;
        unknown: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    }, {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    }>;
    /** Business nodes include work, human gates and external confirmations; controls are excluded. */
    business: z.ZodOptional<z.ZodObject<{
        total: z.ZodNumber;
        completed: z.ZodNumber;
        failed: z.ZodNumber;
        cancelled: z.ZodNumber;
        running: z.ZodNumber;
        blocked: z.ZodNumber;
        unknown: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    }, {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    }>>;
    needsYou: z.ZodNumber;
    attempts: z.ZodObject<{
        total: z.ZodNumber;
        queued: z.ZodNumber;
        running: z.ZodNumber;
        waiting: z.ZodOptional<z.ZodNumber>;
        succeeded: z.ZodNumber;
        failed: z.ZodNumber;
        cancelled: z.ZodNumber;
        unknown: z.ZodNumber;
        terminal: z.ZodNumber;
        successRate: z.ZodNullable<z.ZodNumber>;
        retries: z.ZodNumber;
        additionalAttempts: z.ZodOptional<z.ZodNumber>;
        unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    }, {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    }>;
    timing: z.ZodOptional<z.ZodObject<{
        samples: z.ZodNumber;
        unavailable: z.ZodNumber;
        totalMs: z.ZodNullable<z.ZodNumber>;
        meanMs: z.ZodNullable<z.ZodNumber>;
        medianMs: z.ZodNullable<z.ZodNumber>;
        p95Ms: z.ZodNullable<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    }, {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    }>>;
    byExecutor: z.ZodOptional<z.ZodArray<z.ZodObject<{
        xpertId: z.ZodNullable<z.ZodString>;
        agentKey: z.ZodNullable<z.ZodString>;
        provider: z.ZodNullable<z.ZodString>;
        toolId: z.ZodNullable<z.ZodString>;
        serviceRef: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        attempts: z.ZodObject<{
            total: z.ZodNumber;
            queued: z.ZodNumber;
            running: z.ZodNumber;
            waiting: z.ZodOptional<z.ZodNumber>;
            succeeded: z.ZodNumber;
            failed: z.ZodNumber;
            cancelled: z.ZodNumber;
            unknown: z.ZodNumber;
            terminal: z.ZodNumber;
            successRate: z.ZodNullable<z.ZodNumber>;
            retries: z.ZodNumber;
            additionalAttempts: z.ZodOptional<z.ZodNumber>;
            unclassifiedAttempts: z.ZodOptional<z.ZodNumber>;
        }, "strict", z.ZodTypeAny, {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        }, {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        }>;
        timing: z.ZodObject<{
            samples: z.ZodNumber;
            unavailable: z.ZodNumber;
            totalMs: z.ZodNullable<z.ZodNumber>;
            meanMs: z.ZodNullable<z.ZodNumber>;
            medianMs: z.ZodNullable<z.ZodNumber>;
            p95Ms: z.ZodNullable<z.ZodNumber>;
        }, "strict", z.ZodTypeAny, {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        }, {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        }>;
    }, "strict", z.ZodTypeAny, {
        provider: string | null;
        xpertId: string | null;
        agentKey: string | null;
        toolId: string | null;
        attempts: {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        };
        timing: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        serviceRef?: string | null | undefined;
    }, {
        provider: string | null;
        xpertId: string | null;
        agentKey: string | null;
        toolId: string | null;
        attempts: {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        };
        timing: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        serviceRef?: string | null | undefined;
    }>, "many">>;
    modelUsage: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"linked_native_llm_calls">;
        requestedExecutions: z.ZodNumber;
        executionsWithRecords: z.ZodNumber;
        truncated: z.ZodBoolean;
        rejectedRecords: z.ZodNumber;
        calls: z.ZodNumber;
        inputTokens: z.ZodNullable<z.ZodNumber>;
        outputTokens: z.ZodNullable<z.ZodNumber>;
        totalTokens: z.ZodNullable<z.ZodNumber>;
        unpricedCalls: z.ZodNumber;
        chargedPoints: z.ZodNullable<z.ZodNumber>;
        byModel: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            calls: z.ZodNumber;
            inputTokens: z.ZodNullable<z.ZodNumber>;
            outputTokens: z.ZodNullable<z.ZodNumber>;
            totalTokens: z.ZodNullable<z.ZodNumber>;
        }, "strict", z.ZodTypeAny, {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }, {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        truncated: boolean;
        scope: "linked_native_llm_calls";
        calls: number;
        requestedExecutions: number;
        executionsWithRecords: number;
        rejectedRecords: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        unpricedCalls: number;
        chargedPoints: number | null;
        byModel: {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }[];
    }, {
        truncated: boolean;
        scope: "linked_native_llm_calls";
        calls: number;
        requestedExecutions: number;
        executionsWithRecords: number;
        rejectedRecords: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        unpricedCalls: number;
        chargedPoints: number | null;
        byModel: {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }[];
    }>>;
    nativeModelBudget: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"instance_native_llm">;
        policy: z.ZodEffects<z.ZodObject<{
            maxCalls: z.ZodNumber;
            maxTokens: z.ZodNumber;
            reservationTokens: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }>, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }>;
        calls: z.ZodNumber;
        heldCalls: z.ZodNumber;
        actualTokens: z.ZodNumber;
        chargedAndReservedTokens: z.ZodNumber;
        admissionBlocked: z.ZodBoolean;
    }, "strict", z.ZodTypeAny, {
        scope: "instance_native_llm";
        policy: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        };
        calls: number;
        heldCalls: number;
        actualTokens: number;
        chargedAndReservedTokens: number;
        admissionBlocked: boolean;
    }, {
        scope: "instance_native_llm";
        policy: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        };
        calls: number;
        heldCalls: number;
        actualTokens: number;
        chargedAndReservedTokens: number;
        admissionBlocked: boolean;
    }>>;
    byLane: z.ZodArray<z.ZodObject<{
        key: z.ZodNullable<z.ZodString>;
        work: z.ZodObject<{
            total: z.ZodNumber;
            completed: z.ZodNumber;
            failed: z.ZodNumber;
            cancelled: z.ZodNumber;
            running: z.ZodNumber;
            blocked: z.ZodNumber;
            unknown: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        }, {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        }>;
    }, "strict", z.ZodTypeAny, {
        key: string | null;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }, {
        key: string | null;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }>, "many">;
    byStage: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        work: z.ZodObject<{
            total: z.ZodNumber;
            completed: z.ZodNumber;
            failed: z.ZodNumber;
            cancelled: z.ZodNumber;
            running: z.ZodNumber;
            blocked: z.ZodNumber;
            unknown: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        }, {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        }>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }, {
        key: string;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    work: {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    };
    scope: "round";
    attempts: {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    };
    needsYou: number;
    byLane: {
        key: string | null;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }[];
    byStage: {
        key: string;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }[];
    nativeModelBudget?: {
        scope: "instance_native_llm";
        policy: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        };
        calls: number;
        heldCalls: number;
        actualTokens: number;
        chargedAndReservedTokens: number;
        admissionBlocked: boolean;
    } | undefined;
    timing?: {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    } | undefined;
    executionScope?: "round" | "linked_task_history" | undefined;
    business?: {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    } | undefined;
    byExecutor?: {
        provider: string | null;
        xpertId: string | null;
        agentKey: string | null;
        toolId: string | null;
        attempts: {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        };
        timing: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        serviceRef?: string | null | undefined;
    }[] | undefined;
    modelUsage?: {
        truncated: boolean;
        scope: "linked_native_llm_calls";
        calls: number;
        requestedExecutions: number;
        executionsWithRecords: number;
        rejectedRecords: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        unpricedCalls: number;
        chargedPoints: number | null;
        byModel: {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }[];
    } | undefined;
}, {
    work: {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    };
    scope: "round";
    attempts: {
        unknown: number;
        failed: number;
        cancelled: number;
        running: number;
        succeeded: number;
        terminal: number;
        total: number;
        queued: number;
        successRate: number | null;
        retries: number;
        waiting?: number | undefined;
        additionalAttempts?: number | undefined;
        unclassifiedAttempts?: number | undefined;
    };
    needsYou: number;
    byLane: {
        key: string | null;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }[];
    byStage: {
        key: string;
        work: {
            unknown: number;
            blocked: number;
            failed: number;
            cancelled: number;
            running: number;
            completed: number;
            total: number;
        };
    }[];
    nativeModelBudget?: {
        scope: "instance_native_llm";
        policy: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        };
        calls: number;
        heldCalls: number;
        actualTokens: number;
        chargedAndReservedTokens: number;
        admissionBlocked: boolean;
    } | undefined;
    timing?: {
        unavailable: number;
        samples: number;
        totalMs: number | null;
        meanMs: number | null;
        medianMs: number | null;
        p95Ms: number | null;
    } | undefined;
    executionScope?: "round" | "linked_task_history" | undefined;
    business?: {
        unknown: number;
        blocked: number;
        failed: number;
        cancelled: number;
        running: number;
        completed: number;
        total: number;
    } | undefined;
    byExecutor?: {
        provider: string | null;
        xpertId: string | null;
        agentKey: string | null;
        toolId: string | null;
        attempts: {
            unknown: number;
            failed: number;
            cancelled: number;
            running: number;
            succeeded: number;
            terminal: number;
            total: number;
            queued: number;
            successRate: number | null;
            retries: number;
            waiting?: number | undefined;
            additionalAttempts?: number | undefined;
            unclassifiedAttempts?: number | undefined;
        };
        timing: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        serviceRef?: string | null | undefined;
    }[] | undefined;
    modelUsage?: {
        truncated: boolean;
        scope: "linked_native_llm_calls";
        calls: number;
        requestedExecutions: number;
        executionsWithRecords: number;
        rejectedRecords: number;
        inputTokens: number | null;
        outputTokens: number | null;
        totalTokens: number | null;
        unpricedCalls: number;
        chargedPoints: number | null;
        byModel: {
            provider: string;
            calls: number;
            inputTokens: number | null;
            outputTokens: number | null;
            totalTokens: number | null;
            model: string;
        }[];
    } | undefined;
}>;
export type ProjectPipelineStatistics = z.output<typeof projectPipelineStatisticsSchema>;
type Node = {
    projection: ProjectPipelineProjectionNode;
    taskIds: string[];
    executionIds?: string[];
};
export declare function selectedPipelineAttemptFacts(nodes: readonly Node[], executions: readonly PipelineAttemptFact[], historical?: boolean): PipelineAttemptFact[];
/** Compute on the server from a complete, authorized MVCC snapshot; never from a filtered page. */
export declare function projectPipelineStatistics(nodes: readonly Node[], executions: readonly PipelineAttemptFact[], historical?: boolean, executionScope?: 'round' | 'linked_task_history'): ProjectPipelineStatistics;
export {};
