import { z } from 'zod/v3';
export declare const pipelineQueueStatisticsSchema: z.ZodObject<{
    scope: z.ZodLiteral<"recorded_dispatch_outbox_created_in_window">;
    coverage: z.ZodObject<{
        recorded: z.ZodNumber;
        missingCreatedAt: z.ZodNumber;
        outsideWindow: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        recorded: number;
        missingCreatedAt: number;
        outsideWindow: number;
    }, {
        recorded: number;
        missingCreatedAt: number;
        outsideWindow: number;
    }>;
    total: z.ZodObject<{
        total: z.ZodNumber;
        dispatched: z.ZodNumber;
        queued: z.ZodNumber;
        unavailable: z.ZodNumber;
        dispatchWait: z.ZodObject<{
            samples: z.ZodNumber;
            unavailable: z.ZodNumber;
            totalMs: z.ZodNullable<z.ZodNumber>;
            meanMs: z.ZodNullable<z.ZodNumber>;
            medianMs: z.ZodNullable<z.ZodNumber>;
            p95Ms: z.ZodNullable<z.ZodNumber>;
        }, "strict", z.ZodTypeAny, {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        }, {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        }>;
        pendingWait: z.ZodObject<{
            samples: z.ZodNumber;
            totalMs: z.ZodNullable<z.ZodNumber>;
            oldestMs: z.ZodNullable<z.ZodNumber>;
        }, "strict", z.ZodTypeAny, {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        }, {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        }>;
    }, "strict", z.ZodTypeAny, {
        unavailable: number;
        total: number;
        queued: number;
        dispatched: number;
        dispatchWait: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        pendingWait: {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        };
    }, {
        unavailable: number;
        total: number;
        queued: number;
        dispatched: number;
        dispatchWait: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        pendingWait: {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        };
    }>;
    bySource: z.ZodArray<z.ZodObject<{
        source: z.ZodEnum<["managed_operation", "provider_action"]>;
        metrics: z.ZodObject<{
            total: z.ZodNumber;
            dispatched: z.ZodNumber;
            queued: z.ZodNumber;
            unavailable: z.ZodNumber;
            dispatchWait: z.ZodObject<{
                samples: z.ZodNumber;
                unavailable: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                meanMs: z.ZodNullable<z.ZodNumber>;
                medianMs: z.ZodNullable<z.ZodNumber>;
                p95Ms: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }, {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            }>;
            pendingWait: z.ZodObject<{
                samples: z.ZodNumber;
                totalMs: z.ZodNullable<z.ZodNumber>;
                oldestMs: z.ZodNullable<z.ZodNumber>;
            }, "strict", z.ZodTypeAny, {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            }, {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            }>;
        }, "strict", z.ZodTypeAny, {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        }, {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        }>;
    }, "strict", z.ZodTypeAny, {
        source: "provider_action" | "managed_operation";
        metrics: {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        };
    }, {
        source: "provider_action" | "managed_operation";
        metrics: {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        };
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    coverage: {
        recorded: number;
        missingCreatedAt: number;
        outsideWindow: number;
    };
    scope: "recorded_dispatch_outbox_created_in_window";
    total: {
        unavailable: number;
        total: number;
        queued: number;
        dispatched: number;
        dispatchWait: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        pendingWait: {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        };
    };
    bySource: {
        source: "provider_action" | "managed_operation";
        metrics: {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        };
    }[];
}, {
    coverage: {
        recorded: number;
        missingCreatedAt: number;
        outsideWindow: number;
    };
    scope: "recorded_dispatch_outbox_created_in_window";
    total: {
        unavailable: number;
        total: number;
        queued: number;
        dispatched: number;
        dispatchWait: {
            unavailable: number;
            samples: number;
            totalMs: number | null;
            meanMs: number | null;
            medianMs: number | null;
            p95Ms: number | null;
        };
        pendingWait: {
            samples: number;
            totalMs: number | null;
            oldestMs: number | null;
        };
    };
    bySource: {
        source: "provider_action" | "managed_operation";
        metrics: {
            unavailable: number;
            total: number;
            queued: number;
            dispatched: number;
            dispatchWait: {
                unavailable: number;
                samples: number;
                totalMs: number | null;
                meanMs: number | null;
                medianMs: number | null;
                p95Ms: number | null;
            };
            pendingWait: {
                samples: number;
                totalMs: number | null;
                oldestMs: number | null;
            };
        };
    }[];
}>;
export type PipelineQueueStatistics = z.output<typeof pipelineQueueStatisticsSchema>;
export interface PipelineQueueFact {
    id: string;
    source: 'managed_operation' | 'provider_action';
    createdAt: string | null;
    dispatchStartedAt: string | null;
    waiting: boolean;
}
/** Outbox admission to first dispatch, not Agent runtime or human approval time.
 * Unknown/closed records without a dispatch timestamp are not zero-duration waits. */
export declare function pipelineQueueStatistics(facts: readonly PipelineQueueFact[], window: {
    from: string;
    to: string;
}, snapshotAt: string): PipelineQueueStatistics;
