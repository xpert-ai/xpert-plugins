import { z } from 'zod/v3';
import type { PipelineHumanWaitSnapshot } from './human-wait.schema';
export declare const pipelineHumanWaitStatisticsSchema: z.ZodObject<{
    scope: z.ZodLiteral<"observed_human_ready_intervals_intersecting_window">;
    intervals: z.ZodNumber;
    ongoing: z.ZodNumber;
    censored: z.ZodNumber;
    observedNodeMs: z.ZodNullable<z.ZodNumber>;
    observedUnionMs: z.ZodNullable<z.ZodNumber>;
    coverage: z.ZodObject<{
        snapshots: z.ZodNumber;
        missingEvents: z.ZodNumber;
        invalidEvents: z.ZodNumber;
        currentUntrackedNodes: z.ZodNumber;
        observedWindowMs: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        snapshots: number;
        missingEvents: number;
        invalidEvents: number;
        currentUntrackedNodes: number;
        observedWindowMs: number;
    }, {
        snapshots: number;
        missingEvents: number;
        invalidEvents: number;
        currentUntrackedNodes: number;
        observedWindowMs: number;
    }>;
}, "strict", z.ZodTypeAny, {
    coverage: {
        snapshots: number;
        missingEvents: number;
        invalidEvents: number;
        currentUntrackedNodes: number;
        observedWindowMs: number;
    };
    scope: "observed_human_ready_intervals_intersecting_window";
    intervals: number;
    ongoing: number;
    censored: number;
    observedNodeMs: number | null;
    observedUnionMs: number | null;
}, {
    coverage: {
        snapshots: number;
        missingEvents: number;
        invalidEvents: number;
        currentUntrackedNodes: number;
        observedWindowMs: number;
    };
    scope: "observed_human_ready_intervals_intersecting_window";
    intervals: number;
    ongoing: number;
    censored: number;
    observedNodeMs: number | null;
    observedUnionMs: number | null;
}>;
export type PipelineHumanWaitStatistics = z.output<typeof pipelineHumanWaitStatisticsSchema>;
export interface PipelineHumanWaitEvent {
    instanceId: string;
    revision: number;
    snapshot: PipelineHumanWaitSnapshot | null;
    invalid?: boolean;
}
/** Reconstruct only observed ready intervals. A missing event breaks continuity;
 * an initial ready snapshot supplies a lower bound, never a fabricated historical start. */
export declare function pipelineHumanWaitStatistics(events: readonly PipelineHumanWaitEvent[], currentWaitingNodeIds: readonly string[], window: {
    from: string;
    to: string;
}, snapshotAt: string): PipelineHumanWaitStatistics;
