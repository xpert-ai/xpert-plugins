import type { ProjectPipelineDefinition } from './definition.schema';
export interface ProjectPipelineValidationIssue {
    code: string;
    path: Array<string | number>;
}
/** Pure semantic checks shared by configuration APIs, plugin registrations and persisted snapshots. */
export declare function validateProjectPipelineDefinition(definition: ProjectPipelineDefinition): ProjectPipelineValidationIssue[];
