import { z } from 'zod/v3';
/** Only explicit primitives can control flow; configuration cannot embed executable expressions. */
export declare const projectPipelineNodeSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    kind: z.ZodLiteral<"work">;
    laneKey: z.ZodEffects<z.ZodString, string, string>;
    presentation: z.ZodOptional<z.ZodObject<{
        foldIntoApproval: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        foldIntoApproval: string;
    }, {
        foldIntoApproval: string;
    }>>;
    operationRef: z.ZodString;
    executorSlot: z.ZodEffects<z.ZodString, string, string>;
    completionRef: z.ZodString;
    resourceResolverRef: z.ZodOptional<z.ZodString>;
    outputSchemaRef: z.ZodOptional<z.ZodString>;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "work";
    key: string;
    laneKey: string;
    operationRef: string;
    executorSlot: string;
    completionRef: string;
    stageKey: string;
    label?: string | undefined;
    presentation?: {
        foldIntoApproval: string;
    } | undefined;
    resourceResolverRef?: string | undefined;
    outputSchemaRef?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}, {
    kind: "work";
    key: string;
    laneKey: string;
    operationRef: string;
    executorSlot: string;
    completionRef: string;
    stageKey: string;
    label?: string | undefined;
    presentation?: {
        foldIntoApproval: string;
    } | undefined;
    resourceResolverRef?: string | undefined;
    outputSchemaRef?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"fork">;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "fork";
    key: string;
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}, {
    kind: "fork";
    key: string;
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"join">;
    join: z.ZodObject<{
        mode: z.ZodLiteral<"all_selected">;
        accept: z.ZodLiteral<"completed">;
    }, "strict", z.ZodTypeAny, {
        mode: "all_selected";
        accept: "completed";
    }, {
        mode: "all_selected";
        accept: "completed";
    }>;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "join";
    key: string;
    join: {
        mode: "all_selected";
        accept: "completed";
    };
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}, {
    kind: "join";
    key: string;
    join: {
        mode: "all_selected";
        accept: "completed";
    };
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"router">;
    policyRef: z.ZodString;
    outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
    unmatched: z.ZodLiteral<"block">;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "router";
    key: string;
    stageKey: string;
    policyRef: string;
    outcomes: string[];
    unmatched: "block";
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}, {
    kind: "router";
    key: string;
    stageKey: string;
    policyRef: string;
    outcomes: string[];
    unmatched: "block";
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"human_gate">;
    laneKey: z.ZodEffects<z.ZodString, string, string>;
    policyRef: z.ZodString;
    candidateRoleKey: z.ZodEffects<z.ZodString, string, string>;
    outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
    outcomeLabels: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "human_gate";
    key: string;
    laneKey: string;
    stageKey: string;
    policyRef: string;
    outcomes: string[];
    candidateRoleKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
    outcomeLabels?: Record<string, string> | undefined;
}, {
    kind: "human_gate";
    key: string;
    laneKey: string;
    stageKey: string;
    policyRef: string;
    outcomes: string[];
    candidateRoleKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
    outcomeLabels?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"external_wait">;
    laneKey: z.ZodEffects<z.ZodString, string, string>;
    subscriptionRef: z.ZodString;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "external_wait";
    key: string;
    laneKey: string;
    stageKey: string;
    subscriptionRef: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}, {
    kind: "external_wait";
    key: string;
    laneKey: string;
    stageKey: string;
    subscriptionRef: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"terminal">;
    outcome: z.ZodEffects<z.ZodString, string, string>;
    disposition: z.ZodOptional<z.ZodEnum<["complete", "await_new_subject"]>>;
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodOptional<z.ZodString>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
        from: z.ZodLiteral<"subject">;
    }, "strict", z.ZodTypeAny, {
        from: "subject";
    }, {
        from: "subject";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"parameter">;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        from: "parameter";
    }, {
        key: string;
        from: "parameter";
    }>, z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, z.ZodObject<{
        from: z.ZodLiteral<"collection">;
        items: z.ZodArray<z.ZodObject<{
            from: z.ZodLiteral<"node_output">;
            nodeKey: z.ZodEffects<z.ZodString, string, string>;
            port: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }, {
            from: "node_output";
            nodeKey: string;
            port: string;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }, {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }>]>>>;
    outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    kind: "terminal";
    key: string;
    outcome: string;
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
    disposition?: "complete" | "await_new_subject" | undefined;
}, {
    kind: "terminal";
    key: string;
    outcome: string;
    stageKey: string;
    label?: string | undefined;
    inputBindings?: Record<string, {
        from: "node_output";
        nodeKey: string;
        port: string;
    } | {
        from: "subject";
    } | {
        key: string;
        from: "parameter";
    } | {
        items: {
            from: "node_output";
            nodeKey: string;
            port: string;
        }[];
        from: "collection";
    }> | undefined;
    outputPorts?: Record<string, string> | undefined;
    disposition?: "complete" | "await_new_subject" | undefined;
}>]>;
export type ProjectPipelineNodeDefinition = z.output<typeof projectPipelineNodeSchema>;
