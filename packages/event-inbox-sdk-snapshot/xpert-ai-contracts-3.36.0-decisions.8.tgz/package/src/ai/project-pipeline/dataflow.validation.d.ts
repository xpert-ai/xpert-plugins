import type { ProjectPipelineDefinition } from './definition.schema';
import type { ProjectPipelineValidationIssue } from './definition.validation';
/** Bounded symbolic execution proves required outputs exist on every selected branch. */
export declare function validateProjectPipelineDataflow(definition: Extract<ProjectPipelineDefinition, {
    executionAuthority?: 'platform';
}>, ordered: string[]): ProjectPipelineValidationIssue[];
