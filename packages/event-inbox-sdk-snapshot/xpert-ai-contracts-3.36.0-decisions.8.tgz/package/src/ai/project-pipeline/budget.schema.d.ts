import { z } from 'zod/v3';
/** Admission controls for host-native LLM requests; provider-internal retries and currency are not hard quotas. */
export declare const projectPipelineNativeModelBudgetSchema: z.ZodEffects<z.ZodObject<{
    maxCalls: z.ZodNumber;
    maxTokens: z.ZodNumber;
    reservationTokens: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    maxCalls: number;
    maxTokens: number;
    reservationTokens: number;
}, {
    maxCalls: number;
    maxTokens: number;
    reservationTokens: number;
}>, {
    maxCalls: number;
    maxTokens: number;
    reservationTokens: number;
}, {
    maxCalls: number;
    maxTokens: number;
    reservationTokens: number;
}>;
export type ProjectPipelineNativeModelBudget = z.output<typeof projectPipelineNativeModelBudgetSchema>;
/** Human management command. maxTokens is the new total ceiling, not an additional allowance. */
export declare const projectPipelineModelBudgetIncreaseSchema: z.ZodObject<{
    instanceId: z.ZodString;
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
    maxTokens: z.ZodNumber;
    reason: z.ZodString;
}, "strict", z.ZodTypeAny, {
    requestId: string;
    maxTokens: number;
    instanceId: string;
    expectedRevision: number;
    reason: string;
}, {
    requestId: string;
    maxTokens: number;
    instanceId: string;
    expectedRevision: number;
    reason: string;
}>;
export type ProjectPipelineModelBudgetIncrease = z.output<typeof projectPipelineModelBudgetIncreaseSchema>;
export declare const projectPipelineModelBudgetIncreaseRecordSchema: z.ZodObject<{
    requestId: z.ZodString;
    previousMaxTokens: z.ZodNumber;
    maxTokens: z.ZodNumber;
    reason: z.ZodString;
}, "strict", z.ZodTypeAny, {
    requestId: string;
    maxTokens: number;
    reason: string;
    previousMaxTokens: number;
}, {
    requestId: string;
    maxTokens: number;
    reason: string;
    previousMaxTokens: number;
}>;
export type ProjectPipelineModelBudgetIncreaseRecord = z.output<typeof projectPipelineModelBudgetIncreaseRecordSchema>;
export declare const projectPipelineNativeModelBudgetStatusSchema: z.ZodObject<{
    scope: z.ZodLiteral<"instance_native_llm">;
    policy: z.ZodEffects<z.ZodObject<{
        maxCalls: z.ZodNumber;
        maxTokens: z.ZodNumber;
        reservationTokens: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    }, {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    }>, {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    }, {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    }>;
    calls: z.ZodNumber;
    heldCalls: z.ZodNumber;
    actualTokens: z.ZodNumber;
    chargedAndReservedTokens: z.ZodNumber;
    admissionBlocked: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    scope: "instance_native_llm";
    policy: {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    };
    calls: number;
    heldCalls: number;
    actualTokens: number;
    chargedAndReservedTokens: number;
    admissionBlocked: boolean;
}, {
    scope: "instance_native_llm";
    policy: {
        maxCalls: number;
        maxTokens: number;
        reservationTokens: number;
    };
    calls: number;
    heldCalls: number;
    actualTokens: number;
    chargedAndReservedTokens: number;
    admissionBlocked: boolean;
}>;
export type ProjectPipelineNativeModelBudgetStatus = z.output<typeof projectPipelineNativeModelBudgetStatusSchema>;
