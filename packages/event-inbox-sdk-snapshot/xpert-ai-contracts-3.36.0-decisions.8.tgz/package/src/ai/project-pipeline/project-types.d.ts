import { z } from 'zod/v3';
import type { ProjectPipelineDefinition } from './definition.schema';
/** Explicit application/type identities; plugin availability alone never implies applicability. */
export declare const projectPipelineProjectTypesSchema: z.ZodEffects<z.ZodArray<z.ZodObject<{
    applicationKey: z.ZodString;
    projectTypeKey: z.ZodString;
}, "strict", z.ZodTypeAny, {
    applicationKey: string;
    projectTypeKey: string;
}, {
    applicationKey: string;
    projectTypeKey: string;
}>, "many">, {
    applicationKey: string;
    projectTypeKey: string;
}[], {
    applicationKey: string;
    projectTypeKey: string;
}[]>;
export declare function isProjectPipelineApplicable(definition: Pick<ProjectPipelineDefinition, 'projectTypes'>, project: {
    applicationKey?: string | null;
    projectTypeKey?: string | null;
}): boolean;
