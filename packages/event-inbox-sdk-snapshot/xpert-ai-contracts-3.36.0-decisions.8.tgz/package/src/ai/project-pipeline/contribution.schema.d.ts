import { z } from 'zod/v3';
export declare const projectPipelineContributionSchema: z.ZodEffects<z.ZodObject<{
    key: z.ZodEffects<z.ZodString, string, string>;
    configurations: z.ZodArray<z.ZodEffects<z.ZodObject<{
        schemaVersion: z.ZodLiteral<1>;
        template: z.ZodEffects<z.ZodDiscriminatedUnion<"executionAuthority", [z.ZodObject<{
            executionAuthority: z.ZodLiteral<"provider">;
            providerRef: z.ZodString;
            topology: z.ZodObject<{
                source: z.ZodLiteral<"provider">;
                presentationAdapterRef: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                source: "provider";
                presentationAdapterRef: string;
            }, {
                source: "provider";
                presentationAdapterRef: string;
            }>;
            actionRefs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            hostRequirements: z.ZodOptional<z.ZodObject<{
                protocol: z.ZodNumber;
                features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodNumber>, Record<string, number>, Record<string, number>>;
            }, "strict", z.ZodTypeAny, {
                protocol: number;
                features: Record<string, number>;
            }, {
                protocol: number;
                features: Record<string, number>;
            }>>;
            key: z.ZodEffects<z.ZodString, string, string>;
            version: z.ZodString;
            title: z.ZodString;
            projectTypes: z.ZodEffects<z.ZodArray<z.ZodObject<{
                applicationKey: z.ZodString;
                projectTypeKey: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                applicationKey: string;
                projectTypeKey: string;
            }, {
                applicationKey: string;
                projectTypeKey: string;
            }>, "many">, {
                applicationKey: string;
                projectTypeKey: string;
            }[], {
                applicationKey: string;
                projectTypeKey: string;
            }[]>;
            subjectResolverRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                allowedKinds: z.ZodArray<z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>, "many">;
            }, "strict", z.ZodTypeAny, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }>, "many">;
            lanes: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }, {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }>, "many">;
            stages: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                icon: z.ZodOptional<z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>>;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }, {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }>, "many">;
            presentation: z.ZodOptional<z.ZodObject<{
                views: z.ZodArray<z.ZodEnum<["tasks", "pipeline", "agent_timeline"]>, "many">;
                nodeDetailRef: z.ZodOptional<z.ZodString>;
                evidenceTypes: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            }, "strict", z.ZodTypeAny, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }>>;
            metrics: z.ZodOptional<z.ZodObject<{
                dimensionRefs: z.ZodArray<z.ZodString, "many">;
                metricRefs: z.ZodArray<z.ZodString, "many">;
            }, "strict", z.ZodTypeAny, {
                dimensionRefs: string[];
                metricRefs: string[];
            }, {
                dimensionRefs: string[];
                metricRefs: string[];
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>, z.ZodObject<{
            executionAuthority: z.ZodLiteral<"platform">;
            topology: z.ZodObject<{
                source: z.ZodLiteral<"definition">;
            }, "strict", z.ZodTypeAny, {
                source: "definition";
            }, {
                source: "definition";
            }>;
            nodes: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
                kind: z.ZodLiteral<"work">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                presentation: z.ZodOptional<z.ZodObject<{
                    foldIntoApproval: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    foldIntoApproval: string;
                }, {
                    foldIntoApproval: string;
                }>>;
                operationRef: z.ZodString;
                executorSlot: z.ZodEffects<z.ZodString, string, string>;
                completionRef: z.ZodString;
                resourceResolverRef: z.ZodOptional<z.ZodString>;
                outputSchemaRef: z.ZodOptional<z.ZodString>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"fork">;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"join">;
                join: z.ZodObject<{
                    mode: z.ZodLiteral<"all_selected">;
                    accept: z.ZodLiteral<"completed">;
                }, "strict", z.ZodTypeAny, {
                    mode: "all_selected";
                    accept: "completed";
                }, {
                    mode: "all_selected";
                    accept: "completed";
                }>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"router">;
                policyRef: z.ZodString;
                outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
                unmatched: z.ZodLiteral<"block">;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"human_gate">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                policyRef: z.ZodString;
                candidateRoleKey: z.ZodEffects<z.ZodString, string, string>;
                outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
                outcomeLabels: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            }, {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"external_wait">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                subscriptionRef: z.ZodString;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"terminal">;
                outcome: z.ZodEffects<z.ZodString, string, string>;
                disposition: z.ZodOptional<z.ZodEnum<["complete", "await_new_subject"]>>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            }, {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            }>]>, "many">;
            edges: z.ZodArray<z.ZodObject<{
                from: z.ZodEffects<z.ZodString, string, string>;
                to: z.ZodEffects<z.ZodString, string, string>;
                outcome: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
            }, "strict", z.ZodTypeAny, {
                from: string;
                to: string;
                outcome?: string | undefined;
            }, {
                from: string;
                to: string;
                outcome?: string | undefined;
            }>, "many">;
            roundPolicy: z.ZodObject<{
                entryNodeKey: z.ZodEffects<z.ZodString, string, string>;
                maxRounds: z.ZodNumber;
                onRework: z.ZodLiteral<"await_new_subject_then_next_round">;
                onLimit: z.ZodLiteral<"attention">;
                newVersionWhileActive: z.ZodLiteral<"supersede_round">;
                terminalOutcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
            }, "strict", z.ZodTypeAny, {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            }, {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            }>;
            failurePolicy: z.ZodObject<{
                requiredNodeFailure: z.ZodLiteral<"block_and_attention">;
                unknownExecution: z.ZodLiteral<"inspect_without_replay">;
            }, "strict", z.ZodTypeAny, {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            }, {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            }>;
            hostRequirements: z.ZodOptional<z.ZodObject<{
                protocol: z.ZodNumber;
                features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodNumber>, Record<string, number>, Record<string, number>>;
            }, "strict", z.ZodTypeAny, {
                protocol: number;
                features: Record<string, number>;
            }, {
                protocol: number;
                features: Record<string, number>;
            }>>;
            key: z.ZodEffects<z.ZodString, string, string>;
            version: z.ZodString;
            title: z.ZodString;
            projectTypes: z.ZodEffects<z.ZodArray<z.ZodObject<{
                applicationKey: z.ZodString;
                projectTypeKey: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                applicationKey: string;
                projectTypeKey: string;
            }, {
                applicationKey: string;
                projectTypeKey: string;
            }>, "many">, {
                applicationKey: string;
                projectTypeKey: string;
            }[], {
                applicationKey: string;
                projectTypeKey: string;
            }[]>;
            subjectResolverRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                allowedKinds: z.ZodArray<z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>, "many">;
            }, "strict", z.ZodTypeAny, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }>, "many">;
            lanes: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }, {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }>, "many">;
            stages: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                icon: z.ZodOptional<z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>>;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }, {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }>, "many">;
            presentation: z.ZodOptional<z.ZodObject<{
                views: z.ZodArray<z.ZodEnum<["tasks", "pipeline", "agent_timeline"]>, "many">;
                nodeDetailRef: z.ZodOptional<z.ZodString>;
                evidenceTypes: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            }, "strict", z.ZodTypeAny, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }>>;
            metrics: z.ZodOptional<z.ZodObject<{
                dimensionRefs: z.ZodArray<z.ZodString, "many">;
                metricRefs: z.ZodArray<z.ZodString, "many">;
            }, "strict", z.ZodTypeAny, {
                dimensionRefs: string[];
                metricRefs: string[];
            }, {
                dimensionRefs: string[];
                metricRefs: string[];
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>]>, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>;
        binding: z.ZodObject<{
            templateRef: z.ZodString;
            roleBindings: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
                kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
                selectionKey: z.ZodEffects<z.ZodString, string, string>;
                requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
            }, "strict", z.ZodTypeAny, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>>;
            executorBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodEffects<z.ZodObject<{
                kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
                selectionKey: z.ZodEffects<z.ZodString, string, string>;
                requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
            } & {
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                workspaceId: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }>, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }>>>;
            providerConfiguration: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
            parameters: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
            limits: z.ZodOptional<z.ZodObject<{
                maxConcurrentExecutions: z.ZodNumber;
                maxTechnicalAttemptsPerNode: z.ZodNumber;
                runTimeoutMinutes: z.ZodNumber;
                nativeModelBudget: z.ZodOptional<z.ZodEffects<z.ZodObject<{
                    maxCalls: z.ZodNumber;
                    maxTokens: z.ZodNumber;
                    reservationTokens: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }>, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }>>;
            }, "strict", z.ZodTypeAny, {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            }, {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            }>>;
            triggers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                adapterRef: z.ZodString;
                events: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
            }, "strict", z.ZodTypeAny, {
                adapterRef: string;
                events: string[];
            }, {
                adapterRef: string;
                events: string[];
            }>, "many">>;
        }, "strict", z.ZodTypeAny, {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        }, {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }>, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }>, "many">;
    descriptors: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"schema">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "schema";
        ref: string;
    }, {
        kind: "schema";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"resource">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "resource";
        ref: string;
    }, {
        kind: "resource";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"subject">;
        outputSchemaRef: z.ZodString;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    }, {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"operation">;
        effects: z.ZodEnum<["read_only", "isolated_write", "external_write"]>;
        idempotency: z.ZodEnum<["read_only", "keyed_receipt"]>;
        retry: z.ZodOptional<z.ZodEnum<["never", "after_confirmed_failure"]>>;
        requiredCapabilities: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
        inputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
            schemaRef: z.ZodString;
            cardinality: z.ZodEnum<["one", "collection"]>;
        }, "strict", z.ZodTypeAny, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>>;
        outputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    }, {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"completion">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "completion";
        ref: string;
    }, {
        kind: "completion";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"policy">;
        outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "policy";
        outcomes: string[];
        ref: string;
    }, {
        kind: "policy";
        outcomes: string[];
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"projection">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "projection";
        ref: string;
    }, {
        kind: "projection";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"presentation">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "presentation";
        ref: string;
    }, {
        kind: "presentation";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "action";
        ref: string;
    }, {
        kind: "action";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"metric">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "metric";
        ref: string;
    }, {
        kind: "metric";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"dimension">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "dimension";
        ref: string;
    }, {
        kind: "dimension";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"trigger">;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "trigger";
        ref: string;
    }, {
        kind: "trigger";
        ref: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"subscription">;
        outputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>;
        ref: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    }, {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    }>]>, "many">;
    forms: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodObject<{
        templateRef: z.ZodString;
        description: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        assistantSlots: z.ZodArray<z.ZodObject<{
            slot: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, "many">;
        runtimeSlots: z.ZodOptional<z.ZodArray<z.ZodObject<{
            slot: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, "many">>;
        nativeModelBudget: z.ZodOptional<z.ZodEffects<z.ZodObject<{
            maxCalls: z.ZodNumber;
            maxTokens: z.ZodNumber;
            reservationTokens: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }>, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }, {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        }>>;
        parameters: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"boolean">;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"text">;
            maxLength: z.ZodNumber;
            minLength: z.ZodNumber;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"number">;
            min: z.ZodNumber;
            max: z.ZodNumber;
            integer: z.ZodBoolean;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"choice">;
            options: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                label: z.ZodObject<{
                    en_US: z.ZodString;
                    zh_Hans: z.ZodOptional<z.ZodString>;
                }, "strict", z.ZodTypeAny, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }>;
            }, "strict", z.ZodTypeAny, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }>, "many">;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"multi_choice">;
            options: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                label: z.ZodObject<{
                    en_US: z.ZodString;
                    zh_Hans: z.ZodOptional<z.ZodString>;
                }, "strict", z.ZodTypeAny, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }>;
            }, "strict", z.ZodTypeAny, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }>, "many">;
            minItems: z.ZodDefault<z.ZodNumber>;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"string_list">;
            maxItems: z.ZodNumber;
            itemMaxLength: z.ZodNumber;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }, {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }>, {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }, {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }>, "many">>;
}, "strict", z.ZodTypeAny, {
    key: string;
    configurations: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }[];
    descriptors: ({
        kind: "schema";
        ref: string;
    } | {
        kind: "resource";
        ref: string;
    } | {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    } | {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    } | {
        kind: "completion";
        ref: string;
    } | {
        kind: "policy";
        outcomes: string[];
        ref: string;
    } | {
        kind: "projection";
        ref: string;
    } | {
        kind: "presentation";
        ref: string;
    } | {
        kind: "action";
        ref: string;
    } | {
        kind: "metric";
        ref: string;
    } | {
        kind: "dimension";
        ref: string;
    } | {
        kind: "trigger";
        ref: string;
    } | {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    })[];
    forms?: {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }[] | undefined;
}, {
    key: string;
    configurations: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }[];
    descriptors: ({
        kind: "schema";
        ref: string;
    } | {
        kind: "resource";
        ref: string;
    } | {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    } | {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    } | {
        kind: "completion";
        ref: string;
    } | {
        kind: "policy";
        outcomes: string[];
        ref: string;
    } | {
        kind: "projection";
        ref: string;
    } | {
        kind: "presentation";
        ref: string;
    } | {
        kind: "action";
        ref: string;
    } | {
        kind: "metric";
        ref: string;
    } | {
        kind: "dimension";
        ref: string;
    } | {
        kind: "trigger";
        ref: string;
    } | {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    })[];
    forms?: {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }[] | undefined;
}>, {
    key: string;
    configurations: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }[];
    descriptors: ({
        kind: "schema";
        ref: string;
    } | {
        kind: "resource";
        ref: string;
    } | {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    } | {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    } | {
        kind: "completion";
        ref: string;
    } | {
        kind: "policy";
        outcomes: string[];
        ref: string;
    } | {
        kind: "projection";
        ref: string;
    } | {
        kind: "presentation";
        ref: string;
    } | {
        kind: "action";
        ref: string;
    } | {
        kind: "metric";
        ref: string;
    } | {
        kind: "dimension";
        ref: string;
    } | {
        kind: "trigger";
        ref: string;
    } | {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    })[];
    forms?: {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }[] | undefined;
}, {
    key: string;
    configurations: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                label: string;
                order: number;
                roleKey: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                label: string;
                order: number;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                label?: string | undefined;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }[];
    descriptors: ({
        kind: "schema";
        ref: string;
    } | {
        kind: "resource";
        ref: string;
    } | {
        kind: "subject";
        outputSchemaRef: string;
        ref: string;
    } | {
        kind: "operation";
        requiredCapabilities: string[];
        ref: string;
        effects: "read_only" | "isolated_write" | "external_write";
        idempotency: "read_only" | "keyed_receipt";
        inputs: Record<string, {
            schemaRef: string;
            cardinality: "collection" | "one";
        }>;
        outputs: Record<string, string>;
        retry?: "never" | "after_confirmed_failure" | undefined;
    } | {
        kind: "completion";
        ref: string;
    } | {
        kind: "policy";
        outcomes: string[];
        ref: string;
    } | {
        kind: "projection";
        ref: string;
    } | {
        kind: "presentation";
        ref: string;
    } | {
        kind: "action";
        ref: string;
    } | {
        kind: "metric";
        ref: string;
    } | {
        kind: "dimension";
        ref: string;
    } | {
        kind: "trigger";
        ref: string;
    } | {
        kind: "subscription";
        ref: string;
        outputs: Record<string, string>;
    })[];
    forms?: {
        templateRef: string;
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        description: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        assistantSlots: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[];
        nativeModelBudget?: {
            maxCalls: number;
            maxTokens: number;
            reservationTokens: number;
        } | undefined;
        runtimeSlots?: {
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            slot: string;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }[] | undefined;
    }[] | undefined;
}>;
/** Catalog metadata only. Runtime adapters are resolved separately and are never called during checking. */
export type ProjectPipelineContribution = z.output<typeof projectPipelineContributionSchema>;
