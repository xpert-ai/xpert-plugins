import { z } from 'zod/v3';
export declare const projectPipelinePortDescriptorSchema: z.ZodObject<{
    schemaRef: z.ZodString;
    cardinality: z.ZodEnum<["one", "collection"]>;
}, "strict", z.ZodTypeAny, {
    schemaRef: string;
    cardinality: "collection" | "one";
}, {
    schemaRef: string;
    cardinality: "collection" | "one";
}>;
/** Declarations allow configuration checks. They never prove a runtime executor is currently available. */
export declare const projectPipelineExtensionDescriptorSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    kind: z.ZodLiteral<"schema">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "schema";
    ref: string;
}, {
    kind: "schema";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"resource">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "resource";
    ref: string;
}, {
    kind: "resource";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"subject">;
    outputSchemaRef: z.ZodString;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "subject";
    outputSchemaRef: string;
    ref: string;
}, {
    kind: "subject";
    outputSchemaRef: string;
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"operation">;
    effects: z.ZodEnum<["read_only", "isolated_write", "external_write"]>;
    idempotency: z.ZodEnum<["read_only", "keyed_receipt"]>;
    retry: z.ZodOptional<z.ZodEnum<["never", "after_confirmed_failure"]>>;
    requiredCapabilities: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
    inputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
        schemaRef: z.ZodString;
        cardinality: z.ZodEnum<["one", "collection"]>;
    }, "strict", z.ZodTypeAny, {
        schemaRef: string;
        cardinality: "collection" | "one";
    }, {
        schemaRef: string;
        cardinality: "collection" | "one";
    }>>;
    outputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "operation";
    requiredCapabilities: string[];
    ref: string;
    effects: "read_only" | "isolated_write" | "external_write";
    idempotency: "read_only" | "keyed_receipt";
    inputs: Record<string, {
        schemaRef: string;
        cardinality: "collection" | "one";
    }>;
    outputs: Record<string, string>;
    retry?: "never" | "after_confirmed_failure" | undefined;
}, {
    kind: "operation";
    requiredCapabilities: string[];
    ref: string;
    effects: "read_only" | "isolated_write" | "external_write";
    idempotency: "read_only" | "keyed_receipt";
    inputs: Record<string, {
        schemaRef: string;
        cardinality: "collection" | "one";
    }>;
    outputs: Record<string, string>;
    retry?: "never" | "after_confirmed_failure" | undefined;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"completion">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "completion";
    ref: string;
}, {
    kind: "completion";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"policy">;
    outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "policy";
    outcomes: string[];
    ref: string;
}, {
    kind: "policy";
    outcomes: string[];
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"projection">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "projection";
    ref: string;
}, {
    kind: "projection";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"presentation">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "presentation";
    ref: string;
}, {
    kind: "presentation";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"action">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "action";
    ref: string;
}, {
    kind: "action";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"metric">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "metric";
    ref: string;
}, {
    kind: "metric";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"dimension">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "dimension";
    ref: string;
}, {
    kind: "dimension";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"trigger">;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "trigger";
    ref: string;
}, {
    kind: "trigger";
    ref: string;
}>, z.ZodObject<{
    kind: z.ZodLiteral<"subscription">;
    outputs: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>;
    ref: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "subscription";
    ref: string;
    outputs: Record<string, string>;
}, {
    kind: "subscription";
    ref: string;
    outputs: Record<string, string>;
}>]>;
export type ProjectPipelineExtensionDescriptor = z.output<typeof projectPipelineExtensionDescriptorSchema>;
export type ProjectPipelineExtensionKind = ProjectPipelineExtensionDescriptor['kind'];
export interface ProjectPipelineConfigurationCheck {
    valid: boolean;
    /** Configuration checking never saves a binding, invokes a resolver or starts work. */
    runtimeReadiness: 'not_checked';
    issues: Array<{
        code: string;
        path: Array<string | number>;
        ref?: string;
    }>;
    requiredCapabilities: Array<{
        executorSlot: string;
        capabilities: string[];
    }>;
}
