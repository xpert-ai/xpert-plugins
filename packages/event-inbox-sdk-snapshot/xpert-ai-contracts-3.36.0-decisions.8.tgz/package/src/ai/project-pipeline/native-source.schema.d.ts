import { z } from 'zod/v3';
/** Host-issued dispatch lease; a reference is not authorization until revalidated against durable work. */
export declare const projectPipelineNativeDispatchSchema: z.ZodObject<{
    kind: z.ZodLiteral<"provider_action">;
    operationId: z.ZodString;
    leaseOwner: z.ZodString;
    leaseFence: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    kind: "provider_action";
    operationId: string;
    leaseOwner: string;
    leaseFence: number;
}, {
    kind: "provider_action";
    operationId: string;
    leaseOwner: string;
    leaseFence: number;
}>;
export declare const projectPipelineNativeSourceSchema: z.ZodObject<{
    kind: z.ZodLiteral<"provider_action">;
    operationId: z.ZodString;
    leaseOwner: z.ZodString;
    leaseFence: z.ZodNumber;
} & {
    callKey: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    kind: "provider_action";
    operationId: string;
    leaseOwner: string;
    leaseFence: number;
    callKey: string;
}, {
    kind: "provider_action";
    operationId: string;
    leaseOwner: string;
    leaseFence: number;
    callKey: string;
}>;
export type ProjectPipelineNativeDispatch = z.output<typeof projectPipelineNativeDispatchSchema>;
export type ProjectPipelineNativeSource = z.output<typeof projectPipelineNativeSourceSchema>;
