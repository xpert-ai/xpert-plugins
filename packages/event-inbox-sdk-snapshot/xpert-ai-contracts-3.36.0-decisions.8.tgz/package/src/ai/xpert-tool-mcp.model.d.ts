import type { TMcpAppCsp, TMcpAppPermissions, TMcpAppToolResult, TMcpAppVisibility } from '@xpert-ai/chatkit-types';
import type { I18nObject } from '../i18n.model';
import type { IconDefinition } from '../types';
import type { McpCapabilityVisibility, McpJsonSchema, McpToolAnnotations } from './mcp-capability.model';
export declare enum MCPServerType {
    SSE = "sse",
    STDIO = "stdio",
    CODE = "code",
    HTTP = "http"
}
/**
 * Configuration for stdio transport connection
 */
export interface StdioConnection {
    transport: 'stdio';
    command: string;
    args: string[];
    env?: Record<string, string>;
    stderr?: 'pipe' | 'inherit' | 'ignore' | string;
    encoding?: string;
    encodingErrorHandler?: 'strict' | 'ignore' | 'replace';
}
/**
 * Configuration for SSE transport connection
 */
export interface SSEConnection {
    transport: 'sse';
    url: string;
    headers?: Record<string, string>;
    useNodeEventSource?: boolean;
}
/**
 * Configuration for Streamable HTTP transport connection
 */
export interface HttpConnection {
    transport: 'http';
    url: string;
    headers?: Record<string, string>;
    /**
     * Whether to automatically fallback to SSE if Streamable HTTP is not available.
     * Defaults to true.
     */
    automaticSSEFallback?: boolean;
}
export type TMCPServerReconnect = {
    /**
     * Whether to automatically restart the process if it exits
     */
    enabled?: boolean;
    /**
     * Maximum number of restart attempts
     */
    maxAttempts?: number;
    /**
     * Delay in milliseconds between restart attempts
     */
    delayMs?: number;
};
/** Supported authentication modes for a host-consumed MCP server. */
export declare const MCP_CONSUMER_AUTH_TYPES: readonly ["none", "manual_header", "api_key", "oauth", "connector"];
/** Discriminator for MCP consumer authentication configuration. */
export type McpConsumerAuthType = (typeof MCP_CONSUMER_AUTH_TYPES)[number];
/** MCP authentication by mode; Connector credentials remain host-managed. */
export type TMcpConsumerAuth = {
    /** Use the caller's Connector authorization. */
    type: 'connector';
    /** Administrator-resolved binding. Never a token or a package-supplied machine ID. */
    bindingId: string;
    /** Registered Connector strategy key matching this binding. */
    provider: string;
    /** Resource/audience understood by the Connector provider. */
    resource?: string;
    /** Required scopes, revalidated by the Connector. */
    scopes?: string[];
} | {
    type: 'none';
} | {
    type: 'manual_header';
} | {
    type: 'api_key';
    /** Header used by the remote MCP server, for example Authorization or x-api-key. */
    headerName: string;
    /** Environment expression or value resolved by the existing MCP header resolver. */
    value: string;
} | {
    type: 'oauth';
    /** OAuth tokens are encrypted server-side and bound to this subject scope. */
    binding: 'user' | 'organization';
    scopes?: string[];
};
export interface IMcpConsumerOAuthStatus {
    status: 'disconnected' | 'pending' | 'connected' | 'expired' | 'error';
    authorizationUrl?: string | null;
    expiresAt?: string | null;
    scopes?: string[];
    message?: string | null;
}
export interface IMcpConsumerServerCapabilities {
    serverName: string;
    serverInfo?: {
        name: string;
        version: string;
    };
    instructions?: string;
    tools: Array<{
        name: string;
        title?: string;
        description?: string;
        inputSchema: McpJsonSchema;
        outputSchema?: McpJsonSchema;
        annotations?: McpToolAnnotations;
        taskSupport?: 'required' | 'optional' | 'forbidden';
        /** MCP Apps visibility from Tool._meta.ui; omitted only for older persisted discovery payloads. */
        visibility?: McpCapabilityVisibility[];
    }>;
    resources: Array<{
        uri: string;
        name: string;
        title?: string;
        description?: string;
        mimeType?: string;
    }>;
    resourceTemplates: Array<{
        uriTemplate: string;
        name: string;
        title?: string;
        description?: string;
        mimeType?: string;
        argumentSchema: McpJsonSchema;
    }>;
    prompts: Array<{
        name: string;
        title?: string;
        description?: string;
        argumentSchema: McpJsonSchema;
    }>;
    apps: Array<{
        toolName: string;
        title?: string;
        resourceUri: string;
    }>;
    supportsCompletion?: boolean;
    errors?: Partial<Record<'tools' | 'resources' | 'resourceTemplates' | 'prompts' | 'apps', string>>;
}
export type TMcpStdioRuntimePolicy = {
    /**
     * Runtime provider requested by the toolset or plugin. v1 supports
     * local-process; sandbox and sidecar are reserved extension points.
     */
    provider?: 'local-process' | 'sandbox' | 'sidecar' | string;
    /**
     * Maximum startup wait time in milliseconds.
     */
    startupTimeoutMs?: number;
    /**
     * Maximum idle lifetime in milliseconds before the host may close the runtime.
     */
    idleTimeoutMs?: number;
    /**
     * Maximum total lifetime in milliseconds.
     */
    maxLifetimeMs?: number;
    /**
     * Optional command allow-list requested by the plugin/toolset. The platform
     * allow-list remains authoritative.
     */
    allowedCommands?: string[];
};
export type TMCPServer = {
    type: MCPServerType;
    command?: string;
    args?: string[];
    env?: Record<string, string>;
    stderr?: 'pipe' | 'inherit' | 'ignore' | string;
    encoding?: string;
    encodingErrorHandler?: string;
    /**
     * Additional reconnection settings
     */
    reconnect?: TMCPServerReconnect;
    url?: string;
    headers?: Record<string, string>;
    /** Explicit authentication mode for external MCP Consumer connections. */
    auth?: TMcpConsumerAuth;
    useNodeEventSource?: boolean;
    /**
     * Whether to automatically fallback to SSE if Streamable HTTP is not available.
     * Defaults to true. Only applicable for HTTP transport.
     */
    automaticSSEFallback?: boolean;
    /**
     * Default timeout in milliseconds for tool execution. Must be greater than 0.
     * If not specified, tools will use their own configured timeout values.
     */
    defaultToolTimeout?: number;
    files?: {
        name: string;
        content: string;
    }[];
    toolNamePrefix?: string;
    /**
     * Init scripts for sandbox
     */
    initScripts?: string;
    /**
     * Requested stdio runtime policy. The platform clamps this policy before use.
     */
    runtime?: TMcpStdioRuntimePolicy;
};
export type TMCPSchema = {
    servers?: Record<string, TMCPServer>;
    mcpServers?: Record<string, TMCPServer>;
};
export declare const MCP_APP_RESOURCE_MIME_TYPE = "text/html;profile=mcp-app";
/** Optional host refresh action. Arguments are fixed by the resource provider. */
export type TMcpAppRefresh = {
    toolName: string;
    arguments?: Record<string, import('../core.model').JSONValue>;
};
export type TMcpAppUiMeta = {
    refresh?: TMcpAppRefresh;
    resourceUri: string;
    title?: string | I18nObject;
    description?: string | I18nObject;
    icon?: IconDefinition;
    /**
     * @deprecated MCP Apps resource security metadata belongs on the resource
     * content item `_meta.ui`. Tool-level values are kept only as a legacy
     * fallback while older plugins migrate.
     */
    csp?: TMcpAppCsp;
    /**
     * @deprecated MCP Apps resource security metadata belongs on the resource
     * content item `_meta.ui`. Tool-level values are kept only as a legacy
     * fallback while older plugins migrate.
     */
    permissions?: TMcpAppPermissions;
    domain?: string;
    prefersBorder?: boolean;
};
export type TMcpToolExecution = {
    taskSupport?: 'required' | 'optional' | 'forbidden';
};
export type TMcpToolAppMeta = {
    serverName: string;
    name: string;
    displayName: string;
    inputSchema?: Record<string, unknown>;
    visibility: TMcpAppVisibility[];
    ui?: TMcpAppUiMeta;
    annotations?: Record<string, unknown>;
    execution?: TMcpToolExecution;
    _meta?: Record<string, unknown>;
};
export type TMcpAppComponentData = {
    type: 'McpApp';
    appInstanceId: string;
    appInstanceToken?: string;
    resourceUri: string;
    toolName: string;
    toolCallId?: string;
    toolsetId?: string;
    serverName?: string;
    executionId?: string;
    title?: string | I18nObject;
    description?: string | I18nObject;
    icon?: IconDefinition;
    csp?: TMcpAppCsp;
    permissions?: TMcpAppPermissions;
    domain?: string;
    prefersBorder?: boolean;
    toolInput?: Record<string, unknown>;
    /**
     * Standardized initial CallToolResult used to replay MCP App history without
     * re-running the originating tool. Raw app HTML is never persisted here.
     */
    toolResult?: TMcpAppToolResult;
    /** Serialized byte size of the initial tool result when known. */
    toolResultSize?: number;
    /** True when the initial tool result was too large to inline in chat history. */
    toolResultTruncated?: boolean;
    visibility?: TMcpAppVisibility[];
    status?: 'running' | 'success' | 'fail';
    error?: string;
};
