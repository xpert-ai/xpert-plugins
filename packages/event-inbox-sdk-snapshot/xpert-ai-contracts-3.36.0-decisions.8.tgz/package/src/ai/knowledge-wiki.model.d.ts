import type { IDocChunkMetadata } from './knowledge-doc-chunk.model';
export declare const KNOWLEDGE_WIKI_SCHEMA_VERSION = 1;
export type KnowledgeWikiExtractionGranularity = 'focused' | 'standard' | 'exhaustive';
export type KnowledgebaseWikiConfig = {
    enabled: boolean;
    extractionGranularity: KnowledgeWikiExtractionGranularity;
    contentGenerationRequirements?: string;
    extractionFocus?: string;
};
export type ResolvedKnowledgebaseWikiConfig = KnowledgebaseWikiConfig & {
    contentGenerationRequirements: string;
    extractionFocus: string;
};
export declare const KNOWLEDGE_WIKI_MAX_CUSTOM_INSTRUCTION_LENGTH = 4000;
export declare const DEFAULT_KNOWLEDGEBASE_WIKI_CONFIG: {
    readonly enabled: false;
    readonly extractionGranularity: "standard";
    readonly contentGenerationRequirements: "";
    readonly extractionFocus: "";
};
export declare function normalizeKnowledgebaseWikiConfig(config?: Partial<KnowledgebaseWikiConfig> | null): ResolvedKnowledgebaseWikiConfig;
export type KnowledgeWikiStatus = 'disabled' | 'indexing' | 'ready' | 'failed' | 'rebuild_required';
export type KnowledgeWikiAvailability = 'unavailable' | 'ready' | 'degraded';
export type KnowledgeWikiPageType = 'summary' | 'entity' | 'concept' | 'index';
export type KnowledgeWikiMappedPageType = Exclude<KnowledgeWikiPageType, 'index'>;
export type KnowledgeWikiPageStatus = 'building' | 'ready' | 'stale' | 'failed' | 'archived';
export type KnowledgeWikiProjectionStatus = 'pending' | 'ready' | 'failed' | 'disabled';
export type KnowledgeWikiJobType = 'classify' | 'source_map' | 'identity_resolve' | 'page_reduce' | 'retract' | 'rebuild' | 'finalize';
export type KnowledgeWikiJobStatus = 'queued' | 'running' | 'succeeded' | 'failed' | 'stale' | 'cancelled';
export type KnowledgeWikiInvocationStatus = 'prepared' | 'running' | 'reconciling' | 'succeeded' | 'failed' | 'indeterminate';
export type KnowledgeWikiRecoveryAction = {
    jobId: string;
    invocationId: string;
    reconciliationStatus: 'not_available' | 'pending' | 'recovered' | 'not_executed' | 'indeterminate';
    failureReason?: 'preparation_failed' | 'request_rejected';
    canRetry: boolean;
    requiresAdditionalChargeConfirmation: boolean;
    inputCurrent: boolean;
    recommendedAction: 'wait' | 'retry_job' | 'full_rebuild';
};
export type KnowledgeWikiReaderStatus = {
    canManage: false;
    enabled: boolean;
    status: KnowledgeWikiStatus;
    availability: KnowledgeWikiAvailability;
    readyPageCount: number;
    requiresManagement: boolean;
    errorCode?: string | null;
};
export type KnowledgeWikiJobCounts = {
    queued: number;
    running: number;
    failed: number;
};
export type KnowledgeWikiPageCounts = {
    ready: number;
    stale: number;
    failed: number;
    archived: number;
    projectionFailed: number;
};
export type KnowledgeWikiManagementStatus = Omit<KnowledgeWikiReaderStatus, 'canManage'> & {
    canManage: true;
    activeRevision?: number | null;
    stagedRevision?: number | null;
    activeConfigFingerprint?: string | null;
    targetConfigFingerprint?: string | null;
    rebuildRequiredReason?: 'generator_upgrade' | null;
    generationJobs: KnowledgeWikiJobCounts;
    pages: KnowledgeWikiPageCounts;
    indeterminateInvocationCount: number;
    billingRecoveryCount: number;
    cleanupPendingCount: number;
    cleanupFailedCount: number;
    recoveryActions: KnowledgeWikiRecoveryAction[];
};
export type KnowledgeWikiStatusResponse = KnowledgeWikiReaderStatus | KnowledgeWikiManagementStatus;
export declare const KNOWLEDGE_WIKI_DOCUMENT_STATUS_BATCH_SIZE = 100;
export type KnowledgeWikiDocumentStatusResponse = {
    /** Sources of currently published, usable Wiki pages, not merely completed parsing jobs. */
    indexedDocumentIds: string[];
    documents?: KnowledgeWikiDocumentProgress[];
};
export type KnowledgeWikiDocumentProgressState = 'not_started' | 'queued' | 'generating' | 'indexing' | 'publishing' | 'ready' | 'failed' | 'outdated' | 'no_content';
export type KnowledgeWikiDocumentStageState = 'pending' | 'running' | 'complete' | 'failed' | 'skipped';
export type KnowledgeWikiDocumentProgress = {
    documentId: string;
    state: KnowledgeWikiDocumentProgressState;
    stages: {
        generation: KnowledgeWikiDocumentStageState;
        indexing: KnowledgeWikiDocumentStageState;
        publication: KnowledgeWikiDocumentStageState;
    };
    /** A full rebuild publishes as a batch; another source can block publication. */
    waitingForBatch?: boolean;
    error?: string;
    errorCode?: string;
    retry?: {
        jobId: string;
        requiresAdditionalChargeConfirmation: boolean;
    };
    canView: boolean;
};
export type KnowledgeWikiPageContributionPayload = {
    schemaVersion: typeof KNOWLEDGE_WIKI_SCHEMA_VERSION;
    pageType: KnowledgeWikiMappedPageType;
    canonicalName: string;
    aliases: string[];
    summary: string;
    facts: Array<{
        text: string;
        sourceChunkIds: string[];
    }>;
    suggestedLinks: Array<{
        targetType: KnowledgeWikiPageType;
        targetCanonicalName: string;
        label?: string;
    }>;
};
/** One source's contributions after identity resolution. Aggregate counts may exceed Map output limits. */
export type KnowledgeWikiPageSourcePayload = KnowledgeWikiPageContributionPayload;
export declare const KNOWLEDGE_WIKI_MAX_ALIASES = 20;
export declare const KNOWLEDGE_WIKI_MAX_FACTS = 100;
export declare const KNOWLEDGE_WIKI_MAX_SUGGESTED_LINKS = 50;
export declare const KNOWLEDGE_WIKI_MAX_SOURCE_CHUNKS_PER_FACT = 50;
export declare const KNOWLEDGE_WIKI_MAX_CANONICAL_NAME_LENGTH = 512;
export declare const KNOWLEDGE_WIKI_MAX_SUMMARY_LENGTH = 8000;
export declare const KNOWLEDGE_WIKI_MAX_FACT_LENGTH = 4000;
export declare function isKnowledgeWikiPageContributionPayload(value: unknown): value is KnowledgeWikiPageContributionPayload;
export declare function isKnowledgeWikiPageSourcePayload(value: unknown): value is KnowledgeWikiPageSourcePayload;
export type KnowledgeWikiPageGroup = 'knowledge' | 'summary';
export type KnowledgeWikiPageListParams = {
    pageGroup?: KnowledgeWikiPageGroup;
    folderId?: string;
    unclassified?: boolean;
    search?: string;
    pageType?: KnowledgeWikiPageType;
    status?: KnowledgeWikiPageStatus;
    skip?: number;
    take?: number;
};
export type KnowledgeWikiPageListItem = {
    identityId?: string | null;
    placement?: import('./knowledge-wiki-organization.model').KnowledgeWikiPlacement;
    id: string;
    pageKey: string;
    pageType: KnowledgeWikiPageType;
    canonicalName: string;
    title: string;
    slug: string;
    summary: string;
    aliases: string[];
    status: KnowledgeWikiPageStatus;
    projectionStatus: KnowledgeWikiProjectionStatus;
    updatedAt?: Date;
};
export type KnowledgeWikiPageListResult = {
    items: KnowledgeWikiPageListItem[];
    total: number;
};
export type KnowledgeWikiPageEvidence = {
    id: string;
    sourceDocumentId: string;
    sourceChunkId: string;
    quote: string;
    ordinal: number;
    sectionAnchor?: string | null;
    sourceAvailable: boolean;
};
export type KnowledgeWikiPageLink = {
    pageId: string;
    pageType: KnowledgeWikiPageType;
    title: string;
    slug: string;
    sectionAnchor?: string | null;
    label?: string | null;
};
export type KnowledgeWikiPageDetail = KnowledgeWikiPageListItem & {
    markdown: string;
    revision: number;
    links: KnowledgeWikiPageLink[];
    backlinks: KnowledgeWikiPageLink[];
    evidence: KnowledgeWikiPageEvidence[];
};
export interface IKnowledgeWikiChunkMetadata extends IDocChunkMetadata {
    contentKind: 'wiki';
    wikiPageId: string;
    wikiPageVersionId: string;
    wikiPageKey: string;
    wikiPageType: KnowledgeWikiPageType;
    wikiRevision: number;
    sectionAnchor: string;
    projectionStatus: KnowledgeWikiProjectionStatus;
}
export declare function isKnowledgeWikiChunkMetadata(value: unknown): value is IKnowledgeWikiChunkMetadata;
export declare const KNOWLEDGE_WIKI_DEFAULT_PAGE_SIZE = 50;
export declare const KNOWLEDGE_WIKI_MAX_PAGE_SIZE = 100;
export declare const KNOWLEDGE_WIKI_MAX_SEARCH_LENGTH = 200;
export declare const KNOWLEDGE_WIKI_FAILED_CONTENT_RETENTION_DAYS = 7;
export declare const KNOWLEDGE_WIKI_OPERATION_RETENTION_DAYS = 30;
export declare const KNOWLEDGE_WIKI_DELETION_RECEIPT_RETENTION_DAYS = 90;
export declare const KNOWLEDGE_WIKI_STALE_VECTOR_CLEANUP_SLO_HOURS = 24;
