import { IBasePerTenantEntityModel } from '../base-entity.model';
import { IOrganization } from '../organization.model';
import { AiProvider } from './ai.model';
import { ICopilot, TCopilotTokenUsage } from './copilot.model';
/**
 * Organization token usage of global copilot
 */
export interface ICopilotOrganization extends IBasePerTenantEntityModel, TCopilotTokenUsage {
    organizationId?: string;
    organization?: IOrganization;
    copilotId?: string;
    copilot?: ICopilot;
    provider?: AiProvider | string;
    model?: string;
    tokenTotalUsed?: number;
    priceTotalUsed?: number;
}
