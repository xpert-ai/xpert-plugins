import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IUser } from '../user.model';
import type { BosiOnboardingPreferences } from './bosi.model';
export declare enum AssistantCode {
    CHAT_COMMON = "chat_common",
    XPERT_SHARED = "xpert_shared",
    CLAWXPERT = "clawxpert"
}
export declare enum AssistantBindingScope {
    TENANT = "tenant",
    ORGANIZATION = "organization",
    USER = "user"
}
export declare enum AssistantBindingSourceScope {
    NONE = "none",
    TENANT = "tenant",
    ORGANIZATION = "organization"
}
export type AssistantManagement = 'system' | 'user';
export interface IAssistantBindingToolsetPreference {
    toolsetId?: string | null;
    toolsetName: string;
    disabledTools: string[];
}
export interface IAssistantBindingMiddlewarePreference {
    provider: string;
    disabledTools: string[];
}
export interface IAssistantBindingSkillPreference {
    workspaceId: string;
    disabledSkillIds: string[];
}
export type AssistantBindingToolPreferenceSourceType = 'toolset' | 'middleware';
export type AssistantBindingToolPreferenceSourceMetadata = {
    toolsetId?: string | null;
    toolsetName: string;
} | {
    provider: string;
};
export interface IAssistantBindingConversationPreferences {
    version: 2;
    defaultThreadId?: string | null;
    lastThreadId?: string | null;
    defaultFollowUpBehavior?: 'queue' | 'steer';
}
export interface IAssistantBindingToolPreferences {
    version: number;
    toolsets?: Record<string, IAssistantBindingToolsetPreference>;
    middlewares?: Record<string, IAssistantBindingMiddlewarePreference>;
    skills?: Record<string, IAssistantBindingSkillPreference>;
}
export declare function normalizeAssistantBindingToolPreferences(value?: IAssistantBindingToolPreferences | null): IAssistantBindingToolPreferences | null;
export declare function isAssistantBindingToolPreferencesEmpty(preferences?: IAssistantBindingToolPreferences | null): boolean;
export declare function getAssistantBindingDisabledTools(preferences: IAssistantBindingToolPreferences | null | undefined, sourceType: AssistantBindingToolPreferenceSourceType, nodeKey: string | null | undefined): string[];
export declare function getAssistantBindingDisabledSkillIds(preferences: IAssistantBindingToolPreferences | null | undefined, workspaceId: string | null | undefined): string[];
export declare function isAssistantBindingToolEnabled(preferences: IAssistantBindingToolPreferences | null | undefined, sourceType: AssistantBindingToolPreferenceSourceType, nodeKey: string | null | undefined, toolName: string): boolean;
export declare function isAssistantBindingSkillEnabled(preferences: IAssistantBindingToolPreferences | null | undefined, workspaceId: string | null | undefined, skillId: string): boolean;
export declare function filterAssistantBindingDisabledTools<T extends {
    name: string;
}>(tools: T[], preferences: IAssistantBindingToolPreferences | null | undefined, sourceType: AssistantBindingToolPreferenceSourceType, nodeKey: string | null | undefined): T[];
export declare function filterAssistantBindingDisabledSkillIds(skillIds: string[], preferences: IAssistantBindingToolPreferences | null | undefined, workspaceId: string | null | undefined): string[];
export declare function updateAssistantBindingToolPreferences(preferences: IAssistantBindingToolPreferences | null | undefined, sourceType: AssistantBindingToolPreferenceSourceType, nodeKey: string | null | undefined, metadata: AssistantBindingToolPreferenceSourceMetadata, toolName: string, enabled: boolean): IAssistantBindingToolPreferences | null;
export declare function updateAssistantBindingSkillPreferences(preferences: IAssistantBindingToolPreferences | null | undefined, workspaceId: string | null | undefined, skillId: string, enabled: boolean): IAssistantBindingToolPreferences | null;
export declare function ensureAssistantBindingSkillWorkspacePreference(preferences: IAssistantBindingToolPreferences | null | undefined, workspaceId: string): IAssistantBindingToolPreferences;
export interface IAssistantBinding extends IBasePerTenantAndOrganizationEntityModel {
    /** Defaults for the binding owner's private workspace, not organization-wide installation or access grants. */
    desktopOnboarding?: BosiOnboardingPreferences | null;
    code: AssistantCode;
    scope: AssistantBindingScope;
    assistantId?: string | null;
    enabled?: boolean | null;
    userId?: string | null;
    user?: IUser;
    preferences?: IAssistantBindingUserPreference[];
}
export interface IAssistantBindingUserPreference extends IBasePerTenantAndOrganizationEntityModel {
    assistantBindingId: string;
    assistantBinding?: IAssistantBinding;
    userId?: string | null;
    user?: IUser;
    soul?: string | null;
    profile?: string | null;
    toolPreferences?: IAssistantBindingToolPreferences | null;
    conversationPreferences?: IAssistantBindingConversationPreferences | null;
}
export interface IResolvedAssistantBinding extends IAssistantBinding {
    sourceScope: AssistantBindingSourceScope;
}
export interface IAssistantBindingUpsertInput {
    code: AssistantCode;
    scope: AssistantBindingScope;
    assistantId?: string | null;
    enabled?: boolean;
}
export interface IAssistantBindingUserPreferenceUpsertInput {
    scope: AssistantBindingScope;
    soul?: string | null;
    profile?: string | null;
    toolPreferences?: IAssistantBindingToolPreferences | null;
    conversationPreferences?: IAssistantBindingConversationPreferences | null;
}
export declare function getAssistantManagement(code: AssistantCode): AssistantManagement;
export declare function isUserManagedAssistant(code: AssistantCode): boolean;
export declare function isSystemManagedAssistant(code: AssistantCode): boolean;
