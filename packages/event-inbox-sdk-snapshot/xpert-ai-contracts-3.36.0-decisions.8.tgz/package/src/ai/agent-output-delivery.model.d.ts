import { z } from 'zod/v3';
export declare const AGENT_OUTPUT_MAX_PATHS = 128;
/** Relative file selections only. A declaration does not grant filesystem access. */
export declare const agentResultPathSchema: z.ZodEffects<z.ZodString, string, string>;
/** Omission means no file delivery. A report file is optional and independent of artifact export mode. */
export declare const agentOutputDeliverySchema: z.ZodDiscriminatedUnion<"mode", [z.ZodObject<{
    mode: z.ZodLiteral<"none">;
    reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
}, "strict", z.ZodTypeAny, {
    mode: "none";
    reportPath?: string | undefined;
}, {
    mode: "none";
    reportPath?: string | undefined;
}>, z.ZodObject<{
    mode: z.ZodLiteral<"files">;
    paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
    reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
}, "strict", z.ZodTypeAny, {
    mode: "files";
    reportPath?: string | undefined;
    paths?: string[] | undefined;
}, {
    mode: "files";
    reportPath?: string | undefined;
    paths?: string[] | undefined;
}>, z.ZodObject<{
    mode: z.ZodLiteral<"archive">;
    paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
    reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
}, "strict", z.ZodTypeAny, {
    mode: "archive";
    reportPath?: string | undefined;
    paths?: string[] | undefined;
}, {
    mode: "archive";
    reportPath?: string | undefined;
    paths?: string[] | undefined;
}>]>;
export type AgentOutputDelivery = z.output<typeof agentOutputDeliverySchema>;
/** A delivery retry cannot relaunch the executor or change its originally selected report. */
export declare const agentDeliveryRecoverySchema: z.ZodObject<{
    expectedRevision: z.ZodNumber;
    paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
}, "strict", z.ZodTypeAny, {
    expectedRevision: number;
    paths?: string[] | undefined;
}, {
    expectedRevision: number;
    paths?: string[] | undefined;
}>;
export type AgentDeliveryRecovery = z.output<typeof agentDeliveryRecoverySchema>;
