import { z } from 'zod/v3';
import type { JsonSchemaObjectType } from './types';
import type { XpertProjectTypeRef } from './xpert-project-type.model';
export type ProjectConfigurationValue = string | number | boolean | null | ProjectConfigurationValue[] | {
    [key: string]: ProjectConfigurationValue;
};
export type ProjectConfigurationValues = {
    [key: string]: ProjectConfigurationValue;
};
export declare const projectConfigurationValuesSchema: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodType<ProjectConfigurationValue, z.ZodTypeDef, ProjectConfigurationValue>>, Record<string, ProjectConfigurationValue>, Record<string, ProjectConfigurationValue>>;
export declare const projectConfigurationUpdateSchema: z.ZodObject<{
    revision: z.ZodNumber;
    values: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodType<ProjectConfigurationValue, z.ZodTypeDef, ProjectConfigurationValue>>, Record<string, ProjectConfigurationValue>, Record<string, ProjectConfigurationValue>>;
}, "strict", z.ZodTypeAny, {
    values?: Record<string, ProjectConfigurationValue>;
    revision?: number;
}, {
    values?: Record<string, ProjectConfigurationValue>;
    revision?: number;
}>;
export type ProjectConfigurationUpdate = z.output<typeof projectConfigurationUpdateSchema>;
/** Non-secret, type-defined settings. JSON Schema defaults are applied by the host. */
export interface XpertProjectTypeConfigurationDefinition {
    schema: JsonSchemaObjectType;
}
export interface ProjectTaskDurationConfiguration {
    projectType: XpertProjectTypeRef;
    configurationRevision: number;
    /** Absent preserves the tenant's default duration. */
    maxDurationSeconds?: number;
}
export interface XpertProjectConfigurationView {
    projectType: XpertProjectTypeRef;
    revision: number;
    schema?: JsonSchemaObjectType;
    values: ProjectConfigurationValues;
    effectiveValues: ProjectConfigurationValues;
    canEdit: boolean;
    taskExecution: {
        configuredMaxDurationSeconds?: number;
        defaultDurationSeconds: number;
        tenantMaxDurationSeconds: number;
        effectiveMaxDurationSeconds: number;
    };
}
/** Reserved host setting; custom type settings remain uninterpreted by the runtime. */
export declare const projectTaskDurationSchema: z.ZodNumber;
export declare function projectTaskConfigurationSchema(defaultSeconds?: number): JsonSchemaObjectType;
