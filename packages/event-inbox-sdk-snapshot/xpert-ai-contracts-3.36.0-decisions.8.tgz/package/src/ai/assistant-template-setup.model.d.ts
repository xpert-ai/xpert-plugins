import { z } from 'zod';
import type { TemplateManifest } from './assistant-template-manifest.model';
export declare const templatePreferenceValuesSchema: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodString>, Record<string, string>, Record<string, string>>;
export declare const assistantTemplateSetupStateSchema: z.ZodObject<{
    revision: z.ZodNumber;
    preferences: z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodString>, Record<string, string>, Record<string, string>>;
    completedAt: z.ZodOptional<z.ZodString>;
    firstResult: z.ZodOptional<z.ZodString>;
    connectors: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<"choice", [z.ZodObject<{
        choice: z.ZodLiteral<"binding">;
        bindingId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        bindingId?: string;
        choice?: "binding";
    }, {
        bindingId?: string;
        choice?: "binding";
    }>, z.ZodObject<{
        choice: z.ZodLiteral<"skip">;
    }, "strict", z.ZodTypeAny, {
        choice?: "skip";
    }, {
        choice?: "skip";
    }>]>>;
}, "strict", z.ZodTypeAny, {
    preferences?: Record<string, string>;
    connectors?: Record<string, {
        bindingId?: string;
        choice?: "binding";
    } | {
        choice?: "skip";
    }>;
    completedAt?: string;
    revision?: number;
    firstResult?: string;
}, {
    preferences?: Record<string, string>;
    connectors?: Record<string, {
        bindingId?: string;
        choice?: "binding";
    } | {
        choice?: "skip";
    }>;
    completedAt?: string;
    revision?: number;
    firstResult?: string;
}>;
export type AssistantTemplateSetupState = z.output<typeof assistantTemplateSetupStateSchema>;
export declare const templateSetupUpdateSchema: z.ZodObject<{
    revision: z.ZodNumber;
    preferences: z.ZodOptional<z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodString>, Record<string, string>, Record<string, string>>>;
    firstResult: z.ZodOptional<z.ZodString>;
    connector: z.ZodOptional<z.ZodObject<{
        key: z.ZodString;
        selection: z.ZodDiscriminatedUnion<"choice", [z.ZodObject<{
            choice: z.ZodLiteral<"binding">;
            bindingId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            bindingId?: string;
            choice?: "binding";
        }, {
            bindingId?: string;
            choice?: "binding";
        }>, z.ZodObject<{
            choice: z.ZodLiteral<"skip">;
        }, "strict", z.ZodTypeAny, {
            choice?: "skip";
        }, {
            choice?: "skip";
        }>]>;
    }, "strict", z.ZodTypeAny, {
        selection?: {
            bindingId?: string;
            choice?: "binding";
        } | {
            choice?: "skip";
        };
        key?: string;
    }, {
        selection?: {
            bindingId?: string;
            choice?: "binding";
        } | {
            choice?: "skip";
        };
        key?: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    preferences?: Record<string, string>;
    revision?: number;
    connector?: {
        selection?: {
            bindingId?: string;
            choice?: "binding";
        } | {
            choice?: "skip";
        };
        key?: string;
    };
    firstResult?: string;
}, {
    preferences?: Record<string, string>;
    revision?: number;
    connector?: {
        selection?: {
            bindingId?: string;
            choice?: "binding";
        } | {
            choice?: "skip";
        };
        key?: string;
    };
    firstResult?: string;
}>;
export type TemplateSetupUpdate = z.output<typeof templateSetupUpdateSchema>;
export interface AssistantTemplateSetup {
    assistantId: string;
    state: AssistantTemplateSetupState;
    onboarding?: TemplateManifest['onboarding'];
    connectors: {
        key: string;
        provider: string;
        required: boolean;
        purpose: string;
        permissions: string[];
        status: 'ready' | 'skipped' | 'requires_auth' | 'expired' | 'unavailable';
        options: {
            bindingId: string;
            label: string;
            status: string;
            runtimeUsage?: 'middleware' | 'credential';
        }[];
    }[];
    managementUrl?: string;
    routines: TemplateRoutineStatus[];
}
export interface TemplateRoutineStatus {
    key: string;
    supported: boolean;
    skill: string;
    output: string;
    taskId?: string;
    enabled: boolean;
    expression: string;
    timeZone?: string;
    nextRunAt?: string;
}
/** Assistant execution policy, independent of template delivery metadata. Exact tool names only. */
export declare const assistantOperationPolicySchema: z.ZodEffects<z.ZodObject<{
    default: z.ZodEnum<["allow", "approve", "deny"]>;
    rules: z.ZodArray<z.ZodObject<{
        tool: z.ZodString;
        decision: z.ZodEnum<["allow", "approve", "deny"]>;
        reason: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }, {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    default?: "allow" | "deny" | "approve";
    rules?: {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }[];
}, {
    default?: "allow" | "deny" | "approve";
    rules?: {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }[];
}>, {
    default?: "allow" | "deny" | "approve";
    rules?: {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }[];
}, {
    default?: "allow" | "deny" | "approve";
    rules?: {
        reason?: string;
        tool?: string;
        decision?: "allow" | "deny" | "approve";
    }[];
}>;
export type AssistantOperationPolicy = z.output<typeof assistantOperationPolicySchema>;
