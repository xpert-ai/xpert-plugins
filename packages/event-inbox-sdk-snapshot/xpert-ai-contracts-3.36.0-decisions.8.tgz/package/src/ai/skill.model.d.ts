import type { ChatKitPromptWorkflow, ChatKitSlashCommand, ChatKitSlashCommandAction, ChatKitSlashCommandAvailability, ChatKitSlashCommandCapability, ChatKitSlashCommandKind } from '@xpert-ai/chatkit-types';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { I18nObject, IconDefinition } from '../types';
import { JsonSchemaObjectType } from './types';
import { IWorkflowNode, WorkflowNodeTypeEnum } from './xpert-workflow.model';
import { IBasePerWorkspaceEntityModel } from './xpert-workspace.model';
export type SkillId = string;
export type TRuntimeSkillSource = {
    type: 'xpert';
    ownerId: string;
    label: string;
    skillId: string;
} | {
    type: 'project';
    ownerId: string;
    label: string;
    skillId: string;
};
export declare function createRuntimeSkillCapabilityId(source: Pick<TRuntimeSkillSource, 'type' | 'ownerId' | 'skillId'>): string;
export declare function parseRuntimeSkillCapabilityId(id: string): Pick<TRuntimeSkillSource, 'type' | 'ownerId' | 'skillId'> | null;
export declare const WORKSPACE_PUBLIC_SKILL_SOURCE_PROVIDER = "workspace-public";
export declare const WORKSPACE_PUBLIC_SKILL_REPOSITORY_NAME = "Workspace Shared Skills";
export interface ISkillRepositoryIndexStats {
    comments?: number;
    downloads?: number;
    installsAllTime?: number;
    installsCurrent?: number;
    stars?: number;
    versions?: number;
}
export interface ISkillRepositoryIndexPublisher {
    handle?: string;
    displayName?: string;
    name?: string;
    image?: string;
    kind?: string;
}
export type SkillSlashCommandCapability = ChatKitSlashCommandCapability;
export type SkillSlashCommandAction = ChatKitSlashCommandAction;
export type SkillSlashCommandAvailability = ChatKitSlashCommandAvailability;
export type SkillSlashCommandKind = ChatKitSlashCommandKind;
export type SkillPromptWorkflow = ChatKitPromptWorkflow;
export type SkillSlashCommand = Omit<ChatKitSlashCommand, 'icon'> & {
    icon?: ChatKitSlashCommand['icon'] | IconDefinition;
};
export interface IShareSkillPackageInput {
    displayName: string;
    description: string;
    tags?: string[];
    license?: string;
    version?: string;
}
export interface SkillMetadata {
    name: string;
    displayName?: I18nObject;
    version: string;
    summary?: I18nObject;
    description?: I18nObject;
    icon?: IconDefinition;
    color?: string;
    tags?: string[];
    author?: {
        name: string;
        email?: string;
        org?: string;
    };
    license?: string;
    visibility: 'private' | 'team' | 'tenant' | 'public';
    categories?: string[];
    runtime?: {
        entry?: string;
        language?: 'js' | 'py' | 'bash';
        permissions?: string[];
        tools?: string[];
    };
    commands?: SkillSlashCommand[];
    mcp?: {
        servers?: string[];
    };
    provenance?: Record<string, unknown>;
}
export interface SkillResourcesIndex {
    files: Array<{
        path: string;
        kind: 'script' | 'template' | 'doc' | 'asset';
        hash: string;
        size: number;
    }>;
    chunks?: Array<{
        id: string;
        path: string;
        summary: string;
        tokens: number;
    }>;
}
export interface TSkillPackage {
    metadata: SkillMetadata;
    instructions: {
        system?: string;
        developer?: string;
        examples?: Array<{
            user: string;
            assistant: string;
        }>;
        guidelines?: string[];
    };
    resources?: SkillResourcesIndex;
    abac?: {
        owners: string[];
        readers: string[];
        writers: string[];
        policies?: Record<string, unknown>;
    };
    signatures?: string[];
    provenance?: Record<string, unknown>;
}
/**
 * Represents a repository (e.g. anthropics/skills)
 */
export interface ISkillRepository<O = Record<string, unknown>, C = Record<string, unknown>> extends IBasePerTenantAndOrganizationEntityModel {
    name: string;
    provider: string;
    /**
     * Provider credentials such as GitHub tokens
     */
    credentials?: C;
    /**
     * Options configured using the strategy's configSchema
     */
    options?: O;
    lastSyncAt?: Date;
    deletedAt?: Date;
}
/**
 * Skill index produced by repository sync scan (one per skill directory)
 */
export interface ISkillRepositoryIndex extends IBasePerTenantAndOrganizationEntityModel {
    repositoryId: string;
    repository?: ISkillRepository;
    skillPath: string;
    skillId: string;
    name?: string;
    link?: string;
    publisher?: ISkillRepositoryIndexPublisher;
    description?: string;
    license?: string;
    tags?: string[];
    version?: string;
    stats?: ISkillRepositoryIndexStats;
    resources?: Array<Record<string, unknown>>;
    deletedAt?: Date;
}
export interface ISkillMarketFilterOption {
    value: string;
    label: string;
    description?: string;
}
export interface ISkillMarketFilterGroup {
    label: string;
    options: ISkillMarketFilterOption[];
}
export interface ISkillMarketFilterGroups {
    roles: ISkillMarketFilterGroup;
    appTypes: ISkillMarketFilterGroup;
    hot: ISkillMarketFilterGroup;
}
export interface ISkillMarketFeaturedRef {
    provider: string;
    repositoryName: string;
    skillId: string;
    badge?: string;
    title?: string;
    description?: string;
    avatar?: IconDefinition;
}
export interface ISkillMarketFeaturedSkill extends ISkillMarketFeaturedRef {
    skill: ISkillRepositoryIndex;
}
export interface ISkillMarketConfig {
    featured: ISkillMarketFeaturedSkill[];
    filters: ISkillMarketFilterGroups;
}
/**
 * Installed skill package record (skill.yaml)
 */
export interface ISkillPackage extends IBasePerWorkspaceEntityModel, TSkillPackage {
    skillIndexId?: SkillId;
    skillIndex?: ISkillRepositoryIndex;
    name?: string;
    visibility: 'private' | 'team' | 'tenant';
    packagePath?: string;
    sharedSkillId?: string;
    sharedPackagePath?: string;
}
/**
 * Skill version (multiple versions can coexist per skill)
 */
export interface ISkillVersion extends IBasePerWorkspaceEntityModel {
    packageId: string;
    version: string;
    metadata: SkillMetadata;
    instructions: TSkillPackage['instructions'];
    installedAt?: string;
}
/**
 * Skill resource file record (scripts/templates/assets)
 */
export interface ISkillResource extends IBasePerWorkspaceEntityModel {
    versionId: string;
    path: string;
    type: 'script' | 'template' | 'asset' | 'doc';
    hash?: string;
    size?: number;
    meta?: Record<string, unknown>;
}
/**
 * Tenant/organization/team/user installation record
 */
export interface ISkillInstallation extends IBasePerTenantAndOrganizationEntityModel {
    versionId: string;
    installedBy: string;
    visibility: 'private' | 'team' | 'tenant';
    targetScope?: string;
    status: 'pending' | 'installed' | 'failed';
}
/**
 * Detailed logs during skill installation
 */
export interface ISkillInstallLog extends IBasePerTenantAndOrganizationEntityModel {
    installationId: string;
    level: 'info' | 'warn' | 'error';
    message: string;
    timestamp: string;
}
/**
 * Runtime audit log for skills
 */
export interface ISkillAuditLog extends IBasePerTenantAndOrganizationEntityModel {
    skillId: string;
    versionId: string;
    sessionId: string;
    eventType: string;
    metadata: Record<string, unknown>;
}
export type TSkillSourceMeta = {
    /**
     * Provider name, e.g. github / git / zip / marketplace
     */
    name: string;
    label: I18nObject;
    icon?: IconDefinition;
    description?: I18nObject;
    /**
     * Optional configuration schema for frontend forms
     */
    configSchema?: JsonSchemaObjectType;
    /**
     * Credential schema for source authentication
     */
    credentialSchema?: JsonSchemaObjectType;
};
export interface IWFNSkill extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.SKILL;
    skills?: string[];
}
export declare function genXpertSkillKey(): string;
