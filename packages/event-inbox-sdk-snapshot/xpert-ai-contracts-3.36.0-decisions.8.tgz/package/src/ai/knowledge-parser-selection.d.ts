import type { IKnowledgeDocument } from './knowledge-doc.model';
import type { KnowledgebaseParserConfig, KnowledgeParserSelection } from './knowledgebase.model';
export declare const BUILTIN_KNOWLEDGE_PARSER = "builtin";
/** Only formats with a real builtin reader; unknown binary formats are not advertised as text. */
export declare const BUILTIN_KNOWLEDGE_FILE_TYPES: string[];
export declare function knowledgeDocumentFileType(document: Partial<Pick<IKnowledgeDocument, 'type' | 'mimeType'>>): string;
export declare function knowledgebaseParserSelection(config: Partial<KnowledgebaseParserConfig> | null | undefined, documentType: string): KnowledgeParserSelection | undefined;
/** Existing uploader/importer defaults plus capabilities advertised by installed document parsers.
 * Explicit caller restrictions remain authoritative; this does not grant builtin parsing support.
 */
export declare function knowledgeUploadFileTypes(defaults: readonly string[], providers: readonly {
    supportedFileTypes?: string[];
}[], accepts?: readonly string[] | null): string[];
