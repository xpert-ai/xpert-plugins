/** Provenance is descriptive, never an execution principal or an authorization grant. */
export type TChatMessageSource = {
    type: 'user';
    userId: string;
} | {
    type: 'voice';
    sessionId: string;
} | {
    type: 'assistant';
    xpertId: string;
} | {
    type: 'agent';
    xpertId: string;
    agentKey: string;
} | {
    type: 'runtime';
    provider: string;
    bindingId: string;
    invocationId: string;
} | {
    type: 'automation';
    taskId: string;
};
/** Presentation does not change model roles or remove input from execution/retry history. */
export type TChatMessagePresentation = 'message' | 'event' | 'runtime';
/** Host-created provenance, persisted in ChatMessage.messageEnvelope. */
export interface TChatMessageEnvelope {
    version: 1;
    source: TChatMessageSource;
    presentation: TChatMessagePresentation;
    /** Audited destination, not routing instructions. The authorized request owns routing. */
    target?: {
        xpertId: string;
        agentKey?: string;
        conversationId?: string;
        threadId?: string;
    };
    correlation?: {
        messageId?: string;
        replyToMessageId?: string;
        executionId?: string;
        invocationId?: string;
        /** Existing platform task identity; never substitute a Project Task ID. */
        taskId?: string;
        projectTaskId?: string;
        taskExecutionId?: string;
    };
}
/** Persistence boundary: unknown versions stay hidden until this host understands their policy. */
export declare function chatMessagePresentation(message: {
    messageEnvelope?: unknown;
}): TChatMessagePresentation;
export declare function isRuntimeChatMessage(message: {
    messageEnvelope?: unknown;
}): boolean;
