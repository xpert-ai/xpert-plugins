import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { type PluginMarketplaceCategory } from '../plugin';
import { IUser } from '../user.model';
import { IUserGroup } from '../user-group.model';
import { WorkflowNodeTypeEnum } from './xpert-workflow.model';
import type { TXpertTemplate } from './xpert-template.model';
import type { IXpert, TXpertTeamDraft } from './xpert.model';
export declare const XpertMarketplaceBusinessCategories: readonly ["featured", "business-operations", "communication", "creativity", "data-analytics", "developer-tools", "education-research", "finance", "productivity", "research", "security", "travel", "sales", "other"];
export type TXpertMarketplaceBusinessCategory = PluginMarketplaceCategory;
export declare const XpertMarketplaceCollaborationModes: readonly ["single-agent", "multi-agent", "human-in-loop"];
export type TXpertMarketplaceCollaborationMode = (typeof XpertMarketplaceCollaborationModes)[number];
export declare const XpertMarketplaceTechnicalCategories: readonly ["knowledge-retrieval", "tool-calling", "workflow", "external-xpert", "file-understanding", "sandbox", "trigger", "http", "code", "database", "structured-output"];
export type TXpertMarketplaceTechnicalCategory = (typeof XpertMarketplaceTechnicalCategories)[number];
export type TXpertMarketplaceTechnicalProfile = {
    agentCount: number;
    toolsetCount: number;
    knowledgebaseCount: number;
    externalXpertCount: number;
    workflowNodeCount: number;
    workflowNodeTypes: WorkflowNodeTypeEnum[];
    categories: TXpertMarketplaceTechnicalCategory[];
    collaborationModes: TXpertMarketplaceCollaborationMode[];
};
export type TXpertMarketplaceProfile = {
    summary?: string | null;
    businessCategories?: TXpertMarketplaceBusinessCategory[];
    capabilityTags?: string[];
    collaborationModes?: TXpertMarketplaceCollaborationMode[];
    technical?: TXpertMarketplaceTechnicalProfile;
    featured?: boolean;
};
export declare enum XpertAccessRequestStatusEnum {
    REQUESTED = "requested",
    APPROVED = "approved",
    REJECTED = "rejected"
}
export type XpertAccessRequestStatus = XpertAccessRequestStatusEnum.REQUESTED | XpertAccessRequestStatusEnum.APPROVED | XpertAccessRequestStatusEnum.REJECTED;
export type TXpertMarketplaceAccessStatus = 'not_requested' | 'requested' | 'approved' | 'rejected' | 'accessible' | 'owned';
export interface IXpertAccessRequest extends IBasePerTenantAndOrganizationEntityModel {
    xpertId: string;
    xpert?: IXpert;
    requesterId: string;
    requester?: IUser;
    reviewerId?: string | null;
    reviewer?: IUser | null;
    accessGroupId?: string | null;
    accessGroup?: IUserGroup | null;
    status: XpertAccessRequestStatus;
    reason?: string | null;
    response?: string | null;
    reviewedAt?: Date | string | null;
}
export type TXpertMarketplaceQuery = {
    search?: string | null;
    businessAreaIds?: string[];
    businessCategories?: TXpertMarketplaceBusinessCategory[];
    capabilityTags?: string[];
    collaborationModes?: TXpertMarketplaceCollaborationMode[];
    technicalCategories?: TXpertMarketplaceTechnicalCategory[];
    status?: TXpertMarketplaceAccessStatus | null;
    sort?: 'match' | 'hot' | 'updated';
    skip?: number;
    take?: number;
};
export type TXpertAccessRequestCreateInput = {
    reason?: string | null;
};
export type TXpertAccessRequestDecisionInput = {
    response?: string | null;
};
export type TXpertPublishMarketplaceInput = Pick<TXpertMarketplaceProfile, 'summary' | 'businessCategories' | 'capabilityTags' | 'featured'>;
export type IXpertMarketplaceItem = {
    xpert: IXpert;
    marketplace: TXpertMarketplaceProfile;
    accessStatus: TXpertMarketplaceAccessStatus;
    request?: IXpertAccessRequest | null;
    canReview: boolean;
};
export type IXpertMarketplaceListResponse = {
    items: IXpertMarketplaceItem[];
    businessAreas?: {
        id: string;
        name: string;
    }[];
    recommendedTemplates: TXpertTemplate[];
    total: number;
    reviewableCount: number;
};
export declare function deriveXpertMarketplaceTechnicalProfile(draft?: Pick<TXpertTeamDraft, 'nodes' | 'connections' | 'team'> | null): TXpertMarketplaceTechnicalProfile;
export declare function buildXpertMarketplaceProfileSnapshot(input: TXpertPublishMarketplaceInput | TXpertMarketplaceProfile | undefined | null, draft?: Pick<TXpertTeamDraft, 'nodes' | 'connections' | 'team'> | null): TXpertMarketplaceProfile;
