import { z } from 'zod';
export declare const templateActivityReadSchema: z.ZodObject<{
    keys: z.ZodArray<z.ZodString, "many">;
}, "strict", z.ZodTypeAny, {
    keys?: string[];
}, {
    keys?: string[];
}>;
export type TemplateActivityRead = z.output<typeof templateActivityReadSchema>;
export interface TemplateActivity {
    assistantName: string;
    items: {
        id: string;
        key: string;
        routine: string;
        status: 'pending' | 'running' | 'awaiting_approval' | 'paused' | 'succeeded' | 'failed';
        scheduledAt: string;
        conversationId?: string;
        threadId?: string;
        unread: boolean;
        reason?: string;
    }[];
    unread: number;
}
