import type { AgentInvocationStatus } from './agent-runtime.model';
import type { ProjectTaskDecision, ProjectTaskReviewSubject, ProjectTaskExecutionPurpose, ProjectTaskSpecificationSnapshot } from './project-task-runtime.model';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IPagination } from '../core.model';
import { IIntegration } from '../integration.model';
import { IStorageFile, TFile } from '../storage-file.model';
import { TAvatar } from '../types';
import { IUser } from '../user.model';
import { ICopilotModel } from './copilot-model.model';
import { IKnowledgebase } from './knowledgebase.model';
import { IXpertToolset } from './xpert-toolset.model';
import { IXpertWorkspace } from './xpert-workspace.model';
import { IXpert, TXpertTeamDraft } from './xpert.model';
import type { XpertProjectClassification, XpertProjectTypeRef } from './xpert-project-type.model';
import type { ConversationResourceCard } from './resource-card';
export type TXpertProjectSettings = {
    /** @deprecated Project instructions are stored in /project/<projectId>/project.md. */
    instruction?: string;
    mode?: '' | 'plan';
    managementMode?: TXpertProjectManagementMode;
    /** Server-owned first-send provenance; the provisional name may be reconciled once by the business app. */
    conversationBootstrap?: {
        conversationId: string;
        initialName: string;
        nameResolved?: boolean;
        resourceCards?: ConversationResourceCard[];
        resourceCardMessageId?: string;
    };
    /** @deprecated Project Xperts are peers and no default Project Assistant is selected. */
    projectAssistantId?: string;
};
export type TXpertProjectManagementMode = 'simple' | 'advanced';
export type TXpertProjectMemberRole = 'manager' | 'editor' | 'member';
export type TXpertProjectAccessRole = 'owner' | TXpertProjectMemberRole;
export type TXpertProjectInvitationStatus = 'pending' | 'accepted' | 'declined' | 'revoked' | 'expired';
export type TXpertProjectAccessSummary = {
    role: TXpertProjectAccessRole;
    capabilities: {
        canRead: boolean;
        canEdit: boolean;
        canManage: boolean;
        canUse: boolean;
    };
};
export type TXpertProjectMemberSummary = {
    id: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    username?: string;
    imageUrl?: string;
    membershipId?: string;
    projectRole: TXpertProjectAccessRole;
    joinedAt?: Date;
};
export type TXpertProjectInstructions = {
    content: string;
};
export type TXpertProjectSkillSource = 'repository' | 'upload' | 'legacy';
export type TXpertProjectSkillSummary = {
    id: string;
    name: string;
    path: string;
    enabled: boolean;
    source: TXpertProjectSkillSource;
    skillIndexId?: string;
    description?: string;
    version?: string;
};
export type TXpertProjectSkills = {
    items: TXpertProjectSkillSummary[];
    total: number;
};
export type TXpertProjectSkillFile = {
    path: string;
    content: string;
};
export type TXpertProjectMemberInput = {
    userId: string;
    role?: TXpertProjectMemberRole;
};
export type TXpertProjectMemberRoleInput = {
    role: TXpertProjectMemberRole;
};
export type TXpertProjectInvitationInput = {
    email: string;
    role?: TXpertProjectMemberRole;
};
export type TXpertProjectInvitationTokenInput = {
    token: string;
};
export type TXpertProjectStatus = 'active' | 'deprecated' | 'archived';
export type TXpertProjectPlanStatus = 'draft' | 'active' | 'completed' | 'archived';
export type TXpertProjectMilestoneStatus = 'planned' | 'in_progress' | 'completed' | 'blocked';
export type TXpertProjectTaskStatus = 'todo' | 'in_progress' | 'review' | 'paused' | 'done' | 'blocked' | 'cancelled';
export type TXpertProjectTaskPriority = 'urgent' | 'high' | 'medium' | 'low';
export type TXpertProjectPlanView = 'board' | 'table' | 'gantt' | 'calendar' | 'list';
export type TXpertProjectSprintStatus = 'planned' | 'running' | 'review' | 'done';
export type TXpertProjectSprintStrategy = 'software_delivery' | 'data_analysis';
export type TXpertProjectSwimlaneKind = 'backlog' | 'execution';
export type TXpertProjectAgentRole = 'planner' | 'coder' | 'reviewer' | 'operator' | 'researcher' | 'analyst' | 'visualizer';
export type TXpertProjectExecutionEnvironment = 'browser' | 'container' | 'terminal';
export type TXpertProjectTaskConversationRelation = 'origin' | 'discussion' | 'execution' | 'review';
export type TXpertProjectTaskExecutionStatus = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export type TXpertProjectAssetKind = 'file' | 'folder';
export type TXpertProjectAssetSource = 'upload' | 'ai_output' | 'conversation' | 'import';
export type TXpertProjectAutomationTrigger = 'schedule' | 'task.status_changed' | 'asset.created' | 'conversation.completed';
export type TXpertProjectAutomationRunStatus = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export declare enum XpertProjectTaskStatusEnum {
    TODO = "todo",
    IN_PROGRESS = "in_progress",
    REVIEW = "review",
    PAUSED = "paused",
    DONE = "done",
    BLOCKED = "blocked",
    CANCELLED = "cancelled"
}
export declare enum XpertProjectTaskPriorityEnum {
    URGENT = "urgent",
    HIGH = "high",
    MEDIUM = "medium",
    LOW = "low"
}
export declare enum XpertProjectPlanViewEnum {
    BOARD = "board",
    TABLE = "table",
    GANTT = "gantt",
    CALENDAR = "calendar",
    LIST = "list"
}
export declare enum XpertProjectAssetSourceEnum {
    UPLOAD = "upload",
    AI_OUTPUT = "ai_output",
    CONVERSATION = "conversation",
    IMPORT = "import"
}
export declare enum XpertProjectAutomationTriggerEnum {
    SCHEDULE = "schedule",
    TASK_STATUS_CHANGED = "task.status_changed",
    ASSET_CREATED = "asset.created",
    CONVERSATION_COMPLETED = "conversation.completed"
}
export declare enum XpertProjectAutomationRunStatusEnum {
    QUEUED = "queued",
    RUNNING = "running",
    SUCCEEDED = "succeeded",
    FAILED = "failed",
    CANCELLED = "cancelled"
}
export type TXpertProject = XpertProjectClassification & {
    name: string;
    avatar?: TAvatar;
    description?: string;
    status: TXpertProjectStatus;
    settings?: TXpertProjectSettings;
    copilotModel?: ICopilotModel;
    copilotModelId?: string;
    vcsId?: string;
};
/**
 * Expert Project
 */
export interface IXpertProject extends TXpertProject, IBasePerTenantAndOrganizationEntityModel {
    /** @deprecated Projects are scoped by Organization and no longer bind runtime data to a Workspace. */
    workspaceId?: string;
    workspace?: IXpertWorkspace;
    ownerId: string;
    owner?: IUser;
    xperts?: IXpert[];
    toolsets?: IXpertToolset[];
    knowledges?: IKnowledgebase[];
    /** @deprecated Legacy relation. Use memberships and the Project membership API for access management. */
    members?: IUser[];
    memberships?: IXpertProjectMembership[];
    /**
     * @deprecated Use project file volume / FileAsset workspace projection instead.
     */
    files?: IXpertProjectFile[];
    /**
     * @deprecated Use project file volume / FileAsset workspace projection instead.
     */
    attachments?: IStorageFile[];
    vcs?: IXpertProjectVCS;
}
export interface IXpertProjectMembership extends IBasePerTenantAndOrganizationEntityModel {
    projectId: string;
    project?: IXpertProject;
    userId: string;
    user?: IUser;
    role: TXpertProjectMemberRole;
    invitedById?: string;
    invitedBy?: IUser;
    joinedAt: Date;
    removedAt?: Date;
}
export interface IXpertProjectInvitation extends IBasePerTenantAndOrganizationEntityModel {
    projectId: string;
    project?: IXpertProject;
    email: string;
    normalizedEmail: string;
    targetUserId?: string;
    targetUser?: IUser;
    role: TXpertProjectMemberRole;
    status: TXpertProjectInvitationStatus;
    expiresAt: Date;
    invitedById: string;
    invitedBy?: IUser;
    acceptedById?: string;
    acceptedBy?: IUser;
    acceptedAt?: Date;
    lastSentAt: Date;
}
export type IXpertProjectCreateInput = Partial<IXpertProject> & {
    projectType?: XpertProjectTypeRef;
    xpertIds?: string[];
    toolsetIds?: string[];
    knowledgebaseIds?: string[];
    memberIds?: string[];
};
export interface IBasePerXpertProjectEntityModel extends IBasePerTenantAndOrganizationEntityModel {
    projectId?: string;
    project?: IXpertProject;
}
export interface IXpertProjectTask extends IBasePerXpertProjectEntityModel {
    reviewSubject?: ProjectTaskReviewSubject | null;
    controlKind?: 'ordinary' | 'provider' | 'pipeline';
    pipelineInstanceId?: string | null;
    pipelineDisposition?: 'active' | 'removed' | 'excluded' | 'superseded' | null;
    decisions?: ProjectTaskDecision[];
    /** Measured completion percentage (0–100); null/omitted means unknown. */
    progress?: number | null;
    providerKey?: string | null;
    sourceKey?: string | null;
    sourceRevision?: string | null;
    revision?: number;
    kind?: 'task' | 'summary' | 'milestone';
    parentTaskId?: string | null;
    predecessorIds?: string[];
    plannedStartAt?: Date | null;
    plannedEndAt?: Date | null;
    estimatedDurationMs?: number | null;
    diagnostic?: string | null;
    threadId?: string;
    name: string;
    title?: string;
    description?: string;
    /** Explicit completion requirements, independent of reported step progress. */
    requirements?: string[];
    /** Business task type. Provider projections use their registered namespaced taskType key. */
    type?: string;
    status: TXpertProjectTaskStatus | 'pending' | 'completed' | 'failed';
    priority?: TXpertProjectTaskPriority;
    assigneeId?: string;
    assignee?: IUser;
    /** Project Xpert responsible for executing this task. */
    assigneeXpertId?: string;
    dueDate?: Date;
    planId?: string;
    milestoneId?: string;
    column?: string;
    order?: number;
    plan?: IXpertProjectPlan;
    milestone?: IXpertProjectMilestone;
    steps: IXpertProjectTaskStep[];
    conversations?: IXpertProjectTaskConversation[];
    executions?: IXpertProjectTaskExecution[];
}
export interface IXpertProjectTaskConversation extends IBasePerXpertProjectEntityModel {
    taskId: string;
    conversationId: string;
    relationType: TXpertProjectTaskConversationRelation;
    isPrimary?: boolean;
    sourceMessageId?: string;
    sourceExecutionId?: string;
}
export interface IXpertProjectTaskExecution extends IBasePerXpertProjectEntityModel {
    reviewReportAvailable?: boolean;
    /** Runtime-owned attempt. Distinct from a native Agent execution ID. */
    invocationId?: string | null;
    invocationStatus?: AgentInvocationStatus | null;
    dispatchRequestId?: string | null;
    dispatchState?: 'pending' | 'submitted' | null;
    specificationSnapshot?: ProjectTaskSpecificationSnapshot | null;
    purpose?: ProjectTaskExecutionPurpose | null;
    /** Observed runtime status, independent from the business task acceptance status. */
    runtimeStartedAt?: string | null;
    runtimeCompletedAt?: string | null;
    /** Authorized runtime presentation, not persisted task state. */
    runtimeProvider?: string;
    runtimeToolId?: string;
    /** Exact registered handler from a persisted Pipeline service operation. */
    runtimeServiceRef?: string;
    /** Classified from the exact persisted managed Pipeline operation, never from task attempt count. */
    pipelineAttemptKind?: 'initial' | 'technical_retry';
    runtimeStatus?: 'running' | 'success' | 'error' | 'pending' | 'timeout' | 'interrupted' | 'unknown' | 'queued' | 'succeeded' | 'failed' | 'cancelled';
    sourceKey?: string | null;
    taskId: string;
    conversationId?: string;
    threadId?: string;
    agentExecutionId?: string;
    xpertId?: string;
    agentKey?: string;
    attempt: number;
    status: TXpertProjectTaskExecutionStatus;
    inputSummary?: string;
    outputSummary?: string;
    error?: string;
    artifactIds?: string[];
    startedAt?: Date;
    completedAt?: Date;
}
export interface IXpertProjectTaskStep extends IBasePerXpertProjectEntityModel {
    taskId: string;
    stepIndex: number;
    description: string;
    notes: string;
    status: 'pending' | 'running' | 'done' | 'failed';
}
export interface IXpertProjectTaskLog extends IBasePerXpertProjectEntityModel {
    stepId: string;
    logType: 'input' | 'output' | 'error';
    content: string;
}
/**
 * @deprecated use CodeXpert instead
 */
export interface IXpertProjectVCS extends IBasePerXpertProjectEntityModel {
    integrationId?: string;
    integration?: IIntegration;
    auth?: {
        token_type?: string;
        access_token?: string;
        state?: string;
    };
    installationId?: number | string;
    repository?: string;
}
/**
 * @deprecated Use project file volume / FileAsset workspace projection instead.
 */
export interface IXpertProjectFile extends IBasePerXpertProjectEntityModel, Omit<TFile, 'createdAt' | 'updatedAt'> {
}
export type TXpertProjectDSL = IXpertProject & {
    xperts?: TXpertTeamDraft[];
    plans?: IXpertProjectPlan[];
    milestones?: IXpertProjectMilestone[];
    automations?: IXpertProjectAutomation[];
};
export interface IXpertProjectPlan extends IBasePerXpertProjectEntityModel {
    name: string;
    description?: string;
    status: TXpertProjectPlanStatus;
    view?: TXpertProjectPlanView;
    startDate?: Date;
    dueDate?: Date;
    order?: number;
    milestones?: IXpertProjectMilestone[];
    sprints?: IXpertProjectSprint[];
}
export interface IXpertProjectMilestone extends IBasePerXpertProjectEntityModel {
    planId: string;
    plan?: IXpertProjectPlan;
    name: string;
    description?: string;
    status: TXpertProjectMilestoneStatus;
    dueDate?: Date;
    order?: number;
}
export interface IXpertProjectSprint extends IBasePerXpertProjectEntityModel {
    planId?: string;
    plan?: IXpertProjectPlan;
    goal: string;
    status: TXpertProjectSprintStatus;
    strategyType: TXpertProjectSprintStrategy;
    startAt?: Date;
    endAt?: Date;
    retrospective?: string;
    swimlanes?: IXpertProjectSwimlane[];
}
export interface IXpertProjectSwimlane extends IBasePerXpertProjectEntityModel {
    sprintId: string;
    sprint?: IXpertProjectSprint;
    key: string;
    name: string;
    kind: TXpertProjectSwimlaneKind;
    priority: number;
    weight: number;
    concurrencyLimit: number;
    wipLimit: number;
    agentRole: TXpertProjectAgentRole;
    environmentType: TXpertProjectExecutionEnvironment;
    sortOrder: number;
    sourceStrategyType: TXpertProjectSprintStrategy;
}
export interface IXpertProjectActivity extends IBasePerXpertProjectEntityModel {
    type: string;
    entityType?: string;
    entityId?: string;
    summary: string;
    payload?: Record<string, unknown>;
    actor?: IUser;
}
export interface IXpertProjectAsset extends IBasePerXpertProjectEntityModel {
    parentId?: string;
    parent?: IXpertProjectAsset;
    name: string;
    path: string;
    kind: TXpertProjectAssetKind;
    mimeType?: string;
    size?: number;
    source: TXpertProjectAssetSource;
    taskId?: string;
    conversationId?: string;
    status?: 'available' | 'processing' | 'failed';
}
export interface IXpertProjectAutomation extends IBasePerXpertProjectEntityModel {
    name: string;
    enabled: boolean;
    trigger: {
        type: TXpertProjectAutomationTrigger;
        cron?: string;
        timezone?: string;
        eventType?: string;
    };
    actions: Array<Record<string, unknown>>;
    lastRunAt?: Date;
    nextRunAt?: Date;
    runs?: IXpertProjectAutomationRun[];
}
export interface IXpertProjectAutomationRun extends IBasePerXpertProjectEntityModel {
    automationId: string;
    automation?: IXpertProjectAutomation;
    status: TXpertProjectAutomationRunStatus;
    occurrenceKey: string;
    jobId?: string;
    startedAt?: Date;
    completedAt?: Date;
    error?: string;
    output?: Record<string, unknown>;
}
export type TXpertProjectPage<T> = IPagination<T>;
export type IXpertProjectPlanInput = Partial<Omit<IXpertProjectPlan, 'id' | 'projectId' | 'project' | 'milestones'>>;
export type IXpertProjectMilestoneInput = Partial<Omit<IXpertProjectMilestone, 'id' | 'projectId' | 'project' | 'plan'>>;
export type IXpertProjectActivityInput = Pick<IXpertProjectActivity, 'type' | 'summary'> & Partial<Pick<IXpertProjectActivity, 'entityType' | 'entityId' | 'payload'>>;
export type IXpertProjectAssetInput = Partial<Omit<IXpertProjectAsset, 'id' | 'projectId' | 'project' | 'parent'>>;
export type IXpertProjectAutomationInput = Partial<Omit<IXpertProjectAutomation, 'id' | 'projectId' | 'project' | 'runs'>>;
