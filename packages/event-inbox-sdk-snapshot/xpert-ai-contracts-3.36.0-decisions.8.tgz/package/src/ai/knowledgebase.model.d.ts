import type { KnowledgeAutomaticTaggingConfig } from './knowledge-tag.model';
import type { KnowledgeChunkLanguageHint } from './knowledge-chunking.model';
import type { KnowledgeQuestionGenerationConfig } from './knowledge-question.model';
import type { TKBRetrievalSettings } from './xpert.model';
import type { KnowledgeKeywordAnalyzer } from './knowledge-keyword-analyzer.model';
import { VectorTypeEnum } from './rag';
import { ICopilotModel } from './copilot-model.model';
import { I18nObject, TAvatar } from '../types';
import { IBasePerWorkspaceEntityModel } from './xpert-workspace.model';
import { IKnowledgeDocument, type DocumentSpreadsheetParserConfig } from './knowledge-doc.model';
import { IXpert } from './xpert.model';
import { IIntegration } from '../integration.model';
import { IDocChunkMetadata } from './knowledge-doc-chunk.model';
import type { GraphRagConfig, KnowledgeGraphStatus } from './knowledge-graph.model';
import type { KnowledgebaseWikiConfig, KnowledgeWikiStatus, KnowledgeWikiAvailability } from './knowledge-wiki.model';
/**
 * Non-internal types should remain the same as IntegrationEnum.
 */
export declare enum KnowledgeProviderEnum {
    Internal = "internal"
}
export declare enum KnowledgebaseTypeEnum {
    Standard = "standard",
    FAQ = "faq",
    External = "external"
}
/**
 * Knowledge bases created before the type discriminator was introduced are document knowledge bases.
 */
export declare function isDocumentKnowledgebaseType(type: KnowledgebaseTypeEnum | null | undefined): boolean;
export type KnowledgebaseFAQIndexMode = 'question_only' | 'question_answer';
export type KnowledgebaseFAQQuestionIndexMode = 'combined' | 'separate';
export type KnowledgebaseFAQNegativeMatchMode = 'exact' | 'semantic';
export type KnowledgebaseFAQConfig = {
    indexMode: KnowledgebaseFAQIndexMode;
    questionIndexMode: KnowledgebaseFAQQuestionIndexMode;
    /** Optional for knowledge bases created before negative matching was configurable. */
    negativeMatchMode?: KnowledgebaseFAQNegativeMatchMode;
    /** Required for semantic mode; cosine similarity in [0, 1]. Immutable after creation. */
    semanticThreshold?: number;
    /** Required for semantic mode; negative minus positive similarity in (0, 2]. */
    semanticMargin?: number;
};
export declare const DEFAULT_KNOWLEDGEBASE_FAQ_CONFIG: {
    readonly indexMode: "question_only";
    readonly questionIndexMode: "separate";
    readonly negativeMatchMode: "exact";
};
export type KnowledgeRetrievalMode = 'vector' | 'keyword' | 'graph' | 'hybrid';
/** Request-local content selection, independent of algorithms and persisted recall settings. */
export type KnowledgeRetrievalContentScope = 'all' | 'original' | 'wiki';
export declare enum KnowledgebaseStatusEnum {
    READY = "ready",
    REBUILD_REQUIRED = "rebuild_required",
    REBUILDING = "rebuilding",
    REBUILD_FAILED = "rebuild_failed"
}
export type KnowledgebaseEmbeddingRebuildInput = {
    embeddingBatchSize?: number;
};
export declare enum KnowledgeStructureEnum {
    General = "general",
    ParentChild = "parent-child",
    QA = "qa"
}
export type KnowledgeParserSelection = {
    transformerType: string;
    transformerIntegration?: string;
    transformer?: {
        [key: string]: unknown;
    };
};
export type KnowledgebaseParserConfig = {
    /** Canonical extension -> parser. Null explicitly restores system defaults, including legacy PDF settings. */
    parsers?: {
        [format: string]: KnowledgeParserSelection | null;
    };
    spreadsheet?: Pick<DocumentSpreadsheetParserConfig, 'firstRowAsHeader'>;
    tableMetadataRequirements?: string;
    /** Additional cl100k_base token cap for text retrieval chunks; 0 disables it. Context parents are retained. */
    maxChunkTokens?: number;
    /** Public natural-language boundary hint; absence means auto. */
    chunkLanguageHint?: KnowledgeChunkLanguageHint;
    questionGeneration?: KnowledgeQuestionGenerationConfig;
    pages?: number[][];
    embeddingBatchSize?: number;
    chunkSize: number | null;
    chunkOverlap: number | null;
    delimiter: string | null;
    /** Legacy PDF selection; parsers.pdf takes precedence when present. */
    pdfParser?: KnowledgeParserSelection;
    textSplitterType?: string;
    textSplitter?: {
        [key: string]: unknown;
    };
    separators?: string[];
    imageUnderstandingEnabled?: boolean;
    imageUnderstandingType?: string;
    imageUnderstanding?: {
        [key: string]: unknown;
    };
};
/**
 * Type of rag knowledgebase
 */
export interface KnowledgeVectorStoreOptions {
    default: VectorTypeEnum;
    stores: {
        type: VectorTypeEnum;
    }[];
}
export type TKnowledgebase = {
    /** Null on legacy knowledgebases: use the deployment default. */
    vectorStore?: VectorTypeEnum | null;
    /**
     * KB name
     */
    name: string;
    /**
     * Type of KB
     */
    type: KnowledgebaseTypeEnum;
    /**
     * Creation-time indexing behavior for FAQ knowledge bases.
     */
    faqConfig?: KnowledgebaseFAQConfig | null;
    /** Optional generated Wiki capability for Standard knowledgebases. */
    wikiConfig?: KnowledgebaseWikiConfig | null;
    wikiStatus?: KnowledgeWikiStatus | null;
    wikiAvailability?: KnowledgeWikiAvailability | null;
    wikiRevision?: number | null;
    wikiActiveRevision?: number | null;
    wikiStagedRevision?: number | null;
    wikiBuildError?: string | null;
    wikiRebuildRequiredReason?: 'generator_upgrade' | null;
    wikiGeneratorVersion?: string | null;
    wikiConfigFingerprint?: string | null;
    canManageWiki?: boolean;
    canManageDocumentDeletions?: boolean;
    /**
     * English | Chinese
     */
    language?: 'Chinese' | 'English' | null;
    /**
     * Avatar object
     */
    avatar?: TAvatar;
    /**
     * KB description
     */
    description?: string;
    /**
     * Stable application-owned classification labels used for exact discovery.
     * These are machine-readable identifiers, not user-facing search tags.
     */
    applicationTags?: string[];
    automaticTagging?: KnowledgeAutomaticTaggingConfig | null;
    /**
     * Public in tenant or in organization or private
     * @default private
     */
    permission?: KnowledgebasePermission;
    /**
     * Copilot model for knowledgebase
     */
    copilotModel?: ICopilotModel;
    copilotModelId?: string;
    /**
     * Chat model for knowledgebase LLM tasks.
     */
    chatModel?: ICopilotModel | null;
    chatModelId?: string | null;
    /** Optional dedicated LLM for Wiki generation. Falls back to chatModel when unset. */
    wikiModel?: ICopilotModel | null;
    wikiModelId?: string | null;
    embeddingCollectionName?: string | null;
    embeddingModelFingerprint?: string | null;
    embeddingDimensions?: number | null;
    embeddingRevision?: number | null;
    pendingCopilotModel?: ICopilotModel | null;
    pendingCopilotModelId?: string | null;
    pendingEmbeddingCollectionName?: string | null;
    pendingEmbeddingModelFingerprint?: string | null;
    pendingEmbeddingDimensions?: number | null;
    pendingEmbeddingRevision?: number | null;
    rebuildTaskId?: string | null;
    embeddingRebuildError?: string | null;
    graphRag?: GraphRagConfig | null;
    graphStatus?: KnowledgeGraphStatus | null;
    graphRevision?: number | null;
    graphIndexError?: string | null;
    rerankModel?: ICopilotModel;
    rerankModelId?: string;
    visionModel?: ICopilotModel;
    visionModelId?: string;
    documentNum?: number | null;
    tokenNum?: number | null;
    chunkNum?: number | null;
    /**
     *@deprecated use `recall`
     */
    similarityThreshold?: number;
    vectorSimilarityWeight?: number;
    /**
     * @deprecated
     * default parser ID
     */
    parserId?: string;
    parserConfig?: KnowledgebaseParserConfig;
    /** Null retains the legacy PostgreSQL simple/trigram retrieval path. */
    keywordAnalyzer?: KnowledgeKeywordAnalyzer | null;
    /** Set by the server when the first document is inserted. */
    keywordAnalyzerLocked?: boolean;
    /**
     * Index structure determines how the knowledge base organizes and indexes your document content.
     * @deprecated
     */
    structure?: KnowledgeStructureEnum;
    /**
     * Recall params for kb chunks
     */
    recall?: TKBRecallParams;
    status?: KnowledgebaseStatusEnum;
    /**
     * Metadata custom field definition array
     */
    metadataSchema?: KBMetadataFieldDef[];
    /**
     * API service enabled
     */
    apiEnabled?: boolean;
    /**
     * Enable source matching for newly ingested documents.
     */
    incrementalSyncEnabled?: boolean;
    documents?: IKnowledgeDocument[];
    integrationId?: string;
    extKnowledgebaseId?: string;
    pipelineId?: string;
};
/**
 * Knowledgebase Entity
 */
export interface IKnowledgebase extends TKnowledgebase, IBasePerWorkspaceEntityModel {
    xperts?: IXpert[];
    integration?: IIntegration;
    pipeline?: IXpert;
}
/**
 * Knowledgebase permission levels
 */
export declare enum KnowledgebasePermission {
    /**
     * Only visible to you
     * @default
     */
    Private = "private",
    /**
     * Visible to all members in the organization
     */
    Organization = "organization",
    /**
     * Visible to all members in the tenant
     */
    Public = "public"
}
/**
 * Recall parameters
 */
export type TKBRecallParams = {
    /** Default content selection, used only when Wiki is enabled. */
    contentScope?: KnowledgeRetrievalContentScope;
    /**
     * Default retrieval mode for this knowledgebase.
     */
    mode?: KnowledgeRetrievalMode;
    /**
     * Top K of result chunks
     */
    topK?: number;
    /**
     * Minimum vector similarity. Null disables the threshold.
     */
    score?: number | null;
    /**
     * Minimum relevance score returned by the rerank model. Null disables the threshold.
     */
    rerankThreshold?: number | null;
    /**
     * Weight in EnsembleRetriever
     */
    weight?: number;
    /**
     * Candidate fusion strategy. Missing configuration keeps the legacy behavior.
     */
    fusion?: TKBFusionConfig;
};
export type KnowledgeFusionMode = 'legacy' | 'weighted_rrf';
export declare const DEFAULT_KNOWLEDGE_RRF_RANK_CONSTANT = 60;
export declare const DEFAULT_KNOWLEDGE_RRF_WEIGHTS: {
    readonly vector: 0.65;
    readonly graph: 0.35;
    readonly keyword: 0.3;
};
export type TKBFusionConfig = {
    mode?: KnowledgeFusionMode;
    rankConstant?: number;
    weights?: {
        vector?: number;
        graph?: number;
        keyword?: number;
    };
};
export declare const DEFAULT_KNOWLEDGEBASE_FAQ_RECALL: {
    readonly mode: "hybrid";
    readonly fusion: {
        readonly mode: "weighted_rrf";
        readonly rankConstant: 60;
        readonly weights: {
            readonly vector: 0.7;
            readonly keyword: 0.3;
            readonly graph: 0;
        };
    };
};
export declare const KNOWLEDGEBASE_FAQ_RETRIEVAL_MODES: readonly ["vector", "keyword", "hybrid"];
/**
 * FAQ retrieval only uses question vectors and keyword indexes. Graph retrieval is not supported.
 */
export declare function normalizeKnowledgebaseFAQRecall(recall?: TKBRecallParams | null): TKBRecallParams;
export type DocumentMetadata = IDocChunkMetadata & {
    score?: number;
    relevanceScore?: number;
} & Record<string, any>;
export type MetadataFieldType = 'string' | 'number' | 'boolean' | 'enum' | 'datetime' | 'string[]' | 'number[]' | 'object';
export type KBMetadataFieldDef = {
    key: string;
    label?: I18nObject;
    type: MetadataFieldType;
    /**
     * Storage scope of the metadata value. Existing definitions are migrated to `document`.
     */
    scope?: 'document' | 'chunk';
    enumValues?: string[];
    description?: string;
};
/**
 * Channel name for knowledgebase pipeline
 */
export declare const KnowledgebaseChannel: string;
/**
 * Task ID of a knowledgebase run
 */
export declare const KnowledgeTask = "task_id";
/**
 * Specify the data source to run
 */
export declare const KNOWLEDGE_SOURCES_NAME = "sources";
/** Workflow-state key carrying the requested document processing resume point. */
export declare const KNOWLEDGE_PROCESSING_MODE_NAME = "processing_mode";
export declare const KNOWLEDGE_DOCUMENTS_NAME = "documents";
export declare const KNOWLEDGE_FOLDER_ID_NAME = "folder_id";
export declare const KNOWLEDGE_STAGE_NAME = "stage";
/** Check the sources that can execute within the selected content scope. */
export declare function hasEnabledKnowledgeRetrievalSource(retrieval: Partial<IKnowledgebase & TKBRetrievalSettings> | null | undefined, allowGraphRetrieval?: boolean, contentScope?: KnowledgeRetrievalContentScope): boolean;
