import { type IKnowledgeDocument } from './knowledge-doc.model';
import type { IDocChunkMetadata, IKnowledgeDocumentChunk } from './knowledge-doc-chunk.model';
/** Parser-owned identities and coordinates; generated descriptions never redefine these fields. */
export interface KnowledgeTableColumn {
    columnId: string;
    key: string;
    label: string;
    column: number;
    /** Certified from all nonempty source cells by the parser, never inferred by the model. */
    valueType?: 'boolean';
}
export interface KnowledgeTableDefinition {
    tableId: string;
    sheetName: string;
    range: string;
    headerRow?: number;
    rowCount: number;
    columns: KnowledgeTableColumn[];
}
export interface KnowledgeTableSource extends KnowledgeTableDefinition {
    /** Bounded parser samples. Keys are columnId values, not generated labels. */
    samples: Array<{
        rowNumber: number;
        values: {
            [columnId: string]: string | number | boolean | null;
        };
    }>;
}
export interface KnowledgeTableColumnDescription extends KnowledgeTableColumn {
    description: string;
    unit?: string;
    valueMeanings?: string;
}
export interface KnowledgeTableResult extends Omit<KnowledgeTableDefinition, 'columns'> {
    summary: string;
    columns: KnowledgeTableColumnDescription[];
}
export interface KnowledgeTableMetadata {
    schemaVersion: 1;
    status: 'generating' | 'generated' | 'ready' | 'failed' | 'skipped';
    reason?: 'missing_model' | 'no_data' | 'unsupported';
    inputHash: string;
    /** Full parsed source fingerprint, independent of the bounded model samples. */
    sourceFingerprint?: string;
    /** Successful column batches can be resumed independently of the displayed structure. */
    completedColumns?: {
        [tableId: string]: string[];
    };
    /** Model-selected ISO 639 language, reused across batches and retries. */
    language?: string;
    generationId: string;
    resultHash?: string;
    appliedResultHash?: string;
    updatedAt: string;
    error?: string;
    tables: KnowledgeTableResult[];
}
/** Compact retrieval-only view of the published generation. Source row content stays unchanged. */
export interface KnowledgeTableContext {
    tableId: string;
    resultHash: string;
    sheetName: string;
    summary: string;
    columns: Array<Pick<KnowledgeTableColumnDescription, 'columnId' | 'key' | 'description' | 'unit' | 'valueMeanings'>>;
}
export interface KnowledgeTablePreview {
    tables: KnowledgeTableDefinition[];
    chunks: IKnowledgeDocumentChunk<IDocChunkMetadata>[];
}
export declare function isNativeKnowledgeTableDocument(document: Pick<Partial<IKnowledgeDocument>, 'category' | 'type' | 'parserConfig' | 'sourceConfig'>): boolean;
/** Parse persisted JSON at the read boundary before using the shared result contract. */
export declare function isKnowledgeTableMetadata(value: unknown): value is KnowledgeTableMetadata;
