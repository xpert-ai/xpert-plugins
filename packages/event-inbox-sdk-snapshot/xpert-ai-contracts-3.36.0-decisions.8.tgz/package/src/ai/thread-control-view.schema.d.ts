import { z } from 'zod/v3';
/** Public presentation only. Every command revalidates permission and execution admission. */
export declare const threadControlActionsSchema: z.ZodObject<{
    canPause: z.ZodBoolean;
    canResume: z.ZodBoolean;
    canTerminate: z.ZodBoolean;
    canSend: z.ZodBoolean;
    canQueue: z.ZodBoolean;
    canRetry: z.ZodBoolean;
    canRespond: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    canPause?: boolean;
    canResume?: boolean;
    canTerminate?: boolean;
    canSend?: boolean;
    canQueue?: boolean;
    canRetry?: boolean;
    canRespond?: boolean;
}, {
    canPause?: boolean;
    canResume?: boolean;
    canTerminate?: boolean;
    canSend?: boolean;
    canQueue?: boolean;
    canRetry?: boolean;
    canRespond?: boolean;
}>;
export declare const threadControlViewSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    threadId: z.ZodString;
    runId: z.ZodNullable<z.ZodString>;
    revision: z.ZodString;
    state: z.ZodEnum<["idle", "running", "pausing", "paused", "stopping", "settling", "input_required", "confirming", "completed", "stopped", "failed"]>;
    actions: z.ZodObject<{
        canPause: z.ZodBoolean;
        canResume: z.ZodBoolean;
        canTerminate: z.ZodBoolean;
        canSend: z.ZodBoolean;
        canQueue: z.ZodBoolean;
        canRetry: z.ZodBoolean;
        canRespond: z.ZodBoolean;
    }, "strict", z.ZodTypeAny, {
        canPause?: boolean;
        canResume?: boolean;
        canTerminate?: boolean;
        canSend?: boolean;
        canQueue?: boolean;
        canRetry?: boolean;
        canRespond?: boolean;
    }, {
        canPause?: boolean;
        canResume?: boolean;
        canTerminate?: boolean;
        canSend?: boolean;
        canQueue?: boolean;
        canRetry?: boolean;
        canRespond?: boolean;
    }>;
    pauseId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    revision?: string;
    threadId?: string;
    runId?: string;
    state?: "idle" | "completed" | "failed" | "pausing" | "paused" | "running" | "stopping" | "input_required" | "settling" | "confirming" | "stopped";
    actions?: {
        canPause?: boolean;
        canResume?: boolean;
        canTerminate?: boolean;
        canSend?: boolean;
        canQueue?: boolean;
        canRetry?: boolean;
        canRespond?: boolean;
    };
    pauseId?: string;
}, {
    version?: 1;
    revision?: string;
    threadId?: string;
    runId?: string;
    state?: "idle" | "completed" | "failed" | "pausing" | "paused" | "running" | "stopping" | "input_required" | "settling" | "confirming" | "stopped";
    actions?: {
        canPause?: boolean;
        canResume?: boolean;
        canTerminate?: boolean;
        canSend?: boolean;
        canQueue?: boolean;
        canRetry?: boolean;
        canRespond?: boolean;
    };
    pauseId?: string;
}>;
export type ThreadControlView = Omit<Required<z.output<typeof threadControlViewSchema>>, 'actions' | 'pauseId'> & {
    actions: ThreadControlActions;
    pauseId?: string;
};
export type ThreadControlActions = Required<z.output<typeof threadControlActionsSchema>>;
