import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IKnowledgebase } from './knowledgebase.model';
import { KnowledgeFilterDiagnostics, KnowledgeFilterNode, KnowledgeFilterStatus } from './knowledge-filter.model';
export interface IKnowledgeRetrievalLog extends IBasePerTenantAndOrganizationEntityModel {
    query: string;
    source: string;
    hitCount: number;
    requestId: string;
    filterVersion?: number;
    fixedFilter?: KnowledgeFilterNode;
    dynamicFilter?: KnowledgeFilterNode;
    requestFilter?: KnowledgeFilterNode;
    effectiveFilter?: KnowledgeFilterNode;
    filterHash?: string;
    filterStatus?: KnowledgeFilterStatus;
    fallbackReason?: string;
    errorCode?: string;
    candidateDocumentCount?: number;
    candidateChunkCount?: number;
    vectorBackend?: string;
    filterLatency?: number;
    vectorLatency?: number;
    diagnostics?: KnowledgeFilterDiagnostics;
    knowledgebaseId?: string;
    knowledgebase?: IKnowledgebase;
}
