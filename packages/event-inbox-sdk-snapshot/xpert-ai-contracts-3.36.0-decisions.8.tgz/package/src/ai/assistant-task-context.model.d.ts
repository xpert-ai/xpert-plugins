import { z } from 'zod/v3';
/** Host-owned routing context for a native Assistant invocation, not a separate runtime provider. */
export declare const assistantTaskGroupContextSchema: z.ZodObject<{
    type: z.ZodLiteral<"group_member">;
    groupId: z.ZodString;
    participantId: z.ZodString;
    sourceParticipantId: z.ZodString;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "group_member";
    projectId?: string;
    participantId?: string;
    groupId?: string;
    sourceParticipantId?: string;
}, {
    type?: "group_member";
    projectId?: string;
    participantId?: string;
    groupId?: string;
    sourceParticipantId?: string;
}>;
export type AssistantTaskGroupContext = z.output<typeof assistantTaskGroupContextSchema>;
export declare function assistantTaskGroupContext(target: {
    provider: string;
    configuration: unknown;
}): AssistantTaskGroupContext | null;
