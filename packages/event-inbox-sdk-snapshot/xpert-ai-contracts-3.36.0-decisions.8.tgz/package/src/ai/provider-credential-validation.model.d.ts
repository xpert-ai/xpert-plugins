import { z } from 'zod';
import { AiModelTypeEnum } from '../agent/ai-model';
import type { DiscoveredModel } from './model-discovery.model';
export declare const providerCredentialValidationTargetSchema: z.ZodObject<{
    modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
    model: z.ZodString;
}, "strict", z.ZodTypeAny, {
    modelType?: AiModelTypeEnum;
    model?: string;
}, {
    modelType?: AiModelTypeEnum;
    model?: string;
}>;
export type ProviderCredentialValidationTarget = z.infer<typeof providerCredentialValidationTargetSchema>;
export declare const providerCredentialCheckSchema: z.ZodObject<{
    credentials: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    validationTarget: z.ZodOptional<z.ZodObject<{
        modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
        model: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        modelType?: AiModelTypeEnum;
        model?: string;
    }, {
        modelType?: AiModelTypeEnum;
        model?: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    credentials?: Record<string, unknown>;
    validationTarget?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    };
}, {
    credentials?: Record<string, unknown>;
    validationTarget?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    };
}>;
export type ProviderCredentialCheckInput = z.infer<typeof providerCredentialCheckSchema>;
/** Providers opt in when credential checks require a user-selected inference target. */
export interface ProviderCredentialValidationPolicy {
    mode: 'model';
    modelTypes: AiModelTypeEnum[];
}
export type ProviderCredentialValidationCapabilities = {
    method: 'discovery';
} | {
    method: 'model';
    modelTypes: AiModelTypeEnum[];
    models: ProviderCredentialValidationTarget[];
} | {
    method: 'provider';
};
export type ProviderCredentialValidationResult = {
    method: 'discovery';
    models: DiscoveredModel[];
} | {
    method: 'model';
    target: ProviderCredentialValidationTarget;
} | {
    method: 'provider';
};
