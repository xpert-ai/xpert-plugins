import { z } from 'zod/v3';
export declare const executionObservationStatusSchema: z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>;
export declare const executionObservationFilterSchema: z.ZodObject<{
    from: z.ZodString;
    to: z.ZodString;
    timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
    countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
    assistantId: z.ZodOptional<z.ZodString>;
    conversationId: z.ZodOptional<z.ZodString>;
    threadId: z.ZodOptional<z.ZodString>;
    unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
    workspaceId: z.ZodOptional<z.ZodString>;
    recordedById: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
    statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
    search: z.ZodOptional<z.ZodString>;
    asOf: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
}, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
}>;
export declare const executionObservationQuerySchema: z.ZodEffects<z.ZodObject<{
    from: z.ZodString;
    to: z.ZodString;
    timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
    countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
    assistantId: z.ZodOptional<z.ZodString>;
    conversationId: z.ZodOptional<z.ZodString>;
    threadId: z.ZodOptional<z.ZodString>;
    unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
    workspaceId: z.ZodOptional<z.ZodString>;
    recordedById: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
    statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
    search: z.ZodOptional<z.ZodString>;
    asOf: z.ZodOptional<z.ZodString>;
} & {
    page: z.ZodDefault<z.ZodNumber>;
    pageSize: z.ZodDefault<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    page?: number;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
    pageSize?: number;
}, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    page?: number;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
    pageSize?: number;
}>, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    page?: number;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
    pageSize?: number;
}, {
    timeZone?: string;
    workspaceId?: string;
    search?: string;
    source?: string;
    page?: number;
    conversationId?: string;
    from?: string;
    to?: string;
    threadId?: string;
    assistantId?: string;
    countingUnit?: "root_execution" | "assistant_invocation";
    unknownAssistantOnly?: boolean;
    recordedById?: string;
    statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
    asOf?: string;
    pageSize?: number;
}>;
export type ExecutionObservationQuery = z.output<typeof executionObservationQuerySchema>;
export type ExecutionObservationQueryInput = z.input<typeof executionObservationQuerySchema>;
export declare const executionObservationRecordSchema: z.ZodObject<{
    id: z.ZodString;
    assistantId: z.ZodNullable<z.ZodString>;
    assistantName: z.ZodNullable<z.ZodString>;
    workspaceId: z.ZodNullable<z.ZodString>;
    workspaceName: z.ZodNullable<z.ZodString>;
    conversationId: z.ZodNullable<z.ZodString>;
    threadId: z.ZodNullable<z.ZodString>;
    parentId: z.ZodNullable<z.ZodString>;
    parentThreadId: z.ZodNullable<z.ZodString>;
    forkedFromMessageId: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.ZodString>;
    source: z.ZodNullable<z.ZodString>;
    recordedById: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>;
    createdAt: z.ZodString;
    completedAt: z.ZodNullable<z.ZodString>;
    elapsedTimeMs: z.ZodNullable<z.ZodNumber>;
    invocationKind: z.ZodNullable<z.ZodEnum<["external_assistant", "sub_agent"]>>;
    endKnown: z.ZodBoolean;
    hasError: z.ZodBoolean;
    timingBasis: z.ZodLiteral<"record_lifecycle">;
    phasesAvailable: z.ZodLiteral<false>;
}, "strip", z.ZodTypeAny, {
    status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
    parentId?: string;
    workspaceId?: string;
    id?: string;
    createdAt?: string;
    source?: string;
    completedAt?: string;
    title?: string;
    conversationId?: string;
    threadId?: string;
    invocationKind?: "external_assistant" | "sub_agent";
    assistantName?: string;
    assistantId?: string;
    recordedById?: string;
    workspaceName?: string;
    parentThreadId?: string;
    forkedFromMessageId?: string;
    elapsedTimeMs?: number;
    endKnown?: boolean;
    hasError?: boolean;
    timingBasis?: "record_lifecycle";
    phasesAvailable?: false;
}, {
    status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
    parentId?: string;
    workspaceId?: string;
    id?: string;
    createdAt?: string;
    source?: string;
    completedAt?: string;
    title?: string;
    conversationId?: string;
    threadId?: string;
    invocationKind?: "external_assistant" | "sub_agent";
    assistantName?: string;
    assistantId?: string;
    recordedById?: string;
    workspaceName?: string;
    parentThreadId?: string;
    forkedFromMessageId?: string;
    elapsedTimeMs?: number;
    endKnown?: boolean;
    hasError?: boolean;
    timingBasis?: "record_lifecycle";
    phasesAvailable?: false;
}>;
export type ExecutionObservationRecord = z.infer<typeof executionObservationRecordSchema>;
export declare const executionObservationSegmentSchema: z.ZodObject<{
    start: z.ZodString;
    end: z.ZodString;
    count: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    end?: string;
    start?: string;
    count?: number;
}, {
    end?: string;
    start?: string;
    count?: number;
}>;
export type ExecutionObservationSegment = z.infer<typeof executionObservationSegmentSchema>;
export declare const executionObservationSummarySchema: z.ZodObject<{
    total: z.ZodNumber;
    assistants: z.ZodNumber;
    conversations: z.ZodNumber;
    statuses: z.ZodObject<{
        running: z.ZodNumber;
        success: z.ZodNumber;
        error: z.ZodNumber;
        pending: z.ZodNumber;
        timeout: z.ZodNumber;
        interrupted: z.ZodNumber;
        unknown: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        error?: number;
        success?: number;
        interrupted?: number;
        unknown?: number;
        running?: number;
        pending?: number;
        timeout?: number;
    }, {
        error?: number;
        success?: number;
        interrupted?: number;
        unknown?: number;
        running?: number;
        pending?: number;
        timeout?: number;
    }>;
    successRate: z.ZodNullable<z.ZodNumber>;
    p50ElapsedMs: z.ZodNullable<z.ZodNumber>;
    p95ElapsedMs: z.ZodNullable<z.ZodNumber>;
    durationSamples: z.ZodNumber;
    peakOverlap: z.ZodNumber;
    overlap: z.ZodArray<z.ZodObject<{
        start: z.ZodString;
        end: z.ZodString;
        count: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        end?: string;
        start?: string;
        count?: number;
    }, {
        end?: string;
        start?: string;
        count?: number;
    }>, "many">;
    knownIntervals: z.ZodNumber;
    unknownEnds: z.ZodNumber;
    timingBasis: z.ZodLiteral<"record_lifecycle">;
    phaseCoverage: z.ZodLiteral<"unavailable">;
    observedAt: z.ZodString;
    asOf: z.ZodString;
    usage: z.ZodObject<{
        records: z.ZodNumber;
        totalTokens: z.ZodNullable<z.ZodNumber>;
        unpricedRecords: z.ZodNumber;
        currencies: z.ZodArray<z.ZodObject<{
            currency: z.ZodString;
            amount: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            currency?: string;
            amount?: number;
        }, {
            currency?: string;
            amount?: number;
        }>, "many">;
        basis: z.ZodLiteral<"direct_execution_ledger">;
        coveredExecutions: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    }, {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    }>;
}, "strip", z.ZodTypeAny, {
    usage?: {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    };
    total?: number;
    observedAt?: string;
    conversations?: number;
    assistants?: number;
    successRate?: number;
    statuses?: {
        error?: number;
        success?: number;
        interrupted?: number;
        unknown?: number;
        running?: number;
        pending?: number;
        timeout?: number;
    };
    asOf?: string;
    timingBasis?: "record_lifecycle";
    p50ElapsedMs?: number;
    p95ElapsedMs?: number;
    durationSamples?: number;
    peakOverlap?: number;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    knownIntervals?: number;
    unknownEnds?: number;
    phaseCoverage?: "unavailable";
}, {
    usage?: {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    };
    total?: number;
    observedAt?: string;
    conversations?: number;
    assistants?: number;
    successRate?: number;
    statuses?: {
        error?: number;
        success?: number;
        interrupted?: number;
        unknown?: number;
        running?: number;
        pending?: number;
        timeout?: number;
    };
    asOf?: string;
    timingBasis?: "record_lifecycle";
    p50ElapsedMs?: number;
    p95ElapsedMs?: number;
    durationSamples?: number;
    peakOverlap?: number;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    knownIntervals?: number;
    unknownEnds?: number;
    phaseCoverage?: "unavailable";
}>;
export type ExecutionObservationSummary = z.infer<typeof executionObservationSummarySchema>;
/** Static avatar projection; animated appearance assets are unnecessary in dense rows. */
export declare const executionObservationAvatarSchema: z.ZodObject<{
    url: z.ZodOptional<z.ZodString>;
    background: z.ZodOptional<z.ZodString>;
    emoji: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        unified: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        id?: string;
        unified?: string;
    }, {
        id?: string;
        unified?: string;
    }>>;
}, "strip", z.ZodTypeAny, {
    emoji?: {
        id?: string;
        unified?: string;
    };
    background?: string;
    url?: string;
}, {
    emoji?: {
        id?: string;
        unified?: string;
    };
    background?: string;
    url?: string;
}>;
export declare const executionObservationAssistantSchema: z.ZodObject<{
    id: z.ZodNullable<z.ZodString>;
    name: z.ZodNullable<z.ZodString>;
    workspaceId: z.ZodNullable<z.ZodString>;
    workspaceName: z.ZodNullable<z.ZodString>;
    avatar: z.ZodNullable<z.ZodObject<{
        url: z.ZodOptional<z.ZodString>;
        background: z.ZodOptional<z.ZodString>;
        emoji: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            unified: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            id?: string;
            unified?: string;
        }, {
            id?: string;
            unified?: string;
        }>>;
    }, "strip", z.ZodTypeAny, {
        emoji?: {
            id?: string;
            unified?: string;
        };
        background?: string;
        url?: string;
    }, {
        emoji?: {
            id?: string;
            unified?: string;
        };
        background?: string;
        url?: string;
    }>>;
    total: z.ZodNumber;
    running: z.ZodNumber;
    pending: z.ZodNumber;
    interrupted: z.ZodNumber;
    failed: z.ZodNumber;
    failures: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        completedAt: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id?: string;
        completedAt?: string;
    }, {
        id?: string;
        completedAt?: string;
    }>, "many">;
    failureMarkersTruncated: z.ZodBoolean;
    overlap: z.ZodArray<z.ZodObject<{
        start: z.ZodString;
        end: z.ZodString;
        count: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        end?: string;
        start?: string;
        count?: number;
    }, {
        end?: string;
        start?: string;
        count?: number;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    failed?: number;
    name?: string;
    workspaceId?: string;
    interrupted?: number;
    id?: string;
    running?: number;
    pending?: number;
    total?: number;
    avatar?: {
        emoji?: {
            id?: string;
            unified?: string;
        };
        background?: string;
        url?: string;
    };
    workspaceName?: string;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    failures?: {
        id?: string;
        completedAt?: string;
    }[];
    failureMarkersTruncated?: boolean;
}, {
    failed?: number;
    name?: string;
    workspaceId?: string;
    interrupted?: number;
    id?: string;
    running?: number;
    pending?: number;
    total?: number;
    avatar?: {
        emoji?: {
            id?: string;
            unified?: string;
        };
        background?: string;
        url?: string;
    };
    workspaceName?: string;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    failures?: {
        id?: string;
        completedAt?: string;
    }[];
    failureMarkersTruncated?: boolean;
}>;
export declare const executionObservationOverviewSchema: z.ZodObject<{
    query: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
        timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
        countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
        assistantId: z.ZodOptional<z.ZodString>;
        conversationId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
        workspaceId: z.ZodOptional<z.ZodString>;
        recordedById: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodString>;
        statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
        search: z.ZodOptional<z.ZodString>;
        asOf: z.ZodOptional<z.ZodString>;
    } & {
        page: z.ZodDefault<z.ZodNumber>;
        pageSize: z.ZodDefault<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>;
    summary: z.ZodObject<Omit<{
        total: z.ZodNumber;
        assistants: z.ZodNumber;
        conversations: z.ZodNumber;
        statuses: z.ZodObject<{
            running: z.ZodNumber;
            success: z.ZodNumber;
            error: z.ZodNumber;
            pending: z.ZodNumber;
            timeout: z.ZodNumber;
            interrupted: z.ZodNumber;
            unknown: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        }, {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        }>;
        successRate: z.ZodNullable<z.ZodNumber>;
        p50ElapsedMs: z.ZodNullable<z.ZodNumber>;
        p95ElapsedMs: z.ZodNullable<z.ZodNumber>;
        durationSamples: z.ZodNumber;
        peakOverlap: z.ZodNumber;
        overlap: z.ZodArray<z.ZodObject<{
            start: z.ZodString;
            end: z.ZodString;
            count: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            end?: string;
            start?: string;
            count?: number;
        }, {
            end?: string;
            start?: string;
            count?: number;
        }>, "many">;
        knownIntervals: z.ZodNumber;
        unknownEnds: z.ZodNumber;
        timingBasis: z.ZodLiteral<"record_lifecycle">;
        phaseCoverage: z.ZodLiteral<"unavailable">;
        observedAt: z.ZodString;
        asOf: z.ZodString;
        usage: z.ZodObject<{
            records: z.ZodNumber;
            totalTokens: z.ZodNullable<z.ZodNumber>;
            unpricedRecords: z.ZodNumber;
            currencies: z.ZodArray<z.ZodObject<{
                currency: z.ZodString;
                amount: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                currency?: string;
                amount?: number;
            }, {
                currency?: string;
                amount?: number;
            }>, "many">;
            basis: z.ZodLiteral<"direct_execution_ledger">;
            coveredExecutions: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            totalTokens?: number;
            records?: number;
            unpricedRecords?: number;
            currencies?: {
                currency?: string;
                amount?: number;
            }[];
            basis?: "direct_execution_ledger";
            coveredExecutions?: number;
        }, {
            totalTokens?: number;
            records?: number;
            unpricedRecords?: number;
            currencies?: {
                currency?: string;
                amount?: number;
            }[];
            basis?: "direct_execution_ledger";
            coveredExecutions?: number;
        }>;
    }, "usage">, "strip", z.ZodTypeAny, {
        total?: number;
        observedAt?: string;
        conversations?: number;
        assistants?: number;
        successRate?: number;
        statuses?: {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        };
        asOf?: string;
        timingBasis?: "record_lifecycle";
        p50ElapsedMs?: number;
        p95ElapsedMs?: number;
        durationSamples?: number;
        peakOverlap?: number;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        knownIntervals?: number;
        unknownEnds?: number;
        phaseCoverage?: "unavailable";
    }, {
        total?: number;
        observedAt?: string;
        conversations?: number;
        assistants?: number;
        successRate?: number;
        statuses?: {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        };
        asOf?: string;
        timingBasis?: "record_lifecycle";
        p50ElapsedMs?: number;
        p95ElapsedMs?: number;
        durationSamples?: number;
        peakOverlap?: number;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        knownIntervals?: number;
        unknownEnds?: number;
        phaseCoverage?: "unavailable";
    }>;
    assistants: z.ZodArray<z.ZodObject<{
        id: z.ZodNullable<z.ZodString>;
        name: z.ZodNullable<z.ZodString>;
        workspaceId: z.ZodNullable<z.ZodString>;
        workspaceName: z.ZodNullable<z.ZodString>;
        avatar: z.ZodNullable<z.ZodObject<{
            url: z.ZodOptional<z.ZodString>;
            background: z.ZodOptional<z.ZodString>;
            emoji: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                unified: z.ZodOptional<z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                id?: string;
                unified?: string;
            }, {
                id?: string;
                unified?: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        }, {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        }>>;
        total: z.ZodNumber;
        running: z.ZodNumber;
        pending: z.ZodNumber;
        interrupted: z.ZodNumber;
        failed: z.ZodNumber;
        failures: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            completedAt: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            id?: string;
            completedAt?: string;
        }, {
            id?: string;
            completedAt?: string;
        }>, "many">;
        failureMarkersTruncated: z.ZodBoolean;
        overlap: z.ZodArray<z.ZodObject<{
            start: z.ZodString;
            end: z.ZodString;
            count: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            end?: string;
            start?: string;
            count?: number;
        }, {
            end?: string;
            start?: string;
            count?: number;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        failed?: number;
        name?: string;
        workspaceId?: string;
        interrupted?: number;
        id?: string;
        running?: number;
        pending?: number;
        total?: number;
        avatar?: {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        };
        workspaceName?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        failureMarkersTruncated?: boolean;
    }, {
        failed?: number;
        name?: string;
        workspaceId?: string;
        interrupted?: number;
        id?: string;
        running?: number;
        pending?: number;
        total?: number;
        avatar?: {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        };
        workspaceName?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        failureMarkersTruncated?: boolean;
    }>, "many">;
    totalAssistants: z.ZodNumber;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    page?: number;
    summary?: {
        total?: number;
        observedAt?: string;
        conversations?: number;
        assistants?: number;
        successRate?: number;
        statuses?: {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        };
        asOf?: string;
        timingBasis?: "record_lifecycle";
        p50ElapsedMs?: number;
        p95ElapsedMs?: number;
        durationSamples?: number;
        peakOverlap?: number;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        knownIntervals?: number;
        unknownEnds?: number;
        phaseCoverage?: "unavailable";
    };
    query?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    assistants?: {
        failed?: number;
        name?: string;
        workspaceId?: string;
        interrupted?: number;
        id?: string;
        running?: number;
        pending?: number;
        total?: number;
        avatar?: {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        };
        workspaceName?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        failureMarkersTruncated?: boolean;
    }[];
    pageSize?: number;
    totalAssistants?: number;
}, {
    page?: number;
    summary?: {
        total?: number;
        observedAt?: string;
        conversations?: number;
        assistants?: number;
        successRate?: number;
        statuses?: {
            error?: number;
            success?: number;
            interrupted?: number;
            unknown?: number;
            running?: number;
            pending?: number;
            timeout?: number;
        };
        asOf?: string;
        timingBasis?: "record_lifecycle";
        p50ElapsedMs?: number;
        p95ElapsedMs?: number;
        durationSamples?: number;
        peakOverlap?: number;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        knownIntervals?: number;
        unknownEnds?: number;
        phaseCoverage?: "unavailable";
    };
    query?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    assistants?: {
        failed?: number;
        name?: string;
        workspaceId?: string;
        interrupted?: number;
        id?: string;
        running?: number;
        pending?: number;
        total?: number;
        avatar?: {
            emoji?: {
                id?: string;
                unified?: string;
            };
            background?: string;
            url?: string;
        };
        workspaceName?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        failureMarkersTruncated?: boolean;
    }[];
    pageSize?: number;
    totalAssistants?: number;
}>;
export type ExecutionObservationOverview = z.infer<typeof executionObservationOverviewSchema>;
export declare const executionObservationListSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        assistantId: z.ZodNullable<z.ZodString>;
        assistantName: z.ZodNullable<z.ZodString>;
        workspaceId: z.ZodNullable<z.ZodString>;
        workspaceName: z.ZodNullable<z.ZodString>;
        conversationId: z.ZodNullable<z.ZodString>;
        threadId: z.ZodNullable<z.ZodString>;
        parentId: z.ZodNullable<z.ZodString>;
        parentThreadId: z.ZodNullable<z.ZodString>;
        forkedFromMessageId: z.ZodNullable<z.ZodString>;
        title: z.ZodNullable<z.ZodString>;
        source: z.ZodNullable<z.ZodString>;
        recordedById: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>;
        createdAt: z.ZodString;
        completedAt: z.ZodNullable<z.ZodString>;
        elapsedTimeMs: z.ZodNullable<z.ZodNumber>;
        invocationKind: z.ZodNullable<z.ZodEnum<["external_assistant", "sub_agent"]>>;
        endKnown: z.ZodBoolean;
        hasError: z.ZodBoolean;
        timingBasis: z.ZodLiteral<"record_lifecycle">;
        phasesAvailable: z.ZodLiteral<false>;
    }, "strip", z.ZodTypeAny, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }>, "many">;
    total: z.ZodNumber;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    asOf: z.ZodString;
    observedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    total?: number;
    page?: number;
    items?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }[];
    observedAt?: string;
    asOf?: string;
    pageSize?: number;
}, {
    total?: number;
    page?: number;
    items?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }[];
    observedAt?: string;
    asOf?: string;
    pageSize?: number;
}>;
export type ExecutionObservationList = z.infer<typeof executionObservationListSchema>;
export declare const executionObservationWorkspacesSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        id?: string;
    }, {
        name?: string;
        id?: string;
    }>, "many">;
    hasMore: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    items?: {
        name?: string;
        id?: string;
    }[];
    hasMore?: boolean;
}, {
    items?: {
        name?: string;
        id?: string;
    }[];
    hasMore?: boolean;
}>;
export declare const executionObservationDetailSchema: z.ZodObject<{
    item: z.ZodObject<{
        id: z.ZodString;
        assistantId: z.ZodNullable<z.ZodString>;
        assistantName: z.ZodNullable<z.ZodString>;
        workspaceId: z.ZodNullable<z.ZodString>;
        workspaceName: z.ZodNullable<z.ZodString>;
        conversationId: z.ZodNullable<z.ZodString>;
        threadId: z.ZodNullable<z.ZodString>;
        parentId: z.ZodNullable<z.ZodString>;
        parentThreadId: z.ZodNullable<z.ZodString>;
        forkedFromMessageId: z.ZodNullable<z.ZodString>;
        title: z.ZodNullable<z.ZodString>;
        source: z.ZodNullable<z.ZodString>;
        recordedById: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>;
        createdAt: z.ZodString;
        completedAt: z.ZodNullable<z.ZodString>;
        elapsedTimeMs: z.ZodNullable<z.ZodNumber>;
        invocationKind: z.ZodNullable<z.ZodEnum<["external_assistant", "sub_agent"]>>;
        endKnown: z.ZodBoolean;
        hasError: z.ZodBoolean;
        timingBasis: z.ZodLiteral<"record_lifecycle">;
        phasesAvailable: z.ZodLiteral<false>;
    }, "strip", z.ZodTypeAny, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }>;
    children: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        assistantId: z.ZodNullable<z.ZodString>;
        assistantName: z.ZodNullable<z.ZodString>;
        workspaceId: z.ZodNullable<z.ZodString>;
        workspaceName: z.ZodNullable<z.ZodString>;
        conversationId: z.ZodNullable<z.ZodString>;
        threadId: z.ZodNullable<z.ZodString>;
        parentId: z.ZodNullable<z.ZodString>;
        parentThreadId: z.ZodNullable<z.ZodString>;
        forkedFromMessageId: z.ZodNullable<z.ZodString>;
        title: z.ZodNullable<z.ZodString>;
        source: z.ZodNullable<z.ZodString>;
        recordedById: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>;
        createdAt: z.ZodString;
        completedAt: z.ZodNullable<z.ZodString>;
        elapsedTimeMs: z.ZodNullable<z.ZodNumber>;
        invocationKind: z.ZodNullable<z.ZodEnum<["external_assistant", "sub_agent"]>>;
        endKnown: z.ZodBoolean;
        hasError: z.ZodBoolean;
        timingBasis: z.ZodLiteral<"record_lifecycle">;
        phasesAvailable: z.ZodLiteral<false>;
    }, "strip", z.ZodTypeAny, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }, {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }>, "many">;
    childTotal: z.ZodNumber;
    childPage: z.ZodNumber;
    usage: z.ZodObject<{
        records: z.ZodNumber;
        totalTokens: z.ZodNullable<z.ZodNumber>;
        unpricedRecords: z.ZodNumber;
        currencies: z.ZodArray<z.ZodObject<{
            currency: z.ZodString;
            amount: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            currency?: string;
            amount?: number;
        }, {
            currency?: string;
            amount?: number;
        }>, "many">;
        basis: z.ZodLiteral<"direct_execution_ledger">;
        coveredExecutions: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    }, {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    }>;
    observedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    children?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }[];
    usage?: {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    };
    observedAt?: string;
    item?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    };
    childTotal?: number;
    childPage?: number;
}, {
    children?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    }[];
    usage?: {
        totalTokens?: number;
        records?: number;
        unpricedRecords?: number;
        currencies?: {
            currency?: string;
            amount?: number;
        }[];
        basis?: "direct_execution_ledger";
        coveredExecutions?: number;
    };
    observedAt?: string;
    item?: {
        status?: "error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout";
        parentId?: string;
        workspaceId?: string;
        id?: string;
        createdAt?: string;
        source?: string;
        completedAt?: string;
        title?: string;
        conversationId?: string;
        threadId?: string;
        invocationKind?: "external_assistant" | "sub_agent";
        assistantName?: string;
        assistantId?: string;
        recordedById?: string;
        workspaceName?: string;
        parentThreadId?: string;
        forkedFromMessageId?: string;
        elapsedTimeMs?: number;
        endKnown?: boolean;
        hasError?: boolean;
        timingBasis?: "record_lifecycle";
        phasesAvailable?: false;
    };
    childTotal?: number;
    childPage?: number;
}>;
export type ExecutionObservationDetail = z.infer<typeof executionObservationDetailSchema>;
export declare const executionObservationDetailQuerySchema: z.ZodObject<{
    executionId: z.ZodString;
    childPage: z.ZodDefault<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    executionId?: string;
    childPage?: number;
}, {
    executionId?: string;
    childPage?: number;
}>;
export declare const executionObservationCompareSchema: z.ZodObject<{
    current: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
        timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
        countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
        assistantId: z.ZodOptional<z.ZodString>;
        conversationId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
        workspaceId: z.ZodOptional<z.ZodString>;
        recordedById: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodString>;
        statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
        search: z.ZodOptional<z.ZodString>;
        asOf: z.ZodOptional<z.ZodString>;
    } & {
        page: z.ZodDefault<z.ZodNumber>;
        pageSize: z.ZodDefault<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>;
    baseline: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
        timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
        countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
        assistantId: z.ZodOptional<z.ZodString>;
        conversationId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
        workspaceId: z.ZodOptional<z.ZodString>;
        recordedById: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodString>;
        statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
        search: z.ZodOptional<z.ZodString>;
        asOf: z.ZodOptional<z.ZodString>;
    } & {
        page: z.ZodDefault<z.ZodNumber>;
        pageSize: z.ZodDefault<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>;
}, "strict", z.ZodTypeAny, {
    current?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    baseline?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
}, {
    current?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    baseline?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
}>;
export declare const executionObservationAnomalySchema: z.ZodObject<{
    query: z.ZodEffects<z.ZodObject<{
        from: z.ZodString;
        to: z.ZodString;
        timeZone: z.ZodEffects<z.ZodDefault<z.ZodString>, string, string>;
        countingUnit: z.ZodDefault<z.ZodEnum<["root_execution", "assistant_invocation"]>>;
        assistantId: z.ZodOptional<z.ZodString>;
        conversationId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        unknownAssistantOnly: z.ZodOptional<z.ZodBoolean>;
        workspaceId: z.ZodOptional<z.ZodString>;
        recordedById: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodString>;
        statuses: z.ZodOptional<z.ZodArray<z.ZodEnum<["running", "success", "error", "pending", "timeout", "interrupted", "unknown"]>, "many">>;
        search: z.ZodOptional<z.ZodString>;
        asOf: z.ZodOptional<z.ZodString>;
    } & {
        page: z.ZodDefault<z.ZodNumber>;
        pageSize: z.ZodDefault<z.ZodNumber>;
    }, "strict", z.ZodTypeAny, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }, {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    }>;
    rule: z.ZodDefault<z.ZodEnum<["failed", "long_running", "slow_completed"]>>;
    thresholdMs: z.ZodDefault<z.ZodNumber>;
    limit: z.ZodDefault<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    query?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    rule?: "failed" | "long_running" | "slow_completed";
    thresholdMs?: number;
    limit?: number;
}, {
    query?: {
        timeZone?: string;
        workspaceId?: string;
        search?: string;
        source?: string;
        page?: number;
        conversationId?: string;
        from?: string;
        to?: string;
        threadId?: string;
        assistantId?: string;
        countingUnit?: "root_execution" | "assistant_invocation";
        unknownAssistantOnly?: boolean;
        recordedById?: string;
        statuses?: ("error" | "success" | "interrupted" | "unknown" | "running" | "pending" | "timeout")[];
        asOf?: string;
        pageSize?: number;
    };
    rule?: "failed" | "long_running" | "slow_completed";
    thresholdMs?: number;
    limit?: number;
}>;
export type ExecutionObservationComparison = {
    current: ExecutionObservationSummary;
    baseline: ExecutionObservationSummary;
    currentPerHour: number;
    baselinePerHour: number;
    countDelta: number;
    successRateDelta: number | null;
};
export type ExecutionObservationAnomalies = {
    rule: z.infer<typeof executionObservationAnomalySchema>['rule'];
    thresholdMs: number;
    items: ExecutionObservationRecord[];
    total: number;
    asOf: string;
    observedAt: string;
};
/** Complete conversation groups, paginated after aggregation so a group is never split. */
export declare const executionObservationConversationSchema: z.ZodObject<{
    key: z.ZodString;
    conversationId: z.ZodNullable<z.ZodString>;
    threadId: z.ZodNullable<z.ZodString>;
    executionId: z.ZodNullable<z.ZodString>;
    total: z.ZodNumber;
    threads: z.ZodNumber;
    branches: z.ZodNumber;
    childExecutions: z.ZodNumber;
    failed: z.ZodNumber;
    unknownEnds: z.ZodNumber;
    overlap: z.ZodArray<z.ZodObject<{
        start: z.ZodString;
        end: z.ZodString;
        count: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        end?: string;
        start?: string;
        count?: number;
    }, {
        end?: string;
        start?: string;
        count?: number;
    }>, "many">;
    failures: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        completedAt: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id?: string;
        completedAt?: string;
    }, {
        id?: string;
        completedAt?: string;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    failed?: number;
    total?: number;
    key?: string;
    conversationId?: string;
    executionId?: string;
    threadId?: string;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    unknownEnds?: number;
    failures?: {
        id?: string;
        completedAt?: string;
    }[];
    threads?: number;
    branches?: number;
    childExecutions?: number;
}, {
    failed?: number;
    total?: number;
    key?: string;
    conversationId?: string;
    executionId?: string;
    threadId?: string;
    overlap?: {
        end?: string;
        start?: string;
        count?: number;
    }[];
    unknownEnds?: number;
    failures?: {
        id?: string;
        completedAt?: string;
    }[];
    threads?: number;
    branches?: number;
    childExecutions?: number;
}>;
export type ExecutionObservationConversation = z.infer<typeof executionObservationConversationSchema>;
export declare const executionObservationConversationsSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        conversationId: z.ZodNullable<z.ZodString>;
        threadId: z.ZodNullable<z.ZodString>;
        executionId: z.ZodNullable<z.ZodString>;
        total: z.ZodNumber;
        threads: z.ZodNumber;
        branches: z.ZodNumber;
        childExecutions: z.ZodNumber;
        failed: z.ZodNumber;
        unknownEnds: z.ZodNumber;
        overlap: z.ZodArray<z.ZodObject<{
            start: z.ZodString;
            end: z.ZodString;
            count: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            end?: string;
            start?: string;
            count?: number;
        }, {
            end?: string;
            start?: string;
            count?: number;
        }>, "many">;
        failures: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            completedAt: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            id?: string;
            completedAt?: string;
        }, {
            id?: string;
            completedAt?: string;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        failed?: number;
        total?: number;
        key?: string;
        conversationId?: string;
        executionId?: string;
        threadId?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        unknownEnds?: number;
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        threads?: number;
        branches?: number;
        childExecutions?: number;
    }, {
        failed?: number;
        total?: number;
        key?: string;
        conversationId?: string;
        executionId?: string;
        threadId?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        unknownEnds?: number;
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        threads?: number;
        branches?: number;
        childExecutions?: number;
    }>, "many">;
    total: z.ZodNumber;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    asOf: z.ZodString;
    observedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    total?: number;
    page?: number;
    items?: {
        failed?: number;
        total?: number;
        key?: string;
        conversationId?: string;
        executionId?: string;
        threadId?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        unknownEnds?: number;
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        threads?: number;
        branches?: number;
        childExecutions?: number;
    }[];
    observedAt?: string;
    asOf?: string;
    pageSize?: number;
}, {
    total?: number;
    page?: number;
    items?: {
        failed?: number;
        total?: number;
        key?: string;
        conversationId?: string;
        executionId?: string;
        threadId?: string;
        overlap?: {
            end?: string;
            start?: string;
            count?: number;
        }[];
        unknownEnds?: number;
        failures?: {
            id?: string;
            completedAt?: string;
        }[];
        threads?: number;
        branches?: number;
        childExecutions?: number;
    }[];
    observedAt?: string;
    asOf?: string;
    pageSize?: number;
}>;
export type ExecutionObservationConversations = z.infer<typeof executionObservationConversationsSchema>;
