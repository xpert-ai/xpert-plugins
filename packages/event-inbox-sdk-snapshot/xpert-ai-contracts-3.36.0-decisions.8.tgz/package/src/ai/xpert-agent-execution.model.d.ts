import { StoredMessage } from '@langchain/core/messages';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IXpert, TXpertTeamNodeType } from './xpert.model';
import { IXpertAgent } from './xpert-agent.model';
import { TSensitiveOperation } from './chat.model';
import { WorkflowNodeTypeEnum } from './xpert-workflow.model';
import type { IModelUsageDetails } from './model-usage.model';
import type { TAvatar } from '../types';
export type TXpertExecution = {
    category?: TXpertTeamNodeType;
    type?: WorkflowNodeTypeEnum | string;
    title?: string;
    inputs?: any;
    outputs?: any;
    status?: XpertAgentExecutionStatusEnum;
    error?: string;
    elapsedTime?: number;
    /** Wall-clock end of the current execution attempt; cleared when execution resumes. */
    completedAt?: Date | null;
    threadId?: string;
    checkpointNs?: string;
    checkpointId?: string;
    channelName?: string;
    parent_thread_id?: string;
    /**
     * Include workflow node key
     */
    agentKey?: string;
    predecessor?: string;
    xpert?: IXpert;
    xpertId?: string;
    parentId?: string;
};
export type TXpertAgentExecutionCheckpoint = {
    threadId: string;
    checkpointNs: string;
    checkpointId: string;
    parentCheckpointId?: string | null;
    createdAt?: string | null;
    metadata?: Record<string, unknown> | null;
    isCurrent?: boolean;
};
/** Priced model usage for one execution, in each provider's reported currency. */
export type ExecutionUsageSummary = {
    costs: Array<{
        currency: string;
        amount: number;
        tokens: number;
    }>;
    /** Most recent positive prompt measurement for the context-window indicator. */
    lastInputTokens: number;
};
/**
 * Corresponds to the run in the [Agent Protocol](https://github.com/langchain-ai/agent-protocol).
 */
export type TXpertAgentExecution = TXpertExecution & {
    /**
     * Total token usage of chat model
     */
    tokens?: number;
    /**
     * Token usage of embedding
     */
    embedTokens?: number;
    metadata?: TAgentExecutionMetadata;
    /**
     * Latency of response from provider (s)
     */
    responseLatency?: number;
    /** Posted point debits for this execution alone. Absent until a linked debit is recorded. */
    chargedPoints?: number | null;
    usageSummary?: ExecutionUsageSummary | null;
    /** Available when the priced calls have a single currency. */
    totalPrice?: number | null;
    currency?: string | null;
    inputTokens?: number;
    inputUnitPrice?: number;
    inputPriceUnit?: number;
    outputTokens?: number;
    outputUnitPrice?: number;
    outputPriceUnit?: number;
    /**
     * Latest operation when interrupted
     */
    operation?: TSensitiveOperation;
    messages?: StoredMessage[];
    agent?: IXpertAgent;
    totalTokens?: number;
    modelUsages?: IModelUsageDetails[];
    /**
     * Summary of conversation
     */
    summary?: string;
};
/**
 * Execution of agent or workflow nodes.
 *
 * Corresponds to the run in the [Agent Protocol](https://github.com/langchain-ai/agent-protocol).
 */
export interface IXpertAgentExecution extends IBasePerTenantAndOrganizationEntityModel, TXpertAgentExecution {
    subExecutions?: IXpertAgentExecution[];
    runningExecution?: IXpertAgentExecution;
}
/**
 * Corresponds to the status of Run in [Agent Protocol](https://github.com/langchain-ai/agent-protocol).
 */
export declare enum XpertAgentExecutionStatusEnum {
    RUNNING = "running",
    SUCCESS = "success",
    ERROR = "error",
    PENDING = "pending",
    TIMEOUT = "timeout",
    INTERRUPTED = "interrupted"
}
export type TAgentExecutionMetadata = {
    /** Host-created result continuation; its inbox claim proves the originating execution. */
    runtimeContinuation?: {
        inboxId: string;
    };
    /** Written atomically with root checkpoints, not by message/execution finalizers. */
    recovery?: import('./chat-recovery.model').TChatExecutionRecovery;
    templateSource?: import('../agent-plugin').TemplateAgentSource;
    businessOutcome?: import('@xpert-ai/chatkit-types').TAgentExecutionOutcome;
    /** Recorded by the invocation boundary; never inferred from agent names. */
    invocationKind?: 'external_assistant' | 'sub_agent';
    /** Tool call in the parent execution that started this run. Omit for workflow-driven runs. */
    sourceToolCallId?: string;
    assistantName?: string;
    assistantAvatar?: TAvatar;
    /**
     * AI model provider
     */
    provider?: string;
    /**
     * AI Model
     */
    model?: string;
    /** Opaque Assistant model option used by the base and Primary models. */
    primaryModelId?: string;
    primaryModelSource?: import('./assistant-model.model').TAssistantPrimaryModelSelectionSource;
    /** Sanitized model snapshot used to keep resume and retry deterministic. */
    primaryModelSnapshot?: Pick<import('./copilot-model.model').TCopilotModel, 'copilotId' | 'modelType' | 'model' | 'options'>;
    triggerSource?: 'integration' | 'channel' | 'api' | 'job' | 'trigger' | string;
    sourceIntegrationId?: string;
    integrationId?: string;
    channelType?: string;
    channelSource?: string;
    from?: string;
    fromEndUserId?: string;
    channelUserId?: string;
    uuid?: string;
    ownerWxid?: string;
    contactId?: string;
    chatId?: string;
    chatType?: string;
    senderId?: string;
    sourceMessageLogIds?: string[];
    handoffMessageId?: string;
    handoffTraceId?: string;
    handoffParentMessageId?: string;
    runtimePrincipalType?: string;
    runtimePrincipalXpertId?: string;
    /** Root execution this run continued after a durable thread pause. */
    resumedFromExecutionId?: string;
    [key: string]: unknown;
};
/** Public execution summary shared by live events and conversation history. */
export type TChatAgentRunSummary = {
    businessOutcome?: import('@xpert-ai/chatkit-types').TAgentExecutionOutcome;
    /** Identifies the main reply and its total duration without inferring identity from agent names. */
    isRoot?: boolean;
    id: string;
    parentId?: string;
    type?: string;
    category?: TXpertTeamNodeType;
    agentKey?: string;
    xpertId?: string;
    xpertName?: string;
    avatar?: TAvatar;
    title?: string;
    invocationKind?: TAgentExecutionMetadata['invocationKind'];
    /** Matches the Tool component id within parentId; never match by tool name or provider. */
    sourceToolCallId?: TAgentExecutionMetadata['sourceToolCallId'];
    model?: string;
    status?: string;
    elapsedTime?: number;
    inputs?: unknown;
    error?: string;
    createdAt?: string;
    updatedAt?: string;
};
