import type { ConversationResourceTarget } from '../conversation-resource.model';
import type { RuntimeCapabilitiesSelection, TMessageContentResourceCard } from '@xpert-ai/chatkit-types';
import type { RuntimeResourcesSelection } from '../agent-plugin';
import type { IconDefinition, TAvatar } from '../types';
import type { XpertProjectTypeRef } from './xpert-project-type.model';
/**
 * Public group protocol for ChatConversation(purpose='group'). Each Assistant has a separate runtime.
 * Participant IDs identify membership within this group; subject IDs identify User or Xpert records.
 * These DTOs do not grant access: validate inputs and resolve identity/permissions on the server.
 * Extend machine-readable discriminants and their validators/consumers together; never infer kind from names.
 */
/**
 * Server-resolved communication intent, independent of whether the sender is human or an Assistant.
 * `request` addresses members and may wake an Assistant; `reply` answers an existing request and
 * routes back to its sender; `message` publishes information without waking addressed Assistants.
 */
export type ChatGroupIntent = 'request' | 'reply' | 'message';
/**
 * Completion intent for one sender's reply to one group request, independent of delivery/run status.
 * `progress` publishes a partial answer without completing the request or waking its requester.
 * `final` completes this sender's answer only after successful publication and may wake the requester.
 * It does not complete a Project task, accept its result, or complete other recipients' answers.
 */
export type ChatGroupReplyStage = 'progress' | 'final';
/** Per-recipient delivery progress, independent of the overall Assistant run status. */
export type ChatGroupDeliveryStatus = 
/** Accepted for delivery; dispatch may still be pending. */
'pending'
/** Runtime reserved; acceptance of this specific input has not yet been confirmed. */
 | 'starting'
/** Submitted to an active run through the existing steer/follow-up mechanism. */
 | 'steering'
/**
 * Consumed by the runtime; an Assistant delivery linked to an execution can display this as "read".
 * Non-waking deliveries also use this terminal state, without asserting that a human has read them.
 * Does not mean a reply has been published or the run has finished.
 */
 | 'consumed'
/** Delivery cannot proceed under the current authorization or runtime state. */
 | 'blocked'
/** Delivery was canceled. */
 | 'canceled'
/** Dispatch failed after its retry policy was exhausted. */
 | 'failed';
/** Public member profile; runtime conversation IDs and private account data are excluded. */
export interface ChatGroupParticipant {
    /** GroupParticipant ID used by mentions, senders, recipients and runtime projections. */
    id: string;
    /** Selects the entity namespace of subjectId; also drives member-specific UI and routing. */
    kind: 'user' | 'assistant';
    /** User Account ID for `user`, Xpert ID for `assistant`; not a membership ID. */
    subjectId: string;
    /** Display label only; use IDs for identity and authorization. */
    name: string;
    /** Public User/Xpert avatar; absence permits a display fallback. */
    avatar?: TAvatar | null;
    /** Group management role; `owner` does not identify the primary Assistant. */
    role: 'owner' | 'member';
    /** Inactive members may remain in snapshots to identify historical message authors. */
    active: boolean;
}
/** Invite candidate before membership exists; submit kind + subjectId to add the member. */
export type ChatGroupCandidate = Pick<ChatGroupParticipant, 'kind' | 'subjectId' | 'name' | 'avatar'>;
/** A rejected send has not persisted a message or queued an Assistant execution. */
export type ChatGroupProjectRequiredError = {
    statusCode: 400;
    error: 'Bad Request';
    code: 'GROUP_PROJECT_REQUIRED';
    message: string;
    groupId: string;
    participantIds: string[];
};
/**
 * Per-message selections from the shared Composer, scoped to one addressed Assistant.
 * This does not choose the recipient: the server requires a single matching Assistant recipient
 * and validates project/file/capability access within that scope.
 */
export interface ChatGroupComposerInput {
    /** Membership ID of the Assistant whose Composer resources were selected. */
    participantId: string;
    /** Optional project context for this Assistant, subject to server-side access checks. */
    projectId?: string;
    /** Workspace file references, not file contents or arbitrary download URLs. */
    files?: {
        /** Workspace-relative path; currently must match workspacePath. */
        filePath: string;
        /** Authorized path in the target workspace; absolute paths and traversal are rejected. */
        workspacePath: string;
        originalName?: string;
        mimeType?: string;
        /** File size in bytes, when available. */
        size?: number;
        purpose: 'workspace';
    }[];
    /** Shared runtime-resource selection contract, including its own catalog revision. */
    runtimeResources?: RuntimeResourcesSelection;
    /** Shared capability selection contract; selection does not confer permission to use a capability. */
    runtimeCapabilities?: RuntimeCapabilitiesSelection;
}
/**
 * Server-authored clickable resource entry persisted with a group message.
 * History replay may show the entry but must not auto-open it; opening always reauthorizes the resource in the current group and Project.
 */
export interface ChatGroupResourceLink {
    /** Public type icon captured by the host when publishing. Optional for legacy links; never an access grant. */
    icon?: IconDefinition;
    /** Canonical locator shared with discovery and Workbench. Contains no access grant. */
    resource: ConversationResourceTarget;
    /** Receiving group's runtime Project; checked before opening, never a source Project override. */
    projectId: string;
    /** Display label only; never use it to infer resource identity or type. */
    title: string;
}
/** Live, requester-addressed navigation request derived from a resource link; not a durable open-on-load instruction. */
export interface ChatGroupResourceOpenRequest extends ChatGroupResourceLink {
    /** Server-generated deduplication ID; consumers must not repeat an already handled navigation request. */
    requestId: string;
    /** Initiating message's client correlation ID, or its message ID fallback; used to match the current sender. */
    clientMessageId: string;
}
/** Server-authored routing and causality metadata; public senders cannot supply or override identity. */
export interface ChatGroupCommunication {
    /** Inert resource entries for message rendering, including history; these alone never trigger navigation. */
    resourceLinks?: ChatGroupResourceLink[];
    /**
     * Server-only instruction to derive a fresh resource_open event for one human participant.
     * Stream adapters check audience, connection freshness and request deduplication; replayed messages remain inert.
     */
    resourceNavigation?: {
        /** Unique navigation request ID, carried into ChatGroupResourceOpenRequest. */
        requestId: string;
        /** Server emission time in Unix epoch milliseconds; used to reject stale/replayed instructions. */
        issuedAt: number;
        /** Client correlation ID of the initiating message, with server message ID as fallback. */
        clientMessageId: string;
        /** Intended viewer's group membership ID, not a User Account or Assistant ID. */
        participantId: string;
    };
    /** Host-only task routing metadata; never accepted by group send APIs or model tools. */
    projectTask?: {
        invocationId: string;
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
    };
    /** Durable Invocation result notification, delivered through the group queue. */
    runtimeResult?: {
        invocationId: string;
        consumerExecutionId: string;
        revision: number;
        projectId: string;
        projectTaskId: string;
        taskExecutionId: string;
        specificationDigest: string;
    };
    /** Validated Composer selections for this message, when supplied by a human sender. */
    composer?: ChatGroupComposerInput;
    intent: ChatGroupIntent;
    /** Authenticated human or verified runtime author's membership ID. */
    senderId: string;
    /** Resolved membership IDs, including the original sender when intent is `reply`. */
    recipientIds: string[];
    /** Public group request being answered; a protocol relationship, not a required UI quote. */
    replyToMessageId?: string;
    /**
     * Valid only for `intent: 'reply'`. New Assistant tool calls must explicitly choose a stage.
     * Absent on legacy replies means `final`; new publications persist the resolved stage.
     * A successfully published final tool reply suppresses the automatic final answer for the same
     * request and sender. Progress replies, ordinary messages and requests do not suppress it.
     */
    replyStage?: ChatGroupReplyStage;
    /** Public group message that caused this runtime output; independent of explicit reply intent. */
    causedByMessageId?: string;
    /** First public message ID in the causal chain, inherited across Assistant handoffs/replies. */
    rootMessageId: string;
    /** Real initiating User Account ID, inherited for execution attribution; never an Assistant principal. */
    rootUserId: string;
    /** Causal depth: roots start at zero; inherited messages increment it for server loop limits. */
    hop: number;
}
/** JSON presentation values only; no executable code, runtime sessions or host credentials. */
export type ChatGroupDisplayValue = string | number | boolean | null | ChatGroupDisplayValue[] | {
    [key: string]: ChatGroupDisplayValue;
};
/**
 * First-phase allowlist of inert tool-result snapshots. This is not a plugin publication API.
 * Widget uses existing flat A2UI messages; ResourceCard uses the existing card contract.
 * McpApp carries only a result snapshot, never an App instance, token, input or bridge.
 * These blocks do not complete a request, wake an Assistant, or authorize resource access.
 * Consumers must ignore unknown/malformed blocks and must not attach the source run's actions.
 */
export type ChatGroupDisplay = TMessageContentResourceCard | {
    id: string;
    type: 'component';
    data: {
        category: 'Dashboard';
    } & ({
        type: 'Widget';
        widgets: {
            name: string;
            messages: {
                [key: string]: ChatGroupDisplayValue;
            }[];
        }[];
    } | {
        type: 'McpApp';
        toolResult: {
            content: {
                type: 'text';
                text: string;
            }[];
            structuredContent?: {
                [key: string]: ChatGroupDisplayValue;
            };
            isError?: boolean;
        };
    });
};
/** Public message in the shared group transcript, separate from private runtime ChatMessages. */
export interface ChatGroupMessage {
    /** Persisted ChatMessage ID in the group conversation. */
    id: string;
    /** Correlation/idempotency key of the original submission; not the persisted message ID. */
    clientMessageId: string;
    /** Server-assigned order within this conversation; unchanged when this message is updated. */
    sequence: number;
    text: string;
    /**
     * Server-filtered result snapshots, present even when text is empty. Block IDs are stable
     * within this public message. Live snapshots and paginated history use the same shape.
     * Only trusted runtime projection may supply these; public send APIs remain text-only.
     */
    display?: ChatGroupDisplay[];
    /** ISO 8601 creation timestamp; sequence, not this timestamp, defines transcript order. */
    createdAt: string;
    communication: ChatGroupCommunication;
    /** Members with linked execution records; opening one still requires separate runtime-view authorization. */
    runtimeParticipantIds?: string[];
    /** Delivery state per addressed member; an empty list does not imply unread or failed delivery. */
    deliveries: {
        participantId: string;
        status: ChatGroupDeliveryStatus;
        /** Credential-redacted execution failure; absent for pending or successful deliveries. */
        error?: string;
    }[];
}
/**
 * Binds a member to an exact `@name` span in the submitted text. Offsets use JavaScript UTF-16
 * string indices: [start, end). Spans must not overlap; membership and displayed name are validated.
 */
export interface ChatGroupMention {
    /** Membership ID, not the User/Xpert subject ID. */
    participantId: string;
    /** Inclusive offset of `@`. */
    start: number;
    /** Exclusive offset after the member name. */
    end: number;
}
/**
 * Public human-message input. The server derives author, intent and recipients from trusted context
 * and validated mentions. No mentions routes to the primary Assistant (conversation.xpertId);
 * explicit mentions route only to those members. Busy Assistants receive input through steer.
 */
export type ChatGroupSendInput = {
    composer?: ChatGroupComposerInput;
    /** Client-generated UUID; reuse for retries of the same submission, scoped to group and sender. */
    clientMessageId: string;
    /** Message text against which mention offsets are validated. */
    text: string;
    mentions?: ChatGroupMention[];
    /** Reply candidate; it does not override @ routing or the primary-Assistant fallback. */
    replyToMessageId?: string;
};
/** Identity to invite; the server resolves display data, access and the new membership ID. */
export type ChatGroupMemberInput = {
    kind: 'user' | 'assistant';
    subjectId: string;
};
/** Creates the shared conversation with the authenticated human as owner. */
export interface ChatGroupCreateInput {
    title: string;
    /** Xpert ID stored as conversation.xpertId and enrolled as the primary Assistant. */
    assistantId: string;
}
/** Lightweight list entry; use a snapshot for full membership and message history. */
export interface ChatGroupSummary {
    /** Stable discriminator for the shared Assistant/conversation list. */
    purpose: 'group';
    /** Shared ChatConversation ID, also used as groupId by APIs. */
    id: string;
    /** Shared conversation thread ID, not an individual Assistant runtime thread. */
    threadId: string;
    title: string;
    /** ISO 8601 list activity time, using the latest message time when available. */
    updatedAt: string;
    /** Truncated preview only; never use it as the full message or for routing. */
    lastMessage: string;
    /** Total active members; may exceed the avatar preview count in members. */
    memberCount: number;
    /** Bounded active-member preview for composite avatars, not the complete roster. */
    members: Pick<ChatGroupParticipant, 'id' | 'kind' | 'name' | 'avatar'>[];
    /** Current viewer's unread state, based on their read sequence. */
    unread: boolean;
    /** Current viewer's list preference, not a group-wide setting. */
    pinned: boolean;
    /** Current viewer's list preference; does not archive the group for other members. */
    archived: boolean;
}
/** Authorized public state plus one page of persisted messages; excludes private runtime configuration. */
export interface ChatGroupSnapshot {
    /** Shared ChatConversation ID, also used as groupId by APIs. */
    id: string;
    /** Shared conversation thread ID; Assistant execution threads are separate. */
    threadId: string;
    title: string;
    /** Current viewer's membership ID; compare with communication.senderId for own-message presentation. */
    viewerParticipantId: string;
    /** Primary Assistant's Xpert ID; match an assistant member's subjectId, not its id or role. */
    xpertId: string;
    /** Includes inactive members so older messages can retain their authors' identities. */
    members: ChatGroupParticipant[];
    /** One history page in ascending sequence order, not necessarily the full transcript. */
    messages: ChatGroupMessage[];
    /** Older messages exist before this page; paginate using its earliest message sequence. */
    hasMore: boolean;
    /** Server state version covering message, membership and delivery changes; not a message count or SSE cursor. */
    revision: number;
    /** Public runtime state for member threads with a recorded run, including completed/idle runs. */
    runs: ChatGroupRun[];
    /** Pending/claimed human interactions; full request payloads are returned only to an authorized claimant. */
    interactions?: ChatGroupInteraction[];
}
/** Public summary of a runtime pause requiring a designated human's approval or client tool execution. */
export interface ChatGroupInteraction {
    id: string;
    /** Run that produced this interaction. */
    runId: string;
    /** Assistant membership ID owning the run. */
    participantId: string;
    /** User Account ID allowed to claim/respond; not a group membership ID. */
    assignedUserId: string;
    /** Claim/response lifecycle; claiming does not itself complete or resume the interaction. */
    status: 'pending' | 'claimed' | 'completed' | 'canceled';
}
/** Returned after the assigned human claims an interaction; observing the group stream does not claim it. */
export interface ChatGroupInteractionClaim {
    /** Interaction ID, matching ChatGroupInteraction.id. */
    id: string;
    /** Client claim identifier bound by the server; reuse it when responding or retrying the same claim. */
    claimId: string;
    /** Discriminate by kind, then validate request with the existing client-tool or approval protocol. */
    requests: ({
        kind: 'client_tool';
        request: unknown;
    } | {
        kind: 'approval';
        request: unknown;
    })[];
}
/** Public projection of one Assistant runtime's current thread/run control state. */
export interface ChatGroupRun {
    /** Assistant membership ID. */
    participantId: string;
    /** Execution/run identifier; not the shared group thread ID. */
    runId: string;
    /** Thread state, distinct from individual message delivery statuses. */
    status: 'busy' | 'pausing' | 'paused' | 'interrupted' | 'idle' | 'error';
}
/**
 * Public group SSE payload. Transport event IDs are opaque replay cursors, separate from revision/sequence.
 * Extend this union together with stream validation and reducers; private runtime events do not belong here.
 */
export type ChatGroupEvent = 
/** Live navigation for the addressed requester; clients reauthorize the resource before opening it. */
{
    type: 'resource_open';
    request: ChatGroupResourceOpenRequest;
}
/** Refresh public state and reconcile its history page by message ID. */
 | {
    type: 'snapshot';
    snapshot: ChatGroupSnapshot;
}
/** Append a text delta to a runtime output; messageId is the runtime output ID, not yet the group message ID. */
 | {
    type: 'text';
    participantId: string;
    runId: string;
    messageId: string;
    text: string;
}
/** Replay continuity was lost; recover from a fresh snapshot rather than trusting accumulated deltas. */
 | {
    type: 'resync';
};
/**
 * Workspace-authorized view of the execution linked to a public group message.
 * Opens in the existing external-Assistant Workbench view; group membership alone grants no runtime access.
 * Contains selected display messages, never checkpoints or runtime configuration.
 */
export interface ChatGroupRuntimeView {
    /** Assistant's ChatConversation(purpose='group_assistant_runtime'), not the shared group conversation. */
    conversationId: string;
    /** Assistant runtime thread ID. */
    threadId: string;
    /** Xpert ID owning the execution. */
    xpertId: string;
    /** Corresponding Assistant membership ID in the shared group. */
    participantId: string;
    title: string;
    avatar?: TAvatar | null;
    /** Recorded execution selected by the public group message and participant. */
    executionId: string;
    /** Optional runtime input/output message to focus when opening the view. */
    messageId?: string;
    /** Execution status, distinct from the group's delivery and thread statuses. */
    status: string;
    /** Credential-redacted error for this execution, independent of later runs in the conversation. */
    error?: string;
    /** Display projection for this execution; human runtime context is replaced with the public question. */
    messages: {
        /** Runtime ChatMessage ID, not the public group message ID. */
        id: string;
        role: string;
        /** Existing message-content payload; narrow with its renderer/protocol before use. */
        content: unknown;
        /** Optional reasoning payload; likewise requires the existing message protocol's narrowing. */
        reasoning?: unknown;
        status?: string;
        executionId?: string;
        /** ISO 8601 timestamp. */
        createdAt: string;
    }[];
}
/** Shared Project membership is explicitly selected; group membership alone grants no Project access. */
export interface ChatGroupProjectInput {
    project: {
        mode: 'create';
        id: string;
        name: string;
        projectType?: XpertProjectTypeRef;
    } | {
        mode: 'existing';
        projectId: string;
        reuse?: true;
    };
    /** Include the primary Assistant. Updates add participants and preserve existing bindings. */
    participantIds: string[];
}
export interface ChatGroupProject {
    projectId: string;
    name: string;
    /** Complete active selection after the operation, including previously bound members. */
    participantIds: string[];
}
