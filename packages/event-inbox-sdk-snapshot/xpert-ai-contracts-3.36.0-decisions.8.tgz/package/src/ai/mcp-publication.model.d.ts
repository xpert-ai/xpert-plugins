import type { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import type { JSONValue } from '../core.model';
import type { McpApiKeySubjectType } from './mcp-auth.model';
import type { McpCapabilityDescriptor, McpCapabilityType } from './mcp-capability.model';
import type { I18nObject } from '../types';
import type { JsonSchemaObjectType } from './types';
export interface McpPublicationPluginSource {
    toolsetId: string;
    name: string;
    provider: string;
    pluginName: string;
}
/** A configuration tab edits the existing bound source; it never creates a toolset. */
export interface McpPublicationConfigurationTab extends McpPublicationPluginSource {
    title: I18nObject;
    schema: JsonSchemaObjectType;
    canEdit: boolean;
}
/** Opaque form placeholder. Array secrets append a source reference; clients must return it unchanged. */
export declare const MCP_CONFIGURATION_SECRET_MASK = "__xpert_mcp_secret_unchanged__";
export interface McpPublicationConfiguration {
    values: Record<string, JSONValue>;
    revision: string;
}
export declare const MCP_PROTOCOL_VERSION: "2026-07-28";
export declare const MCP_TASK_EXTENSION_ID: "io.modelcontextprotocol/tasks";
export declare const MCP_HTTP_CORS_REQUEST_HEADERS: readonly ["MCP-Protocol-Version", "Mcp-Session-Id", "Mcp-Method", "Mcp-Name", "Traceparent", "Tracestate", "Baggage", "X-Request-Id"];
export declare const MCP_HTTP_CORS_EXPOSED_HEADERS: readonly ["Content-Location", "WWW-Authenticate", "MCP-Protocol-Version", "Mcp-Session-Id", "X-Request-Id"];
export declare const MCP_PUBLICATION_STATUSES: readonly ["draft", "active", "disabled"];
export type McpPublicationStatus = (typeof MCP_PUBLICATION_STATUSES)[number];
export declare const MCP_PUBLICATION_REVIEW_STATUSES: readonly ["current", "required"];
export type McpPublicationReviewStatus = (typeof MCP_PUBLICATION_REVIEW_STATUSES)[number];
export declare const MCP_AUTH_METHODS: readonly ["api_key", "oauth"];
export type McpAuthMethod = (typeof MCP_AUTH_METHODS)[number];
export declare const MCP_CAPABILITY_APPROVAL_MODES: readonly ["deny", "allow", "confirm"];
export type McpCapabilityApprovalMode = (typeof MCP_CAPABILITY_APPROVAL_MODES)[number];
export interface McpCapabilityPolicy {
    approvalMode?: McpCapabilityApprovalMode;
    timeoutMs?: number;
    rateLimit?: {
        requests: number;
        windowSeconds: number;
    };
}
/** Host-owned execution configuration. Tool arguments cannot override these bindings. */
export interface McpPublicationRuntimeConfiguration {
    files?: {
        type: 'user';
    };
}
export interface IMcpPublication extends IBasePerTenantAndOrganizationEntityModel {
    name: string;
    slug: string;
    status: McpPublicationStatus;
    authMethods: McpAuthMethod[];
    instructions?: string | null;
    runtime?: McpPublicationRuntimeConfiguration | null;
    protocolVersion: typeof MCP_PROTOCOL_VERSION;
    reviewStatus: McpPublicationReviewStatus;
    reviewReason?: string | null;
    reviewedAt?: Date | null;
    reviewedById?: string | null;
}
/** Organization admission to a tenant-scoped MCP Publication. */
export interface IMcpPublicationAccess extends IBasePerTenantAndOrganizationEntityModel {
    publicationId: string;
    enabled: boolean;
    enabledById?: string | null;
    disabledAt?: Date | null;
    disabledById?: string | null;
}
/** Management-list projection used to render publication health without per-card follow-up requests. */
export interface IMcpPublicationSummary extends IMcpPublication {
    capabilityCount: number;
    apiKeyCount: number;
    oauthEnabled: boolean;
    /** Scope that owns the underlying Publication. Shared tenant Publications may be managed from an admitted organization. */
    publicationScope?: 'tenant' | 'organization';
    /** Effective access state for the current organization when managing a shared tenant Publication. */
    organizationAccessEnabled?: boolean;
    recentInvocationAt?: Date | null;
    recentErrorAt?: Date | null;
}
export interface IMcpPublicationCapability extends IBasePerTenantAndOrganizationEntityModel {
    publicationId: string;
    toolsetId: string;
    capabilityType: McpCapabilityType;
    capabilityKey: string;
    publicName: string;
    enabled: boolean;
    policy?: McpCapabilityPolicy | null;
    descriptorHash: string;
    descriptorSnapshot: McpCapabilityDescriptor;
    pluginVersion?: string | null;
}
/** Current plugin-declared capability catalog for a concrete toolset instance. */
export interface IMcpCapabilityCatalog extends IBasePerTenantAndOrganizationEntityModel {
    toolsetId: string;
    capabilityType: McpCapabilityType;
    capabilityKey: string;
    descriptorHash: string;
    descriptor: McpCapabilityDescriptor;
    enabled: boolean;
}
/** Selectable capability source summary used to lazily load one toolset catalog at a time. */
export interface IMcpCapabilitySourceSummary {
    toolsetId: string;
    name: string;
    pluginName?: string;
    capabilityCount: number;
}
export declare const MCP_TASK_STATUSES: readonly ["working", "input_required", "completed", "failed", "cancelled"];
export type McpTaskStatus = (typeof MCP_TASK_STATUSES)[number];
export interface IMcpTask extends IBasePerTenantAndOrganizationEntityModel {
    taskId: string;
    publicationId: string;
    capabilityId: string;
    executionId: string;
    requestId: string;
    toolName: string;
    idempotencyKey: string;
    inputHash: string;
    subjectType: McpApiKeySubjectType;
    subjectId: string;
    queueJobId?: string | null;
    status: McpTaskStatus;
    statusMessage?: string | null;
    progress?: number | null;
    pollIntervalMs?: number | null;
    inputRequests?: JSONValue | null;
    inputResponses?: JSONValue | null;
    requestPayload?: JSONValue | null;
    resultRef?: JSONValue | null;
    error?: {
        code?: string;
        message: string;
    } | null;
    revision: number;
    expiresAt: Date;
}
