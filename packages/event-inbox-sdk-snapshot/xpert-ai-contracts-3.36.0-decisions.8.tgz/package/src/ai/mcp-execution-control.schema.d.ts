import { z } from 'zod/v3';
/** Negotiated Xpert extension. MCP cancellation acknowledgements are not exit evidence. */
export declare const MCP_EXECUTION_CONTROL_EXTENSION_ID = "ai.xpert/execution-control";
export declare const MCP_EXECUTION_CONTROL_METHOD = "xpert/tasks/control";
/** Additive tools/list metadata for 2026, which removed top-level Tool.execution. */
export declare const mcpExecutionToolDeclarationSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    taskSupport: z.ZodEnum<["required", "optional", "forbidden"]>;
}, "strip", z.ZodTypeAny, {
    version?: 1;
    taskSupport?: "required" | "optional" | "forbidden";
}, {
    version?: 1;
    taskSupport?: "required" | "optional" | "forbidden";
}>;
export declare const mcpOperationIdentitySchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    operationId: z.ZodString;
    generation: z.ZodString;
    inputHash: z.ZodString;
    toolName: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    generation?: string;
    toolName?: string;
    inputHash?: string;
    operationId?: string;
}, {
    version?: 1;
    generation?: string;
    toolName?: string;
    inputHash?: string;
    operationId?: string;
}>;
export type McpOperationIdentity = z.output<typeof mcpOperationIdentitySchema>;
export declare const mcpExecutionControlRequestSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    operationId: z.ZodString;
    generation: z.ZodString;
    inputHash: z.ZodString;
    toolName: z.ZodString;
} & {
    serverId: z.ZodString;
    action: z.ZodEnum<["inspect", "terminate"]>;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    generation?: string;
    toolName?: string;
    inputHash?: string;
    action?: "terminate" | "inspect";
    operationId?: string;
    serverId?: string;
}, {
    version?: 1;
    generation?: string;
    toolName?: string;
    inputHash?: string;
    action?: "terminate" | "inspect";
    operationId?: string;
    serverId?: string;
}>;
export type McpExecutionControlRequest = z.output<typeof mcpExecutionControlRequestSchema>;
export declare const mcpExecutionReceiptSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    serverId: z.ZodString;
    operationId: z.ZodString;
    generation: z.ZodString;
    taskId: z.ZodNullable<z.ZodString>;
    state: z.ZodEnum<["pending", "settled", "unknown"]>;
    intent: z.ZodEnum<["running", "paused", "terminated"]>;
    revision: z.ZodNumber;
    handlerExited: z.ZodBoolean;
    descendantsSettled: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    generation?: string;
    revision?: number;
    taskId?: string;
    operationId?: string;
    state?: "unknown" | "pending" | "settled";
    serverId?: string;
    intent?: "paused" | "running" | "terminated";
    handlerExited?: boolean;
    descendantsSettled?: boolean;
}, {
    version?: 1;
    generation?: string;
    revision?: number;
    taskId?: string;
    operationId?: string;
    state?: "unknown" | "pending" | "settled";
    serverId?: string;
    intent?: "paused" | "running" | "terminated";
    handlerExited?: boolean;
    descendantsSettled?: boolean;
}>;
export type McpExecutionReceipt = z.output<typeof mcpExecutionReceiptSchema>;
export declare const mcpExecutionCapabilitySchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    serverId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    serverId?: string;
}, {
    version?: 1;
    serverId?: string;
}>;
