import type { I18nObject, IconDefinition } from '../types';
import type { XpertProjectTypeConfigurationDefinition } from './project-type-configuration.model';
import type { XpertViewScalar } from '../view-extension/model';
export interface XpertProjectViewSelection {
    viewKey: string;
    selectionId?: string;
    parameters?: Record<string, XpertViewScalar | XpertViewScalar[]>;
}
/** Stable identity, independent of installation ids, labels and plugin versions. */
export interface XpertProjectTypeRef {
    applicationKey: string;
    projectTypeKey: string;
}
export declare const GENERAL_PROJECT_TYPE: XpertProjectTypeRef;
/** File-backed collaborative writing workspace using the ordinary Project lifecycle. */
export declare const SPACE_PROJECT_TYPE: XpertProjectTypeRef;
/** Business-task capacity owned by the Project type's dispatcher, never the Agent runtime. */
export interface XpertProjectTaskConcurrency {
    maxConcurrentTasks: number;
}
export interface XpertProjectTypeDefinition {
    key: string;
    title: string | I18nObject;
    icon?: IconDefinition;
    /** Entity-backed applications enforce this policy in their business preparation/claim services. */
    taskConcurrency?: XpertProjectTaskConcurrency;
    configuration?: XpertProjectTypeConfigurationDefinition;
    /** Entity types delegate creation and lifecycle to their registered provider. */
    binding: {
        kind: 'project';
    } | {
        kind: 'entity';
        providerKey: string;
    };
}
export interface XpertProjectTypeSummary extends XpertProjectTypeRef {
    applicationTitle: string | I18nObject;
    title: string | I18nObject;
    icon?: IconDefinition;
    binding: XpertProjectTypeDefinition['binding'];
    taskConcurrency?: XpertProjectTaskConcurrency;
    configuration?: XpertProjectTypeConfigurationDefinition;
    available: boolean;
}
export interface XpertProjectClassification {
    applicationKey?: string | null;
    projectTypeKey?: string | null;
    applicationInstallationId?: string | null;
    /** Display-only snapshot survives plugin removal; never used for authorization. */
    projectTypeSnapshot?: Pick<XpertProjectTypeSummary, 'applicationTitle' | 'title' | 'binding'> | null;
}
export interface XpertProjectListFilter {
    search?: string;
    applicationKey?: string;
    projectTypeKey?: string;
    unclassified?: boolean;
}
/** Resolved by the host and a trusted provider, never an arbitrary URL. */
export type XpertProjectEntry = {
    kind: 'project';
    projectId?: string;
    projectType: XpertProjectTypeRef;
} | ({
    kind: 'assistant';
    xpertId: string;
    slug: string;
    projectId?: string;
} & XpertProjectViewSelection);
export interface XpertProjectTypeCatalog {
    items: XpertProjectTypeSummary[];
    defaultProjectType?: XpertProjectTypeRef;
}
