import type { JSONSchema4 } from 'json-schema';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { I18nObject } from '../types';
import { DefaultModelRole, LegacyProviderRole } from './default-model-role';
import { TAvatar } from '../types';
import { IXpertToolset } from './xpert-toolset.model';
/**
 * Tools for Xpert
 */
export interface IXpertTool extends IBasePerTenantAndOrganizationEntityModel, XpertToolType {
}
export type XpertToolType = {
    name: string;
    label?: I18nObject | string;
    description?: string;
    avatar?: TAvatar;
    /**
     * @deprecated use disabled
     */
    enabled?: boolean;
    /**
     * Is disabled in toolset
     */
    disabled?: boolean;
    options?: Record<string, any>;
    /**
     * Schema of tool
     */
    schema?: Record<string, any> | TXpertToolEntity | IBuiltinTool;
    /**
     * Default input parameters of tool
     */
    parameters?: Record<string, any>;
    /**
     * Priority role of AI provider
     * @deprecated Use defaultModelRole. Legacy serialized field remains readable.
     */
    aiProviderRole?: LegacyProviderRole;
    defaultModelRole?: DefaultModelRole;
    toolset?: IXpertToolset;
    toolsetId?: string;
    provider?: IBuiltinTool;
};
export type TToolProviderIdentity = {
    name: string;
    author: string;
    label: I18nObject;
    provider: string;
    entity?: string;
};
interface ToolParameterOption {
    value: string;
    label: I18nObject;
}
export declare enum ToolParameterType {
    STRING = "string",
    NUMBER = "number",
    BOOLEAN = "boolean",
    ARRAY = "array",
    SELECT = "select",
    SECRET_INPUT = "secret-input",
    FILE = "file"
}
export declare enum ToolParameterForm {
    SCHEMA = "schema",// should be set while adding tool
    FORM = "form",// should be set before invoking tool
    LLM = "llm"
}
export type TToolParameter = {
    name: string;
    label: I18nObject;
    human_description?: I18nObject;
    placeholder?: I18nObject;
    type: ToolParameterType;
    form: ToolParameterForm;
    llm_description?: string;
    required?: boolean;
    default?: number | string;
    min?: number;
    max?: number;
    options?: ToolParameterOption[];
    items?: {
        type: ToolParameterType;
    };
    /**
     * Is visible for ai tool parameters
     */
    visible?: boolean;
};
export interface ApiToolBundle {
    /**
     * This interface is used to store the schema information of an api based tool,
     * such as the url, the method, the parameters, etc.
     */
    server_url: string;
    method: string;
    summary?: string;
    operation_id?: string;
    /**
     * parameters
     * @deprecated use schema
     */
    parameters?: TToolParameter[];
    schema?: JSONSchema4;
    author: string;
    icon?: string;
    openapi: Record<string, any>;
}
export interface IBuiltinTool {
    identity: TToolProviderIdentity;
    description: {
        human: I18nObject;
        llm: string;
    };
    /**
     * Definition of input parameters (yaml schema)
     */
    parameters?: TToolParameter[];
    /**
     * Schema of tool (zod/json-schema)
     */
    schema?: any;
    /**
     * @deprecated how to use?
     */
    entity?: string;
}
export type TXpertToolEntity = {
    name: string;
    method: 'create' | 'get' | 'query' | 'update' | 'delete';
    entity: string;
    path: string;
    /**
     * Definition of properties
     */
    parameters: Partial<TToolParameter>[];
    description?: string;
};
export declare const TOOL_NAME_REGEX: RegExp;
/**
 *
 * @param tool Tool
 * @param disableToolDefault Is default disable tools
 * @returns Tool is enabled?
 */
export declare function isToolEnabled(tool: IXpertTool, disableToolDefault?: boolean): boolean;
/**
 * Tool is enabled?
 *
 * @deprecated use isToolEnabled
 */
export declare function isEnableTool(tool: IXpertTool, toolset: IXpertToolset): boolean;
export declare function getEnabledTools(toolset: IXpertToolset): IXpertTool[];
export declare function getToolLabel(tool: IXpertTool): I18nObject | string;
export {};
