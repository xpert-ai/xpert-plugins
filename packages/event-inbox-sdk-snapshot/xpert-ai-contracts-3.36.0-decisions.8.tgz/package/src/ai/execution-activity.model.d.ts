import { z } from 'zod/v3';
export declare const codingExecutionViewKey = "platform.coding-execution__execution";
export declare const executionActivityCapabilitiesSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    presentation: z.ZodLiteral<"coding">;
}, "strict", z.ZodTypeAny, {
    version: 1;
    presentation: "coding";
}, {
    version: 1;
    presentation: "coding";
}>;
export type ExecutionActivityCapabilities = z.infer<typeof executionActivityCapabilitiesSchema>;
export declare const executionActivityItemSchema: z.ZodObject<{
    id: z.ZodString;
    occurredAt: z.ZodOptional<z.ZodString>;
    content: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"message">;
        text: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "message";
        text: string;
    }, {
        kind: "message";
        text: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"tool">;
        activityKind: z.ZodOptional<z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>>;
        name: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<["running", "succeeded", "failed", "unknown"]>;
        input: z.ZodOptional<z.ZodString>;
        output: z.ZodOptional<z.ZodString>;
        truncated: z.ZodOptional<z.ZodBoolean>;
        outputRef: z.ZodOptional<z.ZodObject<{
            key: z.ZodString;
            length: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            key: string;
            length: number;
        }, {
            key: string;
            length: number;
        }>>;
        detail: z.ZodOptional<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"command">;
            command: z.ZodString;
            cwd: z.ZodOptional<z.ZodString>;
            exitCode: z.ZodOptional<z.ZodNumber>;
            outputMode: z.ZodLiteral<"merged">;
        }, "strict", z.ZodTypeAny, {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        }, {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"file_change">;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                change: z.ZodEnum<["created", "modified", "deleted", "reported"]>;
                patch: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }, {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        }, {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        }>]>>;
    }, "strict", z.ZodTypeAny, {
        kind: "tool";
        status: "unknown" | "failed" | "running" | "succeeded";
        input?: string | undefined;
        output?: string | undefined;
        activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
        name?: string | undefined;
        truncated?: boolean | undefined;
        outputRef?: {
            key: string;
            length: number;
        } | undefined;
        detail?: {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        } | {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        } | undefined;
    }, {
        kind: "tool";
        status: "unknown" | "failed" | "running" | "succeeded";
        input?: string | undefined;
        output?: string | undefined;
        activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
        name?: string | undefined;
        truncated?: boolean | undefined;
        outputRef?: {
            key: string;
            length: number;
        } | undefined;
        detail?: {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        } | {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        } | undefined;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"diagnostic">;
        code: z.ZodString;
        text: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        code: string;
        kind: "diagnostic";
        text: string;
    }, {
        code: string;
        kind: "diagnostic";
        text: string;
    }>]>;
}, "strict", z.ZodTypeAny, {
    id: string;
    content: {
        kind: "message";
        text: string;
    } | {
        kind: "tool";
        status: "unknown" | "failed" | "running" | "succeeded";
        input?: string | undefined;
        output?: string | undefined;
        activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
        name?: string | undefined;
        truncated?: boolean | undefined;
        outputRef?: {
            key: string;
            length: number;
        } | undefined;
        detail?: {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        } | {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        } | undefined;
    } | {
        code: string;
        kind: "diagnostic";
        text: string;
    };
    occurredAt?: string | undefined;
}, {
    id: string;
    content: {
        kind: "message";
        text: string;
    } | {
        kind: "tool";
        status: "unknown" | "failed" | "running" | "succeeded";
        input?: string | undefined;
        output?: string | undefined;
        activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
        name?: string | undefined;
        truncated?: boolean | undefined;
        outputRef?: {
            key: string;
            length: number;
        } | undefined;
        detail?: {
            type: "command";
            command: string;
            outputMode: "merged";
            cwd?: string | undefined;
            exitCode?: number | undefined;
        } | {
            type: "file_change";
            files: {
                path: string;
                change: "created" | "modified" | "deleted" | "reported";
                patch?: string | undefined;
            }[];
        } | undefined;
    } | {
        code: string;
        kind: "diagnostic";
        text: string;
    };
    occurredAt?: string | undefined;
}>;
export type ExecutionActivityItem = z.infer<typeof executionActivityItemSchema>;
export declare const executionActivityBatchSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        occurredAt: z.ZodOptional<z.ZodString>;
        content: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"message">;
            text: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "message";
            text: string;
        }, {
            kind: "message";
            text: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"tool">;
            activityKind: z.ZodOptional<z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>>;
            name: z.ZodOptional<z.ZodString>;
            status: z.ZodEnum<["running", "succeeded", "failed", "unknown"]>;
            input: z.ZodOptional<z.ZodString>;
            output: z.ZodOptional<z.ZodString>;
            truncated: z.ZodOptional<z.ZodBoolean>;
            outputRef: z.ZodOptional<z.ZodObject<{
                key: z.ZodString;
                length: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                length: number;
            }, {
                key: string;
                length: number;
            }>>;
            detail: z.ZodOptional<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
                type: z.ZodLiteral<"command">;
                command: z.ZodString;
                cwd: z.ZodOptional<z.ZodString>;
                exitCode: z.ZodOptional<z.ZodNumber>;
                outputMode: z.ZodLiteral<"merged">;
            }, "strict", z.ZodTypeAny, {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            }, {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            }>, z.ZodObject<{
                type: z.ZodLiteral<"file_change">;
                files: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    change: z.ZodEnum<["created", "modified", "deleted", "reported"]>;
                    patch: z.ZodOptional<z.ZodString>;
                }, "strict", z.ZodTypeAny, {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }, {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }>, "many">;
            }, "strict", z.ZodTypeAny, {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            }, {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            }>]>>;
        }, "strict", z.ZodTypeAny, {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        }, {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"diagnostic">;
            code: z.ZodString;
            text: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            code: string;
            kind: "diagnostic";
            text: string;
        }, {
            code: string;
            kind: "diagnostic";
            text: string;
        }>]>;
    }, "strict", z.ZodTypeAny, {
        id: string;
        content: {
            kind: "message";
            text: string;
        } | {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        } | {
            code: string;
            kind: "diagnostic";
            text: string;
        };
        occurredAt?: string | undefined;
    }, {
        id: string;
        content: {
            kind: "message";
            text: string;
        } | {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        } | {
            code: string;
            kind: "diagnostic";
            text: string;
        };
        occurredAt?: string | undefined;
    }>, "many">;
    sourceCursor: z.ZodOptional<z.ZodString>;
    expectedSourceCursor: z.ZodOptional<z.ZodString>;
    complete: z.ZodOptional<z.ZodBoolean>;
    gaps: z.ZodOptional<z.ZodArray<z.ZodEnum<["source_truncated", "storage_unavailable", "capture_limit", "interrupted", "source_lost"]>, "many">>;
}, "strict", z.ZodTypeAny, {
    items: {
        id: string;
        content: {
            kind: "message";
            text: string;
        } | {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        } | {
            code: string;
            kind: "diagnostic";
            text: string;
        };
        occurredAt?: string | undefined;
    }[];
    sourceCursor?: string | undefined;
    expectedSourceCursor?: string | undefined;
    complete?: boolean | undefined;
    gaps?: ("interrupted" | "source_truncated" | "storage_unavailable" | "capture_limit" | "source_lost")[] | undefined;
}, {
    items: {
        id: string;
        content: {
            kind: "message";
            text: string;
        } | {
            kind: "tool";
            status: "unknown" | "failed" | "running" | "succeeded";
            input?: string | undefined;
            output?: string | undefined;
            activityKind?: "task" | "explore" | "change" | "verify" | "answer" | "other" | undefined;
            name?: string | undefined;
            truncated?: boolean | undefined;
            outputRef?: {
                key: string;
                length: number;
            } | undefined;
            detail?: {
                type: "command";
                command: string;
                outputMode: "merged";
                cwd?: string | undefined;
                exitCode?: number | undefined;
            } | {
                type: "file_change";
                files: {
                    path: string;
                    change: "created" | "modified" | "deleted" | "reported";
                    patch?: string | undefined;
                }[];
            } | undefined;
        } | {
            code: string;
            kind: "diagnostic";
            text: string;
        };
        occurredAt?: string | undefined;
    }[];
    sourceCursor?: string | undefined;
    expectedSourceCursor?: string | undefined;
    complete?: boolean | undefined;
    gaps?: ("interrupted" | "source_truncated" | "storage_unavailable" | "capture_limit" | "source_lost")[] | undefined;
}>;
export type ExecutionActivityBatch = z.infer<typeof executionActivityBatchSchema>;
export type ExecutionActivityGap = NonNullable<ExecutionActivityBatch['gaps']>[number];
export interface ExecutionActivityCheckpoint {
    sourceCursor?: string;
    seq: number;
}
export interface ExecutionActivityPage {
    items: Array<ExecutionActivityItem & {
        seq: number;
        firstSeq: number;
        observedAt: string;
    }>;
    nextCursor: number;
    hasMore: boolean;
    state: 'not_recorded' | 'recording' | 'closed' | 'expired';
    gaps: ExecutionActivityGap[];
}
