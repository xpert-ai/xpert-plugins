import type { DocumentTextParserConfig, DocumentSheetParserConfig } from './knowledge-doc.model';
import type { KnowledgebaseParserConfig } from './knowledgebase.model';
import type { IKnowledgeDocumentChunk, IDocChunkMetadata } from './knowledge-doc-chunk.model';
import type { KnowledgeChunkingDecision, KnowledgeChunkLanguageDecision } from './knowledge-chunking.model';
export interface KnowledgeChunkPreviewInput {
    text: string;
    type: 'txt' | 'md';
    parserConfig: KnowledgebaseParserConfig;
}
export interface KnowledgeChunkPreviewResult {
    chunks: IKnowledgeDocumentChunk<IDocChunkMetadata>[];
    decisions?: KnowledgeChunkingDecision[];
    languages?: KnowledgeChunkLanguageDecision[];
}
/** Only copy configured defaults; do not turn built-in defaults into document overrides. */
export declare function knowledgebaseDocumentParserDefaults(config?: KnowledgebaseParserConfig | null, documentType?: string): DocumentTextParserConfig & Partial<DocumentSheetParserConfig>;
/** Arrays are the canonical ordered format; retain the plugin's legacy comma syntax. */
export declare function decodeKnowledgeSeparators(value?: string | string[]): string[];
