import { IPoint } from '../types';
import { IXpertAgent } from './xpert-agent.model';
import { IXpert, TXpertGraph, TXpertTeamConnection, TXpertTeamDraft, TXpertTeamNode } from './xpert.model';
export declare function omitXpertRelations(xpert: Partial<IXpert>): {
    environmentId?: string | null;
    workspaceId?: string;
    workspace?: import("./xpert-workspace.model").IXpertWorkspace;
    publishAt?: Date;
    deletedAt?: Date;
    organizationId?: string;
    organization?: import("..").IOrganization;
    tenantId?: string;
    tenant?: import("..").ITenant;
    id?: import("../types").ID;
    createdById?: import("../types").ID;
    createdBy?: import("..").IUser;
    updatedById?: import("../types").ID;
    updatedBy?: import("..").IUser;
    createdAt?: Date;
    updatedAt?: Date;
    slug?: string;
    name?: string;
    type?: import("./xpert.model").XpertTypeEnum;
    title?: string;
    titleCN?: string;
    description?: string;
    workspaceDataScope?: import("./xpert.model").XpertWorkspaceDataScope;
    active?: boolean;
    avatar?: import("../types").TAvatar;
    starters?: string[];
    options?: import("./xpert.model").TXpertOptions;
    agentConfig?: import("./xpert.model").TXpertAgentConfig;
    summarize?: import("./xpert.model").TSummarize;
    features?: import("./xpert.model").TXpertFeatures;
    commandProfile?: import("./prompt-workflow.model").TXpertCommandProfile;
    marketplace?: import("./xpert-marketplace.model").TXpertMarketplaceProfile;
    businessAreaId?: string | null;
    businessArea?: import("..").IBusinessArea | null;
    version?: string;
    latest?: boolean;
    releaseNotes?: string;
    exportedTemplate?: import("./xpert.model").TXpertExportedTemplate | null;
    graph?: TXpertGraph;
    api?: import("./xpert.model").TChatApi;
    app?: import("./xpert.model").TChatApp;
    userId?: string;
    user?: import("..").IUser;
    copilotModel?: import("./copilot-model.model").ICopilotModel;
    copilotModelId?: string;
    tags?: import("..").ITag[];
};
/**
 * Figure out latest xpert or draft xpert.
 *
 * @param xpert
 * @param isDraft Is draft
 * @returns
 */
export declare function figureOutXpert(xpert: IXpert, isDraft: boolean): Partial<IXpert>;
export declare function resolveRuntimeXpert(xpert: IXpert, isDraft: boolean): IXpert;
export declare function resolveDraftRuntimeGraph(xpert: IXpert, draft: TXpertTeamDraft): TXpertGraph;
export declare function resolveDraftPrimaryAgent(xpert: IXpert, draft: TXpertTeamDraft, graph: TXpertGraph): IXpertAgent | undefined;
export declare function xpertLabel(agent: Partial<IXpert>): string;
export declare function createXpertGraph(xpert: IXpert, position: IPoint): {
    nodes: TXpertTeamNode[];
    size: {
        width: number;
        height: number;
    };
    connections: TXpertTeamConnection[];
};
export declare function locateNodes(nodes: TXpertTeamNode[], position: IPoint): {
    size: {
        width: number;
        height: number;
    };
    nodes: TXpertTeamNode[];
};
/**
 * Create all nodes of xpert and it's area size
 *
 * @param xpert
 * @returns
 */
export declare function createXpertNodes(xpert: IXpert, position: IPoint): {
    nodes: TXpertTeamNode[];
    size: {
        width: number;
        height: number;
    };
};
export declare function createAgentConnections(agent: IXpertAgent, collaborators: IXpert[]): any[];
export declare function replaceAgentInDraft(draft: TXpertTeamDraft, sourceKey: string, agent: Partial<IXpertAgent>, options?: {
    requireNode?: boolean;
}): TXpertTeamDraft;
