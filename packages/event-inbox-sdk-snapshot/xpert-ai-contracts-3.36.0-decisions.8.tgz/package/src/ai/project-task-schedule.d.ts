/** Minimal, browser-safe scheduling contract, independent of server or Agent contracts. */
export interface ProjectTaskScheduleNode {
    id: string;
    status: string;
    kind: 'task' | 'summary' | 'milestone';
    parentTaskId: string | null;
    predecessorIds: string[];
    plannedStartAt: string | null;
    plannedEndAt: string | null;
    estimatedDurationMs: number | null;
    actualStartAt: string | null;
    actualEndAt: string | null;
}
export interface ProjectTaskForecast {
    taskId: string;
    startAt: string | null;
    endAt: string | null;
    affected: boolean;
    critical: boolean;
}
/** Tree containment and finish-to-start dependencies are separate acyclic graphs. */
export declare function validateProjectTaskGraph(tasks: readonly ProjectTaskScheduleNode[]): void;
/** Unknown estimates stay unknown. Summary rows never contribute another duration. */
export declare function forecastProjectTasks(tasks: readonly ProjectTaskScheduleNode[], changedId?: string): ProjectTaskForecast[];
