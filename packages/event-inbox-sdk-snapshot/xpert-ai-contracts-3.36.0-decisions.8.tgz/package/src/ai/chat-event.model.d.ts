import type { TChatEventMessage, TFollowUpConsumedEvent, TThreadGoalClearedEvent, TThreadGoalUpdatedEvent } from '@xpert-ai/chatkit-types';
import type { IThreadGoal } from './thread-goal.model';
export type { TThreadGoalClearedEvent, TThreadGoalUpdatedEvent } from '@xpert-ai/chatkit-types';
export declare const CHAT_EVENT_TYPE_FOLLOW_UP_CONSUMED: "follow_up_consumed";
export declare const CHAT_EVENT_TYPE_THREAD_CONTEXT_USAGE: "thread_context_usage";
export declare const CHAT_EVENT_TYPE_CONVERSATION_TITLE_SUMMARY: "conversation_title_summary";
export declare const CHAT_EVENT_TYPE_THREAD_GOAL_UPDATED: "thread_goal_updated";
export declare const CHAT_EVENT_TYPE_THREAD_GOAL_CLEARED: "thread_goal_cleared";
export type TConversationTitleSummaryEvent = TChatEventMessage & {
    id?: string;
    type: typeof CHAT_EVENT_TYPE_CONVERSATION_TITLE_SUMMARY;
};
export declare function createConversationTitleSummaryEvent(event: Omit<TConversationTitleSummaryEvent, 'type'>): TConversationTitleSummaryEvent;
export declare function createFollowUpConsumedEvent(event: Omit<TFollowUpConsumedEvent, 'type'>): TFollowUpConsumedEvent;
export declare function createThreadGoalUpdatedEvent(goal: IThreadGoal, updatedAt?: string | Date): TThreadGoalUpdatedEvent;
export declare function createThreadGoalClearedEvent(event: Omit<TThreadGoalClearedEvent, 'type' | 'updatedAt'> & {
    updatedAt?: string | Date;
}): TThreadGoalClearedEvent;
