import type { ContextCompressionReason } from '@xpert-ai/chatkit-types';
import type { I18nText } from '../i18n.model';
export declare const CONTEXT_COMPRESSION_COMPONENT_TYPE = "context-compression";
export type TContextCompressionComponentStatus = 'running' | 'success' | 'fail';
export type TContextCompressionComponentReason = ContextCompressionReason;
export type TContextCompressionComponentData = {
    category: 'Tool';
    type: typeof CONTEXT_COMPRESSION_COMPONENT_TYPE;
    status: TContextCompressionComponentStatus;
    reason?: TContextCompressionComponentReason;
    title?: I18nText;
    message?: I18nText;
    summary?: string;
    error?: I18nText;
    created_date?: string | Date | null;
    end_date?: string | Date | null;
};
export declare function isContextCompressionComponentData(value: unknown): value is TContextCompressionComponentData;
