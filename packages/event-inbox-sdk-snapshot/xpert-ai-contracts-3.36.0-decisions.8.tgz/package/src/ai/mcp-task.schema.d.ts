import { z } from 'zod';
export declare const mcpTaskStartResultSchema: z.ZodObject<{
    resultType: z.ZodLiteral<"task">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    content: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    resultType: z.ZodLiteral<"task">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    content: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    resultType: z.ZodLiteral<"task">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    content: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
}, z.ZodTypeAny, "passthrough">>;
export declare const mcpTaskResultSchema: z.ZodObject<{
    resultType: z.ZodLiteral<"complete">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    inputRequests: z.ZodOptional<z.ZodUnknown>;
    result: z.ZodOptional<z.ZodUnknown>;
    error: z.ZodOptional<z.ZodUnknown>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    resultType: z.ZodLiteral<"complete">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    inputRequests: z.ZodOptional<z.ZodUnknown>;
    result: z.ZodOptional<z.ZodUnknown>;
    error: z.ZodOptional<z.ZodUnknown>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    resultType: z.ZodLiteral<"complete">;
    taskId: z.ZodString;
    status: z.ZodEnum<["working", "input_required", "completed", "failed", "cancelled"]>;
    statusMessage: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    lastUpdatedAt: z.ZodString;
    ttlMs: z.ZodNullable<z.ZodNumber>;
    pollIntervalMs: z.ZodOptional<z.ZodNumber>;
    progress: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    inputRequests: z.ZodOptional<z.ZodUnknown>;
    result: z.ZodOptional<z.ZodUnknown>;
    error: z.ZodOptional<z.ZodUnknown>;
}, z.ZodTypeAny, "passthrough">>;
export declare const mcpTaskAcknowledgementSchema: z.ZodObject<{
    resultType: z.ZodLiteral<"complete">;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    resultType: z.ZodLiteral<"complete">;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    resultType: z.ZodLiteral<"complete">;
}, z.ZodTypeAny, "passthrough">>;
export type McpConsumerTaskStart = z.infer<typeof mcpTaskStartResultSchema>;
export type McpConsumerTask = z.infer<typeof mcpTaskResultSchema>;
export type McpConsumerTaskAcknowledgement = z.infer<typeof mcpTaskAcknowledgementSchema>;
