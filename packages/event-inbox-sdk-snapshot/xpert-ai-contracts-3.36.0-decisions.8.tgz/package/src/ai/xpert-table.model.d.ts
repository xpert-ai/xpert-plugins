import { IWorkflowNode, WorkflowNodeTypeEnum } from './xpert-workflow.model';
import { IBasePerWorkspaceEntityModel } from './xpert-workspace.model';
/**
 * Table status
 */
export declare enum XpertTableStatus {
    DRAFT = "draft",
    READY = "ready",
    PENDING_ACTIVATION = "pendingActivation",
    ACTIVE = "active",
    NEEDS_MIGRATION = "needsMigration",
    DEPRECATED = "deprecated",
    ERROR = "error"
}
/**
 * Custom Table for Xpert
 */
export interface IXpertTable extends IBasePerWorkspaceEntityModel, TXpertTable {
}
export type TXpertTable = {
    name: string;
    description?: string;
    database?: string;
    schema?: string;
    columns?: TXpertTableColumn[];
    status: XpertTableStatus;
    version?: number;
    activatedAt?: Date;
    message?: string;
};
/**
 * Union type for all supported database types
 * Used when database type is not yet determined or needs to support multiple databases
 */
export type DatabaseDataType = string;
export type TXpertTableColumn = {
    name: string;
    type: DatabaseDataType;
    label?: string;
    required?: boolean;
    isPrimaryKey?: boolean;
    isUnique?: boolean;
    autoIncrement?: boolean;
    defaultValue?: string;
    length?: number;
    precision?: number;
    scale?: number;
    enumValues?: string[];
    setValues?: string[];
};
export interface IWorkflowNodeDBOperation extends IWorkflowNode {
    tableId: string;
}
export interface IWFNDBInsert extends IWorkflowNodeDBOperation {
    type: WorkflowNodeTypeEnum.DB_INSERT;
    columns?: Record<string, {
        type: DatabaseDataType;
        value?: any;
        valueSelector?: string;
    }>;
}
export declare function genXpertDBInsertKey(): string;
export interface IWFNDBUpdate extends IWorkflowNodeDBOperation {
    type: WorkflowNodeTypeEnum.DB_UPDATE;
    columns?: Record<string, {
        type: DatabaseDataType;
        value?: any;
        valueSelector?: string;
    }>;
}
export declare function genXpertDBUpdateKey(): string;
export interface IWFNDBDelete extends IWorkflowNodeDBOperation {
    type: WorkflowNodeTypeEnum.DB_DELETE;
}
export declare function genXpertDBDeleteKey(): string;
export interface IWFNDBQuery extends IWorkflowNodeDBOperation {
    type: WorkflowNodeTypeEnum.DB_QUERY;
}
export declare function genXpertDBQueryKey(): string;
export interface IWFNDBSql extends IWorkflowNodeDBOperation {
    type: WorkflowNodeTypeEnum.DB_SQL;
    sqlTemplate?: string;
}
export declare function genXpertDBSqlKey(): string;
