import { ToolCall as LToolCall } from '@langchain/core/messages/tool';
import { RunnableToolLike } from '@langchain/core/runnables';
import { StructuredToolInterface } from '@langchain/core/tools';
import { ITag } from '../tag-entity.model';
import { IUser, LanguagesEnum } from '../user.model';
import { IUserGroup } from '../user-group.model';
import { ICopilotModel, TCopilotModel } from './copilot-model.model';
import { IKnowledgebase, KnowledgeRetrievalMode, TKBFusionConfig, TKBRecallParams } from './knowledgebase.model';
import { ChecklistItem, I18nObject, IPoint, ISize, TAvatar } from '../types';
import { IXpertAgent } from './xpert-agent.model';
import { IXpertToolset } from './xpert-toolset.model';
import { IBasePerWorkspaceEntityModel } from './xpert-workspace.model';
import { IIntegration } from '../integration.model';
import { TChatCheckpointReference, TChatFrom } from './chat.model';
import { IWorkflowNode, TVariableAssigner, VariableOperationEnum } from './xpert-workflow.model';
import { IEnvironment } from './environment.model';
import { TXpertCommandProfile } from './prompt-workflow.model';
import type { TXpertMarketplaceProfile } from './xpert-marketplace.model';
import type { KnowledgeFilterNode } from './knowledge-filter.model';
import type { IBusinessArea } from '../business-area.model';
export type ToolCall = LToolCall;
export declare enum XpertTypeEnum {
    /**
     * Chat Agents
     */
    Agent = "agent",
    /**
     * @deprecated use Chatkit with agent instead.
     */
    Copilot = "copilot",
    /**
     * Knowledge Workflow
     */
    Knowledge = "knowledge"
}
export type TXpertSandboxFeature = {
    enabled: boolean;
    provider?: string;
};
export type TXpertTitleFeature = {
    enabled: boolean;
    instruction?: string;
};
/** A short display label can accompany the complete message sent by a starter. */
export type TXpertOpenerQuestion = string | {
    label: string;
    prompt: string;
};
export declare function toXpertOpenerPrompt(question: TXpertOpenerQuestion): {
    label: string;
    prompt: string;
};
export type TXpertFeatures = {
    realtimeVoice?: import('./realtime-voice.model').RealtimeVoiceFeature;
    /** Generate start-screen questions from recurring intents in conversation history. */
    frequentQuestions?: {
        enabled: boolean;
    };
    opener: {
        enabled: boolean;
        message: string;
        questions: TXpertOpenerQuestion[];
    };
    suggestion: {
        enabled: boolean;
        prompt: string;
    };
    textToSpeech: {
        enabled: boolean;
        copilotModel?: TCopilotModel;
    };
    speechToText: {
        enabled: boolean;
        copilotModel?: TCopilotModel;
    };
    /**
     * File upload feature
     */
    attachment?: TXpertAttachment;
    /**
     * Sandbox feature
     */
    sandbox?: TXpertSandboxFeature;
    /**
     * Conversation title generation feature
     */
    title?: TXpertTitleFeature;
};
export type TXpertFeatureKey = keyof TXpertFeatures;
export type TXpertExportedTemplate = {
    id: string;
    filePath: string;
    exportedAt: string;
    isDraft: boolean;
};
export type XpertFrequentQuestionsRequest = {
    locale?: string | null;
    windowDays?: number | null;
    conversationLimit?: number | null;
    questionCount?: number | null;
    forceRefresh?: boolean | null;
};
export type XpertFrequentQuestionsSample = {
    windowDays: number;
    conversationLimit: number;
    questionCount: number;
    conversationCount: number;
    messageCount: number;
    since: string;
    until: string;
};
export type XpertFrequentQuestionsResponse = {
    xpertId: string;
    organizationId: string | null;
    locale: string;
    questions: string[];
    generatedAt: string;
    expiresAt: string;
    cached: boolean;
    sample: XpertFrequentQuestionsSample;
};
export type TXpert = {
    /**
     * Unique slug identifier, generated from name
     */
    slug: string;
    /**
     * Expert name
     */
    name: string;
    /**
     * Expert type
     */
    type: XpertTypeEnum;
    title?: string;
    /**
     * @deprecated use title
     */
    titleCN?: string;
    /**
     * Expert description
     */
    description?: string;
    /**
     * Ownership of non-Project runtime files. This is selected when the Xpert is
     * created and is immutable afterwards. Missing legacy values mean `shared`.
     */
    workspaceDataScope?: XpertWorkspaceDataScope;
    /**
     * Is active
     */
    active?: boolean;
    /**
     * Avatar Object
     */
    avatar?: TAvatar;
    /**
     * Conversation starters
     */
    starters?: string[];
    /**
     * More configuration
     */
    options?: TXpertOptions;
    /**
     * Config for every agent
     */
    agentConfig?: TXpertAgentConfig;
    /**
     * Config of summarize past conversations
     */
    summarize?: TSummarize;
    features?: TXpertFeatures;
    commandProfile?: TXpertCommandProfile;
    marketplace?: TXpertMarketplaceProfile;
    /**
     * Organization business taxonomy used to group this assistant in product menus.
     * This is independent from marketplace business categories.
     */
    businessAreaId?: string | null;
    businessArea?: IBusinessArea | null;
    /**
     * Version of role: '1' '2' '2.1' '2.2'...
     */
    version?: string;
    /**
     * Is latest version
     */
    latest?: boolean;
    /**
     * Release notes
     */
    releaseNotes?: string;
    exportedTemplate?: TXpertExportedTemplate | null;
    /**
     * Draft on current version
     */
    draft?: TXpertTeamDraft;
    /**
     * Published graph
     */
    graph?: TXpertGraph;
    api?: TChatApi;
    app?: TChatApp;
    userId?: string;
    user?: IUser;
    /**
     * Primary agent for this expert
     */
    agent?: IXpertAgent;
    copilotModel?: ICopilotModel;
    copilotModelId?: string;
    agents?: IXpertAgent[];
    /**
     * Sub-experts, Digital experts who perform specific tasks, focus on completing the assigned work
     */
    executors?: IXpert[];
    /**
     * The task coordinator who called this expert
     */
    leaders?: IXpert[];
    knowledgebases?: IKnowledgebase[];
    toolsets?: IXpertToolset[];
    /**
     * User groups that are allowed to use this published digital expert.
     */
    userGroups?: IUserGroup[];
    /**
     * Integrations for this xpert
     */
    integrations?: IIntegration[];
    tags?: ITag[];
};
export type XpertWorkspaceDataScope = 'shared' | 'user';
export declare const DEFAULT_XPERT_WORKSPACE_DATA_SCOPE: XpertWorkspaceDataScope;
/**
 * Digital Expert
 */
export interface IXpert extends IBasePerWorkspaceEntityModel, TXpert {
    environmentId?: string | null;
    environment?: IEnvironment;
    /**
     * When type is 'knowledge', it must binding a knowledgebase
     */
    knowledgebase?: IKnowledgebase;
}
export interface IXpertPrincipalReference {
    id: string;
    name: string;
    title?: string;
    organizationName?: string | null;
    tenantName?: string | null;
    workspaceName?: string | null;
}
export declare enum XpertWorkbenchInitialLayoutEnum {
    TwoColumns = "two-columns",
    OverlayDialog = "overlay-dialog",
    ChatkitMaximized = "chatkit-maximized",
    WorkbenchMaximized = "workbench-maximized"
}
export type TXpertWorkbenchOptions = {
    /**
     * Initial layout used before this user has a saved Workbench layout preference.
     */
    initialLayout?: XpertWorkbenchInitialLayoutEnum;
    /** Public extension view key selected when the Workbench first loads. */
    defaultViewKey?: string;
};
/**
 * Stable lineage for an Xpert created or updated from an Assistant template.
 * `templateId` is the canonical lookup key. Plugin templates use
 * `<plugin package>:<template key>` so a later sync resolves the same provider.
 */
export type TXpertTemplateSource = {
    /** Portable section hashes at installation/update, used for three-way conflict detection. */
    baseline?: Partial<Record<import('./template-lifecycle.model').TemplateUpgradeSection, string>>;
    manifest?: import('./template-manifest.model').TemplateManifest;
    dependencyLocks?: import('./template-manifest.model').TemplateDependencyLock[];
    templateId: string;
    templateKey: string;
    pluginName?: string;
    pluginDisplayName?: string;
    source?: 'builtin' | 'plugin' | string;
    installedAt?: string;
    lastSyncedAt?: string;
    releaseNotes?: string;
    locale?: string;
    pluginVersion?: string;
    contentHash?: string;
};
export type TXpertTemplateSyncResult = {
    xpertId: string;
    templateSource: TXpertTemplateSource;
    templateTitle: string;
    releaseNotes?: string;
};
export type TXpertDataXpertOptions = {
    /** Keep a group-restricted publication closed if its last assigned group is deleted. */
    requireUserGroup?: boolean;
    managedBy?: string;
    templateKey?: string;
    requiredPlugin?: string;
    requiredPlugins?: string[];
    [key: string]: unknown;
};
export type TXpertOptions = {
    /** Server-owned activation checkpoint; excluded from reusable template exports/imports. */
    pendingPublication?: {
        version: string;
        previousGraph?: TXpertGraph;
    };
    operationPolicy?: import('./assistant-template-setup.model').AssistantOperationPolicy;
    templateDefinition?: import('./assistant-template.model').AssistantTemplateMetadata;
    templateDependencyLocks?: import('./template-installation.model').TemplateDependencyLock[];
    /** Default ChatKit message display for this Assistant. Omit to inherit the host application's default. */
    messagePresentation?: {
        mode?: 'transcript' | 'bubbles';
    };
    assistantCapabilities?: import('./assistant-configuration.model').AssistantCapabilityState;
    /** Runtime-selectable Primary Agent models. The configured Primary model is added automatically. */
    modelSelection?: {
        /** Additional LLM models users may select. */
        allowedModels: TCopilotModel[];
    };
    /** Declares how an Assistant resolves the workspace used by files and Agent runs. */
    workspaceScope?: {
        /** Require an explicit Project, or prefer one while preserving the legacy fallback. */
        mode: 'project-required' | 'project-preferred';
        /** Create on first send, or defer creation until a human confirms the pending setup App. */
        onMissing?: 'create' | 'confirm';
        /** Explicit application context for discovery and governed Project creation. */
        projectType?: import('./xpert-project-type.model').XpertProjectTypeRef;
    };
    /** Legacy template key retained for existing plugin-authored DSL files. */
    templateKey?: string;
    /** Legacy Agentic App descriptor retained for backward-compatible source discovery. */
    dataXpert?: TXpertDataXpertOptions;
    /** Canonical source used by Studio's update-from-template operation. */
    templateSource?: TXpertTemplateSource;
    bootstrap?: {
        source: 'template';
        templateKey: string;
        workspaceKind: 'org-default';
    };
    workbench?: TXpertWorkbenchOptions;
    knowledge?: Record<string, {
        position?: IPoint;
        size?: ISize;
    }>;
    toolset?: Record<string, {
        position?: IPoint;
        size?: ISize;
    }>;
    agent?: Record<string, {
        position?: IPoint;
        size?: ISize;
    }>;
    workflow?: Record<string, {
        position?: IPoint;
        size?: ISize;
    }>;
    xpert?: Record<string, {
        position?: IPoint;
        size?: ISize;
    }>;
    position?: IPoint;
    scale?: number;
};
/**
 * Config for Agent execution (Langgraph.js)
 */
export declare const DEFAULT_XPERT_AGENT_RECURSION_LIMIT = 1000;
export type TXpertAgentConfig = {
    /**
     * Maximum number of times a call can recurse. If not provided, defaults to 1000.
     */
    recursionLimit?: number;
    /**
     * @deprecated Silently ignored. LangGraph.js can drop queued tasks when set to 1
     * (langchain-ai/langgraphjs#2656). Retained for plugin and imported-template compatibility;
     * Assistant execution uses LangGraph's default scheduler without this option.
     */
    maxConcurrency?: number;
    /**
     * Timeout for this call in milliseconds.
     */
    timeout?: number;
    /**
     * Sensitive tools and agents
     */
    interruptBefore?: string[];
    /** Pause after these tools finish, before the next model turn. Resume never reruns the tool. */
    interruptAfter?: string[];
    /**
     * End nodes
     */
    endNodes?: string[];
    /**
     * Custom variables of graph state
     */
    stateVariables?: TStateVariable[];
    /**
     * Custom input parameters should be consistent with the start node or primary agent parameters.
     */
    parameters?: TXpertParameter[];
    /**
     * @deprecated use memories in tools
     */
    toolsMemory?: Record<string, TVariableAssigner[]>;
    /**
     * Disable agent's output
     * @deprecated use `mute` instead
     */
    disableOutputs?: string[];
    /**
     * Mute nodes in the graph of agents: filter messages by tags of stream events
     */
    mute?: string[][];
    /**
     * Recall knowledge params
     */
    recalls?: Record<string, TKBRecallParams>;
    /**
     * Retrieval params for every knowledgebase
     */
    retrievals?: Record<string, TKBRetrievalSettings>;
    tools?: Record<string, {
        /**
         * Memory assigner for tool's results. (save result of tool call into state variable)
         */
        memories?: TVariableAssigner[];
        timeout?: number;
        /**
         * Custom description for the tool
         */
        description?: string;
        parameters?: Record<string, any>;
    }>;
};
export declare function getXpertAgentRecursionLimit(agentConfig?: {
    recursionLimit?: number | null;
} | null): number;
type AgentConfigInput = {
    recursionLimit?: number | null;
    maxConcurrency?: unknown;
};
export declare function normalizeXpertAgentConfig(): {
    recursionLimit: number;
};
export declare function normalizeXpertAgentConfig<T extends AgentConfigInput>(agentConfig: T): Omit<T, 'recursionLimit' | 'maxConcurrency'> & {
    recursionLimit: number;
};
export type TStateVariableType = XpertParameterTypeEnum | 'object' | 'array[string]' | 'array[number]' | 'array[object]';
/**
 */
export type TStateVariable<ValueType = any, UpdateType = ValueType> = TXpertParameter & {
    type: TStateVariableType;
    default?: any;
    reducer?: (a: ValueType, b: UpdateType) => ValueType;
    operation?: VariableOperationEnum;
};
/**
 * Config for summarizing past conversations
 */
export type TSummarize = {
    enabled?: boolean;
    /**
     * The system prompt guide how to summarize the conversation
     */
    prompt?: string;
    /**
     * The maximum number of tolerated messages, otherwise it will be summarized.
     * Should be greater than the number of retained messages
     */
    maxMessages?: number;
    /**
     * Number of retained messages
     */
    retainMessages?: number;
};
export type TXpertAttachmentType = 'document' | 'image' | 'audio' | 'video' | 'others';
export type TXpertAttachment = {
    enabled?: boolean;
    type?: 'upload' | 'url' | 'all';
    maxNum?: number;
    fileTypes?: Array<TXpertAttachmentType>;
};
export declare enum XpertParameterTypeEnum {
    /**
     * @deprecated use string
     */
    TEXT = "text",
    /**
     * @deprecated use string
     */
    PARAGRAPH = "paragraph",
    STRING = "string",
    NUMBER = "number",
    OBJECT = "object",
    SELECT = "select",
    FILE = "file",
    ARRAY_STRING = "array[string]",
    ARRAY_NUMBER = "array[number]",
    ARRAY = "array[object]",
    ARRAY_FILE = "array[file]",
    ARRAY_DOCUMENT = "array[document]",
    ARRAY_MESSAGE = "array[message]",
    BOOLEAN = "boolean",
    SECRET = "secret"
}
export type TXpertParameter = {
    type: XpertParameterTypeEnum;
    name: string;
    /**
     * @deprecated use description and name only
     */
    title?: string;
    description?: string | I18nObject;
    optional?: boolean;
    default?: any;
    maximum?: number;
    options?: string[];
    item?: TXpertParameter[];
};
export type TChatApp = {
    enabled?: boolean;
    public?: boolean;
    channels?: Partial<Record<TEnterpriseH5Platform, TEnterpriseH5ChannelConfig>>;
};
export declare const ENTERPRISE_H5_PLATFORMS: readonly ["dingtalk"];
/** Allowlisted enterprise platforms that can host an Xpert ChatKit application. */
export type TEnterpriseH5Platform = (typeof ENTERPRISE_H5_PLATFORMS)[number];
export declare function isEnterpriseH5Platform(value: unknown): value is TEnterpriseH5Platform;
/** Per-platform publishing configuration for an enterprise H5 ChatKit channel. */
export type TEnterpriseH5ChannelConfig = {
    enabled?: boolean;
    integrationId?: string;
};
/** Short-lived proof supplied by an enterprise H5 client for identity exchange. */
export type TEnterpriseH5IdentityGrant = {
    type: 'authorization_code';
    code: string;
};
export type TChatApi = {
    disabled?: boolean;
};
export type TXpertGraph = {
    nodes: TXpertTeamNode[];
    connections: TXpertTeamConnection[];
};
export type TXpertTeamDraft = TXpertGraph & {
    template?: import('./assistant-template.model').AssistantTemplateMetadata;
    team: Partial<IXpert>;
    savedAt?: Date;
    checklist?: ChecklistItem[];
};
export type TXpertTeamNodeType = 'agent' | 'knowledge' | 'toolset' | 'xpert' | 'workflow';
export type TXpertTeamNodeBase = {
    key: string;
    position: IRect;
    size?: ISize;
    hash?: string;
    parentId?: string;
    readonly?: boolean;
};
/** type -> entity + extra props */
export type TXpertTeamNodeSpec = {
    agent: {
        entity: IXpertAgent;
    };
    knowledge: {
        entity: IKnowledgebase;
    };
    toolset: {
        entity: IXpertToolset;
    };
    xpert: {
        entity: IXpert;
        nodes?: TXpertTeamNode[];
        connections?: TXpertTeamConnection[];
        expanded?: boolean;
    };
    workflow: {
        entity: IWorkflowNode;
    };
};
/** If you want TXpertTeamNodeType always match spec keys */
export type TXpertTeamNodeType2 = keyof TXpertTeamNodeSpec;
export type TXpertTeamNode<T extends TXpertTeamNodeType = TXpertTeamNodeType> = T extends TXpertTeamNodeType ? TXpertTeamNodeBase & {
    type: T;
} & TXpertTeamNodeSpec[T] : never;
export type NodeOf<T extends keyof TXpertTeamNodeSpec> = TXpertTeamNode<T>;
export type NodeEntity<T extends keyof TXpertTeamNodeSpec> = TXpertTeamNodeSpec[T]['entity'];
export type AnyNodeEntity = NodeEntity<keyof TXpertTeamNodeSpec>;
export interface IRect extends IPoint, Partial<ISize> {
    gravityCenter?: IPoint;
}
export type TXpertTeamGroup = {
    id: string;
    title: string;
    position: IPoint;
    size?: ISize;
    parentId?: string;
    team: IXpert;
    agent?: IXpertAgent;
};
export interface TXpertTeamConnection {
    key: string;
    from: string;
    to: string;
    /**
     * - edge: Horizontal Process, workflow
     * - others: Vertical Process, agent
     */
    type: 'edge' | TXpertTeamNodeType;
    /**
     * Runtime selection behavior for selectable connections.
     * For sub-agent connections, omitted means required.
     */
    required?: boolean;
    readonly?: boolean;
}
export type TChatOptions = {
    xpertId?: string;
    conversationId?: string;
    messageId?: string;
    thread_id?: string;
    checkpointId?: string;
    /** Server-resolved pause checkpoint; never an arbitrary client state patch. */
    resumeCheckpoint?: TChatCheckpointReference;
    inputMessageId?: string;
    /**
     * The language used by the current browser page
     */
    language?: LanguagesEnum;
    /**
     * The browser's time zone
     */
    timeZone?: string;
    /**
     * Call from
     */
    from?: TChatFrom;
    /**
     * Project ID, identify the project where the xpert invoked
     */
    projectId?: string;
    /**
     * Schedule task ID
     */
    taskId?: string;
    /**
     * Specify environment with variables to run
     */
    environment?: IEnvironment;
    /**
     * Specify a sandbox environment container to run in
     */
    sandboxEnvironmentId?: string;
    /**
     * Specify additional tools
     */
    tools?: (StructuredToolInterface | RunnableToolLike)[];
    /**
     * Per-request runtime context forwarded to agent middleware/tools.
     */
    context?: Record<string, unknown>;
    /** Resolved Primary model; explicit and preference selections also supply Assistant base inheritance. */
    primaryCopilotModel?: TCopilotModel;
    /** Trusted Assistant model selection, also recorded for audit and retry. */
    primaryModelId?: string;
    /** Published Primary Agent key to which the override is restricted. */
    primaryAgentKey?: string;
    /** How the effective Primary Agent model was selected. */
    primaryModelSource?: import('./assistant-model.model').TAssistantPrimaryModelSelectionSource;
};
export type TChatRuntimePrincipal = {
    type: 'assistant';
    xpertId?: string;
    sourceIntegrationId?: string | null;
};
export type TChatSourceAuditOptions = {
    runtimePrincipal?: TChatRuntimePrincipal;
    /**
     * Integration that caused this background run. Kept separate from the
     * execution principal, which is normally the assistant technical account.
     */
    sourceIntegrationId?: string | null;
    integrationId?: string | null;
    channelType?: string | null;
    channelSource?: string | null;
    channel_source?: string | null;
    channelUserId?: string | null;
    uuid?: string | null;
    ownerWxid?: string | null;
    contactId?: string | null;
    contact_id?: string | null;
    chatId?: string | null;
    chat_id?: string | null;
    chatType?: string | null;
    chat_type?: string | null;
    senderId?: string | null;
    sender_id?: string | null;
    sourceMessageLogIds?: string[];
    currentInboundLogIds?: string[];
    handoffMessageId?: string | null;
    handoffTraceId?: string | null;
    handoffParentMessageId?: string | null;
};
/**
 * Knowledgebase retrieval settings
 */
export type TKBRetrievalSettings = {
    mode?: KnowledgeRetrievalMode;
    /** Overrides the knowledgebase candidate fusion strategy for this retrieval. */
    fusion?: TKBFusionConfig;
    neighborHops?: number;
    entityTopK?: number;
    communityTopK?: number;
    graphWeight?: number;
    filtering?: {
        /** Mandatory filter owned by the Agent/workflow to knowledgebase binding. */
        fixed?: KnowledgeFilterNode;
        /** Agent-authored filters can only narrow `fixed` filters. */
        agent?: {
            enabled: boolean;
        };
    };
};
export declare function isXpertNodeType<T extends TXpertTeamNodeType>(type: T): (node: TXpertTeamNode) => node is NodeOf<T>;
export {};
