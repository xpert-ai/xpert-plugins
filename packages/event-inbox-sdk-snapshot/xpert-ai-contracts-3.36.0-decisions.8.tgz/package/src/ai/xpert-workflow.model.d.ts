import { I18nObject, IconDefinition } from '../types';
import { ICopilotModel } from './copilot-model.model';
import { TKBRecallParams } from './knowledgebase.model';
import { ApiAuthType, JsonSchemaObjectType, TErrorHandling, TXpertRefParameter } from './types';
import { TKBRetrievalSettings, TStateVariable, TXpertParameter } from './xpert.model';
import type { AssistantTriggerPresentation } from './assistant-trigger.model';
export type TWorkflowNodeMeta = {
    name: string;
    label: I18nObject;
    icon: IconDefinition;
    deprecated?: boolean;
    configSchema: JsonSchemaObjectType;
};
export type TWorkflowTriggerMeta = TWorkflowNodeMeta & {
    assistant?: AssistantTriggerPresentation;
    quickConnect?: {
        method: 'qr';
        integrationProvider: string;
        configField: string;
    };
};
export type TWorkflowTriggerConnectionStatus = {
    provider: string;
    enabled: boolean;
    connected: boolean;
    state: 'disconnected' | 'connecting' | 'connected' | 'failed';
};
export declare enum WorkflowNodeTypeEnum {
    START = "start",
    END = "end",
    /**
     * Trigger
     */
    TRIGGER = "trigger",
    /**
     * State Variable Assigner
     */
    ASSIGNER = "assigner",
    /**
     * Router
     */
    IF_ELSE = "if-else",
    LIST_OPERATOR = "list-operator",
    VARIABLE_AGGREGATOR = "variable-aggregator",
    /**
     * @deprecated use ITERATOR instead
     */
    ITERATING = "iterating",
    ITERATOR = "iterator",
    HTTP = "http",
    SUBFLOW = "subflow",
    TOOL = "tool",
    AGENT_WORKFLOW = "agent-workflow",
    /**
     * @deprecated use AGENT_WORKFLOW instead
     */
    AGENT_TOOL = "agent-tool",
    NOTE = "note",
    /**
     * Task node, distribute tasks to sub-agents
     */
    TASK = "task",
    SOURCE = "source",
    PROCESSOR = "processor",
    CHUNKER = "chunker",
    UNDERSTANDING = "understanding",
    KNOWLEDGE_BASE = "knowledgebase",
    CLASSIFIER = "classifier",
    KNOWLEDGE = "knowledge",
    CODE = "code",
    TEMPLATE = "template",
    ANSWER = "answer",
    JSON_STRINGIFY = "json-stringify",
    JSON_PARSE = "json-parse",
    /**
     * Custom SQL
     */
    DB_SQL = "db-sql",
    /**
     * Insert data (INSERT)
     */
    DB_INSERT = "db-insert",
    /**
     * Update data (UPDATE)
     */
    DB_UPDATE = "db-update",
    /**
     * Delete data (DELETE)
     */
    DB_DELETE = "db-delete",
    /**
     * Query data (SELECT)
     */
    DB_QUERY = "db-query",
    MIDDLEWARE = "middleware",
    SKILL = "skill"
}
export interface IWorkflowNode {
    id: string;
    key: string;
    title?: string;
    description?: string | I18nObject;
    type: WorkflowNodeTypeEnum;
}
export declare enum VariableOperationEnum {
    APPEND = "append",
    EXTEND = "extend",
    OVERWRITE = "overwrite",
    CLEAR = "clear"
}
export type TVariableAssigner = {
    id: string;
    inputType: 'variable' | 'constant' | 'message';
    /**
     * value from variable
     */
    value?: string;
    /**
     * value write to state's variable
     */
    variableSelector: string;
    /**
     * How to write value to variable
     */
    operation: VariableOperationEnum;
    /**
     * The message template to write to messages variable
     */
    messages?: {
        role: string;
        content: string;
    }[];
};
export interface IWFNAssigner extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.ASSIGNER;
    assigners: TVariableAssigner[];
}
export interface IWFNIfElse extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.IF_ELSE;
    cases: TWFCase[];
}
/**
 * The list operator can filter and extract attributes such as file format type, file name, and size,
 * passing different format files to corresponding processing nodes to achieve precise control over different file processing flows.
 */
export interface IWFNListOperator extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.LIST_OPERATOR;
    input: string;
    itemVarType: string;
    filterBy?: {
        enabled: boolean;
        conditions: TWFCaseCondition[];
        logicalOperator: WorkflowLogicalOperator;
    };
    extractBy?: {
        enabled: boolean;
        index: number;
    };
    sortBy?: {
        enabled: boolean;
        variable: string;
        descending?: boolean;
    };
    topN?: {
        enabled: boolean;
        count: number;
    };
}
/**
 * Aggregate variables from multiple branches into a single variable to achieve unified configuration for downstream nodes.
 */
export interface IWFNVariableAggregator extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.VARIABLE_AGGREGATOR;
    inputs: string[];
    outputType: string;
}
export interface IWFNIterator extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.ITERATOR;
    /**
     * Variable name of input array in state
     */
    inputVariable: string;
    outputParams?: TXpertRefParameter[];
    /**
     * Execute in parallel, otherwise execute sequentially
     */
    parallel?: boolean;
    /**
     * Maximum number of parallel task
     */
    maximum?: number;
    /**
     * - terminate: terminate on error
     * - ignore: ignore error and continue
     * - remove: remove error output
     */
    errorMode?: 'terminate' | 'ignore' | 'remove';
}
/**
 * @deprecated use IWFNIterator instead
 */
export interface IWFNIterating extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.ITERATING;
    /**
     * Variable name of input array in state
     */
    inputVariable: string;
    inputParams?: TXpertRefParameter[];
    outputParams?: TXpertRefParameter[];
    /**
     * Execute in parallel, otherwise execute sequentially
     */
    parallel?: boolean;
    /**
     * Maximum number of parallel task
     */
    maximum?: number;
    /**
     * - terminate: terminate on error
     * - ignore: ignore error and continue
     * - remove: remove error output
     */
    errorMode?: 'terminate' | 'ignore' | 'remove';
}
/**
 * @deprecated use `IteratorItemParameterName` instead
 */
export declare const IteratingItemParameterName = "$item";
/**
 * @deprecated use `IteratorIndexParameterName` instead
 */
export declare const IteratingIndexParameterName = "$index";
/**
 * The parameter name that represents the entire current element in array
 */
export declare const IteratorItemParameterName = "$item";
export declare const IteratorIndexParameterName = "$index";
export interface IWFNAnswer extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.ANSWER;
    promptTemplate: string;
    mute?: boolean;
}
export declare enum WorkflowLogicalOperator {
    AND = "and",
    OR = "or"
}
export declare enum WorkflowComparisonOperator {
    CONTAINS = "contains",
    NOT_CONTAINS = "not-contains",
    EQUAL = "equal",
    NOT_EQUAL = "not-equal",
    GT = "gt",
    LT = "lt",
    GE = "ge",
    LE = "le",
    STARTS_WITH = "starts-with",
    ENDS_WITH = "ends-with",
    EMPTY = "empty",
    NOT_EMPTY = "not-empty",
    IS_TRUE = "is-true",
    IS_FALSE = "is-false",
    LIKE = "like",
    NOT_LIKE = "not-like"
}
/**
 * Comparison condition for if-else and list-operator nodes
 */
export type TWFCaseCondition = {
    id: string;
    comparisonOperator: WorkflowComparisonOperator;
    value?: string;
    varType?: string;
    variableSelector?: string;
};
export type TWFCase = {
    caseId: string;
    conditions: TWFCaseCondition[];
    logicalOperator: WorkflowLogicalOperator;
};
export type TWorkflowVarGroup = {
    group?: {
        name: string;
        description: string | I18nObject;
    };
    variables: TStateVariable[];
};
export type TWorkflowRetry = {
    enabled?: boolean;
    stopAfterAttempt?: number;
    retryInterval?: number;
};
export interface IWFNCode extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.CODE;
    language: 'python' | 'javascript';
    code: string;
    inputs: {
        name: string;
        variable?: string;
    }[];
    outputs: TXpertParameter[];
    /**
     * Retry on failure
     */
    retry?: TWorkflowRetry;
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export type BodyType = 'none' | 'form-data' | 'x-www-form-urlencoded' | 'json' | 'raw' | 'binary';
interface HttpParam {
    key: string;
    value: string;
}
interface HttpHeader {
    name: string;
    value: string;
}
export type TWorkflowAuthorization = {
    auth_type?: ApiAuthType;
    api_key_type?: '' | 'bearer' | 'custom';
    api_key_header?: string;
    api_key_value?: string;
    username?: string;
    password?: string;
};
export interface IWFNHttp extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.HTTP;
    authorization?: TWorkflowAuthorization;
    method: 'get' | 'post' | 'put' | 'delete' | 'patch' | 'head';
    url: string;
    headers: HttpHeader[];
    params: HttpParam[];
    body: {
        type?: BodyType;
        body?: string;
        encodedForm?: HttpParam[];
    };
    connectionTimeout?: number;
    readTimeout?: number;
    writeTimeout?: number;
    /**
     * Retry on failure
     */
    retry?: TWorkflowRetry;
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export interface IWFNKnowledgeRetrieval extends IWorkflowNode {
    queryVariable: string;
    knowledgebases: string[];
    recall?: TKBRecallParams;
    retrieval?: TKBRetrievalSettings;
}
export interface IWFNSubflow extends IWorkflowNode {
    inputParams?: TXpertRefParameter[];
    outputParams?: TXpertRefParameter[];
}
export interface IWFNTemplate extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.TEMPLATE;
    inputParams?: TXpertRefParameter[];
    code: string;
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export interface IWFNClassifier extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.CLASSIFIER;
    copilotModel: ICopilotModel;
    inputVariables: string[];
    classes: {
        description?: string;
    }[];
    instruction?: string;
}
export interface IWFNClassifier extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.CLASSIFIER;
    copilotModel: ICopilotModel;
    inputVariables: string[];
    classes: {
        description?: string;
    }[];
    instruction?: string;
}
export interface IWFNTemplate extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.TEMPLATE;
    inputParams?: TXpertRefParameter[];
    code: string;
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export interface IWFNTool extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.TOOL;
    toolsetId: string;
    toolName: string;
    /**
     * @deprecated Use parameters instead
     */
    parameterVariable: string;
    parameters?: any;
    omitBlankValues?: boolean;
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export interface IWFNNote extends IWorkflowNode {
    content: string;
}
export type TAgentToolReturnSource = {
    type: 'last_message';
} | {
    type: 'variable';
    variableSelector: string;
} | {
    type: 'template';
    template: string;
};
export type TAgentWorkflowNodeType = WorkflowNodeTypeEnum.AGENT_WORKFLOW | WorkflowNodeTypeEnum.AGENT_TOOL;
export declare function isAgentWorkflowNodeType(type: WorkflowNodeTypeEnum | string | null | undefined): type is TAgentWorkflowNodeType;
export interface IWFNAgentWorkflow extends IWorkflowNode {
    type: TAgentWorkflowNodeType;
    toolName: string;
    toolDescription?: string;
    toolParameters?: TXpertParameter[];
    /**
     * Source used to build the ToolMessage returned to the caller agent.
     * Empty means the last message in the workflow state, for backward compatibility.
     */
    returnSource?: TAgentToolReturnSource;
    /**
     * End point tool
     */
    isEnd?: boolean;
    /**
     * @deprecated Mixed sub-processes are not suitable for catching exceptions unless they are implemented using a separate subgraph
     * Error handling
     */
    errorHandling?: TErrorHandling;
}
export declare function isAgentWorkflowNode(node: IWorkflowNode | null | undefined): node is IWFNAgentWorkflow;
export interface IWFNAgentTool extends IWFNAgentWorkflow {
    type: WorkflowNodeTypeEnum.AGENT_TOOL;
}
export interface IWFNTrigger extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.TRIGGER;
    from: string;
    parameters?: TXpertParameter[];
    config?: any;
}
export interface IWFNTask extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.TASK;
    descriptionPrefix?: string;
    descriptionSuffix?: string;
}
export interface IWFNJSONStringify extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.JSON_STRINGIFY;
    inputVariable: string;
}
export interface IWFNJSONParse extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.JSON_PARSE;
    inputVariable: string;
}
export declare function genXpertTriggerKey(): string;
export declare function genListOperatorKey(): string;
export declare function genVariableAggregatorKey(): string;
export declare function genJSONStringifyKey(): string;
export declare function genJSONParseKey(): string;
export declare function genXpertIteratorKey(): string;
export declare function genXpertStartKey(key: string): string;
export declare function isAgentKey(key: string): boolean;
export declare function isRouterKey(key: string): boolean;
/**
 * @deprecated use `isIteratorKey` instead
 */
export declare function isIteratingKey(key: string): boolean;
export declare function isIteratorKey(key: string): boolean;
export declare function workflowNodeIdentifier(node: IWorkflowNode): string;
export {};
