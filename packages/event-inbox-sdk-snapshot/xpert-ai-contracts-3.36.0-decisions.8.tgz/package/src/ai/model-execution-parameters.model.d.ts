import { z } from 'zod/v3';
/** Credential-free tuning snapshot. Null persists an explicit opt-out of optional provider defaults. */
export declare const modelExecutionParametersSchema: z.ZodObject<{
    temperature: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    top_p: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    top_k: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    presence_penalty: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    frequency_penalty: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    repetition_penalty: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    seed: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    max_tokens: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    enable_thinking: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    thinking_budget: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    reasoning_effort: z.ZodOptional<z.ZodNullable<z.ZodEnum<["none", "minimal", "low", "medium", "high", "xhigh", "max"]>>>;
    thinking: z.ZodOptional<z.ZodNullable<z.ZodEnum<["enabled", "disabled", "adaptive"]>>>;
    budget_tokens: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, "strict", z.ZodTypeAny, {
    max_tokens?: number;
    temperature?: number;
    top_p?: number;
    top_k?: number;
    presence_penalty?: number;
    frequency_penalty?: number;
    repetition_penalty?: number;
    seed?: number;
    enable_thinking?: boolean;
    thinking_budget?: number;
    reasoning_effort?: "none" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";
    thinking?: "disabled" | "enabled" | "adaptive";
    budget_tokens?: number;
}, {
    max_tokens?: number;
    temperature?: number;
    top_p?: number;
    top_k?: number;
    presence_penalty?: number;
    frequency_penalty?: number;
    repetition_penalty?: number;
    seed?: number;
    enable_thinking?: boolean;
    thinking_budget?: number;
    reasoning_effort?: "none" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";
    thinking?: "disabled" | "enabled" | "adaptive";
    budget_tokens?: number;
}>;
export type ModelExecutionParameters = z.output<typeof modelExecutionParametersSchema>;
