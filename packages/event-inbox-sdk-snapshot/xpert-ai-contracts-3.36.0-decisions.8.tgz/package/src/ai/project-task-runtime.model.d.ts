import { z } from 'zod/v3';
export declare const projectTaskSpecificationDigestSchema: z.ZodString;
/** Only requirements belong here; status, progress, assignment and generic revision do not. */
export declare const projectTaskSpecificationSchema: z.ZodEffects<z.ZodObject<{
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    requirements: z.ZodArray<z.ZodString, "many">;
    steps: z.ZodArray<z.ZodObject<{
        stepIndex: z.ZodNumber;
        description: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        description: string;
        stepIndex: number;
    }, {
        description: string;
        stepIndex: number;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    title: string;
    version: 1;
    steps: {
        description: string;
        stepIndex: number;
    }[];
    requirements: string[];
    description?: string | undefined;
}, {
    title: string;
    version: 1;
    steps: {
        description: string;
        stepIndex: number;
    }[];
    requirements: string[];
    description?: string | undefined;
}>, {
    title: string;
    version: 1;
    steps: {
        description: string;
        stepIndex: number;
    }[];
    requirements: string[];
    description?: string | undefined;
}, {
    title: string;
    version: 1;
    steps: {
        description: string;
        stepIndex: number;
    }[];
    requirements: string[];
    description?: string | undefined;
}>;
export type ProjectTaskSpecification = z.output<typeof projectTaskSpecificationSchema>;
/** The host verifies the digest against the specification at the persistence boundary. */
export declare const projectTaskSpecificationSnapshotSchema: z.ZodObject<{
    digest: z.ZodString;
    specification: z.ZodEffects<z.ZodObject<{
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        requirements: z.ZodArray<z.ZodString, "many">;
        steps: z.ZodArray<z.ZodObject<{
            stepIndex: z.ZodNumber;
            description: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            description: string;
            stepIndex: number;
        }, {
            description: string;
            stepIndex: number;
        }>, "many">;
    }, "strict", z.ZodTypeAny, {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    }, {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    }>, {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    }, {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    }>;
}, "strict", z.ZodTypeAny, {
    digest: string;
    specification: {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    };
}, {
    digest: string;
    specification: {
        title: string;
        version: 1;
        steps: {
            description: string;
            stepIndex: number;
        }[];
        requirements: string[];
        description?: string | undefined;
    };
}>;
export type ProjectTaskSpecificationSnapshot = z.output<typeof projectTaskSpecificationSnapshotSchema>;
/** Versioned references, not paths or access grants. Resolve and authorize before reading. */
export declare const projectTaskEvidenceReferenceSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"artifact">;
    artifactId: z.ZodString;
    versionId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "artifact";
    artifactId: string;
    versionId: string;
}, {
    type: "artifact";
    artifactId: string;
    versionId: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"invocation_result">;
    invocationId: z.ZodString;
    revision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    type: "invocation_result";
    revision: number;
    invocationId: string;
}, {
    type: "invocation_result";
    revision: number;
    invocationId: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"workspace_snapshot">;
    snapshotId: z.ZodString;
    digest: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type: "workspace_snapshot";
    digest: string;
    snapshotId: string;
}, {
    type: "workspace_snapshot";
    digest: string;
    snapshotId: string;
}>]>;
export type ProjectTaskEvidenceReference = z.output<typeof projectTaskEvidenceReferenceSchema>;
export declare const projectTaskReviewerSchema: z.ZodObject<{
    bindingId: z.ZodString;
    mode: z.ZodEnum<["evidence_only", "execution"]>;
}, "strict", z.ZodTypeAny, {
    mode: "execution" | "evidence_only";
    bindingId: string;
}, {
    mode: "execution" | "evidence_only";
    bindingId: string;
}>;
export type ProjectTaskReviewer = z.output<typeof projectTaskReviewerSchema>;
/** Host-owned identity of a review work item; retries cannot change its candidate. */
export declare const projectTaskReviewSubjectSchema: z.ZodObject<{
    implementationTaskId: z.ZodString;
    implementationExecutionId: z.ZodString;
    specificationDigest: z.ZodString;
}, "strict", z.ZodTypeAny, {
    implementationTaskId: string;
    implementationExecutionId: string;
    specificationDigest: string;
}, {
    implementationTaskId: string;
    implementationExecutionId: string;
    specificationDigest: string;
}>;
export type ProjectTaskReviewSubject = z.output<typeof projectTaskReviewSubjectSchema>;
export declare const projectTaskReworkSchema: z.ZodObject<{
    reviewExecutionId: z.ZodString;
    feedback: z.ZodString;
}, "strict", z.ZodTypeAny, {
    reviewExecutionId: string;
    feedback: string;
}, {
    reviewExecutionId: string;
    feedback: string;
}>;
export declare const projectTaskCandidatePathSchema: z.ZodEffects<z.ZodString, string, string>;
export declare const projectTaskEvidencePathSchema: z.ZodEffects<z.ZodString, string, string>;
export declare const projectTaskExecutionPurposeSchema: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"implementation">;
    reviewer: z.ZodOptional<z.ZodObject<{
        bindingId: z.ZodString;
        mode: z.ZodEnum<["evidence_only", "execution"]>;
    }, "strict", z.ZodTypeAny, {
        mode: "execution" | "evidence_only";
        bindingId: string;
    }, {
        mode: "execution" | "evidence_only";
        bindingId: string;
    }>>;
    coordination: z.ZodOptional<z.ZodObject<{
        taskId: z.ZodString;
        specificationDigest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        taskId: string;
        specificationDigest: string;
    }, {
        taskId: string;
        specificationDigest: string;
    }>>;
    rework: z.ZodOptional<z.ZodObject<{
        reviewExecutionId: z.ZodString;
        feedback: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        reviewExecutionId: string;
        feedback: string;
    }, {
        reviewExecutionId: string;
        feedback: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    type: "implementation";
    reviewer?: {
        mode: "execution" | "evidence_only";
        bindingId: string;
    } | undefined;
    coordination?: {
        taskId: string;
        specificationDigest: string;
    } | undefined;
    rework?: {
        reviewExecutionId: string;
        feedback: string;
    } | undefined;
}, {
    type: "implementation";
    reviewer?: {
        mode: "execution" | "evidence_only";
        bindingId: string;
    } | undefined;
    coordination?: {
        taskId: string;
        specificationDigest: string;
    } | undefined;
    rework?: {
        reviewExecutionId: string;
        feedback: string;
    } | undefined;
}>, z.ZodObject<{
    type: z.ZodLiteral<"review">;
    mode: z.ZodOptional<z.ZodEnum<["evidence_only", "execution"]>>;
    candidatePaths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
    implementationExecutionId: z.ZodString;
    implementationTaskId: z.ZodOptional<z.ZodString>;
    implementationInvocationId: z.ZodString;
    specificationDigest: z.ZodString;
    evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"artifact">;
        artifactId: z.ZodString;
        versionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"invocation_result">;
        invocationId: z.ZodString;
        revision: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"workspace_snapshot">;
        snapshotId: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }>]>, "many">;
}, "strict", z.ZodTypeAny, {
    type: "review";
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    implementationInvocationId: string;
    mode?: "execution" | "evidence_only" | undefined;
    implementationTaskId?: string | undefined;
    candidatePaths?: string[] | undefined;
}, {
    type: "review";
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    implementationInvocationId: string;
    mode?: "execution" | "evidence_only" | undefined;
    implementationTaskId?: string | undefined;
    candidatePaths?: string[] | undefined;
}>]>, {
    type: "implementation";
    reviewer?: {
        mode: "execution" | "evidence_only";
        bindingId: string;
    } | undefined;
    coordination?: {
        taskId: string;
        specificationDigest: string;
    } | undefined;
    rework?: {
        reviewExecutionId: string;
        feedback: string;
    } | undefined;
} | {
    type: "review";
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    implementationInvocationId: string;
    mode?: "execution" | "evidence_only" | undefined;
    implementationTaskId?: string | undefined;
    candidatePaths?: string[] | undefined;
}, {
    type: "implementation";
    reviewer?: {
        mode: "execution" | "evidence_only";
        bindingId: string;
    } | undefined;
    coordination?: {
        taskId: string;
        specificationDigest: string;
    } | undefined;
    rework?: {
        reviewExecutionId: string;
        feedback: string;
    } | undefined;
} | {
    type: "review";
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    implementationInvocationId: string;
    mode?: "execution" | "evidence_only" | undefined;
    implementationTaskId?: string | undefined;
    candidatePaths?: string[] | undefined;
}>;
export type ProjectTaskExecutionPurpose = z.output<typeof projectTaskExecutionPurposeSchema>;
export declare const projectTaskExecutionReferenceSchema: z.ZodObject<{
    projectId: z.ZodString;
    projectTaskId: z.ZodString;
    taskExecutionId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    projectId: string;
    projectTaskId: string;
    taskExecutionId: string;
}, {
    projectId: string;
    projectTaskId: string;
    taskExecutionId: string;
}>;
export type ProjectTaskExecutionReference = z.output<typeof projectTaskExecutionReferenceSchema>;
/** Host-owned attempt context. Review is a new attempt and grants no completion authority. */
export declare const projectTaskExecutionContextSchema: z.ZodEffects<z.ZodObject<{
    projectId: z.ZodString;
    projectTaskId: z.ZodString;
    taskExecutionId: z.ZodString;
} & {
    specification: z.ZodObject<{
        digest: z.ZodString;
        specification: z.ZodEffects<z.ZodObject<{
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            requirements: z.ZodArray<z.ZodString, "many">;
            steps: z.ZodArray<z.ZodObject<{
                stepIndex: z.ZodNumber;
                description: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                description: string;
                stepIndex: number;
            }, {
                description: string;
                stepIndex: number;
            }>, "many">;
        }, "strict", z.ZodTypeAny, {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        }, {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        }>, {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        }, {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    }, {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    }>;
    purpose: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"implementation">;
        reviewer: z.ZodOptional<z.ZodObject<{
            bindingId: z.ZodString;
            mode: z.ZodEnum<["evidence_only", "execution"]>;
        }, "strict", z.ZodTypeAny, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }>>;
        coordination: z.ZodOptional<z.ZodObject<{
            taskId: z.ZodString;
            specificationDigest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            taskId: string;
            specificationDigest: string;
        }, {
            taskId: string;
            specificationDigest: string;
        }>>;
        rework: z.ZodOptional<z.ZodObject<{
            reviewExecutionId: z.ZodString;
            feedback: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            reviewExecutionId: string;
            feedback: string;
        }, {
            reviewExecutionId: string;
            feedback: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"review">;
        mode: z.ZodOptional<z.ZodEnum<["evidence_only", "execution"]>>;
        candidatePaths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        implementationExecutionId: z.ZodString;
        implementationTaskId: z.ZodOptional<z.ZodString>;
        implementationInvocationId: z.ZodString;
        specificationDigest: z.ZodString;
        evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"artifact">;
            artifactId: z.ZodString;
            versionId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"invocation_result">;
            invocationId: z.ZodString;
            revision: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"workspace_snapshot">;
            snapshotId: z.ZodString;
            digest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }>]>, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }>;
}, "strict", z.ZodTypeAny, {
    purpose: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    };
    projectId: string;
    specification: {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    };
    projectTaskId: string;
    taskExecutionId: string;
}, {
    purpose: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    };
    projectId: string;
    specification: {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    };
    projectTaskId: string;
    taskExecutionId: string;
}>, {
    purpose: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    };
    projectId: string;
    specification: {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    };
    projectTaskId: string;
    taskExecutionId: string;
}, {
    purpose: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    };
    projectId: string;
    specification: {
        digest: string;
        specification: {
            title: string;
            version: 1;
            steps: {
                description: string;
                stepIndex: number;
            }[];
            requirements: string[];
            description?: string | undefined;
        };
    };
    projectTaskId: string;
    taskExecutionId: string;
}>;
export type ProjectTaskExecutionContext = z.output<typeof projectTaskExecutionContextSchema>;
/** A receipt is neither a business completion decision nor proof that the process has started. */
export declare const projectTaskDispatchReceiptSchema: z.ZodObject<{
    projectId: z.ZodString;
    projectTaskId: z.ZodString;
    taskExecutionId: z.ZodString;
} & {
    invocationId: z.ZodString;
    status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
}, "strict", z.ZodTypeAny, {
    status: "unknown" | "failed" | "cancelled" | "running" | "waiting" | "cancelling" | "succeeded" | "queued";
    projectId: string;
    invocationId: string;
    projectTaskId: string;
    taskExecutionId: string;
}, {
    status: "unknown" | "failed" | "cancelled" | "running" | "waiting" | "cancelling" | "succeeded" | "queued";
    projectId: string;
    invocationId: string;
    projectTaskId: string;
    taskExecutionId: string;
}>;
export type ProjectTaskDispatchReceipt = z.output<typeof projectTaskDispatchReceiptSchema>;
export declare const projectTaskDispatchInputSchema: z.ZodEffects<z.ZodObject<{
    requestId: z.ZodString;
    taskId: z.ZodString;
    expectedRevision: z.ZodNumber;
    bindingId: z.ZodOptional<z.ZodString>;
    target: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"group_member">;
        participantId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "group_member";
        participantId: string;
    }, {
        type: "group_member";
        participantId: string;
    }>>;
    purpose: z.ZodOptional<z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"implementation">;
        reviewer: z.ZodOptional<z.ZodObject<{
            bindingId: z.ZodString;
            mode: z.ZodEnum<["evidence_only", "execution"]>;
        }, "strict", z.ZodTypeAny, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }>>;
        coordination: z.ZodOptional<z.ZodObject<{
            taskId: z.ZodString;
            specificationDigest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            taskId: string;
            specificationDigest: string;
        }, {
            taskId: string;
            specificationDigest: string;
        }>>;
        rework: z.ZodOptional<z.ZodObject<{
            reviewExecutionId: z.ZodString;
            feedback: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            reviewExecutionId: string;
            feedback: string;
        }, {
            reviewExecutionId: string;
            feedback: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"review">;
        mode: z.ZodOptional<z.ZodEnum<["evidence_only", "execution"]>>;
        candidatePaths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        implementationExecutionId: z.ZodString;
        implementationTaskId: z.ZodOptional<z.ZodString>;
        implementationInvocationId: z.ZodString;
        specificationDigest: z.ZodString;
        evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"artifact">;
            artifactId: z.ZodString;
            versionId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"invocation_result">;
            invocationId: z.ZodString;
            revision: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"workspace_snapshot">;
            snapshotId: z.ZodString;
            digest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }>]>, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    }>>;
    reviewAsSubtask: z.ZodOptional<z.ZodBoolean>;
    delivery: z.ZodOptional<z.ZodDiscriminatedUnion<"mode", [z.ZodObject<{
        mode: z.ZodLiteral<"none">;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "none";
        reportPath?: string | undefined;
    }, {
        mode: "none";
        reportPath?: string | undefined;
    }>, z.ZodObject<{
        mode: z.ZodLiteral<"files">;
        paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }, {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }>, z.ZodObject<{
        mode: z.ZodLiteral<"archive">;
        paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }, {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }>]>>;
    instructions: z.ZodDefault<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    taskId: string;
    requestId: string;
    expectedRevision: number;
    instructions: string;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
}, {
    taskId: string;
    requestId: string;
    expectedRevision: number;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
    instructions?: string | undefined;
}>, {
    taskId: string;
    requestId: string;
    expectedRevision: number;
    instructions: string;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
}, {
    taskId: string;
    requestId: string;
    expectedRevision: number;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        coordination?: {
            taskId: string;
            specificationDigest: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        implementationTaskId?: string | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
    instructions?: string | undefined;
}>;
export declare const projectTaskDispatchToolInputSchema: z.ZodEffects<z.ZodObject<{
    taskId: z.ZodString;
    expectedRevision: z.ZodNumber;
    bindingId: z.ZodOptional<z.ZodString>;
    target: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"group_member">;
        participantId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "group_member";
        participantId: string;
    }, {
        type: "group_member";
        participantId: string;
    }>>;
    reviewAsSubtask: z.ZodOptional<z.ZodBoolean>;
    delivery: z.ZodOptional<z.ZodDiscriminatedUnion<"mode", [z.ZodObject<{
        mode: z.ZodLiteral<"none">;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "none";
        reportPath?: string | undefined;
    }, {
        mode: "none";
        reportPath?: string | undefined;
    }>, z.ZodObject<{
        mode: z.ZodLiteral<"files">;
        paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }, {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }>, z.ZodObject<{
        mode: z.ZodLiteral<"archive">;
        paths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>, "many">>;
        reportPath: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    }, "strict", z.ZodTypeAny, {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }, {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    }>]>>;
    instructions: z.ZodDefault<z.ZodString>;
} & {
    purpose: z.ZodOptional<z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<Omit<{
        type: z.ZodLiteral<"implementation">;
        reviewer: z.ZodOptional<z.ZodObject<{
            bindingId: z.ZodString;
            mode: z.ZodEnum<["evidence_only", "execution"]>;
        }, "strict", z.ZodTypeAny, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }, {
            mode: "execution" | "evidence_only";
            bindingId: string;
        }>>;
        coordination: z.ZodOptional<z.ZodObject<{
            taskId: z.ZodString;
            specificationDigest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            taskId: string;
            specificationDigest: string;
        }, {
            taskId: string;
            specificationDigest: string;
        }>>;
        rework: z.ZodOptional<z.ZodObject<{
            reviewExecutionId: z.ZodString;
            feedback: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            reviewExecutionId: string;
            feedback: string;
        }, {
            reviewExecutionId: string;
            feedback: string;
        }>>;
    }, "coordination">, "strict", z.ZodTypeAny, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    }>, z.ZodObject<Omit<{
        type: z.ZodLiteral<"review">;
        mode: z.ZodOptional<z.ZodEnum<["evidence_only", "execution"]>>;
        candidatePaths: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        implementationExecutionId: z.ZodString;
        implementationTaskId: z.ZodOptional<z.ZodString>;
        implementationInvocationId: z.ZodString;
        specificationDigest: z.ZodString;
        evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"artifact">;
            artifactId: z.ZodString;
            versionId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }, {
            type: "artifact";
            artifactId: string;
            versionId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"invocation_result">;
            invocationId: z.ZodString;
            revision: z.ZodNumber;
        }, "strict", z.ZodTypeAny, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }, {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"workspace_snapshot">;
            snapshotId: z.ZodString;
            digest: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }, {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        }>]>, "many">;
    }, "implementationTaskId">, "strict", z.ZodTypeAny, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    }>]>, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    }, {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    }>>;
}, "strict", z.ZodTypeAny, {
    taskId: string;
    expectedRevision: number;
    instructions: string;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
}, {
    taskId: string;
    expectedRevision: number;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
    instructions?: string | undefined;
}>, {
    taskId: string;
    expectedRevision: number;
    instructions: string;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
}, {
    taskId: string;
    expectedRevision: number;
    purpose?: {
        type: "implementation";
        reviewer?: {
            mode: "execution" | "evidence_only";
            bindingId: string;
        } | undefined;
        rework?: {
            reviewExecutionId: string;
            feedback: string;
        } | undefined;
    } | {
        type: "review";
        evidence: ({
            type: "artifact";
            artifactId: string;
            versionId: string;
        } | {
            type: "invocation_result";
            revision: number;
            invocationId: string;
        } | {
            type: "workspace_snapshot";
            digest: string;
            snapshotId: string;
        })[];
        implementationExecutionId: string;
        specificationDigest: string;
        implementationInvocationId: string;
        mode?: "execution" | "evidence_only" | undefined;
        candidatePaths?: string[] | undefined;
    } | undefined;
    bindingId?: string | undefined;
    target?: {
        type: "group_member";
        participantId: string;
    } | undefined;
    reviewAsSubtask?: boolean | undefined;
    delivery?: {
        mode: "none";
        reportPath?: string | undefined;
    } | {
        mode: "files";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | {
        mode: "archive";
        reportPath?: string | undefined;
        paths?: string[] | undefined;
    } | undefined;
    instructions?: string | undefined;
}>;
export type ProjectTaskDispatchInput = z.output<typeof projectTaskDispatchInputSchema>;
/** Markdown is authored evidence. Only an explicit coordinator decision accepts a task. */
export declare const projectTaskReviewReportSchema: z.ZodObject<{
    format: z.ZodLiteral<"markdown">;
    markdown: z.ZodString;
}, "strict", z.ZodTypeAny, {
    format: "markdown";
    markdown: string;
}, {
    format: "markdown";
    markdown: string;
}>;
export type ProjectTaskReviewReport = z.output<typeof projectTaskReviewReportSchema>;
export declare const projectTaskDecisionToolInputSchema: z.ZodObject<{
    decisionRef: z.ZodString;
    outcome: z.ZodEnum<["accept", "rework"]>;
    rationale: z.ZodString;
    checks: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strict", z.ZodTypeAny, {
    outcome: "accept" | "rework";
    decisionRef: string;
    rationale: string;
    checks?: string[] | undefined;
}, {
    outcome: "accept" | "rework";
    decisionRef: string;
    rationale: string;
    checks?: string[] | undefined;
}>;
export type ProjectTaskDecisionToolInput = z.output<typeof projectTaskDecisionToolInputSchema>;
export declare const projectTaskDecisionInputSchema: z.ZodObject<{
    requestId: z.ZodString;
    taskId: z.ZodString;
    expectedRevision: z.ZodNumber;
    implementationExecutionId: z.ZodString;
    specificationDigest: z.ZodString;
    evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"artifact">;
        artifactId: z.ZodString;
        versionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"invocation_result">;
        invocationId: z.ZodString;
        revision: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"workspace_snapshot">;
        snapshotId: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }>]>, "many">;
    reviewExecutionId: z.ZodOptional<z.ZodString>;
    outcome: z.ZodEnum<["accept", "rework"]>;
    rationale: z.ZodString;
    checks: z.ZodArray<z.ZodString, "many">;
}, "strict", z.ZodTypeAny, {
    taskId: string;
    requestId: string;
    outcome: "accept" | "rework";
    expectedRevision: number;
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    rationale: string;
    checks: string[];
    reviewExecutionId?: string | undefined;
}, {
    taskId: string;
    requestId: string;
    outcome: "accept" | "rework";
    expectedRevision: number;
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    implementationExecutionId: string;
    specificationDigest: string;
    rationale: string;
    checks: string[];
    reviewExecutionId?: string | undefined;
}>;
export type ProjectTaskDecisionInput = z.output<typeof projectTaskDecisionInputSchema>;
export declare const projectTaskDecisionSchema: z.ZodObject<{
    requestId: z.ZodString;
    taskId: z.ZodString;
    expectedRevision: z.ZodNumber;
    implementationExecutionId: z.ZodString;
    specificationDigest: z.ZodString;
    evidence: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"artifact">;
        artifactId: z.ZodString;
        versionId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }, {
        type: "artifact";
        artifactId: string;
        versionId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"invocation_result">;
        invocationId: z.ZodString;
        revision: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }, {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"workspace_snapshot">;
        snapshotId: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }, {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    }>]>, "many">;
    reviewExecutionId: z.ZodOptional<z.ZodString>;
    outcome: z.ZodEnum<["accept", "rework"]>;
    rationale: z.ZodString;
    checks: z.ZodArray<z.ZodString, "many">;
} & {
    actorId: z.ZodString;
    actorType: z.ZodEnum<["user", "xpert", "project_agent"]>;
    executionId: z.ZodOptional<z.ZodString>;
    reviewResult: z.ZodOptional<z.ZodObject<{
        invocationId: z.ZodString;
        revision: z.ZodNumber;
        sha256: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        revision: number;
        sha256: string;
        invocationId: string;
    }, {
        revision: number;
        sha256: string;
        invocationId: string;
    }>>;
    decidedAt: z.ZodString;
    taskRevision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    taskId: string;
    requestId: string;
    outcome: "accept" | "rework";
    expectedRevision: number;
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    decidedAt: string;
    implementationExecutionId: string;
    specificationDigest: string;
    rationale: string;
    checks: string[];
    actorId: string;
    actorType: "user" | "xpert" | "project_agent";
    taskRevision: number;
    executionId?: string | undefined;
    reviewExecutionId?: string | undefined;
    reviewResult?: {
        revision: number;
        sha256: string;
        invocationId: string;
    } | undefined;
}, {
    taskId: string;
    requestId: string;
    outcome: "accept" | "rework";
    expectedRevision: number;
    evidence: ({
        type: "artifact";
        artifactId: string;
        versionId: string;
    } | {
        type: "invocation_result";
        revision: number;
        invocationId: string;
    } | {
        type: "workspace_snapshot";
        digest: string;
        snapshotId: string;
    })[];
    decidedAt: string;
    implementationExecutionId: string;
    specificationDigest: string;
    rationale: string;
    checks: string[];
    actorId: string;
    actorType: "user" | "xpert" | "project_agent";
    taskRevision: number;
    executionId?: string | undefined;
    reviewExecutionId?: string | undefined;
    reviewResult?: {
        revision: number;
        sha256: string;
        invocationId: string;
    } | undefined;
}>;
export type ProjectTaskDecision = z.output<typeof projectTaskDecisionSchema>;
