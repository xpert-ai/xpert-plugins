import type { McpCapabilityApprovalMode } from './mcp-publication.model';
import type { I18nObject } from '../types';
import type { TMcpAppRefresh } from './xpert-tool-mcp.model';
import type { JSONValue } from '../core.model';
export declare const MCP_CAPABILITY_DESCRIPTOR_VERSION: 1;
export declare const MCP_CAPABILITY_TYPES: readonly ["tool", "resource", "resource_template", "prompt", "app"];
export type McpCapabilityType = (typeof MCP_CAPABILITY_TYPES)[number];
export declare const MCP_TOOL_RISKS: readonly ["read", "write", "dangerous"];
export type McpToolRisk = (typeof MCP_TOOL_RISKS)[number];
export declare const MCP_TOOL_SIDE_EFFECTS: readonly ["none", "reversible", "irreversible"];
export type McpToolSideEffect = (typeof MCP_TOOL_SIDE_EFFECTS)[number];
export declare const MCP_TOOL_IDEMPOTENCY: readonly ["safe", "idempotent", "non_idempotent"];
export type McpToolIdempotency = (typeof MCP_TOOL_IDEMPOTENCY)[number];
export declare const MCP_REQUIRED_CONTEXTS: readonly ["tenant", "organization", "workspace", "principal", "project", "conversation", "agent", "execution", "store", "checkpoint"];
export type McpRequiredContext = (typeof MCP_REQUIRED_CONTEXTS)[number];
export declare const MCP_CAPABILITY_VISIBILITIES: readonly ["model", "app"];
export type McpCapabilityVisibility = (typeof MCP_CAPABILITY_VISIBILITIES)[number];
/** JSON Schema 2020-12 document stored and transported without framework-specific schema objects. */
export type McpJsonSchema = {
    [keyword: string]: JSONValue;
};
export interface McpToolBehavior {
    risk: McpToolRisk;
    sideEffect: McpToolSideEffect;
    idempotency: McpToolIdempotency;
}
export interface McpToolAnnotations {
    title?: string;
    readOnlyHint?: boolean;
    destructiveHint?: boolean;
    idempotentHint?: boolean;
    openWorldHint?: boolean;
}
export interface McpCapabilitySource {
    toolsetId: string;
    pluginName?: string;
    pluginVersion?: string;
    /** Configured server within a multi-server MCP Consumer toolset. */
    serverName?: string;
    /** Capability name used on the remote MCP server before host-side disambiguation. */
    remoteName?: string;
}
export interface McpCapabilityDescriptorBase {
    descriptorVersion: typeof MCP_CAPABILITY_DESCRIPTOR_VERSION;
    capabilityType: McpCapabilityType;
    capabilityKey: string;
    title?: string;
    description?: string;
    /** Lower-priority guidance supplied by the plugin or remote MCP server. */
    providerInstructions?: string;
    source: McpCapabilitySource;
    requiredContext: McpRequiredContext[];
    visibility: McpCapabilityVisibility[];
}
export interface McpToolCapabilityDescriptor extends McpCapabilityDescriptorBase {
    capabilityType: 'tool';
    inputSchema: McpJsonSchema;
    outputSchema?: McpJsonSchema;
    behavior: McpToolBehavior;
    /** Plugin default used when a Publication has no explicit approval override. */
    defaultApprovalMode?: McpCapabilityApprovalMode;
    annotations?: McpToolAnnotations;
    appResourceKey?: string;
    taskMode?: 'optional' | 'required';
    taskMaxLifetimeMs?: number;
}
export interface McpResourceCapabilityDescriptor extends McpCapabilityDescriptorBase {
    capabilityType: 'resource';
    uri: string;
    mimeType?: string;
    cacheTtlMs?: number;
}
export interface McpResourceTemplateCapabilityDescriptor extends McpCapabilityDescriptorBase {
    capabilityType: 'resource_template';
    uriTemplate: string;
    mimeType?: string;
    argumentSchema: McpJsonSchema;
    supportsCompletion: boolean;
    cacheTtlMs?: number;
}
export interface McpPromptCapabilityDescriptor extends McpCapabilityDescriptorBase {
    capabilityType: 'prompt';
    name: string;
    argumentSchema: McpJsonSchema;
    supportsCompletion?: boolean;
}
export interface McpAppCapabilityDescriptor extends Omit<McpCapabilityDescriptorBase, 'title'> {
    title?: string | I18nObject;
    refresh?: TMcpAppRefresh;
    capabilityType: 'app';
    entry: string;
    csp?: {
        connectDomains?: string[];
        resourceDomains?: string[];
    };
    permissions?: {
        clipboardWrite?: boolean;
        camera?: boolean;
        microphone?: boolean;
        geolocation?: boolean;
    };
}
export type McpCapabilityDescriptor = McpToolCapabilityDescriptor | McpResourceCapabilityDescriptor | McpResourceTemplateCapabilityDescriptor | McpPromptCapabilityDescriptor | McpAppCapabilityDescriptor;
type McpCapabilityDeclarationOf<TDescriptor extends McpCapabilityDescriptor> = TDescriptor extends McpCapabilityDescriptor ? Omit<TDescriptor, 'source'> & {
    source?: Omit<McpCapabilitySource, 'toolsetId'>;
} : never;
/** Plugin-side declaration before the host binds it to a concrete toolset instance. */
export type McpCapabilityDeclaration = McpCapabilityDeclarationOf<McpCapabilityDescriptor>;
/** Resolve the declaration default; callers must apply explicit Publication policy first. */
export declare function defaultMcpToolApprovalMode(descriptor: Pick<McpToolCapabilityDescriptor, 'behavior' | 'defaultApprovalMode'>): McpCapabilityApprovalMode;
/** Dangerous tools may run directly only when their owner explicitly declares that policy. */
export declare function canAllowMcpToolDirectly(descriptor: Pick<McpToolCapabilityDescriptor, 'behavior' | 'defaultApprovalMode'>): boolean;
export {};
