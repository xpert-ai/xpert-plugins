import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IChatConversation } from './chat.model';
import { IKnowledgeDocument, KnowledgeDocumentProcessingMode } from './knowledge-doc.model';
import { IKnowledgebase } from './knowledgebase.model';
import { IXpertAgentExecution } from './xpert-agent-execution.model';
/**
 * Task executions of a knowledgebase
 */
export interface IKnowledgebaseTask extends IBasePerTenantAndOrganizationEntityModel {
    knowledgebaseId?: string;
    knowledgebase?: IKnowledgebase;
    conversationId?: string;
    conversation?: IChatConversation;
    executionId?: string;
    execution?: IXpertAgentExecution;
    taskType: string;
    status?: 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
    steps: TaskStep[];
    error?: string;
    /**
     * Temporary content: Documents not actually processed in the task yet
     */
    context?: {
        documents?: Partial<IKnowledgeDocument>[];
        /** Propagates full conversion vs. snapshot-only rechunking through the background task. */
        processingMode?: KnowledgeDocumentProcessingMode;
        /** Server-created preview ID -> saved document ID bindings, grouped by source node. */
        materializedSources?: Record<string, Record<string, string>>;
    };
    /**
     * Many to Many of documents in task
     */
    documents?: IKnowledgeDocument[];
}
export interface TaskStep {
    name: string;
    status: 'pending' | 'running' | 'success' | 'failed';
    progress: number;
    log?: string;
    error_message?: string;
    started_at?: Date;
    finished_at?: Date;
}
