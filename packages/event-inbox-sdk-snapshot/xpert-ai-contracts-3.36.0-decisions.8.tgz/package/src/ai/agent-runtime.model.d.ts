import { z } from 'zod/v3';
/**
 * Running means accepted; actual work start requires an observation.
 * Only succeeded, failed and cancelled are terminal. Unknown must be reconciled without replay.
 */
export declare const agentInvocationStatusSchema: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
export type AgentInvocationStatus = z.output<typeof agentInvocationStatusSchema>;
export declare const agentInvocationTerminalStatusSchema: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
/** Activity and reported progress are separate from business acceptance. No invented percentage. */
export declare const agentRuntimeProgressSchema: z.ZodObject<{
    source: z.ZodEnum<["executor", "host"]>;
    observedAt: z.ZodString;
    startedAt: z.ZodOptional<z.ZodString>;
    phase: z.ZodOptional<z.ZodString>;
    summary: z.ZodOptional<z.ZodString>;
    steps: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        completed: z.ZodNumber;
        total: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        completed: number;
        total: number;
    }, {
        completed: number;
        total: number;
    }>, {
        completed: number;
        total: number;
    }, {
        completed: number;
        total: number;
    }>>;
}, "strict", z.ZodTypeAny, {
    source: "executor" | "host";
    observedAt: string;
    phase?: string | undefined;
    startedAt?: string | undefined;
    steps?: {
        completed: number;
        total: number;
    } | undefined;
    summary?: string | undefined;
}, {
    source: "executor" | "host";
    observedAt: string;
    phase?: string | undefined;
    startedAt?: string | undefined;
    steps?: {
        completed: number;
        total: number;
    } | undefined;
    summary?: string | undefined;
}>;
export type AgentRuntimeProgress = z.output<typeof agentRuntimeProgressSchema>;
