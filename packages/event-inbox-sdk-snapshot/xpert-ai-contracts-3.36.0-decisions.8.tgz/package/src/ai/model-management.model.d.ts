import { z } from 'zod';
import { AiModelTypeEnum } from '../agent';
import { DefaultModelRole } from './default-model-role';
import { ParameterRule } from './ai-model.model';
import type { ICopilotProvider } from './copilot-provider.model';
export declare const modelIdentitySchema: z.ZodObject<{
    copilotId: z.ZodString;
    modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
    model: z.ZodString;
}, "strict", z.ZodTypeAny, {
    copilotId?: string;
    modelType?: AiModelTypeEnum;
    model?: string;
}, {
    copilotId?: string;
    modelType?: AiModelTypeEnum;
    model?: string;
}>;
export type ModelIdentity = z.output<typeof modelIdentitySchema>;
export declare const modelBindingSchema: z.ZodObject<{
    copilotId: z.ZodString;
    modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
    model: z.ZodString;
} & {
    options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
}, "strict", z.ZodTypeAny, {
    options?: Record<string, string | number | boolean>;
    copilotId?: string;
    modelType?: AiModelTypeEnum;
    model?: string;
}, {
    options?: Record<string, string | number | boolean>;
    copilotId?: string;
    modelType?: AiModelTypeEnum;
    model?: string;
}>;
export type ModelBinding = z.output<typeof modelBindingSchema>;
export declare const roleDefaultInputSchema: z.ZodDiscriminatedUnion<"mode", [z.ZodObject<{
    role: z.ZodNativeEnum<{
        readonly Primary: "primary";
        readonly Secondary: "secondary";
        readonly Reasoning: "reasoning";
        readonly Embedding: "embedding";
        readonly Realtime: "realtime";
        readonly TextToSpeech: "tts";
        readonly SpeechToText: "speech2text";
        readonly ImageGeneration: "image";
        readonly VideoGeneration: "video";
        readonly Rerank: "rerank";
        readonly Moderation: "moderation";
    }>;
    mode: z.ZodLiteral<"fixed">;
    binding: z.ZodObject<{
        copilotId: z.ZodString;
        modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
        model: z.ZodString;
    } & {
        options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
    }, "strict", z.ZodTypeAny, {
        options?: Record<string, string | number | boolean>;
        copilotId?: string;
        modelType?: AiModelTypeEnum;
        model?: string;
    }, {
        options?: Record<string, string | number | boolean>;
        copilotId?: string;
        modelType?: AiModelTypeEnum;
        model?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "fixed";
    binding?: {
        options?: Record<string, string | number | boolean>;
        copilotId?: string;
        modelType?: AiModelTypeEnum;
        model?: string;
    };
}, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "fixed";
    binding?: {
        options?: Record<string, string | number | boolean>;
        copilotId?: string;
        modelType?: AiModelTypeEnum;
        model?: string;
    };
}>, z.ZodObject<{
    role: z.ZodNativeEnum<{
        readonly Primary: "primary";
        readonly Secondary: "secondary";
        readonly Reasoning: "reasoning";
        readonly Embedding: "embedding";
        readonly Realtime: "realtime";
        readonly TextToSpeech: "tts";
        readonly SpeechToText: "speech2text";
        readonly ImageGeneration: "image";
        readonly VideoGeneration: "video";
        readonly Rerank: "rerank";
        readonly Moderation: "moderation";
    }>;
    mode: z.ZodLiteral<"inherit">;
}, "strict", z.ZodTypeAny, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "inherit";
}, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "inherit";
}>, z.ZodObject<{
    role: z.ZodNativeEnum<{
        readonly Primary: "primary";
        readonly Secondary: "secondary";
        readonly Reasoning: "reasoning";
        readonly Embedding: "embedding";
        readonly Realtime: "realtime";
        readonly TextToSpeech: "tts";
        readonly SpeechToText: "speech2text";
        readonly ImageGeneration: "image";
        readonly VideoGeneration: "video";
        readonly Rerank: "rerank";
        readonly Moderation: "moderation";
    }>;
    mode: z.ZodLiteral<"disabled">;
}, "strict", z.ZodTypeAny, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "disabled";
}, {
    role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
    mode?: "disabled";
}>]>;
export declare const saveRoleDefaultsSchema: z.ZodEffects<z.ZodObject<{
    defaults: z.ZodArray<z.ZodDiscriminatedUnion<"mode", [z.ZodObject<{
        role: z.ZodNativeEnum<{
            readonly Primary: "primary";
            readonly Secondary: "secondary";
            readonly Reasoning: "reasoning";
            readonly Embedding: "embedding";
            readonly Realtime: "realtime";
            readonly TextToSpeech: "tts";
            readonly SpeechToText: "speech2text";
            readonly ImageGeneration: "image";
            readonly VideoGeneration: "video";
            readonly Rerank: "rerank";
            readonly Moderation: "moderation";
        }>;
        mode: z.ZodLiteral<"fixed">;
        binding: z.ZodObject<{
            copilotId: z.ZodString;
            modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
            model: z.ZodString;
        } & {
            options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
        }, "strict", z.ZodTypeAny, {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        }, {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    }, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    }>, z.ZodObject<{
        role: z.ZodNativeEnum<{
            readonly Primary: "primary";
            readonly Secondary: "secondary";
            readonly Reasoning: "reasoning";
            readonly Embedding: "embedding";
            readonly Realtime: "realtime";
            readonly TextToSpeech: "tts";
            readonly SpeechToText: "speech2text";
            readonly ImageGeneration: "image";
            readonly VideoGeneration: "video";
            readonly Rerank: "rerank";
            readonly Moderation: "moderation";
        }>;
        mode: z.ZodLiteral<"inherit">;
    }, "strict", z.ZodTypeAny, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    }, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    }>, z.ZodObject<{
        role: z.ZodNativeEnum<{
            readonly Primary: "primary";
            readonly Secondary: "secondary";
            readonly Reasoning: "reasoning";
            readonly Embedding: "embedding";
            readonly Realtime: "realtime";
            readonly TextToSpeech: "tts";
            readonly SpeechToText: "speech2text";
            readonly ImageGeneration: "image";
            readonly VideoGeneration: "video";
            readonly Rerank: "rerank";
            readonly Moderation: "moderation";
        }>;
        mode: z.ZodLiteral<"disabled">;
    }, "strict", z.ZodTypeAny, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    }, {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    }>]>, "many">;
}, "strict", z.ZodTypeAny, {
    defaults?: ({
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    })[];
}, {
    defaults?: ({
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    })[];
}>, {
    defaults?: ({
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    })[];
}, {
    defaults?: ({
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "fixed";
        binding?: {
            options?: Record<string, string | number | boolean>;
            copilotId?: string;
            modelType?: AiModelTypeEnum;
            model?: string;
        };
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "inherit";
    } | {
        role?: "image" | "primary" | "realtime" | "rerank" | "speech2text" | "moderation" | "tts" | "video" | "secondary" | "reasoning" | "embedding";
        mode?: "disabled";
    })[];
}>;
export type RoleDefaultInput = z.output<typeof roleDefaultInputSchema>;
export interface RoleDefaultSetting {
    role: DefaultModelRole;
    mode: 'fixed' | 'inherit' | 'disabled' | 'legacy';
    binding: ModelBinding | null;
    sourceOrganizationId: string | null;
    connectionName?: string;
    inheritedBinding?: ModelBinding | null;
    inheritedAvailable?: boolean;
    available: boolean;
}
export declare function modelIdentityKey(model: Pick<ModelIdentity, 'modelType' | 'model'>): string;
export declare function sameModelIdentity(left?: Partial<ModelIdentity> | null, right?: Partial<ModelIdentity> | null): boolean;
export type ModelParameterPolicy = 'reset' | 'compatible';
export interface ModelParameterChange {
    name: string;
    before: unknown;
    after: unknown;
    action: 'retained' | 'reset' | 'removed';
}
/** Switching uses the target schema only; missing rules never preserve arbitrary old keys. */
export declare function transitionModelParameters(previous: Record<string, unknown> | undefined, rules: ParameterRule[], policy: ModelParameterPolicy): {
    options: Record<string, string | number | boolean>;
    missing: string[];
    changes: ModelParameterChange[];
};
export interface EnabledModelSelection {
    model: string;
    modelType: AiModelTypeEnum;
}
/** Undefined is a legacy catalog; an empty array deliberately enables nothing. */
export declare function isProviderModelEnabled(provider: Pick<ICopilotProvider, 'options'>, model: EnabledModelSelection): boolean;
export declare const enabledModelsSchema: z.ZodEffects<z.ZodObject<{
    models: z.ZodArray<z.ZodObject<Omit<{
        copilotId: z.ZodString;
        modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
        model: z.ZodString;
    }, "copilotId">, "strict", z.ZodTypeAny, {
        modelType?: AiModelTypeEnum;
        model?: string;
    }, {
        modelType?: AiModelTypeEnum;
        model?: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    models?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    }[];
}, {
    models?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    }[];
}>, {
    models?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    }[];
}, {
    models?: {
        modelType?: AiModelTypeEnum;
        model?: string;
    }[];
}>;
