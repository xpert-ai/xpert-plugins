export interface AssistantOrderItem {
    id?: string | null;
    createdAt?: Date | string | null;
}
export declare function orderAssistantXperts<T extends AssistantOrderItem>(items: T[], orderedIds?: string[]): T[];
