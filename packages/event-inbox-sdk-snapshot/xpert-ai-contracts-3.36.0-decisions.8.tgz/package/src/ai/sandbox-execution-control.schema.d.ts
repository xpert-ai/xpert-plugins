import { z } from 'zod/v3';
/** A control request can address only the original environment and execution generation. */
export declare const sandboxRuntimeTargetSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    kind: z.ZodEnum<["host", "engine"]>;
    provider: z.ZodString;
    runtimeProfile: z.ZodString;
    generation: z.ZodString;
    environmentId: z.ZodString;
    runtimeRef: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    provider?: string;
    generation?: string;
    kind?: "host" | "engine";
    environmentId?: string;
    runtimeProfile?: string;
    runtimeRef?: string;
}, {
    version?: 1;
    provider?: string;
    generation?: string;
    kind?: "host" | "engine";
    environmentId?: string;
    runtimeProfile?: string;
    runtimeRef?: string;
}>;
export type SandboxRuntimeTarget = z.output<typeof sandboxRuntimeTargetSchema>;
/** An accepted stop, closed stream, or expired lease is never an exit receipt. */
export declare const sandboxRuntimeEvidenceSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    target: z.ZodObject<{
        version: z.ZodLiteral<1>;
        kind: z.ZodEnum<["host", "engine"]>;
        provider: z.ZodString;
        runtimeProfile: z.ZodString;
        generation: z.ZodString;
        environmentId: z.ZodString;
        runtimeRef: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        version?: 1;
        provider?: string;
        generation?: string;
        kind?: "host" | "engine";
        environmentId?: string;
        runtimeProfile?: string;
        runtimeRef?: string;
    }, {
        version?: 1;
        provider?: string;
        generation?: string;
        kind?: "host" | "engine";
        environmentId?: string;
        runtimeProfile?: string;
        runtimeRef?: string;
    }>;
    state: z.ZodEnum<["running", "exited", "not_started", "unknown"]>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version?: 1;
    target?: {
        version?: 1;
        provider?: string;
        generation?: string;
        kind?: "host" | "engine";
        environmentId?: string;
        runtimeProfile?: string;
        runtimeRef?: string;
    };
    state?: "unknown" | "running" | "exited" | "not_started";
    observedAt?: string;
}, {
    version?: 1;
    target?: {
        version?: 1;
        provider?: string;
        generation?: string;
        kind?: "host" | "engine";
        environmentId?: string;
        runtimeProfile?: string;
        runtimeRef?: string;
    };
    state?: "unknown" | "running" | "exited" | "not_started";
    observedAt?: string;
}>;
export type SandboxRuntimeEvidence = z.output<typeof sandboxRuntimeEvidenceSchema>;
export declare function sandboxTargetsEqual(a: SandboxRuntimeTarget, b: SandboxRuntimeTarget): boolean;
export declare function sandboxEvidence(target: SandboxRuntimeTarget, state: SandboxRuntimeEvidence['state']): SandboxRuntimeEvidence;
/** Explicit new business retry; it may proceed only after this original generation settled. */
export declare const sandboxJobRetryReferenceSchema: z.ZodObject<{
    jobId: z.ZodString;
    generation: z.ZodString;
}, "strict", z.ZodTypeAny, {
    generation?: string;
    jobId?: string;
}, {
    generation?: string;
    jobId?: string;
}>;
export type SandboxJobRetryReference = z.output<typeof sandboxJobRetryReferenceSchema>;
