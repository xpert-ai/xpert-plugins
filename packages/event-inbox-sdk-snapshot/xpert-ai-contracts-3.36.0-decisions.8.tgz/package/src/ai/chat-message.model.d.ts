import { MessageType } from '@langchain/core/messages';
import type { ChatKitReference, ChatKitReferenceBase, TChatMessageStep, TChatTaskSummaryContribution, TMessageContent, TMessageContentReasoning } from '@xpert-ai/chatkit-types';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IChatConversation, TChatInputCheckpoint, TChatOutputCheckpoint, TChatMessageBranching } from './chat.model';
import { IXpertAgentExecution, XpertAgentExecutionStatusEnum } from './xpert-agent-execution.model';
import { JSONValue } from '../core.model';
import { IStorageFile } from '../storage-file.model';
import type { TChatMessageEnvelope } from './chat-message-envelope.model';
export type TChatElementAttribute = {
    name: string;
    value: string;
};
export type TChatElementReferenceFields = {
    attributes: TChatElementAttribute[];
    outerHtml: string;
    pageTitle?: string;
    pageUrl: string;
    role?: string;
    selector: string;
    serviceId: string;
    tagName: string;
};
export type TChatFileElementReferenceFields = {
    attributes: TChatElementAttribute[];
    documentTitle?: string;
    domPath: string;
    filePath: string;
    outerHtml: string;
    role?: string;
    selector: string;
    sourceEndLine?: number;
    sourceStartLine?: number;
    tagName: string;
    text: string;
};
export type TChatElementReferenceCandidateFields = {
    [Property in keyof TChatElementReferenceFields]?: unknown;
};
export type TChatFileElementReferenceCandidateFields = {
    [Property in keyof TChatFileElementReferenceFields]?: unknown;
};
export type TChatElementReference = ChatKitReferenceBase & TChatElementReferenceFields & {
    type: 'element';
};
export type TChatFileElementReference = ChatKitReferenceBase & TChatFileElementReferenceFields & {
    type: 'file_element';
};
export type TChatReference = ChatKitReference | TChatElementReference | TChatFileElementReference;
export * from './chat-message-envelope.model';
/**
 * Chat message entity type
 */
export interface IChatMessage extends IBasePerTenantAndOrganizationEntityModel, Omit<Omit<CopilotBaseMessage, 'createdAt'>, 'id'> {
    /**
     * Server-assigned order within a conversation using sequenced messages (currently group chat).
     * Stable across message updates; use for ordering/history cursors, not identity or cross-thread order.
     * Optional for legacy/unsequenced messages; distinct from the conversation's state revision.
     */
    sequence?: number;
    /** Persisted host-owned provenance; read-only through public message APIs. */
    messageEnvelope?: TChatMessageEnvelope | null;
    parent?: IChatMessage | null;
    children?: IChatMessage[];
    parentId?: string | null;
    inputCheckpoint?: TChatInputCheckpoint | null;
    /** Internal persisted state; excluded from public DTOs and raw stream events. */
    outputCheckpoint?: TChatOutputCheckpoint | null;
    /** Public capability derived from the finalized message, not inferred from executionId. */
    branching?: TChatMessageBranching;
    /** Copied execution history is display-only and must not restore live tool sessions. */
    historical?: boolean;
    /** Owned snapshot for a branch whose original execution may later be deleted. */
    historicalAgentRuns?: import('./xpert-agent-execution.model').TChatAgentRunSummary[];
    /**
     * @deprecated Chat attachments now use `fileAssets`. This field is kept only
     * for historical messages that stored raw StorageFile handles.
     */
    attachments?: IStorageFile[];
    /**
     * Parsed file assets used by the file understanding pipeline and agent tools.
     */
    fileAssets?: Array<{
        id?: string;
        storageFileId?: string;
        [key: string]: any;
    }>;
    /**
     * Structured references associated with the human input
     */
    references?: TChatReference[];
    /** Compact contribution used to rebuild the thread task summary. */
    taskSummary?: TChatTaskSummaryContribution;
    /**
     * the third-party platform's message
     */
    thirdPartyMessage?: any;
    /**
     * Step messages from tools or others
     */
    events?: TChatMessageStep[];
    /**
     * Chat conversation
     */
    conversation?: IChatConversation;
    conversationId?: string | null;
    /**
     * Runtime thread that originally created this message. A message may still
     * be visible from descendant threads through the message ancestor path.
     */
    createdInThreadId?: string | null;
    executionId?: string;
    execution?: IXpertAgentExecution;
    followUpMode?: 'queue' | 'steer';
    followUpStatus?: 'pending' | 'consumed' | 'canceled';
    targetExecutionId?: string | null;
    visibleAt?: Date | string | null;
}
/**
 * @deprecated
 */
export type DeprecatedMessageType = 'assistant' | 'user' | 'info' | 'component';
export type CopilotMessageType = MessageType | DeprecatedMessageType;
export type ChatMessageStatusEnum = XpertAgentExecutionStatusEnum | 'thinking' | 'reasoning' | 'answering' | 'aborted';
/**
 * BaseMessage or AIMessage in Langchain.js
 */
export interface CopilotBaseMessage {
    id?: string;
    createdAt?: Date;
    role: CopilotMessageType;
    /**
     * Status of the message:
     */
    status?: ChatMessageStatusEnum;
    content?: string | TMessageContent;
    /**
     * Reasoning step messages
     */
    reasoning?: TMessageContentReasoning[];
    /**
     * Error info when status is error
     */
    error?: string;
}
export type CopilotChatMessage = CopilotBaseMessage & {
    tool_call_id?: string;
    /**
     * If the message has a role of `function`, the `name` field is the name of the function.
     * Otherwise, the name field should not be set.
     */
    name?: string;
    data?: JSONValue;
    messages?: Array<any>;
    executionId?: string;
};
/**
 * @deprecated use data attr in message (subMessages)
 */
export interface CopilotMessageGroup extends CopilotBaseMessage {
    messages?: CopilotChatMessage[];
}
/**
 * @deprecated use content in message
 */
export declare function isMessageGroup(message: CopilotBaseMessage): message is CopilotMessageGroup;
