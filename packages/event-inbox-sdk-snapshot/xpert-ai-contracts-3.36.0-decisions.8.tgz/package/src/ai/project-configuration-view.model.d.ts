import { z } from 'zod/v3';
export declare const PROJECT_CONFIGURATION_PROVIDER = "platform.project-configuration";
export declare const PROJECT_CONFIGURATION_VIEW = "platform.project-configuration__configuration";
export declare const projectConfigurationSectionSchema: z.ZodEnum<["type", "experts", "members", "skills", "connectors", "automations", "delete"]>;
export type ProjectConfigurationSection = z.infer<typeof projectConfigurationSectionSchema>;
export declare const PROJECT_CONFIGURATION_ACTION_HANDLERS: {
    readonly type: "editors";
    readonly 'type-save': "editors";
    readonly experts: "editors";
    readonly 'expert-add': "editors";
    readonly 'expert-remove': "editors";
    readonly members: "editors";
    readonly 'member-add': "editors";
    readonly 'member-role': "editors";
    readonly 'member-remove': "editors";
    readonly 'member-owner': "editors";
    readonly 'member-invite': "editors";
    readonly 'invitation-revoke': "editors";
    readonly 'skill-catalog': "editors";
    readonly 'skill-install': "editors";
    readonly 'skill-toggle': "editors";
    readonly 'skill-remove': "editors";
    readonly connectors: "connectors";
    readonly 'connector-add': "connectors";
    readonly 'connector-remove': "connectors";
    readonly 'connector-connect': "connectors";
    readonly 'connector-status': "connectors";
    readonly 'connector-cancel': "connectors";
    readonly automations: "automations";
    readonly 'automation-save': "automations";
    readonly 'automation-options': "automations";
    readonly 'automation-pause': "automations";
    readonly 'automation-resume': "automations";
    readonly 'automation-delete': "automations";
    readonly 'automation-propose': "automations";
    readonly 'automation-accept': "automations";
    readonly 'automation-connectors': "automations";
    readonly delete: "editors";
};
export type ProjectConfigurationAction = keyof typeof PROJECT_CONFIGURATION_ACTION_HANDLERS;
export declare const projectConfigurationActionSchema: z.ZodType<"type" | "connectors" | "experts" | "members" | "delete" | "automations" | "type-save" | "expert-add" | "expert-remove" | "member-add" | "member-role" | "member-remove" | "member-owner" | "member-invite" | "invitation-revoke" | "skill-catalog" | "skill-install" | "skill-toggle" | "skill-remove" | "connector-add" | "connector-remove" | "connector-connect" | "connector-status" | "connector-cancel" | "automation-save" | "automation-options" | "automation-pause" | "automation-resume" | "automation-delete" | "automation-propose" | "automation-accept" | "automation-connectors", z.ZodTypeDef, "type" | "connectors" | "experts" | "members" | "delete" | "automations" | "type-save" | "expert-add" | "expert-remove" | "member-add" | "member-role" | "member-remove" | "member-owner" | "member-invite" | "invitation-revoke" | "skill-catalog" | "skill-install" | "skill-toggle" | "skill-remove" | "connector-add" | "connector-remove" | "connector-connect" | "connector-status" | "connector-cancel" | "automation-save" | "automation-options" | "automation-pause" | "automation-resume" | "automation-delete" | "automation-propose" | "automation-accept" | "automation-connectors">;
export declare const PROJECT_CONFIGURATION_ACTIONS: ("type" | "connectors" | "experts" | "members" | "delete" | "automations" | "type-save" | "expert-add" | "expert-remove" | "member-add" | "member-role" | "member-remove" | "member-owner" | "member-invite" | "invitation-revoke" | "skill-catalog" | "skill-install" | "skill-toggle" | "skill-remove" | "connector-add" | "connector-remove" | "connector-connect" | "connector-status" | "connector-cancel" | "automation-save" | "automation-options" | "automation-pause" | "automation-resume" | "automation-delete" | "automation-propose" | "automation-accept" | "automation-connectors")[];
/** Compact public projection; credentials and authoring Assistant graphs never enter the iframe. */
export interface ProjectConfigurationOverview {
    projectId: string;
    name: string;
    userId: string;
    canEdit: boolean;
    canManage: boolean;
    isOwner: boolean;
    applicationManaged: boolean;
    instruction: string;
    effectiveMaxDurationSeconds: number;
    tenantMaxDurationSeconds: number;
    experts: {
        id: string;
        name: string;
    }[];
    members: {
        id: string;
        name: string;
        role: 'owner' | 'manager' | 'editor' | 'member';
    }[];
    skills: {
        id: string;
        name: string;
        description?: string;
        enabled: boolean;
        skillIndexId?: string;
    }[];
    automations: {
        id: string;
        name: string;
        schedule: string;
        status: string;
    }[];
    automationTotal: number;
}
