import type { ChatTaskSummaryOutputKind } from '@xpert-ai/chatkit-types';
/** Display and validation formats for explicitly presented files; never automatic delivery policy. */
export type SandboxFileOutputRule = {
    extension: string;
    kind: ChatTaskSummaryOutputKind;
    mimeType: string;
    format: 'docx' | 'xlsx' | 'pptx' | 'pdf' | 'json' | 'utf8' | 'png' | 'jpeg' | 'binary';
};
export declare const SANDBOX_FILE_OUTPUT_RULES: readonly SandboxFileOutputRule[];
