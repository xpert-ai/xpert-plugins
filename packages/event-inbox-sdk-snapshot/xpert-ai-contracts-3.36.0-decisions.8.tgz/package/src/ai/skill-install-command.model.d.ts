export type ParsedGithubSkillInstallCommand = {
    repositoryUrl: string;
    repositoryPath: string;
    branch: string;
    skills: string[];
    installAll: boolean;
};
export type InstallGithubSkillPackagesInput = {
    url?: string;
    command?: string;
    path?: string;
    branch?: string;
    token?: string;
    skills?: string[];
};
export declare function parseGithubSkillInstallCommand(input: string): ParsedGithubSkillInstallCommand;
