import type { TChatConversationStatus } from './chat-activity.model';
export type { TChatConversationStatus, IChatConversationUnreadXpertSummary, IChatConversationUnreadSnapshot } from './chat-activity.model';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { IXpertAgentExecution } from './xpert-agent-execution.model';
import { IXpert } from './xpert.model';
import { I18nObject } from '../types';
import { CopilotChatMessage, CopilotMessageGroup, IChatMessage } from './chat-message.model';
import { IXpertAgent } from './xpert-agent.model';
import { IXpertProject } from './xpert-project.model';
import { IStorageFile } from '../storage-file.model';
import { IXpertTask } from './xpert-task.model';
import { TToolCall } from '../agent';
import { TInterrupt } from '../agent/interrupt';
import { IUser } from '../user.model';
import type { RuntimeCapabilitiesSelection } from '@xpert-ai/chatkit-types';
export type TChatConversationOptions = {
    /** First Project binding is deferred until a human submits the application's setup App. */
    projectCreation?: {
        status: 'awaiting_confirmation';
    } | {
        status: 'confirmed';
        confirmationId: string;
    };
    /** Preserve an explicit no-Project choice across reloads and subsequent sends. */
    projectSelection?: import('./project-selection.model').ProjectSelection;
    /** Persisted resources augment the entry Agent without changing the Assistant graph. */
    runtimeResources?: import('../agent-plugin').RuntimeResourcesSelection;
    parameters?: {
        input?: string;
        [key: string]: unknown;
    };
    knowledgebases?: string[];
    toolsets?: string[];
    features?: Array<'timeline' | 'sandbox' | 'files'>;
    workspacePath?: string;
    workspaceUrl?: string;
    workspaceRoot?: string;
    sharedWorkspacePath?: string;
    agentWorkspacePath?: string;
    sessionWorkspacePath?: string;
    memoryWorkspacePath?: string;
    sandboxEnvironmentId?: string;
    runtimeCapabilities?: RuntimeCapabilitiesSelection;
};
export type TChatConversationSourceAudit = {
    sourceIntegrationId?: string | null;
    channelType?: string | null;
    sourceMessageLogIds?: string[];
};
export type TChatCheckpointReference = {
    threadId: string;
    checkpointNs: string;
    checkpointId: string;
};
export type TChatInputCheckpoint = {
    version: 1;
    checkpoint: TChatCheckpointReference | null;
    graphRevision: string;
};
/**
 * Server-only graph boundary for an assistant reply. Capture first pins persisted
 * state; both hashes are added only after the final message and its path are saved.
 * An unsealed boundary must never enable branching in public message payloads.
 */
export type TChatOutputCheckpoint = {
    version: 1;
    /** Exact root-graph resume point; never substitute the thread's latest checkpoint. */
    checkpoint: TChatCheckpointReference;
    /** Root and child namespaces pinned while this execution still owns the thread. */
    checkpoints: TChatCheckpointReference[];
    /** Reject continuation if the published graph no longer matches this boundary. */
    graphRevision: string;
    options?: TChatConversationOptions;
    /** Hash of the finalized presentation; detects later edits to stored messages. */
    messageHash?: string;
    /** Hash of the ordered ancestor path, including the selected assistant reply. */
    messagePathHash?: string;
    /** Access must be checked again before linking these assets to a new conversation. */
    fileAssetIds?: string[];
    agentRuns?: import('./xpert-agent-execution.model').TChatAgentRunSummary[];
};
/** Copy the source thread's ancestor path through afterMessageId, inclusive. */
export type TConversationBranchRequest = {
    sourceThreadId: string;
    afterMessageId: string;
    /** Reuse this UUID for retries of one user attempt; changing parameters is a conflict. */
    requestId: string;
};
/** Audit data and retry identity, not foreign keys into the source conversation. */
export type TConversationBranchSource = {
    conversationId: string;
    threadId: string;
    messageId: string;
    requestId: string;
    naming?: TConversationBranchNaming;
};
/** Persisted numbering group; display titles are never parsed to infer ancestry. */
export type TConversationBranchNaming = {
    /** Stable numbering group retained even if its original conversation is deleted. */
    familyId: string;
    baseTitle: string;
    /** The original is implicitly 1; generated branches start at 2. */
    number: number;
    /** A different current title means the user renamed the branch and starts a new group. */
    generatedTitle: string;
};
/** Public capability reasons shared by history reads and message completion events. */
export type TChatMessageBranchUnavailableReason = 'message_not_complete' | 'checkpoint_unavailable' | 'graph_changed' | 'state_not_supported';
/** UI hint only; the branch endpoint revalidates access, state and graph compatibility. */
export type TChatMessageBranching = {
    available: boolean;
    reason?: TChatMessageBranchUnavailableReason;
};
/** @deprecated Legacy presentation metadata. Run control no longer stores or returns display snapshots. */
export type TChatThreadDisplayPause = {
    executionId: string;
    pauseId: string;
    createdAt: string;
    snapshot?: string;
};
export type TChatThreadRunControl = {
    executionId: string;
    state: 'running' | 'pausing' | 'paused' | 'terminating' | 'settling' | 'input_wait';
    /** Trusted checkpoint node names allowed to finish the current input continuation during pause. */
    inputNodes?: string[];
    /** Saved graph outcome while attached work still lacks settlement evidence. */
    pendingFinish?: {
        status: TChatConversationStatus;
        error?: string | null;
        operation?: TSensitiveOperation | null;
    };
    pauseId?: string;
    /** Fences late finalizers while a resume is claimed but not yet bound to its new execution. */
    resumeClaimed?: boolean;
    resumeClaimId?: string;
    graphRevision?: string;
    checkpoint?: TChatCheckpointReference;
};
/** Why a derived conversation thread was created. */
export declare const ChatThreadPurpose: {
    readonly SideChat: "side-chat";
    readonly MessageEdit: "message-edit";
};
export type TChatThreadPurpose = (typeof ChatThreadPurpose)[keyof typeof ChatThreadPurpose];
/** Machine-readable keys stored in `ChatConversationThread.metadata`. */
export type TChatThreadMetadata = {
    /** Server-owned admission for historical-message edits. */
    editAdmission?: import('./chat-recovery.model').TMessageEditAdmission;
    /** User-editable branch label, independent of the conversation title. */
    title?: string;
    primary?: boolean;
    purpose?: TChatThreadPurpose;
    /** Graph revision captured for a fork; cleared after the first successful run. */
    forkGraphRevision?: string;
    /** Client-provided idempotency key for branch creation. */
    forkRequestId?: string;
    /** Explicit copy semantics for validating idempotent retries. */
    forkMode?: 'latest-sealed-reply';
    [key: string]: unknown;
};
export type TToolCallType = 'agent' | 'tool';
/**
 * Conversation origin: built-in values and stable identifiers supplied by channel plugins.
 * Keep legacy values for stored conversations and editor completion; adding a channel
 * must not require a platform release. Attribution does not grant execution permissions.
 */
export type TChatFrom = 'platform' | 'webapp' | 'debugger' | 'knowledge' | 'job' | 'schedule' | 'api' | 'feishu' | 'lark' | 'dingtalk' | 'wecom' | 'wechat' | (string & {});
/**
 * Operation for interrupt
 */
export type TSensitiveOperation = {
    messageId?: string;
    tasks?: {
        name: string;
        interrupts: TInterrupt[];
        type?: TToolCallType;
        info?: {
            name: string;
            title?: string;
            description: string;
        };
        parameters?: {
            name: string;
            title: I18nObject | string;
            type: string;
            description: I18nObject | string;
            placeholder?: I18nObject | string;
        }[];
        call?: TToolCall;
        agent?: IXpertAgent;
    }[];
};
/**
 * Chat conversation for xpert ai agent.
 *
 * Corresponds to the thread in the [Agent Protocol](https://github.com/langchain-ai/agent-protocol).
 */
export interface IChatConversation extends IBasePerTenantAndOrganizationEntityModel {
    /** Optimistic concurrency token for the persisted working-thread selection. */
    workingThreadRevision?: number;
    /**
     * `private`: ordinary chat; `group`: shared public transcript; `group_assistant_runtime`:
     * one member Assistant's isolated execution history. Optional for legacy DTOs (treated as private).
     * Group xpertId identifies the primary Assistant; runtime records require separate access checks.
     */
    purpose?: 'private' | 'group' | 'group_assistant_runtime';
    /**
     * Server-maintained state version, currently used by group snapshots. Also advances for updates
     * that append no message (e.g. membership/delivery changes); not a count, sequence or replay cursor.
     */
    revision?: number;
    /**
     * Highest server-allocated message sequence in this conversation (zero before the first allocation).
     * Used for ordering/read positions, not the number of retained messages; updates reuse their sequence.
     */
    lastMessageSequence?: number;
    branchSource?: TConversationBranchSource | null;
    /**
     * Non-persistent, response-only field populated by the sidebar endpoint.
     * Not stored on the ChatConversation entity or in the chat_conversation table.
     * Values are persisted separately in the current user's Assistant preferences
     * under preferences.conversationSidebar[conversationId].
     *
     * @transient
     */
    sidebar?: TChatConversationSidebarState;
    /**
     * Thread id for agent execution
     */
    threadId: string;
    /**
     * A short title summarizing the session
     */
    title?: string;
    /**
     * Current status of conversation
     */
    status?: TChatConversationStatus;
    /**
     * Options
     */
    options?: TChatConversationOptions;
    /**
     * Stable source audit information for background/channel-triggered conversations.
     */
    sourceAudit?: TChatConversationSourceAudit | null;
    /**
     * Error message when status is error
     */
    error?: string;
    /**
     * ChatMessages in conversation
     */
    messages?: IChatMessage[] | null;
    /**
     * The last operation when interrupted
     */
    operation?: TSensitiveOperation;
    /**
     * Conversation source / user type
     */
    from: TChatFrom;
    /**
     * End anonymous user
     */
    fromEndUserId?: string;
    /**
     * Internal user matched by fromEndUserId when available
     */
    fromEndUser?: IUser;
    /**
     * Chat with Xpert
     */
    xpert?: IXpert;
    xpertId?: string | null;
    project?: IXpertProject;
    projectId?: string | null;
    task?: IXpertTask;
    taskId?: string | null;
    executions?: IXpertAgentExecution[];
    /**
     * @deprecated Conversation-level chat attachments are superseded by
     * per-message `fileAssets` and `ConversationFileLink`.
     */
    attachments?: IStorageFile[];
}
export type TChatConversationSidebarState = {
    pinned: boolean;
    archived: boolean;
};
export type TChatConversationLog = IChatConversation & {
    messageCount: number;
    sourceIntegrationId?: string | null;
    channelType?: string | null;
    sourceMessageLogIds?: string[];
};
export interface IChatConversationReadState extends IBasePerTenantAndOrganizationEntityModel {
    conversationId: string;
    userId: string;
    lastReadAt: Date | string;
    lastReadMessageId?: string | null;
}
export interface IChatConversationMarkReadRequest {
    lastReadMessageId?: string | null;
}
export interface IChatConversationUnreadXpertsRequest {
    xpertIds: string[];
    includePending?: boolean;
}
export type ChatMessage = {
    conversationId: string;
    id: string;
    content: string;
};
export type ChatUserMessage = ChatMessage & {
    language: string;
};
/**
 * @deprecated use ChatMessageEventTypeEnum
 */
export declare enum ChatGatewayEvent {
    ACK = "ack",// acknowledgment for received message
    ConversationCreated = "conversation_created",
    Message = "message",
    MessageStream = "message_stream",
    StepStart = "step_start",
    StepEnd = "step_end",
    ToolStart = "tool_start",
    ToolEnd = "tool_end",
    ChainStart = "chain_start",
    ChainEnd = "chain_end",
    CancelChain = "cancel_chain",
    ChainAborted = "chain_aborted",
    Error = "error",
    Agent = "agent"
}
/**
 * @deprecated use ChatMessageEventTypeEnum
 */
export type ChatGatewayMessage = {
    organizationId?: string;
    xpert?: {
        id: string;
        knowledgebases?: string[];
        toolsets: string[] | null;
    };
} & ({
    event: ChatGatewayEvent.CancelChain;
    data: {
        conversationId: string;
    };
} | {
    event: ChatGatewayEvent.ChainAborted;
    data: {
        conversationId: string;
        id?: string;
    };
} | {
    event: ChatGatewayEvent.ConversationCreated;
    data: IChatConversation;
} | {
    event: ChatGatewayEvent.MessageStream;
    data: ChatUserMessage;
} | {
    event: ChatGatewayEvent.ToolStart | ChatGatewayEvent.ToolEnd;
    data: CopilotMessageGroup | CopilotMessageGroup[];
} | {
    event: ChatGatewayEvent.ChainStart | ChatGatewayEvent.ChainEnd;
    data: {
        id: string;
    };
} | {
    event: ChatGatewayEvent.StepStart | ChatGatewayEvent.StepEnd;
    data: CopilotChatMessage;
} | {
    event: ChatGatewayEvent.Message | ChatGatewayEvent.Error;
    data: CopilotChatMessage;
} | {
    event: ChatGatewayEvent.Agent;
    data: {
        id: string;
        message: CopilotChatMessage;
    };
});
