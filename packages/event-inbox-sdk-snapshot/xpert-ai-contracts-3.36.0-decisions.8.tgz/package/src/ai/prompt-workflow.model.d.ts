import { IconDefinition } from '../types';
import { IBasePerWorkspaceEntityModel } from './xpert-workspace.model';
import { SkillSlashCommandAvailability } from './skill.model';
import { ITag } from '../tag-entity.model';
import type { ChatKitPromptScenario } from '@xpert-ai/chatkit-types';
export type PromptWorkflowScenario = ChatKitPromptScenario;
/** Boundary validation for persisted and API-provided scenario lists. */
export declare function isPromptWorkflowScenarios(value: unknown): value is PromptWorkflowScenario[];
export type PromptWorkflowVisibility = 'private' | 'team' | 'tenant';
export type PromptWorkflowSourceType = 'xpert' | 'workspace_prompt_workflow' | 'skill';
export type PromptWorkflowCommandPriority = 'normal' | 'preferred';
export type PromptWorkflowActionType = 'insert_text' | 'insert_invocation' | 'submit_prompt';
export type TPromptWorkflow = {
    name: string;
    label?: string;
    description?: string;
    icon?: string | IconDefinition | Record<string, unknown>;
    category?: string;
    aliases?: string[];
    argsHint?: string;
    template: string;
    /** insert_invocation inserts /name; insert_text expands the template; submit_prompt sends it. */
    actionType?: PromptWorkflowActionType;
    scenarios?: PromptWorkflowScenario[];
    tags?: string[];
    visibility?: PromptWorkflowVisibility;
    runtimeCapabilities?: unknown;
    archivedAt?: Date | string | null;
};
export interface IPromptWorkflow extends IBasePerWorkspaceEntityModel, TPromptWorkflow {
    organizationTags?: ITag[];
    /** Empty means every expert in this workspace. Stale IDs must not broaden the scope. */
    associatedXpertIds?: string[] | null;
}
export type PromptWorkflowInput = Partial<TPromptWorkflow> & {
    organizationTagIds?: string[];
    associatedXpertIds?: string[];
};
export type TPromptWorkflowCommandSnapshot = TPromptWorkflow & {
    workflowId?: string;
    workspaceId?: string;
};
export type TXpertCommandProfileEntry = {
    id?: string;
    source: PromptWorkflowSourceType;
    enabled?: boolean;
    order?: number;
    priority?: PromptWorkflowCommandPriority;
    workflowId?: string;
    skillCommandName?: string;
    snapshot?: TPromptWorkflowCommandSnapshot;
    name?: string;
    label?: string;
    description?: string;
    icon?: string | IconDefinition | Record<string, unknown>;
    category?: string;
    aliases?: string[];
    argsHint?: string;
    template?: string;
    actionType?: PromptWorkflowActionType;
    runtimeCapabilities?: unknown;
    availability?: SkillSlashCommandAvailability;
};
export type TXpertCommandProfile = {
    version: 1;
    enabled?: boolean;
    commands?: TXpertCommandProfileEntry[];
};
