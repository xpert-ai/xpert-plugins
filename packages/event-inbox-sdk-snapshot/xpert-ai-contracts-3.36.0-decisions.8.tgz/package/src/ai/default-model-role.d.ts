import { z } from 'zod';
import { AiModelTypeEnum } from '../agent/ai-model';
/** A default assignment's purpose, independent of connection identity and model type. */
export declare const DefaultModelRole: {
    readonly Primary: "primary";
    readonly Secondary: "secondary";
    readonly Reasoning: "reasoning";
    readonly Embedding: "embedding";
    readonly Realtime: "realtime";
    readonly TextToSpeech: "tts";
    readonly SpeechToText: "speech2text";
    readonly ImageGeneration: "image";
    readonly VideoGeneration: "video";
    readonly Rerank: "rerank";
    readonly Moderation: "moderation";
};
export declare const defaultModelRoleSchema: z.ZodNativeEnum<{
    readonly Primary: "primary";
    readonly Secondary: "secondary";
    readonly Reasoning: "reasoning";
    readonly Embedding: "embedding";
    readonly Realtime: "realtime";
    readonly TextToSpeech: "tts";
    readonly SpeechToText: "speech2text";
    readonly ImageGeneration: "image";
    readonly VideoGeneration: "video";
    readonly Rerank: "rerank";
    readonly Moderation: "moderation";
}>;
export type DefaultModelRole = z.output<typeof defaultModelRoleSchema>;
export declare const legacyProviderRoleSchema: z.ZodEnum<["primary", "secondary", "reasoning", "embedding"]>;
export type LegacyProviderRole = z.output<typeof legacyProviderRoleSchema>;
export interface DefaultModelDefinition {
    role: DefaultModelRole;
    modelType: AiModelTypeEnum;
    group: 'roles' | 'types';
    /** Only the compatibility adapter may use this legacy connection field. */
    legacyRole?: LegacyProviderRole;
}
export declare const DEFAULT_MODEL_DEFINITIONS: readonly DefaultModelDefinition[];
export declare function defaultModelDefinition(role: DefaultModelRole): DefaultModelDefinition;
