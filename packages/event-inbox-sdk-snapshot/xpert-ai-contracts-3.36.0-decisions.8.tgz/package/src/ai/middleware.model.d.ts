import { IWorkflowNode, WorkflowNodeTypeEnum } from './xpert-workflow.model';
import { I18nObject, I18nText, IconDefinition } from '../types';
import { TXpertFeatureKey, TXpertGraph, TXpertTeamNode } from './xpert.model';
import { JsonSchemaObjectType } from './types';
import type { SkillSlashCommand } from './skill.model';
export declare const LEGACY_SANDBOX_COMPRESSION_MIDDLEWARE_NAME = "SandboxCompressionMiddleware";
export declare const CONTEXT_COMPRESSION_MIDDLEWARE_NAME = "ContextCompressionMiddleware";
export declare const XPERT_FILE_MEMORY_MIDDLEWARE_NAME = "XpertFileMemoryMiddleware";
export declare const SKILLS_MIDDLEWARE_NAME = "skillsMiddleware";
export interface IWFNMiddleware extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.MIDDLEWARE;
    provider: string;
    /**
     * Required middlewares are always loaded at runtime and hidden from user-facing runtime selectors.
     */
    required?: boolean;
    /** Omission uses an empty configuration; explicit values are validated by the middleware. */
    options?: Record<string, any>;
    tools?: Record<string, TMiddlewareToolConfig | boolean>;
}
export type TMiddlewareToolConfig = {
    enabled?: boolean;
};
export declare function isMiddlewareToolEnabled(config?: TMiddlewareToolConfig | boolean): boolean;
export declare function isRequiredMiddleware(entity?: Pick<IWFNMiddleware, 'required'> | null): boolean;
/** Default only omitted options. Preserve null and other invalid values for provider validation. */
export declare function normalizeMiddlewareOptions<T>(options: T | undefined): T | Record<string, never>;
export declare function genXpertMiddlewareKey(): string;
export declare function normalizeMiddlewareProvider(provider?: string | null): string;
export declare function normalizeMiddlewareNode<T extends TXpertTeamNode>(node: T): T;
export declare function normalizeMiddlewareNodes<T extends TXpertTeamNode>(nodes?: T[] | null): T[];
export type TAgentMiddlewareMeta = {
    name: string;
    label: I18nObject;
    icon?: IconDefinition;
    description?: I18nObject;
    configSchema?: JsonSchemaObjectType;
    features?: Array<TXpertFeatureKey | string>;
    /** Optional display labels keyed by declared Feature identifier; never grants capabilities. */
    featureLabels?: Record<string, I18nObject>;
    slashCommands?: SkillSlashCommand[];
    builtin?: boolean;
    /**
     * Marks a middleware as deprecated while keeping it selectable/visible for migration.
     */
    deprecated?: boolean;
    /**
     * Optional user-facing migration guidance shown when the middleware is deprecated.
     */
    deprecationMessage?: I18nObject;
};
export type TAgentMiddlewareSource = {
    kind: 'builtin';
} | {
    kind: 'plugin';
    pluginName: string;
    displayName: I18nText;
    icon?: IconDefinition;
};
export type TAgentMiddlewareDescriptor = {
    meta: TAgentMiddlewareMeta;
    source: TAgentMiddlewareSource;
};
export declare function isUserAddableAgentMiddleware(meta?: Pick<TAgentMiddlewareMeta, 'builtin'> | null): boolean;
export declare function getAgentMiddlewareNodes(graph: TXpertGraph, agentKey: string): TXpertTeamNode[];
