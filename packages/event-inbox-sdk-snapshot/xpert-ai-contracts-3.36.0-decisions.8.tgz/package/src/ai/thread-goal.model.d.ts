import type { ThreadGoalSpec, ThreadGoalStatus } from '@xpert-ai/chatkit-types';
import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
export type { ThreadGoalSpec, ThreadGoalStatus } from '@xpert-ai/chatkit-types';
export declare const THREAD_GOAL_STATUS_VALUES: readonly ["active", "paused", "blocked", "usage_limited", "budget_limited", "complete"];
export type ThreadGoalUserStatus = Extract<ThreadGoalStatus, 'active' | 'paused'>;
export type ThreadGoalModelStatus = Extract<ThreadGoalStatus, 'complete' | 'blocked'>;
export interface IThreadGoal extends IBasePerTenantAndOrganizationEntityModel {
    conversationId: string;
    threadId: string;
    objective: string;
    goalSpec?: ThreadGoalSpec | null;
    status: ThreadGoalStatus;
    tokensUsed: number;
    elapsedSeconds: number;
    continuationCount: number;
    statusUpdatedAt?: Date | string | null;
    completedAt?: Date | string | null;
    blockedAt?: Date | string | null;
}
export type TThreadGoalSetRequest = {
    objective: string;
};
export type TThreadGoalPatchRequest = {
    objective?: string;
    status?: ThreadGoalUserStatus;
};
export declare function isRunnableThreadGoalStatus(status: ThreadGoalStatus | null | undefined): boolean;
