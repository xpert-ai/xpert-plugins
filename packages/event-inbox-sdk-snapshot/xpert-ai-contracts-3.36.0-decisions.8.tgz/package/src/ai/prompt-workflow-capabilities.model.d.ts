import type { RuntimeCapabilitiesSelection } from '@xpert-ai/chatkit-types';
/** Expert node keys are local to their graph. Resolve this config before sending it to ChatKit. */
export type PromptWorkflowCapabilityConfig = {
    type: 'expert_scoped_capabilities';
    version: 1;
    defaults?: RuntimeCapabilitiesSelection | null;
    experts: Array<{
        xpertId: string;
        selection: RuntimeCapabilitiesSelection | null;
    }>;
};
export declare function parsePromptCapabilitySelection(value: unknown): RuntimeCapabilitiesSelection | null;
export declare function isScopedPromptCapabilityConfig(value: unknown): boolean;
export declare function parsePromptCapabilityConfig(value: unknown): PromptWorkflowCapabilityConfig | null;
export declare function resolvePromptWorkflowCapabilities(value: unknown, xpertId?: string): unknown;
