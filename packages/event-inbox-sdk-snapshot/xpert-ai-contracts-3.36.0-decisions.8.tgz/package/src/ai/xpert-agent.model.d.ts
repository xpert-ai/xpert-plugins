import { IBasePerTenantAndOrganizationEntityModel } from '../base-entity.model';
import { ICopilotModel, TCopilotModel } from './copilot-model.model';
import { IKnowledgebase, TKBRecallParams } from './knowledgebase.model';
import { I18nObject, TAvatar } from '../types';
import { IXpertToolset } from './xpert-toolset.model';
import { IXpert, TXpertParameter } from './xpert.model';
import { TVariableAssigner } from './xpert-workflow.model';
import { TErrorHandling } from './types';
export type TXpertAgent = {
    key: string;
    name?: string;
    title?: string;
    description?: string;
    avatar?: TAvatar;
    /**
     * System prompt
     */
    prompt?: string;
    /**
     * Prompt templates (ai or human)
     */
    promptTemplates?: TAgentPromptTemplate[];
    /**
     * Input parameters for agent
     */
    parameters?: TXpertParameter[];
    /**
     * Output variables of agent
     */
    outputVariables?: TAgentOutputVariable[];
    /**
     * More configuration
     */
    options?: TXpertAgentOptions;
    /**
     * This is the xpert's primary agent
     */
    xpert?: IXpert;
    xpertId?: string;
    /**
     * Copilot model of this agent
     */
    copilotModel?: ICopilotModel;
    copilotModelId?: string;
    /**
     * This is one of the xpert team's agent
     */
    team?: IXpert;
    teamId?: string;
    /**
     * My leader in xpert team
     */
    leader?: IXpertAgent;
    leaderKey?: string;
    /**
     * I am the leader of followers in xpert's team
     */
    followers?: IXpertAgent[];
    /**
     * External xpert teams
     */
    collaborators?: IXpert[];
    collaboratorNames?: string[];
    /**
     * I used toolsets
     */
    toolsets?: IXpertToolset[];
    toolsetIds?: string[];
    /**
     * I used knowledgebases
     */
    knowledgebases?: IKnowledgebase[];
    knowledgebaseIds?: string[];
};
/**
 * Expert agent, ai agent for the xperts.
 */
export interface IXpertAgent extends IBasePerTenantAndOrganizationEntityModel, TXpertAgent {
}
export type TXpertAgentOptions = {
    /**
     * Hide this agent node in the graph
     */
    hidden?: boolean;
    /**
     * Disable message history for agent conversation
     */
    disableMessageHistory?: boolean;
    /**
     * The variable of message history to use
     */
    historyVariable?: string;
    /**
     * Write output variables to memory (state)
     */
    memories?: TVariableAssigner[];
    /**
     * Whether to enable parallel tool calls, default: true
     */
    parallelToolCalls?: boolean;
    /**
     * Retry on failure
     */
    retry?: {
        enabled?: boolean;
        stopAfterAttempt?: number;
    };
    /**
     * Fallback model
     */
    fallback?: {
        enabled?: boolean;
        copilotModel?: TCopilotModel;
    };
    /**
     * Error handling
     */
    errorHandling?: TErrorHandling;
    /**
     * Recall params for kbs
     */
    recall?: TKBRecallParams;
    /**
     * Available tools
     */
    availableTools?: Record<string, string[]>;
    /**
     * Options for tools of agent
     */
    tools?: Record<string, {
        timeout?: number;
    }>;
    /**
     * How to achieve structured output (`StructuredOutputMethodOptions['method']`)
     * - *functionCalling*
     * - *jsonMode*
     * - *jsonSchema*
     *
     */
    structuredOutputMethod?: 'functionCalling' | 'jsonMode' | 'jsonSchema' | string;
    /**
     * @deprecated use attachment
     */
    vision?: TXpertAgentVision;
    /**
     * Attachment config of agent
     */
    attachment?: TXpertAgentAttachment;
    /**
     * Built-in file understanding tools config of agent
     */
    fileUnderstanding?: TXpertAgentFileUnderstanding;
    /**
     * Config of middlewares for agent
     */
    middlewares?: {
        order: string[];
    };
};
export type TXpertAgentVision = {
    enabled?: boolean;
    /**
     * Variable name that store the list of files to be understood
     */
    variable?: string;
    /**
     * Image resolution for vision tasks
     */
    resolution?: 'high' | 'low';
};
export type TXpertAgentAttachment = TXpertAgentVision & {
    /**
     * Max number of files to be processed
     */
    maxNum?: number;
};
export type TXpertAgentFileUnderstanding = {
    /**
     * Enable built-in tools for understanding conversation files. Default: true
     */
    enabled?: boolean;
};
export type TAgentPromptTemplate = {
    id: string;
    role: 'ai' | 'human';
    text: string;
};
export type TAgentOutputVariable = TXpertParameter & {
    /**
     * value write to state's variable
     */
    variableSelector: string;
    /**
     * How to write value to variable
     */
    operation: 'append' | 'extends' | 'overwrite' | 'clear';
};
export declare function agentLabel(agent: Partial<IXpertAgent>): string;
export declare function agentUniqueName(agent: IXpertAgent): string;
export declare function convertToUrlPath(title: string): string;
export declare const VariableOperations: {
    value: TAgentOutputVariable['operation'];
    label: I18nObject;
}[];
