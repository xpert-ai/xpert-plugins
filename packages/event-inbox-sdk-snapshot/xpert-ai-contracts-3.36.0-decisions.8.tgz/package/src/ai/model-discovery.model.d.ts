import { z } from 'zod';
import { AiModelTypeEnum } from '../agent/ai-model';
import { AIModelEntity, ModelFeature, ProviderModel } from './ai-model.model';
import type { ICopilotProvider, ICopilotProviderModel } from './copilot-provider.model';
export declare const discoverableModelTypes: readonly [AiModelTypeEnum.LLM, AiModelTypeEnum.TEXT_EMBEDDING, AiModelTypeEnum.RERANK];
export type DiscoverableModelType = (typeof discoverableModelTypes)[number];
export declare const DEFAULT_EMBEDDING_BATCH_SIZE = 10;
/** Saved model configuration is explicit; name heuristics are only discovery suggestions. */
export declare const modelConfigurationSchema: z.ZodEffects<z.ZodDiscriminatedUnion<"modelType", [z.ZodObject<{
    maxOutputTokens: z.ZodNumber;
    defaultMaxTokens: z.ZodNumber;
    features: z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">;
    contextSize: z.ZodNumber;
    maxConcurrency: z.ZodNumber;
    modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
}, "strict", z.ZodTypeAny, {
    modelType?: AiModelTypeEnum.LLM;
    maxOutputTokens?: number;
    defaultMaxTokens?: number;
    features?: ModelFeature[];
    contextSize?: number;
    maxConcurrency?: number;
}, {
    modelType?: AiModelTypeEnum.LLM;
    maxOutputTokens?: number;
    defaultMaxTokens?: number;
    features?: ModelFeature[];
    contextSize?: number;
    maxConcurrency?: number;
}>, z.ZodObject<{
    dimensions: z.ZodOptional<z.ZodNumber>;
    batchSize: z.ZodNumber;
    contextSize: z.ZodNumber;
    maxConcurrency: z.ZodNumber;
    modelType: z.ZodLiteral<AiModelTypeEnum.TEXT_EMBEDDING>;
}, "strict", z.ZodTypeAny, {
    modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
    contextSize?: number;
    maxConcurrency?: number;
    dimensions?: number;
    batchSize?: number;
}, {
    modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
    contextSize?: number;
    maxConcurrency?: number;
    dimensions?: number;
    batchSize?: number;
}>, z.ZodObject<{
    contextSize: z.ZodNumber;
    maxConcurrency: z.ZodNumber;
    modelType: z.ZodLiteral<AiModelTypeEnum.RERANK>;
}, "strict", z.ZodTypeAny, {
    modelType?: AiModelTypeEnum.RERANK;
    contextSize?: number;
    maxConcurrency?: number;
}, {
    modelType?: AiModelTypeEnum.RERANK;
    contextSize?: number;
    maxConcurrency?: number;
}>]>, {
    modelType?: AiModelTypeEnum.LLM;
    maxOutputTokens?: number;
    defaultMaxTokens?: number;
    features?: ModelFeature[];
    contextSize?: number;
    maxConcurrency?: number;
} | {
    modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
    contextSize?: number;
    maxConcurrency?: number;
    dimensions?: number;
    batchSize?: number;
} | {
    modelType?: AiModelTypeEnum.RERANK;
    contextSize?: number;
    maxConcurrency?: number;
}, {
    modelType?: AiModelTypeEnum.LLM;
    maxOutputTokens?: number;
    defaultMaxTokens?: number;
    features?: ModelFeature[];
    contextSize?: number;
    maxConcurrency?: number;
} | {
    modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
    contextSize?: number;
    maxConcurrency?: number;
    dimensions?: number;
    batchSize?: number;
} | {
    modelType?: AiModelTypeEnum.RERANK;
    contextSize?: number;
    maxConcurrency?: number;
}>;
export type ModelConfiguration = z.output<typeof modelConfigurationSchema>;
export declare function defaultModelConfiguration(modelType: DiscoverableModelType): ModelConfiguration;
/** Start with editable defaults and overlay the matching built-in YAML values. */
export declare function configurationFromModel(modelType: ModelConfiguration['modelType'], model?: Partial<AIModelEntity>): ModelConfiguration;
export declare function isDiscoverableModelType(value: unknown): value is DiscoverableModelType;
/** Parse the persisted JSON field once when entering the model configuration boundary. */
export declare function readModelConfiguration(properties?: {
    model_configuration?: unknown;
} | null): ModelConfiguration | undefined;
/** Legacy fallback only; explicit model_configuration.features remains authoritative. */
export declare function legacyModelFeatures(properties?: Record<string, unknown> | null): ModelFeature[];
export interface DiscoveredModel {
    /** Exact ID returned by the upstream discovery endpoint. */
    model: string;
    label: string;
    modelType: DiscoverableModelType | null;
    typeSource: 'provider' | 'catalog' | 'name' | 'unknown';
    configuration?: ModelConfiguration;
    /** Adapter-owned, non-secret settings such as an exact endpoint model ID or rerank path. */
    modelProperties?: Record<string, string | number | boolean>;
}
/** Last successful, explicitly saved account catalog; failed previews never change it. */
export interface ModelDiscoveryState {
    mode: 'configured';
    syncedAt: string;
    availableModelIds: string[];
}
export type ProviderModelSource = 'builtin' | 'discovered' | 'manual';
export declare function configuredModelSource(model: Pick<ICopilotProviderModel, 'modelProperties'>): Exclude<ProviderModelSource, 'builtin'>;
export declare function usesConfiguredModelCatalog(provider: Pick<ICopilotProvider, 'options'>): boolean;
/** Shared by management UI, pickers and execution authorization. Manual additions remain explicit opt-ins. */
export declare function isConfiguredModelAvailable(provider: Pick<ICopilotProvider, 'options'>, model?: Pick<ICopilotProviderModel, 'modelProperties'> | null): boolean;
export interface ModelDiscoveryItem extends DiscoveredModel {
    configured: boolean;
    configuredModelId?: string;
    source: Exclude<ProviderModelSource, 'builtin'>;
    available: boolean;
}
export interface ModelDiscoveryResult {
    models: ModelDiscoveryItem[];
}
export interface ProviderModelCatalog {
    custom: ICopilotProviderModel[];
    /** Reference metadata, not proof of account access. */
    builtin: Array<ProviderModel & Partial<Pick<AIModelEntity, 'parameter_rules'>>>;
    discoverySupported: boolean;
    modelDiscovery?: ModelDiscoveryState;
    enabledModels?: import('./model-management.model').EnabledModelSelection[];
}
export declare const modelImportSchema: z.ZodEffects<z.ZodObject<{
    models: z.ZodArray<z.ZodObject<{
        model: z.ZodString;
        configuration: z.ZodEffects<z.ZodDiscriminatedUnion<"modelType", [z.ZodObject<{
            maxOutputTokens: z.ZodNumber;
            defaultMaxTokens: z.ZodNumber;
            features: z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">;
            contextSize: z.ZodNumber;
            maxConcurrency: z.ZodNumber;
            modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
        }, "strict", z.ZodTypeAny, {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        }, {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        }>, z.ZodObject<{
            dimensions: z.ZodOptional<z.ZodNumber>;
            batchSize: z.ZodNumber;
            contextSize: z.ZodNumber;
            maxConcurrency: z.ZodNumber;
            modelType: z.ZodLiteral<AiModelTypeEnum.TEXT_EMBEDDING>;
        }, "strict", z.ZodTypeAny, {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        }, {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        }>, z.ZodObject<{
            contextSize: z.ZodNumber;
            maxConcurrency: z.ZodNumber;
            modelType: z.ZodLiteral<AiModelTypeEnum.RERANK>;
        }, "strict", z.ZodTypeAny, {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        }, {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        }>]>, {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        }, {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        }>;
    }, "strict", z.ZodTypeAny, {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }, {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    models?: {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }[];
}, {
    models?: {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }[];
}>, {
    models?: {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }[];
}, {
    models?: {
        model?: string;
        configuration?: {
            modelType?: AiModelTypeEnum.LLM;
            maxOutputTokens?: number;
            defaultMaxTokens?: number;
            features?: ModelFeature[];
            contextSize?: number;
            maxConcurrency?: number;
        } | {
            modelType?: AiModelTypeEnum.TEXT_EMBEDDING;
            contextSize?: number;
            maxConcurrency?: number;
            dimensions?: number;
            batchSize?: number;
        } | {
            modelType?: AiModelTypeEnum.RERANK;
            contextSize?: number;
            maxConcurrency?: number;
        };
    }[];
}>;
export type ModelImportInput = z.output<typeof modelImportSchema>;
export interface ModelImportResult {
    added: number;
    skipped: number;
}
