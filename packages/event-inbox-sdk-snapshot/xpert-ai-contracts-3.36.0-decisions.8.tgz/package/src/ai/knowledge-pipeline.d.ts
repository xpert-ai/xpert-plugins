import { I18nObject, IconDefinition } from '../types';
import { ICopilotModel } from './copilot-model.model';
import { KnowledgeStructureEnum } from './knowledgebase.model';
import { IWorkflowNode, WorkflowNodeTypeEnum } from './xpert-workflow.model';
import { TXpertParameter } from './xpert.model';
export interface IDocumentNodeProvider {
    name: string;
    label: I18nObject;
    icon?: IconDefinition;
    description?: I18nObject;
    helpUrl?: string;
    configSchema: any;
}
/**
 * Category of document source provider
 */
export declare enum DocumentSourceProviderCategoryEnum {
    /**
     * Local files uploaded directly to the system
     */
    LocalFile = "local-file",
    /**
     * Remote file systems, e.g. S3, FTP, etc.
     */
    FileSystem = "file-system",
    /**
     * Online documents, e.g. public URLs, Google Docs, etc.
     */
    OnlineDocument = "online-document",
    /**
     * Web crawling from public websites
     */
    WebCrawl = "web-crawl",
    /**
     * Database connections, e.g. MySQL, PostgreSQL, etc.
     * @deprecated Planning
     */
    Database = "database"
}
export interface IDocumentSourceProvider extends IDocumentNodeProvider {
    category: DocumentSourceProviderCategoryEnum;
}
export interface IDocumentProcessorProvider extends IDocumentNodeProvider {
    /** Where new parser options are configured; omitted keeps legacy document-level forms. */
    configScope?: 'document' | 'integration';
    /** Explicit file extensions supported for per-format knowledgebase defaults. */
    supportedFileTypes?: string[];
    /** Converter already extracts image text; run an additional image pass only when explicitly enabled. */
    providesImageText?: boolean;
}
export interface IDocumentChunkerProvider extends IDocumentNodeProvider {
    structure?: KnowledgeStructureEnum;
    /** Opt into the public language context without changing legacy token/structure capabilities. */
    supportsLanguageHint?: boolean;
    /** Optional capabilities; absence keeps the legacy provider form and execution behavior. */
    chunkingCapabilities?: {
        size: 'target' | 'strategy-dependent' | 'maximum';
        separators: boolean;
        tokenBudget: boolean;
    };
}
export interface IDocumentUnderstandingProvider extends IDocumentNodeProvider {
}
/**
 * Knowledge Pipeline Source Node
 */
export interface IWFNSource<T = any> extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.SOURCE;
    provider: string;
    parameters?: TXpertParameter[];
    config: T;
    integrationId?: string;
}
export interface IWFNProcessor extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.PROCESSOR;
    provider: string;
    config: any;
    input: string;
    integrationId?: string;
}
export interface IWFNChunker extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.CHUNKER;
    provider: string;
    config: any;
    input: string;
}
export interface IWFNUnderstanding extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.UNDERSTANDING;
    provider: string;
    config: any;
    input: string;
    visionModel?: ICopilotModel;
}
export interface IWFNKnowledgeBase extends IWorkflowNode {
    type: WorkflowNodeTypeEnum.KNOWLEDGE_BASE;
    /**
     * @deprecated
     */
    structure?: KnowledgeStructureEnum;
    /**
     * Documents input variables
     */
    inputs?: string[];
    /**
     * @deprecated Configure embedding model on the knowledgebase.
     */
    copilotModel?: ICopilotModel;
    /**
     * @deprecated Configure rerank model on the knowledgebase.
     */
    rerankModel?: ICopilotModel;
    /**
     * @deprecated Configure chat model on the knowledgebase.
     */
    chatModel?: ICopilotModel;
    /**
     * @deprecated Configure vision model on the knowledgebase.
     */
    visionModel?: ICopilotModel;
    documents?: string[];
}
export declare function genPipelineSourceKey(): string;
export declare function genPipelineProcessorKey(): string;
export declare function genPipelineChunkerKey(): string;
export declare function genPipelineUnderstandingKey(): string;
export declare function genPipelineKnowledgeBaseKey(): string;
