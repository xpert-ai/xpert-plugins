import { IntegrationEnum } from "../integration.model";
import { TParameter, TSelectOption } from "../types";
import { IKnowledgeDocumentPage } from "./knowledge-doc-page.model";
export declare enum KDocumentWebTypeEnum {
    Playwright = "playwright",
    FireCrawl = "firecrawl",
    Notion = "notion"
}
export type TRagWebOptions = {
    url: string;
    params?: Record<string, unknown>;
};
export type TKDocumentWebSchema = {
    type: KDocumentWebTypeEnum;
    helpUrl: string;
    options: TParameter[];
    /**
     * Need to provide integration of provider
     */
    integrationProvider?: IntegrationEnum;
};
export type TRagWebResult = {
    docs: IKnowledgeDocumentPage[];
    duration: number;
};
export declare const KDocumentWebTypeOptions: TSelectOption<KDocumentWebTypeEnum>[];
