import type { TMessageContent, TMessageContentComplex } from '@xpert-ai/chatkit-types';
import { CopilotChatMessage } from './chat-message.model';
export type TMessageJoinHint = 'none' | 'space' | 'line' | 'paragraph';
export type TMessageAppendContext = {
    source?: string;
    streamId?: string;
    joinHint?: TMessageJoinHint;
};
export type TAppendMessageContentOptions = TMessageAppendContext & {
    previous?: TMessageAppendContext | null;
};
export type TResolveMessageAppendContextOptions = {
    previous?: TMessageAppendContext | null;
    incoming: string | TMessageContentComplex;
    fallbackSource?: string;
    fallbackStreamId?: string;
};
export type TResolvedMessageAppendContext = {
    appendContext: TMessageAppendContext;
    messageContext: TMessageAppendContext;
};
export type TMessageAppendContextTracker = {
    resolve: (options: Omit<TResolveMessageAppendContextOptions, 'previous'>) => TResolvedMessageAppendContext;
    reset: () => void;
    current: () => TMessageAppendContext | null;
};
export declare function inferMessageAppendContext(content: string | TMessageContentComplex, fallbackSource?: string): TMessageAppendContext;
export declare function resolveMessageAppendContext(options: TResolveMessageAppendContextOptions): TResolvedMessageAppendContext;
/**
 * Stateful helper for streaming append.
 *
 * It keeps the previous append context and resolves the current one, so callers
 * can avoid passing `previous` manually for every chunk and still get stable
 * join behavior (for example, same source + same stream -> `joinHint: 'none'`).
 *
 * Call `reset()` at turn/session boundaries to prevent cross-turn contamination.
 */
export declare function createMessageAppendContextTracker(initial?: TMessageAppendContext | null): TMessageAppendContextTracker;
/**
 * Append one incoming chunk into a chat message in place.
 *
 * Behavior:
 * - Keeps `aiMessage` object reference stable (caller may hold this object).
 * - Updates message properties with new references (`content`/`reasoning` arrays)
 *   so UI change detection that relies on reference changes can react reliably.
 * - Applies context-aware merge rules for text/reasoning/component chunks.
 * - `previous` must be supplied by caller when same-stream join inference is needed.
 */
export declare function appendMessageContent(aiMessage: CopilotChatMessage, incoming: string | TMessageContentComplex, context?: TAppendMessageContentOptions): void;
export declare function appendMessagePlainText(accumulator: string, incoming: string | TMessageContentComplex, context?: TMessageAppendContext): string;
/**
 * Creates a display-only content view that reassembles text chunks belonging to
 * the same stream id. This preserves markdown continuity without changing the
 * underlying stored/streamed message structure.
 */
export declare function mergeMessageContentForDisplay(content: TMessageContent | TMessageContentComplex | null | undefined): TMessageContentComplex[] | null;
export declare function stringifyMessageContent(content: TMessageContent | TMessageContentComplex): string;
export declare function filterMessageText(content: TMessageContent | TMessageContentComplex): string;
