export declare const CONNECTION_REFERENCE_KINDS: readonly ["defaults", "assistants", "knowledgebases", "projects", "connections", "gateways", "membershipPlans", "accessGrants", "accessRequests", "executions", "voiceSessions"];
export type ConnectionReferenceKind = (typeof CONNECTION_REFERENCE_KINDS)[number];
/** Current business dependencies that prevent permanent connection removal. */
export interface ConnectionDeletionImpact {
    enabled: boolean;
    canDelete: boolean;
    references: Record<ConnectionReferenceKind, number>;
}
