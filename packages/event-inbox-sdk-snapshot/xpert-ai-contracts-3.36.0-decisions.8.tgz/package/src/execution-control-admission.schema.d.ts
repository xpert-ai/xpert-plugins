import { z } from 'zod';
/** Internal boot capabilities. Online/readiness and execution settlement remain separate facts. */
export declare const executionControlProtocols: {
    readonly taskControl: 2;
    readonly managedQueue: 3;
    readonly threadControlView: 1;
    readonly mcpControl: 1;
    readonly sandboxControl: 1;
    readonly invocationEvidence: 2;
};
export type ExecutionControlCapability = keyof typeof executionControlProtocols;
export declare const controlledHandlerSchema: z.ZodObject<{
    pluginName: z.ZodString;
    queueName: z.ZodString;
    jobName: z.ZodString;
    scopeKey: z.ZodNullable<z.ZodString>;
    controlContract: z.ZodString;
}, "strict", z.ZodTypeAny, {
    pluginName?: string;
    scopeKey?: string;
    queueName?: string;
    jobName?: string;
    controlContract?: string;
}, {
    pluginName?: string;
    scopeKey?: string;
    queueName?: string;
    jobName?: string;
    controlContract?: string;
}>;
export type ControlledHandlerCapability = z.infer<typeof controlledHandlerSchema>;
export declare const executionControlCapabilitiesSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    validUntil: z.ZodNumber;
    protocols: z.ZodObject<{
        taskControl: z.ZodOptional<z.ZodLiteral<2>>;
        managedQueue: z.ZodOptional<z.ZodLiteral<3>>;
        threadControlView: z.ZodOptional<z.ZodLiteral<1>>;
        mcpControl: z.ZodOptional<z.ZodLiteral<1>>;
        sandboxControl: z.ZodOptional<z.ZodLiteral<1>>;
        invocationEvidence: z.ZodOptional<z.ZodLiteral<2>>;
    }, "strict", z.ZodTypeAny, {
        taskControl?: 2;
        managedQueue?: 3;
        threadControlView?: 1;
        mcpControl?: 1;
        sandboxControl?: 1;
        invocationEvidence?: 2;
    }, {
        taskControl?: 2;
        managedQueue?: 3;
        threadControlView?: 1;
        mcpControl?: 1;
        sandboxControl?: 1;
        invocationEvidence?: 2;
    }>;
    queuePrefix: z.ZodString;
    queuePools: z.ZodArray<z.ZodEnum<["default", "sandbox-browser"]>, "many">;
    handlers: z.ZodArray<z.ZodObject<{
        pluginName: z.ZodString;
        queueName: z.ZodString;
        jobName: z.ZodString;
        scopeKey: z.ZodNullable<z.ZodString>;
        controlContract: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        pluginName?: string;
        scopeKey?: string;
        queueName?: string;
        jobName?: string;
        controlContract?: string;
    }, {
        pluginName?: string;
        scopeKey?: string;
        queueName?: string;
        jobName?: string;
        controlContract?: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    validUntil?: number;
    version?: 1;
    protocols?: {
        taskControl?: 2;
        managedQueue?: 3;
        threadControlView?: 1;
        mcpControl?: 1;
        sandboxControl?: 1;
        invocationEvidence?: 2;
    };
    queuePrefix?: string;
    queuePools?: ("default" | "sandbox-browser")[];
    handlers?: {
        pluginName?: string;
        scopeKey?: string;
        queueName?: string;
        jobName?: string;
        controlContract?: string;
    }[];
}, {
    validUntil?: number;
    version?: 1;
    protocols?: {
        taskControl?: 2;
        managedQueue?: 3;
        threadControlView?: 1;
        mcpControl?: 1;
        sandboxControl?: 1;
        invocationEvidence?: 2;
    };
    queuePrefix?: string;
    queuePools?: ("default" | "sandbox-browser")[];
    handlers?: {
        pluginName?: string;
        scopeKey?: string;
        queueName?: string;
        jobName?: string;
        controlContract?: string;
    }[];
}>;
export type ExecutionControlCapabilities = z.infer<typeof executionControlCapabilitiesSchema>;
