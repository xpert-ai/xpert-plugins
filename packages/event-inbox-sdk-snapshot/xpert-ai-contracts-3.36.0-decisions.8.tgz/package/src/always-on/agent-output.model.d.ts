import { agentOutputReferenceSchema } from './agent-output-reference.schema';
import { type HumanDecision } from './human-decision.model';
import { z } from 'zod/v3';
import { type OpenConversationAction } from '../user-notification.schema';
/** HTTP Accept profile for notification clients that can display agent outputs in list and sync responses. */
export declare const AGENT_OUTPUT_ACCEPT = "application/json; profile=\"xpert-agent-output-v1\"";
/**
 * A labeled value the source has cleared for this recipient. Notification details and private
 * decision cards share these display fields, for example a supplier's proposed delivery date.
 */
export type AgentOutputField = {
    label: {
        en_US: string;
        zh_Hans: string;
    };
    value: string;
};
/**
 * One readable result in an in-app notification, which may group several results. The id
 * identifies the delivery member. The host adds a conversation action when navigation is authorized.
 */
export interface AgentOutputItem {
    id: string;
    title: string;
    action: OpenConversationAction | null;
    fields?: AgentOutputField[];
}
/** Validates the local delivery window against its time zone, including windows that span midnight. */
export declare const outputQuietHoursSchema: z.ZodEffects<z.ZodObject<{
    zone: z.ZodEffects<z.ZodString, string, string>;
    start: z.ZodString;
    end: z.ZodString;
}, "strict", z.ZodTypeAny, {
    start: string;
    zone: string;
    end: string;
}, {
    start: string;
    zone: string;
    end: string;
}>, {
    start: string;
    zone: string;
    end: string;
}, {
    start: string;
    zone: string;
    end: string;
}>;
/**
 * A recipient's daily quiet period in local time. Outputs arriving during the period can
 * be grouped for delivery when it ends. An end before the start falls on the following day.
 */
export type OutputQuietHours = {
    zone: string;
    start: string;
    end: string;
};
/** Validates per-channel settings. Enabling private Lark delivery requires a selected integration. */
export declare const outputPreferenceSchema: z.ZodEffects<z.ZodObject<{
    kind: z.ZodString;
    channel: z.ZodEnum<["in_app", "lark"]>;
    enabled: z.ZodBoolean;
    integrationId: z.ZodNullable<z.ZodString>;
    quiet: z.ZodNullable<z.ZodEffects<z.ZodObject<{
        zone: z.ZodEffects<z.ZodString, string, string>;
        start: z.ZodString;
        end: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        start: string;
        zone: string;
        end: string;
    }, {
        start: string;
        zone: string;
        end: string;
    }>, {
        start: string;
        zone: string;
        end: string;
    }, {
        start: string;
        zone: string;
        end: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    kind: string;
    channel: "in_app" | "lark";
    enabled: boolean;
    integrationId: string | null;
    quiet: {
        start: string;
        zone: string;
        end: string;
    } | null;
}, {
    kind: string;
    channel: "in_app" | "lark";
    enabled: boolean;
    integrationId: string | null;
    quiet: {
        start: string;
        zone: string;
        end: string;
    } | null;
}>, {
    kind: string;
    channel: "in_app" | "lark";
    enabled: boolean;
    integrationId: string | null;
    quiet: {
        start: string;
        zone: string;
        end: string;
    } | null;
}, {
    kind: string;
    channel: "in_app" | "lark";
    enabled: boolean;
    integrationId: string | null;
    quiet: {
        start: string;
        zone: string;
        end: string;
    } | null;
}>;
/**
 * A recipient's delivery policy for one output kind and channel in the current organization.
 * The recipient chooses the channel and quiet period. The source still authorizes each result.
 */
export type OutputPreference = {
    kind: string;
    channel: 'in_app' | 'lark';
    enabled: boolean;
    integrationId: string | null;
    quiet: OutputQuietHours | null;
};
export { agentOutputReferenceSchema };
/**
 * Identifies a committed result for one recipient, for example a published delivery reminder.
 * The source reuses this reference across handoff retries with the same business revision and
 * publication time. The host assigns a message ID when it accepts the result.
 */
export type AgentOutputReference = Required<z.output<typeof agentOutputReferenceSchema>>;
/** Validates the source's current visibility outcome and the content it permits the recipient to see. */
export declare const agentOutputPresentationSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"visible">;
    title: z.ZodString;
    decision: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"human_decision">;
        schemaVersion: z.ZodLiteral<1>;
        requestVersion: z.ZodNumber;
        choices: z.ZodEffects<z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans: string;
            }, {
                en_US: string;
                zh_Hans: string;
            }>;
            replyCommand: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }, {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }>, "many">, {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[], {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[]>;
    }, "strict", z.ZodTypeAny, {
        type: "human_decision";
        schemaVersion: 1;
        requestVersion: number;
        choices: {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[];
    }, {
        type: "human_decision";
        schemaVersion: 1;
        requestVersion: number;
        choices: {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[];
    }>>;
    fields: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans: string;
        }, {
            en_US: string;
            zh_Hans: string;
        }>;
        value: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        value: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
    }, {
        value: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
    }>, "many">>;
    conversation: z.ZodCatch<z.ZodOptional<z.ZodObject<{
        conversationId: z.ZodString;
        threadId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        conversationId: string;
        threadId?: string | undefined;
    }, {
        conversationId: string;
        threadId?: string | undefined;
    }>>>;
}, "strict", z.ZodTypeAny, {
    status: "visible";
    title: string;
    decision?: {
        type: "human_decision";
        schemaVersion: 1;
        requestVersion: number;
        choices: {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[];
    } | undefined;
    fields?: {
        value: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
    }[] | undefined;
    conversation?: {
        conversationId: string;
        threadId?: string | undefined;
    } | undefined;
}, {
    status: "visible";
    title: string;
    decision?: {
        type: "human_decision";
        schemaVersion: 1;
        requestVersion: number;
        choices: {
            key: string;
            label: {
                en_US: string;
                zh_Hans: string;
            };
            replyCommand?: string | undefined;
        }[];
    } | undefined;
    fields?: {
        value: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
    }[] | undefined;
    conversation?: unknown;
}>, z.ZodObject<{
    status: z.ZodEnum<["superseded", "forbidden", "unavailable"]>;
}, "strict", z.ZodTypeAny, {
    status: "superseded" | "forbidden" | "unavailable";
}, {
    status: "superseded" | "forbidden" | "unavailable";
}>]>;
/**
 * The source resolves the result for its recipient at dispatch and again on read.
 *
 * - `visible` — The source provides content for the recipient and may offer a human decision.
 * - `superseded` — The result is no longer current and is omitted.
 * - `forbidden` — The recipient lacks access to the result and it is omitted.
 * - `unavailable` — The source cannot resolve the result yet. Dispatch may retry, and the current read omits it.
 */
export type AgentOutputPresentation = {
    status: 'visible';
    title: string;
    decision?: HumanDecision;
    fields?: AgentOutputField[];
    conversation?: {
        conversationId: string;
        threadId?: string;
    };
} | {
    status: 'superseded' | 'forbidden' | 'unavailable';
};
