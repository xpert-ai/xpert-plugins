import { z } from 'zod/v3';
/**
 * Validates the immutable reference a source hands to the outbox. The key and revision use
 * the source's vocabulary, such as a review run ID and its Git commit SHA.
 */
export declare const agentOutputReferenceSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    kind: z.ZodString;
    key: z.ZodString;
    revision: z.ZodString;
    publishedAt: z.ZodString;
    recipientId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: string;
    key: string;
    schemaVersion: 1;
    revision: string;
    publishedAt: string;
    recipientId: string;
}, {
    kind: string;
    key: string;
    schemaVersion: 1;
    revision: string;
    publishedAt: string;
    recipientId: string;
}>;
