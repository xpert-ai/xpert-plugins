import type { AgentOutputField } from './agent-output.model';
import { z } from 'zod/v3';
/** Validates the choices a source offers. Choice keys and direct-reply commands must each be unambiguous. */
export declare const humanDecisionSchema: z.ZodObject<{
    type: z.ZodLiteral<"human_decision">;
    schemaVersion: z.ZodLiteral<1>;
    requestVersion: z.ZodNumber;
    choices: z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans: string;
        }, {
            en_US: string;
            zh_Hans: string;
        }>;
        replyCommand: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }, {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }>, "many">, {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }[], {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }[]>;
}, "strict", z.ZodTypeAny, {
    type: "human_decision";
    schemaVersion: 1;
    requestVersion: number;
    choices: {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }[];
}, {
    type: "human_decision";
    schemaVersion: 1;
    requestVersion: number;
    choices: {
        key: string;
        label: {
            en_US: string;
            zh_Hans: string;
        };
        replyCommand?: string | undefined;
    }[];
}>;
/**
 * A request for an authorized person to choose a business outcome. The source defines the choices
 * and their effects. Buttons submit a stable choice key. A quoted reply must match a declared
 * replyCommand. The enclosing output reference identifies the request and business revision.
 */
export type HumanDecision = z.output<typeof humanDecisionSchema>;
/** Validates the submission shared by workbench actions and verified private-channel replies. */
export declare const humanDecisionInputSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    requestId: z.ZodString;
    sourceRevision: z.ZodString;
    requestVersion: z.ZodNumber;
    choice: z.ZodString;
    commandId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    schemaVersion: 1;
    requestVersion: number;
    requestId: string;
    sourceRevision: string;
    choice: string;
    commandId: string;
}, {
    schemaVersion: 1;
    requestVersion: number;
    requestId: string;
    sourceRevision: string;
    choice: string;
    commandId: string;
}>;
/**
 * One choice for the request and business revision the person saw. requestVersion identifies
 * the state of the decision request. sourceRevision identifies the underlying business terms.
 * Retries reuse commandId. The source arbitrates competing submissions under the authenticated actor.
 */
export type HumanDecisionInput = z.output<typeof humanDecisionInputSchema>;
/** Outcomes the workbench and channels can report after a submission is evaluated. */
export declare const humanDecisionStatusSchema: z.ZodEnum<["recorded", "already_recorded", "conflicting_choice", "stale", "closed", "forbidden"]>;
/**
 * Outcome of submitting a choice for a decision request.
 *
 * - `recorded` — The source committed the choice.
 * - `already_recorded` — The source previously committed the same choice for this request.
 * - `conflicting_choice` — The choice conflicts with a recorded decision, or the command ID was reused with different input.
 * - `stale` — The submitted version is out of date. Review the current request before choosing again.
 * - `closed` — The request no longer accepts choices.
 * - `forbidden` — The submission could not be authorized.
 */
export type HumanDecisionStatus = z.infer<typeof humanDecisionStatusSchema>;
/** Submission outcomes that can replace the actionable controls on the original private card. */
export declare const privateDecisionFeedbackStatusSchema: z.ZodEnum<["recorded", "already_recorded", "stale", "closed"]>;
/** A visible outcome for the original recipient. Conflicts and unauthorized attempts leave the card untouched. */
export type PrivateDecisionFeedbackStatus = z.infer<typeof privateDecisionFeedbackStatusSchema>;
/**
 * Result returned to the caller after submitting a choice. When present, decisionId identifies the source's durable
 * business decision. Concurrent submissions from different channels can return the same ID.
 */
export type HumanDecisionResult = {
    status: HumanDecisionStatus;
    decisionId?: string;
};
/** Accepts a button callback or a reply quoting a specific message, together with its sender and chat. */
export declare const privateDecisionReplySchema: z.ZodObject<{
    parentId: z.ZodString;
    chatId: z.ZodString;
    openId: z.ZodString;
    unionId: z.ZodOptional<z.ZodString>;
    input: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"button">;
        interactionId: z.ZodString;
        choice: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "button";
        choice: string;
        interactionId: string;
    }, {
        type: "button";
        choice: string;
        interactionId: string;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"quoted_text">;
        text: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type: "quoted_text";
        text: string;
    }, {
        type: "quoted_text";
        text: string;
    }>]>;
}, "strict", z.ZodTypeAny, {
    parentId: string;
    chatId: string;
    openId: string;
    input: {
        type: "button";
        choice: string;
        interactionId: string;
    } | {
        type: "quoted_text";
        text: string;
    };
    unionId?: string | undefined;
}, {
    parentId: string;
    chatId: string;
    openId: string;
    input: {
        type: "button";
        choice: string;
        interactionId: string;
    } | {
        type: "quoted_text";
        text: string;
    };
    unionId?: string | undefined;
}>;
/**
 * Channel evidence for a button click or a direct reply quoting the original card.
 * The host matches `parentId` and `chatId` to the delivery and checks the sender's current identity
 * binding before translating the button key or declared reply command into a decision input.
 */
export type PrivateDecisionReply = z.output<typeof privateDecisionReplySchema>;
/**
 * A single recipient's decision as delivered to a private chat. The channel renders the
 * authorized fields and choices, using the host's delivery attempt ID to correlate button replies.
 */
export interface PrivateDecisionCard {
    title: string;
    fields: AgentOutputField[];
    decision: HumanDecision;
}
