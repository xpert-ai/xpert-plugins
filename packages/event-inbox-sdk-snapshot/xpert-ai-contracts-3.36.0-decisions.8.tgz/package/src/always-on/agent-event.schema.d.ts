import { z } from 'zod/v3';
/** Validates the source-defined object identity carried in a subject or a handling result. */
export declare const agentEventRefSchema: z.ZodObject<{
    kind: z.ZodEffects<z.ZodString, string, string>;
    key: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    kind: string;
    key: string;
}, {
    kind: string;
    key: string;
}>;
/** Validates the event envelope at inbox admission. The source retains the referenced business data. */
export declare const pluginAgentEventSchema: z.ZodObject<{
    sourceEventId: z.ZodEffects<z.ZodString, string, string>;
    bindingRevision: z.ZodNumber;
    type: z.ZodEffects<z.ZodString, string, string>;
    schemaVersion: z.ZodNumber;
    occurredAt: z.ZodString;
    subject: z.ZodObject<{
        kind: z.ZodEffects<z.ZodString, string, string>;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        kind: string;
        key: string;
    }, {
        kind: string;
        key: string;
    }>;
    fact: z.ZodObject<{
        key: z.ZodEffects<z.ZodString, string, string>;
        revision: z.ZodEffects<z.ZodString, string, string>;
        sha256: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        key: string;
        revision: string;
        sha256: string;
    }, {
        key: string;
        revision: string;
        sha256: string;
    }>;
}, "strict", z.ZodTypeAny, {
    type: string;
    sourceEventId: string;
    bindingRevision: number;
    schemaVersion: number;
    occurredAt: string;
    subject: {
        kind: string;
        key: string;
    };
    fact: {
        key: string;
        revision: string;
        sha256: string;
    };
}, {
    type: string;
    sourceEventId: string;
    bindingRevision: number;
    schemaVersion: number;
    occurredAt: string;
    subject: {
        kind: string;
        key: string;
    };
    fact: {
        key: string;
        revision: string;
        sha256: string;
    };
}>;
/**
 * An object in the source domain. The subject's kind and key determine which events are
 * ordered together. A result reference uses the same shape to identify an outcome.
 */
export type AgentEventRef = z.infer<typeof agentEventRefSchema>;
/**
 * One occurrence reported under a source binding. Retrying it reuses the entire envelope.
 * bindingRevision identifies the source configuration, schemaVersion identifies the event format,
 * and fact identifies the immutable business snapshot by key, revision and content digest.
 */
export type PluginAgentEvent = z.infer<typeof pluginAgentEventSchema>;
/** Accepts a completed source handler outcome for storage on the inbox receipt. */
export declare const agentEventDecisionSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"handled">;
    operationKey: z.ZodEffects<z.ZodString, string, string>;
    resultRef: z.ZodObject<{
        kind: z.ZodEffects<z.ZodString, string, string>;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        kind: string;
        key: string;
    }, {
        kind: string;
        key: string;
    }>;
}, "strict", z.ZodTypeAny, {
    status: "handled";
    operationKey: string;
    resultRef: {
        kind: string;
        key: string;
    };
}, {
    status: "handled";
    operationKey: string;
    resultRef: {
        kind: string;
        key: string;
    };
}>, z.ZodObject<{
    status: z.ZodLiteral<"ignored">;
    reasonCode: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status: "ignored";
    reasonCode: string;
}, {
    status: "ignored";
    reasonCode: string;
}>, z.ZodObject<{
    status: z.ZodLiteral<"blocked">;
    reasonCode: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status: "blocked";
    reasonCode: string;
}, {
    status: "blocked";
    reasonCode: string;
}>]>;
/**
 * The source handler's disposition of one receipt.
 *
 * - `handled` — Identifies the business operation and its result. Several receipts can resolve to the same operation.
 * - `ignored` — No action applies to this event. The handler supplies a stable reason code.
 * - `blocked` — The handler could not proceed. The reason code identifies what prevented it.
 */
export type EventDecision = z.infer<typeof agentEventDecisionSchema>;
