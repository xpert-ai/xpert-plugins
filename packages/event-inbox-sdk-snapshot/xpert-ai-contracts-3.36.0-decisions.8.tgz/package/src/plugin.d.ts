import { IBasePerTenantAndOrganizationEntityModel } from './base-entity.model';
import type { PluginInstallationSummary } from './plugin-management';
import type { PluginMarketplaceAppConfig } from './plugin-application';
import type { IXpert, XpertWorkspaceDataScope } from './ai/xpert.model';
import type { TMcpStdioRuntimePolicy } from './ai/xpert-tool-mcp.model';
import type { IMcpApiKey } from './ai/mcp-auth.model';
import type { IMcpPublication, McpPublicationStatus } from './ai/mcp-publication.model';
import type { JSONValue } from './core.model';
export type * from './plugin-management';
import { IconDefinition, I18nObject } from './types';
export * from './plugin-application';
export type PluginName = string;
export declare const PLUGIN_LEVEL: {
    readonly SYSTEM: "system";
    readonly TENANT: "tenant";
    readonly ORGANIZATION: "organization";
};
export declare const PLUGIN_SOURCE: {
    readonly MARKETPLACE: "marketplace";
    readonly LOCAL: "local";
    readonly GIT: "git";
    readonly URL: "url";
    readonly NPM: "npm";
    readonly CODE: "code";
    readonly ENV: "env";
};
export declare const PLUGIN_CONFIGURATION_STATUS: {
    readonly VALID: "valid";
    readonly INVALID: "invalid";
};
export declare const PLUGIN_LOAD_STATUS: {
    readonly LOADED: "loaded";
    readonly PENDING_RESTART: "pending_restart";
    readonly FAILED: "failed";
};
export declare const PLUGIN_COMPONENT_TYPE: {
    readonly SKILL: "skill";
    readonly MCP_SERVER: "mcp_server";
    readonly TOOLSET: "toolset";
    readonly APP: "app";
    readonly HOOK: "hook";
    readonly ASSET: "asset";
};
export declare const PLUGIN_MARKETPLACE_INSTALLATION_POLICY: {
    readonly AVAILABLE: "AVAILABLE";
    readonly INSTALLED_BY_DEFAULT: "INSTALLED_BY_DEFAULT";
    readonly NOT_AVAILABLE: "NOT_AVAILABLE";
};
export declare const PLUGIN_MARKETPLACE_AUTHENTICATION_POLICY: {
    readonly ON_INSTALL: "ON_INSTALL";
    readonly ON_FIRST_USE: "ON_FIRST_USE";
    readonly NONE: "NONE";
};
export declare const PLUGIN_MCP_TOOL_APPROVAL_MODE: {
    readonly PROMPT: "prompt";
    readonly APPROVE: "approve";
    readonly DENY: "deny";
};
export declare const PLUGIN_RESOURCE_RUNTIME_TYPE: {
    readonly SKILL_PACKAGE: "skill_package";
    readonly TOOLSET: "toolset";
    readonly HOOK_PROFILE: "hook_profile";
    readonly APP_CONNECTOR: "app_connector";
};
export declare const PLUGIN_RESOURCE_INSTALLATION_STATUS: {
    readonly READY: "ready";
    readonly PENDING_AUTH: "pending_auth";
    readonly BLOCKED: "blocked";
    readonly FAILED: "failed";
};
export declare const PLUGIN_RESOURCE_ERROR_CODE: {
    readonly NO_MATCHING_COMPONENTS: "PLUGIN_RESOURCE_NO_MATCHING_COMPONENTS";
};
/**
 * Classifies plugin scope and governance.
 * - `system`: built-in/platform-managed plugin that users cannot install/uninstall from org APIs.
 * - `tenant`: tenant-owned plugin shared across organizations in its owning tenant.
 * - `organization`: tenant/org-managed plugin that can be installed and removed per organization.
 */
export type PluginLevel = (typeof PLUGIN_LEVEL)[keyof typeof PLUGIN_LEVEL];
export type PluginSource = (typeof PLUGIN_SOURCE)[keyof typeof PLUGIN_SOURCE];
export type PluginConfigurationStatus = (typeof PLUGIN_CONFIGURATION_STATUS)[keyof typeof PLUGIN_CONFIGURATION_STATUS];
export type PluginLoadStatus = (typeof PLUGIN_LOAD_STATUS)[keyof typeof PLUGIN_LOAD_STATUS];
export type PluginComponentType = (typeof PLUGIN_COMPONENT_TYPE)[keyof typeof PLUGIN_COMPONENT_TYPE];
export type PluginMarketplaceInstallationPolicy = (typeof PLUGIN_MARKETPLACE_INSTALLATION_POLICY)[keyof typeof PLUGIN_MARKETPLACE_INSTALLATION_POLICY];
export type PluginMarketplaceAuthenticationPolicy = (typeof PLUGIN_MARKETPLACE_AUTHENTICATION_POLICY)[keyof typeof PLUGIN_MARKETPLACE_AUTHENTICATION_POLICY];
export type PluginMcpToolApprovalMode = (typeof PLUGIN_MCP_TOOL_APPROVAL_MODE)[keyof typeof PLUGIN_MCP_TOOL_APPROVAL_MODE];
export type PluginResourceRuntimeType = (typeof PLUGIN_RESOURCE_RUNTIME_TYPE)[keyof typeof PLUGIN_RESOURCE_RUNTIME_TYPE];
export type PluginResourceInstallationStatus = (typeof PLUGIN_RESOURCE_INSTALLATION_STATUS)[keyof typeof PLUGIN_RESOURCE_INSTALLATION_STATUS];
export type PluginResourceErrorCode = (typeof PLUGIN_RESOURCE_ERROR_CODE)[keyof typeof PLUGIN_RESOURCE_ERROR_CODE];
export type PluginScopeRelation = 'none' | 'overrides-global' | 'shadowed-by-organization';
export type PluginTargetApp = 'xpert' | 'data-xpert' | (string & {});
export type PluginSdkCompatibilityWarningCode = 'plugin-sdk-peer-dependency-missing' | 'plugin-sdk-peer-range-invalid' | 'plugin-sdk-peer-range-incompatible' | 'plugin-sdk-peer-range-spans-major';
export type PluginMarketplaceContributionType = 'app' | 'view' | 'feature' | 'skill' | 'tool' | 'mcp' | 'hook' | 'assistant-template' | (string & {});
export type PluginMarketplaceOperationAccess = 'read' | 'write' | 'admin' | (string & {});
export interface PluginMarketplaceOperation {
    name: string;
    displayName?: string | I18nObject;
    description?: string | I18nObject;
    access?: PluginMarketplaceOperationAccess;
    tags?: string[];
}
export interface XpertPluginMarketplacePolicy {
    installation?: PluginMarketplaceInstallationPolicy;
    authentication?: PluginMarketplaceAuthenticationPolicy;
    pluginSharing?: boolean;
}
export interface XpertPluginMarketplaceSource {
    source?: 'local' | 'url' | 'git-subdir' | 'github' | 'git' | 'npm' | 'marketplace' | (string & {});
    path?: string;
    url?: string;
    ref?: string;
    sha?: string;
    sparsePath?: string;
    packageName?: string;
}
export interface XpertPluginInstallInterface {
    displayName?: string;
    shortDescription?: string;
    longDescription?: string;
    developerName?: string;
    category?: string;
    capabilities?: string[];
    websiteURL?: string;
    privacyPolicyURL?: string;
    termsOfServiceURL?: string;
    defaultPrompt?: string[];
    brandColor?: string;
    composerIcon?: string;
    logo?: string;
    screenshots?: string[];
}
export interface XpertPluginMcpServerPolicy {
    enabled?: boolean;
    defaultToolsApprovalMode?: PluginMcpToolApprovalMode;
    enabledTools?: string[];
    runtime?: TMcpStdioRuntimePolicy;
    tools?: {
        [toolName: string]: {
            approvalMode?: PluginMcpToolApprovalMode;
        };
    };
}
/**
 * Declares a trusted executable bundle that a system-level plugin can run through Sandbox Jobs.
 * The bundle is resolved relative to the action manifest file, never from a caller-provided host path.
 */
export interface XpertPluginSandboxActionDefinition {
    /** Stable action identity used by SandboxJobsApi callers. */
    name: string;
    /** Version of the action payload and output behavior, independent of the plugin package version. */
    version: string;
    /** Provider-neutral Runtime Definition required to execute this action. */
    runtimeProfile: string;
    /** Runner Host contract version expected by the bundle. */
    runtimeContractVersion: string;
    /** Optional exact Playwright compatibility requirement for Browser Runtime actions. */
    playwrightVersion?: string;
    /** Bundle directory relative to this definition or the plugin manifest. */
    bundle: string;
    /** Regular-file entrypoint relative to the verified bundle root. */
    entrypoint: string;
    /** Deterministic SHA-256 tree hash covering every regular file in the bundle. */
    bundleSha256: string;
}
/** Inline Action declarations or paths to Action manifest files in an installed plugin. */
export type XpertPluginSandboxActions = string | string[] | XpertPluginSandboxActionDefinition | XpertPluginSandboxActionDefinition[];
export interface XpertPluginBundleManifest {
    name: string;
    version?: string;
    /**
     * Stable namespace claimed by bundle artifacts before install.
     * Marketplace indexing uses this value to display and review artifact ownership.
     */
    artifactNamespace?: string;
    description?: string;
    author?: string;
    homepage?: string;
    repository?: JSONValue;
    license?: string;
    keywords?: string[];
    skills?: string | string[];
    mcpServers?: string | string[] | JSONValue;
    /** Host-native toolset providers contributed by the loaded plugin. */
    toolsets?: string | string[] | JSONValue;
    apps?: string | string[] | JSONValue;
    connectors?: string | string[] | JSONValue;
    hooks?: string | string[] | JSONValue | JSONValue[];
    /** Sandbox Action manifest paths or definitions. Executable actions are restricted to system-level plugins. */
    sandboxActions?: XpertPluginSandboxActions;
    interface?: XpertPluginInstallInterface;
    policy?: XpertPluginMarketplacePolicy;
    source?: XpertPluginMarketplaceSource;
    assets?: {
        composerIcon?: string;
        logo?: string;
        screenshots?: string[];
    };
    targetApps?: PluginTargetApp[];
    targetAppMeta?: PluginTargetAppMeta;
}
/** @deprecated Use the Assistant template domain contracts. */
export type { AssistantTemplateSkillDependency as XpertTemplatePluginSkillDependency, AssistantTemplateMcpServerDependency as XpertTemplatePluginMcpServerDependency, AssistantTemplateHookDependency as XpertTemplatePluginHookDependency, AssistantTemplateAppDependency as XpertTemplatePluginAppDependency, AssistantTemplateToolsetDependency as XpertTemplatePluginToolsetDependency, AssistantTemplateDependencies as XpertTemplatePluginDependencies } from './ai/assistant-template-dependencies.model';
export interface PluginMarketplaceContribution {
    /** Project types defined by an App, separate from installation configuration. */
    projectTypes?: import('./ai/xpert-project-type.model').XpertProjectTypeDefinition[];
    id?: string;
    type: PluginMarketplaceContributionType;
    name: string;
    displayName?: string | I18nObject;
    description?: string | I18nObject;
    icon?: IconDefinition;
    color?: string;
    operations?: PluginMarketplaceOperation[];
    tags?: string[];
    metadata?: Record<string, unknown>;
    /** Valid only when `type` is `app`. */
    appConfig?: PluginMarketplaceAppConfig;
}
export interface PluginMarketplaceTrialShortcut {
    id?: string;
    label?: string | I18nObject;
    prompt: string;
    skillKey?: string;
    icon?: IconDefinition;
}
export declare const PLUGIN_MARKETPLACE_CATEGORIES: readonly ["featured", "business-operations", "communication", "creativity", "data-analytics", "developer-tools", "education-research", "finance", "productivity", "research", "security", "travel", "sales", "other"];
export type PluginMarketplaceCategory = (typeof PLUGIN_MARKETPLACE_CATEGORIES)[number];
/**
 * Technical subcategories used by the plugin marketplace.
 * marketplace.category describes the business-facing group; marketplace.subcategory describes the technical type.
 */
export declare const PLUGIN_MARKETPLACE_SUBCATEGORIES: readonly ["connector", "middleware", "integration", "database", "tools", "model", "vlm", "vector-store", "doc-source", "datasource", "agent", "set"];
export type PluginMarketplaceSubcategory = (typeof PLUGIN_MARKETPLACE_SUBCATEGORIES)[number];
export interface PluginTargetAppMarketplaceMetadata {
    contents?: PluginMarketplaceContribution[];
    category?: PluginMarketplaceCategory;
    subcategory?: string;
    featured?: boolean;
    screenshots?: string[];
    trialShortcuts?: PluginMarketplaceTrialShortcut[];
    readme?: string;
    updatedAt?: string;
}
export interface PluginTargetAppRuntimeMetadata {
    middlewareProviders?: string[];
    viewProviders?: string[];
    templateProviders?: string[];
    [key: string]: unknown;
}
export interface PluginSdkCompatibilityWarning {
    code: PluginSdkCompatibilityWarningCode;
    packageName: PluginName;
    hostVersion: string;
    peerRange?: string | null;
    message: string;
}
export interface PluginTargetAppMetadata {
    /**
     * App-owned classification values. Each target app owns the vocabulary for its own entry.
     */
    types?: string[];
    /**
     * Minimum version of the target app that can safely use this plugin.
     */
    minAppVersion?: string;
    capabilities?: string[];
    marketplace?: PluginTargetAppMarketplaceMetadata;
    runtime?: PluginTargetAppRuntimeMetadata;
    [key: string]: unknown;
}
export type PluginTargetAppMeta = Record<string, PluginTargetAppMetadata | undefined>;
export interface PluginCodeSourceConfig {
    workspacePath?: string;
}
export interface PluginSourceConfig extends PluginCodeSourceConfig {
    installationMethod?: 'archive' | 'workspace';
    /** Written by the archive upload endpoint; retained for legacy installation provenance. */
    uploadFileName?: string;
    uploadInstalledAt?: string;
    /** Host-computed SHA-256 of the installed archive; never accepted from client sourceConfig. */
    archiveSha256?: string;
    /** Host-owned immutable installation directory; never supplied as an authorization grant. */
    runtimeName?: string;
    immutableRuntime?: boolean;
    [key: string]: unknown;
}
export interface PluginRuntimePolicy {
    install: 'hot' | 'restart';
    update: 'hot' | 'restart';
    uninstall: 'hot' | 'restart';
}
export interface PluginMeta {
    /** Explicit lifecycle support, independent of scope. Declared in package.json xpert.plugin. */
    runtimePolicy?: PluginRuntimePolicy;
    name: PluginName;
    version: string;
    /**
     * Stable namespace used for plugin-owned artifacts such as database tables.
     * Table artifacts must use names like `plugin_<artifactNamespace>_<tableKey>`.
     */
    artifactNamespace?: string;
    /**
     * Declares the plugin's operational level used for visibility and install/uninstall guardrails.
     */
    level?: PluginLevel;
    /**
     * Declares the product surfaces this plugin is intended to appear in.
     *
     * When omitted, the plugin remains a generic xpert-pro plugin for backwards compatibility.
     */
    targetApps?: PluginTargetApp[];
    /**
     * App-specific metadata grouped by target app without overloading the technical category.
     */
    targetAppMeta?: PluginTargetAppMeta;
    /**
     * Marks a plugin as deprecated while keeping it installable/visible for migration.
     */
    deprecated?: boolean;
    /**
     * Optional user-facing migration guidance shown when the plugin is deprecated.
     */
    deprecationMessage?: I18nObject;
    icon?: IconDefinition;
    category: 'set' | 'doc-source' | 'agent' | 'tools' | 'model' | 'vlm' | 'vector-store' | 'integration' | 'datasource' | 'database' | 'middleware';
    displayName: string | I18nObject;
    description: string | I18nObject;
    keywords?: string[];
    author: string;
    homepage?: string;
}
export type PluginMarketplaceSourceType = 'url' | 'github' | 'git';
export type PluginMarketplaceSourceResponseType = PluginMarketplaceSourceType | 'platform';
export type PluginMarketplaceRegistrySection = 'marketplace' | 'official' | 'partner' | 'community';
export type PluginMarketplaceRegistryDownloadStatus = 'idle' | 'success' | 'failed';
export type PluginMarketplaceItemSourceType = 'marketplace' | 'github' | 'git' | 'url' | 'npm' | 'website' | 'other' | (string & {});
export interface PluginMarketplaceSourceInput {
    name?: string;
    type?: PluginMarketplaceSourceType;
    url?: string;
    ref?: string | null;
    sparsePath?: string | null;
    enabled?: boolean;
    priority?: number;
}
export interface PluginMarketplaceSourceResponse {
    id: string;
    name: string;
    type: PluginMarketplaceSourceResponseType;
    url: string;
    ref?: string | null;
    sparsePath?: string | null;
    enabled: boolean;
    priority: number;
    lastIndexStatus?: string | null;
    lastIndexedAt?: Date | string | null;
    lastIndexError?: string | null;
    builtin?: boolean;
}
export interface PluginMarketplaceRegistryItem {
    id: string;
    packageName: string;
    version?: string | null;
    /**
     * Optional artifact namespace declared by the registry for plugins that are not installed yet.
     * When omitted, marketplace views may derive a default from the package name.
     */
    artifactNamespace?: string | null;
    displayName: string | I18nObject;
    description: string | I18nObject;
    category: string;
    author: string;
    icon?: IconDefinition | null;
    keywords: string[];
    homepage?: string | null;
    repository?: JSONValue | null;
    targetApps: PluginTargetApp[];
    targetAppMeta: PluginTargetAppMeta;
    enabled: boolean;
    priority: number;
    section: PluginMarketplaceRegistrySection;
    downloads?: PluginMarketplaceDownloads | null;
    downloadsStatus?: PluginMarketplaceRegistryDownloadStatus | string | null;
    downloadsUpdatedAt?: Date | string | null;
    downloadsError?: string | null;
    createdAt?: Date | string | null;
    updatedAt?: Date | string | null;
}
export type PluginMarketplaceRegistryItemResponse = PluginMarketplaceRegistryItem;
export interface PluginMarketplaceRegistryItemInput {
    packageName?: string;
    version?: string | null;
    /**
     * Explicit artifact namespace used during manual marketplace registration or review.
     * Keep it aligned with the plugin manifest/meta when the plugin declares one.
     */
    artifactNamespace?: string | null;
    displayName?: string | I18nObject;
    description?: string | I18nObject;
    category?: string;
    author?: string;
    icon?: IconDefinition | null;
    keywords?: string[];
    homepage?: string | null;
    repository?: JSONValue | null;
    targetApps?: PluginTargetApp[];
    targetAppMeta?: PluginTargetAppMeta | null;
    enabled?: boolean;
    priority?: number;
    section?: PluginMarketplaceRegistrySection;
}
export interface PluginMarketplaceAuthor {
    name?: string | null;
    displayName?: string | null;
    url?: string | null;
    homepage?: string | null;
}
export interface PluginMarketplaceDownloads {
    lastWeek?: number;
    lastMonth?: number;
    lastYear?: number;
    [key: string]: JSONValue | undefined;
}
export interface PluginMarketplaceOperationSummary {
    total: number;
    read: number;
    write: number;
    admin: number;
}
export interface PluginMarketplaceItemSource {
    type?: PluginMarketplaceItemSourceType;
    url?: string | null;
    path?: string | null;
    ref?: string | null;
    packageName?: string | null;
}
export interface PluginMarketplaceItem {
    /** A card projection; fetch the plugin endpoint before displaying full contents/actions. */
    summary?: boolean;
    /** Content hash of an embedded icon served by the authenticated marketplace assets endpoint. */
    iconAsset?: string;
    name: string;
    packageName?: string | null;
    displayName?: I18nObject | string;
    description?: I18nObject | string;
    version?: string | null;
    /**
     * Namespace shown to users/reviewers for plugin-owned artifacts such as tables.
     * This may come from registry data, bundle manifest, runtime meta, or package-name derivation.
     */
    artifactNamespace?: string | null;
    level?: PluginLevel;
    deprecated?: boolean;
    deprecationMessage?: I18nObject | string | null;
    category?: PluginMeta['category'] | string;
    icon?: IconDefinition | null;
    author?: PluginMarketplaceAuthor | string | null;
    source?: PluginMarketplaceItemSource | null;
    keywords?: string[];
    screenshots?: string[];
    downloads?: PluginMarketplaceDownloads | null;
    sourceId?: string | null;
    sourceName?: string | null;
    sourceNameI18nKey?: string | null;
    installed?: boolean;
    contributions?: PluginMarketplaceContribution[];
    defaultPrompt?: string[];
    trialShortcuts?: PluginMarketplaceTrialShortcut[];
    operationSummary?: PluginMarketplaceOperationSummary;
    targetApps?: PluginTargetApp[];
    targetAppMeta?: PluginTargetAppMeta | null;
    marketplacePlugin?: JSONValue | null;
    section?: PluginMarketplaceRegistrySection | string;
}
export type PluginMarketplaceReadmeSource = 'installed-package' | 'npm-package' | 'marketplace-metadata' | 'description';
export interface PluginMarketplaceReadme {
    locale: string;
    requestedLocale?: string | null;
    fileName?: string | null;
    content: string;
    source: PluginMarketplaceReadmeSource;
    version?: string | null;
}
export interface PluginMarketplaceDetailItem extends PluginMarketplaceItem {
    installations?: PluginInstallationSummary[];
    readme: PluginMarketplaceReadme;
    availableReadmeLocales?: string[];
}
export declare enum PluginMarketplaceDetailErrorCode {
    Unavailable = "PLUGIN_MARKETPLACE_DETAIL_UNAVAILABLE",
    LookupFailed = "PLUGIN_MARKETPLACE_LOOKUP_FAILED"
}
export interface PluginMarketplaceResponse {
    updatedAt: string | null;
    total: number;
    items: PluginMarketplaceItem[];
    sources: PluginMarketplaceSourceResponse[];
    official?: string[];
    partner?: string[];
    community?: string[];
    errors?: Array<{
        sourceId: string;
        sourceName: string;
        message: string;
    }>;
}
export interface IPluginComponentDocument {
    pluginName: PluginName;
    componentType: PluginComponentType;
    componentKey: string;
    sourcePath?: string | null;
    fileName?: string | null;
    content: string;
}
export interface IPluginResourceComponentState {
    componentType: PluginComponentType;
    componentKey: string;
    installed: boolean;
    staleDefinition: boolean;
    runtimeType?: PluginResourceRuntimeType | null;
    runtimeId?: string | null;
    status?: PluginResourceInstallationStatus | null;
    installation?: IPluginResourceInstallation | null;
    mcpServer?: IPluginMcpServerState | null;
}
export interface IPluginMcpServerState {
    publicationId?: string | null;
    /** Publication ownership follows the contributing plugin level. */
    publicationScope?: 'tenant' | 'organization' | null;
    /** Organization admission state for a tenant-scoped Publication. */
    accessEnabled?: boolean | null;
    status?: McpPublicationStatus | null;
    endpoint?: string | null;
    protocolVersion?: string | null;
    transport?: 'streamable-http' | null;
    apiKeyCount?: number;
    syncError?: string | null;
    syncFailedAt?: string | null;
}
export interface IPluginMcpServerConnectionInfo {
    protocolVersion: string;
    transport: 'streamable-http';
    endpoint: string;
    authorization: 'Bearer';
    serverInstructions?: string;
}
export interface IPluginMcpServerActivationResult {
    installation: IPluginResourceInstallation;
    publication: IMcpPublication;
    connectionInfo: IPluginMcpServerConnectionInfo;
    createdApiKey?: {
        apiKey: Omit<IMcpApiKey, 'keyHash'>;
        secret: string;
    };
}
/** A retrievable MCP client credential scoped to the requesting administrator and organization. */
export interface IPluginMcpServerCredentialResult {
    connectionInfo: IPluginMcpServerConnectionInfo;
    apiKey: Omit<IMcpApiKey, 'keyHash'>;
    secret: string;
}
export interface PluginResourceComponentSelector {
    componentType?: PluginComponentType;
    componentKey: string;
    pluginName?: PluginName;
    targetAgentKey?: string;
    policyOverrides?: XpertPluginMcpServerPolicy;
    events?: string[];
    auth?: 'on_install' | 'on_first_use';
}
export interface IPluginResourceInstallation extends IBasePerTenantAndOrganizationEntityModel {
    pluginName: PluginName;
    componentType: PluginComponentType;
    componentKey: string;
    workspaceId?: string | null;
    xpertId?: string | null;
    agentKey?: string | null;
    runtimeType: PluginResourceRuntimeType;
    runtimeId?: string | null;
    runtimeNodeKey?: string | null;
    definitionHash: string;
    status: PluginResourceInstallationStatus;
    config?: JSONValue | null;
    enabled: boolean;
}
export interface IPluginResourceInstallResult {
    installations: IPluginResourceInstallation[];
    pendingAuth: IPluginResourceInstallation[];
    xpert?: IXpert;
}
export interface PluginResourceInstallWorkspaceInput {
    workspaceId: string;
    components?: PluginResourceComponentSelector[];
}
export interface PluginResourceInstallOrganizationInput {
    components?: PluginResourceComponentSelector[];
}
export interface PluginResourceInstallXpertInput {
    xpertId: string;
    components?: PluginResourceComponentSelector[];
    agentKey?: string;
}
export interface XpertTemplateInstallInput {
    workspaceId: string;
    /** Optional Assistant capability IDs selected for this installation. */
    capabilities?: string[];
    basic?: {
        name?: string;
        title?: string;
        description?: string;
        avatar?: JSONValue | null;
        copilotModel?: JSONValue | null;
        workspaceDataScope?: XpertWorkspaceDataScope;
    };
}
