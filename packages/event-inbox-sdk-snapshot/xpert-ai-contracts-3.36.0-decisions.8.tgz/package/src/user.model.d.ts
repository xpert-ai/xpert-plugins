import { IRole } from './role.model';
import { IBasePerTenantEntityModel } from './base-entity.model';
import { ITag } from './tag-entity.model';
import { IEmployee } from './employee.model';
import { IUserOrganization } from './user-organization.model';
export declare enum UserType {
    USER = "user",// Regular user
    COMMUNICATION = "communication"
}
export interface IUser extends IBasePerTenantEntityModel {
    /** Administrators may suspend sign-in and subsequent execution without deleting account data. */
    isActive?: boolean;
    thirdPartyId?: string;
    name?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    mobile?: string;
    username?: string;
    timeZone?: string;
    type?: UserType;
    role?: IRole;
    roleId?: string;
    hash?: string;
    imageUrl?: string;
    employee?: IEmployee;
    employeeId?: string;
    tags?: ITag[];
    preferredLanguage?: string;
    paymentsId?: string;
    fullName?: string;
    organizations?: IUserOrganization[];
    isImporting?: boolean;
    sourceId?: string;
    emailVerified?: boolean;
    emailVerification?: IEmailVerification;
    deletedAt?: Date;
}
export interface IEmailVerification extends IBasePerTenantEntityModel {
    token: string;
    userId: string;
    user?: IUser;
    validUntil: Date;
}
export interface IUserEmailInput {
    email: string;
}
export interface IUserFindInput {
    thirdPartyId?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    username?: string;
    role?: IRole;
    roleId?: string;
    hash?: string;
    imageUrl?: string;
    tags?: ITag[];
    preferredLanguage?: LanguagesEnum;
}
export interface IUserRegistrationInput {
    user: IUser;
    password?: string;
    confirmPassword?: string;
    referralCode?: string;
    originalUrl?: string;
    organizationId?: string;
    createdById?: string;
    isImporting?: boolean;
    sourceId?: string;
    timeZone?: string;
}
export interface IUserLoginInput {
    email: string;
    password: string;
}
export interface AccessTokenClaims {
    /** Login tokens issued before purpose marking omit this claim. */
    purpose?: 'access';
    id: string;
    thirdPartyId?: string;
    tenantId?: string;
    employeeId?: string | null;
    username?: string;
    role?: string | null;
    permissions?: string[] | null;
}
export interface IAuthResponse {
    user: IUser;
    token: string;
    refreshToken: string;
}
export interface IUserCreateInput {
    type?: UserType;
    firstName?: string;
    lastName?: string;
    email?: string;
    username?: string;
    role?: IRole;
    roleId?: string;
    hash?: string;
    imageUrl?: string;
    tags?: ITag[];
    preferredLanguage?: LanguagesEnum;
    timeZone?: string;
    thirdPartyId?: string;
    roleName?: string;
}
export interface IUserUpdateInput extends Omit<IUserCreateInput, 'type'> {
    password?: string;
    confirmPassword?: string;
}
export interface IUserPasswordInput {
    hash?: string;
    password?: string;
    confirmPassword?: string;
}
/**
 * Browser http header `Language`
 */
export declare enum LanguagesEnum {
    Chinese = "zh-CN",
    SimplifiedChinese = "zh-Hans",
    TraditionalChinese = "zh-Hant",
    English = "en"
}
export declare const LanguagesMap: {
    'zh-CN': LanguagesEnum;
    'zh-Hans': LanguagesEnum;
    zh: LanguagesEnum;
};
export declare enum ProviderEnum {
    GOOGLE = "google",
    FACEBOOK = "facebook"
}
export interface IUserViewModel extends IBasePerTenantEntityModel {
    fullName: string;
    email: string;
    bonus?: number;
    endWork?: any;
    id: string;
    roleName?: string;
    role?: string;
    tags?: ITag[];
}
