import { TXpertGraph } from '../ai/xpert.model';
type TStartNodeConnection = Partial<Pick<TXpertGraph['connections'][number], 'type' | 'from' | 'to'>>;
type TStartNodeGraph = {
    connections?: TStartNodeConnection[];
};
/**
 * Channels of all upstream and downstream nodes relative to the starting point startKey.
 *
 * @param graph
 * @param startKey
 */
export declare function allChannels(graph: TXpertGraph, startKey: string): string[];
export declare function findStartNodes(graph: TStartNodeGraph, key: string): string[];
/**
 * Keep the content in the same graph as the key node (including the node, its connected nodes, and the 'edge' type connections between them)
 *
 * @param graph
 * @param key
 * @returns
 */
export declare function getCurrentGraph(graph: TXpertGraph, key: string): TXpertGraph;
export declare function shortTitle(input: string): string;
export {};
