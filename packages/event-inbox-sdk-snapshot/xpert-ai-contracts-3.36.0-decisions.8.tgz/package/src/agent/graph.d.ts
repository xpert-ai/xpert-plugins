import { BaseMessage } from '@langchain/core/messages';
import { RunnableConfig } from '@langchain/core/runnables';
import type { TMessageContentComplex } from '@xpert-ai/chatkit-types';
import { Subscriber } from 'rxjs';
import { ICopilotModel } from '../ai/copilot-model.model';
import { TWorkflowVarGroup } from '../ai/xpert-workflow.model';
import { TXpertGraph, TXpertTeamNode } from '../ai/xpert.model';
import { IXpertAgent } from '../ai/xpert-agent.model';
/**
 * @deprecated can use getCurrentTaskInput instead?
 */
export declare const CONTEXT_VARIABLE_CURRENTSTATE = "currentState";
export declare const STATE_VARIABLE_SYS = "sys";
export declare const GRAPH_NODE_SUMMARIZE_CONVERSATION = "summarize_conversation";
export declare const GRAPH_NODE_TITLE_CONVERSATION = "title_conversation";
export declare const STATE_VARIABLE_FILES = "files";
export declare const STATE_VARIABLE_INPUT = "input";
export declare const STATE_SYS_VOLUME = "volume";
/**
 * Workspace path in sandbox environment
 */
export declare const STATE_SYS_WORKSPACE_PATH = "workspace_path";
/**
 * URL for workspace files in sandbox environment
 */
export declare const STATE_SYS_WORKSPACE_URL = "workspace_url";
export declare const STATE_SYS_WORKSPACE_ROOT = "workspace_root";
export declare const STATE_SYS_SHARED_WORKSPACE_PATH = "shared_workspace_path";
export declare const STATE_SYS_AGENT_WORKSPACE_PATH = "agent_workspace_path";
export declare const STATE_SYS_SESSION_WORKSPACE_PATH = "session_workspace_path";
export declare const STATE_SYS_MEMORY_WORKSPACE_PATH = "memory_workspace_path";
/**
 * Current runtime thread id
 */
export declare const STATE_SYS_THREAD_ID = "thread_id";
export declare const STATE_VARIABLE_TITLE_CHANNEL: string;
export type TMessageChannel = {
    system: string;
    messages: BaseMessage[];
    summary?: string;
    error?: string | null;
    /** Checkpointed input identity; committed with the corresponding messages. */
    inputReceipt?: {
        id: string;
        status: 'pending' | 'consumed';
    };
};
export interface IBackendProtocol {
    workingDirectory: string;
}
export type TSandboxConfigurable = {
    /**
     * Resolved sandbox provider type used for this backend acquisition.
     */
    provider?: string;
    /**
     * Effective working directory inside the sandbox backend.
     */
    workingDirectory?: string;
    /**
     * Canonical sandbox environment id that owns this backend/container.
     */
    environmentId?: string | null;
    /**
     * Underlying runtime container id when the backend is container-backed.
     */
    containerId?: string | null;
    /**
     * Container lifecycle run id created for this acquisition, if a new
     * container run was recorded.
     */
    runId?: string | null;
    /**
     * Concrete backend instance used by the agent/runtime.
     */
    backend?: unknown;
};
export type TAgentRunnableConfigurable = {
    /**
     * Thread id
     */
    thread_id: string;
    checkpoint_ns: string;
    checkpoint_id: string;
    tool_call_id?: string;
    tenantId: string;
    organizationId: string;
    language: string;
    userId: string;
    /**
     * Xpert project id
     */
    projectId?: string;
    xpertId?: string;
    agentKey: string;
    xpertName?: string;
    toolName?: string;
    /**
     * Additional runtime context for middleware/tool execution.
     */
    context?: Record<string, unknown> & {
        env?: Record<string, unknown>;
    };
    /** Current graph state exposed to tools for resolving server-owned configuration variables. */
    runtimeState?: Record<string, unknown>;
    copilotModel?: ICopilotModel;
    subscriber: Subscriber<any>;
    /**
     * Execution id of agent workflow node
     */
    executionId: string;
    /**
     * Root execution id of the current agent run.
     * Nested subgraphs keep writing steer follow-ups back into this execution.
     */
    rootExecutionId?: string;
    /**
     * Root agent key of the current agent run.
     * Nested subgraphs use this as the primary transcript/log channel.
     */
    rootAgentKey?: string;
    /**
     * Sandbox backend context
     */
    sandbox?: TSandboxConfigurable;
    signal?: AbortSignal;
};
/**
 * @deprecated use import { type ToolCall } from '@langchain/core/messages/tool';
 */
export type TToolCall = {
    id?: string;
    name: string;
    type?: 'tool_call';
    args: Record<string, any>;
};
export declare function channelName(name: string): string;
export declare function messageContentText(content: string | TMessageContentComplex): any;
/**
 * Get workspace folder for sandbox from runnable configurable
 *
 * @param configurable
 * @returns
 */
export declare function getWorkspaceFromRunnable(configurable: TAgentRunnableConfigurable): {
    type?: 'project' | 'user';
    id?: string;
};
export declare function getToolCallFromConfig(config: any): TToolCall;
export declare function getToolCallIdFromConfig(config: any): string;
/**
 * Compute long-term memory namespace:
 * 1. When a user talks to a digital expert individually, use `ExpertId` + `UserId` to store memory
 * 2. When talking to a digital expert in a project, all users and digital experts share `ProjectId` to store memory
 *
 * @param config
 * @returns
 */
export declare function getStoreNamespace(config: RunnableConfig): string[];
export declare function configurableStoreNamespace(configurable: Partial<TAgentRunnableConfigurable>): string[];
/**
 * Set value into variable of state.
 *
 * @param state
 * @param varName
 * @param value
 * @returns
 */
export declare function setStateVariable(state: Record<string, any>, varName: string, value: any): Record<string, any>;
/**
 * Get agent variable group from graph.
 *
 * @param key
 * @param graph
 * @returns
 */
export declare function getAgentVarGroup(key: string, graph: TXpertGraph): TWorkflowVarGroup;
/**
 * Get swarm partners of agent in team
 *
 * @param graph
 * @param agentKey
 */
export declare function getSwarmPartners(graph: TXpertGraph, agentKey: string, partners: string[], leaderKey?: string): string[];
export declare function getWorkflowTriggers(graph: TXpertGraph, from: string): ((import("../ai/xpert.model").TXpertTeamNodeBase & {
    type: "toolset";
} & {
    entity: import("..").IXpertToolset;
}) | (import("../ai/xpert.model").TXpertTeamNodeBase & {
    type: "xpert";
} & {
    entity: import("../ai/xpert.model").IXpert;
    nodes?: TXpertTeamNode[];
    connections?: import("../ai/xpert.model").TXpertTeamConnection[];
    expanded?: boolean;
}) | (import("../ai/xpert.model").TXpertTeamNodeBase & {
    type: "knowledge";
} & {
    entity: import("..").IKnowledgebase;
}) | (import("../ai/xpert.model").TXpertTeamNodeBase & {
    type: "agent";
} & {
    entity: IXpertAgent;
}) | (import("../ai/xpert.model").TXpertTeamNodeBase & {
    type: "workflow";
} & {
    entity: import("../ai/xpert-workflow.model").IWorkflowNode;
}))[];
