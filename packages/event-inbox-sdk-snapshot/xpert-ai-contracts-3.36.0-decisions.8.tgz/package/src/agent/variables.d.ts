import { TWorkflowVarGroup } from '../ai/xpert-workflow.model';
import { TXpertParameter } from '../ai/xpert.model';
/**
 *
 * Returns the variable schema for a given variable name.
 * The variable name can be in the format of 'groupName.variableName' or just 'variableName'.
 *
 * @param variables
 * @param variable
 * @returns
 */
export declare function getVariableSchema(variables: TWorkflowVarGroup[] | null | undefined, variable: string | null | undefined): {
    group: TWorkflowVarGroup;
    variable: import("../ai/xpert.model").TStateVariable;
};
export declare const FILE_VARIABLES: TXpertParameter[];
