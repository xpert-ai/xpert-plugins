import { IBasePerTenantEntityModel } from './base-entity.model';
import { IContact } from './contact.model';
import { CurrenciesEnum } from './currency.model';
import { IEmployee } from './employee.model';
import { IFeatureOrganization } from './feature.model';
import { IOrganizationLanguage } from './organization-language.model';
import { ITag } from './tag-entity.model';
import { ITenant } from './tenant.model';
import { LanguagesEnum } from './user.model';
export declare enum OrganizationPermissionsEnum {
    ALLOW_MANUAL_TIME = "allowManualTime",
    ALLOW_MODIFY_TIME = "allowModifyTime",
    ALLOW_DELETE_TIME = "allowDeleteTime",
    ALLOW_FUTURE_DATE = "futureDateAllowed"
}
export declare enum ListsInputTypeEnum {
    DEPARTMENTS = "DEPARTMENTS",
    POSITIONS = "POSITIONS",
    VENDORS = "VENDORS"
}
export interface IOrganization extends IBasePerTenantEntityModel {
    name: string;
    isDefault: boolean;
    profile_link: string;
    valueDate?: Date;
    totalEmployees: number;
    status?: string;
    imageUrl?: string;
    banner: string;
    short_description: string;
    client_focus: string;
    createdDemo?: boolean;
    show_income?: boolean;
    show_profits?: boolean;
    show_bonuses_paid?: boolean;
    show_total_hours?: boolean;
    show_minimum_project_size?: boolean;
    show_projects_count?: boolean;
    show_clients_count?: boolean;
    show_employees_count?: boolean;
    overview: string;
    currency: string;
    isActive: boolean;
    defaultValueDateType: string;
    defaultAlignmentType?: string;
    dateFormat?: string;
    brandColor?: string;
    timeZone?: string;
    officialName?: string;
    startWeekOn?: string;
    taxId?: string;
    numberFormat?: string;
    bonusType?: string;
    bonusPercentage?: number;
    employees?: IEmployee[];
    invitesAllowed?: boolean;
    inviteExpiryPeriod?: number;
    sidebarExpandedByDefault?: boolean;
    tags: ITag[];
    futureDateAllowed?: boolean;
    allowManualTime?: boolean;
    allowModifyTime?: boolean;
    allowDeleteTime?: boolean;
    regionCode?: string;
    requireReason?: boolean;
    requireDescription?: boolean;
    requireProject?: boolean;
    requireTask?: boolean;
    requireClient?: boolean;
    timeFormat?: 12 | 24;
    defaultStartTime?: string;
    defaultEndTime?: string;
    registrationDate?: Date;
    separateInvoiceItemTaxAndDiscount?: boolean;
    minimumProjectSize?: string;
    show_clients?: boolean;
    currencyPosition?: string;
    website?: string;
    fiscalInformation?: string;
    fiscalStartDate?: Date;
    fiscalEndDate?: Date;
    discountAfterTax?: boolean;
    languages?: IOrganizationLanguage[];
    featureOrganizations?: IFeatureOrganization[];
    defaultInvoiceEstimateTerms?: string;
    convertAcceptedEstimates?: boolean;
    daysUntilDue?: number;
    preferredLanguage?: LanguagesEnum;
}
export interface IOrganizationFindInput extends IBasePerTenantEntityModel {
    id?: string;
    name?: string;
    isDefault?: boolean;
    profile_link?: string;
    valueDate?: Date;
    imageUrl?: string;
    currency?: CurrenciesEnum;
    isActive?: boolean;
    tags?: ITag[];
}
export interface IOrganizationCreateInput extends IContact {
    name: string;
    isDefault: boolean;
    profile_link: string;
    valueDate?: Date;
    imageUrl: string;
    currency: CurrenciesEnum;
    client_focus: string;
    show_income?: boolean;
    show_profits?: boolean;
    show_bonuses_paid?: boolean;
    show_total_hours?: boolean;
    show_minimum_project_size?: boolean;
    show_projects_count?: boolean;
    show_clients_count?: boolean;
    show_employees_count?: boolean;
    defaultValueDateType: DefaultValueDateTypeEnum;
    dateFormat?: string;
    timeZone?: string;
    officialName?: string;
    startWeekOn?: string;
    taxId?: string;
    numberFormat?: string;
    bonusType: BonusTypeEnum;
    bonusPercentage?: number;
    invitesAllowed?: boolean;
    inviteExpiryPeriod?: number;
    sidebarExpandedByDefault?: boolean;
    tags?: ITag[];
    tenant: ITenant;
    contact?: IContact;
    minimumProjectSize?: string;
    show_clients?: boolean;
    website?: string;
    fiscalInformation?: string;
    defaultInvoiceEstimateTerms?: string;
    convertAcceptedEstimates?: boolean;
    daysUntilDue?: number;
    preferredLanguage?: LanguagesEnum;
    isImporting?: boolean;
    sourceId?: string;
    userOrganizationSourceId?: string;
}
export interface IOrganizationUpdateInput extends IOrganizationCreateInput {
    id?: string;
}
export declare enum OrganizationSelectInput {
    id = "id",
    name = "name",
    profile_link = "profile_link",
    valueDate = "valueDate",
    imageUrl = "imageUrl",
    currency = "currency",
    createdAt = "createdAt",
    updatedAt = "updatedAt",
    isActive = "isActive",
    sidebarExpandedByDefault = "sidebarExpandedByDefault",
    tags = "tags"
}
export declare enum RegionsEnum {
    'EN' = "English (United States)",
    'BG' = "Bulgarian (Bulgaria)",
    'HE' = "Hebrew (Israel)",
    'RU' = "Rusian (Russia)"
}
export declare enum DefaultValueDateTypeEnum {
    TODAY = "TODAY",
    END_OF_MONTH = "END_OF_MONTH",
    START_OF_MONTH = "START_OF_MONTH"
}
export declare enum ProjectBillingEnum {
    RATE = "RATE",
    FLAT_FEE = "FLAT_FEE",
    MILESTONES = "MILESTONES"
}
export declare enum AlignmentOptions {
    LEFT = "LEFT",
    RIGHT = "RIGHT",
    CENTER = "CENTER"
}
export declare enum CurrencyPosition {
    LEFT = "LEFT",
    RIGHT = "RIGHT"
}
export declare enum WeekDaysEnum {
    MONDAY = "MONDAY",
    TUESDAY = "TUESDAY",
    WEDNESDAY = "WEDNESDAY",
    THURSDAY = "THURSDAY",
    FRIDAY = "FRIDAY",
    SATURDAY = "SATURDAY",
    SUNDAY = "SUNDAY"
}
export declare enum BonusTypeEnum {
    PROFIT_BASED_BONUS = "PROFIT_BASED_BONUS",
    REVENUE_BASED_BONUS = "REVENUE_BASED_BONUS"
}
export declare enum ClientFocusEnum {
    VERY_SMALL_BUSINESSES = "Very Small Businesses",
    SMALL_BUSINESSES = "Small Businesses",
    MEDIUM_BUSINESSES = "Medium Businesses",
    LARGE_BUSINESSES = "Large Businesses"
}
export declare enum ProjectOwnerEnum {
    CLIENT = "CLIENT",
    INTERNAL = "INTERNAL"
}
export declare enum MinimumProjectSizeEnum {
    ONE_THOUSAND = "1000+",
    FIVE_THOUSAND = "5000+",
    TEN_THOUSAND = "10000+",
    TWENTY_FIVE_THOUSAND = "25000+",
    FIFTY_THOUSAND = "50000+",
    ONE_HUNDRED_THOUSAND = "100000+"
}
export declare const DEFAULT_PROFIT_BASED_BONUS = 75;
export declare const DEFAULT_REVENUE_BASED_BONUS = 10;
export declare const DEFAULT_INVITE_EXPIRY_PERIOD = 7;
export interface IOrganizationStoreState {
    organization: IOrganization;
    action: CrudActionEnum;
}
export declare enum CrudActionEnum {
    CREATED = "CREATED",
    UPDATED = "UPDATED",
    DELETED = "DELETED"
}
export declare const DEFAULT_DATE_FORMATS: string[];
export declare const DEFAULT_TIME_FORMATS: number[];
export interface IKeyValuePair {
    key: string;
    value: boolean | string;
}
export declare enum OrganizationDemoNetworkEnum {
    github = "github",
    aliyun = "aliyun"
}
export type OrgGenerateDemoOptions = {
    source: OrganizationDemoNetworkEnum | string;
    importData: boolean;
};
