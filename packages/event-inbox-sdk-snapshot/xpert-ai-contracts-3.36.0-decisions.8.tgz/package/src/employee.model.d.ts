import { IBasePerTenantAndOrganizationEntityModel } from './base-entity.model';
import { IContact } from './contact.model';
import { CrudActionEnum, IOrganizationFindInput } from './organization.model';
import { IOrganizationTeam } from './organization-team-model';
import { ITag } from './tag-entity.model';
import { IUser, IUserFindInput } from './user.model';
export interface IEmployee extends IBasePerTenantAndOrganizationEntityModel {
    [x: string]: any;
    endWork?: any;
    startedWorkOn?: any;
    user: IUser;
    userId: string;
    valueDate?: Date;
    isActive: boolean;
    short_description?: string;
    description?: string;
    teams?: IOrganizationTeam[];
    payPeriod?: string;
    billRateValue?: number;
    billRateCurrency?: string;
    reWeeklyLimit?: number;
    tags: ITag[];
    offerDate?: Date;
    acceptDate?: Date;
    rejectDate?: Date;
    employeeLevel?: string;
    anonymousBonus?: boolean;
}
export interface UpdateEmployeeJobsStatistics {
    isJobSearchActive?: boolean;
}
export interface IEmployeeFindInput {
    id?: string;
    organization?: IOrganizationFindInput;
    user?: IUserFindInput;
    valueDate?: Date;
    organizationId?: string;
    tenantId?: string;
    tags?: ITag[];
}
export interface IEmployeeUpdateInput extends IBasePerTenantAndOrganizationEntityModel {
    payPeriod?: string;
    billRateValue?: number;
    billRateCurrency?: string;
    reWeeklyLimit?: number;
    offerDate?: Date;
    acceptDate?: Date;
    rejectDate?: Date;
    short_description?: string;
    description?: string;
    averageIncome?: number;
    averageExpenses?: number;
    averageBonus?: number;
    isJobSearchActive?: boolean;
    contact?: IContact;
    linkedInUrl?: string;
    facebookUrl?: string;
    instagramUrl?: string;
    twitterUrl?: string;
    githubUrl?: string;
    gitlabUrl?: string;
    upworkUrl?: string;
}
export interface IEmployeeCreateInput extends IBasePerTenantAndOrganizationEntityModel {
    user: IUser;
    password?: string;
    offerDate?: Date;
    acceptDate?: Date;
    rejectDate?: Date;
    members?: IEmployee[];
    tags?: ITag[];
    startedWorkOn?: any;
    short_description?: string;
    description?: string;
    originalUrl?: string;
    isActive?: boolean;
}
export interface ISelectedEmployee {
    id: string;
    firstName: string;
    lastName: string;
    fullName?: string;
    imageUrl: string;
    defaultType?: DEFAULT_TYPE;
    tags?: ITag[];
}
export declare enum DEFAULT_TYPE {
    ALL_EMPLOYEE = "ALL_EMPLOYEE",
    NO_EMPLOYEE = "NO_EMPLOYEE"
}
export declare enum PayPeriodEnum {
    NONE = "NONE",
    BI_WEEKLY = "BI_WEEKLY",
    WEEKLY = "WEEKLY",
    TWICE_PER_MONTH = "TWICE_PER_MONTH",
    MONTHLY = "MONTHLY"
}
export interface IEmployeeLevel extends IBasePerTenantAndOrganizationEntityModel {
    level: string;
    tag?: ITag[];
}
export interface IEmployeeLevelInput extends IBasePerTenantAndOrganizationEntityModel {
    level: string;
    tags?: ITag[];
}
export interface IEmployeeLevelFindInput {
    organizationId?: string;
    tenantId: string;
}
export interface EmployeeViewModel {
    fullName: string;
    email: string;
    bonus?: number;
    endWork?: any;
    id: string;
    imageUrl?: string;
    averageIncome?: number;
    averageExpenses?: number;
    averageBonus?: number;
    workStatus?: string;
    startedWorkOn?: string;
    isActive?: boolean;
    tags?: ITag[];
}
export interface IEmployeeStoreState {
    employee: IEmployee | IEmployee[];
    action: CrudActionEnum;
}
