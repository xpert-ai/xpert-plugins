/** Official resource packages imported into the selected organization, without publishing workspace bindings. */
export declare const DEFAULT_AGENT_PLUGINS_SOURCE: {
    readonly url: "https://github.com/xpert-ai/xpert-plugins.git";
    readonly ref: "main";
    readonly subdirectory: "agent-plugins";
    readonly browseUrl: "https://github.com/xpert-ai/xpert-plugins/tree/main/agent-plugins";
};
export interface DefaultAgentPluginImportItem {
    id: string;
    status: 'imported' | 'existing' | 'repaired' | 'failed';
    packageId?: string;
    title?: string;
    diagnosticCount?: number;
    error?: string;
}
export interface DefaultAgentPluginsImportResult {
    commit: string;
    items: DefaultAgentPluginImportItem[];
}
/** Scope-owned receipt for a background import; completed items survive API restarts. */
export interface DefaultAgentPluginsImportProgress {
    operationId: string | null;
    phase: 'idle' | 'fetching' | 'importing' | 'completed' | 'failed';
    commit: string | null;
    total: number;
    currentId: string | null;
    items: DefaultAgentPluginImportItem[];
    updatedAt: string;
    error?: string;
}
