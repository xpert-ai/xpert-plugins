import { z } from 'zod/v3';
/** Public presentation metadata only. Renderers retain their own sandbox and URL policies. */
export declare const iconDefinitionSchema: z.ZodObject<{
    type: z.ZodEnum<["image", "svg", "font", "emoji", "lottie"]>;
    value: z.ZodString;
    color: z.ZodOptional<z.ZodString>;
    size: z.ZodOptional<z.ZodNumber>;
    alt: z.ZodOptional<z.ZodString>;
    style: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, "strip", z.ZodTypeAny, {
    size?: number;
    color?: string;
    type?: "image" | "svg" | "font" | "emoji" | "lottie";
    value?: string;
    alt?: string;
    style?: Record<string, string>;
}, {
    size?: number;
    color?: string;
    type?: "image" | "svg" | "font" | "emoji" | "lottie";
    value?: string;
    alt?: string;
    style?: Record<string, string>;
}>;
