export type ShellState = 'pending' | 'running' | 'cancel_requested' | 'succeeded' | 'failed' | 'cancelled' | 'timed_out' | 'rejected' | 'unknown';
export interface ShellExecutionEvidence {
    version: 1;
    generation: string;
    state: 'exited' | 'not_started';
    coverage: 'descendants';
}
export type ShellPlatform = 'darwin' | 'win32';
export interface ShellSettings {
    name: string;
    shell: '/bin/zsh' | '/bin/bash' | 'powershell.exe';
    cwd: string;
    path: string;
}
export interface ShellExecInput {
    action: 'exec';
    command: string;
    cwd?: string;
    timeout_sec?: number;
}
export type ShellComputerInfo = {
    available: false;
} | {
    available: true;
    platform: ShellPlatform;
    name: string;
    shell: ShellSettings['shell'];
    cwd: string;
};
export type ShellInput = ShellExecInput | {
    action: 'info';
} | {
    action: 'status';
    operationId: string;
    cursor?: number;
} | {
    action: 'cancel';
    operationId: string;
};
export interface ShellScope {
    tenantId: string;
    organizationId: string;
    userId: string;
}
export interface ShellDeviceInfo {
    id: string;
    name: string;
    platform: string;
    shell: string;
}
export interface ShellChunk {
    seq: number;
    stream: 'stdout' | 'stderr';
    data: string;
}
export interface ShellResult {
    operationId: string;
    executionTarget: 'desktop';
    device: ShellDeviceInfo;
    cwd: string;
    state: ShellState;
    stdout: string;
    stderr: string;
    exitCode: number | null;
    signal?: string;
    nextCursor: number;
    truncated: boolean;
    error?: {
        code: string;
        message: string;
    };
}
interface WireBase {
    version: 1;
    operationId: string;
    connectionEpoch: string;
}
export interface ShellExecCommand extends WireBase {
    type: 'exec';
    grantId: string;
    argsHash: string;
    command: string;
    cwd: string;
    timeoutSec: number;
    deadline: number;
}
export interface ShellCancelCommand extends WireBase {
    type: 'cancel';
    reason?: 'cancelled' | 'timed_out';
}
export type ShellCommand = ShellExecCommand | ShellCancelCommand;
export interface ShellOutputReport extends WireBase {
    type: 'output';
    state: 'running';
    seq: number;
    stream: 'stdout' | 'stderr';
    data: string;
}
export interface ShellStateReport extends WireBase {
    completion?: ShellExecutionEvidence;
    type: 'state';
    state: ShellState;
    seq: number;
    exitCode: number | null;
    signal?: string;
    truncated: boolean;
    errorCode?: string;
}
export type ShellReport = ShellOutputReport | ShellStateReport;
export interface IDesktopShellDevice extends ShellScope {
    id: string;
    installationId: string;
    name: string;
    platform: string;
    shell: string;
    cwd: string;
    enabled: boolean;
    credentialHash: string;
    credentialExpiresAt: Date;
    connectionEpoch: string | null;
    leaseExpiresAt: Date | null;
}
export interface IDesktopShellGrant extends ShellScope {
    operation: ShellOperationAuthorization | null;
    id: string;
    deviceId: string;
    assistantId: string;
    threadId: string | null;
    enabled: boolean;
    expiresAt: Date;
}
export interface IDesktopShellOperation extends ShellScope {
    completion?: ShellExecutionEvidence | null;
    id: string;
    deviceId: string;
    grantId: string;
    threadId: string;
    runId: string;
    toolCallId: string;
    argsHash: string;
    command: string;
    cwd: string;
    timeoutSec: number;
    deadline: Date;
    state: ShellState;
    output: ShellChunk[];
    outputBytes: number;
    seq: number;
    exitCode: number | null;
    signal: string | null;
    truncated: boolean;
    errorCode: string | null;
}
export type ShellPolicy = 'ask' | 'allow' | 'deny';
export interface ShellPreparationRequest {
    kind: 'desktop-shell';
    assistantId: string;
    threadId: string;
    runId: string;
    toolCallId: string;
    command: string;
    cwd?: string;
    timeoutSec: number;
}
export interface ShellOperationAuthorization {
    runId: string;
    toolCallId: string;
    argsHash: string;
    decision: 'pending' | 'approved' | 'rejected';
}
export interface ShellPreparation {
    kind: 'desktop-shell';
    grantId: string;
    deviceName: string;
    cwd: string;
    decision: 'pending' | 'approved';
    expiresAt: number;
}
export {};
