import { IBasePerTenantAndOrganizationEntityModel } from './base-entity.model';
import { IOrganizationProjectsUpdateInput } from './organization-projects.model';
import { IOrganizationUpdateInput } from './organization.model';
import { ITag } from './tag-entity.model';
import { I18nObject, IconDefinition, TAvatar, TParameterSchema } from './types';
import { IntegrationSharingPolicy } from './integration-sharing.model';
import { IUser } from './user.model';
export interface IIntegration<T = any> extends IBasePerTenantAndOrganizationEntityModel {
    sharing?: IntegrationSharingPolicy | null;
    name: string;
    description?: string;
    /**
     * avatar object
     */
    avatar?: TAvatar;
    slug: string;
    provider: string;
    /**
     * Integration features: ['knowledge', 'agent', ...]
     */
    features?: IntegrationFeatureEnum[];
    /**
     * Custom options for different providers
     */
    options?: T;
    tags?: ITag[];
    /**
     * Stable technical principal for this integration.
     * One integration should map to one long-lived communication user.
     */
    userId?: string;
    user?: IUser;
}
export interface IIntegrationFilter {
    integrationTypeId: string;
    searchQuery: string;
    filter: string;
}
export interface IIntegrationMapSyncProject extends IBasePerTenantAndOrganizationEntityModel {
    organizationProjectInput: IOrganizationProjectsUpdateInput;
    integrationId: string;
    sourceId: number;
}
export interface IIntegrationMapSyncOrganization extends IBasePerTenantAndOrganizationEntityModel {
    organizationInput: IOrganizationUpdateInput;
    integrationId: string;
    sourceId: number;
}
/**
 * @deprecated use Plugins instead
 */
export declare enum IntegrationEnum {
    UPWORK = "Upwork",
    HUBSTAFF = "Hubstaff",
    LARK = "Lark",
    DINGTALK = "DingTalk",
    WECOM = "WeCom",
    FIRECRAWL = "firecrawl",
    KNOWLEDGEBASE = "knowledgebase",
    GITHUB = "github",
    RAGFlow = "ragflow",
    Dify = "dify",
    FastGPT = "fastgpt"
}
export declare enum IntegrationFeatureEnum {
    KNOWLEDGE = "knowledge",
    AGENT = "agent",
    SSO = "sso"
}
export declare enum IntegrationFilterEnum {
    ALL = "All",
    FREE = "Free",
    PAID = "Paid"
}
export declare const DEFAULT_INTEGRATION_PAID_FILTERS: {
    label: IntegrationFilterEnum;
    value: string;
}[];
export interface IDateRangeActivityFilter {
    start: Date;
    end: Date;
}
export type TIntegrationProvider = {
    name: string;
    label: I18nObject;
    description?: I18nObject;
    avatar?: string;
    icon?: IconDefinition;
    webhook?: boolean;
    schema?: TParameterSchema;
    features?: IntegrationFeatureEnum[];
    /**
     * Declares that this integration can exchange an enterprise H5 employee identity.
     * The host uses these stable discriminators instead of matching provider names.
     */
    enterpriseH5?: {
        platform: string;
        externalIdentityProvider: string;
        accountBindingProvider?: string;
    };
    helpUrl?: string;
    helpLabel?: I18nObject;
    helpLinks?: Array<{
        url: string;
        label?: I18nObject;
    }>;
    /**
     * Declarative setup hints consumed by the host integration configuration UI.
     *
     * Plugins can use this to ask the host to run `validateConfig` automatically
     * and display returned setup artifacts, such as webhook/callback URLs or
     * authorization links, without the host hard-coding provider names.
     */
    setup?: {
        /** The provider implements the server-side QR authorization lifecycle. */
        qrAuthorization?: boolean;
        /**
         * When true, the host runs the provider's `validateConfig` after an
         * existing integration is loaded and after save/upsert succeeds. Use this
         * for providers whose setup information is computed by validation.
         */
        autoValidateOnLoad?: boolean;
        authorization?: {
            /**
             * When true, the host can show a generic hint that authorization is
             * available only after the integration has been saved and has an id.
             */
            requiresSavedIntegration?: boolean;
        };
    };
    pro?: boolean;
};
/** Public QR setup data; provider device codes and credentials stay on the server. */
export interface TIntegrationQrSession {
    id: string;
    authorizationUrl: string;
    expiresAt: number;
    intervalSeconds: number;
}
export type TIntegrationQrStatus = 'waiting' | 'authorized' | 'expired' | 'denied' | 'failed';
/** Stable setup failures; clients translate these codes instead of parsing server messages. */
export type TIntegrationQrErrorCode = 'INTEGRATION_QR_BUSY' | 'TRIGGER_DRAFT_CONFLICT' | 'TRIGGER_PUBLISH_REQUIRED';
export interface TIntegrationQrResult {
    status: TIntegrationQrStatus;
}
export type TIntegrationQrCreateInput = Pick<IIntegration, 'name' | 'description' | 'avatar'>;
export type TIntegrationQrCompletion = Pick<IIntegration, 'id' | 'name' | 'slug' | 'provider'> & {
    outcome: 'created' | 'reused';
};
