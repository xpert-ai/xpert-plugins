export declare enum InterruptMessageType {
    SlidesTemplate = "slides_template",
    SwitchGitHubRepository = "switch_github_repository",
    Select = "select"
}
