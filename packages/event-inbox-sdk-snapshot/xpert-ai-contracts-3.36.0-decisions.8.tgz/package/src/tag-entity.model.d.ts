import { IBasePerTenantAndOrganizationEntityModel } from './base-entity.model';
import { I18nObject } from './types';
export interface ITag extends IBasePerTenantAndOrganizationEntityModel {
    name?: string;
    label?: I18nObject;
    description?: string;
    category?: TagCategoryEnum;
    color?: string;
    isSelected?: boolean;
    icon?: string;
    targets?: TagTarget[];
    isActive?: boolean;
    isSystem?: boolean;
}
export type TagTarget = TagCategoryEnum | 'knowledgebase' | 'prompt_workflow' | 'people' | 'integration';
export declare function getTagTargets(tag: ITag): TagTarget[];
export interface ITagUsage {
    target: TagTarget;
    count: number;
}
export interface ITagDirectoryItem extends ITag {
    editable: boolean;
    usage: ITagUsage[];
}
/** A visible expert version associated with a tag; excludes private expert configuration. */
export interface ITagXpertUsage {
    id: string;
    name: string;
    version: string | null;
    latest: boolean;
    deleted: boolean;
}
export interface ITagName {
    name?: string;
}
export declare enum TagCategoryEnum {
    INDICATOR = "indicator",
    STORY = "story",
    TOOLSET = "toolset",
    XPERT = "xpert"
}
export declare const TAG_TARGETS: TagTarget[];
