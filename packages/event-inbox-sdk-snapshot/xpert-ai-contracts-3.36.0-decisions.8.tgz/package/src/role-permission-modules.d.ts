import { AIPermissionsEnum as AI } from './ai/role-permissions';
import { PermissionsEnum as P } from './role-permission.model';
/** Display-only grouping. Runtime access is determined by enabled grants and endpoint/resource policy. */
export type RolePermissionModule = 'ai' | 'projects' | 'members' | 'billing' | 'data' | 'personal' | 'other';
export declare const ROLE_PERMISSION_MODULES: ReadonlyMap<string, RolePermissionModule>;
export declare const DEPRECATED_ROLE_PERMISSIONS: readonly [P.ADMIN_DASHBOARD_VIEW, P.VIEW_ALL_EMAILS, P.ORG_DEMO_EDIT, AI.COPILOT_VIEW, P.CHANGE_SELECTED_ORGANIZATION, P.ACCESS_DELETE_ACCOUNT];
export declare const UNWIRED_AI_PERMISSIONS: readonly AI[];
/** Complete UI/documentation catalog; presence here never grants access or implies endpoint enforcement. */
export declare const ROLE_PERMISSION_CATALOG: {
    permission: P | AI;
    module: RolePermissionModule;
    deprecated: boolean;
    configurable: boolean;
    contractOnly: boolean;
}[];
