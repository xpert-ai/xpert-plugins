import { Endpoints } from '@octokit/types';
export type TGithubAuth = {
    redirectUri: string;
    integrationId: string;
    access_token: string;
    expires_in: number;
    refresh_token: string;
    refresh_token_expires_in: number;
    token_type: string;
    scope: string;
    installation_token: string;
    repository: string;
};
type GitHubInstallationsResponse = Endpoints['GET /user/installations']['response']['data'];
type GitHubInstallation = GitHubInstallationsResponse['installations'][0];
export interface Installation {
    id: number;
    accountName: string;
    accountType: 'User' | 'Organization';
    avatarUrl: string;
}
/**
 * Transform GitHub API installation data to our simplified format
 */
export declare const transformInstallation: (installation: GitHubInstallation) => Installation;
export type TRepositoryReturn = {
    repositories: Repository[];
    pagination: {
        page: number;
        perPage: number;
        hasMore: boolean;
        totalCount: number;
    };
};
/**
 * Repository interface representing GitHub repository data
 */
export interface Repository {
    id: number;
    name: string;
    full_name: string;
    description: string | null;
    private: boolean;
    fork: boolean;
    html_url: string;
    default_branch: string;
    permissions: {
        admin: boolean;
        maintain: boolean;
        push: boolean;
        triage: boolean;
        pull: boolean;
    };
    has_issues: boolean;
}
/**
 * Branch interface representing GitHub branch data
 */
export interface Branch {
    name: string;
    commit: {
        sha: string;
        url: string;
    };
    protected: boolean;
}
export {};
