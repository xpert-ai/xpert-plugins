import { TIntegrationProvider } from '../integration.model';
/**
 * @deprecated use plugin
 */
export declare const IntegrationLarkProvider: TIntegrationProvider;
