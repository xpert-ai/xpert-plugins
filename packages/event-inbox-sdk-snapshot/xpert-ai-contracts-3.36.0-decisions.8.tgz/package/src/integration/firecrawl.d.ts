import { TIntegrationProvider } from '../integration.model';
export declare const IntegrationFirecrawlProvider: TIntegrationProvider;
