import { TIntegrationProvider } from '../integration.model';
export declare const IntegrationWeComProvider: TIntegrationProvider;
