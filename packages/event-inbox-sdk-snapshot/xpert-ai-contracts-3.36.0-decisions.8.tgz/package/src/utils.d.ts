export declare function isNil(value: unknown): value is null | undefined;
export declare function nonNullable<T>(value: T): value is NonNullable<T>;
export declare function isString(value: unknown): value is string;
export declare function isBlank(value: unknown): boolean;
export declare function nonBlank<T>(value: T): value is NonNullable<T>;
