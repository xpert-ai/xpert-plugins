import type { XpertProjectTypeRef } from '../ai/xpert-project-type.model';
import type { PluginApplicationScope } from '../plugin-application';
import type { I18nObject, IconDefinition } from '../types';
import type { JsonSchemaObjectType } from '../ai/types';
import type { XpertViewAssistantIdentity } from './assistant-profile';
import type { XpertViewClientCommandDefinition } from './client-commands';
export * from './client-commands';
export type XpertViewHostType = 'integration' | 'knowledgebase' | 'agent' | 'project' | 'sandbox' | string;
export type XpertViewSlotMode = 'tabs' | 'sections' | 'widgets' | 'sidebar';
export type XpertViewSchemaType = 'stats' | 'table' | 'list' | 'detail' | 'raw_json' | 'remote_component';
export type XpertRemoteComponentRuntime = 'react' | 'vue' | 'esm';
export type XpertViewValueType = 'text' | 'number' | 'status' | 'datetime' | 'json';
export type XpertViewColumnDataType = 'text' | 'number' | 'date' | 'datetime' | 'status' | 'tag' | 'avatar' | 'link';
export type XpertViewActionPlacement = 'toolbar' | 'row';
export type XpertViewActionType = 'invoke' | 'navigate' | 'open_detail' | 'refresh';
export type XpertViewActionTransport = 'json' | 'file';
export type XpertViewFileAccessPurpose = 'preview' | 'download';
export type XpertViewHostAccessLevel = 'read' | 'edit' | 'manage';
export declare const XPERT_VIEW_PROJECT_ID_HEADER = "x-xpert-view-project-id";
export declare const XPERT_VIEW_CONVERSATION_ID_HEADER = "x-xpert-view-conversation-id";
export type XpertViewSortDirection = 'asc' | 'desc';
export type XpertViewFilterOperator = 'eq' | 'neq' | 'contains' | 'starts_with' | 'ends_with' | 'in' | 'gt' | 'gte' | 'lt' | 'lte';
export type XpertViewScalar = string | number | boolean | null;
export interface XpertViewHostContext {
    tenantId: string;
    organizationId?: string | null;
    workspaceId?: string | null;
    userId: string;
    hostType: XpertViewHostType;
    hostId: string;
    module?: string;
    route?: string;
    /** Current actor permissions narrowed to the resolved host; never grants additional authority. */
    permissions?: string[];
    locale?: string;
    runtimeScope?: XpertViewRuntimeScope;
}
export interface XpertViewHostCapabilities {
    features?: string[];
    featureProviders?: Record<string, XpertViewFeatureProvider[]>;
}
export interface XpertViewRuntimeScopeInput {
    /** Route through the group boundary; the server resolves and validates its runtime. */
    groupId?: string | null;
    projectId?: string | null;
    conversationId?: string | null;
}
export interface XpertViewFeatureProvider {
    xpertId: string;
    name: string;
}
export interface XpertViewProjectAccess {
    role: 'owner' | 'manager' | 'editor' | 'member';
    canRead: boolean;
    canEdit: boolean;
    canManage: boolean;
    canUse: boolean;
}
export interface XpertViewWorkspaceFilesScope {
    catalog: 'projects' | 'xperts' | 'user-xperts';
    scopeId: string;
    projectId?: string | null;
    xpertId?: string | null;
    userId?: string | null;
    isolateByUser?: boolean;
}
export interface XpertViewRuntimeScope {
    projectId: string | null;
    conversationId: string | null;
    dataScopeKey: string;
    project?: {
        id: string;
        name: string;
        status?: string | null;
    } | null;
    projectAccess?: XpertViewProjectAccess | null;
    workspaceFiles: XpertViewWorkspaceFilesScope;
}
export interface XpertViewRuntimeScopeInput {
    projectId?: string | null;
    conversationId?: string | null;
}
export interface XpertViewProjectAccess {
    role: 'owner' | 'manager' | 'editor' | 'member';
    canRead: boolean;
    canEdit: boolean;
    canManage: boolean;
    canUse: boolean;
}
export interface XpertViewWorkspaceFilesScope {
    catalog: 'projects' | 'xperts' | 'user-xperts';
    scopeId: string;
    projectId?: string | null;
    xpertId?: string | null;
    userId?: string | null;
    isolateByUser?: boolean;
}
export interface XpertViewRuntimeScope {
    projectId: string | null;
    conversationId: string | null;
    dataScopeKey: string;
    project?: {
        id: string;
        name: string;
        status?: string | null;
    } | null;
    projectAccess?: XpertViewProjectAccess | null;
    workspaceFiles: XpertViewWorkspaceFilesScope;
}
export type XpertViewHostState = Record<string, unknown>;
export interface XpertResolvedViewHostContext extends XpertViewHostContext {
    application?: {
        installationId: string;
        pluginName: string;
        appName: string;
        scope: PluginApplicationScope;
        ownerUserId: string | null;
    } | null;
    assistant?: XpertViewAssistantIdentity;
    slots: XpertViewSlot[];
    hostSnapshot?: unknown;
    capabilities?: XpertViewHostCapabilities;
    hostState?: XpertViewHostState;
}
export interface XpertViewSlot {
    key: string;
    title?: I18nObject;
    mode: XpertViewSlotMode;
    order?: number;
    manifestPolicy?: {
        requireFeatureActivation?: boolean;
    };
}
export interface XpertViewSource {
    provider: string;
    plugin?: string;
    version?: string;
}
export interface XpertViewBadge {
    type: 'count' | 'status' | 'text';
    value?: string | number;
}
export interface XpertViewPolling {
    enabled: boolean;
    intervalMs?: number;
}
export interface XpertViewActivation {
    /** Allow direct document opening in an authorized Project without enabling Assistant tools.
     * Discovery still observes requiredFeatures. Providers must authorize each selected resource
     * and action; this flag grants neither Project membership nor resource write access. */
    projectResource?: boolean;
    requiredFeatures?: string[];
}
export interface XpertWorkbenchViewOptions {
    /** Project type required by this View. UI recovery hint only; providers still enforce access. */
    projectType?: XpertProjectTypeRef;
    /**
     * @deprecated Use the manifest's `visible` field for visibility and `openMode`
     * for initial tab behavior. Retained for compatibility; false hides the view.
     */
    fixed?: boolean;
    /**
     * Initial tab behavior; defaults to auto. On-demand views open through a
     * menu, navigation or live Agent request. This does not grant view access.
     */
    openMode?: 'auto' | 'on-demand';
    /** Opt into conversation changes while retaining the mounted Remote View. */
    contextScope?: 'project' | 'conversation';
    menu?: {
        /** Controls the manual entry only; does not disable the view or navigation. */
        enabled?: boolean;
        label?: string | I18nObject;
        order?: number;
        icon?: IconDefinition;
    };
}
export interface XpertViewCachePolicy {
    enabled?: boolean;
    ttlMs?: number;
}
export interface XpertViewQuerySchema {
    supportsPagination?: boolean;
    supportsSearch?: boolean;
    supportsSort?: boolean;
    supportsFilter?: boolean;
    supportsCursor?: boolean;
    supportsSelection?: boolean;
    supportsParameters?: boolean;
    defaultPageSize?: number;
}
export interface XpertViewDataSource {
    mode: 'platform';
    querySchema?: XpertViewQuerySchema;
    cache?: XpertViewCachePolicy;
    polling?: XpertViewPolling;
}
export interface XpertViewFilter {
    key: string;
    operator?: XpertViewFilterOperator;
    value: XpertViewScalar | XpertViewScalar[];
}
export interface XpertViewQuery {
    page?: number;
    pageSize?: number;
    cursor?: string;
    search?: string;
    sortBy?: string;
    sortDirection?: XpertViewSortDirection;
    filters?: XpertViewFilter[];
    selectionId?: string;
    parameters?: Record<string, XpertViewScalar | XpertViewScalar[]>;
}
export interface XpertStatsViewSchema {
    type: 'stats';
    items: Array<{
        key: string;
        label: I18nObject;
        valueType?: XpertViewValueType;
    }>;
}
export interface XpertTableViewSchema {
    type: 'table';
    columns: Array<{
        key: string;
        label: I18nObject;
        dataType?: XpertViewColumnDataType;
        width?: string;
        sortable?: boolean;
        searchable?: boolean;
    }>;
    pagination?: {
        enabled: boolean;
        pageSize?: number;
    };
    search?: {
        enabled: boolean;
        placeholder?: I18nObject;
    };
}
export interface XpertListViewSchema {
    type: 'list';
    item: {
        titleKey: string;
        subtitleKey?: string;
        descriptionKey?: string;
        metaKeys?: string[];
    };
    pagination?: {
        enabled: boolean;
        pageSize?: number;
    };
    search?: {
        enabled: boolean;
        placeholder?: I18nObject;
    };
}
export interface XpertDetailViewSchema {
    type: 'detail';
    fields: Array<{
        key: string;
        label: I18nObject;
        dataType?: XpertViewValueType;
    }>;
}
export interface XpertRawJsonViewSchema {
    type: 'raw_json';
}
export interface XpertRemoteComponentViewSchema {
    type: 'remote_component';
    runtime: XpertRemoteComponentRuntime;
    protocolVersion: 1;
    component: {
        isolation: 'iframe' | 'module_federation';
        entry: string;
        module?: string;
        exportName?: string;
        integrity?: string;
        propsSchema?: JsonSchemaObjectType;
    };
    dataSource: {
        mode: 'platform';
    };
    actions?: XpertViewActionDefinition[];
}
export interface XpertRemoteComponentEntry {
    html: string;
    contentType?: 'text/html; charset=utf-8';
}
export type XpertViewSchema = XpertStatsViewSchema | XpertTableViewSchema | XpertListViewSchema | XpertDetailViewSchema | XpertRawJsonViewSchema | XpertRemoteComponentViewSchema;
export interface XpertViewParameterDefinition {
    key: string;
    label: I18nObject;
    description?: I18nObject;
    required?: boolean;
    type?: 'string' | 'number' | 'boolean';
    optionSource?: {
        mode: 'provider';
        searchable?: boolean;
        preload?: boolean;
        dependsOn?: string[];
    };
}
export interface XpertViewParameterOption {
    value: XpertViewScalar;
    label: string;
    description?: string | null;
    disabled?: boolean;
}
export interface XpertViewParameterOptionsQuery {
    search?: string;
    parameters?: Record<string, XpertViewScalar | XpertViewScalar[]>;
}
export interface XpertViewParameterOptionsResult {
    items: XpertViewParameterOption[];
}
export interface XpertViewActionDefinition {
    key: string;
    label: I18nObject;
    icon?: string;
    placement?: XpertViewActionPlacement;
    actionType: XpertViewActionType;
    transport?: XpertViewActionTransport;
    inputSchema?: JsonSchemaObjectType;
    inputDefaults?: 'target' | Record<string, unknown>;
    confirm?: {
        title?: I18nObject;
        message?: I18nObject;
    };
    permissions?: string[];
    requiredHostAccess?: XpertViewHostAccessLevel;
}
export interface XpertViewFileAccessDefinition {
    purposes: XpertViewFileAccessPurpose[];
}
export interface XpertViewFileAccessRequest {
    fileKey: string;
    targetId?: string;
    purpose: XpertViewFileAccessPurpose;
}
export interface XpertViewFileAccessSessionResult {
    sessionId: string;
    expiresAt: string;
}
export interface XpertViewFileAccessGrantResult {
    url: string;
    expiresAt: string;
    fileName: string;
    mimeType: string;
    size?: number;
}
export declare const ASSISTANT_CITATION_OPEN_EVENT = "assistant.citation.open";
export declare const KNOWLEDGEBASE_OPEN_CITATION_EFFECT = "knowledgebase.open_citation";
/**
 * Action a host should take when a view host event matches a manifest subscription.
 */
export type XpertViewHostEventSubscriptionActionType = 'refresh' | 'forward' | 'refresh-and-forward';
/**
 * Declarative host event subscription owned by a view manifest.
 */
export interface XpertViewHostEventSubscription {
    /** Stable subscription key used for de-duping and diagnostics. */
    key: string;
    /** Machine-readable event type, for example `assistant.tool.completed`. */
    event: string;
    filter?: {
        /** Optional event source allow-list, for example `chatkit`. */
        sources?: string[];
        /** Optional tool name allow-list for assistant tool completion events. */
        toolNames?: string[];
        /** Optional remote view key allow-list for visualization events. */
        viewKeys?: string[];
        /** Optional visualization type allow-list. */
        visualizationTypes?: string[];
    };
    action?: {
        /** Defaults to `refresh` when omitted. */
        type?: XpertViewHostEventSubscriptionActionType;
        /** Suppresses repeated matching events with the same debounce key for this duration. */
        debounceMs?: number;
    };
}
/**
 * Host event subscriptions declared by a remote view manifest.
 */
export interface XpertViewHostEvents {
    subscriptions?: XpertViewHostEventSubscription[];
}
/**
 * Optional visualization metadata attached to a host event.
 */
export interface XpertViewHostEventVisualization {
    /** Visualization renderer/type discriminator. */
    type?: string;
    /** Remote view key associated with the emitted visualization. */
    viewKey?: string;
    /** Human-readable visualization title. */
    title?: string;
    /** Host slot that should receive the visualization. */
    slotKey?: string;
    /** Parameter key associated with this visualization payload. */
    parameterKey?: string;
}
/**
 * Event payload forwarded to remote components. Keep this shape host-agnostic so
 * the same plugin can run in xpert and data-xpert.
 */
export interface XpertRemoteViewHostEventMessage {
    /** Stable event id for diagnostics and de-duping. */
    id: string;
    /** Machine-readable event type, for example `assistant.tool.completed`. */
    type: string;
    /** Event source, for example `chatkit`. */
    source: string;
    /** ISO timestamp captured when the host normalized the event. */
    receivedAt: string;
    /** Conversation or execution thread id when available. */
    threadId?: string;
    /** Tool name for assistant tool events. */
    toolName?: string;
    /** Tool call id when provided by the runtime. */
    toolCallId?: string;
    /** Runtime run id when provided by the runtime. */
    runId?: string;
    /** Tool duration in milliseconds when provided by the runtime. */
    durationMs?: number;
    /** Opaque event data. Plugin-specific ids stay inside this payload. */
    data?: Record<string, unknown>;
    /** Optional visualization metadata used by manifest filters and remote views. */
    visualization?: XpertViewHostEventVisualization;
}
/** Sent to every mounted View after an authorized runtime context change, including hidden Views. */
export interface XpertRemoteViewContextChangedEvent extends XpertRemoteViewHostEventMessage {
    type: 'view.context.changed';
    data: {
        /** Monotonic within this View instance; stale asynchronous results must be ignored. */
        revision: number;
        /** Complete target scope. Null means no binding, never a scope still being resolved. */
        runtimeScope: Required<XpertViewRuntimeScopeInput>;
    };
}
/** Credential-free activation signal from the top-level shell to its embedded views. */
export interface XpertHostLifecycleMessage {
    channel: 'xpertai.host_lifecycle';
    protocolVersion: 1;
    type: 'activated';
}
/**
 * Host-internal event message. `hostType` and `hostId` are routing fields and
 * must be stripped before forwarding to remote components.
 */
export interface XpertViewHostEventMessage extends XpertRemoteViewHostEventMessage {
    hostType?: string;
    hostId?: string;
    dataScopeKey?: string;
}
export interface XpertExtensionViewManifest {
    key: string;
    title: I18nObject;
    description?: I18nObject;
    icon?: IconDefinition;
    hostType: XpertViewHostType;
    slot: string;
    order?: number;
    visible?: boolean;
    source: XpertViewSource;
    permissions?: string[];
    badge?: XpertViewBadge;
    refreshable?: boolean;
    polling?: XpertViewPolling;
    activation?: XpertViewActivation;
    runtime?: {
        /** Host-derived Assistants that satisfy every required Feature. Provider declarations are ignored. */
        featureProviders?: XpertViewFeatureProvider[];
    };
    workbench?: XpertWorkbenchViewOptions;
    view: XpertViewSchema;
    dataSource: XpertViewDataSource;
    parameters?: XpertViewParameterDefinition[];
    actions?: XpertViewActionDefinition[];
    clientCommands?: XpertViewClientCommandDefinition[];
    fileAccess?: XpertViewFileAccessDefinition;
    hostEvents?: XpertViewHostEvents;
}
export interface XpertViewActionRequest {
    targetId?: string;
    input?: Record<string, unknown> | null;
    parameters?: Record<string, XpertViewScalar | XpertViewScalar[]>;
}
export interface XpertViewDataResult<TItem = unknown, TSummary = unknown> {
    items?: TItem[];
    item?: TItem;
    total?: number;
    nextCursor?: string;
    summary?: TSummary;
    meta?: unknown;
}
export interface XpertViewActionResult<TData = unknown> {
    success: boolean;
    message?: I18nObject;
    data?: TData;
    refresh?: boolean;
    /** Explicitly safe business validation; unclassified failure details remain operator-only. */
    failure?: {
        kind: 'business';
        code: string;
    };
}
