/** Assistant Workbench slot; openMode controls initial tab opening separately. */
export declare const AGENT_WORKBENCH_SLOT = "agent.workbench";
/** Legacy plugin declarations and client requests; normalized to AGENT_WORKBENCH_SLOT by the host. */
export declare const LEGACY_AGENT_WORKBENCH_SLOTS: readonly ["agent.workbench.fixed", "agent.workbench.main"];
/** Platform-provided navigation, available without Assistant middleware. */
export declare const CONVERSATION_MAP_FEATURE = "platform.conversation-map";
