import { z } from 'zod/v3';
/** An integration reference must name the Connector authentication method that consumes it. */
export declare const workspaceConnectorAuthorizationSchema: z.ZodEffects<z.ZodObject<{
    authMethodId: z.ZodOptional<z.ZodString>;
    integrationId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    integrationId?: string;
    authMethodId?: string;
}, {
    integrationId?: string;
    authMethodId?: string;
}>, {
    integrationId?: string;
    authMethodId?: string;
}, {
    integrationId?: string;
    authMethodId?: string;
}>;
export type WorkspaceConnectorAuthorization = z.infer<typeof workspaceConnectorAuthorizationSchema>;
/** Intent only: the host resolves workspace identity, permissions and available Connector definitions. */
export declare const workspaceConnectorConnectPayloadSchema: z.ZodEffects<z.ZodObject<{
    authMethodId: z.ZodOptional<z.ZodString>;
    integrationId: z.ZodOptional<z.ZodString>;
    provider: z.ZodString;
}, "strict", z.ZodTypeAny, {
    provider?: string;
    integrationId?: string;
    authMethodId?: string;
}, {
    provider?: string;
    integrationId?: string;
    authMethodId?: string;
}>, {
    provider?: string;
    integrationId?: string;
    authMethodId?: string;
}, {
    provider?: string;
    integrationId?: string;
    authMethodId?: string;
}>;
export type WorkspaceConnectorConnectPayload = z.infer<typeof workspaceConnectorConnectPayloadSchema>;
