import type { WorkbenchExtensionViewOpenRequest } from './client-commands';
/** Live-only UI request. Project scope is mandatory; history playback must not reopen Views. */
export declare const WORKBENCH_VIEW_OPEN_EVENT = "workbench.view.open";
/**
 * Server-emitted instruction to open a declared View in the current Workbench context.
 * Consumers verify Project/conversation scope and suppress stale or duplicate requests; the event grants no resource access.
 * requestId and issuedAt are optional as a pair for legacy emitters; new navigation emitters should provide both.
 */
export interface WorkbenchViewOpenEvent extends WorkbenchExtensionViewOpenRequest {
    /** Stable event discriminator; arbitrary logs and similarly shaped objects are not navigation requests. */
    type: typeof WORKBENCH_VIEW_OPEN_EVENT;
    /** Project that owns the navigation context; must match the active authorized Workbench scope. */
    projectId: string;
    /** Unique event deduplication ID, separate from the View's selectionId; supply together with issuedAt. */
    requestId?: string;
    /** Positive Unix epoch milliseconds used for freshness checks; supply together with requestId. */
    issuedAt?: number;
    /** Conversation restriction when present; consumers must not apply it to another conversation. */
    conversationId?: string;
}
/**
 * Parse the public lg.chat.event shape and paired replay metadata, keeping arbitrary logs out of navigation.
 * Returns null for invalid payloads. Shape validation does not perform access, active-scope or freshness checks.
 */
export declare function parseWorkbenchViewOpenEvent(value: unknown): WorkbenchViewOpenEvent | null;
