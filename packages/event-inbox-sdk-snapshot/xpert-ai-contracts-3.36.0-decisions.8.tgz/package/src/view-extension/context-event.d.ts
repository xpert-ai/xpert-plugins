import { z } from 'zod/v3';
/** Context revision and runtime scope delivered by an authorized Remote View host. */
export declare const viewContextEventSchema: z.ZodEffects<z.ZodObject<{
    type: z.ZodLiteral<"view.context.changed">;
    data: z.ZodObject<{
        revision: z.ZodNumber;
        runtimeScope: z.ZodObject<{
            projectId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            conversationId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            conversationId?: string;
            projectId?: string;
        }, {
            conversationId?: string;
            projectId?: string;
        }>;
    }, "strip", z.ZodTypeAny, {
        revision?: number;
        runtimeScope?: {
            conversationId?: string;
            projectId?: string;
        };
    }, {
        revision?: number;
        runtimeScope?: {
            conversationId?: string;
            projectId?: string;
        };
    }>;
}, "strip", z.ZodTypeAny, {
    type?: "view.context.changed";
    data?: {
        revision?: number;
        runtimeScope?: {
            conversationId?: string;
            projectId?: string;
        };
    };
}, {
    type?: "view.context.changed";
    data?: {
        revision?: number;
        runtimeScope?: {
            conversationId?: string;
            projectId?: string;
        };
    };
}>, {
    type: "view.context.changed";
    data: {
        revision: number;
        runtimeScope: {
            conversationId?: string;
            projectId?: string;
        };
    };
}, {
    type?: "view.context.changed";
    data?: {
        revision?: number;
        runtimeScope?: {
            conversationId?: string;
            projectId?: string;
        };
    };
}>;
