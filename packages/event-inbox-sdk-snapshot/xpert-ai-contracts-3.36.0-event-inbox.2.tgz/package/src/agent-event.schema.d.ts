import { z } from 'zod/v3';
export declare const agentEventRefSchema: z.ZodObject<{
    kind: z.ZodEffects<z.ZodString, string, string>;
    key: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    kind: string;
    key: string;
}, {
    kind: string;
    key: string;
}>;
export declare const pluginAgentEventSchema: z.ZodObject<{
    sourceEventId: z.ZodEffects<z.ZodString, string, string>;
    bindingRevision: z.ZodNumber;
    type: z.ZodEffects<z.ZodString, string, string>;
    schemaVersion: z.ZodNumber;
    occurredAt: z.ZodString;
    subject: z.ZodObject<{
        kind: z.ZodEffects<z.ZodString, string, string>;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        kind: string;
        key: string;
    }, {
        kind: string;
        key: string;
    }>;
    fact: z.ZodObject<{
        key: z.ZodEffects<z.ZodString, string, string>;
        revision: z.ZodEffects<z.ZodString, string, string>;
        sha256: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        key: string;
        revision: string;
        sha256: string;
    }, {
        key: string;
        revision: string;
        sha256: string;
    }>;
}, "strict", z.ZodTypeAny, {
    type: string;
    sourceEventId: string;
    bindingRevision: number;
    schemaVersion: number;
    occurredAt: string;
    subject: {
        kind: string;
        key: string;
    };
    fact: {
        key: string;
        revision: string;
        sha256: string;
    };
}, {
    type: string;
    sourceEventId: string;
    bindingRevision: number;
    schemaVersion: number;
    occurredAt: string;
    subject: {
        kind: string;
        key: string;
    };
    fact: {
        key: string;
        revision: string;
        sha256: string;
    };
}>;
export type AgentEventRef = z.infer<typeof agentEventRefSchema>;
export type PluginAgentEvent = z.infer<typeof pluginAgentEventSchema>;
export declare const agentEventDecisionSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"handled">;
    operationKey: z.ZodEffects<z.ZodString, string, string>;
    resultRef: z.ZodObject<{
        kind: z.ZodEffects<z.ZodString, string, string>;
        key: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        kind: string;
        key: string;
    }, {
        kind: string;
        key: string;
    }>;
}, "strict", z.ZodTypeAny, {
    status: "handled";
    operationKey: string;
    resultRef: {
        kind: string;
        key: string;
    };
}, {
    status: "handled";
    operationKey: string;
    resultRef: {
        kind: string;
        key: string;
    };
}>, z.ZodObject<{
    status: z.ZodLiteral<"ignored">;
    reasonCode: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status: "ignored";
    reasonCode: string;
}, {
    status: "ignored";
    reasonCode: string;
}>, z.ZodObject<{
    status: z.ZodLiteral<"blocked">;
    reasonCode: z.ZodString;
}, "strict", z.ZodTypeAny, {
    status: "blocked";
    reasonCode: string;
}, {
    status: "blocked";
    reasonCode: string;
}>]>;
export type EventDecision = z.infer<typeof agentEventDecisionSchema>;
