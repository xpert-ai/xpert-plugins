import { z } from 'zod';
export declare const templatePublicationInputSchema: z.ZodObject<{
    revision: z.ZodString;
    contentHash: z.ZodString;
    visibility: z.ZodEnum<["team", "public"]>;
    version: z.ZodString;
    releaseNotes: z.ZodDefault<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    revision?: string;
    version?: string;
    contentHash?: string;
    visibility?: "public" | "team";
    releaseNotes?: string;
}, {
    revision?: string;
    version?: string;
    contentHash?: string;
    visibility?: "public" | "team";
    releaseNotes?: string;
}>;
export type TemplatePublicationInput = z.output<typeof templatePublicationInputSchema>;
export interface TemplatePublicationPreview {
    revision: string;
    contentHash: string;
    content: string;
    omitted: string[];
    blocked: string[];
    publication?: {
        id: string;
        version: string;
        visibility: 'team' | 'public';
        revoked: boolean;
    };
}
export declare const templateUpgradeSectionSchema: z.ZodEnum<["presentation", "instructions", "runtime", "definition"]>;
export type TemplateUpgradeSection = z.output<typeof templateUpgradeSectionSchema>;
export declare const templateUpgradeInputSchema: z.ZodObject<{
    targetTemplateId: z.ZodOptional<z.ZodString>;
    revision: z.ZodString;
    sourceHash: z.ZodString;
    choices: z.ZodRecord<z.ZodEnum<["presentation", "instructions", "runtime", "definition"]>, z.ZodEnum<["keep", "replace"]>>;
}, "strict", z.ZodTypeAny, {
    revision?: string;
    sourceHash?: string;
    targetTemplateId?: string;
    choices?: Partial<Record<"runtime" | "instructions" | "presentation" | "definition", "replace" | "keep">>;
}, {
    revision?: string;
    sourceHash?: string;
    targetTemplateId?: string;
    choices?: Partial<Record<"runtime" | "instructions" | "presentation" | "definition", "replace" | "keep">>;
}>;
export type TemplateUpgradeInput = z.output<typeof templateUpgradeInputSchema>;
export interface TemplateUpgradeSource {
    id: string;
    title: string;
    source?: string;
}
export interface TemplateUpgradePreview {
    previousTemplateId?: string;
    revision: string;
    sourceHash: string;
    templateId: string;
    version: string;
    releaseNotes: string;
    baselineAvailable: boolean;
    blocked: string[];
    changes: {
        section: TemplateUpgradeSection;
        conflict: boolean;
        before: string;
        after: string;
    }[];
    operation?: TemplateUpgradeOperation;
}
export interface TemplateUpgradeOperation {
    id: string;
    state: 'draft' | 'published' | 'failed' | 'rolled-back';
    canResume: boolean;
    canRollback: boolean;
}
export declare const templateUpgradeActionSchema: z.ZodObject<{
    operationId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    operationId?: string;
}, {
    operationId?: string;
}>;
export type TemplateUpgradeAction = z.output<typeof templateUpgradeActionSchema>;
