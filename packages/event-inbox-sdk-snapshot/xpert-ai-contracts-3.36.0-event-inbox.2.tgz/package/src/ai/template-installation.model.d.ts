import { z } from 'zod';
import type { TAvatar } from '../types';
import type { TCopilotModel } from './copilot-model.model';
import type { RealtimeVoiceSelection } from './realtime-voice.model';
/** Reuse a key only for the same installation intent; a new key creates another Assistant. */
export interface TemplateInstallationInput {
    idempotencyKey: string;
    templateId: string;
    workspaceId: string;
    publish?: boolean;
    locale?: string;
    capabilities?: string[];
    basic?: {
        name?: string;
        title?: string;
        description?: string;
        prompt?: string;
        avatar?: Omit<TAvatar, 'appearance'>;
        copilotModel?: Pick<TCopilotModel, 'copilotId' | 'model' | 'modelType' | 'options'>;
        workspaceDataScope?: 'shared' | 'user';
        realtimeVoice?: RealtimeVoiceSelection;
    };
}
export type TemplateInstallationStage = 'importing' | 'dependencies' | 'publishing' | 'initializing' | 'completed';
export type TemplateInstallationStatus = 'running' | 'interrupted' | 'failed' | 'succeeded';
/** Public receipt, deliberately excluding stored input, source content and runtime errors. */
export interface TemplateInstallation {
    dependencyLocks?: TemplateDependencyLock[];
    id: string;
    templateId: string;
    workspaceId: string;
    status: TemplateInstallationStatus;
    stage: TemplateInstallationStage;
    attempt: number;
    assistantId: string | null;
    /** Current authoring access to the target, independent of the historical installation result. Absent on older servers. */
    assistantAvailability?: 'available' | 'unavailable';
    publish: boolean;
    retryable: boolean;
    error: {
        code: 'INSTALL_FAILED' | 'SOURCE_CHANGED';
        message: string;
    } | null;
    resourceInstallationIds: string[];
    pendingAuthInstallationIds: string[];
    createdAt: string;
    updatedAt: string;
}
export declare const templateDependencyVersionsSchema: z.ZodArray<z.ZodObject<{
    pluginName: z.ZodString;
    version: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version?: string;
    pluginName?: string;
}, {
    version?: string;
    pluginName?: string;
}>, "many">;
export declare const templateDependencyLocksSchema: z.ZodArray<z.ZodObject<{
    pluginName: z.ZodString;
    version: z.ZodString;
    /** Explicit template requirement, distinct from the automatically recorded installation version. */
    requiredVersion: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"agent-plugin">;
        name: z.ZodString;
        digest: z.ZodString;
        bindingId: z.ZodString;
        bindingVersion: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind?: "agent-plugin";
        name?: string;
        digest?: string;
        bindingId?: string;
        bindingVersion?: string;
    }, {
        kind?: "agent-plugin";
        name?: string;
        digest?: string;
        bindingId?: string;
        bindingVersion?: string;
    }>>;
    providers: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<["middleware", "sandbox", "toolset"]>;
        key: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind?: "toolset" | "sandbox" | "middleware";
        key?: string;
    }, {
        kind?: "toolset" | "sandbox" | "middleware";
        key?: string;
    }>, "many">>;
    components: z.ZodArray<z.ZodObject<{
        type: z.ZodEnum<["skill", "mcp_server", "toolset", "app", "hook", "asset"]>;
        key: z.ZodString;
        hash: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        type?: "toolset" | "skill" | "app" | "asset" | "mcp_server" | "hook";
        hash?: string;
    }, {
        key?: string;
        type?: "toolset" | "skill" | "app" | "asset" | "mcp_server" | "hook";
        hash?: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    version?: string;
    source?: {
        kind?: "agent-plugin";
        name?: string;
        digest?: string;
        bindingId?: string;
        bindingVersion?: string;
    };
    pluginName?: string;
    requiredVersion?: string;
    providers?: {
        kind?: "toolset" | "sandbox" | "middleware";
        key?: string;
    }[];
    components?: {
        key?: string;
        type?: "toolset" | "skill" | "app" | "asset" | "mcp_server" | "hook";
        hash?: string;
    }[];
}, {
    version?: string;
    source?: {
        kind?: "agent-plugin";
        name?: string;
        digest?: string;
        bindingId?: string;
        bindingVersion?: string;
    };
    pluginName?: string;
    requiredVersion?: string;
    providers?: {
        kind?: "toolset" | "sandbox" | "middleware";
        key?: string;
    }[];
    components?: {
        key?: string;
        type?: "toolset" | "skill" | "app" | "asset" | "mcp_server" | "hook";
        hash?: string;
    }[];
}>, "many">;
export type TemplateDependencyLock = z.output<typeof templateDependencyLocksSchema>[number];
/** Advisory drift in an available runtime dependency; never a compatibility guarantee. */
export interface TemplateDependencyUpdate {
    pluginName: string;
    installedVersion: string;
    currentVersion: string;
    changedComponents: {
        type: TemplateDependencyLock['components'][number]['type'];
        key: string;
    }[];
}
export interface TemplateRuntimeDependencyReport {
    updates: TemplateDependencyUpdate[];
}
