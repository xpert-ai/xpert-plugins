import { z } from 'zod/v3';
/** Runtime-owned activity semantics. Display names and model prose are never classifiers. */
export declare const trailActivityKindSchema: z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>;
export type TrailActivityKind = z.infer<typeof trailActivityKindSchema>;
export declare const trailStatusSchema: z.ZodEnum<["running", "success", "error", "pending", "waiting", "cancelling", "idle", "interrupted", "unknown"]>;
export type TrailStatus = z.infer<typeof trailStatusSchema>;
export declare const trailStepSchema: z.ZodObject<{
    toolCallId: z.ZodOptional<z.ZodString>;
    startedAt: z.ZodOptional<z.ZodString>;
    endedAt: z.ZodOptional<z.ZodString>;
    preview: z.ZodOptional<z.ZodString>;
    answer: z.ZodOptional<z.ZodString>;
    input: z.ZodOptional<z.ZodString>;
    output: z.ZodOptional<z.ZodString>;
    messageId: z.ZodOptional<z.ZodString>;
    threadId: z.ZodOptional<z.ZodString>;
    executionId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    laneId: z.ZodString;
    kind: z.ZodEnum<["turn", "tool", "message"]>;
    activity: z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>;
    title: z.ZodString;
    status: z.ZodEnum<["running", "success", "error", "pending", "waiting", "cancelling", "idle", "interrupted", "unknown"]>;
    order: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    kind: "message" | "turn" | "tool";
    status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
    id: string;
    laneId: string;
    activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
    title: string;
    order: number;
    answer?: string | undefined;
    toolCallId?: string | undefined;
    startedAt?: string | undefined;
    endedAt?: string | undefined;
    preview?: string | undefined;
    input?: string | undefined;
    output?: string | undefined;
    messageId?: string | undefined;
    threadId?: string | undefined;
    executionId?: string | undefined;
}, {
    kind: "message" | "turn" | "tool";
    status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
    id: string;
    laneId: string;
    activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
    title: string;
    order: number;
    answer?: string | undefined;
    toolCallId?: string | undefined;
    startedAt?: string | undefined;
    endedAt?: string | undefined;
    preview?: string | undefined;
    input?: string | undefined;
    output?: string | undefined;
    messageId?: string | undefined;
    threadId?: string | undefined;
    executionId?: string | undefined;
}>;
export declare const trailLaneSchema: z.ZodObject<{
    invocationKind: z.ZodOptional<z.ZodEnum<["sub_agent", "external_assistant", "activity"]>>;
    purpose: z.ZodOptional<z.ZodEnum<["side-chat", "message-edit"]>>;
    elapsedMs: z.ZodOptional<z.ZodNumber>;
    outcome: z.ZodOptional<z.ZodObject<{
        status: z.ZodString;
        accepted: z.ZodBoolean;
        message: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status: string;
        accepted: boolean;
        message?: string | undefined;
    }, {
        status: string;
        accepted: boolean;
        message?: string | undefined;
    }>>;
    messageId: z.ZodOptional<z.ZodString>;
    threadId: z.ZodOptional<z.ZodString>;
    executionId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentId: z.ZodNullable<z.ZodString>;
    spawnStepId: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    primary: z.ZodBoolean;
    status: z.ZodEnum<["running", "success", "error", "pending", "waiting", "cancelling", "idle", "interrupted", "unknown"]>;
}, "strip", z.ZodTypeAny, {
    status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
    id: string;
    title: string;
    parentId: string | null;
    primary: boolean;
    messageId?: string | undefined;
    threadId?: string | undefined;
    executionId?: string | undefined;
    spawnStepId?: string | undefined;
    invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
    purpose?: "side-chat" | "message-edit" | undefined;
    elapsedMs?: number | undefined;
    outcome?: {
        status: string;
        accepted: boolean;
        message?: string | undefined;
    } | undefined;
}, {
    status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
    id: string;
    title: string;
    parentId: string | null;
    primary: boolean;
    messageId?: string | undefined;
    threadId?: string | undefined;
    executionId?: string | undefined;
    spawnStepId?: string | undefined;
    invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
    purpose?: "side-chat" | "message-edit" | undefined;
    elapsedMs?: number | undefined;
    outcome?: {
        status: string;
        accepted: boolean;
        message?: string | undefined;
    } | undefined;
}>;
export declare const trailEpisodeSchema: z.ZodObject<{
    id: z.ZodString;
    laneId: z.ZodString;
    activity: z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>;
    stepIds: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    id: string;
    laneId: string;
    activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
    stepIds: string[];
}, {
    id: string;
    laneId: string;
    activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
    stepIds: string[];
}>;
export declare const trailGraphSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    layer: z.ZodEnum<["conversation", "execution"]>;
    conversationId: z.ZodString;
    threadId: z.ZodString;
    messageId: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    lanes: z.ZodArray<z.ZodObject<{
        invocationKind: z.ZodOptional<z.ZodEnum<["sub_agent", "external_assistant", "activity"]>>;
        purpose: z.ZodOptional<z.ZodEnum<["side-chat", "message-edit"]>>;
        elapsedMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodObject<{
            status: z.ZodString;
            accepted: z.ZodBoolean;
            message: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        }, {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        }>>;
        messageId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        executionId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentId: z.ZodNullable<z.ZodString>;
        spawnStepId: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        primary: z.ZodBoolean;
        status: z.ZodEnum<["running", "success", "error", "pending", "waiting", "cancelling", "idle", "interrupted", "unknown"]>;
    }, "strip", z.ZodTypeAny, {
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        title: string;
        parentId: string | null;
        primary: boolean;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
        spawnStepId?: string | undefined;
        invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
        purpose?: "side-chat" | "message-edit" | undefined;
        elapsedMs?: number | undefined;
        outcome?: {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        } | undefined;
    }, {
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        title: string;
        parentId: string | null;
        primary: boolean;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
        spawnStepId?: string | undefined;
        invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
        purpose?: "side-chat" | "message-edit" | undefined;
        elapsedMs?: number | undefined;
        outcome?: {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        } | undefined;
    }>, "many">;
    steps: z.ZodArray<z.ZodObject<{
        toolCallId: z.ZodOptional<z.ZodString>;
        startedAt: z.ZodOptional<z.ZodString>;
        endedAt: z.ZodOptional<z.ZodString>;
        preview: z.ZodOptional<z.ZodString>;
        answer: z.ZodOptional<z.ZodString>;
        input: z.ZodOptional<z.ZodString>;
        output: z.ZodOptional<z.ZodString>;
        messageId: z.ZodOptional<z.ZodString>;
        threadId: z.ZodOptional<z.ZodString>;
        executionId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        laneId: z.ZodString;
        kind: z.ZodEnum<["turn", "tool", "message"]>;
        activity: z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>;
        title: z.ZodString;
        status: z.ZodEnum<["running", "success", "error", "pending", "waiting", "cancelling", "idle", "interrupted", "unknown"]>;
        order: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        kind: "message" | "turn" | "tool";
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        title: string;
        order: number;
        answer?: string | undefined;
        toolCallId?: string | undefined;
        startedAt?: string | undefined;
        endedAt?: string | undefined;
        preview?: string | undefined;
        input?: string | undefined;
        output?: string | undefined;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
    }, {
        kind: "message" | "turn" | "tool";
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        title: string;
        order: number;
        answer?: string | undefined;
        toolCallId?: string | undefined;
        startedAt?: string | undefined;
        endedAt?: string | undefined;
        preview?: string | undefined;
        input?: string | undefined;
        output?: string | undefined;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
    }>, "many">;
    episodes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        laneId: z.ZodString;
        activity: z.ZodEnum<["task", "explore", "change", "verify", "answer", "other"]>;
        stepIds: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        stepIds: string[];
    }, {
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        stepIds: string[];
    }>, "many">;
    coverage: z.ZodArray<z.ZodEnum<["record_limit", "missing_identity", "no_execution", "timing_unavailable", "activity_unavailable", "historical"]>, "many">;
    source: z.ZodOptional<z.ZodObject<{
        conversationId: z.ZodString;
        threadId: z.ZodString;
        messageId: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        messageId: string;
        threadId: string;
        conversationId: string;
    }, {
        messageId: string;
        threadId: string;
        conversationId: string;
    }>>;
    live: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    title: string;
    threadId: string;
    version: 1;
    layer: "conversation" | "execution";
    conversationId: string;
    lanes: {
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        title: string;
        parentId: string | null;
        primary: boolean;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
        spawnStepId?: string | undefined;
        invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
        purpose?: "side-chat" | "message-edit" | undefined;
        elapsedMs?: number | undefined;
        outcome?: {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        } | undefined;
    }[];
    steps: {
        kind: "message" | "turn" | "tool";
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        title: string;
        order: number;
        answer?: string | undefined;
        toolCallId?: string | undefined;
        startedAt?: string | undefined;
        endedAt?: string | undefined;
        preview?: string | undefined;
        input?: string | undefined;
        output?: string | undefined;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
    }[];
    episodes: {
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        stepIds: string[];
    }[];
    coverage: ("record_limit" | "missing_identity" | "no_execution" | "timing_unavailable" | "activity_unavailable" | "historical")[];
    live: boolean;
    messageId?: string | undefined;
    source?: {
        messageId: string;
        threadId: string;
        conversationId: string;
    } | undefined;
}, {
    title: string;
    threadId: string;
    version: 1;
    layer: "conversation" | "execution";
    conversationId: string;
    lanes: {
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        title: string;
        parentId: string | null;
        primary: boolean;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
        spawnStepId?: string | undefined;
        invocationKind?: "activity" | "sub_agent" | "external_assistant" | undefined;
        purpose?: "side-chat" | "message-edit" | undefined;
        elapsedMs?: number | undefined;
        outcome?: {
            status: string;
            accepted: boolean;
            message?: string | undefined;
        } | undefined;
    }[];
    steps: {
        kind: "message" | "turn" | "tool";
        status: "unknown" | "running" | "success" | "error" | "pending" | "waiting" | "cancelling" | "idle" | "interrupted";
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        title: string;
        order: number;
        answer?: string | undefined;
        toolCallId?: string | undefined;
        startedAt?: string | undefined;
        endedAt?: string | undefined;
        preview?: string | undefined;
        input?: string | undefined;
        output?: string | undefined;
        messageId?: string | undefined;
        threadId?: string | undefined;
        executionId?: string | undefined;
    }[];
    episodes: {
        id: string;
        laneId: string;
        activity: "task" | "explore" | "change" | "verify" | "answer" | "other";
        stepIds: string[];
    }[];
    coverage: ("record_limit" | "missing_identity" | "no_execution" | "timing_unavailable" | "activity_unavailable" | "historical")[];
    live: boolean;
    messageId?: string | undefined;
    source?: {
        messageId: string;
        threadId: string;
        conversationId: string;
    } | undefined;
}>;
export type TrailStep = z.infer<typeof trailStepSchema>;
export type TrailLane = z.infer<typeof trailLaneSchema>;
export type TrailEpisode = z.infer<typeof trailEpisodeSchema>;
export type TrailGraph = z.infer<typeof trailGraphSchema>;
