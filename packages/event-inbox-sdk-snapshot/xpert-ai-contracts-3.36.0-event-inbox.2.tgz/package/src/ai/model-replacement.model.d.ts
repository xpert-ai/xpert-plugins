import { z } from 'zod';
import { AiModelTypeEnum } from '../agent';
import { ModelIdentity, ModelParameterChange } from './model-management.model';
export declare const modelReplacementScopeSchema: z.ZodObject<{
    workspaceId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    workspaceId?: string;
}, {
    workspaceId?: string;
}>;
export type ModelReplacementScope = z.output<typeof modelReplacementScopeSchema>;
export interface ModelReplacementSource {
    identity: ModelIdentity;
    references: number;
}
export declare const modelReplacementSchema: z.ZodEffects<z.ZodObject<{
    source: z.ZodObject<{
        copilotId: z.ZodString;
        model: z.ZodString;
    } & {
        modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
    }, "strict", z.ZodTypeAny, {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    }, {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    }>;
    target: z.ZodObject<{
        copilotId: z.ZodString;
        model: z.ZodString;
    } & {
        modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
    }, "strict", z.ZodTypeAny, {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    }, {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    }>;
    policy: z.ZodEnum<["reset", "compatible"]>;
    workspaceId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    workspaceId?: string;
    source?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    target?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    policy?: "reset" | "compatible";
}, {
    workspaceId?: string;
    source?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    target?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    policy?: "reset" | "compatible";
}>, {
    workspaceId?: string;
    source?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    target?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    policy?: "reset" | "compatible";
}, {
    workspaceId?: string;
    source?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    target?: {
        copilotId?: string;
        modelType?: AiModelTypeEnum.LLM;
        model?: string;
    };
    policy?: "reset" | "compatible";
}>;
export type ModelReplacementInput = z.output<typeof modelReplacementSchema>;
export declare const executeModelReplacementSchema: z.ZodEffects<z.ZodObject<{
    input: z.ZodEffects<z.ZodObject<{
        source: z.ZodObject<{
            copilotId: z.ZodString;
            model: z.ZodString;
        } & {
            modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
        }, "strict", z.ZodTypeAny, {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        }, {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        }>;
        target: z.ZodObject<{
            copilotId: z.ZodString;
            model: z.ZodString;
        } & {
            modelType: z.ZodLiteral<AiModelTypeEnum.LLM>;
        }, "strict", z.ZodTypeAny, {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        }, {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        }>;
        policy: z.ZodEnum<["reset", "compatible"]>;
        workspaceId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    }, {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    }>, {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    }, {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    }>;
    selections: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        revision?: string;
        id?: string;
    }, {
        revision?: string;
        id?: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    input?: {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    };
    selections?: {
        revision?: string;
        id?: string;
    }[];
}, {
    input?: {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    };
    selections?: {
        revision?: string;
        id?: string;
    }[];
}>, {
    input?: {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    };
    selections?: {
        revision?: string;
        id?: string;
    }[];
}, {
    input?: {
        workspaceId?: string;
        source?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        target?: {
            copilotId?: string;
            modelType?: AiModelTypeEnum.LLM;
            model?: string;
        };
        policy?: "reset" | "compatible";
    };
    selections?: {
        revision?: string;
        id?: string;
    }[];
}>;
export type ExecuteModelReplacementInput = z.output<typeof executeModelReplacementSchema>;
export interface ModelReplacementPreview {
    id: string;
    name: string;
    workspaceId: string;
    revision: string;
    count: number;
    changes: {
        path: string;
        parameters: ModelParameterChange[];
    }[];
    missing: string[];
}
export interface ModelReplacementResult {
    id: string;
    status: 'updated' | 'conflict' | 'failed' | 'skipped' | 'restored';
    operationId?: string;
    message?: string;
}
