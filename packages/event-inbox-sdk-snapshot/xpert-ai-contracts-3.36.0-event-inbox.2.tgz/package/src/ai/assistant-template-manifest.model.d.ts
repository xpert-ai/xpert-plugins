import type { TemplateDependencyLock } from './template-installation.model';
import { z } from 'zod';
import { ModelFeature } from './ai-model.model';
/** Portable paths only. Volume remains responsible for canonical containment and symlink checks. */
export declare const templateFilePathSchema: z.ZodEffects<z.ZodString, string, string>;
export declare const templateFilesSchema: z.ZodEffects<z.ZodObject<{
    scope: z.ZodEnum<["shared", "user"]>;
    entries: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"directory">;
        path: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        kind?: "directory";
    }, {
        path?: string;
        kind?: "directory";
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"file">;
        path: z.ZodEffects<z.ZodString, string, string>;
        content: z.ZodString;
        contentVersion: z.ZodString;
        policy: z.ZodLiteral<"create-only">;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    }, {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"ledger">;
        path: z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>;
        structureVersion: z.ZodString;
        columns: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<["string", "number", "boolean", "date"]>;
        }, "strict", z.ZodTypeAny, {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }, {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }>, "many">;
        policy: z.ZodLiteral<"create-only">;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    }, {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    }>]>, "many">;
}, "strict", z.ZodTypeAny, {
    entries?: ({
        path?: string;
        kind?: "directory";
    } | {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    } | {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    })[];
    scope?: "user" | "shared";
}, {
    entries?: ({
        path?: string;
        kind?: "directory";
    } | {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    } | {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    })[];
    scope?: "user" | "shared";
}>, {
    entries?: ({
        path?: string;
        kind?: "directory";
    } | {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    } | {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    })[];
    scope?: "user" | "shared";
}, {
    entries?: ({
        path?: string;
        kind?: "directory";
    } | {
        path?: string;
        kind?: "file";
        policy?: "create-only";
        content?: string;
        contentVersion?: string;
    } | {
        path?: string;
        kind?: "ledger";
        columns?: {
            key?: string;
            type?: "string" | "number" | "boolean" | "date";
            label?: string;
        }[];
        policy?: "create-only";
        structureVersion?: string;
    })[];
    scope?: "user" | "shared";
}>;
/** Versioned, credential-free declarations. Missing manifest preserves the legacy template contract. */
export declare const templateManifestV1Schema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    version: z.ZodString;
    skills: z.ZodOptional<z.ZodArray<z.ZodObject<{
        pluginName: z.ZodOptional<z.ZodString>;
        componentKey: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        pluginName?: string;
        componentKey?: string;
    }, {
        pluginName?: string;
        componentKey?: string;
    }>, "many">>;
    files: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        scope: z.ZodEnum<["shared", "user"]>;
        entries: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"directory">;
            path: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "directory";
        }, {
            path?: string;
            kind?: "directory";
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"file">;
            path: z.ZodEffects<z.ZodString, string, string>;
            content: z.ZodString;
            contentVersion: z.ZodString;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"ledger">;
            path: z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>;
            structureVersion: z.ZodString;
            columns: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<["string", "number", "boolean", "date"]>;
            }, "strict", z.ZodTypeAny, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }>, "many">;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>>;
    onboarding: z.ZodOptional<z.ZodObject<{
        skill: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        preferences: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
        completionCriteria: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }>>;
    connectors: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        provider: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        purpose: z.ZodString;
        permissions: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }>, "many">, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>>;
    routines: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        trigger: z.ZodEnum<["schedule", "event"]>;
        expression: z.ZodString;
        timezone: z.ZodEnum<["user", "organization"]>;
        skill: z.ZodString;
        output: z.ZodString;
        enabled: z.ZodDefault<z.ZodLiteral<false>>;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }>, "many">, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[], {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[]>>;
    execution: z.ZodOptional<z.ZodObject<{
        modelFeatures: z.ZodOptional<z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">>;
        sandbox: z.ZodOptional<z.ZodEnum<["server", "cloud-computer"]>>;
        localCapabilities: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        offline: z.ZodOptional<z.ZodEnum<["requires-online", "local-only"]>>;
    }, "strict", z.ZodTypeAny, {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }, {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }>>;
}, "strict", z.ZodTypeAny, {
    schemaVersion?: 1;
    skills?: {
        pluginName?: string;
        componentKey?: string;
    }[];
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}, {
    schemaVersion?: 1;
    skills?: {
        pluginName?: string;
        componentKey?: string;
    }[];
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}>;
/** V2 keeps only initialization and requirements that the DSL cannot express. */
export declare const assistantTemplateManifestSchema: z.ZodObject<{
    connectors: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        provider: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        purpose: z.ZodString;
        permissions: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }>, "many">, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>>;
    version: z.ZodString;
    files: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        scope: z.ZodEnum<["shared", "user"]>;
        entries: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"directory">;
            path: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "directory";
        }, {
            path?: string;
            kind?: "directory";
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"file">;
            path: z.ZodEffects<z.ZodString, string, string>;
            content: z.ZodString;
            contentVersion: z.ZodString;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"ledger">;
            path: z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>;
            structureVersion: z.ZodString;
            columns: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<["string", "number", "boolean", "date"]>;
            }, "strict", z.ZodTypeAny, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }>, "many">;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>>;
    onboarding: z.ZodOptional<z.ZodObject<{
        skill: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        preferences: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
        completionCriteria: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }>>;
    routines: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        trigger: z.ZodEnum<["schedule", "event"]>;
        expression: z.ZodString;
        timezone: z.ZodEnum<["user", "organization"]>;
        skill: z.ZodString;
        output: z.ZodString;
        enabled: z.ZodDefault<z.ZodLiteral<false>>;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }>, "many">, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[], {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[]>>;
} & {
    schemaVersion: z.ZodLiteral<2>;
    execution: z.ZodOptional<z.ZodObject<Omit<{
        modelFeatures: z.ZodOptional<z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">>;
        sandbox: z.ZodOptional<z.ZodEnum<["server", "cloud-computer"]>>;
        localCapabilities: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        offline: z.ZodOptional<z.ZodEnum<["requires-online", "local-only"]>>;
    }, "sandbox">, "strict", z.ZodTypeAny, {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }, {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }>>;
}, "strict", z.ZodTypeAny, {
    schemaVersion?: 2;
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}, {
    schemaVersion?: 2;
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}>;
export declare const templateManifestSchema: z.ZodDiscriminatedUnion<"schemaVersion", [z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    version: z.ZodString;
    skills: z.ZodOptional<z.ZodArray<z.ZodObject<{
        pluginName: z.ZodOptional<z.ZodString>;
        componentKey: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        pluginName?: string;
        componentKey?: string;
    }, {
        pluginName?: string;
        componentKey?: string;
    }>, "many">>;
    files: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        scope: z.ZodEnum<["shared", "user"]>;
        entries: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"directory">;
            path: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "directory";
        }, {
            path?: string;
            kind?: "directory";
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"file">;
            path: z.ZodEffects<z.ZodString, string, string>;
            content: z.ZodString;
            contentVersion: z.ZodString;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"ledger">;
            path: z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>;
            structureVersion: z.ZodString;
            columns: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<["string", "number", "boolean", "date"]>;
            }, "strict", z.ZodTypeAny, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }>, "many">;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>>;
    onboarding: z.ZodOptional<z.ZodObject<{
        skill: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        preferences: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
        completionCriteria: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }>>;
    connectors: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        provider: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        purpose: z.ZodString;
        permissions: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }>, "many">, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>>;
    routines: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        trigger: z.ZodEnum<["schedule", "event"]>;
        expression: z.ZodString;
        timezone: z.ZodEnum<["user", "organization"]>;
        skill: z.ZodString;
        output: z.ZodString;
        enabled: z.ZodDefault<z.ZodLiteral<false>>;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }>, "many">, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[], {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[]>>;
    execution: z.ZodOptional<z.ZodObject<{
        modelFeatures: z.ZodOptional<z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">>;
        sandbox: z.ZodOptional<z.ZodEnum<["server", "cloud-computer"]>>;
        localCapabilities: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        offline: z.ZodOptional<z.ZodEnum<["requires-online", "local-only"]>>;
    }, "strict", z.ZodTypeAny, {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }, {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }>>;
}, "strict", z.ZodTypeAny, {
    schemaVersion?: 1;
    skills?: {
        pluginName?: string;
        componentKey?: string;
    }[];
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}, {
    schemaVersion?: 1;
    skills?: {
        pluginName?: string;
        componentKey?: string;
    }[];
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        sandbox?: "server" | "cloud-computer";
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}>, z.ZodObject<{
    connectors: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        provider: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        purpose: z.ZodString;
        permissions: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }>, "many">, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>, {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[], {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[]>>;
    version: z.ZodString;
    files: z.ZodOptional<z.ZodEffects<z.ZodObject<{
        scope: z.ZodEnum<["shared", "user"]>;
        entries: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"directory">;
            path: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "directory";
        }, {
            path?: string;
            kind?: "directory";
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"file">;
            path: z.ZodEffects<z.ZodString, string, string>;
            content: z.ZodString;
            contentVersion: z.ZodString;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }, {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"ledger">;
            path: z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>;
            structureVersion: z.ZodString;
            columns: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<["string", "number", "boolean", "date"]>;
            }, "strict", z.ZodTypeAny, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }, {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }>, "many">;
            policy: z.ZodLiteral<"create-only">;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }, {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        }>]>, "many">;
    }, "strict", z.ZodTypeAny, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }, {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    }>>;
    onboarding: z.ZodOptional<z.ZodObject<{
        skill: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        preferences: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
        completionCriteria: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }, {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    }>>;
    routines: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        trigger: z.ZodEnum<["schedule", "event"]>;
        expression: z.ZodString;
        timezone: z.ZodEnum<["user", "organization"]>;
        skill: z.ZodString;
        output: z.ZodString;
        enabled: z.ZodDefault<z.ZodLiteral<false>>;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }>, "many">, {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[], {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[]>>;
} & {
    schemaVersion: z.ZodLiteral<2>;
    execution: z.ZodOptional<z.ZodObject<Omit<{
        modelFeatures: z.ZodOptional<z.ZodArray<z.ZodNativeEnum<typeof ModelFeature>, "many">>;
        sandbox: z.ZodOptional<z.ZodEnum<["server", "cloud-computer"]>>;
        localCapabilities: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        offline: z.ZodOptional<z.ZodEnum<["requires-online", "local-only"]>>;
    }, "sandbox">, "strict", z.ZodTypeAny, {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }, {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    }>>;
}, "strict", z.ZodTypeAny, {
    schemaVersion?: 2;
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}, {
    schemaVersion?: 2;
    connectors?: {
        key?: string;
        provider?: string;
        required?: boolean;
        permissions?: string[];
        purpose?: string;
    }[];
    version?: string;
    execution?: {
        modelFeatures?: ModelFeature[];
        localCapabilities?: string[];
        offline?: "requires-online" | "local-only";
    };
    files?: {
        entries?: ({
            path?: string;
            kind?: "directory";
        } | {
            path?: string;
            kind?: "file";
            policy?: "create-only";
            content?: string;
            contentVersion?: string;
        } | {
            path?: string;
            kind?: "ledger";
            columns?: {
                key?: string;
                type?: "string" | "number" | "boolean" | "date";
                label?: string;
            }[];
            policy?: "create-only";
            structureVersion?: string;
        })[];
        scope?: "user" | "shared";
    };
    onboarding?: {
        preferences?: string[];
        required?: boolean;
        skill?: string;
        completionCriteria?: string;
    };
    routines?: {
        key?: string;
        enabled?: false;
        output?: string;
        required?: boolean;
        trigger?: "schedule" | "event";
        skill?: string;
        expression?: string;
        timezone?: "user" | "organization";
    }[];
}>]>;
export type AssistantTemplateManifest = z.output<typeof assistantTemplateManifestSchema>;
export type TemplateManifest = z.output<typeof templateManifestSchema>;
export type TemplateFiles = z.output<typeof templateFilesSchema>;
export interface TemplateRequirementCheck {
    kind: 'manifest' | 'memory' | 'skills' | 'files' | 'onboarding' | 'connectors' | 'routines' | 'execution' | 'plugin' | 'resource';
    key: string;
    required: boolean;
    status: 'ready' | 'unsupported' | 'missing' | 'incompatible' | 'pending-configuration';
    message: string;
    pluginName?: string;
    version?: string;
}
/** Public projection deliberately excludes initial file contents, DSL, credentials and filesystem roots. */
export interface TemplateReadiness {
    capabilities?: import('./assistant-capability.model').AssistantCapabilitySummary;
    manifestVersion?: string;
    legacy: boolean;
    canInstall: boolean;
    checks: TemplateRequirementCheck[];
    dependencies: TemplateDependencyLock[];
    files?: {
        scope: 'shared' | 'user';
        entries: {
            kind: 'directory' | 'file' | 'ledger';
            path: string;
            version?: string;
        }[];
    };
}
