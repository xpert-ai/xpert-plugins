import { z } from 'zod/v3';
/** Host-assigned attempt identity. A new host boot or execution never inherits an old target. */
export declare const executionRuntimeTargetSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    version: z.ZodLiteral<1>;
    kind: z.ZodLiteral<"host">;
    generation: z.ZodString;
    hostId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "host";
    version: 1;
    generation: string;
    hostId: string;
}, {
    kind: "host";
    version: 1;
    generation: string;
    hostId: string;
}>, z.ZodObject<{
    version: z.ZodLiteral<1>;
    kind: z.ZodLiteral<"provider">;
    generation: z.ZodString;
}, "strict", z.ZodTypeAny, {
    kind: "provider";
    version: 1;
    generation: string;
}, {
    kind: "provider";
    version: 1;
    generation: string;
}>]>;
export type ExecutionRuntimeTarget = z.output<typeof executionRuntimeTargetSchema>;
export declare function executionRuntimeTargetsEqual(left: ExecutionRuntimeTarget | undefined, right: ExecutionRuntimeTarget | undefined): boolean;
/** Control acknowledgements never constitute completion evidence. Missing evidence stays unknown. */
export declare const executionControlEvidenceSchema: z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
    source: z.ZodLiteral<"unavailable">;
    subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"execution">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "execution";
        id: string;
    }, {
        kind: "execution";
        id: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"invocation">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "invocation";
        id: string;
    }, {
        kind: "invocation";
        id: string;
    }>]>;
    state: z.ZodLiteral<"unknown">;
    reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
    version: z.ZodLiteral<1>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        kind: "execution";
        id: string;
    } | {
        kind: "invocation";
        id: string;
    };
    version: 1;
    source: "unavailable";
    reason: "unregistered" | "unconfirmed" | "unsupported";
    state: "unknown";
    observedAt: string;
}, {
    subject: {
        kind: "execution";
        id: string;
    } | {
        kind: "invocation";
        id: string;
    };
    version: 1;
    source: "unavailable";
    reason: "unregistered" | "unconfirmed" | "unsupported";
    state: "unknown";
    observedAt: string;
}>, z.ZodObject<{
    source: z.ZodLiteral<"platform">;
    subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"execution">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "execution";
        id: string;
    }, {
        kind: "execution";
        id: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"invocation">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "invocation";
        id: string;
    }, {
        kind: "invocation";
        id: string;
    }>]>;
    scope: z.ZodLiteral<"owned_subtree">;
    state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
    desired: z.ZodEnum<["running", "paused", "terminated"]>;
    taskId: z.ZodString;
    rootId: z.ZodString;
    revision: z.ZodNumber;
    executionId: z.ZodString;
    threadId: z.ZodString;
    version: z.ZodLiteral<1>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        kind: "execution";
        id: string;
    } | {
        kind: "invocation";
        id: string;
    };
    revision: number;
    threadId: string;
    executionId: string;
    version: 1;
    source: "platform";
    scope: "owned_subtree";
    state: "running" | "paused" | "pausing" | "terminating" | "settled";
    observedAt: string;
    desired: "running" | "paused" | "terminated";
    taskId: string;
    rootId: string;
}, {
    subject: {
        kind: "execution";
        id: string;
    } | {
        kind: "invocation";
        id: string;
    };
    revision: number;
    threadId: string;
    executionId: string;
    version: 1;
    source: "platform";
    scope: "owned_subtree";
    state: "running" | "paused" | "pausing" | "terminating" | "settled";
    observedAt: string;
    desired: "running" | "paused" | "terminated";
    taskId: string;
    rootId: string;
}>, z.ZodObject<{
    source: z.ZodLiteral<"provider">;
    subject: z.ZodObject<{
        kind: z.ZodLiteral<"invocation">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "invocation";
        id: string;
    }, {
        kind: "invocation";
        id: string;
    }>;
    scope: z.ZodLiteral<"operation">;
    state: z.ZodLiteral<"settled">;
    outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
    sessionId: z.ZodString;
    runId: z.ZodString;
    receiptKey: z.ZodString;
    target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        version: z.ZodLiteral<1>;
        kind: z.ZodLiteral<"host">;
        generation: z.ZodString;
        hostId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "host";
        version: 1;
        generation: string;
        hostId: string;
    }, {
        kind: "host";
        version: 1;
        generation: string;
        hostId: string;
    }>, z.ZodObject<{
        version: z.ZodLiteral<1>;
        kind: z.ZodLiteral<"provider">;
        generation: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "provider";
        version: 1;
        generation: string;
    }, {
        kind: "provider";
        version: 1;
        generation: string;
    }>]>>;
    version: z.ZodLiteral<1>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        kind: "invocation";
        id: string;
    };
    outcome: "succeeded" | "failed" | "cancelled";
    version: 1;
    source: "provider";
    scope: "operation";
    state: "settled";
    runId: string;
    observedAt: string;
    sessionId: string;
    receiptKey: string;
    target?: {
        kind: "host";
        version: 1;
        generation: string;
        hostId: string;
    } | {
        kind: "provider";
        version: 1;
        generation: string;
    } | undefined;
}, {
    subject: {
        kind: "invocation";
        id: string;
    };
    outcome: "succeeded" | "failed" | "cancelled";
    version: 1;
    source: "provider";
    scope: "operation";
    state: "settled";
    runId: string;
    observedAt: string;
    sessionId: string;
    receiptKey: string;
    target?: {
        kind: "host";
        version: 1;
        generation: string;
        hostId: string;
    } | {
        kind: "provider";
        version: 1;
        generation: string;
    } | undefined;
}>, z.ZodObject<{
    source: z.ZodLiteral<"native_graph">;
    subject: z.ZodObject<{
        kind: z.ZodLiteral<"invocation">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "invocation";
        id: string;
    }, {
        kind: "invocation";
        id: string;
    }>;
    scope: z.ZodLiteral<"operation">;
    state: z.ZodLiteral<"settled">;
    outcome: z.ZodLiteral<"cancelled">;
    executionId: z.ZodString;
    version: z.ZodLiteral<1>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        kind: "invocation";
        id: string;
    };
    executionId: string;
    outcome: "cancelled";
    version: 1;
    source: "native_graph";
    scope: "operation";
    state: "settled";
    observedAt: string;
}, {
    subject: {
        kind: "invocation";
        id: string;
    };
    executionId: string;
    outcome: "cancelled";
    version: 1;
    source: "native_graph";
    scope: "operation";
    state: "settled";
    observedAt: string;
}>, z.ZodObject<{
    source: z.ZodLiteral<"host_admission">;
    subject: z.ZodObject<{
        kind: z.ZodLiteral<"invocation">;
        id: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        kind: "invocation";
        id: string;
    }, {
        kind: "invocation";
        id: string;
    }>;
    scope: z.ZodLiteral<"operation">;
    state: z.ZodLiteral<"settled">;
    outcome: z.ZodEnum<["failed", "cancelled"]>;
    reason: z.ZodLiteral<"not_started">;
    version: z.ZodLiteral<1>;
    observedAt: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        kind: "invocation";
        id: string;
    };
    outcome: "failed" | "cancelled";
    version: 1;
    source: "host_admission";
    reason: "not_started";
    scope: "operation";
    state: "settled";
    observedAt: string;
}, {
    subject: {
        kind: "invocation";
        id: string;
    };
    outcome: "failed" | "cancelled";
    version: 1;
    source: "host_admission";
    reason: "not_started";
    scope: "operation";
    state: "settled";
    observedAt: string;
}>]>;
export type ExecutionControlEvidence = z.output<typeof executionControlEvidenceSchema>;
export declare function unknownExecutionControl(subject: ExecutionControlEvidence['subject'], reason?: 'unregistered' | 'unconfirmed' | 'unsupported'): ExecutionControlEvidence;
