import { z } from 'zod/v3';
export declare const projectPipelineProviderActionDescriptorSchema: z.ZodEffects<z.ZodObject<{
    ref: z.ZodString;
    label: z.ZodObject<{
        en_US: z.ZodString;
        zh_Hans: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        en_US: string;
        zh_Hans?: string | undefined;
    }, {
        en_US: string;
        zh_Hans?: string | undefined;
    }>;
    description: z.ZodOptional<z.ZodObject<{
        en_US: z.ZodString;
        zh_Hans: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        en_US: string;
        zh_Hans?: string | undefined;
    }, {
        en_US: string;
        zh_Hans?: string | undefined;
    }>>;
    sourceRevision: z.ZodString;
    effects: z.ZodEnum<["read_only", "domain_write", "external_write"]>;
    idempotency: z.ZodLiteral<"keyed_receipt">;
    parameters: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"boolean">;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"text">;
        maxLength: z.ZodNumber;
        minLength: z.ZodNumber;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"number">;
        min: z.ZodNumber;
        max: z.ZodNumber;
        integer: z.ZodBoolean;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"choice">;
        options: z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
        }, "strict", z.ZodTypeAny, {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }, {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }>, "many">;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"multi_choice">;
        options: z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
        }, "strict", z.ZodTypeAny, {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }, {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }>, "many">;
        minItems: z.ZodDefault<z.ZodNumber>;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minItems: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
        minItems?: number | undefined;
    }>, z.ZodObject<{
        type: z.ZodLiteral<"string_list">;
        maxItems: z.ZodNumber;
        itemMaxLength: z.ZodNumber;
        key: z.ZodEffects<z.ZodString, string, string>;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
    }, "strict", z.ZodTypeAny, {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>]>, "many">;
    defaults: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
}, "strict", z.ZodTypeAny, {
    label: {
        en_US: string;
        zh_Hans?: string | undefined;
    };
    parameters: ({
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minItems: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    })[];
    ref: string;
    effects: "read_only" | "external_write" | "domain_write";
    idempotency: "keyed_receipt";
    sourceRevision: string;
    defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    description?: {
        en_US: string;
        zh_Hans?: string | undefined;
    } | undefined;
}, {
    label: {
        en_US: string;
        zh_Hans?: string | undefined;
    };
    parameters: ({
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
        minItems?: number | undefined;
    } | {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    })[];
    ref: string;
    effects: "read_only" | "external_write" | "domain_write";
    idempotency: "keyed_receipt";
    sourceRevision: string;
    defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    description?: {
        en_US: string;
        zh_Hans?: string | undefined;
    } | undefined;
}>, {
    label: {
        en_US: string;
        zh_Hans?: string | undefined;
    };
    parameters: ({
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minItems: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    })[];
    ref: string;
    effects: "read_only" | "external_write" | "domain_write";
    idempotency: "keyed_receipt";
    sourceRevision: string;
    defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    description?: {
        en_US: string;
        zh_Hans?: string | undefined;
    } | undefined;
}, {
    label: {
        en_US: string;
        zh_Hans?: string | undefined;
    };
    parameters: ({
        key: string;
        type: "boolean";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "text";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        minLength: number;
        maxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        type: "number";
        integer: boolean;
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        min: number;
        max: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    } | {
        key: string;
        options: {
            value: string;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
        }[];
        type: "multi_choice";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
        minItems?: number | undefined;
    } | {
        key: string;
        type: "string_list";
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        maxItems: number;
        itemMaxLength: number;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    })[];
    ref: string;
    effects: "read_only" | "external_write" | "domain_write";
    idempotency: "keyed_receipt";
    sourceRevision: string;
    defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    description?: {
        en_US: string;
        zh_Hans?: string | undefined;
    } | undefined;
}>;
export declare const projectPipelineProviderActionTargetSchema: z.ZodObject<{
    instanceId: z.ZodString;
    nodeInstanceId: z.ZodString;
    roundId: z.ZodString;
    expectedRevision: z.ZodNumber;
    generation: z.ZodNumber;
    inputDigest: z.ZodString;
}, "strict", z.ZodTypeAny, {
    instanceId: string;
    expectedRevision: number;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
}, {
    instanceId: string;
    expectedRevision: number;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
}>;
export declare const projectPipelineProviderActionCommandSchema: z.ZodObject<{
    instanceId: z.ZodString;
    nodeInstanceId: z.ZodString;
    roundId: z.ZodString;
    expectedRevision: z.ZodNumber;
    generation: z.ZodNumber;
    inputDigest: z.ZodString;
} & {
    requestId: z.ZodString;
    actionRef: z.ZodString;
    sourceRevision: z.ZodString;
    parameters: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
}, "strict", z.ZodTypeAny, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
    parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
    sourceRevision: string;
    actionRef: string;
}, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
    parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
    sourceRevision: string;
    actionRef: string;
}>;
export declare const projectPipelineProviderActionReceiptSchema: z.ZodObject<{
    status: z.ZodEnum<["pending", "unknown", "succeeded", "failed"]>;
    receiptKey: z.ZodOptional<z.ZodString>;
    reasonCode: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    status: "unknown" | "pending" | "succeeded" | "failed";
    reasonCode?: string | undefined;
    receiptKey?: string | undefined;
}, {
    status: "unknown" | "pending" | "succeeded" | "failed";
    reasonCode?: string | undefined;
    receiptKey?: string | undefined;
}>;
export declare const projectPipelineProviderActionViewSchema: z.ZodObject<{
    id: z.ZodString;
    nodeInstanceId: z.ZodString;
    actionRef: z.ZodString;
    state: z.ZodEnum<["queued", "dispatching", "pending", "unknown", "succeeded", "failed", "superseded"]>;
    reasonCode: z.ZodNullable<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    projectionPending: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    reasonCode: string | null;
    id: string;
    state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
    nodeInstanceId: string;
    createdAt: string;
    actionRef: string;
    updatedAt: string;
    projectionPending: boolean;
}, {
    reasonCode: string | null;
    id: string;
    state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
    nodeInstanceId: string;
    createdAt: string;
    actionRef: string;
    updatedAt: string;
    projectionPending: boolean;
}>;
export declare const projectPipelineProviderActionsSchema: z.ZodObject<{
    dispatchEnabled: z.ZodOptional<z.ZodBoolean>;
    target: z.ZodObject<{
        instanceId: z.ZodString;
        nodeInstanceId: z.ZodString;
        roundId: z.ZodString;
        expectedRevision: z.ZodNumber;
        generation: z.ZodNumber;
        inputDigest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        instanceId: string;
        expectedRevision: number;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    }, {
        instanceId: string;
        expectedRevision: number;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    }>;
    items: z.ZodArray<z.ZodEffects<z.ZodObject<{
        ref: z.ZodString;
        label: z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>;
        description: z.ZodOptional<z.ZodObject<{
            en_US: z.ZodString;
            zh_Hans: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            en_US: string;
            zh_Hans?: string | undefined;
        }, {
            en_US: string;
            zh_Hans?: string | undefined;
        }>>;
        sourceRevision: z.ZodString;
        effects: z.ZodEnum<["read_only", "domain_write", "external_write"]>;
        idempotency: z.ZodLiteral<"keyed_receipt">;
        parameters: z.ZodArray<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
            type: z.ZodLiteral<"boolean">;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"text">;
            maxLength: z.ZodNumber;
            minLength: z.ZodNumber;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"number">;
            min: z.ZodNumber;
            max: z.ZodNumber;
            integer: z.ZodBoolean;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"choice">;
            options: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                label: z.ZodObject<{
                    en_US: z.ZodString;
                    zh_Hans: z.ZodOptional<z.ZodString>;
                }, "strict", z.ZodTypeAny, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }>;
            }, "strict", z.ZodTypeAny, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }>, "many">;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"multi_choice">;
            options: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                label: z.ZodObject<{
                    en_US: z.ZodString;
                    zh_Hans: z.ZodOptional<z.ZodString>;
                }, "strict", z.ZodTypeAny, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }, {
                    en_US: string;
                    zh_Hans?: string | undefined;
                }>;
            }, "strict", z.ZodTypeAny, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }, {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }>, "many">;
            minItems: z.ZodDefault<z.ZodNumber>;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        }>, z.ZodObject<{
            type: z.ZodLiteral<"string_list">;
            maxItems: z.ZodNumber;
            itemMaxLength: z.ZodNumber;
            key: z.ZodEffects<z.ZodString, string, string>;
            label: z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>;
            description: z.ZodOptional<z.ZodObject<{
                en_US: z.ZodString;
                zh_Hans: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                en_US: string;
                zh_Hans?: string | undefined;
            }, {
                en_US: string;
                zh_Hans?: string | undefined;
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }, {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        }>]>, "many">;
        defaults: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
    }, "strict", z.ZodTypeAny, {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }, {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }>, "many">;
    operations: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        nodeInstanceId: z.ZodString;
        actionRef: z.ZodString;
        state: z.ZodEnum<["queued", "dispatching", "pending", "unknown", "succeeded", "failed", "superseded"]>;
        reasonCode: z.ZodNullable<z.ZodString>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        projectionPending: z.ZodBoolean;
    }, "strict", z.ZodTypeAny, {
        reasonCode: string | null;
        id: string;
        state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
        nodeInstanceId: string;
        createdAt: string;
        actionRef: string;
        updatedAt: string;
        projectionPending: boolean;
    }, {
        reasonCode: string | null;
        id: string;
        state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
        nodeInstanceId: string;
        createdAt: string;
        actionRef: string;
        updatedAt: string;
        projectionPending: boolean;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    items: {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minItems: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }[];
    target: {
        instanceId: string;
        expectedRevision: number;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
    operations: {
        reasonCode: string | null;
        id: string;
        state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
        nodeInstanceId: string;
        createdAt: string;
        actionRef: string;
        updatedAt: string;
        projectionPending: boolean;
    }[];
    dispatchEnabled?: boolean | undefined;
}, {
    items: {
        label: {
            en_US: string;
            zh_Hans?: string | undefined;
        };
        parameters: ({
            key: string;
            type: "boolean";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "text";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            minLength: number;
            maxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            type: "number";
            integer: boolean;
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            min: number;
            max: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        } | {
            key: string;
            options: {
                value: string;
                label: {
                    en_US: string;
                    zh_Hans?: string | undefined;
                };
            }[];
            type: "multi_choice";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
            minItems?: number | undefined;
        } | {
            key: string;
            type: "string_list";
            label: {
                en_US: string;
                zh_Hans?: string | undefined;
            };
            maxItems: number;
            itemMaxLength: number;
            description?: {
                en_US: string;
                zh_Hans?: string | undefined;
            } | undefined;
        })[];
        ref: string;
        effects: "read_only" | "external_write" | "domain_write";
        idempotency: "keyed_receipt";
        sourceRevision: string;
        defaults: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        description?: {
            en_US: string;
            zh_Hans?: string | undefined;
        } | undefined;
    }[];
    target: {
        instanceId: string;
        expectedRevision: number;
        roundId: string;
        nodeInstanceId: string;
        inputDigest: string;
        generation: number;
    };
    operations: {
        reasonCode: string | null;
        id: string;
        state: "unknown" | "pending" | "succeeded" | "failed" | "queued" | "superseded" | "dispatching";
        nodeInstanceId: string;
        createdAt: string;
        actionRef: string;
        updatedAt: string;
        projectionPending: boolean;
    }[];
    dispatchEnabled?: boolean | undefined;
}>;
export type ProjectPipelineProviderActionDescriptor = z.output<typeof projectPipelineProviderActionDescriptorSchema>;
export type ProjectPipelineProviderActionTarget = z.output<typeof projectPipelineProviderActionTargetSchema>;
export type ProjectPipelineProviderActionCommand = z.output<typeof projectPipelineProviderActionCommandSchema>;
export type ProjectPipelineProviderActionReceipt = z.output<typeof projectPipelineProviderActionReceiptSchema>;
export type ProjectPipelineProviderActionView = z.output<typeof projectPipelineProviderActionViewSchema>;
export type ProjectPipelineProviderActions = z.output<typeof projectPipelineProviderActionsSchema>;
