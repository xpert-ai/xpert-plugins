import { z } from 'zod/v3';
/** Machine keys are independent of labels. Reserve mutation keys; record readers must still check own fields. */
export declare const projectPipelineKeySchema: z.ZodEffects<z.ZodString, string, string>;
export declare const projectPipelineRefSchema: z.ZodString;
export type ProjectPipelineJsonValue = string | number | boolean | null | ProjectPipelineJsonValue[] | {
    [key: string]: ProjectPipelineJsonValue;
};
export declare const projectPipelineJsonSchema: z.ZodType<ProjectPipelineJsonValue, z.ZodTypeDef, ProjectPipelineJsonValue>;
export declare const projectPipelineParticipantKindSchema: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
export declare const projectPipelineRoleSchema: z.ZodObject<{
    key: z.ZodEffects<z.ZodString, string, string>;
    allowedKinds: z.ZodArray<z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>, "many">;
}, "strict", z.ZodTypeAny, {
    key: string;
    allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
}, {
    key: string;
    allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
}>;
export declare const projectPipelineLaneSchema: z.ZodObject<{
    key: z.ZodEffects<z.ZodString, string, string>;
    roleKey: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodString;
    order: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    key: string;
    order: number;
    roleKey: string;
    label: string;
}, {
    key: string;
    order: number;
    roleKey: string;
    label: string;
}>;
/** Bundled presentation icons only; no executable content or external asset URLs. */
export declare const projectPipelineIconSchema: z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>;
export declare const projectPipelineStageSchema: z.ZodObject<{
    key: z.ZodEffects<z.ZodString, string, string>;
    label: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>>;
    order: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    key: string;
    order: number;
    label: string;
    icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
}, {
    key: string;
    order: number;
    label: string;
    icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
}>;
export declare const projectPipelineOutputBindingSchema: z.ZodObject<{
    from: z.ZodLiteral<"node_output">;
    nodeKey: z.ZodEffects<z.ZodString, string, string>;
    port: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    from: "node_output";
    nodeKey: string;
    port: string;
}, {
    from: "node_output";
    nodeKey: string;
    port: string;
}>;
export declare const projectPipelineInputBindingSchema: z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
    from: z.ZodLiteral<"subject">;
}, "strict", z.ZodTypeAny, {
    from: "subject";
}, {
    from: "subject";
}>, z.ZodObject<{
    from: z.ZodLiteral<"parameter">;
    key: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    key: string;
    from: "parameter";
}, {
    key: string;
    from: "parameter";
}>, z.ZodObject<{
    from: z.ZodLiteral<"node_output">;
    nodeKey: z.ZodEffects<z.ZodString, string, string>;
    port: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    from: "node_output";
    nodeKey: string;
    port: string;
}, {
    from: "node_output";
    nodeKey: string;
    port: string;
}>, z.ZodObject<{
    from: z.ZodLiteral<"collection">;
    items: z.ZodArray<z.ZodObject<{
        from: z.ZodLiteral<"node_output">;
        nodeKey: z.ZodEffects<z.ZodString, string, string>;
        port: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }, {
        from: "node_output";
        nodeKey: string;
        port: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    items: {
        from: "node_output";
        nodeKey: string;
        port: string;
    }[];
    from: "collection";
}, {
    items: {
        from: "node_output";
        nodeKey: string;
        port: string;
    }[];
    from: "collection";
}>]>;
export declare const projectPipelineEdgeSchema: z.ZodObject<{
    from: z.ZodEffects<z.ZodString, string, string>;
    to: z.ZodEffects<z.ZodString, string, string>;
    outcome: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
}, "strict", z.ZodTypeAny, {
    from: string;
    to: string;
    outcome?: string | undefined;
}, {
    from: string;
    to: string;
    outcome?: string | undefined;
}>;
export type ProjectPipelineInputBinding = z.output<typeof projectPipelineInputBindingSchema>;
export type ProjectPipelineParticipantKind = z.output<typeof projectPipelineParticipantKindSchema>;
