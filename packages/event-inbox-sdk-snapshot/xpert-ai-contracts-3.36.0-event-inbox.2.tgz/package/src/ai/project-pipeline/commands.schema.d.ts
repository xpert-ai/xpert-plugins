import { z } from 'zod/v3';
export declare const projectPipelineConfigureSchema: z.ZodObject<{
    requestId: z.ZodString;
    configuration: z.ZodEffects<z.ZodObject<{
        schemaVersion: z.ZodLiteral<1>;
        template: z.ZodEffects<z.ZodDiscriminatedUnion<"executionAuthority", [z.ZodObject<{
            executionAuthority: z.ZodLiteral<"provider">;
            providerRef: z.ZodString;
            topology: z.ZodObject<{
                source: z.ZodLiteral<"provider">;
                presentationAdapterRef: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                source: "provider";
                presentationAdapterRef: string;
            }, {
                source: "provider";
                presentationAdapterRef: string;
            }>;
            actionRefs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            hostRequirements: z.ZodOptional<z.ZodObject<{
                protocol: z.ZodNumber;
                features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodNumber>, Record<string, number>, Record<string, number>>;
            }, "strict", z.ZodTypeAny, {
                protocol: number;
                features: Record<string, number>;
            }, {
                protocol: number;
                features: Record<string, number>;
            }>>;
            key: z.ZodEffects<z.ZodString, string, string>;
            version: z.ZodString;
            title: z.ZodString;
            projectTypes: z.ZodEffects<z.ZodArray<z.ZodObject<{
                applicationKey: z.ZodString;
                projectTypeKey: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                applicationKey: string;
                projectTypeKey: string;
            }, {
                applicationKey: string;
                projectTypeKey: string;
            }>, "many">, {
                applicationKey: string;
                projectTypeKey: string;
            }[], {
                applicationKey: string;
                projectTypeKey: string;
            }[]>;
            subjectResolverRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                allowedKinds: z.ZodArray<z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>, "many">;
            }, "strict", z.ZodTypeAny, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }>, "many">;
            lanes: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }, {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }>, "many">;
            stages: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                icon: z.ZodOptional<z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>>;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }, {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }>, "many">;
            presentation: z.ZodOptional<z.ZodObject<{
                views: z.ZodArray<z.ZodEnum<["tasks", "pipeline", "agent_timeline"]>, "many">;
                nodeDetailRef: z.ZodOptional<z.ZodString>;
                evidenceTypes: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            }, "strict", z.ZodTypeAny, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }>>;
            metrics: z.ZodOptional<z.ZodObject<{
                dimensionRefs: z.ZodArray<z.ZodString, "many">;
                metricRefs: z.ZodArray<z.ZodString, "many">;
            }, "strict", z.ZodTypeAny, {
                dimensionRefs: string[];
                metricRefs: string[];
            }, {
                dimensionRefs: string[];
                metricRefs: string[];
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>, z.ZodObject<{
            executionAuthority: z.ZodLiteral<"platform">;
            topology: z.ZodObject<{
                source: z.ZodLiteral<"definition">;
            }, "strict", z.ZodTypeAny, {
                source: "definition";
            }, {
                source: "definition";
            }>;
            nodes: z.ZodArray<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
                kind: z.ZodLiteral<"work">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                presentation: z.ZodOptional<z.ZodObject<{
                    foldIntoApproval: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    foldIntoApproval: string;
                }, {
                    foldIntoApproval: string;
                }>>;
                operationRef: z.ZodString;
                executorSlot: z.ZodEffects<z.ZodString, string, string>;
                completionRef: z.ZodString;
                resourceResolverRef: z.ZodOptional<z.ZodString>;
                outputSchemaRef: z.ZodOptional<z.ZodString>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"fork">;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"join">;
                join: z.ZodObject<{
                    mode: z.ZodLiteral<"all_selected">;
                    accept: z.ZodLiteral<"completed">;
                }, "strict", z.ZodTypeAny, {
                    mode: "all_selected";
                    accept: "completed";
                }, {
                    mode: "all_selected";
                    accept: "completed";
                }>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"router">;
                policyRef: z.ZodString;
                outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
                unmatched: z.ZodLiteral<"block">;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"human_gate">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                policyRef: z.ZodString;
                candidateRoleKey: z.ZodEffects<z.ZodString, string, string>;
                outcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
                outcomeLabels: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            }, {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"external_wait">;
                laneKey: z.ZodEffects<z.ZodString, string, string>;
                subscriptionRef: z.ZodString;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }, {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            }>, z.ZodObject<{
                kind: z.ZodLiteral<"terminal">;
                outcome: z.ZodEffects<z.ZodString, string, string>;
                disposition: z.ZodOptional<z.ZodEnum<["complete", "await_new_subject"]>>;
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodOptional<z.ZodString>;
                stageKey: z.ZodEffects<z.ZodString, string, string>;
                inputBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodDiscriminatedUnion<"from", [z.ZodObject<{
                    from: z.ZodLiteral<"subject">;
                }, "strict", z.ZodTypeAny, {
                    from: "subject";
                }, {
                    from: "subject";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"parameter">;
                    key: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    key: string;
                    from: "parameter";
                }, {
                    key: string;
                    from: "parameter";
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"node_output">;
                    nodeKey: z.ZodEffects<z.ZodString, string, string>;
                    port: z.ZodEffects<z.ZodString, string, string>;
                }, "strict", z.ZodTypeAny, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                }>, z.ZodObject<{
                    from: z.ZodLiteral<"collection">;
                    items: z.ZodArray<z.ZodObject<{
                        from: z.ZodLiteral<"node_output">;
                        nodeKey: z.ZodEffects<z.ZodString, string, string>;
                        port: z.ZodEffects<z.ZodString, string, string>;
                    }, "strict", z.ZodTypeAny, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }, {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }>, "many">;
                }, "strict", z.ZodTypeAny, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }, {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }>]>>>;
                outputPorts: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodString>>;
            }, "strict", z.ZodTypeAny, {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            }, {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            }>]>, "many">;
            edges: z.ZodArray<z.ZodObject<{
                from: z.ZodEffects<z.ZodString, string, string>;
                to: z.ZodEffects<z.ZodString, string, string>;
                outcome: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
            }, "strict", z.ZodTypeAny, {
                from: string;
                to: string;
                outcome?: string | undefined;
            }, {
                from: string;
                to: string;
                outcome?: string | undefined;
            }>, "many">;
            roundPolicy: z.ZodObject<{
                entryNodeKey: z.ZodEffects<z.ZodString, string, string>;
                maxRounds: z.ZodNumber;
                onRework: z.ZodLiteral<"await_new_subject_then_next_round">;
                onLimit: z.ZodLiteral<"attention">;
                newVersionWhileActive: z.ZodLiteral<"supersede_round">;
                terminalOutcomes: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
            }, "strict", z.ZodTypeAny, {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            }, {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            }>;
            failurePolicy: z.ZodObject<{
                requiredNodeFailure: z.ZodLiteral<"block_and_attention">;
                unknownExecution: z.ZodLiteral<"inspect_without_replay">;
            }, "strict", z.ZodTypeAny, {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            }, {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            }>;
            hostRequirements: z.ZodOptional<z.ZodObject<{
                protocol: z.ZodNumber;
                features: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodNumber>, Record<string, number>, Record<string, number>>;
            }, "strict", z.ZodTypeAny, {
                protocol: number;
                features: Record<string, number>;
            }, {
                protocol: number;
                features: Record<string, number>;
            }>>;
            key: z.ZodEffects<z.ZodString, string, string>;
            version: z.ZodString;
            title: z.ZodString;
            projectTypes: z.ZodEffects<z.ZodArray<z.ZodObject<{
                applicationKey: z.ZodString;
                projectTypeKey: z.ZodString;
            }, "strict", z.ZodTypeAny, {
                applicationKey: string;
                projectTypeKey: string;
            }, {
                applicationKey: string;
                projectTypeKey: string;
            }>, "many">, {
                applicationKey: string;
                projectTypeKey: string;
            }[], {
                applicationKey: string;
                projectTypeKey: string;
            }[]>;
            subjectResolverRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                allowedKinds: z.ZodArray<z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>, "many">;
            }, "strict", z.ZodTypeAny, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }, {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }>, "many">;
            lanes: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }, {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }>, "many">;
            stages: z.ZodArray<z.ZodObject<{
                key: z.ZodEffects<z.ZodString, string, string>;
                label: z.ZodString;
                icon: z.ZodOptional<z.ZodEnum<["layers", "file-text", "folder-open", "list-checks", "search", "scan-search", "boxes", "package", "settings", "clipboard-check", "shield-check", "git-pull-request", "code", "test-tube", "git-merge", "calculator", "file-check", "truck"]>>;
                order: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }, {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }>, "many">;
            presentation: z.ZodOptional<z.ZodObject<{
                views: z.ZodArray<z.ZodEnum<["tasks", "pipeline", "agent_timeline"]>, "many">;
                nodeDetailRef: z.ZodOptional<z.ZodString>;
                evidenceTypes: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            }, "strict", z.ZodTypeAny, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }, {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            }>>;
            metrics: z.ZodOptional<z.ZodObject<{
                dimensionRefs: z.ZodArray<z.ZodString, "many">;
                metricRefs: z.ZodArray<z.ZodString, "many">;
            }, "strict", z.ZodTypeAny, {
                dimensionRefs: string[];
                metricRefs: string[];
            }, {
                dimensionRefs: string[];
                metricRefs: string[];
            }>>;
        }, "strict", z.ZodTypeAny, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>]>, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }, {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        }>;
        binding: z.ZodObject<{
            templateRef: z.ZodString;
            roleBindings: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
                kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
                selectionKey: z.ZodEffects<z.ZodString, string, string>;
                requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
            }, "strict", z.ZodTypeAny, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>>;
            executorBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodEffects<z.ZodObject<{
                kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
                selectionKey: z.ZodEffects<z.ZodString, string, string>;
                requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
            } & {
                roleKey: z.ZodEffects<z.ZodString, string, string>;
                workspaceId: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }>, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }>>>;
            providerConfiguration: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
            parameters: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
            limits: z.ZodOptional<z.ZodObject<{
                maxConcurrentExecutions: z.ZodNumber;
                maxTechnicalAttemptsPerNode: z.ZodNumber;
                runTimeoutMinutes: z.ZodNumber;
                nativeModelBudget: z.ZodOptional<z.ZodEffects<z.ZodObject<{
                    maxCalls: z.ZodNumber;
                    maxTokens: z.ZodNumber;
                    reservationTokens: z.ZodNumber;
                }, "strict", z.ZodTypeAny, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }>, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }, {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                }>>;
            }, "strict", z.ZodTypeAny, {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            }, {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            }>>;
            triggers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                adapterRef: z.ZodString;
                events: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
            }, "strict", z.ZodTypeAny, {
                adapterRef: string;
                events: string[];
            }, {
                adapterRef: string;
                events: string[];
            }>, "many">>;
        }, "strict", z.ZodTypeAny, {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        }, {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        }>;
    }, "strict", z.ZodTypeAny, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }>, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }, {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    }>;
}, "strict", z.ZodTypeAny, {
    requestId: string;
    configuration: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    };
}, {
    requestId: string;
    configuration: {
        schemaVersion: 1;
        binding: {
            templateRef: string;
            roleBindings: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
            }>;
            parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
            executorBindings?: Record<string, {
                kind: "assistant" | "runtime_binding" | "human" | "service";
                roleKey: string;
                selectionKey: string;
                requiredCapabilities?: string[] | undefined;
                workspaceId?: string | undefined;
            }> | undefined;
            providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
            limits?: {
                maxConcurrentExecutions: number;
                maxTechnicalAttemptsPerNode: number;
                runTimeoutMinutes: number;
                nativeModelBudget?: {
                    maxCalls: number;
                    maxTokens: number;
                    reservationTokens: number;
                } | undefined;
            } | undefined;
            triggers?: {
                adapterRef: string;
                events: string[];
            }[] | undefined;
        };
        template: {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "provider";
            providerRef: string;
            topology: {
                source: "provider";
                presentationAdapterRef: string;
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            actionRefs?: string[] | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        } | {
            key: string;
            title: string;
            version: string;
            lanes: {
                key: string;
                order: number;
                roleKey: string;
                label: string;
            }[];
            executionAuthority: "platform";
            topology: {
                source: "definition";
            };
            projectTypes: {
                applicationKey: string;
                projectTypeKey: string;
            }[];
            subjectResolverRef: string;
            roles: {
                key: string;
                allowedKinds: ("assistant" | "runtime_binding" | "human" | "service")[];
            }[];
            stages: {
                key: string;
                order: number;
                label: string;
                icon?: "code" | "layers" | "file-text" | "folder-open" | "list-checks" | "search" | "scan-search" | "boxes" | "package" | "settings" | "clipboard-check" | "shield-check" | "git-pull-request" | "test-tube" | "git-merge" | "calculator" | "file-check" | "truck" | undefined;
            }[];
            nodes: ({
                kind: "work";
                key: string;
                laneKey: string;
                operationRef: string;
                executorSlot: string;
                completionRef: string;
                stageKey: string;
                presentation?: {
                    foldIntoApproval: string;
                } | undefined;
                label?: string | undefined;
                resourceResolverRef?: string | undefined;
                outputSchemaRef?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "fork";
                key: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "join";
                key: string;
                join: {
                    mode: "all_selected";
                    accept: "completed";
                };
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "router";
                key: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                unmatched: "block";
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "human_gate";
                key: string;
                laneKey: string;
                stageKey: string;
                policyRef: string;
                outcomes: string[];
                candidateRoleKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                outcomeLabels?: Record<string, string> | undefined;
            } | {
                kind: "external_wait";
                key: string;
                laneKey: string;
                stageKey: string;
                subscriptionRef: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
            } | {
                kind: "terminal";
                key: string;
                outcome: string;
                stageKey: string;
                label?: string | undefined;
                inputBindings?: Record<string, {
                    from: "node_output";
                    nodeKey: string;
                    port: string;
                } | {
                    from: "subject";
                } | {
                    key: string;
                    from: "parameter";
                } | {
                    items: {
                        from: "node_output";
                        nodeKey: string;
                        port: string;
                    }[];
                    from: "collection";
                }> | undefined;
                outputPorts?: Record<string, string> | undefined;
                disposition?: "complete" | "await_new_subject" | undefined;
            })[];
            edges: {
                from: string;
                to: string;
                outcome?: string | undefined;
            }[];
            roundPolicy: {
                entryNodeKey: string;
                maxRounds: number;
                onRework: "await_new_subject_then_next_round";
                onLimit: "attention";
                newVersionWhileActive: "supersede_round";
                terminalOutcomes: string[];
            };
            failurePolicy: {
                requiredNodeFailure: "block_and_attention";
                unknownExecution: "inspect_without_replay";
            };
            presentation?: {
                views: ("tasks" | "pipeline" | "agent_timeline")[];
                nodeDetailRef?: string | undefined;
                evidenceTypes?: string[] | undefined;
            } | undefined;
            hostRequirements?: {
                protocol: number;
                features: Record<string, number>;
            } | undefined;
            metrics?: {
                dimensionRefs: string[];
                metricRefs: string[];
            } | undefined;
        };
    };
}>;
export declare const projectPipelineStartSchema: z.ZodObject<{
    bindingId: z.ZodString;
    objectKey: z.ZodString;
    triggerKey: z.ZodString;
    title: z.ZodString;
}, "strict", z.ZodTypeAny, {
    title: string;
    objectKey: string;
    bindingId: string;
    triggerKey: string;
}, {
    title: string;
    objectKey: string;
    bindingId: string;
    triggerKey: string;
}>;
export type ProjectPipelineConfigure = z.output<typeof projectPipelineConfigureSchema>;
export type ProjectPipelineStart = z.output<typeof projectPipelineStartSchema>;
export declare const projectPipelineDecisionSchema: z.ZodObject<{
    requestId: z.ZodString;
    attentionId: z.ZodString;
    expectedRevision: z.ZodNumber;
    inputDigest: z.ZodString;
    generation: z.ZodNumber;
    outcome: z.ZodEffects<z.ZodString, string, string>;
    evidence: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    outcome: string;
    requestId: string;
    expectedRevision: number;
    inputDigest: string;
    generation: number;
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
    attentionId: string;
}, {
    outcome: string;
    requestId: string;
    expectedRevision: number;
    inputDigest: string;
    generation: number;
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
    attentionId: string;
}>;
export type ProjectPipelineDecision = z.output<typeof projectPipelineDecisionSchema>;
export declare const projectPipelineNextRoundSchema: z.ZodObject<{
    instanceId: z.ZodString;
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
}, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
}>;
export type ProjectPipelineNextRound = z.output<typeof projectPipelineNextRoundSchema>;
export declare const projectPipelineCancelSchema: z.ZodObject<{
    instanceId: z.ZodString;
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
}, {
    instanceId: string;
    requestId: string;
    expectedRevision: number;
}>;
export type ProjectPipelineCancel = z.output<typeof projectPipelineCancelSchema>;
export declare const projectPipelineRetrySchema: z.ZodObject<{
    instanceId: z.ZodString;
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
    operationId: z.ZodString;
    inputDigest: z.ZodString;
    generation: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    operationId: string;
    instanceId: string;
    requestId: string;
    expectedRevision: number;
    inputDigest: string;
    generation: number;
}, {
    operationId: string;
    instanceId: string;
    requestId: string;
    expectedRevision: number;
    inputDigest: string;
    generation: number;
}>;
export type ProjectPipelineRetry = z.output<typeof projectPipelineRetrySchema>;
export interface ProjectPipelineStartReceipt {
    instanceId: string;
    runId: string;
    roundId: string;
    revision: number;
}
