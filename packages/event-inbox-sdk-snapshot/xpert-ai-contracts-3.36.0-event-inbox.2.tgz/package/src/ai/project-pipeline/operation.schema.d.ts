import { z } from 'zod/v3';
export declare const projectPipelineOperationInputSchema: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
    kind: z.ZodLiteral<"evidence">;
    value: z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>;
}, "strict", z.ZodTypeAny, {
    kind: "evidence";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    };
}, {
    kind: "evidence";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    };
}>, z.ZodObject<{
    kind: z.ZodLiteral<"evidence_collection">;
    value: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    kind: "evidence_collection";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}, {
    kind: "evidence_collection";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}>, z.ZodObject<{
    kind: z.ZodLiteral<"subjects">;
    value: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    kind: "subjects";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }[];
}, {
    kind: "subjects";
    value: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }[];
}>, z.ZodObject<{
    kind: z.ZodLiteral<"parameter">;
    value: z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>;
}, "strict", z.ZodTypeAny, {
    kind: "parameter";
    value: import("./primitives.schema").ProjectPipelineJsonValue;
}, {
    kind: "parameter";
    value: import("./primitives.schema").ProjectPipelineJsonValue;
}>]>;
export declare const projectPipelineAssistantInputSchema: z.ZodObject<{
    prompt: z.ZodString;
    context: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
    humanInput: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
}, "strict", z.ZodTypeAny, {
    prompt: string;
    context?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
    humanInput?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
}, {
    prompt: string;
    context?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
    humanInput?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
}>;
export type ProjectPipelineAssistantInput = z.output<typeof projectPipelineAssistantInputSchema>;
export declare const projectPipelineRuntimeInputSchema: z.ZodObject<{
    prompt: z.ZodString;
    context: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
    parameters: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
}, "strict", z.ZodTypeAny, {
    prompt: string;
    parameters?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
    context?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
}, {
    prompt: string;
    parameters?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
    context?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
}>;
export type ProjectPipelineRuntimeInput = z.output<typeof projectPipelineRuntimeInputSchema>;
export declare const projectPipelineAssistantExecutionSchema: z.ZodObject<{
    kind: z.ZodLiteral<"assistant_task">;
    executionId: z.ZodString;
    conversationId: z.ZodString;
    xpertId: z.ZodString;
    publishedVersion: z.ZodString;
    status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
}, "strict", z.ZodTypeAny, {
    kind: "assistant_task";
    status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
    executionId: string;
    conversationId: string;
    xpertId: string;
    publishedVersion: string;
}, {
    kind: "assistant_task";
    status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
    executionId: string;
    conversationId: string;
    xpertId: string;
    publishedVersion: string;
}>;
export declare const projectPipelineRuntimeExecutionSchema: z.ZodObject<{
    kind: z.ZodLiteral<"runtime_invocation">;
    invocationId: z.ZodString;
    bindingId: z.ZodString;
    provider: z.ZodString;
    revision: z.ZodString;
    status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
}, "strict", z.ZodTypeAny, {
    kind: "runtime_invocation";
    status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
    revision: string;
    provider: string;
    bindingId: string;
    invocationId: string;
}, {
    kind: "runtime_invocation";
    status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
    revision: string;
    provider: string;
    bindingId: string;
    invocationId: string;
}>;
export declare const projectPipelineOperationReceiptSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"pending">;
    control: z.ZodOptional<z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
        source: z.ZodLiteral<"unavailable">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        state: z.ZodLiteral<"unknown">;
        reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"platform">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        scope: z.ZodLiteral<"owned_subtree">;
        state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
        desired: z.ZodEnum<["running", "paused", "terminated"]>;
        taskId: z.ZodString;
        rootId: z.ZodString;
        revision: z.ZodNumber;
        executionId: z.ZodString;
        threadId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"provider">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        receiptKey: z.ZodString;
        target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"host">;
            generation: z.ZodString;
            hostId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }>, z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"provider">;
            generation: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "provider";
            version: 1;
            generation: string;
        }, {
            kind: "provider";
            version: 1;
            generation: string;
        }>]>>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"native_graph">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodLiteral<"cancelled">;
        executionId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"host_admission">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["failed", "cancelled"]>;
        reason: z.ZodLiteral<"not_started">;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>]>>;
    receiptKey: z.ZodString;
    execution: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"assistant_task">;
        executionId: z.ZodString;
        conversationId: z.ZodString;
        xpertId: z.ZodString;
        publishedVersion: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"runtime_invocation">;
        invocationId: z.ZodString;
        bindingId: z.ZodString;
        provider: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }>]>>;
}, "strict", z.ZodTypeAny, {
    status: "pending";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}, {
    status: "pending";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}>, z.ZodObject<{
    status: z.ZodLiteral<"succeeded">;
    outputs: z.ZodEffects<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>>, Record<string, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, Record<string, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>>;
    control: z.ZodOptional<z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
        source: z.ZodLiteral<"unavailable">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        state: z.ZodLiteral<"unknown">;
        reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"platform">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        scope: z.ZodLiteral<"owned_subtree">;
        state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
        desired: z.ZodEnum<["running", "paused", "terminated"]>;
        taskId: z.ZodString;
        rootId: z.ZodString;
        revision: z.ZodNumber;
        executionId: z.ZodString;
        threadId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"provider">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        receiptKey: z.ZodString;
        target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"host">;
            generation: z.ZodString;
            hostId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }>, z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"provider">;
            generation: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "provider";
            version: 1;
            generation: string;
        }, {
            kind: "provider";
            version: 1;
            generation: string;
        }>]>>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"native_graph">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodLiteral<"cancelled">;
        executionId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"host_admission">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["failed", "cancelled"]>;
        reason: z.ZodLiteral<"not_started">;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>]>>;
    receiptKey: z.ZodString;
    execution: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"assistant_task">;
        executionId: z.ZodString;
        conversationId: z.ZodString;
        xpertId: z.ZodString;
        publishedVersion: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"runtime_invocation">;
        invocationId: z.ZodString;
        bindingId: z.ZodString;
        provider: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }>]>>;
}, "strict", z.ZodTypeAny, {
    status: "succeeded";
    outputs: Record<string, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>;
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}, {
    status: "succeeded";
    outputs: Record<string, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>;
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}>, z.ZodObject<{
    status: z.ZodLiteral<"failed">;
    code: z.ZodEffects<z.ZodString, string, string>;
    control: z.ZodOptional<z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
        source: z.ZodLiteral<"unavailable">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        state: z.ZodLiteral<"unknown">;
        reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"platform">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        scope: z.ZodLiteral<"owned_subtree">;
        state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
        desired: z.ZodEnum<["running", "paused", "terminated"]>;
        taskId: z.ZodString;
        rootId: z.ZodString;
        revision: z.ZodNumber;
        executionId: z.ZodString;
        threadId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"provider">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        receiptKey: z.ZodString;
        target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"host">;
            generation: z.ZodString;
            hostId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }>, z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"provider">;
            generation: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "provider";
            version: 1;
            generation: string;
        }, {
            kind: "provider";
            version: 1;
            generation: string;
        }>]>>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"native_graph">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodLiteral<"cancelled">;
        executionId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"host_admission">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["failed", "cancelled"]>;
        reason: z.ZodLiteral<"not_started">;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>]>>;
    receiptKey: z.ZodString;
    execution: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"assistant_task">;
        executionId: z.ZodString;
        conversationId: z.ZodString;
        xpertId: z.ZodString;
        publishedVersion: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"runtime_invocation">;
        invocationId: z.ZodString;
        bindingId: z.ZodString;
        provider: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }>]>>;
}, "strict", z.ZodTypeAny, {
    code: string;
    status: "failed";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}, {
    code: string;
    status: "failed";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}>, z.ZodObject<{
    status: z.ZodLiteral<"cancelled">;
    control: z.ZodOptional<z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
        source: z.ZodLiteral<"unavailable">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        state: z.ZodLiteral<"unknown">;
        reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"platform">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        scope: z.ZodLiteral<"owned_subtree">;
        state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
        desired: z.ZodEnum<["running", "paused", "terminated"]>;
        taskId: z.ZodString;
        rootId: z.ZodString;
        revision: z.ZodNumber;
        executionId: z.ZodString;
        threadId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"provider">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        receiptKey: z.ZodString;
        target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"host">;
            generation: z.ZodString;
            hostId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }>, z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"provider">;
            generation: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "provider";
            version: 1;
            generation: string;
        }, {
            kind: "provider";
            version: 1;
            generation: string;
        }>]>>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"native_graph">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodLiteral<"cancelled">;
        executionId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"host_admission">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["failed", "cancelled"]>;
        reason: z.ZodLiteral<"not_started">;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>]>>;
    receiptKey: z.ZodString;
    execution: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"assistant_task">;
        executionId: z.ZodString;
        conversationId: z.ZodString;
        xpertId: z.ZodString;
        publishedVersion: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"runtime_invocation">;
        invocationId: z.ZodString;
        bindingId: z.ZodString;
        provider: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }>]>>;
}, "strict", z.ZodTypeAny, {
    status: "cancelled";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}, {
    status: "cancelled";
    receiptKey: string;
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}>, z.ZodObject<{
    control: z.ZodOptional<z.ZodDiscriminatedUnion<"source", [z.ZodObject<{
        source: z.ZodLiteral<"unavailable">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        state: z.ZodLiteral<"unknown">;
        reason: z.ZodEnum<["unregistered", "unconfirmed", "unsupported"]>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"platform">;
        subject: z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            kind: z.ZodLiteral<"execution">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "execution";
            id: string;
        }, {
            kind: "execution";
            id: string;
        }>, z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>]>;
        scope: z.ZodLiteral<"owned_subtree">;
        state: z.ZodEnum<["running", "pausing", "paused", "terminating", "settled"]>;
        desired: z.ZodEnum<["running", "paused", "terminated"]>;
        taskId: z.ZodString;
        rootId: z.ZodString;
        revision: z.ZodNumber;
        executionId: z.ZodString;
        threadId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }, {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"provider">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["succeeded", "failed", "cancelled"]>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        receiptKey: z.ZodString;
        target: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"host">;
            generation: z.ZodString;
            hostId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }, {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        }>, z.ZodObject<{
            version: z.ZodLiteral<1>;
            kind: z.ZodLiteral<"provider">;
            generation: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "provider";
            version: 1;
            generation: string;
        }, {
            kind: "provider";
            version: 1;
            generation: string;
        }>]>>;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"native_graph">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodLiteral<"cancelled">;
        executionId: z.ZodString;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>, z.ZodObject<{
        source: z.ZodLiteral<"host_admission">;
        subject: z.ZodObject<{
            kind: z.ZodLiteral<"invocation">;
            id: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            kind: "invocation";
            id: string;
        }, {
            kind: "invocation";
            id: string;
        }>;
        scope: z.ZodLiteral<"operation">;
        state: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<["failed", "cancelled"]>;
        reason: z.ZodLiteral<"not_started">;
        version: z.ZodLiteral<1>;
        observedAt: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }, {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    }>]>>;
    receiptKey: z.ZodOptional<z.ZodString>;
    execution: z.ZodOptional<z.ZodDiscriminatedUnion<"kind", [z.ZodObject<{
        kind: z.ZodLiteral<"assistant_task">;
        executionId: z.ZodString;
        conversationId: z.ZodString;
        xpertId: z.ZodString;
        publishedVersion: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }, {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    }>, z.ZodObject<{
        kind: z.ZodLiteral<"runtime_invocation">;
        invocationId: z.ZodString;
        bindingId: z.ZodString;
        provider: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<["queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }, {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    }>]>>;
    status: z.ZodLiteral<"unknown">;
}, "strict", z.ZodTypeAny, {
    status: "unknown";
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    receiptKey?: string | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}, {
    status: "unknown";
    execution?: {
        kind: "assistant_task";
        status: "unknown" | "running" | "waiting" | "succeeded" | "failed" | "queued" | "cancelled";
        executionId: string;
        conversationId: string;
        xpertId: string;
        publishedVersion: string;
    } | {
        kind: "runtime_invocation";
        status: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled";
        revision: string;
        provider: string;
        bindingId: string;
        invocationId: string;
    } | undefined;
    receiptKey?: string | undefined;
    control?: {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        version: 1;
        source: "unavailable";
        reason: "unregistered" | "unconfirmed" | "unsupported";
        state: "unknown";
        observedAt: string;
    } | {
        subject: {
            kind: "execution";
            id: string;
        } | {
            kind: "invocation";
            id: string;
        };
        revision: number;
        threadId: string;
        executionId: string;
        version: 1;
        source: "platform";
        scope: "owned_subtree";
        state: "running" | "paused" | "pausing" | "terminating" | "settled";
        observedAt: string;
        desired: "running" | "paused" | "terminated";
        taskId: string;
        rootId: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "succeeded" | "failed" | "cancelled";
        version: 1;
        source: "provider";
        scope: "operation";
        state: "settled";
        runId: string;
        observedAt: string;
        sessionId: string;
        receiptKey: string;
        target?: {
            kind: "host";
            version: 1;
            generation: string;
            hostId: string;
        } | {
            kind: "provider";
            version: 1;
            generation: string;
        } | undefined;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        executionId: string;
        outcome: "cancelled";
        version: 1;
        source: "native_graph";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | {
        subject: {
            kind: "invocation";
            id: string;
        };
        outcome: "failed" | "cancelled";
        version: 1;
        source: "host_admission";
        reason: "not_started";
        scope: "operation";
        state: "settled";
        observedAt: string;
    } | undefined;
}>]>;
export declare const projectPipelineCompletionReceiptSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"accepted">;
    evidence: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    status: "accepted";
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}, {
    status: "accepted";
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}>, z.ZodObject<{
    status: z.ZodLiteral<"pending">;
    code: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    code: string;
    status: "pending";
}, {
    code: string;
    status: "pending";
}>, z.ZodObject<{
    status: z.ZodLiteral<"rejected">;
    code: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    code: string;
    status: "rejected";
}, {
    code: string;
    status: "rejected";
}>]>;
export declare const projectPipelinePolicyReceiptSchema: z.ZodDiscriminatedUnion<"status", [z.ZodObject<{
    status: z.ZodLiteral<"decided">;
    outcome: z.ZodEffects<z.ZodString, string, string>;
    evidence: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, "many">;
}, "strict", z.ZodTypeAny, {
    status: "decided";
    outcome: string;
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}, {
    status: "decided";
    outcome: string;
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}>, z.ZodObject<{
    status: z.ZodLiteral<"blocked">;
    code: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    code: string;
    status: "blocked";
}, {
    code: string;
    status: "blocked";
}>]>;
export type ProjectPipelineOperationInput = z.output<typeof projectPipelineOperationInputSchema>;
export type ProjectPipelineOperationReceipt = z.output<typeof projectPipelineOperationReceiptSchema>;
export type ProjectPipelineCompletionReceipt = z.output<typeof projectPipelineCompletionReceiptSchema>;
export type ProjectPipelinePolicyReceipt = z.output<typeof projectPipelinePolicyReceiptSchema>;
