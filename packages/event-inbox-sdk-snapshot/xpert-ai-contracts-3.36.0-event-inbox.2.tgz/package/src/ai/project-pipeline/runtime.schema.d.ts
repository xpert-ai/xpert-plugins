import { z } from 'zod/v3';
export declare const projectPipelineProjectBindingSchema: z.ZodObject<{
    definition: z.ZodObject<{
        templateRef: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        digest: string;
    }, {
        templateRef: string;
        digest: string;
    }>;
    revision: z.ZodNumber;
    configuration: z.ZodObject<{
        templateRef: z.ZodString;
        roleBindings: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
            kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
            selectionKey: z.ZodEffects<z.ZodString, string, string>;
            requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        }, "strict", z.ZodTypeAny, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>>;
        executorBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodEffects<z.ZodObject<{
            kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
            selectionKey: z.ZodEffects<z.ZodString, string, string>;
            requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        } & {
            roleKey: z.ZodEffects<z.ZodString, string, string>;
            workspaceId: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }>, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }>>>;
        providerConfiguration: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
        parameters: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
        limits: z.ZodOptional<z.ZodObject<{
            maxConcurrentExecutions: z.ZodNumber;
            maxTechnicalAttemptsPerNode: z.ZodNumber;
            runTimeoutMinutes: z.ZodNumber;
            nativeModelBudget: z.ZodOptional<z.ZodEffects<z.ZodObject<{
                maxCalls: z.ZodNumber;
                maxTokens: z.ZodNumber;
                reservationTokens: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }>, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }>>;
        }, "strict", z.ZodTypeAny, {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        }, {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        }>>;
        triggers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            adapterRef: z.ZodString;
            events: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
        }, "strict", z.ZodTypeAny, {
            adapterRef: string;
            events: string[];
        }, {
            adapterRef: string;
            events: string[];
        }>, "many">>;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    }, {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    }>;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    revision: number;
    id: string;
    definition: {
        templateRef: string;
        digest: string;
    };
    configuration: {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
}, {
    revision: number;
    id: string;
    definition: {
        templateRef: string;
        digest: string;
    };
    configuration: {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
}>;
export declare const projectPipelineInstanceSchema: z.ZodDiscriminatedUnion<"executionAuthority", [z.ZodObject<{
    executionAuthority: z.ZodLiteral<"provider">;
    providerRef: z.ZodString;
    sourceKey: z.ZodString;
    definition: z.ZodObject<{
        templateRef: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        digest: string;
    }, {
        templateRef: string;
        digest: string;
    }>;
    subject: z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        resolverRef: string;
        objectKey: string;
    }, {
        resolverRef: string;
        objectKey: string;
    }>;
    revision: z.ZodNumber;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        resolverRef: string;
        objectKey: string;
    };
    revision: number;
    id: string;
    executionAuthority: "provider";
    providerRef: string;
    definition: {
        templateRef: string;
        digest: string;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    sourceKey: string;
}, {
    subject: {
        resolverRef: string;
        objectKey: string;
    };
    revision: number;
    id: string;
    executionAuthority: "provider";
    providerRef: string;
    definition: {
        templateRef: string;
        digest: string;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    sourceKey: string;
}>, z.ZodObject<{
    executionAuthority: z.ZodLiteral<"platform">;
    bindingId: z.ZodString;
    sourceKey: z.ZodString;
    definition: z.ZodObject<{
        templateRef: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        digest: string;
    }, {
        templateRef: string;
        digest: string;
    }>;
    subject: z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        resolverRef: string;
        objectKey: string;
    }, {
        resolverRef: string;
        objectKey: string;
    }>;
    revision: z.ZodNumber;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    subject: {
        resolverRef: string;
        objectKey: string;
    };
    revision: number;
    id: string;
    executionAuthority: "platform";
    definition: {
        templateRef: string;
        digest: string;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    sourceKey: string;
    bindingId: string;
}, {
    subject: {
        resolverRef: string;
        objectKey: string;
    };
    revision: number;
    id: string;
    executionAuthority: "platform";
    definition: {
        templateRef: string;
        digest: string;
    };
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    sourceKey: string;
    bindingId: string;
}>]>;
export declare const projectPipelineRunSchema: z.ZodObject<{
    instanceId: z.ZodString;
    triggerKey: z.ZodString;
    definition: z.ZodObject<{
        templateRef: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        digest: string;
    }, {
        templateRef: string;
        digest: string;
    }>;
    bindingSnapshot: z.ZodObject<{
        templateRef: z.ZodString;
        roleBindings: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodObject<{
            kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
            selectionKey: z.ZodEffects<z.ZodString, string, string>;
            requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        }, "strict", z.ZodTypeAny, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>>;
        executorBindings: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodEffects<z.ZodObject<{
            kind: z.ZodEnum<["assistant", "runtime_binding", "human", "service"]>;
            selectionKey: z.ZodEffects<z.ZodString, string, string>;
            requiredCapabilities: z.ZodOptional<z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">>;
        } & {
            roleKey: z.ZodEffects<z.ZodString, string, string>;
            workspaceId: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }>, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }>>>;
        providerConfiguration: z.ZodOptional<z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>>;
        parameters: z.ZodRecord<z.ZodEffects<z.ZodString, string, string>, z.ZodType<import("./primitives.schema").ProjectPipelineJsonValue, z.ZodTypeDef, import("./primitives.schema").ProjectPipelineJsonValue>>;
        limits: z.ZodOptional<z.ZodObject<{
            maxConcurrentExecutions: z.ZodNumber;
            maxTechnicalAttemptsPerNode: z.ZodNumber;
            runTimeoutMinutes: z.ZodNumber;
            nativeModelBudget: z.ZodOptional<z.ZodEffects<z.ZodObject<{
                maxCalls: z.ZodNumber;
                maxTokens: z.ZodNumber;
                reservationTokens: z.ZodNumber;
            }, "strict", z.ZodTypeAny, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }>, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }, {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            }>>;
        }, "strict", z.ZodTypeAny, {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        }, {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        }>>;
        triggers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            adapterRef: z.ZodString;
            events: z.ZodArray<z.ZodEffects<z.ZodString, string, string>, "many">;
        }, "strict", z.ZodTypeAny, {
            adapterRef: string;
            events: string[];
        }, {
            adapterRef: string;
            events: string[];
        }>, "many">>;
    }, "strict", z.ZodTypeAny, {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    }, {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    }>;
    state: z.ZodEnum<["pending", "active", "waiting", "cancelling", "completed", "failed", "cancelled", "superseded"]>;
    revision: z.ZodNumber;
    startedAt: z.ZodNullable<z.ZodString>;
    completedAt: z.ZodNullable<z.ZodString>;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    revision: number;
    id: string;
    startedAt: string | null;
    definition: {
        templateRef: string;
        digest: string;
    };
    instanceId: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    triggerKey: string;
    bindingSnapshot: {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    };
    state: "pending" | "waiting" | "cancelling" | "failed" | "completed" | "cancelled" | "active" | "superseded";
    completedAt: string | null;
}, {
    revision: number;
    id: string;
    startedAt: string | null;
    definition: {
        templateRef: string;
        digest: string;
    };
    instanceId: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    triggerKey: string;
    bindingSnapshot: {
        templateRef: string;
        roleBindings: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
        }>;
        parameters: Record<string, import("./primitives.schema").ProjectPipelineJsonValue>;
        executorBindings?: Record<string, {
            kind: "assistant" | "runtime_binding" | "human" | "service";
            roleKey: string;
            selectionKey: string;
            requiredCapabilities?: string[] | undefined;
            workspaceId?: string | undefined;
        }> | undefined;
        providerConfiguration?: Record<string, import("./primitives.schema").ProjectPipelineJsonValue> | undefined;
        limits?: {
            maxConcurrentExecutions: number;
            maxTechnicalAttemptsPerNode: number;
            runTimeoutMinutes: number;
            nativeModelBudget?: {
                maxCalls: number;
                maxTokens: number;
                reservationTokens: number;
            } | undefined;
        } | undefined;
        triggers?: {
            adapterRef: string;
            events: string[];
        }[] | undefined;
    };
    state: "pending" | "waiting" | "cancelling" | "failed" | "completed" | "cancelled" | "active" | "superseded";
    completedAt: string | null;
}>;
export declare const projectPipelineSubjectVersionSchema: z.ZodObject<{
    resolverRef: z.ZodString;
    objectKey: z.ZodString;
    version: z.ZodString;
    digest: z.ZodString;
}, "strict", z.ZodTypeAny, {
    version: string;
    resolverRef: string;
    digest: string;
    objectKey: string;
}, {
    version: string;
    resolverRef: string;
    digest: string;
    objectKey: string;
}>;
/** Scope and ownership are resolved by the host; possession of this reference grants no access. */
export declare const projectPipelineEvidenceRefSchema: z.ZodObject<{
    resolverRef: z.ZodString;
    objectKey: z.ZodString;
    version: z.ZodString;
    digest: z.ZodString;
} & {
    schemaRef: z.ZodString;
    producerOperationId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    version: string;
    resolverRef: string;
    digest: string;
    objectKey: string;
    schemaRef: string;
    producerOperationId?: string | undefined;
}, {
    version: string;
    resolverRef: string;
    digest: string;
    objectKey: string;
    schemaRef: string;
    producerOperationId?: string | undefined;
}>;
export declare const projectPipelineNodeStateSchema: z.ZodObject<{
    lifecycle: z.ZodEnum<["pending", "active", "completed", "failed", "cancelled"]>;
    readiness: z.ZodEnum<["waiting", "ready", "blocked"]>;
    applicability: z.ZodEnum<["undetermined", "selected", "excluded"]>;
    freshness: z.ZodEnum<["current", "superseded"]>;
    runtime: z.ZodEnum<["none", "queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
}, "strict", z.ZodTypeAny, {
    lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
    readiness: "blocked" | "waiting" | "ready";
    applicability: "undetermined" | "selected" | "excluded";
    freshness: "superseded" | "current";
    runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
}, {
    lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
    readiness: "blocked" | "waiting" | "ready";
    applicability: "undetermined" | "selected" | "excluded";
    freshness: "superseded" | "current";
    runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
}>;
export declare const projectPipelineWorkContextSchema: z.ZodObject<{
    instanceId: z.ZodString;
    runId: z.ZodString;
    roundId: z.ZodString;
    nodeInstanceId: z.ZodString;
    operationId: z.ZodString;
    inputDigest: z.ZodString;
    generation: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    operationId: string;
    instanceId: string;
    runId: string;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
}, {
    operationId: string;
    instanceId: string;
    runId: string;
    roundId: string;
    nodeInstanceId: string;
    inputDigest: string;
    generation: number;
}>;
export declare const projectPipelineRoundSchema: z.ZodObject<{
    runId: z.ZodString;
    sequence: z.ZodNumber;
    generation: z.ZodNumber;
    state: z.ZodEnum<["active", "completed", "awaiting_new_subject", "failed", "cancelled", "superseded"]>;
    inputDigest: z.ZodString;
    subjectVersionSet: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }>, "many">;
    supersedes: z.ZodNullable<z.ZodString>;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    id: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    state: "failed" | "completed" | "cancelled" | "active" | "superseded" | "awaiting_new_subject";
    runId: string;
    inputDigest: string;
    generation: number;
    sequence: number;
    subjectVersionSet: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }[];
    supersedes: string | null;
}, {
    id: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    state: "failed" | "completed" | "cancelled" | "active" | "superseded" | "awaiting_new_subject";
    runId: string;
    inputDigest: string;
    generation: number;
    sequence: number;
    subjectVersionSet: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
    }[];
    supersedes: string | null;
}>;
export declare const projectPipelineNodeInstanceSchema: z.ZodObject<{
    roundId: z.ZodString;
    nodeKey: z.ZodEffects<z.ZodString, string, string>;
    /** Stable source identity; never a list index. */
    expansionKey: z.ZodString;
    laneKey: z.ZodNullable<z.ZodEffects<z.ZodString, string, string>>;
    stageKey: z.ZodEffects<z.ZodString, string, string>;
    state: z.ZodObject<{
        lifecycle: z.ZodEnum<["pending", "active", "completed", "failed", "cancelled"]>;
        readiness: z.ZodEnum<["waiting", "ready", "blocked"]>;
        applicability: z.ZodEnum<["undetermined", "selected", "excluded"]>;
        freshness: z.ZodEnum<["current", "superseded"]>;
        runtime: z.ZodEnum<["none", "queued", "running", "waiting", "cancelling", "succeeded", "failed", "cancelled", "unknown"]>;
    }, "strict", z.ZodTypeAny, {
        lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
        readiness: "blocked" | "waiting" | "ready";
        applicability: "undetermined" | "selected" | "excluded";
        freshness: "superseded" | "current";
        runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
    }, {
        lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
        readiness: "blocked" | "waiting" | "ready";
        applicability: "undetermined" | "selected" | "excluded";
        freshness: "superseded" | "current";
        runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
    }>;
    taskIds: z.ZodArray<z.ZodString, "many">;
    evidence: z.ZodArray<z.ZodObject<{
        resolverRef: z.ZodString;
        objectKey: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
    } & {
        schemaRef: z.ZodString;
        producerOperationId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }, {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }>, "many">;
    revision: z.ZodNumber;
    id: z.ZodString;
    tenantId: z.ZodString;
    organizationId: z.ZodNullable<z.ZodString>;
    projectId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    revision: number;
    id: string;
    nodeKey: string;
    laneKey: string | null;
    stageKey: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    state: {
        lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
        readiness: "blocked" | "waiting" | "ready";
        applicability: "undetermined" | "selected" | "excluded";
        freshness: "superseded" | "current";
        runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
    };
    roundId: string;
    expansionKey: string;
    taskIds: string[];
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}, {
    revision: number;
    id: string;
    nodeKey: string;
    laneKey: string | null;
    stageKey: string;
    tenantId: string;
    organizationId: string | null;
    projectId: string;
    state: {
        lifecycle: "pending" | "failed" | "completed" | "cancelled" | "active";
        readiness: "blocked" | "waiting" | "ready";
        applicability: "undetermined" | "selected" | "excluded";
        freshness: "superseded" | "current";
        runtime: "unknown" | "running" | "waiting" | "cancelling" | "succeeded" | "failed" | "queued" | "cancelled" | "none";
    };
    roundId: string;
    expansionKey: string;
    taskIds: string[];
    evidence: {
        version: string;
        resolverRef: string;
        digest: string;
        objectKey: string;
        schemaRef: string;
        producerOperationId?: string | undefined;
    }[];
}>;
export type ProjectPipelineSubjectVersion = z.output<typeof projectPipelineSubjectVersionSchema>;
export type ProjectPipelineProjectBinding = z.output<typeof projectPipelineProjectBindingSchema>;
export type ProjectPipelineInstance = z.output<typeof projectPipelineInstanceSchema>;
export type ProjectPipelineRun = z.output<typeof projectPipelineRunSchema>;
export type ProjectPipelineEvidenceRef = z.output<typeof projectPipelineEvidenceRefSchema>;
export type ProjectPipelineNodeState = z.output<typeof projectPipelineNodeStateSchema>;
export type ProjectPipelineWorkContext = z.output<typeof projectPipelineWorkContextSchema>;
export type ProjectPipelineRound = z.output<typeof projectPipelineRoundSchema>;
export type ProjectPipelineNodeInstance = z.output<typeof projectPipelineNodeInstanceSchema>;
