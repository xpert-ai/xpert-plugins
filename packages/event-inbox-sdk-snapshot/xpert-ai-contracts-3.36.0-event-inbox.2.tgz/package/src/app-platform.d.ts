import { z } from 'zod/v3';
import { AiModelTypeEnum } from './agent/ai-model';
export declare const appPlatformAppSchema: z.ZodEffects<z.ZodObject<{
    key: z.ZodString;
    appRef: z.ZodObject<{
        pluginName: z.ZodString;
        appName: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        pluginName?: string;
        appName?: string;
    }, {
        pluginName?: string;
        appName?: string;
    }>;
    required: z.ZodBoolean;
    enabled: z.ZodDefault<z.ZodBoolean>;
    configurationRef: z.ZodString;
    dependsOn: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
}, "strict", z.ZodTypeAny, {
    key?: string;
    enabled?: boolean;
    required?: boolean;
    appRef?: {
        pluginName?: string;
        appName?: string;
    };
    configurationRef?: string;
    dependsOn?: string[];
}, {
    key?: string;
    enabled?: boolean;
    required?: boolean;
    appRef?: {
        pluginName?: string;
        appName?: string;
    };
    configurationRef?: string;
    dependsOn?: string[];
}>, {
    key: string;
    required: boolean;
    configurationRef: string;
    dependsOn: string[];
    enabled: boolean;
    appRef: {
        pluginName: string;
        appName: string;
    };
}, {
    key?: string;
    enabled?: boolean;
    required?: boolean;
    appRef?: {
        pluginName?: string;
        appName?: string;
    };
    configurationRef?: string;
    dependsOn?: string[];
}>;
/** Portable product composition. Credentials and database identities never belong here. */
export declare const appPlatformDefinitionSchema: z.ZodEffects<z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    key: z.ZodString;
    version: z.ZodNumber;
    branding: z.ZodObject<{
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        logo: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        description?: string;
        name?: string;
        logo?: string;
    }, {
        description?: string;
        name?: string;
        logo?: string;
    }>;
    registration: z.ZodObject<{
        role: z.ZodLiteral<"APP_USER">;
        organization: z.ZodLiteral<"per-account">;
    }, "strict", z.ZodTypeAny, {
        role?: "APP_USER";
        organization?: "per-account";
    }, {
        role?: "APP_USER";
        organization?: "per-account";
    }>;
    apps: z.ZodArray<z.ZodEffects<z.ZodObject<{
        key: z.ZodString;
        appRef: z.ZodObject<{
            pluginName: z.ZodString;
            appName: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            pluginName?: string;
            appName?: string;
        }, {
            pluginName?: string;
            appName?: string;
        }>;
        required: z.ZodBoolean;
        enabled: z.ZodDefault<z.ZodBoolean>;
        configurationRef: z.ZodString;
        dependsOn: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    }, "strict", z.ZodTypeAny, {
        key?: string;
        enabled?: boolean;
        required?: boolean;
        appRef?: {
            pluginName?: string;
            appName?: string;
        };
        configurationRef?: string;
        dependsOn?: string[];
    }, {
        key?: string;
        enabled?: boolean;
        required?: boolean;
        appRef?: {
            pluginName?: string;
            appName?: string;
        };
        configurationRef?: string;
        dependsOn?: string[];
    }>, {
        key: string;
        required: boolean;
        configurationRef: string;
        dependsOn: string[];
        enabled: boolean;
        appRef: {
            pluginName: string;
            appName: string;
        };
    }, {
        key?: string;
        enabled?: boolean;
        required?: boolean;
        appRef?: {
            pluginName?: string;
            appName?: string;
        };
        configurationRef?: string;
        dependsOn?: string[];
    }>, "many">;
    bindings: z.ZodDefault<z.ZodArray<z.ZodObject<{
        type: z.ZodLiteral<"knowledgebase">;
        from: z.ZodObject<{
            app: z.ZodString;
            resource: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            resource?: string;
            app?: string;
        }, {
            resource?: string;
            app?: string;
        }>;
        to: z.ZodObject<{
            app: z.ZodString;
            resource: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            resource?: string;
            app?: string;
        }, {
            resource?: string;
            app?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }, {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }>, "many">>;
    experience: z.ZodObject<{
        home: z.ZodString;
        navigation: z.ZodArray<z.ZodString, "many">;
    }, "strict", z.ZodTypeAny, {
        navigation?: string[];
        home?: string;
    }, {
        navigation?: string[];
        home?: string;
    }>;
    entitlements: z.ZodObject<{
        defaultPlanRef: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        defaultPlanRef?: string;
    }, {
        defaultPlanRef?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    key?: string;
    schemaVersion?: 1;
    version?: number;
    apps?: {
        key: string;
        required: boolean;
        configurationRef: string;
        dependsOn: string[];
        enabled: boolean;
        appRef: {
            pluginName: string;
            appName: string;
        };
    }[];
    bindings?: {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }[];
    branding?: {
        description?: string;
        name?: string;
        logo?: string;
    };
    registration?: {
        role?: "APP_USER";
        organization?: "per-account";
    };
    experience?: {
        navigation?: string[];
        home?: string;
    };
    entitlements?: {
        defaultPlanRef?: string;
    };
}, {
    key?: string;
    schemaVersion?: 1;
    version?: number;
    apps?: {
        key?: string;
        enabled?: boolean;
        required?: boolean;
        appRef?: {
            pluginName?: string;
            appName?: string;
        };
        configurationRef?: string;
        dependsOn?: string[];
    }[];
    bindings?: {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }[];
    branding?: {
        description?: string;
        name?: string;
        logo?: string;
    };
    registration?: {
        role?: "APP_USER";
        organization?: "per-account";
    };
    experience?: {
        navigation?: string[];
        home?: string;
    };
    entitlements?: {
        defaultPlanRef?: string;
    };
}>, {
    key?: string;
    schemaVersion?: 1;
    version?: number;
    apps?: {
        key: string;
        required: boolean;
        configurationRef: string;
        dependsOn: string[];
        enabled: boolean;
        appRef: {
            pluginName: string;
            appName: string;
        };
    }[];
    bindings?: {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }[];
    branding?: {
        description?: string;
        name?: string;
        logo?: string;
    };
    registration?: {
        role?: "APP_USER";
        organization?: "per-account";
    };
    experience?: {
        navigation?: string[];
        home?: string;
    };
    entitlements?: {
        defaultPlanRef?: string;
    };
}, {
    key?: string;
    schemaVersion?: 1;
    version?: number;
    apps?: {
        key?: string;
        enabled?: boolean;
        required?: boolean;
        appRef?: {
            pluginName?: string;
            appName?: string;
        };
        configurationRef?: string;
        dependsOn?: string[];
    }[];
    bindings?: {
        type?: "knowledgebase";
        from?: {
            resource?: string;
            app?: string;
        };
        to?: {
            resource?: string;
            app?: string;
        };
    }[];
    branding?: {
        description?: string;
        name?: string;
        logo?: string;
    };
    registration?: {
        role?: "APP_USER";
        organization?: "per-account";
    };
    experience?: {
        navigation?: string[];
        home?: string;
    };
    entitlements?: {
        defaultPlanRef?: string;
    };
}>;
export type AppPlatformDefinition = z.output<typeof appPlatformDefinitionSchema>;
export type AppPlatformApp = z.output<typeof appPlatformAppSchema>;
export declare const appPlatformEnvironmentSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    configurations: z.ZodRecord<z.ZodString, z.ZodObject<{
        primary: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            role: z.ZodOptional<z.ZodEnum<["primary", "secondary", "embedding", "reasoning"]>>;
        }, "strict", z.ZodTypeAny, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }>;
        embedding: z.ZodOptional<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            role: z.ZodOptional<z.ZodEnum<["primary", "secondary", "embedding", "reasoning"]>>;
        }, "strict", z.ZodTypeAny, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }>>;
        vision: z.ZodOptional<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            role: z.ZodOptional<z.ZodEnum<["primary", "secondary", "embedding", "reasoning"]>>;
        }, "strict", z.ZodTypeAny, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }>>;
        speechToText: z.ZodOptional<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            role: z.ZodOptional<z.ZodEnum<["primary", "secondary", "embedding", "reasoning"]>>;
        }, "strict", z.ZodTypeAny, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        }>>;
        auxiliaryModels: z.ZodDefault<z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            role: z.ZodOptional<z.ZodEnum<["primary", "secondary", "embedding", "reasoning"]>>;
        } & {
            modelType: z.ZodNativeEnum<typeof AiModelTypeEnum>;
        }, "strict", z.ZodTypeAny, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }, {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }>, "many">>;
        tools: z.ZodEffects<z.ZodDefault<z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            sourceName: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            provider?: string;
            sourceName?: string;
        }, {
            provider?: string;
            sourceName?: string;
        }>, "many">>, {
            provider?: string;
            sourceName?: string;
        }[], {
            provider?: string;
            sourceName?: string;
        }[]>;
    }, "strict", z.ZodTypeAny, {
        primary?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        embedding?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        tools?: {
            provider?: string;
            sourceName?: string;
        }[];
        vision?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        speechToText?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        auxiliaryModels?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }[];
    }, {
        primary?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        embedding?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        tools?: {
            provider?: string;
            sourceName?: string;
        }[];
        vision?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        speechToText?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        auxiliaryModels?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }[];
    }>>;
    plans: z.ZodRecord<z.ZodString, z.ZodObject<{
        trialDays: z.ZodNumber;
        creditLimit: z.ZodNumber;
        maxProjects: z.ZodNumber;
        maxUploadBytes: z.ZodNumber;
        maxStorageBytes: z.ZodDefault<z.ZodNumber>;
        maxTemporaryBytes: z.ZodDefault<z.ZodNumber>;
        maxConcurrentRuns: z.ZodNumber;
    }, "strict", z.ZodTypeAny, {
        trialDays?: number;
        creditLimit?: number;
        maxProjects?: number;
        maxUploadBytes?: number;
        maxStorageBytes?: number;
        maxTemporaryBytes?: number;
        maxConcurrentRuns?: number;
    }, {
        trialDays?: number;
        creditLimit?: number;
        maxProjects?: number;
        maxUploadBytes?: number;
        maxStorageBytes?: number;
        maxTemporaryBytes?: number;
        maxConcurrentRuns?: number;
    }>>;
}, "strict", z.ZodTypeAny, {
    schemaVersion?: 1;
    configurations?: Record<string, {
        primary?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        embedding?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        tools?: {
            provider?: string;
            sourceName?: string;
        }[];
        vision?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        speechToText?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        auxiliaryModels?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }[];
    }>;
    plans?: Record<string, {
        trialDays?: number;
        creditLimit?: number;
        maxProjects?: number;
        maxUploadBytes?: number;
        maxStorageBytes?: number;
        maxTemporaryBytes?: number;
        maxConcurrentRuns?: number;
    }>;
}, {
    schemaVersion?: 1;
    configurations?: Record<string, {
        primary?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        embedding?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        tools?: {
            provider?: string;
            sourceName?: string;
        }[];
        vision?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        speechToText?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            model?: string;
            provider?: string;
        };
        auxiliaryModels?: {
            role?: "primary" | "secondary" | "reasoning" | "embedding";
            modelType?: AiModelTypeEnum;
            model?: string;
            provider?: string;
        }[];
    }>;
    plans?: Record<string, {
        trialDays?: number;
        creditLimit?: number;
        maxProjects?: number;
        maxUploadBytes?: number;
        maxStorageBytes?: number;
        maxTemporaryBytes?: number;
        maxConcurrentRuns?: number;
    }>;
}>;
export type AppPlatformEnvironment = z.output<typeof appPlatformEnvironmentSchema>;
export interface AppPlatformConfiguration {
    definition: AppPlatformDefinition;
    environment: AppPlatformEnvironment;
    digest: string;
}
export declare function appPlatformAppOrder(definition: AppPlatformDefinition): AppPlatformApp[];
export interface AppPlatformStatus {
    mode: 'managed-apps';
    branding: AppPlatformDefinition['branding'];
    platformKey: string;
    version: number;
    organizationId: string;
    home: string;
    ready: boolean;
    apps: Array<{
        key: string;
        required: boolean;
        status: 'pending' | 'initializing' | 'ready' | 'failed' | 'blocked' | 'disabled';
        errorCode?: string;
        entries: Array<{
            key: string;
            id: string;
            slug?: string;
            title: string;
        }>;
    }>;
}
