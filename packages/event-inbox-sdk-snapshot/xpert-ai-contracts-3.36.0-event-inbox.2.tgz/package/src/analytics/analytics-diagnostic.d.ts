import { z } from 'zod/v3';
/** Portable HTTP/provider failure contract. No arbitrary details, cause, query or connection fields. */
export declare const analyticsDiagnosticSchema: z.ZodEffects<z.ZodObject<{
    schema: z.ZodLiteral<"xpert.analytics.diagnostic">;
    version: z.ZodLiteral<1>;
    code: z.ZodString;
    stage: z.ZodEnum<["request", "source", "validation", "authorization", "execution", "result", "dependency"]>;
    message: z.ZodEffects<z.ZodString, string, string>;
    retryable: z.ZodBoolean;
    upstreamExecutionId: z.ZodOptional<z.ZodString>;
    auditRef: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    code?: string;
    message?: string;
    version?: 1;
    stage?: "validation" | "source" | "execution" | "request" | "result" | "dependency" | "authorization";
    schema?: "xpert.analytics.diagnostic";
    retryable?: boolean;
    upstreamExecutionId?: string;
    auditRef?: string;
}, {
    code?: string;
    message?: string;
    version?: 1;
    stage?: "validation" | "source" | "execution" | "request" | "result" | "dependency" | "authorization";
    schema?: "xpert.analytics.diagnostic";
    retryable?: boolean;
    upstreamExecutionId?: string;
    auditRef?: string;
}>, {
    code?: string;
    message?: string;
    version?: 1;
    stage?: "validation" | "source" | "execution" | "request" | "result" | "dependency" | "authorization";
    schema?: "xpert.analytics.diagnostic";
    retryable?: boolean;
    upstreamExecutionId?: string;
    auditRef?: string;
}, {
    code?: string;
    message?: string;
    version?: 1;
    stage?: "validation" | "source" | "execution" | "request" | "result" | "dependency" | "authorization";
    schema?: "xpert.analytics.diagnostic";
    retryable?: boolean;
    upstreamExecutionId?: string;
    auditRef?: string;
}>;
type ParsedDiagnostic = z.infer<typeof analyticsDiagnosticSchema>;
export type AnalyticsDiagnostic = Required<Omit<ParsedDiagnostic, 'upstreamExecutionId' | 'auditRef'>> & Pick<ParsedDiagnostic, 'upstreamExecutionId' | 'auditRef'>;
/** Invalid provider diagnostics fail closed; never return Zod errors containing received input. */
export declare function parseAnalyticsDiagnostic(value: unknown): AnalyticsDiagnostic | undefined;
export {};
