import { z } from 'zod/v3';
export declare const notificationClientSchema: z.ZodEnum<["web", "desktop"]>;
export type NotificationClient = z.infer<typeof notificationClientSchema>;
export declare const announcementActionSchema: z.ZodObject<{
    type: z.ZodLiteral<"link">;
    label: z.ZodString;
    url: z.ZodEffects<z.ZodString, string, string>;
}, "strict", z.ZodTypeAny, {
    type?: "link";
    label?: string;
    url?: string;
}, {
    type?: "link";
    label?: string;
    url?: string;
}>;
export declare const announcementContentSchema: z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("desktop" | "web")[], ("desktop" | "web")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type?: "link";
        label?: string;
        url?: string;
    }, {
        type?: "link";
        label?: string;
        url?: string;
    }>>>;
}, "strict", z.ZodTypeAny, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}>;
export declare const createAnnouncementSchema: z.ZodEffects<z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("desktop" | "web")[], ("desktop" | "web")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type?: "link";
        label?: string;
        url?: string;
    }, {
        type?: "link";
        label?: string;
        url?: string;
    }>>>;
}, "strict", z.ZodTypeAny, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}>, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}, {
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}>;
export declare const updateAnnouncementSchema: z.ZodEffects<z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("desktop" | "web")[], ("desktop" | "web")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type?: "link";
        label?: string;
        url?: string;
    }, {
        type?: "link";
        label?: string;
        url?: string;
    }>>>;
} & {
    revision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}, {
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}>, {
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}, {
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
}>;
export declare const announcementRevisionSchema: z.ZodObject<{
    revision: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    revision?: number;
}, {
    revision?: number;
}>;
export declare const announcementSchema: z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
    severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
    clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("desktop" | "web")[], ("desktop" | "web")[]>;
    startsAt: z.ZodString;
    expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        type: z.ZodLiteral<"link">;
        label: z.ZodString;
        url: z.ZodEffects<z.ZodString, string, string>;
    }, "strict", z.ZodTypeAny, {
        type?: "link";
        label?: string;
        url?: string;
    }, {
        type?: "link";
        label?: string;
        url?: string;
    }>>>;
} & {
    id: z.ZodString;
    status: z.ZodEnum<["draft", "published", "withdrawn"]>;
    revision: z.ZodNumber;
    createdAt: z.ZodString;
    dismissedAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
}, "strict", z.ZodTypeAny, {
    status?: "withdrawn" | "draft" | "published";
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    id?: string;
    createdAt?: string;
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
    dismissedAt?: string;
}, {
    status?: "withdrawn" | "draft" | "published";
    revision?: number;
    category?: "general" | "maintenance" | "model_retirement";
    id?: string;
    createdAt?: string;
    title?: string;
    expiresAt?: string;
    action?: {
        type?: "link";
        label?: string;
        url?: string;
    };
    body?: string;
    severity?: "info" | "important";
    clients?: ("desktop" | "web")[];
    startsAt?: string;
    dismissedAt?: string;
}>;
export type AnnouncementInput = z.output<typeof createAnnouncementSchema>;
export type Announcement = Omit<Required<z.output<typeof announcementSchema>>, 'action'> & {
    action: Required<z.output<typeof announcementActionSchema>> | null;
};
export declare const notificationSourceSchema: z.ZodObject<{
    type: z.ZodLiteral<"scheduled_task">;
    taskId: z.ZodString;
    executionId: z.ZodString;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "scheduled_task";
    conversationId?: string;
    executionId?: string;
    taskId?: string;
    assistantId?: string;
}, {
    type?: "scheduled_task";
    conversationId?: string;
    executionId?: string;
    taskId?: string;
    assistantId?: string;
}>;
export declare const scheduledNotificationOriginSchema: z.ZodObject<{
    type: z.ZodLiteral<"scheduled_task">;
    taskId: z.ZodString;
    executionId: z.ZodString;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
} & {
    threadId: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    type?: "scheduled_task";
    conversationId?: string;
    executionId?: string;
    taskId?: string;
    threadId?: string;
    assistantId?: string;
}, {
    type?: "scheduled_task";
    conversationId?: string;
    executionId?: string;
    taskId?: string;
    threadId?: string;
    assistantId?: string;
}>;
export declare const openConversationActionSchema: z.ZodObject<{
    type: z.ZodLiteral<"open_conversation">;
    assistantId: z.ZodString;
    conversationId: z.ZodString;
    threadId: z.ZodNullable<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    type?: "open_conversation";
    conversationId?: string;
    threadId?: string;
    assistantId?: string;
}, {
    type?: "open_conversation";
    conversationId?: string;
    threadId?: string;
    assistantId?: string;
}>;
export type OpenConversationAction = Required<z.output<typeof openConversationActionSchema>>;
export declare const userNotificationSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<"agent.completed">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"scheduled_task">;
        taskId: z.ZodString;
        executionId: z.ZodString;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        assistantId?: string;
    }, {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        assistantId?: string;
    }>;
    createdAt: z.ZodString;
    readAt: z.ZodNullable<z.ZodString>;
    action: z.ZodObject<{
        type: z.ZodLiteral<"open_conversation">;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
        threadId: z.ZodNullable<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type?: "open_conversation";
        conversationId?: string;
        threadId?: string;
        assistantId?: string;
    }, {
        type?: "open_conversation";
        conversationId?: string;
        threadId?: string;
        assistantId?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    kind?: "agent.completed";
    id?: string;
    createdAt?: string;
    source?: {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        assistantId?: string;
    };
    action?: {
        type?: "open_conversation";
        conversationId?: string;
        threadId?: string;
        assistantId?: string;
    };
    readAt?: string;
}, {
    kind?: "agent.completed";
    id?: string;
    createdAt?: string;
    source?: {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        assistantId?: string;
    };
    action?: {
        type?: "open_conversation";
        conversationId?: string;
        threadId?: string;
        assistantId?: string;
    };
    readAt?: string;
}>;
export type UserNotification = Omit<Required<z.output<typeof userNotificationSchema>>, 'source' | 'action'> & {
    source: Required<z.output<typeof notificationSourceSchema>>;
    action: Required<NonNullable<z.output<typeof userNotificationSchema>['action']>>;
};
export declare const notificationSnapshotSchema: z.ZodObject<{
    supported: z.ZodLiteral<true>;
    version: z.ZodString;
    announcements: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        category: z.ZodDefault<z.ZodEnum<["general", "maintenance", "model_retirement"]>>;
        severity: z.ZodDefault<z.ZodEnum<["info", "important"]>>;
        clients: z.ZodEffects<z.ZodArray<z.ZodEnum<["web", "desktop"]>, "many">, ("desktop" | "web")[], ("desktop" | "web")[]>;
        startsAt: z.ZodString;
        expiresAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        action: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            type: z.ZodLiteral<"link">;
            label: z.ZodString;
            url: z.ZodEffects<z.ZodString, string, string>;
        }, "strict", z.ZodTypeAny, {
            type?: "link";
            label?: string;
            url?: string;
        }, {
            type?: "link";
            label?: string;
            url?: string;
        }>>>;
    } & {
        id: z.ZodString;
        status: z.ZodEnum<["draft", "published", "withdrawn"]>;
        revision: z.ZodNumber;
        createdAt: z.ZodString;
        dismissedAt: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        status?: "withdrawn" | "draft" | "published";
        revision?: number;
        category?: "general" | "maintenance" | "model_retirement";
        id?: string;
        createdAt?: string;
        title?: string;
        expiresAt?: string;
        action?: {
            type?: "link";
            label?: string;
            url?: string;
        };
        body?: string;
        severity?: "info" | "important";
        clients?: ("desktop" | "web")[];
        startsAt?: string;
        dismissedAt?: string;
    }, {
        status?: "withdrawn" | "draft" | "published";
        revision?: number;
        category?: "general" | "maintenance" | "model_retirement";
        id?: string;
        createdAt?: string;
        title?: string;
        expiresAt?: string;
        action?: {
            type?: "link";
            label?: string;
            url?: string;
        };
        body?: string;
        severity?: "info" | "important";
        clients?: ("desktop" | "web")[];
        startsAt?: string;
        dismissedAt?: string;
    }>, "many">;
    notifications: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodLiteral<"agent.completed">;
        source: z.ZodObject<{
            type: z.ZodLiteral<"scheduled_task">;
            taskId: z.ZodString;
            executionId: z.ZodString;
            assistantId: z.ZodString;
            conversationId: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        }, {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        }>;
        createdAt: z.ZodString;
        readAt: z.ZodNullable<z.ZodString>;
        action: z.ZodObject<{
            type: z.ZodLiteral<"open_conversation">;
            assistantId: z.ZodString;
            conversationId: z.ZodString;
            threadId: z.ZodNullable<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        }, {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        kind?: "agent.completed";
        id?: string;
        createdAt?: string;
        source?: {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        };
        action?: {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        };
        readAt?: string;
    }, {
        kind?: "agent.completed";
        id?: string;
        createdAt?: string;
        source?: {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        };
        action?: {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        };
        readAt?: string;
    }>, "many">;
    hasMoreAnnouncements: z.ZodBoolean;
    hasMoreNotifications: z.ZodBoolean;
}, "strict", z.ZodTypeAny, {
    version?: string;
    supported?: true;
    announcements?: {
        status?: "withdrawn" | "draft" | "published";
        revision?: number;
        category?: "general" | "maintenance" | "model_retirement";
        id?: string;
        createdAt?: string;
        title?: string;
        expiresAt?: string;
        action?: {
            type?: "link";
            label?: string;
            url?: string;
        };
        body?: string;
        severity?: "info" | "important";
        clients?: ("desktop" | "web")[];
        startsAt?: string;
        dismissedAt?: string;
    }[];
    notifications?: {
        kind?: "agent.completed";
        id?: string;
        createdAt?: string;
        source?: {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        };
        action?: {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        };
        readAt?: string;
    }[];
    hasMoreAnnouncements?: boolean;
    hasMoreNotifications?: boolean;
}, {
    version?: string;
    supported?: true;
    announcements?: {
        status?: "withdrawn" | "draft" | "published";
        revision?: number;
        category?: "general" | "maintenance" | "model_retirement";
        id?: string;
        createdAt?: string;
        title?: string;
        expiresAt?: string;
        action?: {
            type?: "link";
            label?: string;
            url?: string;
        };
        body?: string;
        severity?: "info" | "important";
        clients?: ("desktop" | "web")[];
        startsAt?: string;
        dismissedAt?: string;
    }[];
    notifications?: {
        kind?: "agent.completed";
        id?: string;
        createdAt?: string;
        source?: {
            type?: "scheduled_task";
            conversationId?: string;
            executionId?: string;
            taskId?: string;
            assistantId?: string;
        };
        action?: {
            type?: "open_conversation";
            conversationId?: string;
            threadId?: string;
            assistantId?: string;
        };
        readAt?: string;
    }[];
    hasMoreAnnouncements?: boolean;
    hasMoreNotifications?: boolean;
}>;
export type NotificationSnapshot = Omit<Required<z.output<typeof notificationSnapshotSchema>>, 'announcements' | 'notifications'> & {
    announcements: Announcement[];
    notifications: UserNotification[];
};
export declare const notificationChangeSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"sync.required">;
    eventId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    type?: "sync.required";
    schemaVersion?: 1;
    eventId?: string;
}, {
    type?: "sync.required";
    schemaVersion?: 1;
    eventId?: string;
}>;
export declare const notificationOutboxPayloadSchema: z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"changed">;
}, "strict", z.ZodTypeAny, {
    type?: "changed";
}, {
    type?: "changed";
}>, z.ZodObject<{
    type: z.ZodLiteral<"announcement.scheduled">;
    announcementId: z.ZodString;
    revision: z.ZodNumber;
    phase: z.ZodEnum<["start", "expiry"]>;
}, "strict", z.ZodTypeAny, {
    type?: "announcement.scheduled";
    revision?: number;
    phase?: "start" | "expiry";
    announcementId?: string;
}, {
    type?: "announcement.scheduled";
    revision?: number;
    phase?: "start" | "expiry";
    announcementId?: string;
}>, z.ZodObject<{
    type: z.ZodLiteral<"agent.completed">;
    source: z.ZodObject<{
        type: z.ZodLiteral<"scheduled_task">;
        taskId: z.ZodString;
        executionId: z.ZodString;
        assistantId: z.ZodString;
        conversationId: z.ZodString;
    } & {
        threadId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        threadId?: string;
        assistantId?: string;
    }, {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        threadId?: string;
        assistantId?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    type?: "agent.completed";
    source?: {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        threadId?: string;
        assistantId?: string;
    };
}, {
    type?: "agent.completed";
    source?: {
        type?: "scheduled_task";
        conversationId?: string;
        executionId?: string;
        taskId?: string;
        threadId?: string;
        assistantId?: string;
    };
}>]>;
export type NotificationOutboxPayload = z.output<typeof notificationOutboxPayloadSchema>;
export type NotificationDeliveryState = 'pending' | 'accepted' | 'delivered' | 'failed' | 'unknown' | 'cancelled';
export type NotificationDestination = {
    type: 'in_app';
    tenantId: string;
    userId: string;
} | {
    type: 'external_identity';
    tenantId: string;
    userId: string;
    integrationId: string;
    bindingId: string;
    bindingRevision: number;
};
export declare function parseAnnouncement(value: unknown): Announcement;
export declare function parseOpenConversationAction(value: unknown): OpenConversationAction;
export declare function parseUserNotification(value: unknown): UserNotification;
export declare function parseNotificationSnapshot(value: unknown): NotificationSnapshot;
