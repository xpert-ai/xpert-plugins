import { IWFNMiddleware, TAgentMiddlewareMeta, TXpertFeatures, XpertWorkspaceDataScope } from '@xpert-ai/contracts';
import { StructuredToolInterface } from '@langchain/core/tools';
import { RunnableToolLike } from '@langchain/core/runnables';
import { BaseStore } from '@langchain/langgraph';
import { AgentMiddleware } from './types';
import { PromiseOrValue } from '../../types';
import { AgentMiddlewareRuntimeApi } from './runtime';
import type { AgentInvocationScope } from '../runtime/types';
export interface IAgentMiddlewareContext {
    tenantId: string;
    organizationId?: string | null;
    userId: string;
    workspaceId?: string;
    projectId?: string;
    conversationId?: string;
    /** Persisted input message for this turn, when available. */
    inputMessageId?: string;
    executionId?: string;
    /** Originating Event Inbox receipt of this authorized wake, including same-scope child agents. */
    readonly eventReceiptId?: string;
    /** Omitted for legacy Assistant hosts. Project general agents must explicitly use project_agent. */
    callerType?: AgentInvocationScope['callerType'];
    threadId?: string;
    xpertId?: string;
    workspaceDataScope?: XpertWorkspaceDataScope | null;
    xpertFeatures?: TXpertFeatures | null;
    agentKey?: string;
    knowledgebaseIds?: string[];
    store?: BaseStore;
    node: IWFNMiddleware;
    tools: Map<string, StructuredToolInterface | RunnableToolLike>;
    runtime: AgentMiddlewareRuntimeApi;
}
export interface IAgentMiddlewareStrategy<T = unknown> {
    meta: TAgentMiddlewareMeta;
    /** Static Tool names exposed by this Middleware, for capability summaries without creating a runtime instance. */
    getToolNames?(options: T): readonly string[];
    /**
     * The host defaults omitted options to {} in preview and runtime, including context.node.options.
     * Explicit values (including null) remain subject to provider validation.
     * Providers with optional configuration should also handle omission from legacy hosts.
     */
    createMiddleware(options: T, context: IAgentMiddlewareContext): PromiseOrValue<AgentMiddleware>;
}
