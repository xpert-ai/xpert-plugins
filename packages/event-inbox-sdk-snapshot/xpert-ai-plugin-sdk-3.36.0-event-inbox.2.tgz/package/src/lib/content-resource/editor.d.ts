import { DiscoveryService, Reflector } from '@nestjs/core';
import type { ContentEditorRegistration, FileContentEditorRegistration, ResourceContentEditorRegistration } from '@xpert-ai/contracts';
import { BaseStrategyRegistry } from '../strategy';
import type { ContentDocumentModel, ContentDocumentScope } from './document';
import type { ContentResourceReference, ContentSourceInput } from './index';
import type { CollaborationSessionDescriptor } from '../collaboration/types';
export { supportsContentModel } from './editor-compatibility';
/** File codecs expose no cells, blocks or plugin-specific edit operations to the platform. */
export interface ContentFileEditor {
    readonly descriptor: FileContentEditorRegistration;
    create(): Promise<Buffer>;
    validateFile(buffer: Buffer): Promise<void>;
}
export interface ContentResourceEditorImplementation {
    readonly descriptor: ResourceContentEditorRegistration;
}
export type IContentEditorProvider = ContentDocumentModel | ContentFileEditor | ContentResourceEditorImplementation;
export declare function isTextContentEditor(provider: IContentEditorProvider): provider is ContentDocumentModel;
export declare function isFileContentEditor(provider: IContentEditorProvider): provider is ContentFileEditor;
export declare function isResourceContentEditor(provider: IContentEditorProvider): provider is ContentResourceEditorImplementation;
export declare const ContentEditorProvider: (key: string) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export declare class ContentEditorRegistry extends BaseStrategyRegistry<IContentEditorProvider> {
    constructor(discovery: DiscoveryService, reflector: Reflector);
    getTextModel(key: string, organizationId: string): ContentDocumentModel;
}
export interface ContentEditorFile {
    editorKey: string;
    projectId: string;
    path: string;
    title: string;
}
/** Resource owner supplies current identity/location and owns atomic versions, independent of format. */
export interface ContentResourceEditor {
    describe(input: ContentSourceInput): Promise<ContentEditorFile>;
    files?: {
        read(input: ContentSourceInput): Promise<{
            buffer: Buffer;
            revision: string;
            sequence?: number;
        }>;
        write(input: ContentSourceInput & {
            buffer: Buffer;
            expectedRevision: string;
        }): Promise<{
            revision: string;
            sequence?: number;
        }>;
    };
    /** Presence and revision notifications only; file bytes remain owned by the CAS writer above. */
    createSession?(input: ContentSourceInput): Promise<CollaborationSessionDescriptor>;
}
export type ContentEditorInput = ContentDocumentScope & {
    source: ContentResourceReference;
    editorKey?: string;
};
export type ContentFileEditorInput = ContentDocumentScope & {
    path: string;
    editorKey?: string;
};
export type ContentEditorPreferenceScope = 'resource' | 'project' | 'organization';
export interface ContentEditorPreferenceState {
    scope: ContentEditorPreferenceScope;
    editorKey: string | null;
    revision: number;
    canSet: boolean;
}
export interface ContentEditorResolution {
    registration: ContentEditorRegistration;
    file?: ContentEditorFile;
    resource?: import('@xpert-ai/contracts').ContentCatalogItem;
    canWrite: boolean;
    viewKey: string;
    selectionId?: string;
    parameters?: {
        contentProvider: string;
        contentId?: string;
        contentTitle?: string;
        contentEditor?: string;
        filePath?: string;
    };
    editors?: ResourceContentEditorRegistration[];
}
/** Trusted scope only. Every operation checks Project, Assistant binding and resource permissions. */
export interface ContentEditorsApi {
    /** Read resource, Project and organization editor preferences, including permission to change each scope. */
    preferences(input: ContentDocumentScope & {
        contentId: string;
    }): Promise<ContentEditorPreferenceState[]>;
    /** Set or clear a scoped preference using its exact revision; editorKey=null restores inherited selection. */
    setPreference(input: ContentDocumentScope & {
        contentId: string;
        scope: ContentEditorPreferenceScope;
        editorKey: string | null;
        expectedRevision: number;
    }): Promise<ContentEditorPreferenceState>;
    /** List editors available in the authorized scope; discovery alone does not grant access to a resource. */
    list(scope: ContentDocumentScope): Promise<ContentEditorRegistration[]>;
    /** Validate supplied bytes or create a blank file with the selected codec; does not persist a resource. */
    prepare(scope: ContentDocumentScope & {
        editorKey: string;
        buffer?: Buffer;
    }): Promise<{
        registration: FileContentEditorRegistration;
        buffer: Buffer;
    }>;
    /** Resolve an authorized resource to a compatible editor and host navigation, honoring editor preferences. */
    resolve(input: ContentEditorInput): Promise<ContentEditorResolution>;
    /** Resolve a Project path through its live resource owner, falling back to a file codec only when unmanaged. */
    resolveFile(input: ContentFileEditorInput): Promise<ContentEditorResolution>;
    /** Read and validate an unmanaged Project file; revision is its current hash. Owned files must use read(). */
    readFile(input: ContentFileEditorInput): Promise<ContentEditorResolution & {
        buffer: Buffer;
        revision: string;
    }>;
    /** Validate and atomically replace an unmanaged file at expectedRevision; reject owned paths and stale hashes. */
    writeFile(input: ContentFileEditorInput & {
        buffer: Buffer;
        expectedRevision: string;
    }): Promise<{
        revision: string;
    }>;
    /** Read a resource owner's current file and opaque revision; sequence and collaboration are optional owner capabilities. */
    read(input: ContentEditorInput): Promise<ContentEditorResolution & {
        buffer: Buffer;
        revision: string;
        sequence?: number;
        collaboration?: boolean;
    }>;
    /** Validate bytes and publish through the owner using expectedRevision; the owner enforces atomic versions and history. */
    write(input: ContentEditorInput & {
        buffer: Buffer;
        expectedRevision: string;
    }): Promise<{
        revision: string;
        sequence?: number;
    }>;
    /** Create an authorized presence/revision session when supported; file writes still use write(), not this channel. */
    createSession(input: ContentEditorInput): Promise<CollaborationSessionDescriptor>;
}
export declare const ContentEditorsRuntimeCapability: import("../core/runtime-capability").RuntimeCapabilityKey<ContentEditorsApi>;
